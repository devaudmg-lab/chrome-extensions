const enabledEl = document.getElementById("enabled");
const siteEl = document.getElementById("siteEnabled");
const maxEl = document.getElementById("maxScale");
const spaceEl = document.getElementById("spacePan");
const loupeBtn = document.getElementById("loupeBtn");
const statusEl = document.getElementById("status");
let host = "";
let isFile = false;
let tabId = null;

function showStatus(text) {
  statusEl.textContent = text;
  statusEl.style.display = "block";
}

async function init() {
  // activeTab (granted by opening this popup) lets us read the current tab's address
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  tabId = tab && tab.id;
  try {
    const url = new URL(tab.url);
    if (/^(https?|file):$/.test(url.protocol)) host = url.hostname || "local files";
    isFile = url.protocol === "file:";
  } catch (err) {
    /* no url: browser page */
  }

  chrome.storage.sync.get({ enabled: true, maxScale: 10, disabledSites: [], onboarded: false, spacePan: true }, (s) => {
    enabledEl.checked = s.enabled !== false;
    spaceEl.checked = s.spacePan !== false;
    maxEl.value = ["3", "5", "10"].includes(String(s.maxScale)) ? String(s.maxScale) : "10";
    if (host) {
      document.getElementById("siteLabel").textContent = "Enabled on " + host;
      siteEl.checked = !s.disabledSites.includes(host);
    } else {
      document.getElementById("siteLabel").textContent = "This page cannot be zoomed";
      siteEl.disabled = true;
      loupeBtn.disabled = true;
    }
    if (!s.onboarded) document.getElementById("tip").hidden = false;
    refreshLoupeButton();
  });

  // Tabs that were open before the extension was installed or updated have no content script yet
  if (host && tabId) {
    chrome.tabs.sendMessage(tabId, { action: "ping" }, { frameId: 0 }).catch(() => {
      contentMissing = true;
      loupeBtn.disabled = true;
      showStatus(
        isFile
          ? 'For local files, turn on "Allow access to file URLs" in the extension details, then reload.'
          : "Reload this tab to use Smooth Zoom on it.",
      );
    });
  }
}

let contentMissing = false;

// Saves settings and reports problems (for example the sync storage quota being full)
function save(obj) {
  chrome.storage.sync.set(obj, () => {
    if (chrome.runtime.lastError) showStatus("Could not save: " + chrome.runtime.lastError.message);
  });
}

function refreshLoupeButton() {
  if (!host || contentMissing) return;
  loupeBtn.disabled = !enabledEl.checked || !siteEl.checked;
}

enabledEl.addEventListener("change", () => {
  save({ enabled: enabledEl.checked });
  refreshLoupeButton();
});
siteEl.addEventListener("change", () => {
  chrome.storage.sync.get({ disabledSites: [] }, (s) => {
    const list = s.disabledSites.filter((h) => h !== host);
    if (!siteEl.checked) list.push(host);
    save({ disabledSites: list });
  });
  refreshLoupeButton();
});
maxEl.addEventListener("change", () => {
  save({ maxScale: Number(maxEl.value) });
});
spaceEl.addEventListener("change", () => {
  save({ spacePan: spaceEl.checked });
});

loupeBtn.addEventListener("click", async () => {
  try {
    const res = await chrome.tabs.sendMessage(tabId, { action: "toggleLoupe" }, { frameId: 0 });
    if (res && res.ok) window.close();
    else showStatus("Zoom is turned off on this site.");
  } catch (err) {
    showStatus("Reload this tab first, then try again.");
  }
});

document.getElementById("tipOk").addEventListener("click", () => {
  document.getElementById("tip").hidden = true;
  save({ onboarded: true });
});

chrome.commands.getAll((commands) => {
  const c = commands.find((x) => x.name === "toggle-loupe");
  if (c) document.getElementById("loupeKey").textContent = c.shortcut || "not set";
});

document.getElementById("shortcuts").addEventListener("click", (e) => {
  e.preventDefault();
  chrome.tabs.create({ url: "chrome://extensions/shortcuts" });
});

init();
