const enabledEl = document.getElementById("enabled");
const maxEl = document.getElementById("maxScale");

chrome.storage.sync.get({ enabled: true, maxScale: 10 }, (s) => {
  enabledEl.checked = s.enabled !== false;
  maxEl.value = String(s.maxScale);
});

enabledEl.addEventListener("change", () => {
  chrome.storage.sync.set({ enabled: enabledEl.checked });
});
maxEl.addEventListener("change", () => {
  chrome.storage.sync.set({ maxScale: Number(maxEl.value) });
});
