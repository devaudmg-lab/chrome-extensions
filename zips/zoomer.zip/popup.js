const enabledEl = document.getElementById("enabled");
const siteEl = document.getElementById("siteEnabled");
const maxEl = document.getElementById("maxScale");
const loupeBtn = document.getElementById("loupeBtn");
const statusEl = document.getElementById("status");
let host = "";
let tabId = null;

function showStatus(text) {
  statusEl.textContent = text;
  statusEl.style.display = "block";
}

async function init() {
  // activeTab (granted by opening this popup) lets us read the current tab's address
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  tabId = tab && tab.id;
  try {
    const url = new URL(tab.url);
    if (/^(https?|file):$/.test(url.protocol)) host = url.hostname || "local files";
  } catch (err) {
    /* no url: browser page */
  }

  chrome.storage.sync.get({ enabled: true, maxScale: 10, disabledSites: [], onboarded: false }, (s) => {
    enabledEl.checked = s.enabled !== false;
    maxEl.value = String(s.maxScale);
    if (host) {
      document.getElementById("siteLabel").textContent = "Enabled on " + host;
      siteEl.checked = !s.disabledSites.includes(host);
    } else {
      document.getElementById("siteLabel").textContent = "This page cannot be zoomed";
      siteEl.disabled = true;
      loupeBtn.disabled = true;
    }
    if (!s.onboarded) document.getElementById("tip").hidden = false;
    refreshLoupeButton();
  });
}

function refreshLoupeButton() {
  if (!host) return;
  loupeBtn.disabled = !enabledEl.checked || !siteEl.checked;
}

enabledEl.addEventListener("change", () => {
  chrome.storage.sync.set({ enabled: enabledEl.checked });
  refreshLoupeButton();
});
siteEl.addEventListener("change", () => {
  chrome.storage.sync.get({ disabledSites: [] }, (s) => {
    const list = s.disabledSites.filter((h) => h !== host);
    if (!siteEl.checked) list.push(host);
    chrome.storage.sync.set({ disabledSites: list });
  });
  refreshLoupeButton();
});
maxEl.addEventListener("change", () => {
  chrome.storage.sync.set({ maxScale: Number(maxEl.value) });
});

loupeBtn.addEventListener("click", async () => {
  try {
    const res = await chrome.tabs.sendMessage(tabId, { action: "toggleLoupe" });
    if (res && res.ok) window.close();
    else showStatus("Zoom is turned off on this site.");
  } catch (err) {
    showStatus("Reload this tab first, then try again.");
  }
});

document.getElementById("tipOk").addEventListener("click", () => {
  document.getElementById("tip").hidden = true;
  chrome.storage.sync.set({ onboarded: true });
});

chrome.commands.getAll((commands) => {
  const c = commands.find((x) => x.name === "toggle-loupe");
  if (c) document.getElementById("loupeKey").textContent = c.shortcut || "not set";
});

document.getElementById("shortcuts").addEventListener("click", (e) => {
  e.preventDefault();
  chrome.tabs.create({ url: "chrome://extensions/shortcuts" });
});

init();
