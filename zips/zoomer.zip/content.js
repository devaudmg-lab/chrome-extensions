(function () {
  // Guard against double injection (e.g. extension reloaded on an open tab)
  if (window.__smoothZoomLoaded) return;
  window.__smoothZoomLoaded = true;

  const root = document.documentElement;
  let scale = 1;
  let translateX = 0;
  let translateY = 0;
  let isPanning = false;
  let didPan = false;
  let handTool = false; // H toggles a Photoshop-style hand: left-drag pans, clicks don't reach the page
  let spaceHeld = false; // Space held down while zoomed = temporary hand (released = back to normal)
  let startX, startY, downX, downY;
  let lastMouseX = window.innerWidth / 2;
  let lastMouseY = window.innerHeight / 2;
  let hud = null;
  let hudTimer = null;
  let hudInTopLayer = false;

  // Page size before zooming (used to keep the zoomed page covering the window while panning)
  let docW = 0;
  let docH = 0;
  // position:fixed elements moved back to where they were on screen (see pinFixedElements)
  let pinned = [];

  let fitTarget = null; // element last fitted with Alt + click
  let loupe = null; // magnifier state while it is open
  let loupePower = 3;
  let loupeSize = 240;

  // Settings (changed from the toolbar popup)
  let enabled = true;
  let globalEnabled = true;
  let disabledSites = [];
  let maxScale = 10;
  let spacePan = true;
  const host = location.hostname || "local files";

  // False once the extension was reloaded or updated and this copy of the script is orphaned
  const extensionAlive = () => {
    try {
      return !!chrome.runtime.id;
    } catch (err) {
      return false;
    }
  };

  function updateEnabled() {
    enabled = globalEnabled && !disabledSites.includes(host);
    if (!enabled) {
      resetZoom();
      closeLoupe();
    }
  }

  try {
    chrome.storage.sync.get(
      { enabled: true, maxScale: 10, disabledSites: [], loupePower: 3, loupeSize: 240, spacePan: true },
      (s) => {
        if (chrome.runtime.lastError) return;
        globalEnabled = s.enabled !== false;
        disabledSites = Array.isArray(s.disabledSites) ? s.disabledSites : [];
        maxScale = Number(s.maxScale) || 10;
        loupePower = Number(s.loupePower) || 3;
        loupeSize = clampLoupeSize(Number(s.loupeSize) || 240);
        spacePan = s.spacePan !== false;
        updateEnabled();
      },
    );
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "sync") return;
      if (changes.enabled) globalEnabled = changes.enabled.newValue !== false;
      if (changes.disabledSites) disabledSites = changes.disabledSites.newValue || [];
      if (changes.maxScale) maxScale = Number(changes.maxScale.newValue) || 10;
      if (changes.spacePan) spacePan = changes.spacePan.newValue !== false;
      if (changes.loupePower && !loupe) loupePower = Number(changes.loupePower.newValue) || 3;
      if (changes.loupeSize && !loupe) loupeSize = clampLoupeSize(Number(changes.loupeSize.newValue) || 240);
      updateEnabled();
      if (enabled && scale > maxScale) zoomAt(lastMouseX, lastMouseY, maxScale / scale);
    });
  } catch (err) {
    /* storage unavailable: keep defaults */
  }

  // State is kept in data-* attributes on <html> (prefixed, so they never clash with the page's own
  // classes such as "is-zoomed").
  const setFlag = (name, on) => root.toggleAttribute("data-smooth-zoom-" + name, !!on);

  const initStyles = () => {
    if (document.getElementById("smooth-zoom-styles")) return;
    const style = document.createElement("style");
    style.id = "smooth-zoom-styles";
    style.textContent = `
      /* Styles only apply while zoomed: a transform on :root turns it into the containing block
         for position:fixed elements, which would break fixed headers at 1x.
         No will-change here: it makes Chrome scale a bitmap of the page, so text gets blurry.
         No page background either: pages without one would turn dark and hide their text.
         Scrollbars are left alone: hiding them changes the page width and re-flows the layout. */
      :root[data-smooth-zoom-zoomed] {
        transition: transform 0.1s cubic-bezier(0.2, 0, 0.2, 1);
        transform-origin: 0 0;
        cursor: crosshair;
      }
      /* No easing while dragging, otherwise panning lags behind the cursor */
      :root[data-smooth-zoom-zoomed][data-smooth-zoom-panning] {
        transition: none;
        cursor: grabbing;
      }
      /* Hand tool: grab cursor everywhere (links and text fields included), no text selection.
         Frames ignore the mouse, so a drag that starts over an embedded video or map still pans. */
      :root[data-smooth-zoom-hand], :root[data-smooth-zoom-hand] * {
        cursor: grab !important;
        user-select: none !important;
      }
      :root[data-smooth-zoom-hand][data-smooth-zoom-panning], :root[data-smooth-zoom-hand][data-smooth-zoom-panning] * {
        cursor: grabbing !important;
      }
      :root[data-smooth-zoom-hand] iframe, :root[data-smooth-zoom-panning] iframe {
        pointer-events: none !important;
      }
      #smooth-zoom-hud {
        all: initial;
        position: fixed;
        z-index: 2147483647;
        pointer-events: none;
        transform-origin: 0 0;
        background: rgba(17, 17, 17, 0.85);
        color: #fff;
        font: 600 13px/1 system-ui, sans-serif;
        white-space: nowrap;
        padding: 6px 10px;
        border-radius: 6px;
        transition: opacity 0.2s;
      }
      #smooth-zoom-loupe {
        all: initial;
        position: fixed;
        z-index: 2147483647;
        pointer-events: none;
        border-radius: 50%;
        border: 3px solid #fff;
        box-shadow: 0 0 0 2px #0d9488, 0 12px 40px rgba(0, 0, 0, 0.45);
        background-color: #fff;
        overflow: hidden;
      }
    `;
    (document.head || root).appendChild(style);
  };

  // Puts an element in the browser's top layer (above every page element and not affected by the
  // transform on :root). Returns false when popovers are not supported.
  function toTopLayer(el) {
    if (typeof el.showPopover !== "function") return false;
    try {
      el.popover = "manual";
      el.showPopover();
      return true;
    } catch (err) {
      return false;
    }
  }

  // Keep the zoomed page covering the whole window: panning stops at the page edges instead of
  // sliding the page out of view. A document point d appears on screen at translate + d * scale - scroll.
  function clampTranslate() {
    const vw = root.clientWidth || window.innerWidth;
    const vh = root.clientHeight || window.innerHeight;
    const w = Math.max(docW, vw);
    const h = Math.max(docH, document.body ? document.body.scrollHeight : 0, vh);
    translateX = Math.min(window.scrollX, Math.max(vw + window.scrollX - w * scale, translateX));
    translateY = Math.min(window.scrollY, Math.max(vh + window.scrollY - h * scale, translateY));
  }

  // Measure the page and prepare it, right before it goes from 100% to zoomed
  function beginZoom() {
    initStyles();
    docW = root.scrollWidth;
    docH = root.scrollHeight;
    pinFixedElements();
  }

  // With a transform on :root, position:fixed elements are placed relative to the top of the
  // document instead of the window. On a scrolled page, a fixed header, chat button or modal
  // would jump out of view. Shift them by the scroll offset so they stay where they were.
  function pinFixedElements() {
    const sx = window.scrollX;
    const sy = window.scrollY;
    if (!document.body || (!sx && !sy)) return;
    const all = document.body.getElementsByTagName("*");
    for (let i = 0; i < all.length; i++) {
      const el = all[i];
      if (el.id === "smooth-zoom-hud" || el.id === "smooth-zoom-loupe") continue;
      if (getComputedStyle(el).position !== "fixed") continue;
      if (!fixedToWindow(el)) continue;
      pinned.push({ el, translate: el.style.getPropertyValue("translate"), prio: el.style.getPropertyPriority("translate") });
      const cur = getComputedStyle(el).translate;
      const [cx = "0px", cy = "0px", cz] = cur && cur !== "none" ? cur.split(" ") : [];
      el.style.setProperty("translate", `calc(${cx} + ${sx}px) calc(${cy} + ${sy}px)${cz ? " " + cz : ""}`, "important");
    }
  }

  // Only fixed elements placed relative to the window: not those inside another fixed element
  // (they move with it) or inside an ancestor that already creates a containing block.
  function fixedToWindow(el) {
    for (let p = el.parentElement; p && p !== root && p !== document.body; p = p.parentElement) {
      const cs = getComputedStyle(p);
      if (cs.position === "fixed") return false;
      if (cs.transform !== "none" || cs.perspective !== "none" || cs.filter !== "none") return false;
      if (cs.translate !== "none" || cs.scale !== "none" || cs.rotate !== "none") return false;
      if (/transform|perspective|filter/.test(cs.willChange) || /paint|layout|strict|content/.test(cs.contain)) return false;
    }
    return true;
  }

  function unpinFixedElements() {
    for (const p of pinned) {
      if (p.translate) p.el.style.setProperty("translate", p.translate, p.prio);
      else p.el.style.removeProperty("translate");
    }
    pinned = [];
  }

  function applyTransform() {
    if (scale <= 1) {
      setFlag("zoomed", false);
      translateX = 0;
      translateY = 0;
      root.style.removeProperty("transform");
      unpinFixedElements();
      return;
    }
    clampTranslate();
    setFlag("zoomed", true);
    root.style.transform = `translate(${translateX}px, ${translateY}px) scale(${scale})`;
  }

  // Small "250%" badge in the top-right corner. In the top layer it is not scaled with the zoomed
  // page; where popovers are missing a fixed element is positioned/scaled with :root, so it is
  // counter-transformed instead.
  function showHud(text) {
    initStyles();
    if (!hud || !hud.isConnected) {
      hud = document.createElement("div");
      hud.id = "smooth-zoom-hud";
      hud.setAttribute("role", "status");
      (document.body || root).appendChild(hud);
      hudInTopLayer = toTopLayer(hud);
    }
    hud.textContent = text || (scale <= 1 ? "100%" : `${Math.round(scale * 100)}%`);
    hud.style.visibility = "";
    const desiredX = (root.clientWidth || window.innerWidth) - 16 - Math.max(74, hud.offsetWidth);
    const desiredY = 16;
    if (scale <= 1 || hudInTopLayer) {
      hud.style.left = desiredX + "px";
      hud.style.top = desiredY + "px";
      hud.style.transform = "";
    } else {
      hud.style.left = (desiredX + window.scrollX - translateX) / scale + "px";
      hud.style.top = (desiredY + window.scrollY - translateY) / scale + "px";
      hud.style.transform = `scale(${1 / scale})`;
    }
    hud.style.opacity = "1";
    clearTimeout(hudTimer);
    hudTimer = setTimeout(() => {
      if (hud) hud.style.opacity = "0";
    }, 900);
  }

  function updateHandFlag() {
    setFlag("hand", (handTool || spaceHeld) && scale > 1);
  }

  function setHandTool(on) {
    handTool = on;
    if (on) initStyles();
    updateHandFlag();
  }

  function endPan() {
    if (!isPanning) return;
    isPanning = false;
    setFlag("panning", false);
  }

  function resetZoom(quiet) {
    const wasZoomed = scale > 1;
    spaceHeld = false;
    setHandTool(false);
    fitTarget = null;
    scale = 1;
    translateX = 0;
    translateY = 0;
    endPan();
    applyTransform();
    if (wasZoomed && !quiet) showHud();
  }

  // Zoom so that an element (image, video, chart...) fills the window, centred
  function zoomToFit(el) {
    if (scale > 1 && fitTarget === el) {
      resetZoom();
      return;
    }
    closeLoupe();
    resetZoom(true);
    const r = el.getBoundingClientRect();
    if (!r.width || !r.height) return;
    const target = Math.min(maxScale, 0.94 * Math.min(window.innerWidth / r.width, window.innerHeight / r.height));
    if (target <= 1.05) {
      showHud("Already fits");
      return;
    }
    beginZoom();
    scale = target;
    // A document point d appears on screen at: translate + d * scale - scroll
    translateX = window.innerWidth / 2 + window.scrollX - (r.left + r.width / 2 + window.scrollX) * scale;
    translateY = window.innerHeight / 2 + window.scrollY - (r.top + r.height / 2 + window.scrollY) * scale;
    fitTarget = el;
    applyTransform();
    showHud();
  }

  // --- Magnifier loupe ---
  // A round lens that follows the mouse. It shows a magnified screenshot of the visible
  // tab (taken by background.js), so it also works on canvases, videos and maps.
  // The screenshot shows the whole tab, including cross-origin iframes the page itself
  // cannot read. So it never goes into the page DOM: it lives in an Image object in this
  // isolated content-script world and is drawn onto a canvas inside a *closed* shadow root.
  function clampLoupeSize(n) {
    return Math.round(Math.min(480, Math.max(140, n)));
  }

  function sizeLoupe() {
    const dpr = window.devicePixelRatio || 1;
    loupe.el.style.width = loupeSize + "px";
    loupe.el.style.height = loupeSize + "px";
    loupe.canvas.width = Math.round(loupeSize * dpr);
    loupe.canvas.height = Math.round(loupeSize * dpr);
  }

  function placeLoupe() {
    if (!loupe) return;
    const half = loupeSize / 2;
    loupe.el.style.left = lastMouseX - half + "px";
    loupe.el.style.top = lastMouseY - half + "px";
    const img = loupe.img;
    if (!img || !img.naturalWidth) return;
    const ctx = loupe.ctx;
    const ratio = img.naturalWidth / window.innerWidth; // screenshot pixels per CSS pixel
    const span = loupeSize / loupe.power; // CSS pixels of the page shown inside the lens
    ctx.fillStyle = "#fff";
    ctx.fillRect(0, 0, loupe.canvas.width, loupe.canvas.height);
    ctx.drawImage(
      img,
      (lastMouseX - span / 2) * ratio,
      (lastMouseY - span / 2) * ratio,
      span * ratio,
      span * ratio,
      0,
      0,
      loupe.canvas.width,
      loupe.canvas.height,
    );
  }

  async function captureForLoupe(attempt = 0) {
    if (!loupe) return;
    if (document.hidden) return; // a background tab can't be captured; refreshed when it is shown again
    const run = ++loupe.run;
    loupe.el.style.visibility = "hidden";
    // Hide the badge at once (its fade-out would still be visible in the screenshot)
    if (hud) hud.style.visibility = "hidden";
    await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
    let res = null;
    if (extensionAlive()) {
      try {
        res = await chrome.runtime.sendMessage({ action: "captureLoupe" });
      } catch (err) {
        res = null;
      }
    }
    if (!loupe || run !== loupe.run) return;
    if (!res || !res.dataUrl) {
      // Chrome allows only two screenshots per second: try again shortly
      if (res && /MAX_CAPTURE|quota/i.test(res.error || "") && attempt < 3) {
        loupe.scrollTimer = setTimeout(() => captureForLoupe(attempt + 1), 600);
        return;
      }
      closeLoupe();
      showHud(extensionAlive() ? "Loupe needs the shortcut or popup again" : "Reload the page to use the loupe");
      return;
    }
    const img = new Image();
    img.onload = () => {
      if (!loupe || run !== loupe.run) return;
      loupe.img = img;
      loupe.el.style.visibility = "visible";
      placeLoupe();
    };
    img.src = res.dataUrl;
  }

  function openLoupe() {
    if (!enabled || loupe) return;
    initStyles();
    resetZoom(true);
    const el = document.createElement("div");
    el.id = "smooth-zoom-loupe";
    el.setAttribute("aria-hidden", "true");
    const shadow = el.attachShadow({ mode: "closed" });
    const canvas = document.createElement("canvas");
    canvas.style.cssText = "display:block;width:100%;height:100%;border-radius:50%";
    shadow.appendChild(canvas);
    el.style.visibility = "hidden";
    (document.body || root).appendChild(el);
    toTopLayer(el); // above the page's own dialogs and popovers
    loupe = { el, canvas, ctx: canvas.getContext("2d"), img: null, power: loupePower, run: 0, scrollTimer: null };
    sizeLoupe();
    placeLoupe();
    captureForLoupe();
  }

  function closeLoupe() {
    if (!loupe) return;
    clearTimeout(loupe.scrollTimer);
    loupe.el.remove();
    loupe = null;
  }

  function refreshLoupeSoon() {
    if (!loupe) return;
    loupe.el.style.visibility = "hidden";
    clearTimeout(loupe.scrollTimer);
    loupe.scrollTimer = setTimeout(captureForLoupe, 350);
  }

  function setLoupePower(power) {
    loupe.power = Math.min(8, Math.max(1.5, power));
    loupePower = loupe.power;
    placeLoupe();
    showHud(`Loupe ${loupe.power.toFixed(1)}x`);
    saveSetting({ loupePower: Math.round(loupe.power * 100) / 100 });
  }

  function saveSetting(obj) {
    if (!extensionAlive()) return;
    try {
      chrome.storage.sync.set(obj, () => void chrome.runtime.lastError);
    } catch (err) {
      /* ignore */
    }
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.action === "ping") {
      sendResponse({ ok: true, enabled });
      return;
    }
    if (msg.action !== "toggleLoupe") return;
    if (!enabled) {
      sendResponse({ ok: false, disabled: true });
      return;
    }
    if (loupe) closeLoupe();
    else openLoupe();
    sendResponse({ ok: true, open: !!loupe });
  });

  // Zoom by `factor`, keeping the point under (clientX, clientY) fixed on screen.
  function zoomAt(clientX, clientY, factor) {
    const oldScale = scale;
    const next = Math.min(Math.max(1, scale * factor), maxScale);
    if (next === oldScale) return;
    if (oldScale <= 1) beginZoom();
    scale = next;

    // The transform is applied to :root, whose origin is the top-left of the
    // document, so the focal point has to include the current scroll offset.
    const fx = clientX + window.scrollX;
    const fy = clientY + window.scrollY;
    translateX = fx - (fx - translateX) * (scale / oldScale);
    translateY = fy - (fy - translateY) * (scale / oldScale);

    if (scale <= 1.01) {
      resetZoom();
    } else {
      applyTransform();
      showHud();
    }
  }

  window.addEventListener(
    "wheel",
    (e) => {
      // ONLY intercept if Alt is held. Otherwise, let the browser scroll.
      if (!enabled || !e.altKey || e.ctrlKey) return;
      // Shift + wheel is turned into a horizontal scroll on some systems
      const dy = e.deltaY || (e.shiftKey ? e.deltaX : 0);
      if (!dy) return;
      e.preventDefault();
      // While the loupe is open, Alt + scroll changes its power and Alt + Shift + scroll its size
      if (loupe) {
        if (e.shiftKey) {
          loupeSize = clampLoupeSize(loupeSize * (dy < 0 ? 1.1 : 1 / 1.1));
          sizeLoupe();
          placeLoupe();
          showHud(`Loupe size ${loupeSize}px`);
          saveSetting({ loupeSize });
        } else {
          setLoupePower(loupe.power * (dy < 0 ? 1.15 : 1 / 1.15));
        }
        return;
      }
      // Normalise line/page deltas (Firefox-style mice, some Windows drivers)
      const unit = e.deltaMode === 1 ? 33 : e.deltaMode === 2 ? window.innerHeight : 1;
      zoomAt(e.clientX, e.clientY, Math.pow(1.1, (-dy * unit) / 200));
    },
    { passive: false },
  );

  // --- Panning ---
  const startsPan = (e) => enabled && scale > 1 && (e.button === 1 || (e.button === 0 && (e.shiftKey || handTool || spaceHeld)));

  // The page must not see the pointer events of a pan either (maps and canvases would drag too)
  const swallowPointer = (e) => {
    if (isPanning || (e.type === "pointerdown" && startsPan(e))) e.stopPropagation();
  };
  window.addEventListener("pointerdown", swallowPointer, true);
  window.addEventListener("pointermove", swallowPointer, true);
  window.addEventListener("pointerup", swallowPointer, true);

  window.addEventListener(
    "mousedown",
    (e) => {
      if (!startsPan(e)) return;
      isPanning = true;
      didPan = false;
      downX = e.clientX;
      downY = e.clientY;
      startX = e.clientX - translateX;
      startY = e.clientY - translateY;
      setFlag("panning", true);
      e.preventDefault(); // also stops middle-click autoscroll and text selection
      e.stopPropagation();
    },
    true,
  );

  window.addEventListener(
    "mousemove",
    (e) => {
      lastMouseX = e.clientX;
      lastMouseY = e.clientY;
      if (loupe) placeLoupe();
      if (!isPanning) return;
      if (!e.buttons) {
        endPan(); // button released outside the window
        return;
      }
      e.stopPropagation();
      if (!didPan && Math.abs(e.clientX - downX) + Math.abs(e.clientY - downY) < 4) return;
      didPan = true;
      translateX = e.clientX - startX;
      translateY = e.clientY - startY;
      applyTransform();
    },
    true,
  );

  window.addEventListener(
    "mouseup",
    (e) => {
      if (!isPanning) return;
      endPan();
      e.stopPropagation();
      // After a real drag, swallow the click / auxclick that follows, so panning over a link
      // does not open it (Shift+click = new window, middle-click = new tab). A plain middle-click
      // or Shift+click without moving still works as usual.
      if (!didPan) return;
      suppressNextClick = true;
      setTimeout(() => (suppressNextClick = false), 50);
    },
    true,
  );
  window.addEventListener("blur", () => {
    endPan();
    if (spaceHeld) {
      spaceHeld = false;
      updateHandFlag();
    }
  });

  let suppressNextClick = false;
  const swallowClick = (e) => {
    // Alt + click on an image, video or chart: zoom it to fit the window (click again to reset).
    // Swallowing the click also stops Chrome's Alt+click "download link" on linked images.
    if (enabled && e.type === "click" && e.altKey && !e.ctrlKey && !e.metaKey && !suppressNextClick) {
      const media = e.target.closest && e.target.closest("img, video, canvas, svg, picture");
      if (media) {
        e.preventDefault();
        e.stopPropagation();
        zoomToFit(media.tagName === "PICTURE" ? media.querySelector("img") || media : media);
        return;
      }
    }
    // With the hand tool on, every click belongs to the hand: links and buttons are never triggered
    if ((handTool || spaceHeld) && scale > 1) {
      suppressNextClick = false;
      e.preventDefault();
      e.stopPropagation();
      return;
    }
    if (!suppressNextClick) return;
    suppressNextClick = false;
    e.preventDefault();
    e.stopPropagation();
  };
  window.addEventListener("click", swallowClick, true);
  window.addEventListener("auxclick", swallowClick, true);

  // The element that really has the focus or got the key (inside shadow roots too)
  function deepTarget(e) {
    const path = e.composedPath ? e.composedPath() : [];
    return path[0] instanceof Element ? path[0] : e.target;
  }

  const isTyping = (t) =>
    !!t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName) || t.getAttribute?.("role") === "textbox");

  // Space is only taken over while zoomed, never on pages with a video (Space = play/pause) and never
  // when the focus is on something that uses Space itself (buttons, links, players, sliders...).
  function spaceIsFree(t) {
    if (!spacePan || scale <= 1 || isTyping(t)) return false;
    if (document.querySelector("video")) return false;
    if (t && t !== document.body && t !== root && t.closest) {
      if (t.closest("a[href], button, summary, select, audio, video, iframe, [tabindex], [contenteditable], [role]")) return false;
    }
    return true;
  }

  // Keyboard zoom: Alt + "=" / "+" zoom in, Alt + "-" zoom out, Alt + 0 reset, Esc reset.
  window.addEventListener(
    "keydown",
    (e) => {
      if (!enabled) return;
      const key = e.key || ""; // Chrome autofill sends keydown events without a key
      const t = deepTarget(e);
      if (e.code === "Space" && !e.altKey && !e.ctrlKey && !e.metaKey && !e.shiftKey) {
        // Hold Space = temporary hand tool (repeats are swallowed too, so the page does not scroll)
        if (spaceHeld || (!e.repeat && spaceIsFree(t))) {
          if (!spaceHeld) {
            spaceHeld = true;
            initStyles();
            updateHandFlag();
          }
          e.preventDefault();
          e.stopPropagation();
        }
        return;
      }
      if (key === "Escape" && loupe) {
        closeLoupe();
        return;
      }
      // Esc leaves the hand tool first, a second Esc resets the zoom
      if (key === "Escape" && handTool) {
        setHandTool(false);
        showHud("Hand tool off");
        e.preventDefault();
        e.stopPropagation();
        return;
      }
      if (key === "Escape" && scale > 1) {
        resetZoom();
        return;
      }
      const typing = isTyping(t);
      // H toggles the hand tool (like Photoshop). Only while zoomed, so H keeps working normally on the page at 100%.
      if (e.code === "KeyH" && !typing && !e.altKey && !e.ctrlKey && !e.metaKey && !e.shiftKey && !e.repeat && scale > 1) {
        setHandTool(!handTool);
        showHud(handTool ? "✋ Hand tool: drag to move · H to exit" : "Hand tool off");
        e.preventDefault();
        e.stopPropagation();
        return;
      }
      // Arrow keys pan while zoomed (Shift = bigger steps), unless the focus is in a text field
      if (scale > 1 && !typing && !e.altKey && !e.ctrlKey && !e.metaKey && key.startsWith("Arrow")) {
        const step = e.shiftKey ? 240 : 80;
        if (key === "ArrowLeft") translateX += step;
        else if (key === "ArrowRight") translateX -= step;
        else if (key === "ArrowUp") translateY += step;
        else if (key === "ArrowDown") translateY -= step;
        applyTransform();
        e.preventDefault();
        e.stopPropagation();
        return;
      }
      if (!e.altKey || e.ctrlKey || e.metaKey) return;
      const code = e.code;
      let handled = true;
      if (code === "Equal" || code === "NumpadAdd") {
        if (loupe) setLoupePower(loupe.power * 1.25);
        else zoomAt(lastMouseX, lastMouseY, 1.25);
      } else if (code === "Minus" || code === "NumpadSubtract") {
        if (loupe) setLoupePower(loupe.power * 0.8);
        else zoomAt(lastMouseX, lastMouseY, 0.8);
      } else if ((code === "Digit0" || code === "Numpad0") && (scale > 1 || loupe)) {
        // Only while zoomed, so Alt + 0 still reaches the page at 100%
        closeLoupe();
        resetZoom();
      } else handled = false;
      if (handled) {
        e.preventDefault();
        e.stopPropagation();
      }
    },
    true,
  );

  window.addEventListener(
    "keyup",
    (e) => {
      if (e.code !== "Space" || !spaceHeld) return;
      spaceHeld = false;
      updateHandFlag();
      e.preventDefault();
      e.stopPropagation();
    },
    true,
  );

  // Keep the badge pinned to the corner while the zoomed page is scrolled
  window.addEventListener("scroll", () => {
    if (hud && hud.style.opacity === "1" && scale > 1) showHud(hud.textContent);
  });
  // The loupe shows a screenshot: hide it while anything scrolls (the window or a scrolling
  // panel, which does not fire a window scroll event) and take a new one afterwards
  document.addEventListener("scroll", refreshLoupeSoon, { capture: true, passive: true });
  window.addEventListener("resize", () => {
    if (!loupe) return;
    clearTimeout(loupe.scrollTimer);
    loupe.scrollTimer = setTimeout(captureForLoupe, 350);
  });
  document.addEventListener("visibilitychange", () => {
    if (!document.hidden && loupe) refreshLoupeSoon();
  });
})();
