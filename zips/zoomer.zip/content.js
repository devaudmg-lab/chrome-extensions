(function () {
  // Guard against double injection (e.g. extension reloaded on an open tab)
  if (window.__smoothZoomLoaded) return;
  window.__smoothZoomLoaded = true;

  let scale = 1;
  let translateX = 0;
  let translateY = 0;
  let isPanning = false;
  let didPan = false;
  let handTool = false; // H toggles a Photoshop-style hand: left-drag pans, clicks don't reach the page
  let startX, startY;
  let lastMouseX = window.innerWidth / 2;
  let lastMouseY = window.innerHeight / 2;
  let hud = null;
  let hudTimer = null;
  let hudInTopLayer = false;

  let fitTarget = null; // element last fitted with Alt + click
  let loupe = null; // magnifier state while it is open
  let loupePower = 3;

  // Settings (changed from the toolbar popup)
  let enabled = true;
  let globalEnabled = true;
  let disabledSites = [];
  let maxScale = 10;
  const host = location.hostname || "local files";

  function updateEnabled() {
    enabled = globalEnabled && !disabledSites.includes(host);
    if (!enabled) {
      resetZoom();
      closeLoupe();
    }
  }

  try {
    chrome.storage.sync.get({ enabled: true, maxScale: 10, disabledSites: [], loupePower: 3 }, (s) => {
      if (chrome.runtime.lastError) return;
      globalEnabled = s.enabled !== false;
      disabledSites = Array.isArray(s.disabledSites) ? s.disabledSites : [];
      maxScale = Number(s.maxScale) || 10;
      loupePower = Number(s.loupePower) || 3;
      updateEnabled();
    });
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "sync") return;
      if (changes.enabled) globalEnabled = changes.enabled.newValue !== false;
      if (changes.disabledSites) disabledSites = changes.disabledSites.newValue || [];
      if (changes.maxScale) maxScale = Number(changes.maxScale.newValue) || 10;
      updateEnabled();
      if (enabled && scale > maxScale) zoomAt(lastMouseX, lastMouseY, maxScale / scale);
    });
  } catch (err) {
    /* storage unavailable: keep defaults */
  }

  const initStyles = () => {
    if (document.getElementById("universal-zoom-styles")) return;
    const style = document.createElement("style");
    style.id = "universal-zoom-styles";
    style.textContent = `
      /* Styles only apply while zoomed: a transform / will-change on :root turns it into the
         containing block for position:fixed elements, which breaks fixed headers at 1x. */
      :root.is-zoomed {
        transition: transform 0.1s cubic-bezier(0.2, 0, 0.2, 1);
        transform-origin: 0 0;
        will-change: transform;
        background-color: #111;
        scrollbar-width: none;
        cursor: crosshair;
      }
      /* No easing while dragging, otherwise panning lags behind the cursor */
      :root.is-zoomed.is-zoom-panning {
        transition: none;
        cursor: grabbing;
      }
      /* Hand tool: grab cursor everywhere (links and text fields included), no text selection */
      :root.is-zoom-hand, :root.is-zoom-hand * {
        cursor: grab !important;
        user-select: none !important;
      }
      :root.is-zoom-hand.is-zoom-panning, :root.is-zoom-hand.is-zoom-panning * {
        cursor: grabbing !important;
      }
      #smooth-zoom-hud {
        all: initial;
        position: fixed;
        z-index: 2147483647;
        pointer-events: none;
        transform-origin: 0 0;
        background: rgba(17, 17, 17, 0.85);
        color: #fff;
        font: 600 13px/1 system-ui, sans-serif;
        padding: 6px 10px;
        border-radius: 6px;
        transition: opacity 0.2s;
      }
      #smooth-zoom-loupe {
        all: initial;
        position: fixed;
        z-index: 2147483647;
        pointer-events: none;
        border-radius: 50%;
        border: 3px solid #fff;
        box-shadow: 0 0 0 2px #0d9488, 0 12px 40px rgba(0, 0, 0, 0.45);
        background-color: #fff;
        background-repeat: no-repeat;
      }
    `;
    (document.head || document.documentElement).appendChild(style);
  };

  function applyTransform() {
    const root = document.documentElement;
    if (scale <= 1) {
      root.classList.remove("is-zoomed");
      translateX = 0;
      translateY = 0;
    } else {
      root.classList.add("is-zoomed");
    }

    root.style.transform =
      scale <= 1 ? "" : `translate3d(${translateX}px, ${translateY}px, 0) scale(${scale})`;
  }

  // Small "2.5x" badge in the top-right corner. While :root is transformed a fixed
  // element is positioned/scaled with it, so we counter-transform the badge.
  function showHud(text) {
    initStyles();
    if (!hud || !hud.isConnected) {
      hud = document.createElement("div");
      hud.id = "smooth-zoom-hud";
      (document.body || document.documentElement).appendChild(hud);
      // In the browser top layer the badge is not scaled with the zoomed page, so it stays sharp
      hudInTopLayer = false;
      if (typeof hud.showPopover === "function") {
        try {
          hud.popover = "manual";
          hud.showPopover();
          hudInTopLayer = true;
        } catch (err) {
          /* fall back to counter-scaling */
        }
      }
    }
    hud.textContent = text || (scale <= 1 ? "100%" : `${Math.round(scale * 100)}%`);
    const desiredX = window.innerWidth - 16 - Math.max(74, hud.offsetWidth);
    const desiredY = 16;
    if (scale <= 1 || hudInTopLayer) {
      hud.style.left = desiredX + "px";
      hud.style.top = desiredY + "px";
      hud.style.transform = "";
    } else {
      hud.style.left = (desiredX + window.scrollX - translateX) / scale + "px";
      hud.style.top = (desiredY + window.scrollY - translateY) / scale + "px";
      hud.style.transform = `scale(${1 / scale})`;
    }
    hud.style.opacity = "1";
    clearTimeout(hudTimer);
    hudTimer = setTimeout(() => {
      if (hud) hud.style.opacity = "0";
    }, 900);
  }

  function setHandTool(on) {
    handTool = on;
    if (on) initStyles();
    document.documentElement.classList.toggle("is-zoom-hand", on);
  }

  function resetZoom(quiet) {
    const wasZoomed = scale > 1;
    setHandTool(false);
    fitTarget = null;
    scale = 1;
    translateX = 0;
    translateY = 0;
    isPanning = false;
    document.documentElement.classList.remove("is-zoom-panning");
    applyTransform();
    if (wasZoomed && !quiet) showHud();
  }

  // Zoom so that an element (image, video, chart...) fills the window, centred
  function zoomToFit(el) {
    if (scale > 1 && fitTarget === el) {
      resetZoom();
      return;
    }
    resetZoom(true);
    const r = el.getBoundingClientRect();
    if (!r.width || !r.height) return;
    const target = Math.min(maxScale, 0.94 * Math.min(window.innerWidth / r.width, window.innerHeight / r.height));
    if (target <= 1.05) {
      showHud("Already fits");
      return;
    }
    initStyles();
    scale = target;
    // A document point d appears on screen at: translate + d * scale - scroll
    translateX = window.innerWidth / 2 + window.scrollX - (r.left + r.width / 2 + window.scrollX) * scale;
    translateY = window.innerHeight / 2 + window.scrollY - (r.top + r.height / 2 + window.scrollY) * scale;
    fitTarget = el;
    applyTransform();
    showHud();
  }

  // --- Magnifier loupe ---
  // A round lens that follows the mouse. It shows a magnified screenshot of the visible
  // tab (taken by background.js), so it also works on canvases, videos and maps.
  const LOUPE_SIZE = 240;
  function placeLoupe() {
    if (!loupe) return;
    const half = LOUPE_SIZE / 2;
    const p = loupe.power;
    loupe.el.style.left = lastMouseX - half + "px";
    loupe.el.style.top = lastMouseY - half + "px";
    loupe.el.style.backgroundSize = `${window.innerWidth * p}px ${window.innerHeight * p}px`;
    loupe.el.style.backgroundPosition = `${half - lastMouseX * p}px ${half - lastMouseY * p}px`;
  }

  async function captureForLoupe() {
    if (!loupe) return;
    const run = ++loupe.run;
    loupe.el.style.visibility = "hidden";
    if (hud) hud.style.opacity = "0";
    await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
    let res = null;
    try {
      res = await chrome.runtime.sendMessage({ action: "captureLoupe" });
    } catch (err) {
      res = null;
    }
    if (!loupe || run !== loupe.run) return;
    if (!res || !res.dataUrl) {
      closeLoupe();
      showHud("Loupe needs the shortcut or popup again");
      return;
    }
    loupe.el.style.backgroundImage = `url("${res.dataUrl}")`;
    loupe.el.style.visibility = "visible";
    placeLoupe();
  }

  function openLoupe() {
    if (!enabled || loupe) return;
    initStyles();
    resetZoom(true);
    const el = document.createElement("div");
    el.id = "smooth-zoom-loupe";
    el.style.width = LOUPE_SIZE + "px";
    el.style.height = LOUPE_SIZE + "px";
    (document.body || document.documentElement).appendChild(el);
    loupe = { el, power: loupePower, run: 0, scrollTimer: null };
    placeLoupe();
    captureForLoupe();
  }

  function closeLoupe() {
    if (!loupe) return;
    clearTimeout(loupe.scrollTimer);
    loupe.el.remove();
    loupe = null;
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.action !== "toggleLoupe") return;
    if (!enabled) {
      sendResponse({ ok: false, disabled: true });
      return;
    }
    if (loupe) closeLoupe();
    else openLoupe();
    sendResponse({ ok: true, open: !!loupe });
  });

  // Zoom by `factor`, keeping the point under (clientX, clientY) fixed on screen.
  function zoomAt(clientX, clientY, factor) {
    initStyles();
    const oldScale = scale;
    scale = Math.min(Math.max(1, scale * factor), maxScale);
    if (scale === oldScale) return;

    // The transform is applied to :root, whose origin is the top-left of the
    // document, so the focal point has to include the current scroll offset.
    const fx = clientX + window.scrollX;
    const fy = clientY + window.scrollY;
    translateX = fx - (fx - translateX) * (scale / oldScale);
    translateY = fy - (fy - translateY) * (scale / oldScale);

    if (scale <= 1.01) {
      resetZoom();
    } else {
      applyTransform();
      showHud();
    }
  }

  window.addEventListener(
    "wheel",
    (e) => {
      // ONLY intercept if Alt is held. Otherwise, let the browser scroll.
      if (!enabled || !e.altKey || e.ctrlKey) return;
      e.preventDefault();
      // While the loupe is open, Alt + scroll changes its magnification instead
      if (loupe) {
        loupe.power = Math.min(8, Math.max(1.5, loupe.power * (e.deltaY < 0 ? 1.15 : 1 / 1.15)));
        loupePower = loupe.power;
        placeLoupe();
        showHud(`Loupe ${loupe.power.toFixed(1)}x`);
        try {
          chrome.storage.sync.set({ loupePower: Math.round(loupe.power * 100) / 100 });
        } catch (err) {
          /* ignore */
        }
        return;
      }
      // Normalise line/page deltas (Firefox-style mice, some Windows drivers)
      const unit = e.deltaMode === 1 ? 33 : e.deltaMode === 2 ? window.innerHeight : 1;
      const delta = -e.deltaY * unit;
      zoomAt(e.clientX, e.clientY, Math.pow(1.1, delta / 200));
    },
    { passive: false },
  );

  // Panning Logic
  window.addEventListener(
    "mousedown",
    (e) => {
      if (!enabled || scale <= 1) return;
      if (e.button === 1 || (e.button === 0 && (e.shiftKey || handTool))) {
        isPanning = true;
        didPan = false;
        startX = e.clientX - translateX;
        startY = e.clientY - translateY;
        document.documentElement.classList.add("is-zoom-panning");
        e.preventDefault(); // also stops middle-click autoscroll
      }
    },
    true,
  );

  window.addEventListener(
    "mousemove",
    (e) => {
      lastMouseX = e.clientX;
      lastMouseY = e.clientY;
      if (loupe) placeLoupe();
      if (!isPanning) return;
      didPan = true;
      translateX = e.clientX - startX;
      translateY = e.clientY - startY;
      applyTransform();
    },
    true,
  );

  window.addEventListener(
    "mouseup",
    () => {
      if (!isPanning) return;
      isPanning = false;
      document.documentElement.classList.remove("is-zoom-panning");
      // Swallow the click / auxclick that follows, so panning over a link
      // does not open it (Shift+click = new window, middle-click = new tab).
      suppressNextClick = true;
      setTimeout(() => (suppressNextClick = false), 50);
    },
    true,
  );

  let suppressNextClick = false;
  const swallowClick = (e) => {
    // Alt + click on an image, video or chart: zoom it to fit the window (click again to reset).
    // Swallowing the click also stops Chrome's Alt+click "download link" on linked images.
    if (enabled && e.type === "click" && e.altKey && !e.ctrlKey && !e.metaKey && !suppressNextClick) {
      const media = e.target.closest && e.target.closest("img, video, canvas, svg, picture");
      if (media) {
        e.preventDefault();
        e.stopPropagation();
        zoomToFit(media.tagName === "PICTURE" ? media.querySelector("img") || media : media);
        return;
      }
    }
    // With the hand tool on, every click belongs to the hand: links and buttons are never triggered
    if (handTool && scale > 1) {
      suppressNextClick = false;
      e.preventDefault();
      e.stopPropagation();
      return;
    }
    if (!suppressNextClick) return;
    suppressNextClick = false;
    e.preventDefault();
    e.stopPropagation();
  };
  window.addEventListener("click", swallowClick, true);
  window.addEventListener("auxclick", swallowClick, true);

  // Keyboard zoom: Alt + "=" / "+" zoom in, Alt + "-" zoom out, Alt + 0 reset, Esc reset.
  window.addEventListener(
    "keydown",
    (e) => {
      if (!enabled) return;
      if (e.key === "Escape" && loupe) {
        closeLoupe();
        return;
      }
      // Esc leaves the hand tool first, a second Esc resets the zoom
      if (e.key === "Escape" && handTool) {
        setHandTool(false);
        showHud("Hand tool off");
        e.preventDefault();
        e.stopPropagation();
        return;
      }
      if (e.key === "Escape" && scale > 1) {
        resetZoom();
        return;
      }
      // Arrow keys pan while zoomed (Shift = bigger steps), unless the focus is in a text field
      const t = e.target;
      const typing = t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName));
      // H toggles the hand tool (like Photoshop). Only while zoomed, so H keeps working normally on the page at 100%.
      if (e.code === "KeyH" && !typing && !e.altKey && !e.ctrlKey && !e.metaKey && !e.shiftKey && !e.repeat && scale > 1) {
        setHandTool(!handTool);
        showHud(handTool ? "✋ Hand tool: drag to move · H to exit" : "Hand tool off");
        e.preventDefault();
        e.stopPropagation();
        return;
      }
      if (scale > 1 && !typing && !e.altKey && !e.ctrlKey && !e.metaKey && e.key.startsWith("Arrow")) {
        const step = e.shiftKey ? 240 : 80;
        if (e.key === "ArrowLeft") translateX += step;
        else if (e.key === "ArrowRight") translateX -= step;
        else if (e.key === "ArrowUp") translateY += step;
        else if (e.key === "ArrowDown") translateY -= step;
        applyTransform();
        e.preventDefault();
        e.stopPropagation();
        return;
      }
      if (!e.altKey || e.ctrlKey || e.metaKey) return;
      const code = e.code;
      let handled = true;
      if (code === "Equal" || code === "NumpadAdd") zoomAt(lastMouseX, lastMouseY, 1.25);
      else if (code === "Minus" || code === "NumpadSubtract") zoomAt(lastMouseX, lastMouseY, 0.8);
      else if (code === "Digit0" || code === "Numpad0") resetZoom();
      else handled = false;
      if (handled) {
        e.preventDefault();
        e.stopPropagation();
      }
    },
    true,
  );

  // Keep the badge pinned to the corner while the zoomed page is scrolled
  window.addEventListener("scroll", () => {
    if (hud && hud.style.opacity === "1" && scale > 1) showHud();
    // The loupe shows a screenshot: hide it while scrolling and take a new one afterwards
    if (loupe) {
      loupe.el.style.visibility = "hidden";
      clearTimeout(loupe.scrollTimer);
      loupe.scrollTimer = setTimeout(captureForLoupe, 350);
    }
  });
  window.addEventListener("resize", () => {
    if (!loupe) return;
    clearTimeout(loupe.scrollTimer);
    loupe.scrollTimer = setTimeout(captureForLoupe, 350);
  });
})();
