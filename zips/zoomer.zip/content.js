(function () {
  // Guard against double injection (e.g. extension reloaded on an open tab)
  if (window.__smoothZoomLoaded) return;
  window.__smoothZoomLoaded = true;

  let scale = 1;
  let translateX = 0;
  let translateY = 0;
  let isPanning = false;
  let didPan = false;
  let startX, startY;
  let lastMouseX = window.innerWidth / 2;
  let lastMouseY = window.innerHeight / 2;
  let hud = null;
  let hudTimer = null;

  // Settings (changed from the toolbar popup)
  let enabled = true;
  let maxScale = 10;

  try {
    chrome.storage.sync.get({ enabled: true, maxScale: 10 }, (s) => {
      if (chrome.runtime.lastError) return;
      enabled = s.enabled !== false;
      maxScale = Number(s.maxScale) || 10;
      if (!enabled) resetZoom();
    });
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "sync") return;
      if (changes.enabled) enabled = changes.enabled.newValue !== false;
      if (changes.maxScale) maxScale = Number(changes.maxScale.newValue) || 10;
      if (!enabled) resetZoom();
      else if (scale > maxScale) zoomAt(lastMouseX, lastMouseY, maxScale / scale);
    });
  } catch (err) {
    /* storage unavailable: keep defaults */
  }

  const initStyles = () => {
    if (document.getElementById("universal-zoom-styles")) return;
    const style = document.createElement("style");
    style.id = "universal-zoom-styles";
    style.textContent = `
      /* Styles only apply while zoomed: a transform / will-change on :root turns it into the
         containing block for position:fixed elements, which breaks fixed headers at 1x. */
      :root.is-zoomed {
        transition: transform 0.1s cubic-bezier(0.2, 0, 0.2, 1);
        transform-origin: 0 0;
        will-change: transform;
        background-color: #111;
        scrollbar-width: none;
        cursor: crosshair;
      }
      /* No easing while dragging, otherwise panning lags behind the cursor */
      :root.is-zoomed.is-zoom-panning {
        transition: none;
        cursor: grabbing;
      }
      #smooth-zoom-hud {
        all: initial;
        position: fixed;
        z-index: 2147483647;
        pointer-events: none;
        transform-origin: 0 0;
        background: rgba(17, 17, 17, 0.85);
        color: #fff;
        font: 600 13px/1 system-ui, sans-serif;
        padding: 6px 10px;
        border-radius: 6px;
        transition: opacity 0.2s;
      }
    `;
    (document.head || document.documentElement).appendChild(style);
  };

  function applyTransform() {
    const root = document.documentElement;
    if (scale <= 1) {
      root.classList.remove("is-zoomed");
      translateX = 0;
      translateY = 0;
    } else {
      root.classList.add("is-zoomed");
    }

    root.style.transform =
      scale <= 1 ? "" : `translate3d(${translateX}px, ${translateY}px, 0) scale(${scale})`;
  }

  // Small "2.5x" badge in the top-right corner. While :root is transformed a fixed
  // element is positioned/scaled with it, so we counter-transform the badge.
  function showHud() {
    initStyles();
    if (!hud || !hud.isConnected) {
      hud = document.createElement("div");
      hud.id = "smooth-zoom-hud";
      (document.body || document.documentElement).appendChild(hud);
    }
    hud.textContent = scale <= 1 ? "100%" : `${Math.round(scale * 100)}%`;
    const desiredX = window.innerWidth - 90;
    const desiredY = 16;
    if (scale <= 1) {
      hud.style.left = desiredX + "px";
      hud.style.top = desiredY + "px";
      hud.style.transform = "";
    } else {
      hud.style.left = (desiredX + window.scrollX - translateX) / scale + "px";
      hud.style.top = (desiredY + window.scrollY - translateY) / scale + "px";
      hud.style.transform = `scale(${1 / scale})`;
    }
    hud.style.opacity = "1";
    clearTimeout(hudTimer);
    hudTimer = setTimeout(() => {
      if (hud) hud.style.opacity = "0";
    }, 900);
  }

  function resetZoom() {
    const wasZoomed = scale > 1;
    scale = 1;
    translateX = 0;
    translateY = 0;
    isPanning = false;
    document.documentElement.classList.remove("is-zoom-panning");
    applyTransform();
    if (wasZoomed) showHud();
  }

  // Zoom by `factor`, keeping the point under (clientX, clientY) fixed on screen.
  function zoomAt(clientX, clientY, factor) {
    initStyles();
    const oldScale = scale;
    scale = Math.min(Math.max(1, scale * factor), maxScale);
    if (scale === oldScale) return;

    // The transform is applied to :root, whose origin is the top-left of the
    // document, so the focal point has to include the current scroll offset.
    const fx = clientX + window.scrollX;
    const fy = clientY + window.scrollY;
    translateX = fx - (fx - translateX) * (scale / oldScale);
    translateY = fy - (fy - translateY) * (scale / oldScale);

    if (scale <= 1.01) {
      resetZoom();
    } else {
      applyTransform();
      showHud();
    }
  }

  window.addEventListener(
    "wheel",
    (e) => {
      // ONLY intercept if Alt is held. Otherwise, let the browser scroll.
      if (!enabled || !e.altKey || e.ctrlKey) return;
      e.preventDefault();
      // Normalise line/page deltas (Firefox-style mice, some Windows drivers)
      const unit = e.deltaMode === 1 ? 33 : e.deltaMode === 2 ? window.innerHeight : 1;
      const delta = -e.deltaY * unit;
      zoomAt(e.clientX, e.clientY, Math.pow(1.1, delta / 200));
    },
    { passive: false },
  );

  // Panning Logic
  window.addEventListener(
    "mousedown",
    (e) => {
      if (!enabled || scale <= 1) return;
      if (e.button === 1 || (e.button === 0 && e.shiftKey)) {
        isPanning = true;
        didPan = false;
        startX = e.clientX - translateX;
        startY = e.clientY - translateY;
        document.documentElement.classList.add("is-zoom-panning");
        e.preventDefault(); // also stops middle-click autoscroll
      }
    },
    true,
  );

  window.addEventListener(
    "mousemove",
    (e) => {
      lastMouseX = e.clientX;
      lastMouseY = e.clientY;
      if (!isPanning) return;
      didPan = true;
      translateX = e.clientX - startX;
      translateY = e.clientY - startY;
      applyTransform();
    },
    true,
  );

  window.addEventListener(
    "mouseup",
    () => {
      if (!isPanning) return;
      isPanning = false;
      document.documentElement.classList.remove("is-zoom-panning");
      // Swallow the click / auxclick that follows, so panning over a link
      // does not open it (Shift+click = new window, middle-click = new tab).
      suppressNextClick = true;
      setTimeout(() => (suppressNextClick = false), 50);
    },
    true,
  );

  let suppressNextClick = false;
  const swallowClick = (e) => {
    if (!suppressNextClick) return;
    suppressNextClick = false;
    e.preventDefault();
    e.stopPropagation();
  };
  window.addEventListener("click", swallowClick, true);
  window.addEventListener("auxclick", swallowClick, true);

  // Keyboard zoom: Alt + "=" / "+" zoom in, Alt + "-" zoom out, Alt + 0 reset, Esc reset.
  window.addEventListener(
    "keydown",
    (e) => {
      if (!enabled) return;
      if (e.key === "Escape" && scale > 1) {
        resetZoom();
        return;
      }
      if (!e.altKey || e.ctrlKey || e.metaKey) return;
      const code = e.code;
      let handled = true;
      if (code === "Equal" || code === "NumpadAdd") zoomAt(lastMouseX, lastMouseY, 1.25);
      else if (code === "Minus" || code === "NumpadSubtract") zoomAt(lastMouseX, lastMouseY, 0.8);
      else if (code === "Digit0" || code === "Numpad0") resetZoom();
      else handled = false;
      if (handled) {
        e.preventDefault();
        e.stopPropagation();
      }
    },
    true,
  );

  // Keep the badge pinned to the corner while the zoomed page is scrolled
  window.addEventListener("scroll", () => {
    if (hud && hud.style.opacity === "1" && scale > 1) showHud();
  });
})();
