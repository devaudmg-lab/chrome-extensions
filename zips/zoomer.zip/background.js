// Magnifier loupe. The keyboard shortcut (or the popup button) grants activeTab for the
// current tab, which is what allows captureVisibleTab below. No <all_urls> host access needed.
chrome.commands.onCommand.addListener(async (command, tab) => {
  if (command !== "toggle-loupe") return;
  if (!tab) [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.id) return;
  try {
    await chrome.tabs.sendMessage(tab.id, { action: "toggleLoupe" }, { frameId: 0 });
  } catch (err) {
    /* page without the content script (chrome://, Web Store, or opened before install) */
  }
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action !== "captureLoupe" || !sender.tab || sender.id !== chrome.runtime.id) return;
  capture(sender)
    .then((dataUrl) => sendResponse({ dataUrl }))
    .catch((err) => sendResponse({ error: String((err && err.message) || err) }));
  return true; // async response
});

// captureVisibleTab captures whatever tab is visible in the window. Only answer the top frame of
// that visible tab, so a page in a background tab can never receive a picture of another tab.
async function capture(sender) {
  if (sender.frameId !== 0) throw new Error("Not the top frame");
  const tab = await chrome.tabs.get(sender.tab.id);
  if (!tab.active) throw new Error("Tab is not visible");
  return chrome.tabs.captureVisibleTab(tab.windowId, { format: "png" });
}
