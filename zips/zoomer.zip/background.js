// Magnifier loupe. The keyboard shortcut (or the popup button) grants activeTab for the
// current tab, which is what allows captureVisibleTab below. No <all_urls> host access needed.
chrome.commands.onCommand.addListener(async (command, tab) => {
  if (command !== "toggle-loupe") return;
  if (!tab) [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.id) return;
  try {
    await chrome.tabs.sendMessage(tab.id, { action: "toggleLoupe" });
  } catch (err) {
    /* page without the content script (chrome://, Web Store, or opened before install) */
  }
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action !== "captureLoupe" || !sender.tab) return;
  chrome.tabs
    .captureVisibleTab(sender.tab.windowId, { format: "png" })
    .then((dataUrl) => sendResponse({ dataUrl }))
    .catch((err) => sendResponse({ error: String(err && err.message) }));
  return true; // async response
});
