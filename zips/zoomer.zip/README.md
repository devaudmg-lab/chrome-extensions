# Smooth Keyboard & Mouse Zoom

Zoom into any web page toward your mouse pointer, like in a map or design tool. It is useful for small diagrams, fine print and image details. The page layout stays the same, because the zoom is a GPU transform and not a text-size change.

## Features

- **Alt + scroll**: zooms in and out around the mouse pointer (up to 1000%).
- **Alt + Plus / Alt + Minus**: zoom with the keyboard, around the last mouse position.
- **Alt + 0 or Esc**: reset to 100%.
- **Pan**: hold the middle mouse button, or Shift + left-drag, to move around while zoomed. Links you pan over are not opened.
- **Zoom badge**: briefly shows the current zoom level in the corner.
- **Popup settings**: turn the extension on or off and choose the maximum zoom (300%, 500% or 1000%).

## Install (Load unpacked)

1. Download the ZIP and extract it to a folder.
2. Open `chrome://extensions` and turn on **Developer mode** (top right).
3. Click **Load unpacked** and select the extracted folder (the one that contains `manifest.json`).
4. Reload any tabs that were already open, then hold Alt and scroll.

Browser pages (`chrome://`, the Chrome Web Store) cannot be zoomed.

## Permissions

- **Read and change data on websites** (content script on all sites): needed to listen for Alt + scroll and to apply the zoom transform on the page. Nothing is read or sent anywhere.
- **storage**: saves your on/off and maximum-zoom settings.

The extension has no server, no analytics and no network requests.
