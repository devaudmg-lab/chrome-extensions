# Smooth Keyboard & Mouse Zoom

Zoom into any web page toward your mouse pointer, like in a map or design tool. It is useful for small diagrams, fine print and image details. The page layout stays the same, because the zoom is a GPU transform and not a text-size change.

## Features

- **Alt + scroll**: zooms in and out around the mouse pointer (up to 1000%).
- **Alt + Plus / Alt + Minus**: zoom with the keyboard, around the last mouse position.
- **Alt + click an image** (new in 1.3): zooms an image, chart, video or canvas so it fills the window. Alt + click it again to go back. This also stops Chrome's Alt + click "download" on linked images.
- **Arrow keys** (new in 1.3): pan while zoomed. Hold Shift for bigger steps. Ignored while you are typing in a text field.
- **Pan with the mouse**: hold the middle mouse button, or Shift + left-drag. Links you pan over are not opened.
- **Magnifier loupe** (new in 1.3): press `Alt+Shift+M` (or use the popup button) for a round lens that follows the mouse. Alt + scroll changes its power (1.5x to 8x, remembered). It works on text, images, maps, canvases and videos. Scrolling refreshes it. `Esc` closes it.
- **Per-site on/off** (new in 1.3): turn zooming off for just the current site from the popup, for example a map or design tool that uses Alt + scroll itself.
- **Alt + 0 or Esc**: reset to 100%.
- **Zoom badge**: briefly shows the current zoom level in the corner. It now stays sharp at high zoom levels.
- **Popup**: on/off everywhere, on/off for this site, maximum zoom (300%, 500% or 1000%), loupe button, all shortcuts, first-run tip, and dark mode.

## Keyboard shortcuts

| Shortcut | Action |
| :--- | :--- |
| `Alt` + scroll | Zoom toward the mouse (with the loupe open: change loupe power) |
| `Alt` + `+` / `Alt` + `-` | Zoom in / out |
| `Alt` + click on an image | Zoom the image to fit / back |
| Arrow keys (`Shift` = faster) | Pan while zoomed |
| Middle-drag or `Shift` + drag | Pan while zoomed |
| `Alt+Shift+M` | Show / hide the magnifier loupe (change at `chrome://extensions/shortcuts`) |
| `Alt` + `0` or `Esc` | Reset zoom / close the loupe |

## Install (Load unpacked)

1. Download the ZIP and extract it to a folder.
2. Open `chrome://extensions` and turn on **Developer mode** (top right).
3. Click **Load unpacked** and select the extracted folder (the one that contains `manifest.json`).
4. Reload any tabs that were already open, then hold Alt and scroll.

Browser pages (`chrome://`, the Chrome Web Store) cannot be zoomed.

## Permissions

| Permission | Why |
| :--- | :--- |
| Read and change data on websites (content script on all sites) | Listens for Alt + scroll and the other shortcuts, and applies the zoom transform on the page. Nothing is read or sent anywhere. |
| `storage` | Saves your settings: on/off, sites where zoom is off, maximum zoom and loupe power. |
| `activeTab` (new in 1.3) | Only after you press the loupe shortcut or open the popup on a tab: lets the loupe take a screenshot of that visible tab to magnify it, and lets the popup show the site name for the per-site switch. The screenshot stays in the page's memory and is never saved or sent. |

The extension has no server, no analytics and no network requests.

## Changelog

- **1.3.0**: magnifier loupe, Alt + click to fit an image, arrow-key panning, per-site disable, sharper zoom badge, popup redesign with dark mode and first-run tip.
- **1.2.0**: keyboard zoom, zoom badge, popup settings, bug fixes.
