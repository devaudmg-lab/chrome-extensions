# Smooth Keyboard & Mouse Zoom

Zoom into any web page toward your mouse pointer, like in a map or design tool. It is useful for small diagrams, fine print and image details. The page layout stays the same, because the zoom is a CSS transform and not a text-size change, and text is redrawn sharp at every zoom level.

## Features

- **Alt + scroll**: zooms in and out around the mouse pointer (up to 1000%). Text and lines stay sharp (1.5.0).
- **Alt + Plus / Alt + Minus**: zoom with the keyboard, around the last mouse position.
- **Alt + click an image** (new in 1.3): zooms an image, chart, video or canvas so it fills the window. Alt + click it again to go back. This also stops Chrome's Alt + click "download" on linked images.
- **Arrow keys** (new in 1.3): pan while zoomed. Hold Shift for bigger steps. Ignored while you are typing in a text field.
- **Hand tool** (new in 1.4): press `H` while zoomed and drag with the left mouse button to move around the page, like Photoshop's hand tool. Links and buttons can't be clicked by accident while it's on, and maps or embedded players on the page don't drag along. Press `H` again or `Esc` to exit; it also turns off when the zoom is reset.
- **Hold Space for the hand** (new in 1.5): while zoomed, hold `Space` and drag; let go of Space to get the normal pointer back. It only applies while zoomed, so Space scrolls as usual at 100%. It is never used on pages with a video (Space = play/pause there) or when the focus is on a text field, button, link, slider or player. You can turn it off in the popup.
- **Panning stops at the page edges** (1.5): the zoomed page always fills the window, so it can't be dragged out of view.
- **Pan with the mouse**: hold the middle mouse button, or Shift + left-drag. Links you pan over are not opened.
- **Magnifier loupe** (new in 1.3): press `Alt+Shift+M` (or use the popup button) for a round lens that follows the mouse. Alt + scroll changes its power (1.5x to 8x), Alt + Shift + scroll its size (new in 1.5); both are remembered. Alt + Plus / Minus also change the power while it is open. It works on text, images, maps, canvases and videos. Scrolling the page or a scrolling panel refreshes it. `Esc` closes it.
- **Per-site on/off** (new in 1.3): turn zooming off for just the current site from the popup, for example a map or design tool that uses Alt + scroll itself.
- **Alt + 0 or Esc**: reset to 100%.
- **Zoom badge**: briefly shows the current zoom level in the corner. It now stays sharp at high zoom levels.
- **Fixed headers and pop-ups stay put** (1.5): zooming on a scrolled page no longer throws fixed headers, chat buttons or modal windows to the top of the document.
- **Popup**: on/off everywhere, on/off for this site, Space-to-pan switch, maximum zoom (300%, 500% or 1000%), loupe button, all shortcuts, first-run tip, and dark mode. It tells you when a tab needs a reload first.

## Keyboard shortcuts

| Shortcut | Action |
| :--- | :--- |
| `Alt` + scroll | Zoom toward the mouse (with the loupe open: change loupe power) |
| `Alt` + `Shift` + scroll | With the loupe open: change loupe size |
| `Alt` + `+` / `Alt` + `-` | Zoom in / out |
| `Alt` + click on an image | Zoom the image to fit / back |
| Arrow keys (`Shift` = faster) | Pan while zoomed |
| `H` | Hand tool on/off while zoomed (drag to move, `Esc` exits) |
| Hold `Space` | Hand tool while held (zoomed only, can be turned off) |
| Middle-drag or `Shift` + drag | Pan while zoomed |
| `Alt+Shift+M` | Show / hide the magnifier loupe (change at `chrome://extensions/shortcuts`) |
| `Alt` + `0` or `Esc` | Reset zoom / close the loupe (`Alt` + `0` is left to the page at 100%) |

## Install (Load unpacked)

1. Download the ZIP and extract it to a folder.
2. Open `chrome://extensions` and turn on **Developer mode** (top right).
3. Click **Load unpacked** and select the extracted folder (the one that contains `manifest.json`).
4. Reload any tabs that were already open, then hold Alt and scroll.

Browser pages (`chrome://`, the Chrome Web Store) cannot be zoomed.

## Permissions

| Permission | Why |
| :--- | :--- |
| Read and change data on websites (content script on all sites) | Listens for Alt + scroll and the other shortcuts, and applies the zoom transform on the page. Nothing is read or sent anywhere. |
| `storage` | Saves your settings: on/off, sites where zoom is off, maximum zoom, Space-to-pan, loupe power and size. |
| `activeTab` (new in 1.3) | Only after you press the loupe shortcut or open the popup on a tab: lets the loupe take a screenshot of that visible tab to magnify it, and lets the popup show the site name for the per-site switch. The screenshot is only handed to that tab while it is the visible tab, stays in the extension's isolated memory (drawn inside a closed shadow root the page can't read), and is never saved or sent. |

The extension has no server, no analytics and no network requests.

## Changelog

- **1.5.0**: hold Space for the hand tool; loupe size (Alt + Shift + scroll); panning stops at the page edges. Fixes: sharp text when zoomed (no more blurry bitmap), pages without a background no longer turn dark, fixed headers/modals stay in view on scrolled pages, scrollbars no longer hidden (no re-flow), middle-click and Shift + click on links work while zoomed, page maps/canvases no longer drag along with a pan, drags over iframes, no error on autofill key events, typing detection inside shadow DOM, Alt + 0 left to the page at 100%, Alt + Plus/Minus with the loupe open, badge no longer captured in the loupe, loupe refreshes after scrolling panels, background tabs can't receive a screenshot, prefixed state attributes (no clash with page classes), popup reload/file-access hints.
- **1.4.0**: Hand tool (`H`) for dragging around the zoomed page.
- **1.3.0**: magnifier loupe, Alt + click to fit an image, arrow-key panning, per-site disable, sharper zoom badge, popup redesign with dark mode and first-run tip.
- **1.2.0**: keyboard zoom, zoom badge, popup settings, bug fixes.
