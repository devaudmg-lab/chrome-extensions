// Sends a message to the tab's content script, injecting it first if it is
// missing (tab opened before the extension was installed or reloaded).
const sendToTab = (tabId, message, callback = () => {}) => {
  chrome.tabs.sendMessage(tabId, message, (response) => {
    if (!chrome.runtime.lastError) {
      callback(response);
      return;
    }
    chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] }, () => {
      if (chrome.runtime.lastError) {
        callback(null); // restricted page (chrome://, Web Store)
        return;
      }
      chrome.tabs.sendMessage(tabId, message, (retry) => {
        callback(chrome.runtime.lastError ? null : retry);
      });
    });
  });
};

const setBadge = (tabId, scrolling) => {
  chrome.action.setBadgeText({ tabId, text: scrolling ? "ON" : "" }).catch(() => {});
  if (scrolling) {
    chrome.action.setBadgeBackgroundColor({ tabId, color: "#6366f1" }).catch(() => {});
  }
};

const COMMAND_ACTIONS = {
  "toggle-scroll": "toggle",
  "speed-up": "faster",
  "speed-down": "slower",
};

chrome.commands.onCommand.addListener((command) => {
  const action = COMMAND_ACTIONS[command];
  if (!action) return;
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const activeTab = tabs[0];
    if (!activeTab?.id) return;
    sendToTab(activeTab.id, { action });
  });
});

// Content scripts report play/pause so the toolbar icon shows an "ON" badge
chrome.runtime.onMessage.addListener((message, sender) => {
  if (message.action === "state" && sender.tab?.id) {
    setBadge(sender.tab.id, !!message.scrolling);
  }
});

// A navigation reloads the page, which stops scrolling
chrome.tabs.onUpdated.addListener((tabId, info) => {
  if (info.status === "loading") setBadge(tabId, false);
});
