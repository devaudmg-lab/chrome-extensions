/**
 * Pro Auto Scroller - Engine with Spacebar Toggle, speed HUD and hotkeys
 */

if (typeof window.isAutoScrollInitialized === "undefined") {
  window.isAutoScrollInitialized = true;

  const MIN_SPEED = 0.1;
  const MAX_SPEED = 10;
  const PX_PER_SEC = 60; // speed 1.0 = 60 px per second (1px per frame at 60 Hz)

  let scrollSpeed = 0;
  let isScrolling = false;
  let animationId = null;
  let pendingScroll = 0; // accumulates sub-pixel speeds (< 1px/frame would otherwise never move)
  let scrollTarget = null; // element being scrolled (null = the window)
  let lastMovedAt = 0; // timestamp of the last scroll step that actually moved
  let lastFrameAt = 0; // timestamp of the previous animation frame (makes speed refresh-rate independent)

  // Settings (kept in sync with chrome.storage.local)
  let spacebarEnabled = true;
  let stopAtEnd = true;
  let showHud = true;
  let perSiteSpeed = true;

  const host = location.hostname;

  chrome.storage.local.get(["spacebarEnabled", "stopAtEnd", "showHud", "perSiteSpeed"], (r) => {
    if (r?.spacebarEnabled === false) spacebarEnabled = false;
    if (r?.stopAtEnd === false) stopAtEnd = false;
    if (r?.showHud === false) showHud = false;
    if (r?.perSiteSpeed === false) perSiteSpeed = false;
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (changes.spacebarEnabled) spacebarEnabled = changes.spacebarEnabled.newValue !== false;
    if (changes.stopAtEnd) stopAtEnd = changes.stopAtEnd.newValue !== false;
    if (changes.perSiteSpeed) perSiteSpeed = changes.perSiteSpeed.newValue !== false;
    if (changes.showHud) {
      showHud = changes.showHud.newValue !== false;
      updateHud();
    }
  });

  const clampSpeed = (s) => Math.round(Math.min(MAX_SPEED, Math.max(MIN_SPEED, s)) * 10) / 10;

  // Saves the speed as the global default and, if enabled, for this site
  const rememberSpeed = (speed) => {
    if (!(speed > 0)) return;
    chrome.storage.local.get(["siteSpeeds"], (r) => {
      const data = { savedSpeed: speed };
      if (perSiteSpeed && host) {
        const siteSpeeds = r?.siteSpeeds || {};
        siteSpeeds[host] = speed;
        data.siteSpeeds = siteSpeeds;
      }
      chrome.storage.local.set(data);
    });
  };

  // Speed for this page: the per-site speed if there is one, else the last used speed
  const loadSpeed = (callback) => {
    chrome.storage.local.get(["savedSpeed", "siteSpeeds", "perSiteSpeed"], (r) => {
      const site = r?.perSiteSpeed !== false ? parseFloat(r?.siteSpeeds?.[host]) : NaN;
      const saved = parseFloat(r?.savedSpeed);
      callback(site > 0 ? site : saved > 0 ? saved : 1.0);
    });
  };

  const getRootScroller = () => document.scrollingElement || document.documentElement;

  const canScroll = (el) => el && el.scrollHeight - el.clientHeight > 20;

  // Pages like web apps and chat UIs keep the window fixed and scroll an inner
  // container instead. Pick the window if it scrolls, otherwise the largest
  // visible scrollable element.
  const findScrollTarget = () => {
    const root = getRootScroller();
    if (canScroll(root)) return null;

    let best = null;
    let bestArea = 0;
    const all = document.body ? document.body.querySelectorAll("*") : [];
    for (const el of all) {
      if (!canScroll(el)) continue;
      const oy = getComputedStyle(el).overflowY;
      if (oy !== "auto" && oy !== "scroll" && oy !== "overlay") continue;
      const rect = el.getBoundingClientRect();
      const area = Math.max(0, rect.width) * Math.max(0, rect.height);
      if (area > bestArea) {
        best = el;
        bestArea = area;
      }
    }
    return best;
  };

  const getPos = () => (scrollTarget ? scrollTarget.scrollTop : window.scrollY);

  // Pixels left to scroll and the total scrollable distance
  const getRemaining = () => {
    if (scrollTarget) {
      const max = scrollTarget.scrollHeight - scrollTarget.clientHeight;
      return { left: Math.max(0, max - scrollTarget.scrollTop), max };
    }
    const max = getRootScroller().scrollHeight - window.innerHeight;
    return { left: Math.max(0, max - window.scrollY), max };
  };

  const isAtEnd = () => getRemaining().left <= 2;

  // ---------- Speed HUD (shadow DOM so page styles can't leak in) ----------
  let hudHost = null;
  let hud = null;
  let hudDismissed = false; // closed with x: stays hidden until the next start
  let hudTimer = null;
  let hudActive = false; // true once scrolling has started on this page (until stopped)

  const formatTimeLeft = (speed = scrollSpeed) => {
    const { left } = getRemaining();
    if (left <= 2) return "End of page";
    if (!(speed > 0)) return "";
    const secs = Math.round(left / (speed * PX_PER_SEC));
    if (secs < 60) return `${secs}s left`;
    const mins = Math.round(secs / 60);
    if (mins < 60) return `${mins} min left`;
    return `${Math.floor(mins / 60)} h ${mins % 60} min left`;
  };

  const ICON_PLAY = '<svg width="12" height="12" viewBox="0 0 12 12"><path d="M3 1.5v9l7.5-4.5z" fill="currentColor"/></svg>';
  const ICON_PAUSE =
    '<svg width="12" height="12" viewBox="0 0 12 12"><rect x="2" y="1.5" width="3" height="9" rx="1" fill="currentColor"/><rect x="7" y="1.5" width="3" height="9" rx="1" fill="currentColor"/></svg>';

  const buildHud = () => {
    hudHost = document.createElement("div");
    hudHost.id = "pro-auto-scroller-hud";
    hudHost.style.cssText = "all:initial;position:fixed;right:20px;bottom:20px;z-index:2147483647;";
    const root = hudHost.attachShadow({ mode: "closed" });
    root.innerHTML = `
      <style>
        .hud{display:flex;align-items:center;gap:6px;padding:6px 8px 6px 6px;border-radius:999px;
          background:rgba(15,23,42,.92);color:#f8fafc;font:600 12px/1 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;
          box-shadow:0 10px 30px -8px rgba(0,0,0,.45),0 0 0 1px rgba(255,255,255,.08);position:relative;overflow:hidden;
          backdrop-filter:blur(6px);user-select:none}
        button{all:unset;cursor:pointer;width:26px;height:26px;border-radius:50%;display:grid;place-items:center;
          color:#e2e8f0;font-size:14px;line-height:1}
        button:hover{background:rgba(255,255,255,.12)}
        button:focus-visible{outline:2px solid #a5b4fc}
        .play{background:#6366f1;color:#fff}
        .play:hover{background:#4f46e5}
        .speed{min-width:42px;text-align:center;font-size:13px;font-variant-numeric:tabular-nums}
        .speed small{color:#a5b4fc;font-size:11px}
        .left{color:#cbd5e1;font-weight:500;padding:0 4px 0 6px;border-left:1px solid rgba(255,255,255,.15);white-space:nowrap}
        .close{width:20px;height:20px;font-size:12px;color:#94a3b8}
        .bar{position:absolute;left:0;bottom:0;height:2px;background:#818cf8;width:0}
      </style>
      <div class="hud" role="toolbar" aria-label="Auto scroll controls">
        <button class="play" data-a="toggle" title="Play / pause (Space)"></button>
        <button data-a="slower" title="Slower (-)">&minus;</button>
        <span class="speed"><span class="num"></span><small>x</small></span>
        <button data-a="faster" title="Faster (+)">+</button>
        <span class="left"></span>
        <button class="close" data-a="close" title="Stop and hide (Esc)">&#x2715;</button>
        <div class="bar"></div>
      </div>`;
    hud = {
      play: root.querySelector(".play"),
      speedNum: root.querySelector(".speed .num"),
      left: root.querySelector(".left"),
      bar: root.querySelector(".bar"),
    };
    root.querySelector(".hud").addEventListener("click", (e) => {
      const a = e.target.closest("button")?.dataset.a;
      if (a === "toggle") toggleScroll();
      else if (a === "faster") changeSpeed(1);
      else if (a === "slower") changeSpeed(-1);
      else if (a === "close") {
        hudDismissed = true;
        scrollSpeed = 0;
        stopScroll();
      }
    });
    (document.body || document.documentElement).appendChild(hudHost);
  };

  const refreshHudText = () => {
    if (!hud) return;
    hud.play.innerHTML = isScrolling ? ICON_PAUSE : ICON_PLAY; // static SVG strings
    hud.play.setAttribute("aria-label", isScrolling ? "Pause" : "Play");
    hud.speedNum.textContent = (scrollSpeed || 0).toFixed(1);
    hud.left.textContent = formatTimeLeft();
    const { left, max } = getRemaining();
    hud.bar.style.width = max > 0 ? `${Math.min(100, ((max - left) / max) * 100)}%` : "0";
  };

  // HUD is visible while scrolling and while paused (speed kept); hidden when stopped
  const updateHud = () => {
    const visible = showHud && !hudDismissed && hudActive && scrollSpeed > 0;
    if (!visible) {
      if (hudHost) hudHost.style.display = "none";
      clearInterval(hudTimer);
      hudTimer = null;
      return;
    }
    if (!hudHost || !hudHost.isConnected) buildHud();
    hudHost.style.display = "block";
    refreshHudText();
    if (!hudTimer) hudTimer = setInterval(refreshHudText, 500);
  };

  const reportState = () => {
    chrome.runtime.sendMessage({ action: "state", scrolling: isScrolling }, () => void chrome.runtime.lastError);
    updateHud();
  };

  const stopScroll = () => {
    isScrolling = false;
    cancelAnimationFrame(animationId);
    animationId = null;
    if (scrollSpeed <= 0) hudActive = false;
    reportState();
  };

  const performScroll = (now = performance.now()) => {
    cancelAnimationFrame(animationId);
    animationId = null;
    if (!isScrolling || scrollSpeed <= 0) {
      if (isScrolling) stopScroll();
      return;
    }
    // Time-based so a 120 Hz screen doesn't scroll twice as fast; cap after tab switches
    const dt = Math.min(100, now - (lastFrameAt || now));
    lastFrameAt = now;
    pendingScroll += scrollSpeed * (dt / (1000 / PX_PER_SEC));
    const step = Math.floor(pendingScroll);
    if (step >= 1) {
      const before = getPos();
      if (scrollTarget) scrollTarget.scrollTop += step;
      else window.scrollBy(0, step);
      pendingScroll -= step;

      if (getPos() !== before) lastMovedAt = performance.now();

      // Auto-stop at the end of the page. Wait ~2s first so infinite-scroll
      // feeds get a chance to load more content.
      if (stopAtEnd && isAtEnd() && performance.now() - lastMovedAt > 2000) {
        stopScroll();
        return;
      }
    }
    animationId = requestAnimationFrame(performScroll);
  };

  const startScroll = () => {
    scrollTarget = findScrollTarget();
    lastMovedAt = performance.now();
    lastFrameAt = 0;
    isScrolling = true;
    hudActive = true;
    hudDismissed = false;
    reportState();
    performScroll();
  };

  const toggleScroll = () => {
    if (isScrolling) {
      stopScroll();
      return;
    }
    if (scrollSpeed > 0) {
      startScroll();
      return;
    }
    // Use the speed saved for this site (or the last used speed), falling back to 1.0
    loadSpeed((speed) => {
      scrollSpeed = speed;
      startScroll();
    });
  };

  // Faster / slower in ~15% steps (at least 0.1)
  const changeSpeed = (dir) => {
    // When stopped, step from this site's remembered speed instead of 1.0
    if (!(scrollSpeed > 0)) {
      loadSpeed((speed) => {
        scrollSpeed = speed;
        changeSpeed(dir);
      });
      return;
    }
    const base = scrollSpeed;
    const step = Math.max(0.1, Math.round(base * 0.15 * 10) / 10);
    scrollSpeed = clampSpeed(base + dir * step);
    rememberSpeed(scrollSpeed);
    if (!isScrolling) startScroll();
    else updateHud();
  };

  const isTyping = (el) => {
    const tag = (el?.tagName || "").toLowerCase();
    return tag === "input" || tag === "textarea" || tag === "select" || el?.isContentEditable;
  };

  // --- KEYBOARD: Space toggles; + / - change speed and Esc stops while active ---
  window.addEventListener("keydown", (e) => {
    if (e.defaultPrevented || e.ctrlKey || e.altKey || e.metaKey) return;
    if (isTyping(e.target) || (e.composedPath?.()[0] && isTyping(e.composedPath()[0]))) return;

    if (e.code === "Space" && spacebarEnabled && !e.shiftKey) {
      if ((e.target.tagName || "").toLowerCase() === "button") return;
      e.preventDefault(); // Stop the page from jumping down
      toggleScroll();
      return;
    }

    // Speed keys only act while the scroller is active, so they never hijack normal pages
    if (!hudActive || !(scrollSpeed > 0)) return;
    if (e.key === "+" || e.key === "=" || e.key === "]") {
      e.preventDefault();
      changeSpeed(1);
    } else if (e.key === "-" || e.key === "_" || e.key === "[") {
      e.preventDefault();
      changeSpeed(-1);
    } else if (e.key === "Escape") {
      scrollSpeed = 0;
      stopScroll();
    }
  });

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "setSpeed") {
      scrollSpeed = parseFloat(message.speed) || 0;
      if (scrollSpeed > 0) rememberSpeed(scrollSpeed);
      if (scrollSpeed > 0 && !isScrolling) {
        startScroll();
      } else if (scrollSpeed <= 0 && isScrolling) {
        stopScroll();
      } else {
        updateHud();
      }
    }

    if (message.action === "toggle") {
      toggleScroll();
    }

    if (message.action === "faster") changeSpeed(1);
    if (message.action === "slower") changeSpeed(-1);

    if (message.action === "stop") {
      scrollSpeed = 0;
      stopScroll();
    }

    if (message.action === "getSiteSpeed") {
      loadSpeed((speed) => {
        sendResponse({
          status: "ok",
          scrolling: isScrolling,
          speed: scrollSpeed,
          siteSpeed: speed,
          host,
          timeLeft: formatTimeLeft(scrollSpeed > 0 ? scrollSpeed : speed),
        });
      });
      return true;
    }

    // "getState" just falls through and reports the current state
    sendResponse({ status: "ok", scrolling: isScrolling, speed: scrollSpeed, host, timeLeft: isScrolling ? formatTimeLeft() : "" });
  });
}
