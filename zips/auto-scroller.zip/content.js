/**
 * Pro Auto Scroller - Engine with Spacebar Toggle
 */

if (typeof window.isAutoScrollInitialized === "undefined") {
  window.isAutoScrollInitialized = true;

  let scrollSpeed = 0;
  let isScrolling = false;
  let animationId = null;
  let pendingScroll = 0; // accumulates sub-pixel speeds (< 1px/frame would otherwise never move)
  let scrollTarget = null; // element being scrolled (null = the window)
  let lastMovedAt = 0; // timestamp of the last scroll step that actually moved

  // Settings (kept in sync with chrome.storage.local)
  let spacebarEnabled = true;
  let stopAtEnd = true;

  chrome.storage.local.get(["spacebarEnabled", "stopAtEnd"], (r) => {
    if (r?.spacebarEnabled === false) spacebarEnabled = false;
    if (r?.stopAtEnd === false) stopAtEnd = false;
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (changes.spacebarEnabled) spacebarEnabled = changes.spacebarEnabled.newValue !== false;
    if (changes.stopAtEnd) stopAtEnd = changes.stopAtEnd.newValue !== false;
  });

  const getRootScroller = () => document.scrollingElement || document.documentElement;

  const canScroll = (el) => el && el.scrollHeight - el.clientHeight > 20;

  // Pages like web apps and chat UIs keep the window fixed and scroll an inner
  // container instead. Pick the window if it scrolls, otherwise the largest
  // visible scrollable element.
  const findScrollTarget = () => {
    const root = getRootScroller();
    if (canScroll(root)) return null;

    let best = null;
    let bestArea = 0;
    const all = document.body ? document.body.querySelectorAll("*") : [];
    for (const el of all) {
      if (!canScroll(el)) continue;
      const oy = getComputedStyle(el).overflowY;
      if (oy !== "auto" && oy !== "scroll" && oy !== "overlay") continue;
      const rect = el.getBoundingClientRect();
      const area = Math.max(0, rect.width) * Math.max(0, rect.height);
      if (area > bestArea) {
        best = el;
        bestArea = area;
      }
    }
    return best;
  };

  const getPos = () => (scrollTarget ? scrollTarget.scrollTop : window.scrollY);

  const isAtEnd = () => {
    if (scrollTarget) {
      return scrollTarget.scrollTop + scrollTarget.clientHeight >= scrollTarget.scrollHeight - 2;
    }
    const root = getRootScroller();
    return window.scrollY + window.innerHeight >= root.scrollHeight - 2;
  };

  const stopScroll = () => {
    isScrolling = false;
    cancelAnimationFrame(animationId);
    animationId = null;
    reportState();
  };

  const reportState = () => {
    chrome.runtime.sendMessage({ action: "state", scrolling: isScrolling }, () => void chrome.runtime.lastError);
  };

  const performScroll = () => {
    cancelAnimationFrame(animationId);
    if (!isScrolling || scrollSpeed <= 0) {
      if (isScrolling) stopScroll();
      return;
    }
    pendingScroll += scrollSpeed;
    const step = Math.floor(pendingScroll);
    if (step >= 1) {
      const before = getPos();
      if (scrollTarget) scrollTarget.scrollTop += step;
      else window.scrollBy(0, step);
      pendingScroll -= step;

      if (getPos() !== before) lastMovedAt = performance.now();

      // Auto-stop at the end of the page. Wait ~2s first so infinite-scroll
      // feeds get a chance to load more content.
      if (stopAtEnd && isAtEnd() && performance.now() - lastMovedAt > 2000) {
        stopScroll();
        return;
      }
    }
    animationId = requestAnimationFrame(performScroll);
  };

  const startScroll = () => {
    scrollTarget = findScrollTarget();
    lastMovedAt = performance.now();
    isScrolling = true;
    reportState();
    performScroll();
  };

  const toggleScroll = () => {
    if (isScrolling) {
      stopScroll();
      return;
    }
    if (scrollSpeed > 0) {
      startScroll();
      return;
    }
    // Use the speed saved from the popup, falling back to 1.0
    chrome.storage.local.get(["savedSpeed"], (result) => {
      const saved = parseFloat(result?.savedSpeed);
      scrollSpeed = saved > 0 ? saved : 1.0;
      startScroll();
    });
  };

  // --- SPACEBAR INTERCEPTOR ---
  window.addEventListener("keydown", (e) => {
    if (!spacebarEnabled) return;

    // Only trigger if the user isn't typing in an input box or textarea
    const target = (e.target.tagName || "").toLowerCase();
    if (
      target === "input" ||
      target === "textarea" ||
      target === "select" ||
      target === "button" ||
      e.target.isContentEditable
    ) {
      return;
    }

    if (e.code === "Space" && !e.ctrlKey && !e.altKey && !e.metaKey && !e.shiftKey && !e.defaultPrevented) {
      e.preventDefault(); // Stop the page from jumping down
      toggleScroll();
    }
  });

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "setSpeed") {
      scrollSpeed = parseFloat(message.speed) || 0;
      if (scrollSpeed > 0 && !isScrolling) {
        startScroll();
      } else if (scrollSpeed <= 0 && isScrolling) {
        stopScroll();
      }
    }

    if (message.action === "toggle") {
      toggleScroll();
    }

    if (message.action === "stop") {
      scrollSpeed = 0;
      stopScroll();
    }

    // "getState" just falls through and reports the current state
    sendResponse({ status: "ok", scrolling: isScrolling, speed: scrollSpeed });
  });
}
