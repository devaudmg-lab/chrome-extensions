/**
 * Pro Auto Scroller - Engine with Spacebar Toggle, speed HUD and hotkeys
 */

(() => {
  // After an extension update or reload, Chrome injects this script again into
  // the same isolated world. Tear down the old (orphaned) instance first so it
  // doesn't keep its listeners and its HUD around.
  try {
    window.__proAutoScroller?.destroy?.();
  } catch (_) {
    /* old instance already gone */
  }

  const MIN_SPEED = 0.1;
  const MAX_SPEED = 10;
  const PX_PER_SEC = 60; // speed 1.0 = 60 px per second (1px per frame at 60 Hz)
  const MAX_SITES = 500; // cap for per-site maps in storage
  const AUTO_START_DELAY = 1500; // ms after load before auto-start kicks in

  let scrollSpeed = 0;
  let isScrolling = false;
  let animationId = null;
  let pendingScroll = 0; // accumulates sub-pixel speeds (< 1px/frame would otherwise never move)
  let scrollTarget = null; // element being scrolled (null = the window)
  let lastMovedAt = 0; // timestamp of the last scroll step that actually moved
  let lastFrameAt = 0; // timestamp of the previous animation frame (makes speed refresh-rate independent)
  let destroyed = false;

  // Settings (kept in sync with chrome.storage.local)
  let spacebarEnabled = true; // Space pauses / resumes while the scroller is active
  let spaceStarts = false; // Space also starts scrolling on pages where it isn't active (opt-in)
  let stopAtEnd = true;
  let showHud = true;
  let perSiteSpeed = true;

  const host = location.hostname;

  // An orphaned script (extension updated or removed) loses chrome.runtime
  const alive = () => {
    if (destroyed) return false;
    if (!chrome.runtime?.id) {
      destroy();
      return false;
    }
    return true;
  };

  const onStorageChanged = (changes, area) => {
    if (area !== "local" || !alive()) return;
    if (changes.spacebarEnabled) spacebarEnabled = changes.spacebarEnabled.newValue !== false;
    if (changes.spaceStarts) spaceStarts = changes.spaceStarts.newValue === true;
    if (changes.stopAtEnd) stopAtEnd = changes.stopAtEnd.newValue !== false;
    if (changes.perSiteSpeed) perSiteSpeed = changes.perSiteSpeed.newValue !== false;
    if (changes.showHud) {
      showHud = changes.showHud.newValue !== false;
      updateHud();
    }
  };

  const clampSpeed = (s) => Math.round(Math.min(MAX_SPEED, Math.max(MIN_SPEED, s)) * 10) / 10;
  // Finer steps for "finish in N min" (0.1 steps are up to 50% off at slow speeds)
  const clampFine = (s) => Math.round(Math.min(MAX_SPEED, Math.max(MIN_SPEED, s)) * 100) / 100;
  // "1.5", or "0.17" when the speed is finer than 0.1
  const formatSpeed = (s) => (Math.round((s || 0) * 100) % 10 === 0 ? (s || 0).toFixed(1) : s.toFixed(2));

  // Keeps a {host: value} map under MAX_SITES entries, dropping the least recently set
  const putSite = (map, key, value) => {
    const out = map && typeof map === "object" ? { ...map } : {};
    delete out[key]; // re-insert so it moves to the end (most recent)
    if (value !== undefined) out[key] = value;
    const keys = Object.keys(out);
    for (let i = 0; i < keys.length - MAX_SITES; i++) delete out[keys[i]];
    return out;
  };

  // Saves the speed as the global default and, if enabled, for this site.
  // Debounced: dragging the popup slider fires dozens of updates per second.
  let rememberTimer = null;
  const rememberSpeed = (speed) => {
    if (!(speed > 0)) return;
    clearTimeout(rememberTimer);
    rememberTimer = setTimeout(() => {
      if (!alive()) return;
      chrome.storage.local.get(["siteSpeeds"], (r) => {
        if (chrome.runtime.lastError) return;
        const data = { savedSpeed: speed };
        if (perSiteSpeed && host) data.siteSpeeds = putSite(r?.siteSpeeds, host, speed);
        chrome.storage.local.set(data);
      });
    }, 300);
  };

  // Speed for this page: the per-site speed if there is one, else the last used speed
  const loadSpeed = (callback) => {
    if (!alive()) return;
    chrome.storage.local.get(["savedSpeed", "siteSpeeds", "perSiteSpeed"], (r) => {
      const site = r?.perSiteSpeed !== false ? parseFloat(r?.siteSpeeds?.[host]) : NaN;
      const saved = parseFloat(r?.savedSpeed);
      callback(clampSpeed(site > 0 ? site : saved > 0 ? saved : 1.0));
    });
  };

  const getRootScroller = () => document.scrollingElement || document.documentElement;

  const canScroll = (el) => el && el.scrollHeight - el.clientHeight > 20;

  // The window scrolls unless the page locked it with overflow:hidden (web apps, open modals)
  const rootScrolls = () => {
    if (!canScroll(getRootScroller())) return false;
    const hidden = (el) => el && /hidden|clip/.test(getComputedStyle(el).overflowY);
    return !hidden(document.documentElement) && !(document.body && hidden(document.body));
  };

  // Pages like web apps and chat UIs keep the window fixed and scroll an inner
  // container instead. Pick the window if it scrolls, otherwise the largest
  // visible scrollable element.
  const findScrollTarget = () => {
    if (rootScrolls()) return null;

    let best = null;
    let bestArea = 0;
    const all = document.body ? document.body.querySelectorAll("*") : [];
    for (const el of all) {
      if (!canScroll(el)) continue;
      const oy = getComputedStyle(el).overflowY;
      if (oy !== "auto" && oy !== "scroll" && oy !== "overlay") continue;
      const rect = el.getBoundingClientRect();
      const area = Math.max(0, rect.width) * Math.max(0, rect.height);
      if (area > bestArea) {
        best = el;
        bestArea = area;
      }
    }
    return best;
  };

  const getPos = () => (scrollTarget ? scrollTarget.scrollTop : window.scrollY);

  // Pixels left to scroll and the total scrollable distance
  const getRemaining = () => {
    if (scrollTarget) {
      const max = scrollTarget.scrollHeight - scrollTarget.clientHeight;
      return { left: Math.max(0, max - scrollTarget.scrollTop), max };
    }
    const max = getRootScroller().scrollHeight - window.innerHeight;
    return { left: Math.max(0, max - window.scrollY), max };
  };

  const isAtEnd = () => getRemaining().left <= 2;

  // ---------- Speed HUD (closed shadow DOM so page styles can't leak in) ----------
  let hudHost = null;
  let hud = null;
  let hudDismissed = false; // closed with x: stays hidden until the next start
  let hudTimer = null;
  let hudActive = false; // true once scrolling has started on this page (until stopped)

  const formatDuration = (secs) => {
    if (secs < 60) return `${secs}s`;
    const mins = Math.round(secs / 60);
    if (mins < 60) return `${mins} min`;
    return `${Math.floor(mins / 60)} h ${mins % 60} min`;
  };

  const formatTimeLeft = (speed = scrollSpeed) => {
    const { left } = getRemaining();
    if (left <= 2) return "End of page";
    if (!(speed > 0)) return "";
    return `${formatDuration(Math.round(left / (speed * PX_PER_SEC)))} left`;
  };

  const ICON_PLAY = '<svg width="12" height="12" viewBox="0 0 12 12" aria-hidden="true"><path d="M3 1.5v9l7.5-4.5z" fill="currentColor"/></svg>';
  const ICON_PAUSE =
    '<svg width="12" height="12" viewBox="0 0 12 12" aria-hidden="true"><rect x="2" y="1.5" width="3" height="9" rx="1" fill="currentColor"/><rect x="7" y="1.5" width="3" height="9" rx="1" fill="currentColor"/></svg>';

  const buildHud = () => {
    hudHost = document.createElement("div");
    hudHost.id = "pro-auto-scroller-hud";
    hudHost.style.cssText = "all:initial;position:fixed;right:20px;bottom:20px;z-index:2147483647;";
    const root = hudHost.attachShadow({ mode: "closed" });
    // Static markup only; dynamic values are set with textContent below
    root.innerHTML = `
      <style>
        .hud{display:flex;align-items:center;gap:6px;padding:6px 8px 6px 6px;border-radius:999px;
          background:rgba(15,23,42,.92);color:#f8fafc;font:600 12px/1 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;
          box-shadow:0 10px 30px -8px rgba(0,0,0,.45),0 0 0 1px rgba(255,255,255,.08);position:relative;overflow:hidden;
          backdrop-filter:blur(6px);user-select:none}
        button{all:unset;cursor:pointer;width:26px;height:26px;border-radius:50%;display:grid;place-items:center;
          color:#e2e8f0;font-size:14px;line-height:1}
        button:hover{background:rgba(255,255,255,.12)}
        button:focus-visible{outline:2px solid #a5b4fc}
        .play{background:#6366f1;color:#fff}
        .play:hover{background:#4f46e5}
        .speed{min-width:42px;text-align:center;font-size:13px;font-variant-numeric:tabular-nums}
        .speed small{color:#a5b4fc;font-size:11px}
        .left{color:#cbd5e1;font-weight:500;padding:0 4px 0 6px;border-left:1px solid rgba(255,255,255,.15);white-space:nowrap}
        .left:empty{display:none}
        .close{width:20px;height:20px;font-size:12px;color:#cbd5e1}
        .bar{position:absolute;left:0;bottom:0;height:2px;background:#818cf8;width:0}
        @media (max-width:420px){.left{display:none}}
      </style>
      <div class="hud" role="toolbar" aria-label="Auto scroll controls">
        <button class="play" data-a="toggle" title="Play / pause (Space)"></button>
        <button data-a="slower" title="Slower (-)" aria-label="Slower">&minus;</button>
        <span class="speed" aria-label="Speed"><span class="num"></span><small>x</small></span>
        <button data-a="faster" title="Faster (+)" aria-label="Faster">+</button>
        <span class="left"></span>
        <button class="close" data-a="close" title="Stop and hide (Esc)" aria-label="Stop and hide">&#x2715;</button>
        <div class="bar"></div>
      </div>`;
    hud = {
      play: root.querySelector(".play"),
      speedNum: root.querySelector(".speed .num"),
      left: root.querySelector(".left"),
      bar: root.querySelector(".bar"),
      shownPlaying: null,
    };
    root.querySelector(".hud").addEventListener("click", (e) => {
      if (!alive()) return;
      const a = e.target.closest("button")?.dataset.a;
      if (a === "toggle") toggleScroll();
      else if (a === "faster") changeSpeed(1);
      else if (a === "slower") changeSpeed(-1);
      else if (a === "close") {
        hudDismissed = true;
        fullStop();
      }
    });
    (document.body || document.documentElement).appendChild(hudHost);
  };

  const refreshHudText = () => {
    if (!hud || !alive()) return;
    if (hud.shownPlaying !== isScrolling) {
      hud.shownPlaying = isScrolling;
      hud.play.innerHTML = isScrolling ? ICON_PAUSE : ICON_PLAY; // static SVG strings
      hud.play.setAttribute("aria-label", isScrolling ? "Pause" : "Play");
    }
    hud.speedNum.textContent = formatSpeed(scrollSpeed);
    hud.left.textContent = formatTimeLeft();
    const { left, max } = getRemaining();
    hud.bar.style.width = max > 0 ? `${Math.min(100, ((max - left) / max) * 100)}%` : "0";
  };

  // HUD is visible while scrolling and while paused (speed kept); hidden when stopped
  const updateHud = () => {
    const visible = showHud && !hudDismissed && hudActive && scrollSpeed > 0 && !destroyed;
    if (!visible) {
      if (hudHost) hudHost.style.display = "none";
      clearInterval(hudTimer);
      hudTimer = null;
      return;
    }
    if (!hudHost || !hudHost.isConnected) buildHud();
    hudHost.style.display = "block";
    refreshHudText();
    if (!hudTimer) hudTimer = setInterval(refreshHudText, 500);
  };

  const reportState = () => {
    if (!alive()) return;
    try {
      chrome.runtime.sendMessage({ action: "state", scrolling: isScrolling, paused: !isScrolling && hudActive && scrollSpeed > 0 }, () => void chrome.runtime.lastError);
    } catch (_) {
      /* extension context invalidated */
    }
    updateHud();
  };

  const stopScroll = () => {
    isScrolling = false;
    cancelAnimationFrame(animationId);
    animationId = null;
    if (scrollSpeed <= 0) hudActive = false;
    reportState();
  };

  // Stop completely (speed 0, HUD hidden)
  const fullStop = () => {
    scrollSpeed = 0;
    stopScroll();
  };

  // Scroll without the page's CSS `scroll-behavior: smooth`, which would turn
  // every 1px step into a separate animation and stall the scroller.
  const scrollStep = (px) => {
    if (scrollTarget) scrollTarget.scrollBy({ top: px, behavior: "instant" });
    else window.scrollBy({ top: px, behavior: "instant" });
  };

  const performScroll = (now = performance.now()) => {
    cancelAnimationFrame(animationId);
    animationId = null;
    if (!alive()) return;
    if (!isScrolling || scrollSpeed <= 0) {
      if (isScrolling) stopScroll();
      return;
    }
    // A single-page app replaced the panel we were scrolling: pick a new one
    if (scrollTarget && !scrollTarget.isConnected) scrollTarget = findScrollTarget();
    // Time-based so a 120 Hz screen doesn't scroll twice as fast; cap after tab switches
    const dt = Math.min(100, now - (lastFrameAt || now));
    lastFrameAt = now;
    pendingScroll += scrollSpeed * (dt / (1000 / PX_PER_SEC));
    const step = Math.floor(pendingScroll);
    if (step >= 1) {
      const before = getPos();
      scrollStep(step);
      pendingScroll -= step;

      if (getPos() !== before) lastMovedAt = performance.now();

      // Auto-stop at the end of the page. Wait ~2s first so infinite-scroll
      // feeds get a chance to load more content.
      if (stopAtEnd && isAtEnd() && performance.now() - lastMovedAt > 2000) {
        stopScroll();
        return;
      }
    }
    animationId = requestAnimationFrame(performScroll);
  };

  const startScroll = () => {
    if (!alive()) return;
    scrollTarget = findScrollTarget();
    lastMovedAt = performance.now();
    lastFrameAt = 0;
    pendingScroll = 0;
    isScrolling = true;
    hudActive = true;
    hudDismissed = false;
    reportState();
    performScroll();
  };

  const toggleScroll = () => {
    if (isScrolling) {
      stopScroll();
      return;
    }
    if (scrollSpeed > 0) {
      startScroll();
      return;
    }
    // Use the speed saved for this site (or the last used speed), falling back to 1.0
    loadSpeed((speed) => {
      scrollSpeed = speed;
      startScroll();
    });
  };

  // Faster / slower in ~15% steps (at least 0.1)
  const changeSpeed = (dir) => {
    // When stopped, step from this site's remembered speed instead of 1.0
    if (!(scrollSpeed > 0)) {
      loadSpeed((speed) => {
        scrollSpeed = speed;
        changeSpeed(dir);
      });
      return;
    }
    const base = scrollSpeed;
    const step = Math.max(0.1, Math.round(base * 0.15 * 10) / 10);
    scrollSpeed = clampSpeed(base + dir * step);
    rememberSpeed(scrollSpeed);
    if (!isScrolling) startScroll();
    else updateHud();
  };

  // Picks the speed that reaches the end of the page in `minutes` and starts.
  // Returns what was set so the popup can say if the speed hit a limit.
  const fitToTime = (minutes) => {
    const mins = parseFloat(minutes);
    if (!(mins > 0)) return { ok: false };
    if (!isScrolling) scrollTarget = findScrollTarget();
    const { left } = getRemaining();
    if (left <= 2) return { ok: false, reason: "end" };
    const wanted = left / (mins * 60 * PX_PER_SEC);
    scrollSpeed = clampFine(wanted);
    if (!isScrolling) startScroll();
    else updateHud();
    return { ok: true, speed: scrollSpeed, limited: scrollSpeed !== Math.round(wanted * 100) / 100 };
  };

  const isTyping = (el) => {
    const tag = (el?.tagName || "").toLowerCase();
    if (tag === "input" || tag === "textarea" || tag === "select" || el?.isContentEditable) return true;
    const role = el?.getAttribute?.("role");
    return role === "textbox" || role === "searchbox" || role === "combobox";
  };

  // Elements where Space already means something (press a button, play a video...)
  const SPACE_OWNERS = "button,summary,video,audio,[role=button],[role=checkbox],[role=switch],[role=radio],[role=tab],[role=menuitem],[role=option],[role=slider],[role=link]";
  const spaceBelongsToPage = (el) => !!el?.closest?.(SPACE_OWNERS);

  // --- KEYBOARD ---
  // Listens on window in the bubble phase, so the page sees every key first:
  // if a video player, game or app already handled Space (preventDefault),
  // the scroller leaves it alone.
  const onKeyDown = (e) => {
    if (e.defaultPrevented || e.ctrlKey || e.altKey || e.metaKey) return;
    const origin = e.composedPath?.()[0] || e.target;
    if (isTyping(e.target) || isTyping(origin)) return;
    const active = hudActive && scrollSpeed > 0; // started on this page (scrolling or paused)

    if (e.code === "Space" && !e.shiftKey && spacebarEnabled) {
      // When the scroller isn't active, Space keeps its normal page-down job
      // unless the user opted in to "Space also starts scrolling".
      if (!active && !spaceStarts) return;
      if (spaceBelongsToPage(e.target) || spaceBelongsToPage(origin)) return;
      if (!alive()) return;
      e.preventDefault(); // Stop the page from jumping down
      if (!e.repeat) toggleScroll(); // holding Space must not flicker play/pause
      return;
    }

    // Speed keys only act while the scroller is active, so they never hijack normal pages
    if (!active || !alive()) return;
    if (e.key === "+" || e.key === "=" || e.key === "]") {
      e.preventDefault();
      changeSpeed(1);
    } else if (e.key === "-" || e.key === "_" || e.key === "[") {
      e.preventDefault();
      changeSpeed(-1);
    } else if (e.key === "Escape") {
      fullStop();
    }
  };

  const onMessage = (message, sender, sendResponse) => {
    if (!alive() || !message || typeof message.action !== "string") return;
    const state = () => ({
      status: "ok",
      scrolling: isScrolling,
      speed: scrollSpeed,
      host,
      timeLeft: scrollSpeed > 0 ? formatTimeLeft() : "",
    });

    switch (message.action) {
      case "setSpeed": {
        const speed = parseFloat(message.speed);
        scrollSpeed = speed > 0 ? clampFine(speed) : 0;
        if (scrollSpeed > 0) rememberSpeed(scrollSpeed);
        if (scrollSpeed > 0 && !isScrolling) startScroll();
        else if (scrollSpeed <= 0) fullStop();
        else updateHud();
        break;
      }
      case "toggle":
        toggleScroll();
        break;
      case "faster":
        changeSpeed(1);
        break;
      case "slower":
        changeSpeed(-1);
        break;
      case "stop":
        fullStop();
        break;
      case "fitTime": {
        const fit = fitToTime(message.minutes);
        sendResponse({ ...state(), fit });
        return;
      }
      case "getSiteSpeed":
        loadSpeed((speed) => {
          sendResponse({
            ...state(),
            siteSpeed: speed,
            timeLeft: formatTimeLeft(scrollSpeed > 0 ? scrollSpeed : speed),
          });
        });
        return true;
      default:
        break; // "getState" just reports the current state
    }
    sendResponse(state());
  };

  // Back/forward cache: the page comes back with our state intact, so re-sync the badge
  const onPageShow = (e) => {
    if (e.persisted) reportState();
  };

  // ---------- Auto-start on chosen sites ----------
  let autoStartTimer = null;
  const maybeAutoStart = () => {
    if (!alive() || isScrolling || hudActive) return;
    if (document.visibilityState !== "visible") {
      document.addEventListener("visibilitychange", maybeAutoStart, { once: true });
      return;
    }
    toggleScroll();
  };

  chrome.storage.local.get(["spacebarEnabled", "spaceStarts", "stopAtEnd", "showHud", "perSiteSpeed", "autoStartSites"], (r) => {
    if (destroyed) return;
    if (r?.spacebarEnabled === false) spacebarEnabled = false;
    if (r?.spaceStarts === true) spaceStarts = true;
    if (r?.stopAtEnd === false) stopAtEnd = false;
    if (r?.showHud === false) showHud = false;
    if (r?.perSiteSpeed === false) perSiteSpeed = false;
    // Only on a fresh load of a site the user opted in (not when injected later by the popup)
    if (host && r?.autoStartSites?.[host] && performance.now() < 30000) {
      autoStartTimer = setTimeout(maybeAutoStart, AUTO_START_DELAY);
    }
  });

  chrome.storage.onChanged.addListener(onStorageChanged);
  chrome.runtime.onMessage.addListener(onMessage);
  window.addEventListener("keydown", onKeyDown);
  window.addEventListener("pageshow", onPageShow);

  function destroy() {
    if (destroyed) return;
    destroyed = true;
    isScrolling = false;
    cancelAnimationFrame(animationId);
    clearInterval(hudTimer);
    clearTimeout(rememberTimer);
    clearTimeout(autoStartTimer);
    window.removeEventListener("keydown", onKeyDown);
    window.removeEventListener("pageshow", onPageShow);
    document.removeEventListener("visibilitychange", maybeAutoStart);
    try {
      chrome.storage.onChanged.removeListener(onStorageChanged);
      chrome.runtime.onMessage.removeListener(onMessage);
    } catch (_) {
      /* context invalidated */
    }
    hudHost?.remove();
    if (window.__proAutoScroller?.destroy === destroy) delete window.__proAutoScroller;
  }

  window.__proAutoScroller = { destroy };
})();
