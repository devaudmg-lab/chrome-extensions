# Pro Auto Scroller

Smooth, hands-free auto scrolling for long articles, documentation, recipes, lyrics or chord sheets, and feeds.

## Features
- **Smooth scrolling**: frame-synced and adjustable from a slow crawl (0.1) to fast skimming (10).
- **Spacebar play/pause**: press Space on any page to start or pause. It's ignored while you type in a text field, and you can turn it off in the popup.
- **Global shortcut**: `Alt+Shift+S` toggles scrolling. You can change it at `chrome://extensions/shortcuts`.
- **Works in web apps**: if the page itself doesn't scroll, it scrolls the main inner scroll area instead (chat apps, docs viewers).
- **Stops at the end**: it stops on its own when the bottom is reached. It waits about 2 seconds first, so infinite feeds can load more. You can turn this off.
- **Status at a glance**: the toolbar icon shows an **ON** badge while scrolling, and the popup shows Start/Pause.

## Install (Load unpacked)
1. Download and unzip the ZIP.
2. Open `chrome://extensions` and turn on **Developer mode** (top right).
3. Click **Load unpacked** and select the unzipped folder (the one that contains `manifest.json`).
4. Reload any tabs that were already open. Or just open the popup on a tab, which also activates it.

## How to use
- Open the popup and move the **Scroll Speed** slider to start. Set it to 0, or press **Stop Scroll**, to stop.
- Or press **Space** on the page, or **Alt+Shift+S**, to start or pause at your last speed.

Chrome does not allow extensions on `chrome://` pages or the Chrome Web Store.

## Permissions
| Permission | Why |
|---|---|
| Content script on `http(s)` sites | Needed so Space and the shortcut work on any page you read. It only scrolls the page; it reads no data. |
| `activeTab` + `scripting` | Activate the scroller on a tab that was open before the extension was installed. |
| `storage` | Remember your speed and settings. |

Nothing is collected or sent anywhere.
