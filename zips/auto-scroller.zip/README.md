# Pro Auto Scroller

Smooth, hands-free auto scrolling for long articles, documentation, recipes, lyrics or chord sheets, and feeds.

## Features
- **Smooth scrolling**: adjustable from a slow crawl (0.1) to fast skimming (10). Speed is time-based, so it feels the same on 60 Hz and 120 Hz screens.
- **On-page speed bar**: a small floating bar shows play/pause, the speed, `-`/`+` buttons, a progress line and an estimate of the **time left** to the end of the page. Close it with x or turn it off in the popup.
- **Speed hotkeys**: while scrolling, press `+` / `-` (or `]` / `[`) to change speed and `Esc` to stop. These keys do nothing on pages where the scroller isn't running.
- **Speed per site**: each site remembers its own speed (slow for recipes, faster for feeds). You can turn this off.
- **Spacebar play/pause**: press Space on any page to start or pause. It's ignored while you type in a text field, and you can turn it off in the popup.
- **Global shortcuts**: `Alt+Shift+S` toggles scrolling, `Alt+Shift+Up` / `Alt+Shift+Down` change speed. You can change them at `chrome://extensions/shortcuts`.
- **Works in web apps**: if the page itself doesn't scroll, it scrolls the main inner scroll area instead (chat apps, docs viewers).
- **Stops at the end**: it stops on its own when the bottom is reached. It waits about 2 seconds first, so infinite feeds can load more. You can turn this off.
- **Status at a glance**: the toolbar icon shows an **ON** badge while scrolling, and the popup shows Scrolling / Paused / Stopped and the time left.
- **First-run hint and dark mode**: the popup explains the keys on first use and follows your system's light or dark theme.

## Install (Load unpacked)
1. Download and unzip the ZIP.
2. Open `chrome://extensions` and turn on **Developer mode** (top right).
3. Click **Load unpacked** and select the unzipped folder (the one that contains `manifest.json`).
4. Reload any tabs that were already open. Or just open the popup on a tab, which also activates it.

## How to use
- Open the popup and move the **Scroll Speed** slider to start. Set it to 0, or press **Stop Scroll**, to stop.
- Or press **Space** on the page, or **Alt+Shift+S**, to start or pause at this site's speed.
- While it scrolls, use the floating bar or press `+` / `-` to adjust, and `Esc` to stop.

## Keyboard shortcuts
| Keys | Action |
|---|---|
| `Space` (on the page) | Start / pause |
| `+` or `]` / `-` or `[` (while active) | Faster / slower |
| `Esc` (while active) | Stop and hide the speed bar |
| `Alt+Shift+S` | Toggle scrolling (works from anywhere in Chrome) |
| `Alt+Shift+Up` / `Alt+Shift+Down` | Faster / slower |

Chrome does not allow extensions on `chrome://` pages or the Chrome Web Store.

## Permissions
| Permission | Why |
|---|---|
| Content script on `http(s)` sites | Needed so Space and the shortcut work on any page you read. It only scrolls the page; it reads no data. |
| `activeTab` + `scripting` | Activate the scroller on a tab that was open before the extension was installed. |
| `storage` | Remember your settings and the speed you chose for each site (stored only on your computer). |

Nothing is collected or sent anywhere.
