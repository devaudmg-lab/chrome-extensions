# Pro Auto Scroller

Smooth, hands-free auto scrolling for long articles, documentation, recipes, lyrics or chord sheets, and feeds.

## Features
- **Smooth scrolling**: adjustable from a slow crawl (0.1) to fast skimming (10). Speed is time-based, so it feels the same on 60 Hz and 120 Hz screens.
- **On-page speed bar**: a small floating bar shows play/pause, the speed, `-`/`+` buttons, a progress line and an estimate of the **time left** to the end of the page. Close it with x or turn it off in the popup.
- **Speed hotkeys**: while scrolling, press `+` / `-` (or `]` / `[`) to change speed and `Esc` to stop. These keys do nothing on pages where the scroller isn't running.
- **Speed per site**: each site remembers its own speed (slow for recipes, faster for feeds). You can turn this off.
- **Spacebar pause/resume that doesn't fight the page**: once the scroller runs on a page (scrolling or paused), Space pauses and resumes it. Before that, Space keeps its normal job (page down, play a video, jump in a game). It is also left alone when the page itself handles Space, when a button, link-like control or video has focus, and while you type. Holding Space doesn't flicker. Want Space to *start* scrolling anywhere? Turn on **Space also starts scrolling on any page** in the popup.
- **Finish in N minutes**: type how long you want to spend on the page and it picks the exact speed that reaches the end in that time (handy for reading plans, teleprompters, presentations). It tells you if the 10x limit gets in the way.
- **Auto-start on chosen sites**: tick **Auto-start on <site>** in the popup and pages of that site start scrolling by themselves at the site's speed, 1.5 s after they load (only while the tab is visible). Great for lyrics, chord and recipe sites.
- **Global shortcuts**: `Alt+Shift+S` toggles scrolling, `Alt+Shift+Up` / `Alt+Shift+Down` change speed. You can change them at `chrome://extensions/shortcuts`.
- **Works in web apps**: if the page itself doesn't scroll (or locks it with `overflow: hidden`), it scrolls the main inner scroll area instead (chat apps, docs viewers), and finds the new one if a single-page app swaps it out.
- **Works on smooth-scroll sites**: pages with CSS `scroll-behavior: smooth` scroll at the right speed too.
- **Stops at the end**: it stops on its own when the bottom is reached. It waits about 2 seconds first, so infinite feeds can load more. You can turn this off.
- **Status at a glance**: the toolbar icon shows **ON** while scrolling and **II** while paused, and the popup shows Scrolling / Paused / Stopped and the time left.
- **First-run hint and dark mode**: the popup explains the keys on first use and follows your system's light or dark theme.

## Install (Load unpacked)
1. Download and unzip the ZIP.
2. Open `chrome://extensions` and turn on **Developer mode** (top right).
3. Click **Load unpacked** and select the unzipped folder (the one that contains `manifest.json`).
4. Reload any tabs that were already open. Or just open the popup on a tab, which also activates it.

## How to use
- Open the popup and move the **Scroll Speed** slider to start. Set it to 0, or press **Stop Scroll**, to stop.
- Or press **Alt+Shift+S** to start at this site's speed.
- Or type minutes into **Finish page in** and press **Go**.
- While it runs, press **Space** to pause and resume, use the floating bar or `+` / `-` to adjust, and `Esc` to stop.

## Keyboard shortcuts
| Keys | Action |
|---|---|
| `Space` (while active on the page) | Pause / resume (and start, if you turned that on) |
| `+` or `]` / `-` or `[` (while active) | Faster / slower |
| `Esc` (while active) | Stop and hide the speed bar |
| `Alt+Shift+S` | Start / pause (works from anywhere in Chrome) |
| `Alt+Shift+Up` / `Alt+Shift+Down` | Faster / slower |

Chrome does not allow extensions on `chrome://` pages, the Chrome Web Store or the built-in PDF viewer. `file://` pages work only if you allow file access for the extension.

## Why Space doesn't start scrolling by default
Space already means something on most pages: page down, play/pause in video players, jump in games, press the focused button. An extension that grabs Space on every site breaks all of that. So by default Space only controls the scroller once you started it on that page (with the popup, the floating bar or `Alt+Shift+S`); the speed bar on the page makes that state visible. If you want the old behaviour, turn on **Space also starts scrolling on any page**. Even then, Space is left to the page when the page already handles it, when a control or video has focus, or while you type.

## Permissions
| Permission | Why |
|---|---|
| Content script on `http(s)` sites | Needed so Space and the shortcut work on any page you read. It only scrolls the page; it reads no data. |
| `activeTab` + `scripting` | Activate the scroller on a tab that was open before the extension was installed. |
| `storage` | Remember your settings, the speed you chose for each site and the sites you set to auto-start (stored only on your computer, capped at 500 sites each). |

No new permissions were added in 1.5.0.

Nothing is collected or sent anywhere.
