document.addEventListener("DOMContentLoaded", () => {
  const $ = (id) => document.getElementById(id);
  const slider = $("speedSlider");
  const speedVal = $("speedVal");
  const stopBtn = $("stopBtn");
  const toggleBtn = $("toggleBtn");
  const statusEl = $("status");
  const errorEl = $("error");
  const spacebarChk = $("spacebarChk");
  const spaceStartsChk = $("spaceStartsChk");
  const stopEndChk = $("stopEndChk");
  const hudChk = $("hudChk");
  const siteChk = $("siteChk");
  const autoChk = $("autoChk");
  const autoLabel = $("autoLabel");
  const siteName = $("siteName");
  const timeLeft = $("timeLeft");
  const onboard = $("onboard");
  const fitForm = $("fitForm");
  const fitMin = $("fitMin");
  const fitMsg = $("fitMsg");

  const MAX_SITES = 500;
  let currentHost = "";
  let blocked = false;

  // "1.5", or "0.17" when "Finish in N min" picked a speed finer than 0.1
  const formatSpeed = (speed) => {
    const s = parseFloat(speed) || 0;
    return Math.round(s * 100) % 10 === 0 ? s.toFixed(1) : s.toFixed(2);
  };

  const showSpeed = (speed) => {
    slider.value = speed;
    speedVal.textContent = formatSpeed(speed);
    slider.setAttribute("aria-valuetext", `${formatSpeed(speed)} times`);
  };

  chrome.storage.local.get(
    ["savedSpeed", "spacebarEnabled", "spaceStarts", "stopAtEnd", "showHud", "perSiteSpeed", "onboarded"],
    (result) => {
      if (result.savedSpeed !== undefined) showSpeed(result.savedSpeed);
      spacebarChk.checked = result.spacebarEnabled !== false;
      spaceStartsChk.checked = result.spaceStarts === true;
      spaceStartsChk.disabled = !spacebarChk.checked;
      stopEndChk.checked = result.stopAtEnd !== false;
      hudChk.checked = result.showHud !== false;
      siteChk.checked = result.perSiteSpeed !== false;
      if (!result.onboarded) onboard.style.display = "block";
    }
  );

  // First-run hint: hide for good once dismissed or once scrolling was started
  const finishOnboarding = () => {
    if (onboard.style.display === "none") return;
    onboard.style.display = "none";
    chrome.storage.local.set({ onboarded: true });
  };
  $("onboardClose").onclick = finishOnboarding;

  spacebarChk.addEventListener("change", () => {
    spaceStartsChk.disabled = !spacebarChk.checked;
    chrome.storage.local.set({ spacebarEnabled: spacebarChk.checked });
  });
  spaceStartsChk.addEventListener("change", () => chrome.storage.local.set({ spaceStarts: spaceStartsChk.checked }));
  stopEndChk.addEventListener("change", () => chrome.storage.local.set({ stopAtEnd: stopEndChk.checked }));
  hudChk.addEventListener("change", () => chrome.storage.local.set({ showHud: hudChk.checked }));
  siteChk.addEventListener("change", () => chrome.storage.local.set({ perSiteSpeed: siteChk.checked }));

  // Auto-start is stored per site: {hostname: true}, capped like the speed map
  autoChk.addEventListener("change", () => {
    if (!currentHost) return;
    chrome.storage.local.get(["autoStartSites"], (r) => {
      const sites = { ...(r.autoStartSites || {}) };
      delete sites[currentHost];
      if (autoChk.checked) sites[currentHost] = true;
      const keys = Object.keys(sites);
      for (let i = 0; i < keys.length - MAX_SITES; i++) delete sites[keys[i]];
      chrome.storage.local.set({ autoStartSites: sites });
    });
  });

  const setHost = (host) => {
    if (host === currentHost) return;
    currentHost = host || "";
    autoLabel.textContent = currentHost ? `Auto-start on ${currentHost}` : "Auto-start on this site";
    autoChk.disabled = !currentHost;
    chrome.storage.local.get(["autoStartSites"], (r) => {
      autoChk.checked = !!(currentHost && r.autoStartSites?.[currentHost]);
    });
  };

  const showState = (response) => {
    if (!response) {
      blocked = true;
      errorEl.style.display = "block";
      for (const el of [toggleBtn, stopBtn, slider, autoChk, fitMin, $("fitBtn")]) el.disabled = true;
      statusEl.textContent = "Unavailable";
      statusEl.classList.remove("on");
      siteName.textContent = "";
      timeLeft.textContent = "";
      return;
    }
    blocked = false;
    errorEl.style.display = "none";
    for (const el of [toggleBtn, stopBtn, slider, fitMin, $("fitBtn")]) el.disabled = false;
    const on = !!response.scrolling;
    statusEl.textContent = on ? "Scrolling" : response.speed > 0 ? "Paused" : "Stopped";
    statusEl.classList.toggle("on", on);
    toggleBtn.textContent = on ? "Pause" : response.speed > 0 ? "Resume" : "Start";
    if (response.host !== undefined) {
      setHost(response.host);
      siteName.textContent = response.host ? (siteChk.checked ? `Speed for ${response.host}` : response.host) : "";
      siteName.title = response.host || "";
    }
    if (response.timeLeft !== undefined) timeLeft.textContent = response.timeLeft;
    if (on) finishOnboarding();
  };

  // Sends a message to the active tab, injecting the content script if it is missing
  const sendToActiveTab = (message, callback = () => {}) => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tabId = tabs[0]?.id;
      if (!tabId) return callback(null);
      chrome.tabs.sendMessage(tabId, message, (response) => {
        if (!chrome.runtime.lastError) return callback(response);
        // Content script missing (tab opened before install/reload): inject it, then retry
        chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] }, () => {
          if (chrome.runtime.lastError) return callback(null); // restricted page (chrome://, Web Store, PDF)
          chrome.tabs.sendMessage(tabId, message, (retry) => {
            callback(chrome.runtime.lastError ? null : retry);
          });
        });
      });
    });
  };

  const refresh = () => sendToActiveTab({ action: "getState" }, showState);

  const updatePageScroll = (value) => {
    const speed = parseFloat(value);
    fitMsg.textContent = "";
    showSpeed(speed);
    sendToActiveTab({ action: "setSpeed", speed }, showState);
  };

  // Show current state when the popup opens. The slider shows this site's
  // remembered speed (or the current speed if it is already scrolling).
  sendToActiveTab({ action: "getSiteSpeed" }, (response) => {
    showState(response);
    if (!response) return;
    const speed = response.speed > 0 ? response.speed : response.siteSpeed;
    if (speed > 0) showSpeed(speed);
  });

  // Keep the time-left estimate fresh while the popup is open (not on blocked pages)
  setInterval(() => {
    if (!blocked) refresh();
  }, 1000);

  slider.addEventListener("input", (e) => updatePageScroll(e.target.value));

  toggleBtn.onclick = () => {
    sendToActiveTab({ action: "toggle" }, () => {
      // toggle may resolve asynchronously (reads the saved speed), so re-query
      setTimeout(
        () =>
          sendToActiveTab({ action: "getState" }, (response) => {
            showState(response);
            if (response?.speed > 0) showSpeed(response.speed);
          }),
        100
      );
    });
  };

  stopBtn.onclick = () => {
    showSpeed(0);
    fitMsg.textContent = "";
    sendToActiveTab({ action: "stop" }, showState);
  };

  // "Finish in N min": pick the speed that reaches the end of the page in time
  fitForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const minutes = parseFloat(fitMin.value);
    if (!(minutes > 0)) {
      fitMsg.textContent = "Enter the minutes, e.g. 5.";
      return;
    }
    sendToActiveTab({ action: "fitTime", minutes }, (response) => {
      showState(response);
      const fit = response?.fit;
      if (!fit) return;
      if (!fit.ok) {
        fitMsg.textContent = fit.reason === "end" ? "Already at the end of the page." : "Enter the minutes, e.g. 5.";
        return;
      }
      showSpeed(fit.speed);
      fitMsg.textContent = fit.limited
        ? `Speed limit reached: ${formatSpeed(fit.speed)}x (${response.timeLeft || "end of page"}).`
        : `Set to ${formatSpeed(fit.speed)}x (${response.timeLeft || "end of page"}).`;
    });
  });
});
