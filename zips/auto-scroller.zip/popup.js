document.addEventListener("DOMContentLoaded", () => {
  const slider = document.getElementById("speedSlider");
  const speedVal = document.getElementById("speedVal");
  const stopBtn = document.getElementById("stopBtn");
  const toggleBtn = document.getElementById("toggleBtn");
  const statusEl = document.getElementById("status");
  const errorEl = document.getElementById("error");
  const spacebarChk = document.getElementById("spacebarChk");
  const stopEndChk = document.getElementById("stopEndChk");
  const hudChk = document.getElementById("hudChk");
  const siteChk = document.getElementById("siteChk");
  const siteName = document.getElementById("siteName");
  const timeLeft = document.getElementById("timeLeft");
  const onboard = document.getElementById("onboard");

  const showSpeed = (speed) => {
    slider.value = speed;
    speedVal.innerText = parseFloat(speed).toFixed(1);
  };

  chrome.storage.local.get(
    ["savedSpeed", "spacebarEnabled", "stopAtEnd", "showHud", "perSiteSpeed", "onboarded"],
    (result) => {
      if (result.savedSpeed !== undefined) showSpeed(result.savedSpeed);
      spacebarChk.checked = result.spacebarEnabled !== false;
      stopEndChk.checked = result.stopAtEnd !== false;
      hudChk.checked = result.showHud !== false;
      siteChk.checked = result.perSiteSpeed !== false;
      if (!result.onboarded) onboard.style.display = "block";
    }
  );

  // First-run hint: hide for good once dismissed or once scrolling was started
  const finishOnboarding = () => {
    onboard.style.display = "none";
    chrome.storage.local.set({ onboarded: true });
  };
  document.getElementById("onboardClose").onclick = finishOnboarding;

  spacebarChk.addEventListener("change", () => chrome.storage.local.set({ spacebarEnabled: spacebarChk.checked }));
  stopEndChk.addEventListener("change", () => chrome.storage.local.set({ stopAtEnd: stopEndChk.checked }));
  hudChk.addEventListener("change", () => chrome.storage.local.set({ showHud: hudChk.checked }));
  siteChk.addEventListener("change", () => chrome.storage.local.set({ perSiteSpeed: siteChk.checked }));

  const showState = (response) => {
    if (!response) {
      errorEl.style.display = "block";
      toggleBtn.disabled = true;
      stopBtn.disabled = true;
      slider.disabled = true;
      siteName.textContent = "";
      timeLeft.textContent = "";
      return;
    }
    errorEl.style.display = "none";
    toggleBtn.disabled = false;
    stopBtn.disabled = false;
    slider.disabled = false;
    const on = !!response.scrolling;
    statusEl.textContent = on ? "Scrolling" : response.speed > 0 ? "Paused" : "Stopped";
    statusEl.classList.toggle("on", on);
    toggleBtn.textContent = on ? "Pause" : response.speed > 0 ? "Resume" : "Start";
    if (response.host !== undefined) {
      siteName.textContent = response.host ? (siteChk.checked ? `Speed for ${response.host}` : response.host) : "";
      siteName.title = response.host || "";
    }
    if (response.timeLeft !== undefined) timeLeft.textContent = response.timeLeft;
    if (on) finishOnboarding();
  };

  // Sends a message to the active tab, injecting the content script if it is missing
  const sendToActiveTab = (message, callback = () => {}) => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tabId = tabs[0]?.id;
      if (!tabId) return callback(null);
      chrome.tabs.sendMessage(tabId, message, (response) => {
        if (!chrome.runtime.lastError) return callback(response);
        // Content script missing (tab opened before install/reload): inject it, then retry
        chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] }, () => {
          if (chrome.runtime.lastError) return callback(null); // restricted page (chrome://, Web Store)
          chrome.tabs.sendMessage(tabId, message, (retry) => {
            callback(chrome.runtime.lastError ? null : retry);
          });
        });
      });
    });
  };

  const refresh = () => sendToActiveTab({ action: "getState" }, showState);

  const updatePageScroll = (value) => {
    const speed = parseFloat(value);
    speedVal.innerText = speed.toFixed(1);
    sendToActiveTab({ action: "setSpeed", speed: speed }, showState);
  };

  // Show current state when the popup opens. The slider shows this site's
  // remembered speed (or the current speed if it is already scrolling).
  sendToActiveTab({ action: "getSiteSpeed" }, (response) => {
    showState(response);
    if (!response) return;
    const speed = response.speed > 0 ? response.speed : response.siteSpeed;
    if (speed > 0) showSpeed(speed);
  });

  // Keep the time-left estimate fresh while the popup is open
  setInterval(refresh, 1000);

  slider.addEventListener("input", (e) => updatePageScroll(e.target.value));

  toggleBtn.onclick = () => {
    if (parseFloat(slider.value) <= 0) {
      slider.value = 1;
      speedVal.innerText = "1.0";
    }
    sendToActiveTab({ action: "toggle" }, () => {
      // toggle may resolve asynchronously (reads the saved speed), so re-query
      setTimeout(refresh, 100);
    });
  };

  stopBtn.onclick = () => {
    slider.value = 0;
    speedVal.innerText = "0.0";
    sendToActiveTab({ action: "stop" }, showState);
  };
});
