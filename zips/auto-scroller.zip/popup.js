document.addEventListener("DOMContentLoaded", () => {
  const slider = document.getElementById("speedSlider");
  const speedVal = document.getElementById("speedVal");
  const stopBtn = document.getElementById("stopBtn");
  const toggleBtn = document.getElementById("toggleBtn");
  const statusEl = document.getElementById("status");
  const errorEl = document.getElementById("error");
  const spacebarChk = document.getElementById("spacebarChk");
  const stopEndChk = document.getElementById("stopEndChk");

  chrome.storage.local.get(["savedSpeed", "spacebarEnabled", "stopAtEnd"], (result) => {
    if (result.savedSpeed !== undefined) {
      slider.value = result.savedSpeed;
      speedVal.innerText = parseFloat(result.savedSpeed).toFixed(1);
    }
    spacebarChk.checked = result.spacebarEnabled !== false;
    stopEndChk.checked = result.stopAtEnd !== false;
  });

  spacebarChk.addEventListener("change", () => chrome.storage.local.set({ spacebarEnabled: spacebarChk.checked }));
  stopEndChk.addEventListener("change", () => chrome.storage.local.set({ stopAtEnd: stopEndChk.checked }));

  const showState = (response) => {
    if (!response) {
      errorEl.style.display = "block";
      toggleBtn.disabled = true;
      return;
    }
    errorEl.style.display = "none";
    toggleBtn.disabled = false;
    const on = !!response.scrolling;
    statusEl.textContent = on ? "Scrolling" : "Stopped";
    statusEl.classList.toggle("on", on);
    toggleBtn.textContent = on ? "Pause" : "Start";
  };

  // Sends a message to the active tab, injecting the content script if it is missing
  const sendToActiveTab = (message, callback = () => {}) => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tabId = tabs[0]?.id;
      if (!tabId) return callback(null);
      chrome.tabs.sendMessage(tabId, message, (response) => {
        if (!chrome.runtime.lastError) return callback(response);
        // Content script missing (tab opened before install/reload): inject it, then retry
        chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] }, () => {
          if (chrome.runtime.lastError) return callback(null); // restricted page (chrome://, Web Store)
          chrome.tabs.sendMessage(tabId, message, (retry) => {
            callback(chrome.runtime.lastError ? null : retry);
          });
        });
      });
    });
  };

  const updatePageScroll = (value) => {
    const speed = parseFloat(value);
    speedVal.innerText = speed.toFixed(1);
    if (speed > 0) chrome.storage.local.set({ savedSpeed: speed });
    sendToActiveTab({ action: "setSpeed", speed: speed }, showState);
  };

  // Show current state when the popup opens
  sendToActiveTab({ action: "getState" }, showState);

  slider.addEventListener("input", (e) => updatePageScroll(e.target.value));

  toggleBtn.onclick = () => {
    if (parseFloat(slider.value) <= 0) {
      slider.value = 1;
      speedVal.innerText = "1.0";
    }
    sendToActiveTab({ action: "toggle" }, () => {
      // toggle may resolve asynchronously (reads the saved speed), so re-query
      setTimeout(() => sendToActiveTab({ action: "getState" }, showState), 100);
    });
  };

  stopBtn.onclick = () => {
    slider.value = 0;
    speedVal.innerText = "0.0";
    sendToActiveTab({ action: "stop" }, showState);
  };
});
