// 'frame' makes the menu appear when right-clicking inside an iframe (e.g. a payment frame).
export const MENU_CONTEXTS = ['editable', 'page', 'frame'];
export const PAGE_PATTERNS = ['http://*/*', 'https://*/*', 'file:///*'];
export const INSERT_PREFIX = 'insert:';

const FIELD_ONLY = ['editable'];
const insert = (kind, title) => ({ id: INSERT_PREFIX + kind, parentId: 'insert', title, contexts: FIELD_ONLY });

export const MENU_ITEMS = [
  { id: 'fill_form', title: '🪄 Fill Current Form' },
  { id: 'fill_field', title: '✨ Fill this field', contexts: FIELD_ONLY },
  { id: 'insert', title: '🧩 Insert test value', contexts: FIELD_ONLY },
  insert('fullName', 'Full name'),
  insert('email', 'Unique email'),
  insert('phone', 'Phone number'),
  insert('addressLine1', 'Street address'),
  insert('company', 'Company'),
  insert('password', 'Strong password'),
  insert('paragraph', 'Paragraph of text'),
  { id: 'insert_sep', parentId: 'insert', type: 'separator', contexts: FIELD_ONLY },
  insert('edge_long', 'Too long (max length + 1)'),
  insert('edge_unicode', 'Unicode and emoji'),
  insert('edge_rtl', 'Right-to-left text'),
  insert('edge_whitespace', 'Leading and trailing spaces'),
  insert('edge_xss', 'XSS probe'),
  insert('edge_sql', 'SQL injection probe'),
  { id: 'fill_overwrite', title: '✏️ Fill (overwrite)' },
  { id: 'undo_fill', title: '↩️ Undo last fill' },
  { id: 'clear_form', title: '🧹 Clear all fields' },
  { id: 'open_panel', title: '📋 Open FormFiller panel (Keep / Change / Skip)' }
];
