// 'frame' makes the menu appear when right-clicking inside an iframe (e.g. a payment frame).
export const MENU_CONTEXTS = ['editable', 'page', 'frame'];
export const PAGE_PATTERNS = ['http://*/*', 'https://*/*', 'file:///*'];
export const MENU_ITEMS = [
  { id: 'fill_form', title: '🪄 Fill Current Form' },
  { id: 'fill_overwrite', title: '✏️ Fill (overwrite)' },
  { id: 'undo_fill', title: '↩️ Undo last fill' },
  { id: 'clear_form', title: '🧹 Clear all fields' },
  { id: 'open_panel', title: '📋 Open FormFiller panel (Keep / Change / Skip)' }
];
