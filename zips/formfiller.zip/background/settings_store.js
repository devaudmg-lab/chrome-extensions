import '../utils/settings.js';
import '../utils/profiles.js';

export async function loadState() {
  const stored = await chrome.storage.local.get(['settings', 'customProfiles', 'urlRules']);
  const profiles = Array.isArray(stored.customProfiles) && stored.customProfiles.length > 0
    ? stored.customProfiles
    : globalThis.FormFillerProfiles.getDefault();
  return {
    settings: globalThis.FormFillerSettings.withDefaults(stored.settings),
    profiles,
    urlRules: stored.urlRules || []
  };
}
