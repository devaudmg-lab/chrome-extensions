// One-time storage migrations, keyed by settingsVersion.
export const SETTINGS_VERSION = 2;

// Luhn-valid public test cards; persona i uses CARDS[i % 10].
export const CARDS = [
  '4242424242424242', '4111111111111111', '4012888888881881', '4000056655665556', '5555555555554444',
  '5105105105105100', '2223003122003222', '5200828282828210', '378282246310005', '371449635398431'
];

// [cardNumber, cardExpiry] shipped by v1.0.0, in persona order.
export const LEGACY_CARDS = [
  ['4111222233334444', '12/29'], ['4222333344445555', '07/28'], ['4333444455556666', '11/27'], ['4444555566667777', '03/30'], ['4555666677778888', '09/29'], ['4666777788889999', '06/28'],
  ['4222333344445555', '08/30'], ['4111333355557777', '02/29'], ['4222444466668888', '10/28'], ['4333555577779999', '04/27'], ['4444666688880000', '09/30'], ['4555777799991111', '01/29'],
  ['4444555566667777', '10/27'], ['4111444477770000', '05/29'], ['4222555588881111', '12/28'], ['4333666699992222', '08/30'], ['4555888811114444', '03/29'], ['4666999922225555', '11/27'],
  ['4511222233334444', '09/29'], ['4522333344445555', '06/28'], ['4533444455556666', '11/27'], ['4544555566667777', '04/30'], ['4555666677778888', '07/29'], ['4566777788889999', '02/28'],
  ['4611222233334444', '05/29'], ['4622333344445555', '12/28'], ['4633444455556666', '08/29'], ['4644555566667777', '04/30'], ['4655666677778888', '10/27'], ['4666777788889999', '01/29']
];

const LEGACY_NUMBERS = new Set(LEGACY_CARDS.map(([n]) => n));
const LEGACY_EXPIRIES = new Set(LEGACY_CARDS.map(([, e]) => e));
const isAmex = (num) => /^3[47]/.test(num);

function migrateProfile(profile, index, defaults) {
  if (!LEGACY_NUMBERS.has(profile.cardNumber)) return profile;
  const match = defaults.find((d) => d.fullName === profile.fullName);
  const next = { ...profile };
  if (match) {
    next.cardNumber = match.cardNumber;
    next.cardCvv = match.cardCvv;
  } else {
    next.cardNumber = CARDS[index % CARDS.length];
    const cvv = String(profile.cardCvv || '123').slice(0, 3);
    next.cardCvv = isAmex(next.cardNumber) ? cvv + '4' : cvv;
  }
  if (LEGACY_EXPIRIES.has(profile.cardExpiry)) next.cardExpiry = '';
  return next;
}

export function migrate({ settings, customProfiles, settingsVersion } = {}, defaults = []) {
  if (settingsVersion >= SETTINGS_VERSION) {
    return { changed: false, settings, customProfiles, settingsVersion };
  }

  let nextSettings = settings;
  if (settings && settings.aiModel === 'gemini-1.5-flash') {
    nextSettings = { ...settings, aiModel: 'gemini-2.5-flash' };
  }

  const nextProfiles = Array.isArray(customProfiles)
    ? customProfiles.map((p, i) => migrateProfile(p, i, defaults))
    : customProfiles;

  const changed = nextSettings !== settings ||
    (Array.isArray(customProfiles) && nextProfiles.some((p, i) => p !== customProfiles[i])) ||
    settingsVersion !== SETTINGS_VERSION;

  return { changed, settings: nextSettings, customProfiles: nextProfiles, settingsVersion: SETTINGS_VERSION };
}
