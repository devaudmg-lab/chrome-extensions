const GEMINI_API_URL = 'https://generativelanguage.googleapis.com/v1beta/models';
const RETRY_STATUSES = new Set([429, 503]);

// Limits for what a content script may send to Gemini: the page decides how many fields
// and how long their labels are, and every byte is billed to the user's key.
export const AI_LIMITS = { fields: 150, text: 200, options: 50, bytes: 64 * 1024 };

const str = (v, max = AI_LIMITS.text) => (typeof v === 'string' ? v.slice(0, max) : '');

// A clean copy of the schema from serialize.aiPayload, or null when it's not one.
export function validateFormSchema(schema) {
  if (!schema || typeof schema !== 'object' || !Array.isArray(schema.fields)) return null;
  if (schema.fields.length === 0 || schema.fields.length > AI_LIMITS.fields) return null;
  const fields = [];
  for (const f of schema.fields) {
    if (!f || typeof f !== 'object' || typeof f.id !== 'string' || !/^ff_\d+$/.test(f.id)) return null;
    const entry = {
      id: f.id,
      name: str(f.name),
      type: str(f.type, 40),
      placeholder: str(f.placeholder),
      label: str(f.label),
      autocomplete: str(f.autocomplete, 80)
    };
    if (Array.isArray(f.options)) {
      entry.options = f.options.slice(0, AI_LIMITS.options)
        .filter((o) => o && typeof o === 'object')
        .map((o) => ({ value: str(o.value), text: str(o.text) }));
      if (Number.isInteger(f.optionsTotal)) entry.optionsTotal = f.optionsTotal;
    }
    fields.push(entry);
  }
  const out = { url: str(schema.url, 500), title: str(schema.title), fields };
  return JSON.stringify(out).length <= AI_LIMITS.bytes ? out : null;
}

// Only the short persona strings the content script sends reach the prompt.
const PERSONA_KEYS = ['fullName', 'email', 'phone', 'city', 'state', 'country', 'countryCode', 'birthDate', 'company'];

function systemInstruction(context) {
  const raw = context && context.locale;
  const locale = typeof raw === 'string' && /^([A-Z]{2}|random)$/.test(raw) ? raw : 'random';
  const source = (context && context.persona) || {};
  const persona = JSON.stringify(Object.fromEntries(PERSONA_KEYS
    .filter((k) => typeof source[k] === 'string')
    .map((k) => [k, str(source[k], 100)])));
  return 'You are an expert QA tester filling a web form with realistic test data. ' +
    'Return a JSON object with a "fields" array containing one {id, value} entry per form field. ' +
    'For "select" fields choose one of the provided options (prefer the option value). ' +
    'For "radio" fields return "true" for exactly one radio per group (same name) and "false" for the others. ' +
    'For "checkbox" fields return "true" or "false". ' +
    `Use this persona for personal details when relevant and stay consistent with locale ${locale}: ${persona}`;
}

const RESPONSE_SCHEMA = {
  type: 'OBJECT',
  properties: {
    fields: {
      type: 'ARRAY',
      items: {
        type: 'OBJECT',
        properties: { id: { type: 'STRING' }, value: { type: 'STRING' } },
        required: ['id', 'value']
      }
    }
  },
  required: ['fields']
};

function parseResponse(data) {
  const text = data && data.candidates && data.candidates[0] && data.candidates[0].content &&
    data.candidates[0].content.parts && data.candidates[0].content.parts[0] && data.candidates[0].content.parts[0].text;
  let parsed;
  try {
    parsed = JSON.parse(text);
  } catch {
    throw new Error('Invalid AI response');
  }
  if (!parsed || !Array.isArray(parsed.fields)) throw new Error('Invalid AI response');
  return {
    fields: parsed.fields
      .filter((f) => f && typeof f.id === 'string' && ['string', 'number', 'boolean'].includes(typeof f.value))
      .map((f) => ({ id: f.id, value: String(f.value) }))
      .filter((f) => f.value.trim() !== '')
  };
}

// Google's error message (e.g. "API key not valid"), not the whole JSON body.
async function errorMessage(response) {
  let text = '';
  try {
    text = await response.text();
    const body = JSON.parse(text);
    if (body && body.error && typeof body.error.message === 'string') text = body.error.message;
  } catch { /* plain text body */ }
  return String(text).replace(/\s+/g, ' ').trim().slice(0, 200) || 'no details';
}

export async function fetchAiAutofill({ apiKey, model, formSchema, context, fetchImpl = fetch, timeoutMs = 25000, retryDelayMs = 1000 }) {
  const modelId = String(model || '').replace(/^models\//, '');
  if (!/^[A-Za-z0-9][A-Za-z0-9._-]*$/.test(modelId)) throw new Error(`Invalid Gemini model ID "${model}"`);
  const url = `${GEMINI_API_URL}/${modelId}:generateContent`;
  const body = JSON.stringify({
    contents: [{ parts: [{ text: JSON.stringify(formSchema) }] }],
    systemInstruction: { parts: [{ text: systemInstruction(context) }] },
    generationConfig: { responseMimeType: 'application/json', responseSchema: RESPONSE_SCHEMA }
  });

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  const request = () => fetchImpl(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-goog-api-key': apiKey },
    body,
    signal: controller.signal
  });

  try {
    let response = await request();
    if (!response.ok && RETRY_STATUSES.has(response.status)) {
      await new Promise((r) => setTimeout(r, retryDelayMs));
      response = await request();
    }
    if (!response.ok) {
      throw new Error(`Gemini API HTTP Error ${response.status}: ${await errorMessage(response)}`);
    }
    return parseResponse(await response.json());
  } catch (e) {
    if (e.name === 'AbortError') throw new Error('AI request timed out after 25s');
    throw e;
  } finally {
    clearTimeout(timer);
  }
}
