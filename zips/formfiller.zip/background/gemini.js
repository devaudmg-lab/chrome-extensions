const GEMINI_API_URL = 'https://generativelanguage.googleapis.com/v1beta/models';
const RETRY_STATUSES = new Set([429, 503]);

function systemInstruction(context) {
  const locale = (context && context.locale) || 'random';
  const persona = JSON.stringify((context && context.persona) || {});
  return 'You are an expert QA tester filling a web form with realistic test data. ' +
    'Return a JSON object with a "fields" array containing one {id, value} entry per form field. ' +
    'For "select" fields choose one of the provided options (prefer the option value). ' +
    'For "radio" fields return "true" for exactly one radio per group (same name) and "false" for the others. ' +
    'For "checkbox" fields return "true" or "false". ' +
    `Use this persona for personal details when relevant and stay consistent with locale ${locale}: ${persona}`;
}

const RESPONSE_SCHEMA = {
  type: 'OBJECT',
  properties: {
    fields: {
      type: 'ARRAY',
      items: {
        type: 'OBJECT',
        properties: { id: { type: 'STRING' }, value: { type: 'STRING' } },
        required: ['id', 'value']
      }
    }
  },
  required: ['fields']
};

function parseResponse(data) {
  const text = data && data.candidates && data.candidates[0] && data.candidates[0].content &&
    data.candidates[0].content.parts && data.candidates[0].content.parts[0] && data.candidates[0].content.parts[0].text;
  let parsed;
  try {
    parsed = JSON.parse(text);
  } catch {
    throw new Error('Invalid AI response');
  }
  if (!parsed || !Array.isArray(parsed.fields)) throw new Error('Invalid AI response');
  return {
    fields: parsed.fields
      .filter((f) => f && typeof f.id === 'string' && ['string', 'number', 'boolean'].includes(typeof f.value))
      .map((f) => ({ id: f.id, value: String(f.value) }))
      .filter((f) => f.value.trim() !== '')
  };
}

export async function fetchAiAutofill({ apiKey, model, formSchema, context, fetchImpl = fetch, timeoutMs = 25000, retryDelayMs = 1000 }) {
  const modelId = String(model || '').replace(/^models\//, '');
  if (!/^[A-Za-z0-9][A-Za-z0-9._-]*$/.test(modelId)) throw new Error(`Invalid Gemini model ID "${model}"`);
  const url = `${GEMINI_API_URL}/${modelId}:generateContent`;
  const body = JSON.stringify({
    contents: [{ parts: [{ text: JSON.stringify(formSchema) }] }],
    systemInstruction: { parts: [{ text: systemInstruction(context) }] },
    generationConfig: { responseMimeType: 'application/json', responseSchema: RESPONSE_SCHEMA }
  });

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  const request = () => fetchImpl(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-goog-api-key': apiKey },
    body,
    signal: controller.signal
  });

  try {
    let response = await request();
    if (!response.ok && RETRY_STATUSES.has(response.status)) {
      await new Promise((r) => setTimeout(r, retryDelayMs));
      response = await request();
    }
    if (!response.ok) {
      throw new Error(`Gemini API HTTP Error ${response.status}: ${await response.text()}`);
    }
    return parseResponse(await response.json());
  } catch (e) {
    if (e.name === 'AbortError') throw new Error('AI request timed out after 25s');
    throw e;
  } finally {
    clearTimeout(timer);
  }
}
