import { loadState } from './settings_store.js';
import { createSession, aggregate } from './fill_session.js';

export const CONTENT_SCRIPTS = [
  'utils/settings.js',
  'utils/profiles.js',
  'content/dom.js',
  'content/events.js',
  'content/generators.js',
  'content/scanner.js',
  'content/analyzer.js',
  'content/matcher.js',
  'content/filler.js',
  'content/undo.js',
  'content/observer.js',
  'content/serialize.js',
  'content/locator.js',
  'content/modes.js',
  'content/overlay.js',
  'content/index.js'
];

const RESTRICTED_SCHEMES = new Set([
  'chrome:', 'edge:', 'about:', 'chrome-extension:', 'view-source:', 'devtools:', 'chrome-search:', 'chrome-untrusted:'
]);

export function isRestrictedUrl(url) {
  if (!url) return true;
  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    return true;
  }
  if (RESTRICTED_SCHEMES.has(parsed.protocol)) return true;
  if (parsed.hostname === 'chromewebstore.google.com') return true;
  if (parsed.hostname === 'chrome.google.com' && parsed.pathname.startsWith('/webstore')) return true;
  if (parsed.hostname === 'microsoftedge.microsoft.com' && parsed.pathname.startsWith('/addons')) return true;
  return false;
}

// The origin a per-site setting is keyed by (https://example.com), or '' for pages that
// can't be filled.
export function siteOrigin(url) {
  if (isRestrictedUrl(url)) return '';
  try {
    const { protocol, origin } = new URL(url);
    if (protocol === 'file:') return 'file://';
    return protocol === 'http:' || protocol === 'https:' ? origin : '';
  } catch {
    return '';
  }
}

export function shouldAutoFill(url, sites) {
  const origin = siteOrigin(url);
  return !!origin && Array.isArray(sites) && sites.includes(origin);
}

export async function getFrameIds(tabId) {
  try {
    const frames = await chrome.webNavigation.getAllFrames({ tabId });
    return frames && frames.length > 0 ? frames.map((f) => f.frameId) : [0];
  } catch {
    return [0];
  }
}

async function send(tabId, message, frameId) {
  try {
    return await chrome.tabs.sendMessage(tabId, message, { frameId });
  } catch {
    return undefined;
  }
}

// Frames without a live content script (tab opened before install, or orphaned by an
// extension reload) get a fresh copy injected.
export async function ensureInjected(tabId, frameIds) {
  const answers = await Promise.all(frameIds.map((id) => send(tabId, { action: 'ping' }, id)));
  const missing = frameIds.filter((id, i) => !(answers[i] && answers[i].ok));
  // One call per frame: a frame that detached or can't be scripted (sandboxed) would
  // otherwise make Chrome reject the whole batch.
  await Promise.allSettled(missing.map((frameId) =>
    chrome.scripting.executeScript({ target: { tabId, frameIds: [frameId] }, files: CONTENT_SCRIPTS })));
}

export async function broadcast(tabId, message, frameIds) {
  const results = await Promise.all(frameIds.map((id) => send(tabId, message, id)));
  return results.filter((r) => r !== undefined);
}

// Returns the frames to talk to, or null when the tab is a page we can't script.
async function prepare(tabId, frameId) {
  const tab = await chrome.tabs.get(tabId);
  if (isRestrictedUrl(tab && tab.url)) return null;
  const frameIds = frameId !== undefined ? [frameId] : await getFrameIds(tabId);
  await ensureInjected(tabId, frameIds);
  return frameIds;
}

export const lastProfileKey = (tabId) => `ff_lastProfile_${tabId}`;
const AI_SESSION_PREFIX = 'ff_ai_';
const aiSessionKey = (sessionId) => AI_SESSION_PREFIX + sessionId;
const AI_SESSION_TTL_MS = 10 * 60 * 1000;

// Content scripts run in every frame, including cross-origin ones: they get settings
// without the API key, plus a flag saying whether one is configured.
function contentSettings(settings) {
  const copy = { ...settings, aiConfigured: !!settings.aiKey };
  delete copy.aiKey;
  return copy;
}

function scanOptionsOf(settings) {
  return { skipHidden: settings.skipHidden !== false, fillReadonly: settings.fillReadonly === true };
}

// Starts an AI grant for one fill and drops grants that have expired.
async function grantAiSession(sessionId, now = Date.now()) {
  const all = await chrome.storage.session.get(null);
  const stale = Object.keys(all).filter((k) => k.startsWith(AI_SESSION_PREFIX) && !(all[k] && all[k].expires > now));
  if (stale.length) await chrome.storage.session.remove(stale);
  await chrome.storage.session.set({ [aiSessionKey(sessionId)]: { expires: now + AI_SESSION_TTL_MS, frames: [] } });
}

// AI calls are only made for fills the background itself started with AI allowed, and
// each frame of that fill gets one call, so a frame can't replay the grant to spend the
// user's quota.
export async function isAiSessionAuthorized(sessionId, frameId) {
  if (!sessionId || typeof sessionId !== 'string') return false;
  const key = aiSessionKey(sessionId);
  const grant = (await chrome.storage.session.get(key))[key];
  if (!grant || typeof grant.expires !== 'number' || grant.expires <= Date.now()) return false;
  const frame = frameId === undefined ? 0 : frameId;
  if (grant.frames.includes(frame)) return false;
  await chrome.storage.session.set({ [key]: { ...grant, frames: [...grant.frames, frame] } });
  return true;
}

// Our own pages (popup, options, either as a popup or opened in a tab). Content scripts
// always report the web page's URL, so they never match the extension origin.
export function isFromExtensionPage(sender) {
  if (!sender || sender.id !== chrome.runtime.id || !sender.url) return false;
  return sender.url.startsWith(`chrome-extension://${chrome.runtime.id}/`);
}

// Our own content scripts (they always come with the tab they run in).
export function isFromContentScript(sender) {
  return !!sender && sender.id === chrome.runtime.id && !!sender.tab && !isFromExtensionPage(sender);
}

// The key bound to "Undo last fill", for toasts ('' when unbound).
async function undoShortcut() {
  try {
    const commands = await chrome.commands.getAll();
    const undo = commands.find((c) => c.name === 'undo_fill');
    return (undo && undo.shortcut) || '';
  } catch {
    return '';
  }
}

const plural = (n, word) => `${n} ${word}${n === 1 ? '' : 's'}`;

// The on-page message after a fill started without the popup (shortcut, right-click,
// auto-fill), or '' when nothing should be shown.
export function fillToast(out, { auto = false, onlyEmpty = true, undoHint = '' } = {}) {
  const undo = undoHint ? ` · ${undoHint} to undo` : '';
  if (out.status === 'success') {
    if (auto) return out.filled > 0 ? `⚡ FormFiller auto-filled ${plural(out.filled, 'field')}${undo}` : '';
    const who = out.engine === 'ai' ? 'with Gemini AI' : `as ${out.profileName}`;
    let text = `🪄 Filled ${plural(out.filled, 'field')} ${who}${undo}`;
    if (out.aiError) text += `\n⚠️ AI failed (${out.aiError}), filled locally.`;
    return text;
  }
  if (auto) return '';
  if (out.status === 'no_fields') return onlyEmpty && !out.overwrite ? 'ℹ️ FormFiller: no empty fields to fill.' : 'ℹ️ FormFiller: no fillable fields here.';
  if (out.status === 'no_field') return 'ℹ️ FormFiller: right-click a text field to fill it.';
  if (out.status === 'error') return `❌ FormFiller: ${out.message || 'the fill failed.'}`;
  return '';
}

async function toast(tabId, text, frameId = 0) {
  if (text) await send(tabId, { action: 'toast', text }, frameId);
}

// One fill's session: persona, password, card and settings (without the API key).
async function buildSession(tabId, { overwrite, forceAi, auto }) {
  const state = await loadState();
  const stored = await chrome.storage.session.get(lastProfileKey(tabId));
  const session = createSession({ ...state, lastName: stored[lastProfileKey(tabId)], overwrite, forceAi });
  if (!auto && (state.settings.aiEnabled || forceAi) && state.settings.aiKey) await grantAiSession(session.sessionId);
  session.settings = contentSettings(session.settings);
  if (auto) {
    session.settings.aiEnabled = false;
    session.settings.onlyEmpty = true;
    session.auto = true;
  }
  return session;
}

// auto: a fill started by "Auto-fill this site on load". It never overwrites and never
// calls AI (no surprise API usage on every page load).
// scope: 'context' limits the fill to the right-clicked form, 'field' to the right-clicked field.
// notify: show the result on the page (no popup is open to show it).
export async function runFill(tabId, { overwrite = false, forceAi = false, frameId, scope, auto = false, notify = false } = {}) {
  const frameIds = await prepare(tabId, frameId);
  if (!frameIds) return { status: 'restricted', filled: 0, invalid: 0, engine: 'local' };
  if (auto) {
    overwrite = false;
    forceAi = false;
  }
  const session = await buildSession(tabId, { overwrite, forceAi, auto });
  if (scope) session.scope = scope;
  const results = await broadcast(tabId, { action: 'fill_form', session }, frameIds);
  await chrome.storage.session.set({ [lastProfileKey(tabId)]: session.persona.fullName });
  const out = aggregate(results, session.persona.fullName);
  if (out.status === 'success') {
    if (session.edge) out.edge = true;
    if (session.cardNote) out.cardNote = session.cardNote;
  }
  if (auto || notify) {
    const text = fillToast({ ...out, overwrite }, { auto, onlyEmpty: session.settings.onlyEmpty, undoHint: await undoShortcut() });
    await toast(tabId, text, scope === 'field' && frameId !== undefined ? frameId : 0);
  }
  return out;
}

// Only the origin list is read: this runs on every page load.
export async function runAutoFill(tabId, url) {
  const { settings } = await chrome.storage.local.get('settings');
  if (!shouldAutoFill(url, settings && settings.autoFillSites)) return null;
  return runFill(tabId, { auto: true });
}

// Right-click → "Insert test value" → kind, typed into the right-clicked field.
export const INSERT_KINDS = ['fullName', 'email', 'phone', 'addressLine1', 'company', 'password', 'paragraph',
  'edge_long', 'edge_unicode', 'edge_rtl', 'edge_whitespace', 'edge_xss', 'edge_sql'];

export async function runInsert(tabId, frameId, kind) {
  if (!INSERT_KINDS.includes(kind)) return { status: 'error', message: 'Unknown value type' };
  const frame = frameId === undefined ? 0 : frameId;
  const frameIds = await prepare(tabId, frame);
  if (!frameIds) return { status: 'restricted' };
  const session = await buildSession(tabId, {});
  const out = (await send(tabId, { action: 'insert_value', kind, session }, frame)) ||
    { status: 'error', message: 'No response from the page.' };
  if (out.status !== 'success') await toast(tabId, fillToast(out), frame);
  return out;
}

export async function runUndo(tabId, { notify = false } = {}) {
  const frameIds = await prepare(tabId);
  if (!frameIds) return { status: 'restricted', restored: 0 };
  const results = await broadcast(tabId, { action: 'undo_fill' }, frameIds);
  const restored = results.reduce((n, r) => n + (r.restored || 0), 0);
  const out = { status: results.some((r) => r.status === 'undone') ? 'undone' : 'nothing', restored };
  if (notify) await toast(tabId, out.status === 'undone' ? `↩️ FormFiller restored ${plural(restored, 'field')}.` : 'ℹ️ FormFiller: nothing to undo.');
  return out;
}

export async function runClear(tabId, frameId) {
  const frameIds = await prepare(tabId, frameId);
  if (!frameIds) return { status: 'restricted', count: 0 };
  const { settings } = await loadState();
  const results = await broadcast(tabId, { action: 'clear_form', scanOptions: scanOptionsOf(settings) }, frameIds);
  return { status: 'cleared', count: results.reduce((n, r) => n + (r.count || 0), 0) };
}

export async function runCapture(tabId) {
  const frameIds = await prepare(tabId, 0);
  if (!frameIds) return { status: 'restricted' };
  const { settings } = await loadState();
  const response = await send(tabId, { action: 'capture_form', scanOptions: scanOptionsOf(settings) }, 0);
  return response || { status: 'error', message: 'No response from the page.' };
}

// Field list for the side panel: every frame that has fields, tagged with its frame id.
export async function runListFields(tabId) {
  const frameIds = await prepare(tabId);
  if (!frameIds) return { status: 'restricted', frames: [] };
  const { settings } = await loadState();
  const message = { action: 'list_fields', scanOptions: scanOptionsOf(settings) };
  const answers = await Promise.all(frameIds.map((frameId) => send(tabId, message, frameId)));
  const frames = answers
    .map((answer, i) => answer && answer.status === 'success' && answer.fields.length > 0 ? { frameId: frameIds[i], ...answer } : null)
    .filter(Boolean);
  return { status: 'success', frames };
}

// What the side panel may ask a frame to do. Fills and undo go through runFill/runUndo.
export const PANEL_ACTIONS = ['highlight', 'set_mode', 'apply_preset', 'reset_modes'];

export async function runPanelAction(tabId, frameId, message) {
  if (!message || !PANEL_ACTIONS.includes(message.action)) return { status: 'error', message: 'Unsupported panel action' };
  let out = message;
  if (message.action === 'apply_preset') {
    const { settings } = await loadState();
    out = { ...message, scanOptions: scanOptionsOf(settings) };
  }
  return (await send(tabId, out, frameId)) || { status: 'error', message: 'No response from the page.' };
}
