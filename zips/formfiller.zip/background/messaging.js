import { loadState } from './settings_store.js';
import { createSession, aggregate } from './fill_session.js';

export const CONTENT_SCRIPTS = [
  'utils/settings.js',
  'utils/profiles.js',
  'content/dom.js',
  'content/events.js',
  'content/generators.js',
  'content/scanner.js',
  'content/analyzer.js',
  'content/matcher.js',
  'content/filler.js',
  'content/undo.js',
  'content/observer.js',
  'content/serialize.js',
  'content/locator.js',
  'content/modes.js',
  'content/overlay.js',
  'content/index.js'
];

const RESTRICTED_SCHEMES = new Set([
  'chrome:', 'edge:', 'about:', 'chrome-extension:', 'view-source:', 'devtools:', 'chrome-search:', 'chrome-untrusted:'
]);

export function isRestrictedUrl(url) {
  if (!url) return true;
  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    return true;
  }
  if (RESTRICTED_SCHEMES.has(parsed.protocol)) return true;
  if (parsed.hostname === 'chromewebstore.google.com') return true;
  if (parsed.hostname === 'chrome.google.com' && parsed.pathname.startsWith('/webstore')) return true;
  if (parsed.hostname === 'microsoftedge.microsoft.com' && parsed.pathname.startsWith('/addons')) return true;
  return false;
}

// The origin a per-site setting is keyed by (https://example.com), or '' for pages that
// can't be filled.
export function siteOrigin(url) {
  if (isRestrictedUrl(url)) return '';
  try {
    const { protocol, origin } = new URL(url);
    if (protocol === 'file:') return 'file://';
    return protocol === 'http:' || protocol === 'https:' ? origin : '';
  } catch {
    return '';
  }
}

export function shouldAutoFill(url, sites) {
  const origin = siteOrigin(url);
  return !!origin && Array.isArray(sites) && sites.includes(origin);
}

export async function getFrameIds(tabId) {
  try {
    const frames = await chrome.webNavigation.getAllFrames({ tabId });
    return frames && frames.length > 0 ? frames.map((f) => f.frameId) : [0];
  } catch {
    return [0];
  }
}

async function send(tabId, message, frameId) {
  try {
    return await chrome.tabs.sendMessage(tabId, message, { frameId });
  } catch {
    return undefined;
  }
}

// Frames without a live content script (tab opened before install, or orphaned by an
// extension reload) get a fresh copy injected.
export async function ensureInjected(tabId, frameIds) {
  const answers = await Promise.all(frameIds.map((id) => send(tabId, { action: 'ping' }, id)));
  const missing = frameIds.filter((id, i) => !(answers[i] && answers[i].ok));
  // One call per frame: a frame that detached or can't be scripted (sandboxed) would
  // otherwise make Chrome reject the whole batch.
  await Promise.allSettled(missing.map((frameId) =>
    chrome.scripting.executeScript({ target: { tabId, frameIds: [frameId] }, files: CONTENT_SCRIPTS })));
}

export async function broadcast(tabId, message, frameIds) {
  const results = await Promise.all(frameIds.map((id) => send(tabId, message, id)));
  return results.filter((r) => r !== undefined);
}

// Returns the frames to talk to, or null when the tab is a page we can't script.
async function prepare(tabId, frameId) {
  const tab = await chrome.tabs.get(tabId);
  if (isRestrictedUrl(tab && tab.url)) return null;
  const frameIds = frameId !== undefined ? [frameId] : await getFrameIds(tabId);
  await ensureInjected(tabId, frameIds);
  return frameIds;
}

const lastProfileKey = (tabId) => `ff_lastProfile_${tabId}`;
const aiSessionKey = (sessionId) => `ff_ai_${sessionId}`;
const AI_SESSION_TTL_MS = 10 * 60 * 1000;

// Content scripts run in every frame, including cross-origin ones: they get settings
// without the API key, plus a flag saying whether one is configured.
function contentSettings(settings) {
  const copy = { ...settings, aiConfigured: !!settings.aiKey };
  delete copy.aiKey;
  return copy;
}

function scanOptionsOf(settings) {
  return { skipHidden: settings.skipHidden !== false, fillReadonly: settings.fillReadonly === true };
}

// AI calls are only made for fills the background itself started with AI allowed.
export async function isAiSessionAuthorized(sessionId) {
  if (!sessionId) return false;
  const stored = await chrome.storage.session.get(aiSessionKey(sessionId));
  const expires = stored[aiSessionKey(sessionId)];
  return typeof expires === 'number' && expires > Date.now();
}

// Our own pages (popup, options, either as a popup or opened in a tab). Content scripts
// always report the web page's URL, so they never match the extension origin.
export function isFromExtensionPage(sender) {
  if (!sender || sender.id !== chrome.runtime.id || !sender.url) return false;
  return sender.url.startsWith(`chrome-extension://${chrome.runtime.id}/`);
}

// The key bound to "Undo last fill", for the auto-fill toast ('' when unbound).
async function undoShortcut() {
  try {
    const commands = await chrome.commands.getAll();
    const undo = commands.find((c) => c.name === 'undo_fill');
    return (undo && undo.shortcut) || '';
  } catch {
    return '';
  }
}

// auto: a fill started by "Auto-fill this site on load". It never overwrites, never calls
// AI (no surprise API usage on every page load) and tells the page to show a toast.
export async function runFill(tabId, { overwrite = false, forceAi = false, frameId, scope, auto = false } = {}) {
  const frameIds = await prepare(tabId, frameId);
  if (!frameIds) return { status: 'restricted', filled: 0, invalid: 0, engine: 'local' };
  if (auto) {
    overwrite = false;
    forceAi = false;
  }
  const state = await loadState();
  const stored = await chrome.storage.session.get(lastProfileKey(tabId));
  const session = createSession({ ...state, lastName: stored[lastProfileKey(tabId)], overwrite, forceAi });
  if (!auto && (state.settings.aiEnabled || forceAi) && state.settings.aiKey) {
    await chrome.storage.session.set({ [aiSessionKey(session.sessionId)]: Date.now() + AI_SESSION_TTL_MS });
  }
  session.settings = contentSettings(session.settings);
  if (auto) {
    session.settings.aiEnabled = false;
    session.settings.onlyEmpty = true;
    session.auto = true;
    session.undoHint = await undoShortcut();
  }
  // 'context' limits the fill to the form that was right-clicked.
  if (scope) session.scope = scope;
  const results = await broadcast(tabId, { action: 'fill_form', session }, frameIds);
  await chrome.storage.session.set({ [lastProfileKey(tabId)]: session.persona.fullName });
  const out = aggregate(results, session.persona.fullName);
  if (out.status === 'success') {
    if (session.edge) out.edge = true;
    if (session.cardNote) out.cardNote = session.cardNote;
  }
  return out;
}

export async function runAutoFill(tabId, url) {
  const { settings } = await loadState();
  if (!shouldAutoFill(url, settings.autoFillSites)) return null;
  return runFill(tabId, { auto: true });
}

export async function runUndo(tabId) {
  const frameIds = await prepare(tabId);
  if (!frameIds) return { status: 'restricted', restored: 0 };
  const results = await broadcast(tabId, { action: 'undo_fill' }, frameIds);
  const restored = results.reduce((n, r) => n + (r.restored || 0), 0);
  return { status: results.some((r) => r.status === 'undone') ? 'undone' : 'nothing', restored };
}

export async function runClear(tabId, frameId) {
  const frameIds = await prepare(tabId, frameId);
  if (!frameIds) return { status: 'restricted', count: 0 };
  const { settings } = await loadState();
  const results = await broadcast(tabId, { action: 'clear_form', scanOptions: scanOptionsOf(settings) }, frameIds);
  return { status: 'cleared', count: results.reduce((n, r) => n + (r.count || 0), 0) };
}

export async function runCapture(tabId) {
  const frameIds = await prepare(tabId, 0);
  if (!frameIds) return { status: 'restricted' };
  const { settings } = await loadState();
  const response = await send(tabId, { action: 'capture_form', scanOptions: scanOptionsOf(settings) }, 0);
  return response || { status: 'error', message: 'No response from the page.' };
}

// Field list for the side panel: every frame that has fields, tagged with its frame id.
export async function runListFields(tabId) {
  const frameIds = await prepare(tabId);
  if (!frameIds) return { status: 'restricted', frames: [] };
  const { settings } = await loadState();
  const message = { action: 'list_fields', scanOptions: scanOptionsOf(settings) };
  const answers = await Promise.all(frameIds.map((frameId) => send(tabId, message, frameId)));
  const frames = answers
    .map((answer, i) => answer && answer.status === 'success' && answer.fields.length > 0 ? { frameId: frameIds[i], ...answer } : null)
    .filter(Boolean);
  return { status: 'success', frames };
}

// What the side panel may ask a frame to do. Fills and undo go through runFill/runUndo.
export const PANEL_ACTIONS = ['highlight', 'set_mode', 'apply_preset', 'reset_modes'];

export async function runPanelAction(tabId, frameId, message) {
  if (!message || !PANEL_ACTIONS.includes(message.action)) return { status: 'error', message: 'Unsupported panel action' };
  let out = message;
  if (message.action === 'apply_preset') {
    const { settings } = await loadState();
    out = { ...message, scanOptions: scanOptionsOf(settings) };
  }
  return (await send(tabId, out, frameId)) || { status: 'error', message: 'No response from the page.' };
}
