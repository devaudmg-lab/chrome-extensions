import '../content/generators.js';
import '../utils/locales.js';
import '../utils/datagen.js';

const Gen = () => globalThis.FormFillerGen;
const Data = () => globalThis.FormFillerDataGen;

export function pickPersona(profiles, locale, lastName) {
  let pool = locale && locale !== 'random' ? profiles.filter((p) => p.countryCode === locale) : profiles;
  if (pool.length === 0) pool = profiles;
  if (lastName && pool.length > 1) {
    const others = pool.filter((p) => p.fullName !== lastName);
    if (others.length > 0) pool = others;
  }
  return pool[Gen().randInt(0, pool.length - 1)];
}

function parseExpiry(mmYY) {
  const [month, yy] = String(mmYY).split('/').map((s) => s.trim());
  return { month: month.padStart(2, '0'), year: yy.length === 2 ? '20' + yy : yy };
}

// Generated when asked for, or when the chosen locale has no built-in persona.
function basePersona(settings, profiles, lastName, now) {
  const locale = settings.locale;
  const known = !!globalThis.FormFillerLocales.LOCALES[locale];
  const noFixed = locale && locale !== 'random' && known && !profiles.some((p) => p.countryCode === locale);
  if (settings.dataSource === 'generated' || noFixed) {
    const codes = globalThis.FormFillerLocales.codes();
    const code = known ? locale : codes[Gen().randInt(0, codes.length - 1)];
    return Data().generatePersona(code, { now });
  }
  return Data().extendPersona(pickPersona(profiles, locale, lastName), now);
}

// One session per fill: the same persona, password and card expiry go to every frame.
export function createSession({ settings, profiles, urlRules, lastName, overwrite, forceAi, now = new Date() }) {
  const persona = basePersona(settings, profiles, lastName, now);
  persona.email = Data().emailFor(persona, settings, now);
  persona.username = Data().usernameFor(persona, settings, now);
  const card = Data().pickCard({ gateway: settings.cardGateway, brand: settings.cardBrand, scenario: settings.cardScenario });
  if (card) {
    persona.cardNumber = card.number;
    persona.cardCvv = card.cvv;
  }
  const password = settings.passwordSource !== 'generate' && persona.password
    ? persona.password
    : Gen().password({ length: settings.passwordLength });
  const expiry = Gen().expiryIsFuture(persona.cardExpiry, now) ? parseExpiry(persona.cardExpiry) : Gen().futureExpiry(now);
  return {
    sessionId: crypto.randomUUID(),
    persona,
    password,
    expiry,
    settings,
    urlRules: urlRules || [],
    overwrite: !!overwrite,
    forceAi: !!forceAi,
    edge: settings.edgeMode === true,
    ...(card && card.note ? { cardNote: card.note } : {})
  };
}

export function aggregate(results, profileName) {
  const list = results.filter(Boolean);
  const out = { status: 'error', filled: 0, invalid: 0, engine: 'local' };
  for (const r of list) {
    out.filled += r.filled || 0;
    out.invalid += r.invalid || 0;
    if (r.engine === 'ai') out.engine = 'ai';
    if (r.aiError && !out.aiError) out.aiError = r.aiError;
  }
  if (list.some((r) => r.status === 'success')) out.status = 'success';
  else if (list.some((r) => r.status === 'no_fields')) out.status = 'no_fields';
  else out.message = (list.find((r) => r.message) || {}).message || 'No response from the page.';
  if (out.status !== 'error') out.profileName = profileName;
  return out;
}
