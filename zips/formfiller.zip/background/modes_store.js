// Keep / Change / Skip modes, stored per page as `ff_modes:<origin+path>`.
// storage.local is restricted to extension pages and the service worker (it holds the
// Gemini key), so content scripts read and write their page's modes through here. The
// page is taken from the sender, never from the message, so one frame can't touch
// another site's modes.
export const MODES_PREFIX = 'ff_modes:';
export const MODES_INDEX_KEY = 'ff_modes_index';
export const MAX_MODE_PAGES = 300;
const MAX_MAP_BYTES = 200 * 1024;

// Mirrors FormFillerLocator.siteKey() in the content script: origin + path, 'file://'
// for local files, and null for opaque origins (sandboxed and data: frames).
export function siteFromSender(sender) {
  if (!sender || !sender.url) return null;
  let url;
  try {
    url = new URL(sender.url);
  } catch {
    return null;
  }
  const origin = url.protocol === 'file:' ? 'file://' : (sender.origin || url.origin);
  if (!origin || origin === 'null') return null;
  return origin + url.pathname;
}

const isObject = (v) => !!v && typeof v === 'object' && !Array.isArray(v);

export function isValidModesMap(map) {
  if (!isObject(map)) return false;
  for (const form of Object.values(map)) {
    if (!isObject(form)) return false;
    for (const entry of Object.values(form)) {
      if (!isObject(entry) || !['keep', 'change', 'skip'].includes(entry.mode)) return false;
    }
  }
  return JSON.stringify(map).length <= MAX_MAP_BYTES;
}

export async function getModes(sender) {
  const site = siteFromSender(sender);
  if (!site) return {};
  const key = MODES_PREFIX + site;
  const data = await chrome.storage.local.get(key);
  return data[key] || {};
}

// Pages saved before the index existed (v1.3.0 and older) count as the oldest.
async function seedIndex() {
  const all = await chrome.storage.local.get(null);
  const index = {};
  for (const k of Object.keys(all)) if (k.startsWith(MODES_PREFIX)) index[k.slice(MODES_PREFIX.length)] = 0;
  return index;
}

// Saves (or removes, when empty) the sender page's modes and keeps an index of when each
// page was last changed, so the oldest pages are dropped beyond MAX_MODE_PAGES.
export async function setModes(sender, map, now = Date.now()) {
  const site = siteFromSender(sender);
  if (!site) return { status: 'error', message: 'This frame has no stable address.' };
  if (!isValidModesMap(map)) return { status: 'error', message: 'Invalid field modes.' };
  const key = MODES_PREFIX + site;
  const { [MODES_INDEX_KEY]: stored } = await chrome.storage.local.get(MODES_INDEX_KEY);
  const index = isObject(stored) ? { ...stored } : await seedIndex();
  if (Object.keys(map).length === 0) {
    delete index[site];
    await chrome.storage.local.remove(key);
    await chrome.storage.local.set({ [MODES_INDEX_KEY]: index });
    return { status: 'success' };
  }
  index[site] = now;
  const sites = Object.keys(index).sort((a, b) => index[a] - index[b]);
  const dropped = sites.slice(0, Math.max(0, sites.length - MAX_MODE_PAGES));
  for (const s of dropped) delete index[s];
  if (dropped.length) await chrome.storage.local.remove(dropped.map((s) => MODES_PREFIX + s));
  await chrome.storage.local.set({ [key]: map, [MODES_INDEX_KEY]: index });
  return { status: 'success' };
}
