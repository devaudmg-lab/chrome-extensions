import { fetchAiAutofill, validateFormSchema } from './gemini.js';
import { migrate } from './migrate.js';
import { loadState } from './settings_store.js';
import { MENU_ITEMS, MENU_CONTEXTS, PAGE_PATTERNS, INSERT_PREFIX } from './menus.js';
import { getModes, setModes } from './modes_store.js';
import {
  runFill, runUndo, runClear, runCapture, runListFields, runPanelAction, runAutoFill, runInsert,
  isAiSessionAuthorized, isFromExtensionPage, isFromContentScript, lastProfileKey
} from './messaging.js';

// Used by the Playwright e2e suite to trigger fills without the popup.
globalThis.formFillerRunFill = runFill;
globalThis.formFillerRunUndo = runUndo;
globalThis.formFillerRunInsert = runInsert;

// storage.local holds the Gemini key: only extension pages and this worker may read it,
// never content scripts (they run in every frame of every site). Content scripts get
// what they need through messages. The level persists, but is set on every start in
// case an older version or Chrome reset it.
function restrictStorage() {
  if (chrome.storage.local.setAccessLevel) {
    chrome.storage.local.setAccessLevel({ accessLevel: 'TRUSTED_CONTEXTS' }).catch(() => {});
  }
}
restrictStorage();

async function runMigration() {
  const data = await chrome.storage.local.get(['settings', 'customProfiles', 'settingsVersion']);
  const out = migrate(data, globalThis.FormFillerProfiles.getDefault());
  if (!out.changed) return;
  const update = { settingsVersion: out.settingsVersion };
  if (out.settings !== undefined) update.settings = out.settings;
  if (out.customProfiles !== undefined) update.customProfiles = out.customProfiles;
  await chrome.storage.local.set(update);
}

chrome.runtime.onInstalled.addListener(() => {
  restrictStorage();
  chrome.contextMenus.removeAll(() => {
    for (const item of MENU_ITEMS) {
      chrome.contextMenus.create({ contexts: MENU_CONTEXTS, documentUrlPatterns: PAGE_PATTERNS, ...item });
    }
  });
  runMigration().catch(() => {});
});

chrome.runtime.onStartup.addListener(() => {
  runMigration().catch(() => {});
});

chrome.tabs.onRemoved.addListener((tabId) => {
  chrome.storage.session.remove(lastProfileKey(tabId)).catch(() => {});
});

const quiet = (promise) => { promise.catch(() => {}); };

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (!tab || tab.id === undefined) return;
  const id = String(info.menuItemId);
  if (id.startsWith(INSERT_PREFIX)) {
    quiet(runInsert(tab.id, info.frameId, id.slice(INSERT_PREFIX.length)));
    return;
  }
  switch (id) {
    // sidePanel.open must run inside the click's user gesture, before any await.
    case 'open_panel': chrome.sidePanel.open({ tabId: tab.id }).catch(() => {}); break;
    case 'fill_form': quiet(runFill(tab.id, { frameId: info.frameId, scope: 'context', notify: true })); break;
    case 'fill_field': quiet(runFill(tab.id, { frameId: info.frameId, scope: 'field', notify: true })); break;
    case 'fill_overwrite': quiet(runFill(tab.id, { frameId: info.frameId, overwrite: true, notify: true })); break;
    case 'undo_fill': quiet(runUndo(tab.id, { notify: true })); break;
    case 'clear_form': quiet(runClear(tab.id, info.frameId)); break;
  }
});

// "Auto-fill this site on load": fill once the top frame has loaded, and again after a
// single-page app changes its address. The short delay lets client-rendered forms
// appear; fields added later are caught by the content observer.
const AUTO_FILL_DELAY_MS = 400;
function scheduleAutoFill(details) {
  if (details.frameId !== 0) return;
  setTimeout(() => quiet(runAutoFill(details.tabId, details.url)), AUTO_FILL_DELAY_MS);
}
chrome.webNavigation.onCompleted.addListener(scheduleAutoFill);
chrome.webNavigation.onHistoryStateUpdated.addListener(scheduleAutoFill);

async function activeTabId(tab) {
  if (tab && tab.id !== undefined) return tab.id;
  const [active] = await chrome.tabs.query({ active: true, currentWindow: true });
  return active && active.id;
}

chrome.commands.onCommand.addListener(async (command, tab) => {
  const tabId = await activeTabId(tab);
  if (tabId === undefined) return;
  switch (command) {
    case 'fill_current_form': quiet(runFill(tabId, { notify: true })); break;
    case 'fill_form_ai': quiet(runFill(tabId, { forceAi: true, notify: true })); break;
    case 'fill_form_overwrite': quiet(runFill(tabId, { overwrite: true, notify: true })); break;
    case 'undo_fill': quiet(runUndo(tabId, { notify: true })); break;
  }
});

async function analyzeWithAi(message, sender) {
  if (!isFromContentScript(sender) || !(await isAiSessionAuthorized(message.sessionId, sender.frameId))) {
    return { status: 'fallback', reason: 'AI not enabled for this fill' };
  }
  const formSchema = validateFormSchema(message.formSchema);
  if (!formSchema) return { status: 'fallback', reason: 'Form too large or malformed for AI' };
  const { settings } = await loadState();
  if (!settings.aiKey) return { status: 'fallback', reason: 'Gemini API key is missing' };
  try {
    const data = await fetchAiAutofill({
      apiKey: settings.aiKey,
      model: settings.aiModel || 'gemini-2.5-flash',
      formSchema,
      context: message.context
    });
    return { status: 'success', data };
  } catch (e) {
    return { status: 'fallback', reason: e.message };
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const action = message && message.action;
  // Popup/options commands are only accepted from our own extension pages, never from content scripts.
  if (typeof action !== 'string') return false;
  if (action.startsWith('RUN_') && !isFromExtensionPage(sender)) return false;
  if ((action.startsWith('MODES_') || action === 'ANALYZE_FORM_AI') && !isFromContentScript(sender)) return false;
  let work;
  switch (action) {
    case 'RUN_FILL': work = runFill(message.tabId, { overwrite: message.overwrite, forceAi: message.forceAi }); break;
    case 'RUN_UNDO': work = runUndo(message.tabId); break;
    case 'RUN_CLEAR': work = runClear(message.tabId); break;
    case 'RUN_CAPTURE': work = runCapture(message.tabId); break;
    case 'RUN_LIST_FIELDS': work = runListFields(message.tabId); break;
    case 'RUN_PANEL': work = runPanelAction(message.tabId, message.frameId, message.payload); break;
    case 'ANALYZE_FORM_AI': work = analyzeWithAi(message, sender); break;
    case 'MODES_GET': work = getModes(sender).then((map) => ({ status: 'success', map })); break;
    case 'MODES_SET': work = setModes(sender, message.map); break;
    default: return false;
  }
  work.then(sendResponse).catch((e) => sendResponse({ status: 'error', message: e.message }));
  return true;
});
