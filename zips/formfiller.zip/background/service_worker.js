import { fetchAiAutofill } from './gemini.js';
import { migrate } from './migrate.js';
import { loadState } from './settings_store.js';
import { MENU_ITEMS, MENU_CONTEXTS, PAGE_PATTERNS } from './menus.js';
import { runFill, runUndo, runClear, runCapture, runListFields, runPanelAction, isAiSessionAuthorized, isFromExtensionPage } from './messaging.js';

// Used by the Playwright e2e suite to trigger fills without the popup.
globalThis.formFillerRunFill = runFill;
globalThis.formFillerRunUndo = runUndo;


async function runMigration() {
  const data = await chrome.storage.local.get(['settings', 'customProfiles', 'settingsVersion']);
  const out = migrate(data, globalThis.FormFillerProfiles.getDefault());
  if (!out.changed) return;
  const update = { settingsVersion: out.settingsVersion };
  if (out.settings !== undefined) update.settings = out.settings;
  if (out.customProfiles !== undefined) update.customProfiles = out.customProfiles;
  await chrome.storage.local.set(update);
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.removeAll(() => {
    for (const item of MENU_ITEMS) {
      chrome.contextMenus.create({ ...item, contexts: MENU_CONTEXTS, documentUrlPatterns: PAGE_PATTERNS });
    }
  });
  runMigration();
});

chrome.runtime.onStartup.addListener(() => {
  runMigration();
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (!tab || tab.id === undefined) return;
  switch (info.menuItemId) {
    // sidePanel.open must run inside the click's user gesture, before any await.
    case 'open_panel': chrome.sidePanel.open({ tabId: tab.id }).catch(() => {}); break;
    case 'fill_form': runFill(tab.id, { frameId: info.frameId, scope: 'context' }); break;
    case 'fill_overwrite': runFill(tab.id, { frameId: info.frameId, overwrite: true }); break;
    case 'undo_fill': runUndo(tab.id); break;
    case 'clear_form': runClear(tab.id, info.frameId); break;
  }
});

async function activeTabId(tab) {
  if (tab && tab.id !== undefined) return tab.id;
  const [active] = await chrome.tabs.query({ active: true, currentWindow: true });
  return active && active.id;
}

chrome.commands.onCommand.addListener(async (command, tab) => {
  const tabId = await activeTabId(tab);
  if (tabId === undefined) return;
  switch (command) {
    case 'fill_current_form': runFill(tabId); break;
    case 'fill_form_ai': runFill(tabId, { forceAi: true }); break;
    case 'fill_form_overwrite': runFill(tabId, { overwrite: true }); break;
    case 'undo_fill': runUndo(tabId); break;
  }
});

async function analyzeWithAi(message, sender) {
  if (!sender || sender.id !== chrome.runtime.id || !sender.tab || !(await isAiSessionAuthorized(message.sessionId))) {
    return { status: 'fallback', reason: 'AI not enabled for this fill' };
  }
  const { settings } = await loadState();
  if (!settings.aiKey) return { status: 'fallback', reason: 'Gemini API key is missing' };
  try {
    const data = await fetchAiAutofill({
      apiKey: settings.aiKey,
      model: settings.aiModel || 'gemini-2.5-flash',
      formSchema: message.formSchema,
      context: message.context
    });
    return { status: 'success', data };
  } catch (e) {
    return { status: 'fallback', reason: e.message };
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const action = message && message.action;
  // Popup/options commands are only accepted from our own extension pages, never from content scripts.
  if (action && action.startsWith('RUN_') && !isFromExtensionPage(sender)) return false;
  let work;
  switch (action) {
    case 'RUN_FILL': work = runFill(message.tabId, { overwrite: message.overwrite, forceAi: message.forceAi }); break;
    case 'RUN_UNDO': work = runUndo(message.tabId); break;
    case 'RUN_CAPTURE': work = runCapture(message.tabId); break;
    case 'RUN_LIST_FIELDS': work = runListFields(message.tabId); break;
    case 'RUN_PANEL': work = runPanelAction(message.tabId, message.frameId, message.payload); break;
    case 'ANALYZE_FORM_AI': work = analyzeWithAi(message, sender); break;
    default: return false;
  }
  work.then(sendResponse).catch((e) => sendResponse({ status: 'error', message: e.message }));
  return true;
});
