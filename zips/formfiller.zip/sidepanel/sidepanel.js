(function() {
  const V = FormFillerPanelView;
  const $ = (id) => document.getElementById(id);
  const fieldsEl = $('fields');
  const statusEl = $('status');
  const activeEl = $('active');
  const buttons = () => Array.from(document.querySelectorAll('button'));

  // ?tabId=N pins the panel to one tab (used when it is opened as a page, e.g. in tests).
  const pinnedTab = Number(new URLSearchParams(location.search).get('tabId')) || null;
  let tabId = null;
  let frames = [];
  let refreshTimer = null;

  async function currentTabId() {
    if (pinnedTab) return pinnedTab;
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    return tab ? tab.id : null;
  }

  const send = (message) => chrome.runtime.sendMessage(message);
  const panel = (frameId, payload) => send({ action: 'RUN_PANEL', tabId, frameId, payload });

  function showStatus({ text, kind }) {
    statusEl.className = `status ${kind}`;
    statusEl.textContent = text;
  }

  function el(tag, props = {}, children = []) {
    const node = document.createElement(tag);
    Object.assign(node, props);
    for (const child of children) if (child) node.append(child);
    return node;
  }

  function keepEditor(frame, field) {
    if (field.mode !== 'keep' || field.isPassword || Array.isArray(field.keepValue)) return null;
    if (field.type === 'checkbox') {
      const box = el('input', { type: 'checkbox', checked: field.keepValue === true, title: 'Kept checked state' });
      box.addEventListener('change', () => panel(frame.frameId, { action: 'set_mode', ref: field.ref, mode: 'keep', value: box.checked }));
      return el('label', { className: 'sub' }, [box, ' keep checked']);
    }
    const input = el('input', {
      className: 'keep-input',
      value: field.keepValue === undefined || field.keepValue === null ? '' : String(field.keepValue),
      placeholder: 'Filled once, then kept',
      ariaLabel: `Kept value for ${field.label}`
    });
    input.addEventListener('change', () => panel(frame.frameId, { action: 'set_mode', ref: field.ref, mode: 'keep', value: input.value }));
    input.addEventListener('blur', () => scheduleRefresh());
    return input;
  }

  function row(frame, field) {
    const mode = el('button', { className: 'mode', textContent: V.icon(field.mode), title: V.title(field.mode) });
    mode.setAttribute('aria-label', `${field.label}: ${V.title(field.mode)}`);
    mode.dataset.ref = field.ref;
    mode.addEventListener('click', async () => {
      await panel(frame.frameId, { action: 'set_mode', ref: field.ref, mode: V.nextMode(field.mode, field.isPassword) });
      refresh();
    });
    const sub = [field.key || field.type, V.preview(field)].filter(Boolean).join(' · ');
    const meta = el('div', { className: 'meta' }, [
      el('div', { className: 'label', textContent: field.label, title: field.label }),
      el('div', { className: 'sub', textContent: sub }),
      keepEditor(frame, field)
    ]);
    const node = el('div', { className: `row mode-${field.mode || 'none'}` }, [mode, meta]);
    node.dataset.field = field.fieldKey;
    node.addEventListener('mouseenter', () => panel(frame.frameId, { action: 'highlight', ref: field.ref }));
    node.addEventListener('mouseleave', () => panel(frame.frameId, { action: 'highlight', ref: null }));
    return node;
  }

  function render(result) {
    const state = V.status(result);
    activeEl.className = `active ${state.kind}`;
    $('active-text').textContent = state.text;
    frames = (result && result.frames) || [];
    const usable = state.kind !== 'off';
    buttons().forEach((b) => { b.disabled = !usable && b.id !== 'btn-refresh'; });
    document.querySelectorAll('[data-preset]').forEach((b) => { b.disabled = frames.length === 0; });

    fieldsEl.replaceChildren();
    if (frames.length === 0) {
      fieldsEl.append(el('div', { className: 'empty', textContent: usable ? 'No fillable fields on this page.' : state.text }));
      return;
    }
    for (const frame of frames) {
      const heading = V.frameHeading(frame, frames.length);
      if (heading) fieldsEl.append(el('div', { className: 'frame-heading', textContent: heading }));
      const forms = new Set(frame.fields.map((f) => f.formKey));
      let lastForm = null;
      for (const field of frame.fields) {
        if (forms.size > 1 && field.formKey !== lastForm) {
          lastForm = field.formKey;
          fieldsEl.append(el('div', { className: 'form-heading', textContent: field.formKey === 'page' ? 'Outside a form' : `Form ${field.formKey.replace(/^\w+:/, '')}` }));
        }
        fieldsEl.append(row(frame, field));
      }
    }
  }

  async function refresh() {
    clearTimeout(refreshTimer);
    tabId = await currentTabId();
    if (tabId === null) {
      render(null);
      return;
    }
    let result;
    try {
      result = await send({ action: 'RUN_LIST_FIELDS', tabId });
    } catch (e) {
      result = { status: 'error', message: e.message };
    }
    render(result);
  }

  function scheduleRefresh() {
    clearTimeout(refreshTimer);
    refreshTimer = setTimeout(refresh, 150);
  }

  async function withBusy(work) {
    buttons().forEach((b) => { b.disabled = true; });
    try {
      return await work();
    } catch (e) {
      return { status: 'error', message: e.message };
    } finally {
      await refresh();
    }
  }

  async function fill(overwrite) {
    const { settings } = await chrome.storage.local.get('settings');
    const result = await withBusy(() => send({ action: 'RUN_FILL', tabId, overwrite }));
    showStatus(FormFillerPopupStatus.fillMessage(result, FormFillerSettings.withDefaults(settings)));
  }

  $('btn-fill').addEventListener('click', () => fill(false));
  $('btn-overwrite').addEventListener('click', () => fill(true));
  $('btn-undo').addEventListener('click', async () => {
    const result = await withBusy(() => send({ action: 'RUN_UNDO', tabId }));
    showStatus(FormFillerPopupStatus.undoMessage(result));
  });
  $('btn-refresh').addEventListener('click', refresh);

  document.querySelectorAll('[data-preset]').forEach((button) => {
    button.addEventListener('click', () => withBusy(async () => {
      const preset = button.dataset.preset;
      const payload = preset === 'reset' ? { action: 'reset_modes' } : { action: 'apply_preset', preset };
      await Promise.all(frames.map((f) => panel(f.frameId, payload)));
      showStatus({ text: preset === 'reset' ? '↺ All fields back to normal fill.' : `✅ Preset applied: ${button.textContent}`, kind: 'info' });
    }));
  });

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local' || !Object.keys(changes).some((k) => k.startsWith('ff_modes:'))) return;
    // Don't redraw under the cursor while a kept value is being typed.
    if (document.activeElement && document.activeElement.classList.contains('keep-input')) return;
    scheduleRefresh();
  });
  if (!pinnedTab) {
    chrome.tabs.onActivated.addListener(scheduleRefresh);
    chrome.tabs.onUpdated.addListener((id, info) => {
      if (id === tabId && info.status === 'complete') scheduleRefresh();
    });
  }

  refresh();
})();
