(function() {
  const CYCLE = [null, 'keep', 'change', 'skip'];
  // Password values are never stored, so password fields can't be kept.
  const PASSWORD_CYCLE = [null, 'change', 'skip'];
  const ICONS = { keep: '🔒', change: '🔄', skip: '🚫' };
  const TITLES = {
    keep: 'Keep: same value every fill',
    change: 'Change: new value every fill',
    skip: 'Skip: never filled'
  };
  const MAX_PREVIEW = 40;

  const icon = (mode) => ICONS[mode] || '○';
  const title = (mode) => `${TITLES[mode] || 'Normal fill'} (click to change)`;

  function nextMode(mode, isPassword = false) {
    const cycle = isPassword ? PASSWORD_CYCLE : CYCLE;
    return cycle[(cycle.indexOf(mode || null) + 1) % cycle.length];
  }

  function status(result) {
    if (!result || result.status === 'restricted') return { kind: 'off', text: 'Not available on this page' };
    if (result.status !== 'success') return { kind: 'off', text: result.message || 'No response from the page' };
    const count = result.frames.reduce((n, f) => n + f.fields.length, 0);
    if (count === 0) return { kind: 'idle', text: 'FormFiller active · no fields found' };
    return { kind: 'on', text: `FormFiller active · ${count} field${count === 1 ? '' : 's'}` };
  }

  function show(value) {
    if (value === true) return 'checked';
    if (value === false) return 'unchecked';
    if (Array.isArray(value)) return value.join(', ');
    return String(value === undefined || value === null ? '' : value);
  }

  function preview(field) {
    const locked = field.mode === 'keep' && field.keepValue !== undefined;
    if (locked && field.isPassword && field.keepValue) return '••••';
    return show(locked ? field.keepValue : field.value).slice(0, MAX_PREVIEW);
  }

  function frameHeading(frame, frameCount) {
    if (frameCount < 2) return '';
    let host = '';
    try {
      host = new URL(frame.url).host;
    } catch {
      host = frame.url || '';
    }
    return frame.title ? `${host} — ${frame.title}` : host;
  }

  globalThis.FormFillerPanelView = {
    icon,
    title,
    nextMode,
    status,
    preview,
    frameHeading
  };
})();
