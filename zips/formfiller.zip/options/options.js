document.addEventListener('DOMContentLoaded', () => {
  // Tab Switcher
  const navItems = document.querySelectorAll('.nav-item');
  const tabContents = document.querySelectorAll('.tab-content');

  function switchTab(tabId) {
    navItems.forEach(nav => {
      const selected = nav.getAttribute('data-tab') === tabId;
      nav.classList.toggle('active', selected);
      nav.setAttribute('aria-selected', String(selected));
    });
    
    tabContents.forEach(content => {
      if (content.id === `tab-${tabId}`) {
        content.classList.add('active');
      } else {
        content.classList.remove('active');
      }
    });
  }

  navItems.forEach(item => {
    item.addEventListener('click', () => {
      const tabId = item.getAttribute('data-tab');
      switchTab(tabId);
    });
  });

  // Settings elements
  const selectLocale = document.getElementById('setting-locale');
  const inputPasswordLength = document.getElementById('setting-password-length');
  const checkSkipHidden = document.getElementById('setting-skip-hidden');
  const checkOnlyEmpty = document.getElementById('setting-only-empty');
  const selectPasswordSource = document.getElementById('setting-password-source');
  const checkFillReadonly = document.getElementById('setting-fill-readonly');
  const checkDebug = document.getElementById('setting-debug');
  const testDataInputs = {
    dataSource: document.getElementById('setting-data-source'),
    emailStrategy: document.getElementById('setting-email-strategy'),
    baseEmail: document.getElementById('setting-base-email'),
    fixedEmail: document.getElementById('setting-fixed-email'),
    usernameStrategy: document.getElementById('setting-username-strategy'),
    cardGateway: document.getElementById('setting-card-gateway'),
    cardBrand: document.getElementById('setting-card-brand'),
    cardScenario: document.getElementById('setting-card-scenario')
  };
  const checkEdgeMode = document.getElementById('setting-edge-mode');
  
  // AI Settings
  const checkAiEnabled = document.getElementById('setting-ai-enabled');
  const inputAiKey = document.getElementById('setting-ai-key');
  const selectAiModel = document.getElementById('setting-ai-model');
  const inputAiModelCustom = document.getElementById('setting-ai-model-custom');
  const btnTestAiKey = document.getElementById('btn-test-ai-key');
  const aiKeyStatus = document.getElementById('ai-key-status');
  const CUSTOM_MODEL = '__custom';
  const MODEL_ID = /^[A-Za-z0-9][A-Za-z0-9._-]*$/;

  function hasModelOption(id) {
    return Array.from(selectAiModel.options).some((o) => o.value === id);
  }

  function addModelOption(id, label) {
    if (hasModelOption(id)) return;
    const opt = document.createElement('option');
    opt.value = id;
    opt.textContent = label || id;
    selectAiModel.insertBefore(opt, selectAiModel.querySelector(`option[value="${CUSTOM_MODEL}"]`));
  }

  function setAiModel(id) {
    const model = id || 'gemini-2.5-flash';
    if (hasModelOption(model) && model !== CUSTOM_MODEL) {
      selectAiModel.value = model;
      inputAiModelCustom.value = '';
    } else {
      selectAiModel.value = CUSTOM_MODEL;
      inputAiModelCustom.value = model;
    }
    inputAiModelCustom.style.display = selectAiModel.value === CUSTOM_MODEL ? 'block' : 'none';
  }

  function currentAiModel() {
    if (selectAiModel.value !== CUSTOM_MODEL) return selectAiModel.value;
    const custom = inputAiModelCustom.value.trim().replace(/^models\//, '');
    return MODEL_ID.test(custom) ? custom : 'gemini-2.5-flash';
  }

  selectAiModel.addEventListener('change', () => {
    inputAiModelCustom.style.display = selectAiModel.value === CUSTOM_MODEL ? 'block' : 'none';
    if (selectAiModel.value === CUSTOM_MODEL) inputAiModelCustom.focus();
  });

  // Checks the key with models.list and adds every model that supports generateContent.
  btnTestAiKey.addEventListener('click', async () => {
    const key = inputAiKey.value.trim();
    if (!key) {
      aiKeyStatus.textContent = 'Enter an API key first.';
      return;
    }
    btnTestAiKey.disabled = true;
    aiKeyStatus.textContent = 'Testing…';
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 15000);
    try {
      const response = await fetch('https://generativelanguage.googleapis.com/v1beta/models?pageSize=1000', {
        headers: { 'x-goog-api-key': key },
        signal: controller.signal
      });
      if (!response.ok) {
        let reason = `HTTP ${response.status}`;
        try {
          const body = await response.json();
          if (body && body.error && body.error.message) reason += `: ${body.error.message}`;
        } catch { /* keep the status only */ }
        aiKeyStatus.textContent = `Key check failed (${reason})`;
        return;
      }
      const data = await response.json();
      const models = (data.models || [])
        .filter((m) => (m.supportedGenerationMethods || []).includes('generateContent'))
        .map((m) => ({ id: String(m.name || '').replace(/^models\//, ''), label: m.displayName }))
        .filter((m) => MODEL_ID.test(m.id) && /gemini/i.test(m.id));
      const chosen = currentAiModel();
      models.forEach((m) => addModelOption(m.id, m.label ? `${m.label} (${m.id})` : m.id));
      setAiModel(chosen);
      const available = models.some((m) => m.id === chosen);
      aiKeyStatus.textContent = `Key works. ${models.length} Gemini models available.` +
        (available || models.length === 0 ? '' : ` Warning: "${chosen}" is not one of them.`);
    } catch (e) {
      aiKeyStatus.textContent = e.name === 'AbortError' ? 'Key check timed out.' : `Key check failed (${e.message})`;
    } finally {
      clearTimeout(timer);
      btnTestAiKey.disabled = false;
    }
  });
  
  // Custom Mappings Settings
  const rulesContainer = document.getElementById('rules-container');
  const btnAddRule = document.getElementById('btn-add-rule');
  
  // Form Element Control Settings
  const checkFillSelects = document.getElementById('setting-fill-selects');
  const selectSelectStrategy = document.getElementById('setting-select-strategy');
  const checkFillRadios = document.getElementById('setting-fill-radios');
  const selectRadioStrategy = document.getElementById('setting-radio-strategy');
  const checkFillCheckboxes = document.getElementById('setting-fill-checkboxes');
  const selectCheckboxStrategy = document.getElementById('setting-checkbox-strategy');
  const checkSmartTerms = document.getElementById('setting-smart-terms');

  // Profile Editor Elements
  const profileSelect = document.getElementById('profile-select');
  const profileFieldsContainer = document.getElementById('profile-fields-container');
  const btnResetProfiles = document.getElementById('btn-reset-profiles');

  // URL Rules Elements
  const capturedFormContainer = document.getElementById('captured-form-container');
  const noCapturedGuidance = document.getElementById('no-captured-guidance');
  const captureUrlPattern = document.getElementById('capture-url-pattern');
  const capturedFieldsList = document.getElementById('captured-fields-list');
  const btnSaveUrlRule = document.getElementById('btn-save-url-rule');
  const savedUrlRulesList = document.getElementById('saved-url-rules-list');

  const btnSave = document.getElementById('btn-save');
  const saveStatus = document.getElementById('save-status');

  let activeProfilesList = [];
  let savedUrlRules = [];
  let dirty = false;

  document.getElementById('app-version').textContent = chrome.runtime.getManifest().version;

  function flashStatus(text) {
    saveStatus.innerText = text;
    saveStatus.classList.add('show');
    setTimeout(() => {
      if (dirty) {
        saveStatus.innerText = 'Unsaved changes';
      } else {
        saveStatus.classList.remove('show');
      }
    }, 2500);
  }

  // Any edit outside the self-saving URL Rules tab marks the page dirty until Save.
  function markDirty(e) {
    if (e.target.closest('#tab-urlrules') || e.target.closest('[data-autosave]')) return;
    dirty = true;
    saveStatus.innerText = 'Unsaved changes';
    saveStatus.classList.add('show');
  }
  document.querySelector('.main-content').addEventListener('input', markDirty);
  document.querySelector('.main-content').addEventListener('change', markDirty);
  window.addEventListener('beforeunload', (e) => {
    if (!dirty) return undefined;
    e.preventDefault();
    e.returnValue = 'You have unsaved changes.';
    return e.returnValue;
  });

  const fieldKeys = [
    { key: "firstName", label: "First Name" },
    { key: "lastName", label: "Last Name" },
    { key: "fullName", label: "Full Name" },
    { key: "email", label: "Email Address" },
    { key: "phone", label: "Phone Number" },
    { key: "username", label: "Username" },
    { key: "password", label: "Password" },
    { key: "company", label: "Company Name" },
    { key: "addressLine1", label: "Address Line 1" },
    { key: "addressLine2", label: "Address Line 2" },
    { key: "city", label: "City / Suburb" },
    { key: "state", label: "State / Territory" },
    { key: "zipCode", label: "Postcode / ZIP" },
    { key: "country", label: "Country" },
    { key: "cardName", label: "Credit Cardholder Name" },
    { key: "cardNumber", label: "Card Number" },
    { key: "cardExpiry", label: "Card Expiry (MM/YY)" },
    { key: "cardCvv", label: "Card CVV" },
    { key: "website", label: "Website URL" },
    { key: "bio", label: "Biography Description" },
    { key: "birthDate", label: "Date of Birth (YYYY-MM-DD)" }
  ];

  // Load Saved Settings, Profiles, and URL Rules
  chrome.storage.local.get(['settings', 'customProfiles', 'urlRules', 'lastCapturedForm', 'activeSettingsTab'], (result) => {
    const settings = FormFillerSettings.withDefaults(result.settings);

    selectLocale.value = settings.locale;
    inputPasswordLength.value = settings.passwordLength;
    selectPasswordSource.value = settings.passwordSource;
    checkSkipHidden.checked = settings.skipHidden !== false;
    checkOnlyEmpty.checked = settings.onlyEmpty !== false;
    checkFillReadonly.checked = settings.fillReadonly === true;
    checkDebug.checked = settings.debug === true;
    for (const [key, el] of Object.entries(testDataInputs)) el.value = settings[key];
    checkEdgeMode.checked = settings.edgeMode === true;
    renderAutoSites(settings.autoFillSites);
    
    // AI Panel
    checkAiEnabled.checked = !!settings.aiEnabled;
    inputAiKey.value = settings.aiKey || '';
    setAiModel(settings.aiModel);

    // Element Control Panel
    checkFillSelects.checked = settings.fillSelects !== false;
    selectSelectStrategy.value = settings.selectStrategy || 'random';
    checkFillRadios.checked = settings.fillRadios !== false;
    selectRadioStrategy.value = settings.radioStrategy || 'random';
    checkFillCheckboxes.checked = settings.fillCheckboxes !== false;
    selectCheckboxStrategy.value = settings.checkboxStrategy || 'random';
    checkSmartTerms.checked = settings.smartTerms !== false;

    // Injected Custom Mapping Rules
    const mappings = settings.customMappings || [];
    if (mappings.length === 0) {
      addRuleRow('', '');
    } else {
      mappings.forEach(m => addRuleRow(m.key, m.value));
    }

    // Set up profiles in memory
    activeProfilesList = result.customProfiles && result.customProfiles.length > 0 ?
      structuredClone(result.customProfiles) :
      FormFillerProfiles.getDefault();

    populateProfilesSelector();

    // Set up URL Rules
    savedUrlRules = result.urlRules || [];
    renderSavedUrlRules();

    // Setup Captured Form if exists
    if (result.lastCapturedForm) {
      renderCapturedForm(result.lastCapturedForm);
    }

    // Tab redirection trigger
    if (result.activeSettingsTab) {
      switchTab(result.activeSettingsTab);
      // Purge the redirection flag
      chrome.storage.local.remove(['activeSettingsTab']);
    }
  });

  // The popup can toggle AI while this page is open; keep the checkbox in sync so Save keeps it.
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local' || !changes.settings || !changes.settings.newValue) return;
    checkAiEnabled.checked = !!changes.settings.newValue.aiEnabled;
    checkEdgeMode.checked = changes.settings.newValue.edgeMode === true;
    renderAutoSites(FormFillerSettings.withDefaults(changes.settings.newValue).autoFillSites);
  });

  // Auto-fill sites: saved straight to storage (merged), like URL rules.
  const autoSitesList = document.getElementById('auto-sites-list');
  const autoSiteInput = document.getElementById('auto-site-input');
  const autoSiteError = document.getElementById('auto-site-error');

  async function updateAutoSites(change) {
    const { settings } = await chrome.storage.local.get(['settings']);
    const current = settings || {};
    const sites = change(FormFillerSettings.withDefaults(current).autoFillSites);
    await chrome.storage.local.set({ settings: { ...current, autoFillSites: sites } });
    renderAutoSites(sites);
  }

  function renderAutoSites(sites) {
    autoSitesList.replaceChildren();
    if (!sites.length) {
      const empty = document.createElement('li');
      empty.className = 'auto-sites-empty';
      empty.textContent = 'No sites yet. Open a page with a form, click the FormFiller icon and turn on "Auto-fill this site on load".';
      autoSitesList.appendChild(empty);
      return;
    }
    for (const site of sites) {
      const item = document.createElement('li');
      const name = document.createElement('span');
      name.textContent = site === 'file://' ? 'Local files (file://)' : site;
      const remove = document.createElement('button');
      remove.type = 'button';
      remove.className = 'btn btn-danger btn-sm';
      remove.textContent = 'Remove';
      remove.setAttribute('aria-label', `Stop auto-filling ${site}`);
      remove.addEventListener('click', () => updateAutoSites((list) => list.filter((s) => s !== site)));
      item.append(name, remove);
      autoSitesList.appendChild(item);
    }
  }

  function addAutoSite() {
    const raw = autoSiteInput.value.trim();
    let origin = '';
    try {
      const url = new URL(/^[a-z]+:\/\//i.test(raw) ? raw : `https://${raw}`);
      if (url.protocol === 'http:' || url.protocol === 'https:') origin = url.origin;
    } catch {
      origin = '';
    }
    if (!raw || !origin) {
      autoSiteError.textContent = 'Enter a web address such as https://staging.example.com';
      return;
    }
    autoSiteError.textContent = '';
    autoSiteInput.value = '';
    updateAutoSites((list) => (list.includes(origin) ? list : [...list, origin]));
  }

  document.getElementById('btn-add-auto-site').addEventListener('click', addAutoSite);
  autoSiteInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      addAutoSite();
    }
  });

  // Saved Keep / Change / Skip modes (one storage entry per page).
  const MODES_PREFIX = 'ff_modes:';
  const modesSummary = document.getElementById('modes-summary');
  const btnClearModes = document.getElementById('btn-clear-modes');

  async function modePages() {
    const all = await chrome.storage.local.get(null);
    return Object.keys(all).filter((k) => k.startsWith(MODES_PREFIX));
  }

  async function renderModesSummary() {
    const pages = await modePages();
    modesSummary.textContent = pages.length === 0
      ? 'No field modes saved.'
      : `Field modes saved for ${pages.length} page${pages.length === 1 ? '' : 's'}.`;
    btnClearModes.disabled = pages.length === 0;
  }

  btnClearModes.addEventListener('click', async () => {
    const pages = await modePages();
    if (pages.length === 0 || !confirm(`Remove the Keep / Change / Skip modes saved for ${pages.length} page${pages.length === 1 ? '' : 's'}?`)) return;
    await chrome.storage.local.remove([...pages, 'ff_modes_index']);
    renderModesSummary();
  });
  renderModesSummary();

  // Populate profiles dropdown lists
  function populateProfilesSelector() {
    profileSelect.innerHTML = '';
    activeProfilesList.forEach((profile, idx) => {
      const opt = document.createElement('option');
      opt.value = idx;
      opt.text = `${profile.fullName} (${profile.countryCode})`;
      profileSelect.appendChild(opt);
    });

    if (activeProfilesList.length > 0) {
      renderProfileInputs(0);
    }
  }

  // Render individual inputs for profile editor
  function renderProfileInputs(idx) {
    const profile = activeProfilesList[idx];
    profileFieldsContainer.innerHTML = '';

    fieldKeys.forEach(field => {
      const row = document.createElement('div');
      row.className = 'form-row';

      const label = document.createElement('label');
      label.innerText = field.label;
      label.htmlFor = `field-${field.key}`;

      const input = document.createElement('input');
      input.type = 'text';
      input.id = `field-${field.key}`;
      input.value = profile[field.key] || '';
      
      input.addEventListener('input', (e) => {
        profile[field.key] = e.target.value;
        if (field.key === 'firstName' || field.key === 'lastName') {
          const fName = document.getElementById('field-firstName').value.trim();
          const lName = document.getElementById('field-lastName').value.trim();
          profile.fullName = `${fName} ${lName}`.trim();
          document.getElementById('field-fullName').value = profile.fullName;
          profileSelect.options[idx].text = `${profile.fullName} (${profile.countryCode})`;
        }
      });

      row.appendChild(label);
      row.appendChild(input);
      profileFieldsContainer.appendChild(row);
    });
  }

  profileSelect.addEventListener('change', (e) => {
    renderProfileInputs(parseInt(e.target.value, 10));
  });

  // Dynamic Rule Row Builder (Custom Mappings tab)
  function addRuleRow(keyVal = '', valueVal = '') {
    const row = document.createElement('div');
    row.className = 'rule-row';

    const inputKey = document.createElement('input');
    inputKey.type = 'text';
    inputKey.placeholder = 'e.g. billing_token';
    inputKey.value = keyVal;
    inputKey.className = 'rule-key';

    const inputValue = document.createElement('input');
    inputValue.type = 'text';
    inputValue.placeholder = 'e.g. TOK-12345';
    inputValue.value = valueVal;
    inputValue.className = 'rule-value';

    const btnDelete = document.createElement('button');
    btnDelete.className = 'btn btn-danger btn-sm';
    btnDelete.innerText = '✕';
    btnDelete.addEventListener('click', () => {
      row.remove();
    });

    row.appendChild(inputKey);
    row.appendChild(inputValue);
    row.appendChild(btnDelete);
    rulesContainer.appendChild(row);
  }

  btnAddRule.addEventListener('click', () => {
    addRuleRow('', '');
  });

  // Render Captured Form Layout
  function renderCapturedForm(formObj) {
    if (!formObj || !formObj.fields || formObj.fields.length === 0) {
      capturedFormContainer.style.display = 'none';
      noCapturedGuidance.style.display = 'block';
      return;
    }

    capturedFormContainer.style.display = 'block';
    noCapturedGuidance.style.display = 'none';
    captureUrlPattern.value = (formObj.url || '').split(/[?#]/)[0];
    capturedFieldsList.innerHTML = '';

    formObj.fields.forEach(field => {
      const row = document.createElement('div');
      row.className = 'captured-field-row';
      row.setAttribute('data-name', field.name);
      row.setAttribute('data-id', field.id);
      row.setAttribute('data-type', field.type);
      row.setAttribute('data-dom-id', field.domId || '');
      if (field.fieldValue !== undefined) row.setAttribute('data-field-value', field.fieldValue);

      const label = document.createElement('span');
      label.className = 'captured-field-label';
      label.innerText = field.label;
      label.title = `ID: ${field.id} | Name: ${field.name}`;

      const typeBadge = document.createElement('span');
      typeBadge.className = 'captured-field-type';
      typeBadge.innerText = field.type;

      // Rule Override Selector / Input
      let selector;
      if (field.type === 'checkbox') {
        selector = document.createElement('select');
        selector.className = 'rule-select-val';
        selector.innerHTML = `
          <option value="">[Use default strategy]</option>
          <option value="checked">Checked</option>
          <option value="unchecked">Unchecked</option>
        `;
      } else if (field.options && field.options.length > 0) {
        selector = document.createElement('select');
        selector.className = 'rule-select-val';
        selector.innerHTML = `<option value="">[Use default strategy / random]</option>`;
        field.options.forEach(opt => {
          const optVal = opt.value !== undefined ? opt.value : opt;
          const optTxt = opt.text !== undefined ? opt.text : opt;
          const option = document.createElement('option');
          option.value = optVal;
          option.innerText = optTxt;
          selector.appendChild(option);
        });
      } else {
        selector = document.createElement('input');
        selector.type = 'text';
        selector.placeholder = 'Value to inject...';
        selector.className = 'rule-input-val';
      }

      row.appendChild(label);
      row.appendChild(typeBadge);
      row.appendChild(selector);
      capturedFieldsList.appendChild(row);
    });
  }

  // Save rules for specific URL pattern
  btnSaveUrlRule.addEventListener('click', () => {
    const urlPattern = captureUrlPattern.value.trim();
    if (!urlPattern) {
      alert("Please specify a URL Pattern matching the page!");
      return;
    }

    const rules = [];
    const rows = capturedFieldsList.querySelectorAll('.captured-field-row');
    
    rows.forEach(row => {
      const name = row.getAttribute('data-name');
      const id = row.getAttribute('data-id');
      const type = row.getAttribute('data-type');
      const domId = row.getAttribute('data-dom-id') || '';
      const fieldValue = row.getAttribute('data-field-value');

      const selectVal = row.querySelector('.rule-select-val');
      const inputVal = row.querySelector('.rule-input-val');
      const val = selectVal ? selectVal.value : (inputVal ? inputVal.value.trim() : '');

      if (val !== '') {
        const entry = { name, id, domId, type, value: val };
        if (fieldValue !== null) entry.fieldValue = fieldValue;
        rules.push(entry);
      }
    });

    if (rules.length === 0) {
      alert("No rules were set. Configure at least one field to save!");
      return;
    }

    // Upsert the rule in the saved list
    const existingIdx = savedUrlRules.findIndex(r => r.urlPattern === urlPattern);
    if (existingIdx !== -1) {
      savedUrlRules[existingIdx].rules = rules;
    } else {
      savedUrlRules.push({ urlPattern, rules });
    }

    chrome.storage.local.set({ urlRules: savedUrlRules }, () => {
      renderSavedUrlRules();
      flashStatus('URL rule saved successfully!');
    });
  });

  // Render Saved URL rules list
  function renderSavedUrlRules() {
    savedUrlRulesList.innerHTML = '';
    
    if (savedUrlRules.length === 0) {
      savedUrlRulesList.innerHTML = `<p class="description" style="margin: 0; padding: 10px 0;">No URL rules configured yet.</p>`;
      return;
    }

    savedUrlRules.forEach((rule, idx) => {
      const item = document.createElement('div');
      item.className = 'url-rule-item';

      const info = document.createElement('div');
      info.className = 'url-rule-info';

      const title = document.createElement('span');
      title.className = 'url-rule-title';
      title.innerText = rule.urlPattern;

      const details = document.createElement('span');
      details.className = 'url-rule-details';
      details.innerText = `${rule.rules.length} custom field overrides configured`;

      info.appendChild(title);
      info.appendChild(details);

      const btnDelete = document.createElement('button');
      btnDelete.className = 'btn btn-danger btn-sm';
      btnDelete.innerText = 'Delete';
      btnDelete.addEventListener('click', () => {
        savedUrlRules.splice(idx, 1);
        chrome.storage.local.set({ urlRules: savedUrlRules }, () => {
          renderSavedUrlRules();
        });
      });

      item.appendChild(info);
      item.appendChild(btnDelete);
      savedUrlRulesList.appendChild(item);
    });
  }

  // Save Settings
  btnSave.addEventListener('click', () => {
    const mappings = [];
    const rows = rulesContainer.querySelectorAll('.rule-row');
    rows.forEach(row => {
      const key = row.querySelector('.rule-key').value.trim();
      const value = row.querySelector('.rule-value').value.trim();
      if (key) {
        mappings.push({ key, value });
      }
    });

    const passwordLength = FormFillerSettings.clampPasswordLength(inputPasswordLength.value);
    inputPasswordLength.value = passwordLength;

    const formValues = {
      locale: selectLocale.value,
      passwordLength,
      passwordSource: selectPasswordSource.value,
      skipHidden: checkSkipHidden.checked,
      onlyEmpty: checkOnlyEmpty.checked,
      fillReadonly: checkFillReadonly.checked,
      debug: checkDebug.checked,
      ...Object.fromEntries(Object.entries(testDataInputs).map(([key, el]) => [key, el.value.trim()])),
      edgeMode: checkEdgeMode.checked,
      
      // AI Configuration
      aiEnabled: checkAiEnabled.checked,
      aiKey: inputAiKey.value.trim(),
      aiModel: currentAiModel(),
      
      // Custom rules
      customMappings: mappings,

      // Form element strategies
      fillSelects: checkFillSelects.checked,
      selectStrategy: selectSelectStrategy.value,
      fillRadios: checkFillRadios.checked,
      radioStrategy: selectRadioStrategy.value,
      fillCheckboxes: checkFillCheckboxes.checked,
      checkboxStrategy: selectCheckboxStrategy.value,
      smartTerms: checkSmartTerms.checked
    };

    // Merge so keys written elsewhere (e.g. the popup's AI toggle) are kept.
    chrome.storage.local.get(['settings'], (stored) => {
      chrome.storage.local.set({
        settings: { ...(stored.settings || {}), ...formValues },
        customProfiles: activeProfilesList
      }, () => {
        dirty = false;
        flashStatus('Settings saved successfully!');
      });
    });
  });

  // Export / Import (settings, profiles, custom mappings and URL rules; never the API key)
  const BACKUP_FORMAT = 'universal-form-autofiller';
  const importFile = document.getElementById('import-file');

  document.getElementById('btn-export').addEventListener('click', () => {
    if (dirty) flashStatus('Exporting the last saved settings (unsaved changes are not included).');
    chrome.storage.local.get(['settings', 'customProfiles', 'urlRules'], (stored) => {
      const settings = { ...(stored.settings || {}) };
      delete settings.aiKey;
      const backup = {
        format: BACKUP_FORMAT,
        version: chrome.runtime.getManifest().version,
        exportedAt: new Date().toISOString(),
        settings,
        customProfiles: stored.customProfiles || [],
        urlRules: stored.urlRules || []
      };
      const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `formfiller-settings-${new Date().toISOString().slice(0, 10)}.json`;
      document.body.appendChild(link);
      link.click();
      link.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    });
  });

  // A copy with only the string (or number) fields, as strings.
  function stringFields(obj) {
    const out = {};
    for (const [k, v] of Object.entries(obj)) {
      if (typeof v === 'string') out[k] = v.slice(0, 5000);
      else if (typeof v === 'number' && Number.isFinite(v)) out[k] = String(v);
    }
    return out;
  }

  document.getElementById('btn-import').addEventListener('click', () => importFile.click());

  importFile.addEventListener('change', async () => {
    const file = importFile.files && importFile.files[0];
    importFile.value = '';
    if (!file) return;
    let backup;
    try {
      backup = JSON.parse(await file.text());
    } catch {
      flashStatus('Import failed: the file is not valid JSON.');
      return;
    }
    const isObject = (v) => v && typeof v === 'object' && !Array.isArray(v);
    if (!isObject(backup) || backup.format !== BACKUP_FORMAT || !isObject(backup.settings) ||
        (backup.customProfiles !== undefined && !Array.isArray(backup.customProfiles)) ||
        (backup.urlRules !== undefined && !Array.isArray(backup.urlRules))) {
      flashStatus('Import failed: this is not a FormFiller settings export.');
      return;
    }
    if (!confirm('Replace your current settings, profiles and URL rules with the imported file? Your API key is kept.')) return;
    chrome.storage.local.get(['settings'], (stored) => {
      // Shared files are untrusted: only known settings with the right types, and only
      // string fields in personas and rules, are taken.
      const imported = FormFillerSettings.sanitize(backup.settings);
      const current = stored.settings || {};
      const next = { settings: { ...imported, aiKey: current.aiKey || '' } };
      if (backup.customProfiles) {
        next.customProfiles = backup.customProfiles.filter((p) => isObject(p) && typeof p.fullName === 'string').map(stringFields);
      }
      if (backup.urlRules) {
        next.urlRules = backup.urlRules
          .filter((r) => isObject(r) && typeof r.urlPattern === 'string' && Array.isArray(r.rules))
          .map((r) => ({ urlPattern: r.urlPattern.slice(0, 2000), rules: r.rules.filter(isObject).map(stringFields) }));
      }
      chrome.storage.local.set(next, () => {
        dirty = false;
        location.reload();
      });
    });
  });

  // Reset Profiles to Defaults
  btnResetProfiles.addEventListener('click', () => {
    if (confirm('Are you sure you want to revert all personas back to default? All custom edits will be lost.')) {
      chrome.storage.local.remove(['customProfiles'], () => {
        activeProfilesList = FormFillerProfiles.getDefault();
        populateProfilesSelector();
        flashStatus('Profiles reset to default!');
      });
    }
  });
});
