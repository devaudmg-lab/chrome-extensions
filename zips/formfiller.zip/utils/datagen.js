(function() {
  // Generated identities and test data. Runs in the background (imported by fill_session.js)
  // and in the Options page; content scripts only see the finished persona.
  const LOWER = 'abcdefghijklmnopqrstuvwxyz';
  const UPPER = LOWER.toUpperCase();
  const BASE36 = '0123456789' + LOWER;

  function randInt(min, max) {
    const buf = new Uint32Array(1);
    crypto.getRandomValues(buf);
    return min + (buf[0] % (max - min + 1));
  }
  const pick = (list) => list[randInt(0, list.length - 1)];
  const pad2 = (n) => String(n).padStart(2, '0');

  function fromPattern(pattern) {
    return pattern.replace(/[#A]/g, (c) => (c === '#' ? String(randInt(0, 9)) : pick(UPPER)));
  }

  function randomTag(n) {
    let out = '';
    for (let i = 0; i < n; i++) out += pick(BASE36);
    return out;
  }

  // Strip accents and non-alphanumerics: "Müller" → "muller", "de Jong" → "dejong".
  function slug(s) {
    return String(s).normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '');
  }

  // ---- IBAN (ISO 13616 mod-97) ----
  function mod97(digits) {
    let rem = 0;
    for (const ch of digits) rem = (rem * 10 + Number(ch)) % 97;
    return rem;
  }
  const toDigits = (s) => s.toUpperCase().replace(/[A-Z]/g, (c) => String(c.charCodeAt(0) - 55));

  function ibanFor(countryCode, bban) {
    const check = 98 - mod97(toDigits(bban + countryCode + '00'));
    return countryCode + pad2(check) + bban;
  }

  function ibanValid(iban) {
    const s = String(iban || '').replace(/\s+/g, '').toUpperCase();
    if (!/^[A-Z]{2}\d{2}[A-Z0-9]{10,30}$/.test(s)) return false;
    return mod97(toDigits(s.slice(4) + s.slice(0, 4))) === 1;
  }

  // ---- Test cards ----
  // Published test numbers. Adyen/PayPal decline and 3DS cases depend on amount, holder
  // name or sandbox setup rather than the number, so they aren't listed.
  const CARD_TABLE = {
    stripe: [
      { number: '4242424242424242', brand: 'visa', scenario: 'success' },
      { number: '5555555555554444', brand: 'mastercard', scenario: 'success' },
      { number: '378282246310005', brand: 'amex', scenario: 'success' },
      { number: '6011111111111117', brand: 'discover', scenario: 'success' },
      { number: '4000000000000002', brand: 'visa', scenario: 'declined' },
      { number: '4000002500003155', brand: 'visa', scenario: '3ds' }
    ],
    braintree: [
      { number: '4111111111111111', brand: 'visa', scenario: 'success' },
      { number: '5555555555554444', brand: 'mastercard', scenario: 'success' },
      { number: '378282246310005', brand: 'amex', scenario: 'success' },
      { number: '6011111111111117', brand: 'discover', scenario: 'success' },
      { number: '4000111111111115', brand: 'visa', scenario: 'declined' },
      { number: '4000000000001091', brand: 'visa', scenario: '3ds' }
    ],
    adyen: [
      { number: '4111111145551142', brand: 'visa', scenario: 'success' },
      { number: '2222400070000005', brand: 'mastercard', scenario: 'success' },
      { number: '370000000000002', brand: 'amex', scenario: 'success' },
      { number: '6011601160116611', brand: 'discover', scenario: 'success' }
    ],
    paypal: [
      { number: '4111111111111111', brand: 'visa', scenario: 'success' },
      { number: '5555555555554444', brand: 'mastercard', scenario: 'success' },
      { number: '378282246310005', brand: 'amex', scenario: 'success' },
      { number: '6011111111111117', brand: 'discover', scenario: 'success' }
    ]
  };

  const cvvLength = (brand) => (brand === 'amex' ? 4 : 3);

  function brandOf(number) {
    const n = String(number);
    if (/^3[47]/.test(n)) return 'amex';
    if (/^(5[1-5]|2[2-7])/.test(n)) return 'mastercard';
    if (/^6(011|5)/.test(n)) return 'discover';
    return 'visa';
  }

  function cvvFor(brand) {
    return fromPattern('#'.repeat(cvvLength(brand)));
  }

  // null for the 'generic' gateway: the persona's own card is used.
  function pickCard({ gateway = 'generic', brand = 'any', scenario = 'success' } = {}) {
    const table = CARD_TABLE[gateway];
    if (!table) return null;
    let note;
    let list = table.filter((c) => c.scenario === scenario && (brand === 'any' || c.brand === brand));
    if (list.length === 0 && scenario !== 'success') {
      note = `${scenario === '3ds' ? '3-D Secure' : 'Declined'} test cards are not available for ${gateway}; used a success card.`;
      list = table.filter((c) => c.scenario === 'success' && (brand === 'any' || c.brand === brand));
    }
    if (list.length === 0) list = table.filter((c) => c.scenario === 'success');
    const card = pick(list);
    return { ...card, cvv: cvvFor(card.brand), ...(note ? { note } : {}) };
  }

  // ---- Identity numbers (test values only) ----
  function nationalIdFor(idKey) {
    switch (idKey) {
      case 'ssn': return `9${fromPattern('##')}-${fromPattern('##')}-${fromPattern('####')}`; // 9xx is never issued
      case 'pan': return `${fromPattern('AAA')}P${fromPattern('A####A')}`;
      case 'niNumber': return `QQ${fromPattern('######')}${pick(['A', 'B', 'C', 'D'])}`; // QQ is the official test prefix
      case 'sin': return '046 454 286'; // published test SIN (passes the Luhn check)
      case 'tfn': return '123 456 782'; // published test TFN (passes the checksum)
      default: return fromPattern('AA#######');
    }
  }

  const JOBS = [
    ['Software Engineer', 'Engineering', 'Software'],
    ['Product Manager', 'Product', 'Software'],
    ['QA Analyst', 'Quality Assurance', 'Software'],
    ['Data Scientist', 'Data', 'Analytics'],
    ['UX Designer', 'Design', 'Software'],
    ['Account Executive', 'Sales', 'SaaS'],
    ['Operations Manager', 'Operations', 'Logistics'],
    ['Financial Analyst', 'Finance', 'Financial Services']
  ];

  function ageOn(birthDate, now = new Date()) {
    const [y, m, d] = String(birthDate).split('-').map(Number);
    let age = now.getFullYear() - y;
    if (now.getMonth() + 1 < m || (now.getMonth() + 1 === m && now.getDate() < d)) age--;
    return age;
  }

  function genderOf(firstName) {
    for (const loc of Object.values(FormFillerLocales.LOCALES)) {
      if (loc.male.includes(firstName)) return 'male';
      if (loc.female.includes(firstName)) return 'female';
    }
    return '';
  }

  // Keys every persona gets, derived from what it already has. Existing keys win.
  function extendedFor(base, loc, now) {
    const [jobTitle, department, industry] = pick(JOBS);
    const gender = base.gender || genderOf(base.firstName);
    const handle = slug(base.firstName) + slug(base.lastName);
    const place = loc.places.find((p) => p.city === base.city && p.zip === base.zipCode) ||
      loc.places.find((p) => p.city === base.city) || null;
    return {
      middleName: pick([...loc.male, ...loc.female].filter((n) => n !== base.firstName)),
      gender,
      prefix: gender === 'male' ? 'Mr' : gender === 'female' ? 'Ms' : '',
      suffix: '',
      age: base.birthDate ? String(ageOn(base.birthDate, now)) : '',
      nationality: loc.nationality,
      maritalStatus: pick(['Single', 'Married']),
      jobTitle,
      department,
      industry,
      employeeCount: String(pick([12, 48, 150, 320, 1200])),
      linkedin: `https://www.linkedin.com/in/${handle}`,
      github: `https://github.com/${handle}`,
      phoneCountryCode: loc.phoneCode,
      dateFormat: loc.dateFormat,
      currency: loc.currency,
      nationalId: nationalIdFor(loc.idKey),
      passport: fromPattern('A########'),
      iban: ibanFor(loc.bankBban ? base.countryCode : 'GB', loc.bankBban || 'WEST12345698765432'),
      swift: loc.bankBban ? `${slug(base.lastName).slice(0, 4).toUpperCase().padEnd(4, 'X')}${base.countryCode}2X` : 'WESTGB2L',
      routingNumber: '011000015', // Federal Reserve test routing number
      accountNumber: fromPattern('##########'),
      vatNumber: fromPattern(loc.vat),
      amount: String(randInt(10, 500)) + '.00',
      latitude: place ? String(place.lat) : '',
      longitude: place ? String(place.lng) : '',
      landmark: `Near ${pick(['the central station', 'City Mall', 'the main post office', 'Central Park'])}`,
      poBox: `PO Box ${randInt(100, 9999)}`,
      deliveryInstructions: 'Leave the parcel at the front desk.'
    };
  }

  function localeOf(code) {
    return FormFillerLocales.LOCALES[code] || FormFillerLocales.LOCALES.US;
  }

  function extendPersona(persona, now = new Date()) {
    const loc = localeOf(persona.countryCode);
    const extra = extendedFor(persona, loc, now);
    const out = { ...persona };
    for (const [k, v] of Object.entries(extra)) if (out[k] === undefined || out[k] === '') out[k] = v;
    return out;
  }

  function birthDate(now) {
    const year = now.getFullYear() - randInt(22, 60);
    return `${year}-${pad2(randInt(1, 12))}-${pad2(randInt(1, 28))}`;
  }

  function generatePersona(code, { now = new Date() } = {}) {
    const loc = localeOf(code);
    const countryCode = FormFillerLocales.LOCALES[code] ? code : 'US';
    const gender = pick(['male', 'female']);
    const firstName = pick(loc[gender]);
    const lastName = pick(loc.last);
    const place = pick(loc.places);
    const company = pick(loc.companies);
    const companyDomain = `${slug(company.split(' ')[0])}.${loc.emailTld}`;
    const card = pickCard({ gateway: 'stripe', brand: 'any', scenario: 'success' });
    const persona = {
      firstName,
      lastName,
      fullName: `${firstName} ${lastName}`,
      gender,
      email: `${slug(firstName)}.${slug(lastName)}@${companyDomain}`,
      phone: fromPattern(loc.phone.replace('{area}', place.area)),
      username: `${slug(firstName).slice(0, 1)}${slug(lastName)}${randInt(10, 99)}`,
      password: '',
      company,
      companyDomain,
      addressLine1: `${randInt(1, 999)} ${pick(loc.streets)}`,
      addressLine2: pick(['', `Suite ${randInt(100, 900)}`, `Apt ${randInt(1, 40)}`]),
      city: place.city,
      state: place.state,
      stateCode: place.stateCode,
      zipCode: place.zip,
      country: loc.country,
      countryCode,
      cardName: `${firstName} ${lastName}`,
      cardNumber: card.number,
      cardExpiry: '',
      cardCvv: card.cvv,
      website: `https://${companyDomain}`,
      bio: `${pick(JOBS)[0]} based in ${place.city}.`,
      birthDate: birthDate(now),
      generated: true
    };
    return extendPersona(persona, now);
  }

  // ---- Email / username strategies ----
  function splitEmail(email) {
    const s = String(email || '');
    const at = s.lastIndexOf('@');
    return at > 0 ? [s.slice(0, at), s.slice(at + 1)] : ['test', 'example.com'];
  }

  function stamp(now) {
    return `${now.getUTCFullYear()}${pad2(now.getUTCMonth() + 1)}${pad2(now.getUTCDate())}` +
      `${pad2(now.getUTCHours())}${pad2(now.getUTCMinutes())}${pad2(now.getUTCSeconds())}`;
  }

  function emailFor(persona, settings, now = new Date()) {
    const [local, domain] = splitEmail(persona.email);
    switch (settings.emailStrategy) {
      case 'plus': {
        const [bl, bd] = settings.baseEmail ? splitEmail(settings.baseEmail) : [local, domain];
        return `${bl.split('+')[0]}+ff${now.getTime().toString(36)}${randomTag(2)}@${bd}`;
      }
      case 'timestamp': return `${local}.${stamp(now)}@${domain}`;
      case 'random': return `${local}.${randomTag(6)}@${domain}`;
      case 'fixed': return settings.fixedEmail || persona.email;
      default: return persona.email;
    }
  }

  function usernameFor(persona, settings, now = new Date()) {
    if (settings.usernameStrategy !== 'unique') return persona.username;
    return `${persona.username || 'user'}${now.getTime().toString(36).slice(-4)}${randomTag(4)}`;
  }

  globalThis.FormFillerDataGen = {
    CARD_TABLE,
    cvvLength,
    brandOf,
    cvvFor,
    pickCard,
    ibanFor,
    ibanValid,
    ageOn,
    extendPersona,
    generatePersona,
    emailFor,
    usernameFor
  };
})();
