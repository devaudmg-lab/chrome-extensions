(function() {
  const SETTINGS_VERSION = 2;

  const DEFAULTS = {
    locale: 'random',
    passwordLength: 16,
    passwordSource: 'profile',
    skipHidden: true,
    onlyEmpty: true,
    fillReadonly: false,
    debug: false,
    aiEnabled: false,
    aiKey: '',
    aiModel: 'gemini-2.5-flash',
    customMappings: [],
    fillSelects: true,
    selectStrategy: 'random',
    fillRadios: true,
    radioStrategy: 'random',
    fillCheckboxes: true,
    checkboxStrategy: 'random',
    smartTerms: true,
    // Test data (Project 3)
    dataSource: 'fixed',
    emailStrategy: 'persona',
    baseEmail: '',
    fixedEmail: '',
    usernameStrategy: 'persona',
    cardGateway: 'generic',
    cardBrand: 'any',
    cardScenario: 'success',
    edgeMode: false,
    // Persona chosen in the popup ("Fill as"); '' rotates through the personas.
    pinnedPersona: '',
    // Origins (https://example.com) filled automatically when a page finishes loading.
    autoFillSites: []
  };

  function withDefaults(stored) {
    return structuredClone({ ...DEFAULTS, ...(stored || {}) });
  }

  function clampPasswordLength(n) {
    const num = parseInt(n, 10);
    if (Number.isNaN(num)) return 16;
    return Math.min(128, Math.max(4, num));
  }

  globalThis.FormFillerSettings = {
    DEFAULTS,
    SETTINGS_VERSION,
    withDefaults,
    clampPasswordLength
  };
})();
