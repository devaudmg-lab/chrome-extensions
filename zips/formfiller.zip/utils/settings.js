(function() {
  const SETTINGS_VERSION = 2;

  const DEFAULTS = {
    locale: 'random',
    passwordLength: 16,
    passwordSource: 'profile',
    skipHidden: true,
    onlyEmpty: true,
    fillReadonly: false,
    debug: false,
    aiEnabled: false,
    aiKey: '',
    aiModel: 'gemini-2.5-flash',
    customMappings: [],
    fillSelects: true,
    selectStrategy: 'random',
    fillRadios: true,
    radioStrategy: 'random',
    fillCheckboxes: true,
    checkboxStrategy: 'random',
    smartTerms: true,
    // Test data (Project 3)
    dataSource: 'fixed',
    emailStrategy: 'persona',
    baseEmail: '',
    fixedEmail: '',
    usernameStrategy: 'persona',
    cardGateway: 'generic',
    cardBrand: 'any',
    cardScenario: 'success',
    edgeMode: false,
    // Persona chosen in the popup ("Fill as"); '' rotates through the personas.
    pinnedPersona: '',
    // Origins (https://example.com) filled automatically when a page finishes loading.
    autoFillSites: []
  };

  function withDefaults(stored) {
    return structuredClone({ ...DEFAULTS, ...(stored || {}) });
  }

  const ORIGIN = /^https?:\/\/[^/?#\s]+$/;
  const isObject = (v) => !!v && typeof v === 'object' && !Array.isArray(v);

  // Settings from an imported file: known keys with the right type only. The API key is
  // never taken from a file.
  function sanitize(input) {
    const out = {};
    if (!isObject(input)) return out;
    for (const [key, def] of Object.entries(DEFAULTS)) {
      if (key === 'aiKey' || !(key in input)) continue;
      const v = input[key];
      if (key === 'customMappings') {
        if (Array.isArray(v)) {
          out.customMappings = v.filter((m) => isObject(m) && typeof m.key === 'string')
            .map((m) => ({ key: m.key.slice(0, 200), value: String(m.value == null ? '' : m.value).slice(0, 2000) }));
        }
      } else if (key === 'autoFillSites') {
        if (Array.isArray(v)) out.autoFillSites = [...new Set(v.filter((x) => typeof x === 'string' && (x === 'file://' || ORIGIN.test(x))))];
      } else if (key === 'passwordLength') {
        out.passwordLength = clampPasswordLength(v);
      } else if (typeof v === typeof def) {
        out[key] = typeof v === 'string' ? v.slice(0, 500) : v;
      }
    }
    return out;
  }

  function clampPasswordLength(n) {
    const num = parseInt(n, 10);
    if (Number.isNaN(num)) return 16;
    return Math.min(128, Math.max(4, num));
  }

  globalThis.FormFillerSettings = {
    DEFAULTS,
    SETTINGS_VERSION,
    withDefaults,
    sanitize,
    clampPasswordLength
  };
})();
