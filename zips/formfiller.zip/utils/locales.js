(function() {
  // Per-locale data for generated personas. Patterns: '#' = digit, 'A' = capital letter.
  // Phone patterns produce national numbers, in fictional ranges where a country has one
  // (US/CA 555-01xx, GB 07700 900xxx, AU 0491 570xxx).
  // Places are real (city, state, postcode, area code, coordinates) so related fields agree.
  const LOCALES = {
    US: {
      country: 'United States', nationality: 'American', currency: 'USD', phoneCode: '+1', dateFormat: 'MM/DD/YYYY',
      phone: '{area}55501##', emailTld: 'com', idKey: 'ssn',
      male: ['James', 'Michael', 'David', 'Daniel', 'Ethan', 'Noah'],
      female: ['Emily', 'Olivia', 'Sarah', 'Ava', 'Madison', 'Grace'],
      last: ['Miller', 'Johnson', 'Carter', 'Brooks', 'Foster', 'Hayes'],
      places: [
        { city: 'San Francisco', state: 'California', stateCode: 'CA', zip: '94105', area: '415', lat: 37.7897, lng: -122.3942 },
        { city: 'Austin', state: 'Texas', stateCode: 'TX', zip: '78701', area: '512', lat: 30.2711, lng: -97.7437 },
        { city: 'Seattle', state: 'Washington', stateCode: 'WA', zip: '98101', area: '206', lat: 47.6101, lng: -122.3344 },
        { city: 'Chicago', state: 'Illinois', stateCode: 'IL', zip: '60601', area: '312', lat: 41.8858, lng: -87.6181 }
      ],
      streets: ['Market Street', 'Maple Avenue', 'Oak Lane', 'Pine Street', 'Cedar Drive'],
      companies: ['Apex Tech Solutions', 'Northwind Labs', 'Bluebird Analytics', 'Summit Cloud'],
      bankBban: null, vat: 'US##-#######'
    },
    CA: {
      country: 'Canada', nationality: 'Canadian', currency: 'CAD', phoneCode: '+1', dateFormat: 'YYYY-MM-DD',
      phone: '{area}55501##', emailTld: 'ca', idKey: 'sin',
      male: ['Liam', 'Lucas', 'Owen', 'Nathan', 'Félix', 'Logan'],
      female: ['Charlotte', 'Chloé', 'Emma', 'Léa', 'Hannah', 'Maya'],
      last: ['Tremblay', 'Roy', 'Gagnon', 'MacDonald', 'Wilson', 'Campbell'],
      places: [
        { city: 'Toronto', state: 'Ontario', stateCode: 'ON', zip: 'M5H 2N2', area: '416', lat: 43.6510, lng: -79.3810 },
        { city: 'Vancouver', state: 'British Columbia', stateCode: 'BC', zip: 'V6B 1A1', area: '604', lat: 49.2810, lng: -123.1150 },
        { city: 'Montréal', state: 'Quebec', stateCode: 'QC', zip: 'H3B 2Y5', area: '514', lat: 45.5010, lng: -73.5670 }
      ],
      streets: ['King Street West', 'Rue Sainte-Catherine', 'Granville Street', 'Bay Street'],
      companies: ['Maple Leaf Digital', 'Northern Lights Software', 'Laurentian Data'],
      bankBban: null, vat: '#########RT0001'
    },
    GB: {
      country: 'United Kingdom', nationality: 'British', currency: 'GBP', phoneCode: '+44', dateFormat: 'DD/MM/YYYY',
      phone: '07700900###', emailTld: 'co.uk', idKey: 'niNumber',
      male: ['Oliver', 'George', 'Harry', 'Jack', 'Thomas', 'William'],
      female: ['Amelia', 'Isla', 'Poppy', 'Sophie', 'Freya', 'Lily'],
      last: ['Smith', 'Taylor', 'Davies', 'Evans', 'Wright', 'Hughes'],
      places: [
        { city: 'London', state: 'Greater London', stateCode: 'LND', zip: 'EC1A 1BB', area: '020', lat: 51.5202, lng: -0.0979 },
        { city: 'Manchester', state: 'Greater Manchester', stateCode: 'MAN', zip: 'M1 1AE', area: '0161', lat: 53.4794, lng: -2.2453 },
        { city: 'Edinburgh', state: 'Scotland', stateCode: 'EDH', zip: 'EH1 1YZ', area: '0131', lat: 55.9500, lng: -3.1883 }
      ],
      streets: ['High Street', 'Station Road', 'Church Lane', 'Victoria Road'],
      companies: ['Thames Digital Ltd', 'Albion Software', 'Pennine Analytics'],
      bankBban: 'WEST12345698765432', vat: 'GB#########'
    },
    IN: {
      country: 'India', nationality: 'Indian', currency: 'INR', phoneCode: '+91', dateFormat: 'DD/MM/YYYY',
      phone: '98########', emailTld: 'in', idKey: 'pan',
      male: ['Aarav', 'Vihaan', 'Arjun', 'Rohan', 'Karan', 'Ishaan'],
      female: ['Ananya', 'Diya', 'Priya', 'Saanvi', 'Kavya', 'Meera'],
      last: ['Sharma', 'Patel', 'Iyer', 'Reddy', 'Gupta', 'Nair'],
      places: [
        { city: 'Bengaluru', state: 'Karnataka', stateCode: 'KA', zip: '560001', area: '80', lat: 12.9716, lng: 77.5946 },
        { city: 'Mumbai', state: 'Maharashtra', stateCode: 'MH', zip: '400001', area: '22', lat: 18.9388, lng: 72.8354 },
        { city: 'Hyderabad', state: 'Telangana', stateCode: 'TG', zip: '500001', area: '40', lat: 17.3850, lng: 78.4867 }
      ],
      streets: ['MG Road', 'Brigade Road', 'Linking Road', 'Banjara Hills Road'],
      companies: ['Infosphere Technologies', 'Sahyadri Software', 'Deccan Data Labs'],
      bankBban: null, vat: '29AAAAA####A1Z5'
    },
    AU: {
      country: 'Australia', nationality: 'Australian', currency: 'AUD', phoneCode: '+61', dateFormat: 'DD/MM/YYYY',
      phone: '0491570###', emailTld: 'com.au', idKey: 'tfn',
      male: ['Jack', 'Oliver', 'Cooper', 'Lachlan', 'Riley', 'Hudson'],
      female: ['Charlotte', 'Matilda', 'Zoe', 'Ruby', 'Sienna', 'Isla'],
      last: ['Murphy', 'Kelly', 'Bennett', 'Walsh', 'Ryan', 'Clarke'],
      places: [
        { city: 'Sydney', state: 'New South Wales', stateCode: 'NSW', zip: '2000', area: '02', lat: -33.8688, lng: 151.2093 },
        { city: 'Melbourne', state: 'Victoria', stateCode: 'VIC', zip: '3000', area: '03', lat: -37.8136, lng: 144.9631 },
        { city: 'Brisbane', state: 'Queensland', stateCode: 'QLD', zip: '4000', area: '07', lat: -27.4698, lng: 153.0251 }
      ],
      streets: ['George Street', 'Collins Street', 'Queen Street', 'Flinders Lane'],
      companies: ['Southern Cross Digital', 'Coral Reef Software', 'Outback Analytics'],
      bankBban: null, vat: '51824753556'
    },
    DE: {
      country: 'Germany', nationality: 'German', currency: 'EUR', phoneCode: '+49', dateFormat: 'DD.MM.YYYY',
      phone: '0151#######', emailTld: 'de', idKey: 'nationalId',
      male: ['Lukas', 'Leon', 'Finn', 'Jonas', 'Felix', 'Maximilian'],
      female: ['Mia', 'Hannah', 'Emma', 'Lea', 'Sophie', 'Lena'],
      last: ['Müller', 'Schmidt', 'Schneider', 'Fischer', 'Weber', 'Wagner'],
      places: [
        { city: 'Berlin', state: 'Berlin', stateCode: 'BE', zip: '10115', area: '030', lat: 52.5320, lng: 13.3849 },
        { city: 'München', state: 'Bayern', stateCode: 'BY', zip: '80331', area: '089', lat: 48.1351, lng: 11.5820 },
        { city: 'Hamburg', state: 'Hamburg', stateCode: 'HH', zip: '20095', area: '040', lat: 53.5511, lng: 9.9937 }
      ],
      streets: ['Hauptstraße', 'Bahnhofstraße', 'Gartenweg', 'Schillerstraße'],
      companies: ['Rheinwerk Digital GmbH', 'Alpen Software AG', 'Nordlicht Daten GmbH'],
      bankBban: '370400440532013000', vat: 'DE#########'
    },
    FR: {
      country: 'France', nationality: 'French', currency: 'EUR', phoneCode: '+33', dateFormat: 'DD/MM/YYYY',
      phone: '06########', emailTld: 'fr', idKey: 'nationalId',
      male: ['Gabriel', 'Louis', 'Raphaël', 'Jules', 'Hugo', 'Arthur'],
      female: ['Jade', 'Louise', 'Emma', 'Alice', 'Chloé', 'Léa'],
      last: ['Martin', 'Bernard', 'Dubois', 'Thomas', 'Robert', 'Moreau'],
      places: [
        { city: 'Paris', state: 'Île-de-France', stateCode: 'IDF', zip: '75001', area: '01', lat: 48.8606, lng: 2.3376 },
        { city: 'Lyon', state: 'Auvergne-Rhône-Alpes', stateCode: 'ARA', zip: '69001', area: '04', lat: 45.7676, lng: 4.8344 },
        { city: 'Bordeaux', state: 'Nouvelle-Aquitaine', stateCode: 'NAQ', zip: '33000', area: '05', lat: 44.8378, lng: -0.5792 }
      ],
      streets: ['Rue de la Paix', 'Avenue Victor Hugo', 'Rue du Moulin', 'Boulevard Saint-Michel'],
      companies: ['Lumière Numérique SAS', 'Seine Logiciels', 'Provence Data'],
      bankBban: '20041010050500013M02606', vat: 'FR###########'
    },
    ES: {
      country: 'Spain', nationality: 'Spanish', currency: 'EUR', phoneCode: '+34', dateFormat: 'DD/MM/YYYY',
      phone: '6########', emailTld: 'es', idKey: 'nationalId',
      male: ['Hugo', 'Mateo', 'Martín', 'Lucas', 'Leo', 'Daniel'],
      female: ['Lucía', 'Sofía', 'Martina', 'María', 'Julia', 'Paula'],
      last: ['García', 'Rodríguez', 'González', 'Fernández', 'López', 'Martínez'],
      places: [
        { city: 'Madrid', state: 'Comunidad de Madrid', stateCode: 'MD', zip: '28013', area: '91', lat: 40.4168, lng: -3.7038 },
        { city: 'Barcelona', state: 'Cataluña', stateCode: 'CT', zip: '08002', area: '93', lat: 41.3851, lng: 2.1734 },
        { city: 'Valencia', state: 'Comunidad Valenciana', stateCode: 'VC', zip: '46002', area: '96', lat: 39.4699, lng: -0.3763 }
      ],
      streets: ['Calle Mayor', 'Gran Vía', 'Calle de Alcalá', 'Paseo de Gracia'],
      companies: ['Ibérica Digital SL', 'Mediterráneo Software', 'Sol Datos SA'],
      bankBban: '21000418450200051332', vat: 'ESA########'
    },
    NL: {
      country: 'Netherlands', nationality: 'Dutch', currency: 'EUR', phoneCode: '+31', dateFormat: 'DD-MM-YYYY',
      phone: '06########', emailTld: 'nl', idKey: 'nationalId',
      male: ['Daan', 'Sem', 'Lucas', 'Levi', 'Finn', 'Bram'],
      female: ['Emma', 'Julia', 'Sophie', 'Tess', 'Zoë', 'Anna'],
      last: ['de Jong', 'Jansen', 'de Vries', 'Bakker', 'Visser', 'Smit'],
      places: [
        { city: 'Amsterdam', state: 'Noord-Holland', stateCode: 'NH', zip: '1012 AB', area: '020', lat: 52.3731, lng: 4.8926 },
        { city: 'Rotterdam', state: 'Zuid-Holland', stateCode: 'ZH', zip: '3011 AD', area: '010', lat: 51.9225, lng: 4.4792 },
        { city: 'Utrecht', state: 'Utrecht', stateCode: 'UT', zip: '3511 AB', area: '030', lat: 52.0907, lng: 5.1214 }
      ],
      streets: ['Kerkstraat', 'Dorpsstraat', 'Molenweg', 'Prinsengracht'],
      companies: ['Oranje Digitaal BV', 'Polder Software', 'Delta Data BV'],
      bankBban: 'ABNA0417164300', vat: 'NL#########B01'
    },
    BR: {
      country: 'Brazil', nationality: 'Brazilian', currency: 'BRL', phoneCode: '+55', dateFormat: 'DD/MM/YYYY',
      phone: '{area}9########', emailTld: 'com.br', idKey: 'nationalId',
      male: ['Miguel', 'Arthur', 'Heitor', 'Bernardo', 'Davi', 'Gabriel'],
      female: ['Helena', 'Alice', 'Laura', 'Manuela', 'Valentina', 'Sophia'],
      last: ['Silva', 'Santos', 'Oliveira', 'Souza', 'Lima', 'Pereira'],
      places: [
        { city: 'São Paulo', state: 'São Paulo', stateCode: 'SP', zip: '01310-100', area: '11', lat: -23.5614, lng: -46.6559 },
        { city: 'Rio de Janeiro', state: 'Rio de Janeiro', stateCode: 'RJ', zip: '20040-020', area: '21', lat: -22.9068, lng: -43.1729 },
        { city: 'Belo Horizonte', state: 'Minas Gerais', stateCode: 'MG', zip: '30130-010', area: '31', lat: -19.9167, lng: -43.9345 }
      ],
      streets: ['Avenida Paulista', 'Rua das Flores', 'Rua da Consolação', 'Avenida Atlântica'],
      companies: ['Verde Tecnologia Ltda', 'Amazônia Software', 'Carioca Dados'],
      bankBban: '00360305000010009795493C1', vat: '##.###.###/0001-##'
    },
    MX: {
      country: 'Mexico', nationality: 'Mexican', currency: 'MXN', phoneCode: '+52', dateFormat: 'DD/MM/YYYY',
      phone: '{area}########', emailTld: 'com.mx', idKey: 'nationalId',
      male: ['Santiago', 'Mateo', 'Sebastián', 'Diego', 'Emiliano', 'Leonardo'],
      female: ['Sofía', 'Valentina', 'Regina', 'Camila', 'Ximena', 'Renata'],
      last: ['Hernández', 'García', 'Martínez', 'López', 'González', 'Pérez'],
      places: [
        { city: 'Ciudad de México', state: 'Ciudad de México', stateCode: 'CMX', zip: '06000', area: '55', lat: 19.4326, lng: -99.1332 },
        { city: 'Guadalajara', state: 'Jalisco', stateCode: 'JAL', zip: '44100', area: '33', lat: 20.6767, lng: -103.3475 },
        { city: 'Monterrey', state: 'Nuevo León', stateCode: 'NLE', zip: '64000', area: '81', lat: 25.6866, lng: -100.3161 }
      ],
      streets: ['Avenida Reforma', 'Calle Madero', 'Avenida Juárez', 'Calle Hidalgo'],
      companies: ['Azteca Digital SA de CV', 'Maya Software', 'Pacífico Datos'],
      bankBban: null, vat: 'AAA######AA#'
    },
    JP: {
      country: 'Japan', nationality: 'Japanese', currency: 'JPY', phoneCode: '+81', dateFormat: 'YYYY/MM/DD',
      phone: '090########', emailTld: 'jp', idKey: 'nationalId',
      male: ['Haruto', 'Yuto', 'Sota', 'Riku', 'Hinata', 'Ren'],
      female: ['Yui', 'Hina', 'Aoi', 'Sakura', 'Mei', 'Rin'],
      last: ['Sato', 'Suzuki', 'Takahashi', 'Tanaka', 'Watanabe', 'Ito'],
      places: [
        { city: 'Tokyo', state: 'Tokyo', stateCode: '13', zip: '100-0005', area: '03', lat: 35.6812, lng: 139.7671 },
        { city: 'Osaka', state: 'Osaka', stateCode: '27', zip: '530-0001', area: '06', lat: 34.7025, lng: 135.4959 },
        { city: 'Kyoto', state: 'Kyoto', stateCode: '26', zip: '600-8216', area: '075', lat: 34.9858, lng: 135.7588 }
      ],
      streets: ['Marunouchi 1-chome', 'Umeda 3-chome', 'Shijo-dori', 'Ginza 4-chome'],
      companies: ['Sakura Systems KK', 'Fuji Data Co.', 'Kansai Software'],
      bankBban: null, vat: 'T#############'
    },
    SG: {
      country: 'Singapore', nationality: 'Singaporean', currency: 'SGD', phoneCode: '+65', dateFormat: 'DD/MM/YYYY',
      phone: '8#######', emailTld: 'sg', idKey: 'nationalId',
      male: ['Wei Jie', 'Jun Hao', 'Ethan', 'Ryan', 'Arjun', 'Hafiz'],
      female: ['Hui Min', 'Xin Yi', 'Chloe', 'Nurul', 'Priya', 'Rachel'],
      last: ['Tan', 'Lim', 'Lee', 'Ng', 'Wong', 'Goh'],
      places: [
        { city: 'Singapore', state: 'Central Region', stateCode: 'CR', zip: '018956', area: '6', lat: 1.2834, lng: 103.8607 },
        { city: 'Singapore', state: 'East Region', stateCode: 'ER', zip: '529510', area: '6', lat: 1.3526, lng: 103.9447 }
      ],
      streets: ['Orchard Road', 'Raffles Place', 'Tampines Avenue', 'Marina Boulevard'],
      companies: ['Lion City Digital Pte Ltd', 'Merlion Software', 'Straits Data'],
      bankBban: null, vat: 'M#-#######-#'
    },
    AE: {
      country: 'United Arab Emirates', nationality: 'Emirati', currency: 'AED', phoneCode: '+971', dateFormat: 'DD/MM/YYYY',
      phone: '050#######', emailTld: 'ae', idKey: 'nationalId',
      male: ['Mohammed', 'Ahmed', 'Omar', 'Khalid', 'Saeed', 'Rashid'],
      female: ['Fatima', 'Mariam', 'Aisha', 'Noura', 'Layla', 'Hessa'],
      last: ['Al Mansoori', 'Al Hashimi', 'Al Nuaimi', 'Al Suwaidi', 'Al Falasi', 'Al Ketbi'],
      places: [
        { city: 'Dubai', state: 'Dubai', stateCode: 'DU', zip: '00000', area: '04', lat: 25.2048, lng: 55.2708 },
        { city: 'Abu Dhabi', state: 'Abu Dhabi', stateCode: 'AZ', zip: '00000', area: '02', lat: 24.4539, lng: 54.3773 }
      ],
      streets: ['Sheikh Zayed Road', 'Al Wasl Road', 'Corniche Road', 'Hamdan Street'],
      companies: ['Falcon Digital LLC', 'Gulf Software FZ', 'Oasis Data'],
      bankBban: '0331234567890123456', vat: '100#########003'
    },
    ZA: {
      country: 'South Africa', nationality: 'South African', currency: 'ZAR', phoneCode: '+27', dateFormat: 'YYYY/MM/DD',
      phone: '082#######', emailTld: 'co.za', idKey: 'nationalId',
      male: ['Thabo', 'Sipho', 'Liam', 'Johan', 'Lwazi', 'Ethan'],
      female: ['Lerato', 'Naledi', 'Amahle', 'Emma', 'Zanele', 'Mia'],
      last: ['Nkosi', 'Dlamini', 'van der Merwe', 'Botha', 'Mokoena', 'Naidoo'],
      places: [
        { city: 'Cape Town', state: 'Western Cape', stateCode: 'WC', zip: '8001', area: '021', lat: -33.9249, lng: 18.4241 },
        { city: 'Johannesburg', state: 'Gauteng', stateCode: 'GP', zip: '2001', area: '011', lat: -26.2041, lng: 28.0473 },
        { city: 'Durban', state: 'KwaZulu-Natal', stateCode: 'KZN', zip: '4001', area: '031', lat: -29.8587, lng: 31.0218 }
      ],
      streets: ['Long Street', 'Main Road', 'Jan Smuts Avenue', 'Florida Road'],
      companies: ['Protea Digital (Pty) Ltd', 'Table Mountain Software', 'Highveld Data'],
      bankBban: null, vat: '4#########'
    }
  };

  globalThis.FormFillerLocales = {
    LOCALES,
    codes: () => Object.keys(LOCALES)
  };
})();
