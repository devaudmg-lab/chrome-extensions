document.addEventListener('DOMContentLoaded', () => {
  const btnFill = document.getElementById('btn-fill');
  const btnOverwrite = document.getElementById('btn-overwrite');
  const btnUndo = document.getElementById('btn-undo');
  const btnCapture = document.getElementById('btn-capture');
  const btnClear = document.getElementById('btn-clear');
  const btnOptions = document.getElementById('btn-options');
  const statusContainer = document.getElementById('status-container');
  const chkUseAi = document.getElementById('chk-use-ai');
  const actionButtons = [btnFill, btnOverwrite, btnUndo, btnClear, btnCapture];

  async function loadSettings() {
    const { settings } = await chrome.storage.local.get(['settings']);
    return FormFillerSettings.withDefaults(settings);
  }

  const chkEdge = document.getElementById('chk-edge');
  const chkAuto = document.getElementById('chk-auto');
  const autoSite = document.getElementById('auto-site');
  const selPersona = document.getElementById('sel-persona');

  // Merge into stored settings so other keys are never overwritten.
  async function saveSetting(update) {
    const { settings } = await chrome.storage.local.get(['settings']);
    const current = settings || {};
    const patch = typeof update === 'function' ? update(FormFillerSettings.withDefaults(current)) : update;
    await chrome.storage.local.set({ settings: { ...current, ...patch } });
  }

  // Same rule as the background (messaging.js siteOrigin): http(s) origin, or file://.
  function siteOf(url) {
    try {
      const { protocol, origin, hostname, pathname } = new URL(url);
      if (protocol === 'file:') return 'file://';
      if (protocol !== 'http:' && protocol !== 'https:') return '';
      if (hostname === 'chromewebstore.google.com' || (hostname === 'chrome.google.com' && pathname.startsWith('/webstore'))) return '';
      return origin;
    } catch {
      return '';
    }
  }

  let currentSite = '';

  async function loadProfiles() {
    const { customProfiles } = await chrome.storage.local.get(['customProfiles']);
    return Array.isArray(customProfiles) && customProfiles.length > 0 ? customProfiles : FormFillerProfiles.getDefault();
  }

  Promise.all([loadSettings(), loadProfiles(), chrome.tabs.query({ active: true, currentWindow: true })]).then(([settings, profiles, [tab]]) => {
    chkUseAi.checked = !!settings.aiEnabled;
    chkEdge.checked = settings.edgeMode === true;

    for (const p of profiles) {
      if (!p || !p.fullName) continue;
      const opt = document.createElement('option');
      opt.value = p.fullName;
      opt.textContent = `${p.fullName} (${p.countryCode || '?'})`;
      selPersona.appendChild(opt);
    }
    selPersona.value = profiles.some((p) => p && p.fullName === settings.pinnedPersona) ? settings.pinnedPersona : '';

    currentSite = siteOf(tab && tab.url);
    if (currentSite) {
      autoSite.textContent = currentSite === 'file://' ? 'Local files' : currentSite.replace(/^https?:\/\//, '');
      chkAuto.checked = settings.autoFillSites.includes(currentSite);
    } else {
      autoSite.textContent = 'Not available on this page';
      chkAuto.disabled = true;
      document.getElementById('auto-row').classList.add('disabled');
    }
  });

  chkEdge.addEventListener('change', () => saveSetting({ edgeMode: chkEdge.checked }));
  chkUseAi.addEventListener('change', () => saveSetting({ aiEnabled: chkUseAi.checked }));
  selPersona.addEventListener('change', () => saveSetting({ pinnedPersona: selPersona.value }));

  chkAuto.addEventListener('change', async () => {
    if (!currentSite) return;
    const on = chkAuto.checked;
    await saveSetting((s) => {
      const sites = s.autoFillSites.filter((x) => x !== currentSite);
      return { autoFillSites: on ? [...sites, currentSite] : sites };
    });
    showStatus(on
      ? { text: '⚡ This site will be filled every time a page loads (empty fields only, no AI).', kind: 'info' }
      : { text: 'Auto-fill turned off for this site.', kind: 'info' });
  });

  // First-run hint, dismissed for good with "Got it".
  const onboarding = document.getElementById('onboarding');
  chrome.storage.local.get(['ffOnboarded']).then(({ ffOnboarded }) => {
    if (!ffOnboarded) {
      onboarding.hidden = false;
      document.body.classList.add('first-run');
    }
  });
  document.getElementById('btn-onboarding-done').addEventListener('click', () => {
    onboarding.hidden = true;
    document.body.classList.remove('first-run');
    chrome.storage.local.set({ ffOnboarded: true });
  });

  // The real key bindings (the user may have changed them at chrome://extensions/shortcuts).
  const SHORTCUT_LABELS = { fill_current_form: 'Fill', fill_form_ai: 'AI fill', undo_fill: 'Undo', fill_form_overwrite: 'Overwrite' };
  chrome.commands.getAll().then((commands) => {
    const box = document.getElementById('shortcuts');
    const bound = commands.filter((c) => SHORTCUT_LABELS[c.name] && c.shortcut);
    const fill = commands.find((c) => c.name === 'fill_current_form');
    if (fill && fill.shortcut) document.getElementById('ob-fill-key').textContent = fill.shortcut;
    for (const c of bound) {
      const item = document.createElement('span');
      const key = document.createElement('kbd');
      key.textContent = c.shortcut;
      item.append(`${SHORTCUT_LABELS[c.name]} `, key);
      box.appendChild(item);
    }
    const edit = document.createElement('button');
    edit.className = 'btn-link btn-tiny';
    edit.type = 'button';
    edit.textContent = bound.length ? 'Change' : 'Set keyboard shortcuts';
    edit.addEventListener('click', () => chrome.tabs.create({ url: 'chrome://extensions/shortcuts' }));
    box.appendChild(edit);
  }).catch(() => {});

  function showStatus({ text, kind }) {
    statusContainer.className = `status-container ${kind}`;
    statusContainer.style.display = 'block';
    statusContainer.innerText = text;
  }

  function clearStatus() {
    statusContainer.className = 'status-container';
    statusContainer.style.display = 'none';
    statusContainer.innerText = '';
  }

  async function activeTabId() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    return tab && tab.id;
  }

  // Disables the buttons and shows a spinner on `button` while `work` runs.
  async function withBusy(button, busyLabel, work) {
    clearStatus();
    const original = button.innerHTML;
    actionButtons.forEach((b) => { b.disabled = true; });
    button.innerHTML = `<span class="spinner">⚙️</span> ${busyLabel}`;
    try {
      return await work();
    } catch (e) {
      return { status: 'error', message: e.message };
    } finally {
      actionButtons.forEach((b) => { b.disabled = false; });
      button.innerHTML = original;
    }
  }

  async function fill(button, overwrite) {
    const settings = await loadSettings();
    if (chkUseAi.checked && !settings.aiKey) {
      showStatus({ text: '❌ Gemini API Key is missing. Please configure it in Options.', kind: 'error' });
      return;
    }
    const result = await withBusy(button, 'Analyzing & Filling...', async () => chrome.runtime.sendMessage({
      action: 'RUN_FILL',
      tabId: await activeTabId(),
      overwrite,
      forceAi: chkUseAi.checked
    }));
    showStatus(FormFillerPopupStatus.fillMessage(result, settings));
  }

  btnFill.addEventListener('click', () => fill(btnFill, false));
  btnOverwrite.addEventListener('click', () => fill(btnOverwrite, true));

  btnUndo.addEventListener('click', async () => {
    const result = await withBusy(btnUndo, 'Undoing...', async () => chrome.runtime.sendMessage({
      action: 'RUN_UNDO',
      tabId: await activeTabId()
    }));
    showStatus(FormFillerPopupStatus.undoMessage(result));
  });

  btnClear.addEventListener('click', async () => {
    const result = await withBusy(btnClear, 'Clearing...', async () => chrome.runtime.sendMessage({
      action: 'RUN_CLEAR',
      tabId: await activeTabId()
    }));
    if (result && result.status === 'restricted') {
      showStatus(FormFillerPopupStatus.fillMessage(result, {}));
    } else if (result && result.status === 'cleared') {
      showStatus(result.count > 0
        ? { text: `🧹 Cleared ${result.count} fields.`, kind: 'success' }
        : { text: 'ℹ️ No fields to clear on this page.', kind: 'info' });
    } else {
      showStatus({ text: `❌ ${(result && result.message) || 'Could not clear the form.'}`, kind: 'error' });
    }
  });

  btnCapture.addEventListener('click', async () => {
    const result = await withBusy(btnCapture, 'Capturing...', async () => chrome.runtime.sendMessage({
      action: 'RUN_CAPTURE',
      tabId: await activeTabId()
    }));
    if (result && result.status === 'success' && result.data) {
      await chrome.storage.local.set({ lastCapturedForm: result.data, activeSettingsTab: 'urlrules' });
      chrome.runtime.openOptionsPage();
    } else if (result && result.status === 'restricted') {
      showStatus(FormFillerPopupStatus.fillMessage(result, {}));
    } else {
      showStatus({ text: `❌ ${(result && result.message) || 'Failed to capture form structure.'}`, kind: 'error' });
    }
  });

  btnOptions.addEventListener('click', () => chrome.runtime.openOptionsPage());

  // The tab is looked up now: sidePanel.open must be called inside the click's user
  // gesture, which an await before it would lose.
  let panelTabId = null;
  activeTabId().then((id) => { panelTabId = id; });
  document.getElementById('btn-panel').addEventListener('click', () => {
    if (panelTabId === null || !chrome.sidePanel) return;
    chrome.sidePanel.open({ tabId: panelTabId }).then(() => window.close()).catch((e) => {
      showStatus({ text: `❌ ${e.message}`, kind: 'error' });
    });
  });
});
