document.addEventListener('DOMContentLoaded', () => {
  const btnFill = document.getElementById('btn-fill');
  const btnOverwrite = document.getElementById('btn-overwrite');
  const btnUndo = document.getElementById('btn-undo');
  const btnCapture = document.getElementById('btn-capture');
  const btnOptions = document.getElementById('btn-options');
  const statusContainer = document.getElementById('status-container');
  const chkUseAi = document.getElementById('chk-use-ai');
  const actionButtons = [btnFill, btnOverwrite, btnUndo, btnCapture];

  async function loadSettings() {
    const { settings } = await chrome.storage.local.get(['settings']);
    return FormFillerSettings.withDefaults(settings);
  }

  const chkEdge = document.getElementById('chk-edge');
  loadSettings().then((settings) => {
    chkUseAi.checked = !!settings.aiEnabled;
    chkEdge.checked = settings.edgeMode === true;
  });

  chkEdge.addEventListener('change', async () => {
    const { settings } = await chrome.storage.local.get(['settings']);
    await chrome.storage.local.set({ settings: { ...(settings || {}), edgeMode: chkEdge.checked } });
  });

  // Merge into stored settings so other keys are never overwritten.
  chkUseAi.addEventListener('change', async () => {
    const { settings } = await chrome.storage.local.get(['settings']);
    await chrome.storage.local.set({ settings: { ...(settings || {}), aiEnabled: chkUseAi.checked } });
  });

  function showStatus({ text, kind }) {
    statusContainer.className = `status-container ${kind}`;
    statusContainer.style.display = 'block';
    statusContainer.innerText = text;
  }

  function clearStatus() {
    statusContainer.className = 'status-container';
    statusContainer.style.display = 'none';
    statusContainer.innerText = '';
  }

  async function activeTabId() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    return tab && tab.id;
  }

  // Disables the buttons and shows a spinner on `button` while `work` runs.
  async function withBusy(button, busyLabel, work) {
    clearStatus();
    const original = button.innerHTML;
    actionButtons.forEach((b) => { b.disabled = true; });
    button.innerHTML = `<span class="spinner">⚙️</span> ${busyLabel}`;
    try {
      return await work();
    } catch (e) {
      return { status: 'error', message: e.message };
    } finally {
      actionButtons.forEach((b) => { b.disabled = false; });
      button.innerHTML = original;
    }
  }

  async function fill(button, overwrite) {
    const settings = await loadSettings();
    if (chkUseAi.checked && !settings.aiKey) {
      showStatus({ text: '❌ Gemini API Key is missing. Please configure it in Options.', kind: 'error' });
      return;
    }
    const result = await withBusy(button, 'Analyzing & Filling...', async () => chrome.runtime.sendMessage({
      action: 'RUN_FILL',
      tabId: await activeTabId(),
      overwrite,
      forceAi: chkUseAi.checked
    }));
    showStatus(FormFillerPopupStatus.fillMessage(result, settings));
  }

  btnFill.addEventListener('click', () => fill(btnFill, false));
  btnOverwrite.addEventListener('click', () => fill(btnOverwrite, true));

  btnUndo.addEventListener('click', async () => {
    const result = await withBusy(btnUndo, 'Undoing...', async () => chrome.runtime.sendMessage({
      action: 'RUN_UNDO',
      tabId: await activeTabId()
    }));
    showStatus(FormFillerPopupStatus.undoMessage(result));
  });

  btnCapture.addEventListener('click', async () => {
    const result = await withBusy(btnCapture, 'Capturing...', async () => chrome.runtime.sendMessage({
      action: 'RUN_CAPTURE',
      tabId: await activeTabId()
    }));
    if (result && result.status === 'success' && result.data) {
      await chrome.storage.local.set({ lastCapturedForm: result.data, activeSettingsTab: 'urlrules' });
      chrome.runtime.openOptionsPage();
    } else if (result && result.status === 'restricted') {
      showStatus(FormFillerPopupStatus.fillMessage(result, {}));
    } else {
      showStatus({ text: `❌ ${(result && result.message) || 'Failed to capture form structure.'}`, kind: 'error' });
    }
  });

  btnOptions.addEventListener('click', () => chrome.runtime.openOptionsPage());

  // The tab is looked up now: sidePanel.open must be called inside the click's user
  // gesture, which an await before it would lose.
  let panelTabId = null;
  activeTabId().then((id) => { panelTabId = id; });
  document.getElementById('btn-panel').addEventListener('click', () => {
    if (panelTabId === null || !chrome.sidePanel) return;
    chrome.sidePanel.open({ tabId: panelTabId }).then(() => window.close()).catch((e) => {
      showStatus({ text: `❌ ${e.message}`, kind: 'error' });
    });
  });
});
