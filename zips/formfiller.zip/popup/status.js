(function() {
  const RESTRICTED = { text: "🚫 FormFiller can't run on this page.", kind: 'error' };

  function fillMessage(agg, settings) {
    if (!agg) return { text: '❌ Failed to autofill form.', kind: 'error' };
    switch (agg.status) {
      case 'success': {
        let text = `🪄 Filled ${agg.filled} fields using ${agg.engine === 'ai' ? 'Gemini AI' : agg.profileName}`;
        if (agg.edge) text += ' (🧪 edge-case data)';
        if (agg.invalid > 0) text += `\n⚠️ ${agg.invalid} fields still invalid`;
        if (agg.cardNote) text += `\nℹ️ ${agg.cardNote}`;
        if (agg.aiError) text += `\n⚠️ AI failed: ${agg.aiError}. Filled locally.`;
        return { text, kind: 'success' };
      }
      case 'no_fields':
        return settings && settings.onlyEmpty
          ? { text: 'ℹ️ No empty fields found. Use "Fill (overwrite)" to replace values.', kind: 'info' }
          : { text: 'ℹ️ No fillable fields found on this page.', kind: 'info' };
      case 'restricted':
        return RESTRICTED;
      default:
        return { text: `❌ ${agg.message || 'Failed to autofill form.'}`, kind: 'error' };
    }
  }

  function undoMessage(res) {
    if (res && res.status === 'undone') return { text: `↩️ Restored ${res.restored} fields.`, kind: 'success' };
    if (res && res.status === 'restricted') return RESTRICTED;
    return { text: 'ℹ️ Nothing to undo.', kind: 'info' };
  }

  globalThis.FormFillerPopupStatus = {
    fillMessage,
    undoMessage
  };
})();
