(function() {
  // The setter on the element's own prototype, bypassing instance overrides such as
  // React's value tracker. Uses the element's window so iframe elements work too.
  function nativeSetter(el, prop) {
    const win = (el.ownerDocument && el.ownerDocument.defaultView) || window;
    const ctor = el.tagName === 'TEXTAREA' ? win.HTMLTextAreaElement :
      el.tagName === 'SELECT' ? win.HTMLSelectElement :
      el.tagName === 'OPTION' ? win.HTMLOptionElement : win.HTMLInputElement;
    const desc = Object.getOwnPropertyDescriptor(ctor.prototype, prop);
    return desc && desc.set;
  }

  function fire(el, type, bubbles = true) {
    const win = (el.ownerDocument && el.ownerDocument.defaultView) || window;
    let event;
    if (type === 'focus' || type === 'blur' || type === 'focusin' || type === 'focusout') {
      event = new win.FocusEvent(type, { bubbles });
    } else if (type === 'input' && typeof win.InputEvent === 'function') {
      event = new win.InputEvent('input', { bubbles: true, inputType: 'insertText' });
    } else {
      event = new win.Event(type, { bubbles });
    }
    el.dispatchEvent(event);
  }

  function setValue(el, value) {
    fire(el, 'focus', false);
    fire(el, 'focusin');
    nativeSetter(el, 'value').call(el, String(value));
    fire(el, 'input');
    fire(el, 'change');
    fire(el, 'blur', false);
    fire(el, 'focusout');
  }

  function setChecked(el, checked) {
    if (el.checked === checked) return;
    // click() runs the page's own click handlers (React listens to click for checkboxes/radios).
    el.click();
    if (el.checked !== checked) {
      nativeSetter(el, 'checked').call(el, checked);
      fire(el, 'input');
      fire(el, 'change');
    }
  }

  globalThis.FormFillerEvents = {
    nativeSetter,
    setValue,
    setChecked
  };
})();
