(function() {
  // The setter on the element's own prototype, bypassing instance overrides such as
  // React's value tracker. Uses the element's window so iframe elements work too.
  function nativeSetter(el, prop) {
    const win = (el.ownerDocument && el.ownerDocument.defaultView) || window;
    const ctor = el.tagName === 'TEXTAREA' ? win.HTMLTextAreaElement :
      el.tagName === 'SELECT' ? win.HTMLSelectElement :
      el.tagName === 'OPTION' ? win.HTMLOptionElement : win.HTMLInputElement;
    const desc = Object.getOwnPropertyDescriptor(ctor.prototype, prop);
    return desc && desc.set;
  }

  function fire(el, type, bubbles = true) {
    const win = (el.ownerDocument && el.ownerDocument.defaultView) || window;
    let event;
    if (type === 'focus' || type === 'blur' || type === 'focusin' || type === 'focusout') {
      event = new win.FocusEvent(type, { bubbles });
    } else if (type === 'input' && typeof win.InputEvent === 'function') {
      event = new win.InputEvent('input', { bubbles: true, inputType: 'insertText' });
    } else {
      event = new win.Event(type, { bubbles });
    }
    el.dispatchEvent(event);
  }

  // Rich-text editors keep their own model of the text and only notice changes that come
  // through the browser's editing pipeline, so the text is typed with execCommand.
  function setEditableText(el, value) {
    const doc = el.ownerDocument;
    const win = doc.defaultView || window;
    const text = String(value);
    const squash = (s) => String(s || '').replace(/\s+/g, ' ').trim();
    let typed = false;
    // Focusing and typing scroll the editor into view; a fill shouldn't move the page.
    const { scrollX, scrollY } = win;
    try {
      el.focus({ preventScroll: true });
      win.getSelection().selectAllChildren(el);
      typed = text === '' ? doc.execCommand('delete', false) : doc.execCommand('insertText', false, text);
    } catch {
      typed = false;
    }
    if (!typed || squash(FormFillerDom.textOf(el)) !== squash(text)) {
      el.textContent = text;
      fire(el, 'input');
    }
    fire(el, 'change');
    if (typeof el.blur === 'function') el.blur();
    if (win.scrollX !== scrollX || win.scrollY !== scrollY) win.scrollTo(scrollX, scrollY);
  }

  function setValue(el, value) {
    if (FormFillerDom.isEditableRoot(el)) {
      setEditableText(el, value);
      return;
    }
    fire(el, 'focus', false);
    fire(el, 'focusin');
    nativeSetter(el, 'value').call(el, String(value));
    fire(el, 'input');
    fire(el, 'change');
    fire(el, 'blur', false);
    fire(el, 'focusout');
  }

  function setChecked(el, checked) {
    if (el.checked === checked) return;
    // click() runs the page's own click handlers (React listens to click for checkboxes/radios).
    el.click();
    if (el.checked !== checked) {
      nativeSetter(el, 'checked').call(el, checked);
      fire(el, 'input');
      fire(el, 'change');
    }
  }

  globalThis.FormFillerEvents = {
    nativeSetter,
    setValue,
    setChecked
  };
})();
