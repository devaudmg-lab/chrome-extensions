(function() {
  // Per-field fill modes chosen in the side panel or with Alt+L:
  //   keep   – the same value every fill (stored with the mode)
  //   change – a fresh value every fill (unique for email/username)
  //   skip   – never touched
  // Stored per page under FormFillerLocator.storageKey(site) as { [formKey]: { [fieldKey]: entry } }.
  const CYCLE = [undefined, 'keep', 'change', 'skip'];
  const UNIQUE_KEYS = new Set(['email', 'username']);
  // Passwords are never stored, so password fields only offer Change and Skip.
  const PASSWORD_CYCLE = [undefined, 'change', 'skip'];
  const MAX_VALUE_LENGTH = 2000;

  const isPassword = (field) => !!field && field.element.type === 'password';

  function nextMode(mode, field) {
    const cycle = isPassword(field) ? PASSWORD_CYCLE : CYCLE;
    return cycle[(cycle.indexOf(mode) + 1) % cycle.length];
  }

  function capped(value) {
    if (typeof value === 'string') return value.slice(0, MAX_VALUE_LENGTH);
    if (Array.isArray(value)) return value.slice(0, 100).map((v) => String(v).slice(0, MAX_VALUE_LENGTH));
    return value;
  }

  function readValue(field) {
    const el = field.element;
    if (el.type === 'checkbox') return el.checked;
    if (el.type === 'radio') {
      const on = FormFillerDom.radioGroup(el).find((r) => r.checked);
      return on ? on.value : '';
    }
    if (el.tagName === 'SELECT' && el.multiple) return Array.from(el.selectedOptions).map((o) => o.value);
    return el.value;
  }

  // A Keep entry locked while its field was empty has nothing to replay yet.
  function hasValue(entry) {
    const v = entry.value;
    return v !== undefined && v !== null && v !== '' && !(Array.isArray(v) && v.length === 0);
  }

  async function load(site = FormFillerLocator.siteKey()) {
    if (!site) return {};
    const key = FormFillerLocator.storageKey(site);
    const data = await chrome.storage.local.get(key);
    return data[key] || {};
  }

  async function save(map, site = FormFillerLocator.siteKey()) {
    if (!site) return;
    const key = FormFillerLocator.storageKey(site);
    const empty = Object.keys(map).length === 0;
    if (empty) await chrome.storage.local.remove(key);
    else await chrome.storage.local.set({ [key]: map });
  }

  function entryFor(map, field) {
    const { formKey, fieldKey } = FormFillerLocator.locate(field);
    return (map[formKey] || {})[fieldKey];
  }

  function labelOf(field) {
    return field.labelText || field.name || field.placeholder || field.type;
  }

  function put(map, field, mode, value) {
    if (mode === 'keep' && isPassword(field)) return undefined;
    const { formKey, fieldKey } = FormFillerLocator.locate(field);
    const form = map[formKey] || {};
    if (!mode) {
      delete form[fieldKey];
    } else {
      const entry = { mode, label: labelOf(field) };
      if (mode === 'keep') entry.value = capped(value !== undefined ? value : readValue(field));
      form[fieldKey] = entry;
    }
    if (Object.keys(form).length === 0) delete map[formKey];
    else map[formKey] = form;
    return form[fieldKey];
  }

  async function setMode(field, mode, value) {
    if (!FormFillerLocator.siteKey()) return undefined;
    const map = await load();
    const entry = put(map, field, mode, value);
    await save(map);
    return entry;
  }

  // One unique value per key and length limit for the whole fill, so "Email" and
  // "Confirm email" match. ctx.uniqueValues is shared with the observer's later passes.
  function changeValue(field, ctx) {
    const key = FormFillerAnalyzer.classify(field).key;
    if (!UNIQUE_KEYS.has(key)) return undefined;
    const max = field.element.maxLength > 0 ? field.element.maxLength : 0;
    const cacheKey = `${key}|${max}`;
    if (!ctx.uniqueValues.has(cacheKey)) {
      ctx.uniqueValues.set(cacheKey, key === 'email'
        ? FormFillerGen.uniqueEmail(ctx.persona.email, ctx.now, max)
        : FormFillerGen.uniqueUsername(ctx.persona.username, ctx.now, max));
    }
    return ctx.uniqueValues.get(cacheKey);
  }

  // Splits scanned fields by mode: skip fields are dropped, keep/change fields get their
  // values as overrides, and keep fields with nothing stored yet are returned so their
  // filled values can be recorded afterwards.
  function plan(fields, map, ctx) {
    const out = { fields: [], overrides: new Map(), pendingKeep: [], moded: new Set() };
    const now = ctx.now || new Date();
    const uniqueValues = ctx.uniqueValues || new Map();
    for (const field of fields) {
      const entry = entryFor(map, field);
      if (!entry || (entry.mode === 'keep' && isPassword(field))) {
        out.fields.push(field);
        continue;
      }
      if (entry.mode === 'skip') continue;
      out.fields.push(field);
      out.moded.add(field.element);
      if (entry.mode === 'keep') {
        if (hasValue(entry)) out.overrides.set(field.element, entry.value);
        else out.pendingKeep.push(field);
      } else if (entry.mode === 'change') {
        const value = changeValue(field, { ...ctx, now, uniqueValues });
        if (value !== undefined) out.overrides.set(field.element, value);
      }
    }
    return out;
  }

  async function recordKept(fields) {
    if (fields.length === 0) return;
    const map = await load();
    for (const field of fields) {
      // The mode may have been changed in the panel while the fill was running.
      const entry = entryFor(map, field);
      if (entry && entry.mode === 'keep' && !hasValue(entry)) put(map, field, 'keep', readValue(field));
    }
    await save(map);
  }

  const PRESETS = {
    email: (key) => (key === 'email' || key === 'username' ? 'change' : 'keep'),
    email_phone: (key) => (key === 'email' || key === 'username' || key === 'phone' ? 'change' : 'keep'),
    all_but_dob: (key) => (key === 'birthDate' ? 'keep' : 'change')
  };

  async function applyPreset(fields, preset) {
    const rule = PRESETS[preset];
    if (!rule) throw new Error('Unknown preset: ' + preset);
    const map = await load();
    for (const field of fields) {
      if (!isPassword(field)) put(map, field, rule(FormFillerAnalyzer.classify(field).key));
    }
    await save(map);
  }

  async function reset() {
    await save({});
  }

  globalThis.FormFillerModes = {
    MAX_VALUE_LENGTH,
    nextMode,
    readValue,
    load,
    entryFor,
    setMode,
    plan,
    recordKept,
    applyPreset,
    reset
  };
})();
