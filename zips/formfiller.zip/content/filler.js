(function() {
  const SMART_TERMS = /\b(agree|accept|terms|privacy|policy|consent|conditions)\b/i;
  const pad2 = (n) => String(n).padStart(2, '0');

  // Explicit value for a field, strongest first: field mode override (Keep/Change from the
  // side panel) → URL rule → custom mapping → AI.
  function explicitValue(field, ctx) {
    if (ctx.overrides && ctx.overrides.has(field.element)) return ctx.overrides.get(field.element);
    const rule = FormFillerMatch.ruleFor(field, ctx.ruleEntries);
    if (rule) return rule.value;
    const mapping = FormFillerMatch.customMappingFor(field, ctx.settings.customMappings);
    if (mapping) return mapping.value;
    const ai = ctx.aiValues && ctx.aiValues.get(field.element);
    if (typeof ai === 'string' && ai.trim() !== '') return ai;
    return undefined;
  }

  // Passwords regenerated for a field's length limits, keyed by session password + limits,
  // so a password field and its confirm field (same limits) still get the same value.
  const fittedPasswords = new Map();

  function passwordFor(el, sessionPassword) {
    const max = el.maxLength > 0 ? el.maxLength : 0;
    const min = el.minLength > 0 ? el.minLength : 0;
    if ((!max || sessionPassword.length <= max) && sessionPassword.length >= min) return sessionPassword;
    const key = `${sessionPassword}|${min}|${max}`;
    if (!fittedPasswords.has(key)) {
      const length = max ? Math.min(max, Math.max(min, 16)) : Math.max(min, 16);
      fittedPasswords.set(key, FormFillerGen.password({ length, minLength: min, maxLength: max || undefined }));
    }
    return fittedPasswords.get(key);
  }

  const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  const birthParts = (persona) => {
    const [year, month, day] = String(persona.birthDate || '').split('-');
    return { year, month, day };
  };

  function valueForKey(key, field, ctx) {
    const el = field.element;
    const { persona, expiry } = ctx;
    const now = ctx.now || new Date();
    const misc = FormFillerGen.miscValue(key, el, persona);
    if (misc !== undefined) return misc;
    switch (key) {
      case 'phone':
        return persona.phone ? FormFillerGen.phoneFor(persona, el) : undefined;
      case 'birthDay':
        return birthParts(persona).day;
      case 'birthMonth':
        return birthParts(persona).month;
      case 'birthYear':
        return birthParts(persona).year;
      case 'bio':
        return el.tagName === 'TEXTAREA' ? FormFillerGen.longText(FormFillerGen.textKind(field.labelText), persona, el) : persona.bio;
      case 'deliveryInstructions':
        return el.tagName === 'TEXTAREA' ? FormFillerGen.longText('notes', persona, el) : persona.deliveryInstructions;
      case 'password':
        return passwordFor(el, ctx.password);
      case 'cardExpiry':
        return el.type === 'month' ? FormFillerGen.monthValue(expiry.month, expiry.year) : `${expiry.month}/${expiry.year.slice(2)}`;
      case 'cardExpMonth':
        return expiry.month;
      case 'cardExpYear':
        return expiry.year;
      case 'birthDate': {
        if (!persona.birthDate) return undefined;
        if (el.type === 'date') return persona.birthDate;
        const format = FormFillerGen.detectDateFormat(field.placeholder) || persona.dateFormat;
        return format ? FormFillerGen.formatDate(persona.birthDate, format) : persona.birthDate;
      }
      case 'date_generic':
        return FormFillerGen.nearFutureDate(now);
      case 'number_fallback':
        return FormFillerGen.numberFor(el);
      default:
        if (key && persona[key] !== undefined && persona[key] !== '') return String(persona[key]);
        return undefined;
    }
  }

  function typeValue(field, ctx) {
    const el = field.element;
    const now = ctx.now || new Date();
    switch (el.type) {
      case 'number': return FormFillerGen.numberFor(el);
      case 'range': return FormFillerGen.rangeFor(el);
      case 'date': return FormFillerGen.nearFutureDate(now);
      case 'month': return FormFillerGen.isoDate(now).slice(0, 7);
      case 'week': return FormFillerGen.week(now);
      case 'time': return `${pad2(FormFillerGen.randInt(8, 18))}:${pad2(FormFillerGen.randInt(0, 3) * 15)}`;
      case 'datetime-local': return FormFillerGen.datetimeLocal(now);
      case 'color': return '#' + FormFillerGen.randInt(0, 0xffffff).toString(16).padStart(6, '0');
      default: return undefined;
    }
  }

  function fillCheckbox(field, ctx, override) {
    const el = field.element;
    const s = ctx.settings;
    if (s.fillCheckboxes === false) return null;
    let checked;
    if (override !== undefined) {
      if (FormFillerMatch.isTruthy(override)) checked = true;
      else if (FormFillerMatch.isFalsy(override)) checked = false;
      else {
        const want = FormFillerMatch.normalize(override);
        checked = want !== '' && (want === FormFillerMatch.normalize(el.value) || want === FormFillerMatch.normalize(field.labelText));
      }
    } else if (s.smartTerms !== false && SMART_TERMS.test(`${field.labelText} ${field.name}`)) {
      checked = true;
    } else if (s.checkboxStrategy === 'check_all') {
      checked = true;
    } else if (s.checkboxStrategy === 'uncheck_all') {
      checked = false;
    } else {
      checked = FormFillerGen.randInt(0, 1) === 1;
    }
    FormFillerEvents.setChecked(el, checked);
    return el;
  }

  function fillRadioGroup(field, ctx, override, fieldByElement) {
    if (ctx.settings.fillRadios === false) return null;
    const group = FormFillerDom.radioGroup(field.element).filter((r) => !r.disabled);
    if (group.length === 0) return null;
    const label = (r) => (fieldByElement.get(r) || {}).labelText || r.value;
    const options = group.map((r) => ({ value: r.value, text: label(r), el: r }));

    let target = null;
    const exact = override !== undefined ? group.find((r) => r.value === String(override)) : undefined;
    if (exact) {
      target = exact;
    } else if (override !== undefined) {
      if (FormFillerMatch.isTruthy(override)) target = field.element;
      else if (FormFillerMatch.isFalsy(override)) return null;
      else target = (FormFillerMatch.bestOption(options, override) || {}).el || null;
    } else if (ctx.aiValues && ctx.aiValues.size > 0) {
      target = group.find((r) => FormFillerMatch.isTruthy(ctx.aiValues.get(r))) || null;
      if (!target) {
        const named = group.map((r) => ctx.aiValues.get(r)).find((v) => v && !FormFillerMatch.isFalsy(v));
        if (named) target = (FormFillerMatch.bestOption(options, named) || {}).el || null;
      }
    }
    // A persona value for the group's key (gender, marital status, …) picks the matching option.
    if (!target && override === undefined) {
      const wanted = selectCandidates(FormFillerAnalyzer.classify(field).key, ctx);
      if (wanted.length > 0) target = (FormFillerMatch.bestOption(options, wanted) || {}).el || null;
    }
    if (!target) {
      target = ctx.settings.radioStrategy === 'first' ? group[0] : group[FormFillerGen.randInt(0, group.length - 1)];
    }
    FormFillerEvents.setChecked(target, true);
    return target;
  }

  function selectCandidates(key, ctx) {
    const { persona, expiry } = ctx;
    switch (key) {
      case 'country': return [persona.country, persona.countryCode];
      case 'state': return [persona.state, persona.stateCode];
      case 'cardExpMonth': return [expiry.month, String(+expiry.month)];
      case 'cardExpYear': return [expiry.year, expiry.year.slice(2)];
      case 'birthDay': { const { day } = birthParts(persona); return day ? [day, String(+day)] : []; }
      case 'birthMonth': {
        const { month } = birthParts(persona);
        return month ? [month, String(+month), MONTHS[+month - 1], MONTHS[+month - 1].slice(0, 3)] : [];
      }
      case 'birthYear': return [birthParts(persona).year].filter(Boolean);
      case 'phoneCountryCode': return [persona.phoneCountryCode, persona.countryCode, persona.country].filter(Boolean);
      default: return persona[key] !== undefined && persona[key] !== '' ? [String(persona[key])] : [];
    }
  }

  // Dial-code lists repeat codes (+1 is the US, Canada and a dozen islands), so a plain
  // "text includes +1" match lands on the wrong country. Exact matches first, then the
  // persona's country name, then the code as a whole number.
  function dialCodeOption(options, persona) {
    const norm = FormFillerMatch.normalize;
    const exact = [persona.countryCode, persona.country, persona.phoneCountryCode].filter(Boolean).map(norm);
    const byExact = options.find((o) => exact.includes(norm(o.value)) || exact.includes(norm(o.text)));
    if (byExact) return byExact;
    const country = norm(persona.country);
    const byName = country && options.find((o) => norm(o.text).startsWith(country));
    if (byName) return byName;
    const digits = String(persona.phoneCountryCode || '').replace(/\D/g, '');
    if (!digits) return null;
    const code = new RegExp('(^|[^\\d])' + digits + '(?!\\d)');
    return options.find((o) => code.test(o.value) || code.test(o.text)) || null;
  }

  function fillSelect(field, ctx, override) {
    const el = field.element;
    const s = ctx.settings;
    if (s.fillSelects === false) return null;
    const options = Array.from(el.options).filter((o) => !o.disabled);
    if (options.length === 0) return null;
    const real = options.filter((o) => o.value !== '');
    const pool = real.length > 0 ? real : options;

    if (el.multiple && Array.isArray(override)) {
      const want = new Set(override.map(String));
      const setSelected = FormFillerEvents.nativeSetter(options[0], 'selected');
      Array.from(el.options).forEach((o) => setSelected.call(o, want.has(o.value)));
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      return el;
    }

    if (el.multiple) {
      const count = Math.min(pool.length, FormFillerGen.randInt(1, 2));
      const chosen = new Set();
      while (chosen.size < count) chosen.add(pool[FormFillerGen.randInt(0, pool.length - 1)]);
      const setSelected = FormFillerEvents.nativeSetter(options[0], 'selected');
      Array.from(el.options).forEach((o) => setSelected.call(o, chosen.has(o)));
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      return el;
    }

    const key = FormFillerAnalyzer.classify(field).key;
    const wanted = override !== undefined ? override : selectCandidates(key, ctx);
    const match = override === undefined && key === 'phoneCountryCode'
      ? dialCodeOption(options, ctx.persona)
      : FormFillerMatch.bestOption(options, wanted);
    let value;
    if (match) value = match.value;
    else if (s.selectStrategy === 'first') value = pool[0].value;
    else if (s.selectStrategy === 'last') value = pool[pool.length - 1].value;
    else value = pool[FormFillerGen.randInt(0, pool.length - 1)].value;
    FormFillerEvents.setValue(el, value);
    return el;
  }

  function fillText(field, ctx, override) {
    const key = FormFillerAnalyzer.classify(field).key;
    let value = override;
    // Edge-case mode replaces everything except Keep/Change values from the side panel.
    if (ctx.edge && !(ctx.overrides && ctx.overrides.has(field.element))) value = FormFillerGen.edgeValue(field.element);
    if (value === undefined) value = valueForKey(key, field, ctx);
    if (value === undefined && field.element.tagName === 'TEXTAREA') {
      value = FormFillerGen.longText(FormFillerGen.textKind(field.labelText), ctx.persona, field.element);
    }
    if (value === undefined) value = typeValue(field, ctx);
    if (value === undefined) value = FormFillerGen.fallbackText(field);
    const el = field.element;
    const finalValue = FormFillerGen.fitLength(value, el);
    FormFillerEvents.setValue(el, finalValue);
    // The browser sanitizes values a typed input can't hold (e.g. text in type=number) to "".
    if (el.value === '' && finalValue !== '') {
      const typed = typeValue(field, ctx);
      if (typed !== undefined) FormFillerEvents.setValue(el, typed);
    }
    return el;
  }

  function fillAll(fields, ctx) {
    const result = { filled: 0, invalid: 0, errors: [], touched: [] };
    const fieldByElement = new Map(fields.map((f) => [f.element, f]));
    const doneGroups = new Set();

    for (const field of fields) {
      const el = field.element;
      try {
        const override = explicitValue(field, ctx);
        let target;
        if (el.type === 'checkbox') {
          target = fillCheckbox(field, ctx, override);
        } else if (el.type === 'radio') {
          const key = FormFillerDom.groupKey(el);
          if (doneGroups.has(key)) continue;
          doneGroups.add(key);
          target = fillRadioGroup(field, ctx, override, fieldByElement);
        } else if (el.tagName === 'SELECT') {
          target = fillSelect(field, ctx, override);
        } else {
          target = fillText(field, ctx, override);
        }
        if (!target) continue;
        result.filled++;
        result.touched.push(target);
        if (typeof target.checkValidity === 'function' && !target.checkValidity()) result.invalid++;
      } catch (e) {
        result.errors.push(`${field.name || field.id || field.type}: ${e.message}`);
      }
    }
    return result;
  }

  function clearAll(fields) {
    let count = 0;
    for (const field of fields) {
      const el = field.element;
      try {
        if (el.type === 'checkbox' || el.type === 'radio') FormFillerEvents.setChecked(el, false);
        else if (el.tagName === 'SELECT') FormFillerEvents.setValue(el, el.options.length ? el.options[0].value : '');
        else FormFillerEvents.setValue(el, '');
        count++;
      } catch (e) {
        FormFillerDom.log('clear failed', field.name, e.message);
      }
    }
    return count;
  }

  globalThis.FormFillerFiller = {
    fillAll,
    clearAll,
    valueForKey
  };
})();
