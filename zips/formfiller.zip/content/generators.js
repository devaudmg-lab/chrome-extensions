(function() {
  const LOWER = 'abcdefghijklmnopqrstuvwxyz';
  const UPPER = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  const DIGITS = '0123456789';
  const SYMBOLS = '!@#$%&*_-';
  const pad2 = (n) => String(n).padStart(2, '0');

  // Uniform integer in [min, max] (inclusive) from the crypto RNG.
  function randInt(min, max) {
    const range = max - min + 1;
    const buf = new Uint32Array(1);
    crypto.getRandomValues(buf);
    return min + (buf[0] % range);
  }

  function pick(str) {
    return str.charAt(randInt(0, str.length - 1));
  }

  function luhnValid(num) {
    const digits = String(num).replace(/\D/g, '');
    if (!digits) return false;
    let sum = 0;
    let double = false;
    for (let i = digits.length - 1; i >= 0; i--) {
      let d = +digits[i];
      if (double) {
        d *= 2;
        if (d > 9) d -= 9;
      }
      sum += d;
      double = !double;
    }
    return sum % 10 === 0;
  }

  function password({ length = 16, minLength, maxLength } = {}) {
    const lower = Math.max(minLength || 0, 4);
    const upper = maxLength && maxLength > 0 ? maxLength : 128;
    const len = Math.max(lower, Math.min(upper, length));
    const all = LOWER + UPPER + DIGITS + SYMBOLS;
    const chars = [pick(LOWER), pick(UPPER), pick(DIGITS), pick(SYMBOLS)];
    while (chars.length < len) chars.push(pick(all));
    chars.length = len;
    for (let i = chars.length - 1; i > 0; i--) {
      const j = randInt(0, i);
      [chars[i], chars[j]] = [chars[j], chars[i]];
    }
    return chars.join('');
  }

  function decimalsOf(n) {
    const s = String(n);
    const i = s.indexOf('.');
    return i === -1 ? 0 : s.length - i - 1;
  }

  // A random valid value: within [min, max] and on the browser's step grid, whose base is
  // the min attribute (or 0 when there is none).
  function steppedValue(el, defMin, defMax) {
    const minAttr = parseFloat(el.getAttribute('min'));
    const maxAttr = parseFloat(el.getAttribute('max'));
    let step = parseFloat(el.getAttribute('step'));
    if (!Number.isFinite(step) || step <= 0) step = 1;
    const base = Number.isFinite(minAttr) ? minAttr : 0;

    let min = Number.isFinite(minAttr) ? minAttr : Number.isFinite(maxAttr) ? Math.min(defMin, maxAttr - 99) : defMin;
    let max = Number.isFinite(maxAttr) ? maxAttr : defMax === undefined ? min + 99 : Math.max(defMax, min);
    if (max < min) [min, max] = [max, min];

    const firstK = Math.ceil((min - base) / step - 1e-9);
    const lastK = Math.floor((max - base) / step + 1e-9);
    const k = lastK >= firstK ? randInt(firstK, lastK) : firstK;
    const value = base + k * step;
    return value.toFixed(Math.max(decimalsOf(step), decimalsOf(base)));
  }

  function numberFor(el) {
    return steppedValue(el, 1);
  }

  function rangeFor(el) {
    return steppedValue(el, 0, 100);
  }

  function isoDate(d) {
    return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
  }

  // A date format written in a placeholder ("dd/mm/yyyy", "MM-DD-YYYY", "DD.MM.YYYY"),
  // returned upper-case with its own separator, or null.
  function detectDateFormat(placeholder) {
    const m = /(DD|MM|YYYY)([/.-])(DD|MM)\2(DD|YYYY)/.exec(String(placeholder || '').toUpperCase());
    if (!m) return null;
    const parts = [m[1], m[3], m[4]];
    if (new Set(parts).size !== 3 || !parts.includes('YYYY')) return null;
    return m[0];
  }

  function formatDate(iso, format) {
    const [y, m, d] = String(iso).split('-');
    if (!format) return `${y}-${m}-${d}`;
    return format.replace('YYYY', y).replace('MM', m).replace('DD', d);
  }

  function futureExpiry(now = new Date()) {
    const total = now.getFullYear() * 12 + now.getMonth() + randInt(24, 60);
    return { month: pad2((total % 12) + 1), year: String(Math.floor(total / 12)) };
  }

  function expiryIsFuture(mmYY, now = new Date()) {
    const m = /^(\d{2})\s*\/\s*(\d{2}|\d{4})$/.exec(String(mmYY || '').trim());
    if (!m) return false;
    const month = +m[1];
    const year = m[2].length === 2 ? 2000 + +m[2] : +m[2];
    if (month < 1 || month > 12) return false;
    return year * 12 + month - 1 >= now.getFullYear() * 12 + now.getMonth();
  }

  function addDays(now, days) {
    const d = new Date(now.getTime());
    d.setDate(d.getDate() + days);
    return d;
  }

  function nearFutureDate(now = new Date()) {
    return isoDate(addDays(now, randInt(1, 60)));
  }

  function datetimeLocal(now = new Date()) {
    const d = addDays(now, randInt(1, 60));
    return `${isoDate(d)}T${pad2(randInt(8, 18))}:${pad2(randInt(0, 3) * 15)}`;
  }

  function week(now = new Date()) {
    const d = addDays(now, randInt(7, 60));
    // ISO week: the Thursday of this week decides the year.
    const day = (d.getDay() + 6) % 7;
    const thursday = addDays(d, 3 - day);
    const firstThursday = new Date(thursday.getFullYear(), 0, 4);
    const weekNo = 1 + Math.round(((thursday - firstThursday) / 86400000 - 3 + ((firstThursday.getDay() + 6) % 7)) / 7);
    return `${thursday.getFullYear()}-W${pad2(weekNo)}`;
  }

  function monthValue(month, year) {
    return `${year}-${month}`;
  }

  function fitLength(value, el) {
    let v = String(value);
    if (el && el.maxLength > 0 && v.length > el.maxLength) v = v.slice(0, el.maxLength);
    // Padding would corrupt structured values, so only free-text fields are padded.
    const padable = !el || !['email', 'url', 'tel', 'password', 'number'].includes(el.type);
    if (padable && el && el.minLength > 0 && v.length < el.minLength) v = v.padEnd(el.minLength, 'x');
    return v;
  }

  const BASE36 = '0123456789abcdefghijklmnopqrstuvwxyz';

  // ---- Phone ----
  const fieldText = (el) => `${el.name || ''} ${el.id || ''} ${el.getAttribute('aria-label') || ''}`;

  // Fills a placeholder mask like "(555) 555-5555" when it has exactly one slot per digit.
  function applyMask(mask, digits) {
    if (!/^[\d\sx#()+.-]+$/i.test(mask) || /^\+/.test(mask)) return null;
    const slots = (mask.match(/[\dx#]/gi) || []).length;
    if (slots !== digits.length || !/[\s().-]/.test(mask)) return null;
    let i = 0;
    return mask.replace(/[\dx#]/gi, () => digits[i++]);
  }

  // National digits by default; "+CC number" when the field asks for it (placeholder or
  // pattern starting with +, or "intl"/"international" in its name). The trunk 0 is
  // dropped for international numbers and when the national number is too long.
  function phoneFor(persona, el) {
    const national = String(persona.phone || '').replace(/\D/g, '');
    const withoutTrunk = national.replace(/^0/, '');
    const placeholder = el.getAttribute('placeholder') || '';
    const pattern = el.getAttribute('pattern') || '';
    const intl = /^\s*\+/.test(placeholder) || /^\^?\\?\+/.test(pattern) ||
      /intl|international|e164/i.test(fieldText(el));
    if (intl && persona.phoneCountryCode) return `${persona.phoneCountryCode} ${withoutTrunk}`;
    const masked = applyMask(placeholder.trim(), national);
    if (masked) return masked;
    if (el.maxLength > 0 && national.length > el.maxLength) return withoutTrunk;
    return national;
  }

  // ---- Edge-case (negative testing) values ----
  const EDGE_TEXT = [
    'Zoë 😀 Ñandú 漢字 ✓',
    'مرحبا بالعالم',
    '   padded value   ',
    "' OR 1=1 --",
    '<script>alert(1)</script>',
    '"; DROP TABLE users; --',
    ' '
  ];
  const EDGE_EMAIL = ['plainaddress', '@missing-local.com', 'user@', 'two@@example.com', 'spaces in@example.com'];

  function edgeValue(el) {
    switch (el.type) {
      case 'email': return EDGE_EMAIL[randInt(0, EDGE_EMAIL.length - 1)];
      case 'number':
      case 'range': {
        const min = parseFloat(el.getAttribute('min'));
        const max = parseFloat(el.getAttribute('max'));
        const options = [];
        if (Number.isFinite(min)) options.push(String(min - 1));
        if (Number.isFinite(max)) options.push(String(max + 1));
        if (options.length === 0) options.push('-1', '999999999');
        return options[randInt(0, options.length - 1)];
      }
      case 'date': return randInt(0, 1) ? '1900-01-01' : '2999-12-31';
      case 'tel': return ['+++', '1', '0'.repeat(25)][randInt(0, 2)];
      case 'url': return ['not a url', 'javascript:alert(1)'][randInt(0, 1)];
      default: {
        const longest = 'W'.repeat(el.maxLength > 0 ? el.maxLength : 300);
        const pool = [...EDGE_TEXT, longest];
        return pool[randInt(0, pool.length - 1)];
      }
    }
  }

  // ---- Long text for textareas ----
  const TEXT_KINDS = [
    ['cover', /cover|motivation|why (do )?you want/i],
    ['notes', /deliver|instruction|address note|notes?\b/i],
    ['message', /message|feedback|comment|enquir|inquir|question|details|describe/i]
  ];

  function textKind(label) {
    const found = TEXT_KINDS.find(([, re]) => re.test(String(label || '')));
    return found ? found[0] : 'bio';
  }

  function sentences(kind, p) {
    const name = p.fullName || 'Alex Taylor';
    const job = p.jobTitle || 'software engineer';
    const company = p.company || 'my current company';
    const city = p.city || 'my city';
    switch (kind) {
      case 'cover': return [
        `Dear Hiring Manager, my name is ${name} and I am applying for this role.`,
        `I currently work as a ${job} at ${company} in ${city}.`,
        'Over the past few years I have shipped features end to end, from planning to release.',
        'I enjoy working closely with design, QA and product to deliver reliable software.',
        'I would welcome the chance to bring that experience to your team. Thank you for your time.'
      ];
      case 'notes': return [
        'Please leave the parcel at the front desk if nobody answers.',
        'The building entrance is on the side street, next to the café.',
        'Call on arrival; the buzzer does not always work.'
      ];
      case 'message': return [
        `Hello, this is ${name} from ${company}.`,
        'I am testing this form and wanted to send a realistic message.',
        'Could you share more details about pricing and next steps?',
        'Thanks in advance for getting back to me.'
      ];
      default: return [
        `${name} is a ${job} at ${company}, based in ${city}.`,
        'They care about clean code, good tests and clear documentation.',
        'Outside work they enjoy hiking, reading and photography.'
      ];
    }
  }

  function longText(kind, persona, el) {
    const list = sentences(kind, persona || {});
    const min = el && el.minLength > 0 ? el.minLength : 0;
    let text = list.join(' ');
    let i = 0;
    while (text.length < min) text += ' ' + list[i++ % list.length];
    if (el && el.maxLength > 0 && text.length > el.maxLength) {
      const cut = text.slice(0, el.maxLength);
      const end = cut.lastIndexOf('. ');
      text = end > el.maxLength / 2 ? cut.slice(0, end + 1) : cut;
    }
    return text;
  }

  // ---- Per-field generic values ----
  const digitsOf = (n) => Array.from({ length: n }, () => randInt(0, 9)).join('');
  const hex2 = () => randInt(0, 255).toString(16).padStart(2, '0');

  function miscValue(key, el, persona = {}) {
    switch (key) {
      case 'otp': return digitsOf(el.maxLength > 0 && el.maxLength < 6 ? el.maxLength : 6);
      case 'coupon': return 'TEST' + randomTag(6).toUpperCase();
      case 'referral': return 'REF' + randomTag(6).toUpperCase();
      case 'quantity': return String(randInt(1, 5));
      case 'slug': return String(persona.fullName || 'test item').normalize('NFD').replace(/[\u0300-\u036f]/g, '')
        .toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
      case 'uuid': return crypto.randomUUID();
      case 'ip': return `192.0.2.${randInt(1, 254)}`; // TEST-NET-1 (RFC 5737)
      case 'mac': return ['02', hex2(), hex2(), hex2(), hex2(), hex2()].join(':'); // locally administered
      case 'userAgent': return navigator.userAgent;
      default: return undefined;
    }
  }

  function randomTag(n) {
    let out = '';
    for (let i = 0; i < n; i++) out += pick(BASE36);
    return out;
  }

  // A new address on every call: time + random chars as a plus tag, so mail still reaches
  // the base inbox. Any existing tag is replaced. The local part shrinks to fit maxLength.
  function uniqueEmail(base, now = new Date(), maxLength = 0) {
    const at = String(base || '').lastIndexOf('@');
    const local = at > 0 ? base.slice(0, at).split('+')[0] : 'test';
    const domain = at > 0 ? base.slice(at + 1) : 'example.com';
    let tag = now.getTime().toString(36) + randomTag(4);
    if (maxLength > 0) {
      const room = maxLength - domain.length - 2; // '+' and '@'
      if (room - tag.length < 1) tag = tag.slice(-Math.max(4, room - 1));
      return `${local.slice(0, Math.max(1, room - tag.length))}+${tag}@${domain}`;
    }
    return `${local}+${tag}@${domain}`;
  }

  function uniqueUsername(base, now = new Date(), maxLength = 0) {
    const suffix = now.getTime().toString(36).slice(-4) + randomTag(4);
    const name = String(base || 'user');
    if (maxLength > 0 && name.length + suffix.length > maxLength) {
      const keep = Math.max(1, maxLength - suffix.length);
      return (name.slice(0, keep) + suffix).slice(0, maxLength);
    }
    return name + suffix;
  }

  function fallbackText(field) {
    if (field.element && field.element.tagName === 'TEXTAREA') {
      return 'This is a block of generated demo paragraph text to satisfy textarea requirements.';
    }
    const text = `${field.labelText || ''} ${field.name || ''}`;
    if (/\b(age|quantity|qty|amount)\b/i.test(text)) return String(randInt(1, 10));
    return 'Demo Data';
  }

  globalThis.FormFillerGen = {
    randInt,
    luhnValid,
    password,
    numberFor,
    rangeFor,
    isoDate,
    detectDateFormat,
    formatDate,
    futureExpiry,
    expiryIsFuture,
    nearFutureDate,
    datetimeLocal,
    week,
    monthValue,
    fitLength,
    uniqueEmail,
    uniqueUsername,
    phoneFor,
    EDGE_TEXT,
    edgeValue,
    textKind,
    longText,
    miscValue,
    fallbackText
  };
})();
