(function() {
  const MAX_OPTIONS = 50;
  const CARD_KEYS = new Set(['cardNumber', 'cardCvv', 'cardExpiry', 'cardExpMonth', 'cardExpYear']);

  const ids = new WeakMap();
  let counter = 0;

  function idFor(el) {
    if (!ids.has(el)) ids.set(el, 'ff_' + (++counter));
    return ids.get(el);
  }

  function optionsFor(field, fieldByElement) {
    const el = field.element;
    if (el.tagName === 'SELECT') {
      return Array.from(el.options).map((o) => ({ value: o.value, text: o.text })).filter((o) => o.value || o.text);
    }
    if (el.type === 'radio') {
      return FormFillerDom.radioGroup(el).map((r) => ({
        value: r.value,
        text: (fieldByElement.get(r) || {}).labelText || r.value
      }));
    }
    if (el.type === 'checkbox') {
      return [{ value: 'true', text: 'Checked' }, { value: 'false', text: 'Unchecked' }];
    }
    return [];
  }

  function withTruncatedOptions(entry, options) {
    if (options.length > MAX_OPTIONS) {
      entry.options = options.slice(0, MAX_OPTIONS);
      entry.optionsTotal = options.length;
    } else {
      entry.options = options;
    }
    return entry;
  }

  // Only labels/names/options leave the page: never values, passwords, or card fields.
  function aiPayload(fields, { classify }) {
    const fieldByElement = new Map(fields.map((f) => [f.element, f]));
    const idMap = new Map();
    const entries = [];
    for (const field of fields) {
      if (field.element.type === 'password') continue;
      if (CARD_KEYS.has(classify(field).key)) continue;
      const id = idFor(field.element);
      idMap.set(id, field);
      entries.push(withTruncatedOptions({
        id,
        name: field.name,
        type: field.type,
        placeholder: field.placeholder,
        label: field.labelText,
        autocomplete: field.autocomplete
      }, optionsFor(field, fieldByElement)));
    }
    return {
      schema: { url: location.origin + location.pathname, title: document.title, fields: entries },
      idMap
    };
  }

  function capture(fields) {
    const fieldByElement = new Map(fields.map((f) => [f.element, f]));
    const seenGroups = new Set();
    const entries = [];
    for (const field of fields) {
      const el = field.element;
      if (el.type === 'radio') {
        const key = FormFillerDom.groupKey(el);
        if (seenGroups.has(key)) continue;
        seenGroups.add(key);
      }
      const entry = {
        id: idFor(el),
        domId: el.id || '',
        name: field.name,
        type: field.type,
        label: field.labelText || field.name || 'Unnamed field',
        options: el.type === 'checkbox' ? [] : optionsFor(field, fieldByElement)
      };
      if (el.type === 'checkbox') entry.fieldValue = el.value;
      entries.push(entry);
    }
    return { url: location.href, title: document.title, fields: entries };
  }

  globalThis.FormFillerSerialize = {
    idFor,
    aiPayload,
    capture
  };
})();
