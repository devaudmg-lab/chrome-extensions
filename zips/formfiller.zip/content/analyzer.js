(function() {
  // WHATWG autocomplete tokens → profile keys. Checked before any heuristics.
  const AUTOCOMPLETE_MAP = {
    'email': 'email',
    'username': 'username',
    'new-password': 'password',
    'current-password': 'password',
    'name': 'fullName',
    'given-name': 'firstName',
    'family-name': 'lastName',
    'organization': 'company',
    'street-address': 'addressLine1',
    'address-line1': 'addressLine1',
    'address-line2': 'addressLine2',
    'address-level1': 'state',
    'address-level2': 'city',
    'postal-code': 'zipCode',
    'country': 'country',
    'country-name': 'country',
    'tel': 'phone',
    'tel-national': 'phone',
    'cc-name': 'cardName',
    'cc-number': 'cardNumber',
    'cc-exp': 'cardExpiry',
    'cc-exp-month': 'cardExpMonth',
    'cc-exp-year': 'cardExpYear',
    'cc-csc': 'cardCvv',
    'bday': 'birthDate',
    'bday-day': 'birthDay',
    'bday-month': 'birthMonth',
    'bday-year': 'birthYear',
    'url': 'website',
    'tel-country-code': 'phoneCountryCode',
    'honorific-prefix': 'prefix',
    'honorific-suffix': 'suffix',
    'additional-name': 'middleName',
    'sex': 'gender',
    'organization-title': 'jobTitle',
    'one-time-code': 'otp',
    'transaction-amount': 'amount',
    'transaction-currency': 'currency'
  };
  const AUTOCOMPLETE_PREFIXES = new Set(['shipping', 'billing', 'home', 'work', 'mobile', 'fax', 'pager']);

  // Rules in tie-break order: specific keys first, generic fullName last.
  // Each phrase is a space-separated token sequence; a leading '=' means the
  // source's tokens must equal the phrase exactly (so "file name" is not a person's name).
  const RULES = [
    ['phoneCountryCode', ['dial code', 'calling code', 'phone code', 'isd', 'isd code', 'phone country code', 'country calling code']],
    ['ip', ['ip address', '=ip', 'ip addr']],
    ['mac', ['mac address', '=mac']],
    ['userAgent', ['user agent', 'useragent']],
    ['otp', ['otp', 'one time', 'one time code', 'one time password', 'verification code', 'auth code', '2 fa', 'security pin', 'sms code']],
    ['email', ['email', 'e mail', 'mail', 'email address']],
    ['password', ['password', 'pass', 'pwd', 'passwd', 'passcode', 'confirm password']],
    ['cardNumber', ['card number', 'cc number', 'cc num', 'ccnum', 'cardnumber', 'credit card', 'debit card', 'card no', 'credit card number']],
    ['cardExpMonth', ['exp month', 'expiry month', 'expiration month', 'exp mm', 'cc month', 'card month', 'cc exp month']],
    ['cardExpYear', ['exp year', 'expiry year', 'expiration year', 'exp yy', 'exp yyyy', 'cc year', 'card year', 'cc exp year']],
    ['cardExpiry', ['expiry', 'expiration', 'exp date', 'expiry date', 'expiration date', 'cc exp', 'mm yy']],
    ['cardCvv', ['cvv', 'cvc', 'csc', 'cvv 2', 'security code', 'card code', 'card verification']],
    ['cardName', ['card name', 'cardholder', 'card holder', 'name on card', 'holder name', 'cc name', 'cardholder name']],
    ['phone', ['phone', 'mobile', 'tel', 'telephone', 'cell', 'cellphone', 'phone number', 'contact number', 'mobile number']],
    ['iban', ['iban']],
    ['swift', ['swift', 'bic', 'swift code', 'bic code', 'swift bic']],
    ['routingNumber', ['routing', 'routing number', 'aba', 'aba number', 'sort code']],
    ['accountNumber', ['account number', 'acct number', 'account no', 'bank account', 'acct no']],
    ['vatNumber', ['vat', 'vat number', 'gst', 'gstin', 'tax id', 'tax number', 'abn', 'ein']],
    ['nationalId', ['ssn', 'social security', 'social security number', 'national insurance', 'ni number', 'nino', 'social insurance', 'sin number', 'tfn', 'tax file number', 'national id', 'pan number', 'pan card', 'id number']],
    ['passport', ['passport', 'passport number', 'passport no']],
    ['poBox', ['po box', 'p o box', 'pobox', 'post office box']],
    ['deliveryInstructions', ['delivery instructions', 'delivery notes', 'special instructions', 'instructions']],
    ['coupon', ['coupon', 'promo', 'promo code', 'voucher', 'discount code', 'coupon code']],
    ['referral', ['referral', 'referral code', 'referrer', 'invite code']],
    ['zipCode', ['zip', 'zipcode', 'zip code', 'postal', 'postcode', 'post code', 'postal code', 'pincode', 'pin code']],
    ['middleName', ['middle name', 'mname', 'middlename', 'middle initial']],
    ['firstName', ['first name', 'fname', 'firstname', 'given name', 'forename']],
    ['lastName', ['last name', 'lname', 'lastname', 'surname', 'family name']],
    ['username', ['username', 'user name', 'login', 'login name', 'user id', 'userid', 'screen name', 'handle', 'nickname']],
    ['employeeCount', ['company size', 'employees', 'employee count', 'number of employees', 'team size', 'headcount']],
    ['company', ['company', 'company name', 'organization', 'organisation', 'business', 'business name', 'employer', 'firm']],
    ['jobTitle', ['job title', 'jobtitle', 'position', 'designation', 'occupation', 'job role', 'role']],
    ['department', ['department', 'dept', 'division']],
    ['industry', ['industry', 'sector']],
    ['linkedin', ['linkedin', 'linked in']],
    ['github', ['github', 'git hub']],
    ['prefix', ['prefix', 'salutation', 'honorific', '=title', 'name title']],
    ['suffix', ['suffix', 'name suffix']],
    ['gender', ['gender', 'sex']],
    ['maritalStatus', ['marital status', 'marital', 'relationship status']],
    ['nationality', ['nationality', 'citizenship']],
    ['age', ['=age', 'your age', 'age years', 'current age']],
    ['currency', ['currency']],
    ['amount', ['amount', 'price', 'total amount', 'payment amount']],
    ['quantity', ['quantity', 'qty']],
    ['slug', ['slug', 'url slug']],
    ['uuid', ['uuid', 'guid']],
    ['landmark', ['landmark']],
    ['latitude', ['latitude', '=lat']],
    ['longitude', ['longitude', '=lng', '=lon']],
    ['addressLine2', ['address 2', 'address line 2', 'addr 2', 'line 2', 'apt', 'apartment', 'suite', 'unit', 'flat']],
    ['addressLine1', ['address', 'addr', 'street', 'address 1', 'address line', 'address line 1', 'street address', 'mailing address', 'billing address', 'shipping address']],
    ['city', ['city', 'town', 'locality', 'suburb']],
    ['state', ['state', 'province', 'region', 'county', 'state province']],
    ['country', ['country', 'country name', 'country code']],
    ['website', ['website', 'web site', 'url', 'homepage', 'home page', 'web page', 'portfolio']],
    ['bio', ['bio', 'biography', 'about me', 'about you', 'description', 'summary', 'comment', 'comments', 'message', 'notes']],
    ['birthDay', ['birth day', 'dob day', 'day of birth', 'bday day', 'dob dd']],
    ['birthMonth', ['birth month', 'dob month', 'month of birth', 'bday month', 'dob mm']],
    ['birthYear', ['birth year', 'dob year', 'year of birth', 'bday year', 'dob yyyy']],
    ['birthDate', ['birth', 'dob', 'birthday', 'birthdate', 'date of birth', 'born', 'birth date']],
    ['fullName', ['full name', 'fullname', 'your name', 'contact name', 'display name', '=name']]
  ].map(([key, phrases]) => ({
    key,
    phrases: phrases.map((p) => {
      const exact = p.startsWith('=');
      return { exact, tokens: (exact ? p.slice(1) : p).split(' ') };
    })
  }));

  const SOURCE_WEIGHTS = { nameId: 3, label: 2, placeholder: 1 };
  const BIRTH_PHRASES = RULES.find((r) => r.key === 'birthDate').phrases;

  function tokenize(str) {
    return String(str || '')
      .replace(/([a-z])([A-Z])/g, '$1 $2')
      .replace(/([A-Za-z])(\d)/g, '$1 $2')
      .replace(/(\d)([A-Za-z])/g, '$1 $2')
      .toLowerCase()
      .split(/[^a-z0-9]+/)
      .filter(Boolean);
  }

  // Length of the longest phrase that matches (0 = no match).
  function bestPhraseLength(tokens, phrases) {
    let best = 0;
    for (const { exact, tokens: p } of phrases) {
      if (exact) {
        if (tokens.length === p.length && p.every((t, i) => tokens[i] === t)) best = Math.max(best, p.length);
        continue;
      }
      for (let i = 0; i + p.length <= tokens.length; i++) {
        if (p.every((t, j) => tokens[i + j] === t)) {
          best = Math.max(best, p.length);
          break;
        }
      }
    }
    return best;
  }

  function autocompleteKey(autocomplete) {
    const tokens = String(autocomplete || '').toLowerCase().split(/\s+/).filter(Boolean)
      .filter((t) => !t.startsWith('section-') && !AUTOCOMPLETE_PREFIXES.has(t));
    return tokens.length > 0 ? AUTOCOMPLETE_MAP[tokens[0]] || null : null;
  }

  function typeFallback(type) {
    switch (type) {
      case 'email': return 'email';
      case 'tel': return 'phone';
      case 'url': return 'website';
      case 'password': return 'password';
      case 'number': return 'number_fallback';
      case 'date': return 'date_generic';
      default: return null;
    }
  }

  function classify(field) {
    const fromAutocomplete = autocompleteKey(field.autocomplete);
    if (fromAutocomplete) return { key: fromAutocomplete, confidence: 1 };

    const sources = [
      { weight: SOURCE_WEIGHTS.nameId, lists: [tokenize(field.name), tokenize(field.id)] },
      { weight: SOURCE_WEIGHTS.label, lists: [tokenize(field.labelText)] },
      { weight: SOURCE_WEIGHTS.placeholder, lists: [tokenize(field.placeholder)] }
    ];

    if (field.type === 'date') {
      const birth = sources.some((s) => s.lists.some((l) => bestPhraseLength(l, BIRTH_PHRASES) > 0));
      return birth ? { key: 'birthDate', confidence: 0.9 } : { key: 'date_generic', confidence: 0.5 };
    }

    let best = { key: null, score: 0 };
    // "title" alone means Mr/Ms only where the options say so (a select or radio group);
    // a free-text "title" is a job, post or ticket title.
    const choice = field.type === 'select-one' || field.type === 'radio';
    for (const rule of RULES) {
      if (rule.key === 'prefix' && !choice) {
        const phrases = rule.phrases.filter((p) => !(p.exact && p.tokens.join(' ') === 'title'));
        const len = Math.max(...sources.flatMap((s) => s.lists.map((l) => bestPhraseLength(l, phrases))));
        if (len === 0) continue;
      }
      let score = 0;
      let longest = 0;
      for (const source of sources) {
        const len = Math.max(...source.lists.map((l) => bestPhraseLength(l, rule.phrases)));
        if (len > 0) {
          score += source.weight;
          longest = Math.max(longest, len);
        }
      }
      if (score > 0) score += 0.5 * (longest - 1);
      if (score > best.score) best = { key: rule.key, score };
    }

    if (best.key) return { key: best.key, confidence: Math.min(1, best.score / 4) };
    const fallback = typeFallback(field.type);
    return fallback ? { key: fallback, confidence: 0.3 } : { key: null, confidence: 0 };
  }

  function matchField(field) {
    return classify(field).key;
  }

  globalThis.FormFillerAnalyzer = {
    AUTOCOMPLETE_MAP,
    tokenize,
    classify,
    matchField
  };
})();
