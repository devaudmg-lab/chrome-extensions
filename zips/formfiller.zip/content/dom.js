(function() {
  function rootOf(el) {
    return el.getRootNode ? el.getRootNode() : el.ownerDocument;
  }

  // Radios sharing a name within the same form (or, outside any form, the same root).
  // Compares properties in JS so names with quotes/brackets never reach a selector.
  function radioGroup(el) {
    if (!el.name) return [el];
    if (el.form) {
      return Array.from(el.form.elements).filter((r) => r.type === 'radio' && r.name === el.name);
    }
    return Array.from(rootOf(el).querySelectorAll('input')).filter(
      (r) => r.type === 'radio' && r.name === el.name && !r.form
    );
  }

  const groupKeys = new WeakMap();

  function groupKey(el) {
    const scope = !el.name ? el : el.form || rootOf(el);
    let byName = groupKeys.get(scope);
    if (!byName) {
      byName = new Map();
      groupKeys.set(scope, byName);
    }
    let key = byName.get(el.name);
    if (!key) {
      key = { name: el.name };
      byName.set(el.name, key);
    }
    return key;
  }

  // Rich-text editors (Quill, ProseMirror, Draft.js, TinyMCE inline...) are contenteditable
  // elements. jsdom has no isContentEditable, so the attribute is checked as a fallback.
  function isContentEditable(el) {
    if (!el || el.nodeType !== 1) return false;
    if (typeof el.isContentEditable === 'boolean') return el.isContentEditable;
    const host = el.closest && el.closest('[contenteditable]');
    return !!host && host.getAttribute('contenteditable') !== 'false';
  }

  // The outermost element of an editable region; the page body (designMode pages) never counts.
  function isEditableRoot(el) {
    if (!isContentEditable(el) || el.tagName === 'BODY' || el.tagName === 'HTML') return false;
    return !isContentEditable(el.parentElement);
  }

  // The editable region that contains el (el may be a <p> inside the editor), or null.
  function editableRoot(el) {
    let node = el;
    while (node && isContentEditable(node) && !isEditableRoot(node)) node = node.parentElement;
    return node && isEditableRoot(node) ? node : null;
  }

  // Textareas and rich-text editors get paragraphs instead of one-line values.
  function isMultiline(el) {
    return el.tagName === 'TEXTAREA' || isEditableRoot(el);
  }

  function textOf(el) {
    if (!isEditableRoot(el)) return el.value;
    return typeof el.innerText === 'string' ? el.innerText : el.textContent;
  }

  function isEmpty(field) {
    const el = field.element;
    if (isEditableRoot(el)) return String(textOf(el) || '').trim() === '';
    if (el.type === 'checkbox') return !el.checked;
    if (el.type === 'radio') return !radioGroup(el).some((r) => r.checked);
    if (el.tagName === 'SELECT') {
      if (el.selectedIndex === -1) return true;
      return el.options[el.selectedIndex].value === '';
    }
    return String(el.value || '').trim() === '';
  }

  function log(...args) {
    if (globalThis.__ffDebug === true) console.log('FormFiller:', ...args);
  }

  globalThis.FormFillerDom = {
    rootOf,
    radioGroup,
    groupKey,
    isContentEditable,
    isEditableRoot,
    editableRoot,
    isMultiline,
    textOf,
    isEmpty,
    log
  };
})();
