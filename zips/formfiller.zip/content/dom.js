(function() {
  function rootOf(el) {
    return el.getRootNode ? el.getRootNode() : el.ownerDocument;
  }

  // Radios sharing a name within the same form (or, outside any form, the same root).
  // Compares properties in JS so names with quotes/brackets never reach a selector.
  function radioGroup(el) {
    if (!el.name) return [el];
    if (el.form) {
      return Array.from(el.form.elements).filter((r) => r.type === 'radio' && r.name === el.name);
    }
    return Array.from(rootOf(el).querySelectorAll('input')).filter(
      (r) => r.type === 'radio' && r.name === el.name && !r.form
    );
  }

  const groupKeys = new WeakMap();

  function groupKey(el) {
    const scope = !el.name ? el : el.form || rootOf(el);
    let byName = groupKeys.get(scope);
    if (!byName) {
      byName = new Map();
      groupKeys.set(scope, byName);
    }
    let key = byName.get(el.name);
    if (!key) {
      key = { name: el.name };
      byName.set(el.name, key);
    }
    return key;
  }

  function isEmpty(field) {
    const el = field.element;
    if (el.type === 'checkbox') return !el.checked;
    if (el.type === 'radio') return !radioGroup(el).some((r) => r.checked);
    if (el.tagName === 'SELECT') {
      if (el.selectedIndex === -1) return true;
      return el.options[el.selectedIndex].value === '';
    }
    return String(el.value || '').trim() === '';
  }

  function log(...args) {
    if (globalThis.__ffDebug === true) console.log('FormFiller:', ...args);
  }

  globalThis.FormFillerDom = {
    rootOf,
    radioGroup,
    groupKey,
    isEmpty,
    log
  };
})();
