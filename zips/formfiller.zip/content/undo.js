(function() {
  let entries = null;

  // Records current values. With append, keeps the existing snapshot and adds new elements
  // (used for fields filled by dynamic passes after the main fill).
  function snapshot(fields, { append = false } = {}) {
    const list = append && entries ? entries : [];
    const seen = new Set(list.map((e) => e.el));
    const add = (el, entry) => {
      if (seen.has(el)) return;
      seen.add(el);
      list.push({ el, ...entry });
    };
    for (const { element: el } of fields) {
      if (el.type === 'radio') {
        FormFillerDom.radioGroup(el).forEach((r) => add(r, { checked: r.checked }));
      } else if (el.type === 'checkbox') {
        add(el, { checked: el.checked });
      } else if (el.tagName === 'SELECT') {
        add(el, { selected: Array.from(el.options).map((o) => o.selected) });
      } else {
        add(el, { value: el.value });
      }
    }
    entries = list;
  }

  function restore() {
    if (!entries) return 0;
    const list = entries;
    entries = null;
    let count = 0;
    // Uncheck first so re-checking a radio is not undone by its sibling.
    const ordered = [...list.filter((e) => e.checked === false), ...list.filter((e) => e.checked !== false)];
    for (const entry of ordered) {
      const { el } = entry;
      try {
        if ('checked' in entry) {
          FormFillerEvents.setChecked(el, entry.checked);
        } else if ('selected' in entry) {
          const setSelected = FormFillerEvents.nativeSetter(el.options[0] || el, 'selected');
          Array.from(el.options).forEach((o, i) => setSelected.call(o, !!entry.selected[i]));
          el.dispatchEvent(new Event('input', { bubbles: true }));
          el.dispatchEvent(new Event('change', { bubbles: true }));
        } else {
          FormFillerEvents.setValue(el, entry.value);
        }
        count++;
      } catch (e) {
        FormFillerDom.log('undo failed', e.message);
      }
    }
    return count;
  }

  function hasSnapshot() {
    return !!entries;
  }

  globalThis.FormFillerUndo = {
    snapshot,
    restore,
    hasSnapshot
  };
})();
