(function() {
  const TRUTHY = new Set(['true', '1', 'on', 'yes', 'checked']);
  const FALSY = new Set(['false', '0', 'off', 'no', 'unchecked']);

  function normalize(s) {
    return String(s == null ? '' : s).toLowerCase().replace(/\s+/g, ' ').trim();
  }

  const isTruthy = (v) => TRUTHY.has(normalize(v));
  const isFalsy = (v) => FALSY.has(normalize(v));

  // Tiers, strongest first. Each returns true when option o matches the wanted string w.
  const TIERS = [
    (o, w) => o.value !== '' && normalize(o.value) === w,
    (o, w) => normalize(o.text) !== '' && normalize(o.text) === w,
    (o, w) => w.length >= 2 && normalize(o.text).startsWith(w),
    (o, w) => w.length >= 2 && normalize(o.text).includes(w)
  ];

  function bestOption(options, wanted) {
    const candidates = [].concat(wanted == null ? [] : wanted).map(normalize).filter(Boolean);
    for (const w of candidates) {
      for (const tier of TIERS) {
        const hit = options.find((o) => tier(o, w));
        if (hit) return hit;
      }
    }
    return null;
  }

  function containsSequence(tokens, seq) {
    for (let i = 0; i + seq.length <= tokens.length; i++) {
      if (seq.every((t, j) => tokens[i + j] === t)) return true;
    }
    return false;
  }

  function customMappingFor(field, mappings) {
    const tokenize = FormFillerAnalyzer.tokenize;
    const sources = [field.name, field.id, field.labelText, field.placeholder].map(tokenize);
    let best = null;
    let bestRank = [0, 0];
    for (const mapping of mappings || []) {
      const keyTokens = tokenize(mapping.key);
      if (keyTokens.length === 0) continue;
      if (!sources.some((s) => containsSequence(s, keyTokens))) continue;
      const rank = [keyTokens.length, String(mapping.key).length];
      if (rank[0] > bestRank[0] || (rank[0] === bestRank[0] && rank[1] > bestRank[1])) {
        best = mapping;
        bestRank = rank;
      }
    }
    return best;
  }

  const stripQuery = (url) => String(url).split(/[?#]/)[0];

  // A pattern matches when the page URL starts with it. "*" matches any run of characters
  // (e.g. https://*.example.com/signup*). Patterns without "?" or "#" ignore the page's
  // query string and hash, so rules keep working when ?session=... changes.
  function urlPatternMatches(pattern, href) {
    const target = /[?#]/.test(pattern) ? href : stripQuery(href);
    if (!pattern.includes('*')) {
      return target.startsWith(pattern) || (/[?#]/.test(pattern) && stripQuery(href).startsWith(stripQuery(pattern)));
    }
    const source = pattern.split('*').map((part) => part.replace(/[.+?^${}()|[\]\\]/g, '\\$&')).join('.*');
    return new RegExp(`^${source}`).test(target);
  }

  // Most specific rule wins: the pattern with the most literal (non-wildcard) characters.
  function urlRulesFor(urlRules, href) {
    const matches = (urlRules || []).filter((r) => r.urlPattern && urlPatternMatches(r.urlPattern, href));
    if (matches.length === 0) return [];
    const literal = (r) => r.urlPattern.replace(/\*/g, '').length;
    matches.sort((a, b) => literal(b) - literal(a));
    return matches[0].rules || [];
  }

  function ruleFor(field, entries) {
    const list = entries || [];
    const byDomId = list.find((e) => e.domId && e.domId === field.id);
    if (byDomId) return byDomId;
    if (!field.name) return null;
    if (field.type === 'checkbox') {
      return list.find((e) => e.name === field.name &&
        (e.fieldValue === undefined || e.fieldValue === field.element.value)) || null;
    }
    return list.find((e) => e.name && e.name === field.name) || null;
  }

  globalThis.FormFillerMatch = {
    normalize,
    isTruthy,
    isFalsy,
    bestOption,
    customMappingFor,
    urlRulesFor,
    urlPatternMatches,
    stripQuery,
    ruleFor
  };
})();
