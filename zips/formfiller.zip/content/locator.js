(function() {
  // Ids that frameworks generate per render (React's ":r1:", long digit runs) change
  // between page loads, so they can't identify a field.
  const GENERATED_ID = /^:|:$|\d{4,}|^[0-9a-f]{8}-[0-9a-f]{4}-/i;
  const CONTROL_TAGS = new Set(['INPUT', 'SELECT', 'TEXTAREA']);

  const norm = (s) => String(s || '').replace(/\s+/g, ' ').trim().toLowerCase().slice(0, 60);

  // Null for opaque frames (about:blank, srcdoc, data:): their URL says nothing about the
  // site, so a shared key would replay values across unrelated sites.
  function siteKey(loc = location) {
    if (!loc.origin || loc.origin === 'null') return null;
    return loc.origin + loc.pathname;
  }

  function storageKey(site) {
    return 'ff_modes:' + site;
  }

  function actionPath(form) {
    const raw = form.getAttribute('action');
    if (!raw) return '';
    try {
      return new URL(raw, document.baseURI).pathname;
    } catch {
      return '';
    }
  }

  // Ids and names are only unique within one shadow root, so keys of elements inside a
  // shadow root start with a key for each host on the way up: "#host>" or "tag:index>".
  function hostPrefix(el) {
    let prefix = '';
    let root = FormFillerDom.rootOf(el);
    while (root && root.host) {
      const host = root.host;
      const hostRoot = FormFillerDom.rootOf(host);
      const key = host.id
        ? '#' + host.id
        : `${host.localName}:${Array.from(hostRoot.querySelectorAll(host.localName)).indexOf(host)}`;
      prefix = key + '>' + prefix;
      root = hostRoot;
    }
    return prefix;
  }

  function formKey(form) {
    if (!form) return 'page';
    if (form.id) return 'id:' + form.id;
    const name = form.getAttribute('name');
    if (name) return 'name:' + name;
    const path = actionPath(form);
    if (path) return 'action:' + path;
    return 'form:' + Array.from(FormFillerDom.rootOf(form).querySelectorAll('form')).indexOf(form);
  }

  function controlsOf(field) {
    const el = field.element;
    const list = el.form ? Array.from(el.form.elements) : Array.from(FormFillerDom.rootOf(el).querySelectorAll('input, select, textarea')).filter((c) => !c.form);
    return list.filter((c) => CONTROL_TAGS.has(c.tagName));
  }

  function fieldKey(field) {
    const el = field.element;
    if (el.type === 'radio' && el.name) return 'radio:' + el.name;
    if (el.id && !GENERATED_ID.test(el.id)) return 'id:' + el.id;
    if (el.name) return el.type === 'checkbox' ? `name:${el.name}=${el.value}` : 'name:' + el.name;
    const label = norm(field.labelText);
    if (label) return 'label:' + label;
    return `idx:${field.type}:${controlsOf(field).indexOf(el)}`;
  }

  function locate(field) {
    const prefix = hostPrefix(field.element);
    return { formKey: formKey(field.element.form), fieldKey: prefix + fieldKey(field) };
  }

  globalThis.FormFillerLocator = {
    siteKey,
    storageKey,
    formKey,
    fieldKey,
    locate
  };
})();
