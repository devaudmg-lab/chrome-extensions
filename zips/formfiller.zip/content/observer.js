(function() {
  const IDLE_MS = 8000;
  const MAX_PASSES = 3;
  const DEBOUNCE_MS = 300;

  let observer = null;
  const handled = new WeakSet();
  let passes = 0;
  let debounceTimer = null;
  let idleTimer = null;
  let getCtx = null;
  let scanOpts = {};
  let planFields = null;
  let afterFill = null;

  function resetIdle() {
    clearTimeout(idleTimer);
    idleTimer = setTimeout(stop, IDLE_MS);
  }

  function runPass() {
    if (!observer) return;
    const found = FormFillerScanner.scan(scanOpts).filter((f) => !handled.has(f.element));
    found.forEach((f) => handled.add(f.element));
    // planFields applies field modes (drops Skip fields, adds Keep/Change overrides).
    // Fields with a mode are filled even when they render with a value.
    const plan = planFields ? planFields(found) : { fields: found, moded: new Set() };
    const fresh = plan.fields.filter((f) => plan.moded.has(f.element) || FormFillerDom.isEmpty(f));
    if (fresh.length === 0) return;
    FormFillerUndo.snapshot(fresh, { append: true });
    const result = FormFillerFiller.fillAll(fresh, { ...getCtx(), overrides: plan.overrides });
    if (afterFill) afterFill({ ...plan, pendingKeep: (plan.pendingKeep || []).filter((f) => fresh.includes(f)) });
    FormFillerDom.log(`dynamic pass ${passes + 1}/${MAX_PASSES} filled ${result.filled} fields`);
    passes++;
    if (passes >= MAX_PASSES) stop();
    else resetIdle();
  }

  function onMutations(mutations) {
    const addedElement = mutations.some((m) => Array.from(m.addedNodes).some((n) => n.nodeType === Node.ELEMENT_NODE));
    if (!addedElement) return;
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(runPass, DEBOUNCE_MS);
  }

  function start(ctxProvider, opts = {}, planner = null, onFilled = null) {
    getCtx = ctxProvider;
    scanOpts = opts;
    planFields = planner;
    afterFill = onFilled;
    passes = 0;
    if (!observer) {
      observer = new MutationObserver(onMutations);
      observer.observe(document.documentElement, { childList: true, subtree: true });
    }
    resetIdle();
  }

  function stop() {
    if (observer) observer.disconnect();
    observer = null;
    clearTimeout(debounceTimer);
    clearTimeout(idleTimer);
  }

  function markHandled(elements) {
    elements.forEach((el) => handled.add(el));
  }

  globalThis.FormFillerObserver = {
    IDLE_MS,
    MAX_PASSES,
    DEBOUNCE_MS,
    start,
    stop,
    markHandled
  };
})();
