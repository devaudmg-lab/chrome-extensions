(function() {
  const SKIP_TYPES = new Set(['hidden', 'submit', 'button', 'reset', 'image', 'file', 'search']);
  const CONTROL_SELECTOR = 'input, select, textarea, button';
  const LABEL_SIBLING_TAGS = new Set(['SPAN', 'DIV', 'P', 'STRONG', 'B', 'LABEL']);

  const clean = (s) => String(s || '').replace(/\s+/g, ' ').trim();

  // Label text without the text of controls nested inside it (e.g. a wrapped <select>'s options).
  function labelElementText(label) {
    const copy = label.cloneNode(true);
    copy.querySelectorAll(CONTROL_SELECTOR).forEach((n) => n.remove());
    return clean(copy.textContent);
  }

  function labelsOf(el) {
    if (el.labels && el.labels.length > 0) return Array.from(el.labels);
    if (!el.id) return [];
    const root = FormFillerDom.rootOf(el);
    return Array.from(root.querySelectorAll('label')).filter((l) => l.htmlFor === el.id);
  }

  function getLabelText(el) {
    const labels = labelsOf(el).map(labelElementText).filter(Boolean);
    if (labels.length > 0) return labels.join(' ');

    const ariaLabel = clean(el.getAttribute('aria-label'));
    if (ariaLabel) return ariaLabel;

    const labelledBy = el.getAttribute('aria-labelledby');
    if (labelledBy) {
      const root = FormFillerDom.rootOf(el);
      const text = labelledBy.split(/\s+/)
        .map((id) => (root.getElementById ? root.getElementById(id) : null))
        .filter(Boolean)
        .map((n) => clean(n.textContent))
        .join(' ');
      if (clean(text)) return clean(text);
    }

    if (clean(el.title)) return clean(el.title);
    if (clean(el.getAttribute('placeholder'))) return clean(el.getAttribute('placeholder'));

    let prev = el.previousSibling;
    while (prev && prev.nodeType === Node.TEXT_NODE && !clean(prev.textContent)) prev = prev.previousSibling;
    if (prev) {
      if (prev.nodeType === Node.TEXT_NODE) return clean(prev.textContent);
      if (prev.nodeType === Node.ELEMENT_NODE && LABEL_SIBLING_TAGS.has(prev.tagName) &&
          !prev.querySelector(CONTROL_SELECTOR)) {
        const text = clean(prev.textContent);
        if (text && text.length < 80) return text;
      }
    }

    if (el.parentElement) {
      const own = Array.from(el.parentElement.childNodes)
        .filter((n) => n.nodeType === Node.TEXT_NODE)
        .map((n) => n.textContent)
        .join(' ');
      if (clean(own)) return clean(own);
    }
    return '';
  }

  function isVisible(el) {
    if (typeof el.checkVisibility === 'function') {
      return el.checkVisibility({ opacityProperty: true, visibilityProperty: true });
    }
    const style = el.ownerDocument.defaultView.getComputedStyle(el);
    return style.display !== 'none' && style.visibility !== 'hidden' &&
      style.opacity !== '0' && el.getClientRects().length > 0;
  }

  // Styled checkboxes/radios hide the native input and draw a fake one; count the
  // input as visible when its label or wrapper is.
  function isToggleVisible(el) {
    if (isVisible(el)) return true;
    if (labelsOf(el).some(isVisible)) return true;
    return !!el.parentElement && isVisible(el.parentElement);
  }

  function shouldInclude(el, opts) {
    if (SKIP_TYPES.has(el.type)) return false;
    if (el.disabled) return false;
    if (el.readOnly && !opts.fillReadonly) return false;
    if (opts.skipHidden) {
      const toggle = el.type === 'checkbox' || el.type === 'radio';
      if (!(toggle ? isToggleVisible(el) : isVisible(el))) return false;
    }
    return true;
  }

  const words = (str) => String(str || '').replace(/([a-z])([A-Z])/g, '$1 $2').toLowerCase().split(/[^a-z0-9]+/);

  // Site search boxes are usually plain text inputs; never fill them with persona data.
  function isSearchBox(field) {
    const el = field.element;
    if (el.closest && el.closest('[role="search"]')) return true;
    if (field.name === 'q') return true;
    return [field.name, field.id, field.placeholder, field.labelText].some((v) => words(v).includes('search'));
  }

  function toField(el, root) {
    return {
      element: el,
      id: el.id || '',
      name: el.name || '',
      type: el.type || el.tagName.toLowerCase(),
      placeholder: el.getAttribute('placeholder') || '',
      autocomplete: el.getAttribute('autocomplete') || '',
      labelText: getLabelText(el),
      form: el.form || null,
      root
    };
  }

  function walk(root, opts, list) {
    const doc = root.ownerDocument || root;
    const walker = doc.createTreeWalker(root, NodeFilter.SHOW_ELEMENT);
    let node = walker.nextNode();
    while (node) {
      const tag = node.tagName;
      if ((tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') && shouldInclude(node, opts)) {
        const field = toField(node, root);
        if (!isSearchBox(field)) list.push(field);
      }
      // Iframes are not entered: every frame runs its own content script (all_frames).
      if (node.shadowRoot) walk(node.shadowRoot, opts, list);
      node = walker.nextNode();
    }
    return list;
  }

  // The field object for one element (used by the Alt+L shortcut), or null when the
  // element is not something a fill would touch.
  function fieldFor(el) {
    if (!el || !['INPUT', 'TEXTAREA', 'SELECT'].includes(el.tagName) || SKIP_TYPES.has(el.type) || el.disabled) return null;
    const field = toField(el, FormFillerDom.rootOf(el));
    return isSearchBox(field) ? null : field;
  }

  function scan({ skipHidden = true, fillReadonly = false } = {}, root = document) {
    return walk(root, { skipHidden, fillReadonly }, []);
  }

  globalThis.FormFillerScanner = {
    scan,
    fieldFor,
    getLabelText,
    isVisible
  };
})();
