(function() {
  // A fresh copy (injected after an extension reload) tells any orphaned copy to stop.
  document.dispatchEvent(new CustomEvent('formfiller:shutdown'));

  // Scan options of the last fill; clear/capture reuse them unless the message carries settings.
  let lastScanOpts = { skipHidden: true, fillReadonly: false };
  // The element last right-clicked, so the context-menu fill can stay inside its form.
  let contextTarget = null;
  // Side panel row refs → elements, from the last list_fields.
  let refs = new Map();

  const MODE_LABELS = { keep: '🔒 Keep', change: '🔄 Change', skip: '🚫 Skip' };

  function scanOptions(settings) {
    return { skipHidden: settings.skipHidden !== false, fillReadonly: settings.fillReadonly === true };
  }

  async function requestAiValues(fields, session) {
    const { schema, idMap } = FormFillerSerialize.aiPayload(fields, { classify: FormFillerAnalyzer.classify });
    if (schema.fields.length === 0) return { aiValues: new Map() };
    const p = session.persona;
    const context = {
      locale: session.settings.locale,
      persona: {
        fullName: p.fullName, email: p.email, phone: p.phone, city: p.city, state: p.state,
        country: p.country, countryCode: p.countryCode, birthDate: p.birthDate, company: p.company
      }
    };
    let response;
    try {
      response = await chrome.runtime.sendMessage({ action: 'ANALYZE_FORM_AI', sessionId: session.sessionId, formSchema: schema, context });
    } catch (e) {
      return { aiValues: new Map(), aiError: e.message };
    }
    if (!response || response.status !== 'success' || !response.data || !Array.isArray(response.data.fields)) {
      return { aiValues: new Map(), aiError: (response && response.reason) || 'Invalid AI response' };
    }
    const aiValues = new Map();
    for (const { id, value } of response.data.fields) {
      const field = idMap.get(id);
      if (field) aiValues.set(field.element, value);
    }
    return { aiValues };
  }

  function scopeForm(session) {
    if (session.scope !== 'context' || !contextTarget || !contextTarget.isConnected) return null;
    return contextTarget.form || (contextTarget.closest && contextTarget.closest('form')) || null;
  }

  // The right-clicked field (or editor), for "Fill this field" and "Insert test value".
  function contextField() {
    if (!contextTarget || !contextTarget.isConnected) return null;
    return FormFillerScanner.fieldFor(contextTarget);
  }

  // Which scanned fields a fill touches: all of them, the right-clicked form's, or only
  // the right-clicked field (its whole group for a radio).
  function scopeFilter(session) {
    if (session.scope === 'field') {
      const target = contextField();
      if (!target) return null;
      const el = target.element;
      const key = el.type === 'radio' ? FormFillerDom.groupKey(el) : null;
      return (f) => f.element === el || (key !== null && f.element.type === 'radio' && FormFillerDom.groupKey(f.element) === key);
    }
    const form = scopeForm(session);
    return (f) => !form || f.element.form === form || form.contains(f.element);
  }

  async function loadModes() {
    try {
      return await FormFillerModes.load();
    } catch (e) {
      FormFillerDom.log('modes unavailable', e.message);
      return {};
    }
  }

  async function runFill(session) {
    const settings = session.settings;
    globalThis.__ffDebug = settings.debug === true;
    const opts = scanOptions(settings);
    lastScanOpts = opts;
    const inScope = scopeFilter(session);
    if (!inScope) return { status: 'no_field', filled: 0, invalid: 0, engine: 'local' };
    const single = session.scope === 'field';
    const modes = await loadModes();
    const uniqueValues = new Map();
    const planOf = (found) => FormFillerModes.plan(found.filter(inScope), modes, { persona: session.persona, uniqueValues });
    const recordKept = (fieldsToRecord) => FormFillerModes.recordKept(fieldsToRecord)
      .catch((e) => FormFillerDom.log('could not record kept values', e.message));

    const plan = planOf(FormFillerScanner.scan(opts));
    let fields = plan.fields;
    // Fields with a mode, or the one field the user right-clicked, were chosen explicitly,
    // so "only fill empty fields" doesn't apply to them.
    if (settings.onlyEmpty && !session.overwrite && !single) {
      fields = fields.filter((f) => plan.moded.has(f.element) || FormFillerDom.isEmpty(f));
    }
    if (fields.length === 0) return { status: single ? 'no_field' : 'no_fields', filled: 0, invalid: 0, engine: 'local' };

    FormFillerUndo.snapshot(fields);
    const ruleEntries = FormFillerMatch.urlRulesFor(session.urlRules, location.href);

    let aiValues = new Map();
    let aiError;
    if ((settings.aiEnabled || session.forceAi) && settings.aiConfigured) {
      ({ aiValues, aiError } = await requestAiValues(fields.filter((f) => !plan.overrides.has(f.element)), session));
    }

    const ctx = {
      persona: session.persona,
      password: session.password,
      expiry: session.expiry,
      edge: session.edge === true,
      settings,
      ruleEntries,
      aiValues
    };
    const result = FormFillerFiller.fillAll(fields, { ...ctx, overrides: plan.overrides });
    result.errors.forEach((e) => FormFillerDom.log('field error', e));
    await recordKept(plan.pendingKeep.filter((f) => fields.includes(f)));

    // Fields that appear after the fill (multi-step forms, lazy sections) are filled too.
    if (!single) {
      FormFillerObserver.start(() => ({ ...ctx, aiValues: new Map() }), opts, planOf, (p) => recordKept(p.pendingKeep));
      FormFillerObserver.markHandled(fields.map((f) => f.element));
    }

    const response = {
      status: 'success',
      filled: result.filled,
      invalid: result.invalid,
      engine: aiValues.size > 0 ? 'ai' : 'local'
    };
    if (aiError) response.aiError = aiError;
    return response;
  }

  // Right-click → "Insert test value": one value of the chosen kind in the clicked field,
  // undoable like a fill. Edge-case values are inserted as they are (no length fitting).
  const EDGE_VALUES = {
    edge_unicode: 'Zoë 😀 Ñandú 漢字 ✓ Ωmega',
    edge_rtl: 'مرحبا بالعالم שלום',
    edge_whitespace: '   padded value   ',
    edge_xss: '"><img src=x onerror=alert(1)><script>alert(1)</script>',
    edge_sql: "' OR '1'='1' --; DROP TABLE users; --"
  };

  function insertValue(kind, field, session) {
    const el = field.element;
    if (EDGE_VALUES[kind]) return EDGE_VALUES[kind];
    if (kind === 'edge_long') return 'W'.repeat(el.maxLength > 0 ? el.maxLength + 1 : 1000);
    const persona = session.persona;
    const now = new Date();
    let value;
    if (kind === 'email') value = FormFillerGen.uniqueEmail(persona.email, now, el.maxLength > 0 ? el.maxLength : 0);
    else if (kind === 'paragraph') value = FormFillerGen.longText('message', persona, el);
    else if (kind === 'phone') value = FormFillerGen.phoneFor(persona, el);
    else if (kind === 'password') value = FormFillerGen.password({ length: session.settings.passwordLength || 16 });
    else value = persona[kind];
    return FormFillerGen.fitLength(value === undefined ? '' : value, el);
  }

  function insertIntoContext(kind, session) {
    const field = contextField();
    if (!field || field.element.tagName === 'SELECT' || ['checkbox', 'radio'].includes(field.element.type)) {
      return { status: 'no_field' };
    }
    FormFillerUndo.snapshot([field]);
    FormFillerEvents.setValue(field.element, insertValue(kind, field, session));
    return { status: 'success', filled: 1 };
  }

  function optsFor(message) {
    return message.scanOptions || lastScanOpts;
  }

  // One field per radio group, in page order.
  function uniqueFields(fields) {
    const seen = new Set();
    return fields.filter((f) => {
      if (f.element.type !== 'radio') return true;
      const key = FormFillerDom.groupKey(f.element);
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }

  function describe(field, modes) {
    const el = field.element;
    const entry = FormFillerModes.entryFor(modes, field) || {};
    const { formKey, fieldKey } = FormFillerLocator.locate(field);
    const isPassword = el.type === 'password';
    const current = FormFillerModes.readValue(field);
    return {
      ref: FormFillerSerialize.idFor(el),
      label: field.labelText || field.name || field.placeholder || field.type,
      type: field.type,
      key: FormFillerAnalyzer.classify(field).key || '',
      formKey,
      fieldKey,
      mode: entry.mode || null,
      isPassword,
      value: isPassword && current ? '••••' : current,
      keepValue: entry.mode === 'keep' && !isPassword ? entry.value : undefined
    };
  }

  async function listFields(message) {
    const fields = uniqueFields(FormFillerScanner.scan(optsFor(message)));
    refs = new Map(fields.map((f) => [FormFillerSerialize.idFor(f.element), f.element]));
    const modes = await loadModes();
    return {
      status: 'success',
      site: FormFillerLocator.siteKey(),
      url: location.href,
      title: document.title,
      fields: fields.map((f) => describe(f, modes))
    };
  }

  async function setModeByRef({ ref, mode, value }) {
    const el = refs.get(ref);
    const field = el && el.isConnected ? FormFillerScanner.fieldFor(el) : null;
    if (!field) return { status: 'stale' };
    const entry = await FormFillerModes.setMode(field, mode || undefined, value);
    return { status: 'success', entry: entry || null };
  }

  // Alt+L on a focused field cycles its mode and says so in a toast.
  async function cycleFocused(field) {
    const modes = await loadModes();
    const next = FormFillerModes.nextMode((FormFillerModes.entryFor(modes, field) || {}).mode, field);
    await FormFillerModes.setMode(field, next);
    const label = field.labelText || field.name || 'field';
    FormFillerOverlay.toast(`${next ? MODE_LABELS[next] : '↺ Normal fill'}: ${label}`);
    return next || null;
  }

  function deepTarget(event) {
    const path = event.composedPath ? event.composedPath() : [];
    return path[0] || event.target;
  }

  // Only real user input counts: a page can't forge Alt+L or a right-click to change modes.
  function onKeyDown(event) {
    if (!event.isTrusted || !event.altKey || event.ctrlKey || event.metaKey || event.shiftKey || event.code !== 'KeyL') return;
    const field = FormFillerScanner.fieldFor(deepTarget(event));
    if (!field) return;
    event.preventDefault();
    event.stopPropagation();
    cycleFocused(field).catch((e) => FormFillerDom.log('Alt+L failed', e.message));
  }

  function onContextMenu(event) {
    if (!event.isTrusted) return;
    contextTarget = deepTarget(event);
  }

  function respond(promise, sendResponse) {
    promise.then(sendResponse).catch((e) => sendResponse({ status: 'error', message: e.message }));
    return true;
  }

  function onMessage(message, sender, sendResponse) {
    switch (message && message.action) {
      case 'ping':
        sendResponse({ ok: true });
        return false;
      case 'fill_form':
        runFill(message.session)
          .then(sendResponse)
          .catch((e) => sendResponse({ status: 'error', filled: 0, invalid: 0, engine: 'local', message: e.message }));
        return true;
      case 'undo_fill': {
        FormFillerObserver.stop();
        if (!FormFillerUndo.hasSnapshot()) {
          sendResponse({ status: 'nothing' });
          return false;
        }
        sendResponse({ status: 'undone', restored: FormFillerUndo.restore() });
        return false;
      }
      case 'clear_form': {
        FormFillerObserver.stop();
        const toClear = FormFillerScanner.scan(optsFor(message));
        // Undo after Clear brings the values back.
        if (toClear.length > 0) FormFillerUndo.snapshot(toClear);
        const count = FormFillerFiller.clearAll(toClear);
        sendResponse({ status: 'cleared', count });
        return false;
      }
      case 'list_fields':
        return respond(listFields(message), sendResponse);
      case 'highlight': {
        const el = message.ref ? refs.get(message.ref) : null;
        if (el && el.isConnected) FormFillerOverlay.highlight(el);
        else FormFillerOverlay.clearHighlight();
        sendResponse({ status: 'success' });
        return false;
      }
      case 'set_mode':
        return respond(setModeByRef(message), sendResponse);
      case 'apply_preset': {
        const fields = uniqueFields(FormFillerScanner.scan(optsFor(message)));
        return respond(FormFillerModes.applyPreset(fields, message.preset).then(() => ({ status: 'success' })), sendResponse);
      }
      case 'reset_modes':
        return respond(FormFillerModes.reset().then(() => ({ status: 'success' })), sendResponse);
      case 'insert_value':
        try {
          sendResponse(insertIntoContext(message.kind, message.session));
        } catch (e) {
          sendResponse({ status: 'error', message: e.message });
        }
        return false;
      case 'toast':
        FormFillerOverlay.toast(String(message.text || ''), 4000);
        sendResponse({ status: 'success' });
        return false;
      case 'capture_form':
        try {
          sendResponse({ status: 'success', data: FormFillerSerialize.capture(FormFillerScanner.scan(optsFor(message))) });
        } catch (e) {
          sendResponse({ status: 'error', message: e.message });
        }
        return false;
      default:
        return false;
    }
  }

  function isAlive() {
    try {
      return !!(chrome.runtime && chrome.runtime.id);
    } catch {
      return false;
    }
  }

  chrome.runtime.onMessage.addListener(onMessage);
  document.addEventListener('keydown', onKeyDown, true);
  document.addEventListener('contextmenu', onContextMenu, true);
  // Only a copy whose extension context is gone (reloaded or updated) stops: the page
  // can dispatch this event too, and must not be able to switch the filler off.
  document.addEventListener('formfiller:shutdown', function shutdown() {
    if (isAlive()) return;
    document.removeEventListener('formfiller:shutdown', shutdown);
    document.removeEventListener('keydown', onKeyDown, true);
    document.removeEventListener('contextmenu', onContextMenu, true);
    FormFillerObserver.stop();
    FormFillerOverlay.destroy();
    try {
      chrome.runtime.onMessage.removeListener(onMessage);
    } catch {
      // The extension context of an orphaned copy may already be gone.
    }
  });
})();
