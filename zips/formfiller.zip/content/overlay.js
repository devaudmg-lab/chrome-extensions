(function() {
  // Field highlight and toast, drawn in a closed shadow root so page CSS can't reach them.
  let host = null;
  let shadow = null;
  let box = null;
  let toastEl = null;
  let toastTimer = null;
  let target = null;

  const STYLE = `
    .box { position: fixed; pointer-events: none; border: 2px solid #6366f1; border-radius: 4px;
      background: rgba(99, 102, 241, 0.12); box-shadow: 0 0 0 4px rgba(99, 102, 241, 0.25);
      transition: all 80ms ease-out; display: none; }
    .toast { position: fixed; right: 16px; bottom: 16px; padding: 8px 14px; border-radius: 8px;
      background: #1e1b4b; color: #fff; font: 13px/1.4 system-ui, sans-serif; display: none;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.25); max-width: 320px; }`;

  function ensureHost() {
    if (host && host.isConnected) return;
    host = document.createElement('formfiller-overlay');
    host.style.cssText = 'all: initial; position: fixed; inset: 0; pointer-events: none; z-index: 2147483647;';
    shadow = host.attachShadow({ mode: 'closed' });
    const style = document.createElement('style');
    style.textContent = STYLE;
    box = document.createElement('div');
    box.className = 'box';
    toastEl = document.createElement('div');
    toastEl.className = 'toast';
    toastEl.setAttribute('role', 'status');
    shadow.append(style, box, toastEl);
    document.documentElement.appendChild(host);
  }

  function place() {
    if (!target || !target.isConnected) {
      clearHighlight();
      return;
    }
    const r = target.getBoundingClientRect();
    Object.assign(box.style, {
      display: 'block',
      top: `${r.top - 3}px`,
      left: `${r.left - 3}px`,
      width: `${r.width + 2}px`,
      height: `${r.height + 2}px`
    });
  }

  function highlight(el) {
    ensureHost();
    target = el;
    if (el.scrollIntoView) el.scrollIntoView({ block: 'nearest', inline: 'nearest' });
    place();
    window.addEventListener('scroll', place, true);
    window.addEventListener('resize', place);
  }

  function clearHighlight() {
    target = null;
    if (box) box.style.display = 'none';
    window.removeEventListener('scroll', place, true);
    window.removeEventListener('resize', place);
  }

  function toast(text, ms = 1800) {
    ensureHost();
    toastEl.textContent = text;
    toastEl.style.display = 'block';
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { toastEl.style.display = 'none'; }, ms);
  }

  // For tests: the text of the visible toast, or '' when hidden.
  function toastText() {
    return toastEl && toastEl.style.display === 'block' ? toastEl.textContent : '';
  }

  function isHighlighted(el) {
    return target === el && !!box && box.style.display === 'block';
  }

  function destroy() {
    clearHighlight();
    clearTimeout(toastTimer);
    if (host) host.remove();
    host = null;
  }

  globalThis.FormFillerOverlay = {
    highlight,
    clearHighlight,
    toast,
    toastText,
    isHighlighted,
    destroy
  };
})();
