# Universal Form Autofiller

A Chrome extension (Manifest V3) for developers, QA testers and anyone who demos web apps. It fills any web form in one click with realistic test data: generated people, unique emails, gateway test cards and locale formats. You can also let Google Gemini fill a form that needs context (medical intake, insurance, questionnaires) using your own API key.

## Features

- **One-click fill**: fills text fields, selects, radios, checkboxes, dates and textareas. Works with React/Vue/Angular inputs, custom-styled checkboxes, shadow DOM and every frame on the page, including cross-origin iframes.
- **Rich-text editors**: `contenteditable` editors (Quill, Tiptap/ProseMirror, Draft.js, inline TinyMCE and similar) get realistic paragraph text, typed through the browser's editing pipeline so the editor notices. Undo and Clear work on them too.
- **Auto-fill on page load (per site)**: turn on **Auto-fill this site on load** in the popup and every page on that site is filled as soon as it loads, and again when a single-page app changes route. Only empty fields are filled, AI is never used, and a small toast tells you what happened and how to undo. Manage the list in Options → General.
- **Right-click a field**: **Fill this field** fills only that field (even if it already has a value). **Insert test value** types one value of your choice: full name, unique email, phone, street address, company, strong password, a paragraph, or an edge case (max length + 1, Unicode/emoji, RTL, leading/trailing spaces, XSS probe, SQL injection probe). Undo restores the previous value.
- **On-page result toast**: fills, undos and errors started from a keyboard shortcut or the right-click menu show a short message on the page, with the undo shortcut.
- **Fill as a chosen persona**: the popup's **Fill as** menu pins one persona for every fill, or rotates through them.
- **Generated test data**: a new, consistent person on every fill in 15 locales (US, CA, GB, IN, AU, DE, FR, ES, NL, BR, MX, JP, SG, AE, ZA), or 30 fixed personas you can edit.
- **Unique emails and usernames**: plus-addressing on your own inbox (`me+ff…@gmail.com`), timestamp or random suffixes, or a fixed value.
- **Gateway test cards**: Stripe, Braintree, Adyen and PayPal sandbox numbers by brand, including declined and 3-D Secure cards.
- **Keep / Change / Skip per field**: a side panel lists every field. Lock a value, change it on every fill, or skip it. Press `Alt + L` in a field to cycle its mode. Modes are kept for the 300 most recently changed pages; Options → General shows how many pages have modes and clears them.
- **Undo last fill** and **Clear**. Undo also brings back values removed by Clear.
- **Edge-case mode**: max-length strings, Unicode/emoji, RTL, SQL/XSS probe strings and invalid values for negative testing.
- **URL rules**: capture a form, choose fixed values per field, and save them for a URL pattern. Patterns support `*` wildcards (`https://*.example.com/signup*`), ignore query strings and `#hash`, and the most specific pattern wins.
- **Custom mappings**: map a label/name keyword to a fixed value.
- **Gemini AI fill (optional)**: pick Gemini 2.5 Flash, Flash-Lite, Pro or any custom model ID. **Test key** checks your key and lists every model it can use.
- **Export / Import**: save settings, profiles, mappings and URL rules to a JSON file and load them on another machine or share them with your team. The API key is never exported.

## Install (Load unpacked)

1. Download the ZIP and extract it to a folder you will keep (Chrome loads the extension from that folder).
2. Open `chrome://extensions` in Chrome (or Edge, Brave, or another Chromium browser).
3. Turn on **Developer mode** (top-right).
4. Click **Load unpacked** and choose the extracted folder (the one that contains `manifest.json`).
5. Pin the extension from the puzzle-piece menu so the toolbar icon is easy to reach.

To update, extract the new ZIP over the same folder and click the reload icon on the extension's card.

### Optional: Gemini AI

1. Get a free API key at [Google AI Studio](https://aistudio.google.com/apikey).
2. Open the popup, click **Options & Settings**, then go to **AI Configuration**.
3. Turn on **Enable Gemini AI Assistance**, paste the key, click **Test key**, pick a model and click **Save Settings**.

## How to use

- **Popup**: click the toolbar icon (or press `Alt + Shift + F`), then **Fill Current Form**, **Overwrite**, **Undo**, **Clear**, **Keep / Change…** or **Capture form** (for URL rules). **Fill as** picks the persona, and **Auto-fill this site on load** turns automatic filling on for the current site. The first time you open it, a short hint shows the basics; the popup also lists your current keyboard shortcuts.
- **Right-click menu**: fill the form you clicked, fill only the clicked field, insert a test value into it, overwrite, undo, clear, or open the side panel.
- **Keyboard shortcuts** (change them at `chrome://extensions/shortcuts`):

| Action | Windows / Linux | Mac |
|---|---|---|
| Open the popup | `Alt + Shift + F` | `Option + Shift + F` |
| Fill (respects "only fill empty fields") | `Ctrl + Shift + F` | `Control + Shift + F` |
| Fill using AI | `Ctrl + Shift + Y` | `Control + Shift + Y` |
| Undo last fill | `Alt + Shift + U` | `Option + Shift + U` |
| Fill (overwrite) | not bound by default | not bound by default |
| Cycle the focused field's mode | `Alt + L` | `Option + L` |

## Permissions

| Permission | Why it is needed |
|---|---|
| Read and change data on all websites (`<all_urls>`) | To find and fill form fields on any page you choose, including forms inside iframes. The extension only reads or changes fields when you start a fill, capture, use the side panel or `Alt + L`, or on a site where you turned on **Auto-fill this site on load**. |
| `activeTab`, `scripting` | To add the filler to tabs that were already open before the extension was installed or updated. |
| `webNavigation` | To find every frame on the page so forms inside iframes are filled too, and to know when a page on an auto-fill site has finished loading or a single-page app changed route. |
| `storage` | To save your settings, profiles, URL rules and per-field modes in your browser. The storage is restricted to the extension's own pages and background: content scripts on websites can't read it, and ask the background for the one page's field modes they need. |
| `contextMenus` | For the right-click menu (fill the form or one field, insert a test value, undo, clear, open the panel). |
| `sidePanel` | For the Keep / Change / Skip side panel. |
| `generativelanguage.googleapis.com` | Only used for AI fills and **Test key**, to call the Gemini API with your key. |

## Privacy

There is no server and no analytics. All data stays in your browser's extension storage. If you turn on AI, the Gemini API key is stored unencrypted in this browser's extension storage. That storage is closed to websites and to the extension's own scripts on them (only the options page, popup, side panel and background can read it), the key is never put in a page and never exported, and it is sent only to Google in a request header with each AI request. Gemini's answers only ever go into the form fields being filled. AI fills send field labels, names and options plus the page address (without query string) to Google. Field values, passwords and card fields are never sent.

## Development

```bash
npm install                     # dev tools only; nothing in node_modules ships with the extension
npx playwright install chromium # once, for the end-to-end tests
npm test                        # unit tests (Vitest + jsdom)
npm run e2e                     # end-to-end tests (serves tests/fixtures on localhost:4700 and 127.0.0.1:4701)
npm run lint                    # ESLint
npm run icons                   # regenerate icons/*.png
```
