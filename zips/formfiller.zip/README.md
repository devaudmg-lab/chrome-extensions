# Universal Form Autofiller

A Chrome extension (Manifest V3) for developers, QA testers and anyone who demos web apps. It fills any web form in one click with realistic test data: generated people, unique emails, gateway test cards and locale formats. You can also let Google Gemini fill a form that needs context (medical intake, insurance, questionnaires) using your own API key.

## Features

- **One-click fill**: fills text fields, selects, radios, checkboxes, dates and textareas. Works with React/Vue/Angular inputs, custom-styled checkboxes, shadow DOM and every frame on the page, including cross-origin iframes.
- **Generated test data**: a new, consistent person on every fill in 15 locales (US, CA, GB, IN, AU, DE, FR, ES, NL, BR, MX, JP, SG, AE, ZA), or 30 fixed personas you can edit.
- **Unique emails and usernames**: plus-addressing on your own inbox (`me+ff…@gmail.com`), timestamp or random suffixes, or a fixed value.
- **Gateway test cards**: Stripe, Braintree, Adyen and PayPal sandbox numbers by brand, including declined and 3-D Secure cards.
- **Keep / Change / Skip per field**: a side panel lists every field. Lock a value, change it on every fill, or skip it. Press `Alt + L` in a field to cycle its mode.
- **Undo last fill** and **Clear** (only fields the extension filled).
- **Edge-case mode**: max-length strings, Unicode/emoji, RTL, SQL/XSS probe strings and invalid values for negative testing.
- **URL rules**: capture a form, choose fixed values per field, and save them for a URL pattern. Patterns support `*` wildcards (`https://*.example.com/signup*`), ignore query strings and `#hash`, and the most specific pattern wins.
- **Custom mappings**: map a label/name keyword to a fixed value.
- **Gemini AI fill (optional)**: pick Gemini 2.5 Flash, Flash-Lite, Pro or any custom model ID. **Test key** checks your key and lists every model it can use.
- **Export / Import**: save settings, profiles, mappings and URL rules to a JSON file and load them on another machine or share them with your team. The API key is never exported.

## Install (Load unpacked)

1. Download the ZIP and extract it to a folder you will keep (Chrome loads the extension from that folder).
2. Open `chrome://extensions` in Chrome (or Edge, Brave, or another Chromium browser).
3. Turn on **Developer mode** (top-right).
4. Click **Load unpacked** and choose the extracted folder (the one that contains `manifest.json`).
5. Pin the extension from the puzzle-piece menu so the toolbar icon is easy to reach.

To update, extract the new ZIP over the same folder and click the reload icon on the extension's card.

### Optional: Gemini AI

1. Get a free API key at [Google AI Studio](https://aistudio.google.com/apikey).
2. Open the popup, click **Options & Settings**, then go to **AI Configuration**.
3. Turn on **Enable Gemini AI Assistance**, paste the key, click **Test key**, pick a model and click **Save Settings**.

## How to use

- **Popup**: click the toolbar icon, then **Fill Current Form**, **Fill (overwrite)**, **Undo last fill**, **Keep / Change fields…** or **Capture Form Structure** (for URL rules).
- **Right-click menu**: fill the form you clicked, overwrite, undo, clear, or open the side panel.
- **Keyboard shortcuts** (change them at `chrome://extensions/shortcuts`):

| Action | Windows / Linux | Mac |
|---|---|---|
| Fill (respects "only fill empty fields") | `Ctrl + Shift + F` | `Control + Shift + F` |
| Fill using AI | `Ctrl + Shift + Y` | `Control + Shift + Y` |
| Undo last fill | `Alt + Shift + U` | `Option + Shift + U` |
| Fill (overwrite) | not bound by default | not bound by default |
| Cycle the focused field's mode | `Alt + L` | `Option + L` |

## Permissions

| Permission | Why it is needed |
|---|---|
| Read and change data on all websites (`<all_urls>`) | To find and fill form fields on any page you choose, including forms inside iframes. The extension only reads or changes fields when you start a fill, capture, or use the side panel or `Alt + L`. |
| `activeTab`, `scripting` | To add the filler to tabs that were already open before the extension was installed or updated. |
| `webNavigation` | To find every frame on the page so forms inside iframes are filled too. |
| `storage` | To save your settings, profiles, URL rules and per-field modes in your browser. |
| `contextMenus` | For the right-click menu. |
| `sidePanel` | For the Keep / Change / Skip side panel. |
| `generativelanguage.googleapis.com` | Only used for AI fills and **Test key**, to call the Gemini API with your key. |

## Privacy

There is no server and no analytics. All data stays in your browser's extension storage. If you turn on AI, the Gemini API key is stored unencrypted in this browser's extension storage and sent to Google with each AI request. AI fills send field labels, names and options plus the page address (without query string) to Google. Field values, passwords and card fields are never sent.

## Development

```bash
npm install                     # dev tools only; nothing in node_modules ships with the extension
npx playwright install chromium # once, for the end-to-end tests
npm test                        # unit tests (Vitest + jsdom)
npm run e2e                     # end-to-end tests (serves tests/fixtures on localhost:4700 and 127.0.0.1:4701)
npm run lint                    # ESLint
npm run icons                   # regenerate icons/*.png
```
