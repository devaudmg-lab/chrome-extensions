// SEO Rank Finder Background Service Worker
importScripts('shared.js');

const SCHEDULE_ALARM = 'scheduledRankCheck';
const SCHEDULE_PERIODS = { daily: 24 * 60, weekly: 7 * 24 * 60 };
// Politeness limits for unattended (scheduled / "Check all now") runs
const TRACKED_MAX_PAGES = 60;                 // result pages loaded per run, at most
const TRACKED_PAGE_DELAY = [2500, 5000];      // ms between result pages of one keyword
const TRACKED_KEYWORD_DELAY = [8000, 20000];  // ms between keywords
const MANUAL_PAGE_DELAY = [1200, 3000];
const CAPTCHA_BACKOFF_BASE = 6 * 60 * 60 * 1000; // 6 h, doubled per CAPTCHA in a row
const CAPTCHA_BACKOFF_MAX = 48 * 60 * 60 * 1000;

// Time of the last manual scan request, so a scheduled run doesn't overlap it
let lastManualScanAt = 0;
let trackedRunning = false;
// Each scan job has its own cancel flag, so stopping a manual scan never stops
// the tracked run and vice versa
let manualJob = { cancelled: false };
let trackedJob = { cancelled: false };

// Open side panel when icon is clicked
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch((error) => console.error(error));

const escapeRegExp = (str) => str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const randomBetween = ([min, max]) => min + Math.random() * (max - min);

// Sleep that wakes early when the job is cancelled
function sleep(ms, job) {
    return new Promise((resolve) => {
        const end = Date.now() + ms;
        const tick = () => {
            if ((job && job.cancelled) || Date.now() >= end) return resolve();
            setTimeout(tick, Math.min(500, end - Date.now()));
        };
        tick();
    });
}

// Only one Google results tab is ever loading at a time, whoever asked for it
let serpChain = Promise.resolve();
let serpBusy = false;
function withSerpLock(fn) {
    const run = serpChain.then(async () => {
        serpBusy = true;
        try { return await fn(); } finally { serpBusy = false; }
    });
    serpChain = run.catch(() => { });
    return run;
}

// Punycode the host part of a target so "bücher.de" matches "xn--bcher-kva.de"
function targetForMatching(target) {
    const clean = normalizeTarget(target);
    if (!clean) return '';
    const slash = clean.indexOf('/');
    const host = slash === -1 ? clean : clean.slice(0, slash);
    const path = slash === -1 ? '' : clean.slice(slash);
    try {
        const u = new URL('http://' + host + (path || '/'));
        return u.host + (path ? u.pathname.replace(/\/+$/, '') : '');
    } catch (e) {
        return clean;
    }
}

// Check if a URL matches any of the target domains accurately.
// "example.com" matches example.com and its subdomains; "example.com/blog" matches that path prefix.
function getMatch(foundUrl, targets) {
    const found = foundUrl.toLowerCase().replace(/^(https?:\/\/)?(www\.)?/, '');
    for (const target of targets) {
        const targetClean = targetForMatching(target);
        if (!targetClean) continue;
        const domainPattern = new RegExp(`(^|\\.)` + escapeRegExp(targetClean) + `([/?#:]|$)`);
        if (domainPattern.test(found)) {
            return target;
        }
    }
    return null;
}

// Google's own navigation, cache and translate links are not results; other
// Google properties (support.google.com, blog.google, ...) can be.
function isGoogleChrome(url) {
    let host;
    try { host = new URL(url).hostname; } catch (e) { return true; }
    return /^(www\.)?google\.[a-z.]+$/.test(host) ||
        /^(webcache|translate|accounts|policies|maps|consent)\.google(usercontent)?\.[a-z.]+$/.test(host);
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    // Only our own pages talk to the worker (no content scripts, no external senders)
    if (sender.id !== chrome.runtime.id || !String(sender.url || '').startsWith(chrome.runtime.getURL(''))) return false;
    switch (request.action) {
        case 'cancelScan':
            manualJob.cancelled = true;
            sendResponse({ ok: true });
            return false;
        case 'cancelTracked':
            trackedJob.cancelled = true;
            sendResponse({ ok: true });
            return false;
        case 'scheduleChanged':
            applySchedule().then(() => sendResponse({ ok: true }), () => sendResponse({ ok: false }));
            return true;
        case 'runTrackedNow':
            if (trackedRunning) {
                sendResponse({ ok: false, error: 'A tracked-keyword check is already running.' });
                return false;
            }
            runScheduledCheck(true).catch(e => console.error('Tracked check failed:', e));
            sendResponse({ ok: true });
            return false;
        case 'updateTracked':
            updateRankEntry(String(request.id), request.remove ? null : { tracked: !!request.tracked })
                .then(ok => sendResponse({ ok }), () => sendResponse({ ok: false }));
            return true;
        case 'findRank':
            handleFindRank(request).then(sendResponse, (error) => {
                console.error('Background search error:', error);
                sendResponse({ found: false, error: 'Search failed.' });
            });
            return true;
        default:
            return false;
    }
});

async function handleFindRank(request) {
    lastManualScanAt = Date.now();
    const job = { cancelled: false };
    manualJob = job;
    const targets = (Array.isArray(request.targetUrl) ? request.targetUrl : [request.targetUrl])
        .map(normalizeTarget).filter(Boolean);
    const keyword = String(request.keyword || '').trim().slice(0, 300);
    if (!targets.length || !keyword) return { found: false, error: 'Enter a valid website and keyword.' };
    const mode = request.mode === 'broad' ? 'broad' : 'strict';
    const country = /^[a-z]{2}$/.test(request.country || '') ? request.country : '';
    const maxPages = Math.min(10, Math.max(1, parseInt(request.maxPages, 10) || 10));

    if (serpBusy || trackedRunning) sendProgress('manual', 'Waiting for the tracked-keyword check...');
    const res = await withSerpLock(() => {
        lastManualScanAt = Date.now();
        return findRanking(keyword, targets, country, mode, maxPages, job, { kind: 'manual' });
    });

    // Save the primary target's result to history (skipped for stopped or failed scans)
    if (request.record && !res.error && !res.cancelled) {
        const primary = (res.matches || []).find(m => m.target === targets[0]);
        const { prev } = await recordRank({
            target: targets[0], keyword, country, mode, depth: maxPages,
            rank: primary ? primary.position : null, url: primary ? primary.url : '', date: Date.now()
        });
        res.prev = prev;
        res.recorded = true;
    }
    return res;
}

function sendProgress(kind, status) {
    chrome.runtime.sendMessage({ action: 'progress', kind, status }).catch(() => { });
}

// Google no longer serves result HTML to plain fetch() requests (it returns an
// "enable JavaScript" interstitial), so each SERP page is loaded in a background
// tab and the rendered result links are read with chrome.scripting.

// Runs inside the Google results page. Must be self-contained.
// Selectors are layered from the most specific (current Google markup) to the
// most generic, so a class rename degrades gracefully instead of finding nothing.
function extractSerpResults(mode) {
    if (location.pathname.startsWith('/sorry') ||
        document.querySelector('#captcha-form, form[action*="/sorry/"], #recaptcha, iframe[src*="/recaptcha/"]')) {
        return { captcha: true };
    }
    const AD_SCOPES = '#tads, #tadsb, #bottomads, [data-text-ad], .commercial-unit-desktop-top, .commercial-unit-desktop-rhs, .cu-container, .pla-unit';
    const TITLE = 'h3, [role="heading"][aria-level="3"]';
    const strict = mode === 'strict';
    const root = strict
        ? (document.querySelector('#rso') || document.querySelector('#search') || document.querySelector('#center_col') || document.body)
        : document.body;
    const hasTitle = (a) => !!a.querySelector(TITLE);
    const usable = (a) => !a.closest(AD_SCOPES) && (!strict || !a.closest('.related-question-pair'));
    const inOrder = (list) => Array.from(new Set(list)).sort((a, b) =>
        (a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING) ? -1 : 1);

    let anchors;
    if (strict) {
        anchors = inOrder([
            ...root.querySelectorAll('.yuRUbf a[href], .MjjYud a[href]'),
            ...root.querySelectorAll('a[jsname="UWckNb"][href]'),
            ...root.querySelectorAll('div.g a[href], [data-hveid] > div a[href]')
        ].filter(a => a.querySelector('h3') && usable(a)));
        if (anchors.length === 0) anchors = Array.from(root.querySelectorAll('a[href]')).filter(a => hasTitle(a) && usable(a));
    } else {
        anchors = Array.from(root.querySelectorAll('a[href]')).filter(a => hasTitle(a) && usable(a));
    }
    // Collapsed or hidden blocks (e.g. unopened People Also Ask answers) are not on the page for a user
    const visible = anchors.filter(a => a.getClientRects().length > 0);
    if (visible.length) anchors = visible;

    // Google may obfuscate result hrefs (/goto?url=<token>); fall back to the visible <cite> breadcrumb
    const urlFromCite = (a) => {
        const scope = a.closest('.yuRUbf, .MjjYud, div.g') || a.parentElement;
        const cite = a.querySelector('cite') || (scope && scope.querySelector('cite'));
        if (!cite) return null;
        const parts = cite.textContent.split('›').map(p => p.trim()).filter(Boolean);
        if (parts.length === 0) return null;
        const host = /^https?:\/\//.test(parts[0]) ? parts[0] : 'https://' + parts[0];
        return [host].concat(parts.slice(1).map(p => p.replace(/(\.\.\.|…)$/, ''))).join('/');
    };
    const results = anchors.map((a) => {
        let type = 'organic';
        if (a.closest('.ULSxy, .v5y61, .xpdopen, [data-attrid="wa:/description"]')) type = 'snippet';
        if (a.closest('.related-question-pair')) type = 'paa';
        let url = a.href;
        try {
            const u = new URL(url);
            if (/(^|\.)google\./.test(u.hostname) && u.pathname === '/goto') url = urlFromCite(a) || url;
        } catch (e) { /* keep raw href */ }
        return { url, type };
    });

    // Pagination: a "Next" link means more pages. No pager at all (layout change)
    // is reported as unknown so the caller can decide from the result count.
    const current = parseInt(new URLSearchParams(location.search).get('start') || '0', 10) || 0;
    const pageLinks = Array.from(document.querySelectorAll('a[href*="start="]')).filter((a) => {
        try { const u = new URL(a.href); return u.pathname === '/search' && u.searchParams.has('start'); } catch (e) { return false; }
    });
    const hasNext = !!document.querySelector('#pnnext, a[aria-label="Next page"], a[aria-label="Next"]') ||
        pageLinks.some(a => (parseInt(new URL(a.href).searchParams.get('start'), 10) || 0) > current);
    const pagerFound = hasNext || pageLinks.length > 0 || !!document.querySelector('#pnprev, a[aria-label^="Page "]');
    return { captcha: false, results, hasNext, pagerFound };
}

// Navigate a tab and resolve once the new page has finished loading
function loadInTab(tabId, url) {
    return new Promise((resolve, reject) => {
        let sawLoading = false;
        const timer = setTimeout(() => { cleanup(); reject(new Error('Timed out loading Google results.')); }, 30000);
        const listener = (id, info) => {
            if (id !== tabId) return;
            if (info.status === 'loading') sawLoading = true;
            if (info.status === 'complete' && sawLoading) { cleanup(); resolve(); }
        };
        const onRemoved = (id) => {
            if (id === tabId) { cleanup(); reject(new Error('The results tab was closed.')); }
        };
        const cleanup = () => {
            clearTimeout(timer);
            chrome.tabs.onUpdated.removeListener(listener);
            chrome.tabs.onRemoved.removeListener(onRemoved);
        };
        chrome.tabs.onUpdated.addListener(listener);
        chrome.tabs.onRemoved.addListener(onRemoved);
        chrome.tabs.update(tabId, { url }).catch((e) => { cleanup(); reject(e); });
    });
}

// Scan tabs are remembered in session storage so a worker restart mid-scan can
// close the orphans instead of leaving Google tabs behind.
async function trackScanTab(tabId, add) {
    const { scanTabs = [] } = await chrome.storage.session.get('scanTabs');
    const next = add ? [...new Set([...scanTabs, tabId])] : scanTabs.filter(id => id !== tabId);
    await chrome.storage.session.set({ scanTabs: next });
}

async function closeOrphanScanTabs() {
    if (serpBusy) return;
    const { scanTabs = [] } = await chrome.storage.session.get('scanTabs');
    if (!scanTabs.length) return;
    await chrome.storage.session.set({ scanTabs: [] });
    scanTabs.forEach(id => chrome.tabs.remove(id).catch(() => { }));
}

// opts.kind: 'manual' | 'tracked'. Tracked runs never steal focus: a CAPTCHA tab
// stays in the background and the user is told by notification instead.
async function findRanking(keyword, targets, country, mode, maxPages, job, opts = {}) {
    const kind = opts.kind || 'manual';
    const pageDelay = kind === 'tracked' ? TRACKED_PAGE_DELAY : MANUAL_PAGE_DELAY;
    const maxResults = maxPages * 10;
    const resultsPerPage = 10;
    const allOrganicResults = [];
    const foundMatches = [];
    const seenUrls = new Set();
    let pages = 0;

    if (job.cancelled) return { found: false, matches: [], cancelled: true, scanned: 0, pages };
    const scanTab = await chrome.tabs.create({ url: 'about:blank', active: false });
    await trackScanTab(scanTab.id, true).catch(() => { });
    let keepTabOpen = false;
    // Let the blank tab settle so its own load events are not mistaken for the first SERP load
    for (let i = 0; i < 20 && (await chrome.tabs.get(scanTab.id)).status !== 'complete'; i++) {
        await new Promise(resolve => setTimeout(resolve, 100));
    }

    const blocked = async (error, captcha) => {
        keepTabOpen = true;
        if (kind === 'manual') chrome.tabs.update(scanTab.id, { active: true }).catch(() => { });
        await chrome.storage.local.set({ captchaTabId: scanTab.id });
        return { found: false, error, captcha, pages };
    };

    try {
        for (let start = 0; start < maxResults; start += resultsPerPage) {
            if (job.cancelled) {
                return { found: foundMatches.length > 0, matches: foundMatches, cancelled: true, scanned: allOrganicResults.length, pages };
            }
            if (opts.onPage) opts.onPage(Math.floor(start / 10) + 1);
            sendProgress(kind, `Scanning Page ${Math.floor(start / 10) + 1}/${maxPages}...`);

            let searchUrl = `https://www.google.com/search?q=${encodeURIComponent(keyword)}&start=${start}`;
            if (country) {
                searchUrl += `&gl=${country}&hl=en`;
            }

            await loadInTab(scanTab.id, searchUrl);
            pages++;

            let page;
            try {
                const [injection] = await chrome.scripting.executeScript({
                    target: { tabId: scanTab.id },
                    func: extractSerpResults,
                    args: [mode]
                });
                page = injection && injection.result;
            } catch (e) {
                // Usually a redirect away from www.google.com (e.g. the consent screen)
                return blocked('Could not read Google results. Open google.com, accept any consent prompt, and try again.', false);
            }

            if (!page || page.captcha) {
                return blocked(kind === 'manual'
                    ? 'Google CAPTCHA detected. The results tab has been opened for you to solve it. Please solve the CAPTCHA and try again.'
                    : 'Google CAPTCHA detected.', true);
            }

            for (const result of page.results) {
                let url = result.url;
                if (/^https?:\/\/(www\.)?google\.[^/]+\/url\?/.test(url)) {
                    try { url = new URL(url).searchParams.get('q') || new URL(url).searchParams.get('url'); } catch (e) { continue; }
                }
                if (!url || !/^https?:/.test(url) || isGoogleChrome(url) || seenUrls.has(url)) continue;
                if (allOrganicResults.length >= maxResults) break;
                seenUrls.add(url);
                allOrganicResults.push(url);

                const matchedTarget = getMatch(url, targets);
                if (matchedTarget) {
                    foundMatches.push({
                        url: url,
                        target: matchedTarget,
                        position: allOrganicResults.length,
                        page: Math.ceil(allOrganicResults.length / 10),
                        type: result.type
                    });
                }
            }

            // Stop at the last page, or when the pager is missing and the page was thin
            if (page.results.length === 0) break;
            if (!page.hasNext && (page.pagerFound || page.results.length < 5)) break;
            if (start + resultsPerPage < maxResults) await sleep(randomBetween(pageDelay), job);
        }
    } finally {
        if (!keepTabOpen) chrome.tabs.remove(scanTab.id).catch(() => { });
        trackScanTab(scanTab.id, false).catch(() => { });
    }

    return foundMatches.length > 0
        ? { found: true, matches: foundMatches, scanned: allOrganicResults.length, pages }
        : { found: false, scanned: allOrganicResults.length, pages };
}

// ---------------------------------------------------------------------------
// Scheduled re-checks of tracked keywords (chrome.alarms + chrome.notifications)
// ---------------------------------------------------------------------------

// (Re)create the alarm. Alarms can be lost on browser or extension updates, so
// the next run is computed from the last run instead of restarting the period.
async function applySchedule() {
    const { schedule, lastScheduledRun } = await chrome.storage.local.get(['schedule', 'lastScheduledRun']);
    const period = SCHEDULE_PERIODS[schedule];
    const existing = await chrome.alarms.get(SCHEDULE_ALARM);
    if (!period) {
        if (existing) await chrome.alarms.clear(SCHEDULE_ALARM);
        return;
    }
    if (existing && existing.periodInMinutes === period) return;
    const sinceLast = lastScheduledRun ? (Date.now() - lastScheduledRun) / 60000 : 0;
    const delay = lastScheduledRun ? Math.max(1, period - sinceLast) : period;
    await chrome.alarms.create(SCHEDULE_ALARM, { delayInMinutes: delay, periodInMinutes: period });
}

chrome.runtime.onInstalled.addListener(() => { applySchedule(); });
chrome.runtime.onStartup.addListener(() => { applySchedule(); });

chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === SCHEDULE_ALARM) runScheduledCheck(false).catch(e => console.error('Scheduled check failed:', e));
});

// A fresh worker is never in the middle of a run: clear a "running" status and
// scan tabs left behind by a worker that was shut down mid-scan.
(async () => {
    const { scheduleStatus } = await chrome.storage.local.get('scheduleStatus');
    if (scheduleStatus && scheduleStatus.running && !trackedRunning) {
        await chrome.storage.local.set({ scheduleStatus: { ...scheduleStatus, running: false, message: 'The last check was interrupted.', updated: Date.now() } });
    }
    await closeOrphanScanTabs();
})().catch(() => { });

function setScheduleStatus(status) {
    return chrome.storage.local.set({ scheduleStatus: { ...status, updated: Date.now() } });
}

function notify(id, title, message) {
    chrome.notifications.create(id, {
        type: 'basic',
        iconUrl: chrome.runtime.getURL('icons/icon128.png'),
        title,
        message,
        priority: 0
    }, () => void chrome.runtime.lastError);
}

async function runScheduledCheck(manual) {
    if (trackedRunning) return;
    trackedRunning = true; // set synchronously so two quick triggers cannot both start
    const job = { cancelled: false };
    trackedJob = job;
    try {
        await runTrackedKeywords(manual, job);
    } finally {
        trackedRunning = false;
    }
}

async function runTrackedKeywords(manual, job) {
    const stored = await chrome.storage.local.get(['captchaBackoffUntil', 'captchaStrikes', 'notifyMode']);
    if (!manual) {
        // Don't compete with a scan the user started in the last 5 minutes
        if (Date.now() - lastManualScanAt < 5 * 60 * 1000) return;
        // Back off after a CAPTCHA instead of hammering Google on every alarm
        if ((stored.captchaBackoffUntil || 0) > Date.now()) {
            await setScheduleStatus({
                running: false, lastRun: Date.now(),
                message: `Skipped: Google asked for a CAPTCHA recently. Automatic checks resume after ${new Date(stored.captchaBackoffUntil).toLocaleString()}.`
            });
            return;
        }
    }
    await chrome.storage.local.set({ lastScheduledRun: Date.now() });

    const all = await getRankHistory();
    const entries = Object.entries(all)
        .filter(([, e]) => e && e.tracked !== false && e.keyword && e.target)
        .sort((a, b) => (a[1].lastChecked || 0) - (b[1].lastChecked || 0))
        .slice(0, SCHEDULE_MAX_KEYWORDS)
        .map(([id, e]) => ({ id, ...e }));
    if (entries.length === 0) {
        await setScheduleStatus({ running: false, lastRun: Date.now(), message: 'No keywords are set to auto-check.' });
        return;
    }

    const notifyMode = stored.notifyMode || 'any';
    const changes = [];
    let checked = 0;
    let pagesUsed = 0;
    let stopReason = '';
    let captcha = false;
    for (const entry of entries) {
        if (job.cancelled) { stopReason = 'Stopped.'; break; }
        const depth = Math.min(10, Math.max(1, entry.depth || 10));
        // Page budget: what doesn't fit now is checked first next time (oldest first)
        if (checked > 0 && pagesUsed + depth > TRACKED_MAX_PAGES) {
            stopReason = `Paused at the ${TRACKED_MAX_PAGES}-page limit per run; the rest are checked next time.`;
            break;
        }
        const label = `Checking ${checked + 1}/${entries.length}: "${entry.keyword}"`;
        await setScheduleStatus({ running: true, message: label });
        let res;
        try {
            res = await withSerpLock(() => findRanking(entry.keyword, [entry.target], entry.country, entry.mode, depth, job, {
                kind: 'tracked',
                // Heartbeat so the panel can tell a live run from a dead one
                onPage: (n) => { setScheduleStatus({ running: true, message: `${label} (page ${n})` }); }
            }));
        } catch (e) {
            stopReason = /closed/.test(e.message || '') ? 'The results tab was closed.' : 'Could not open a background tab (is a Chrome window open?).';
            break;
        }
        pagesUsed += res.pages || 0;
        if (res.cancelled) { stopReason = 'Stopped.'; break; }
        if (res.error) {
            captcha = !!res.captcha;
            stopReason = captcha
                ? 'Google asked for a CAPTCHA. Solve it in the Google tab, then click "Check all now".'
                : res.error;
            break;
        }
        const match = (res.matches || []).find(m => m.target === entry.target);
        const newRank = match ? match.position : null;
        const { prev } = await recordRank({
            target: entry.target, keyword: entry.keyword, country: entry.country, mode: entry.mode,
            depth, rank: newRank, url: match ? match.url : '', date: Date.now()
        });
        checked++;
        const change = describeChange(prev ? prev.rank : null, newRank);
        if (prev && change.direction !== 'same') {
            changes.push({
                keyword: entry.keyword, from: prev.rank, to: newRank, direction: change.direction,
                notable: isNotableChange(prev.rank, newRank, notifyMode)
            });
        }
        if (entry !== entries[entries.length - 1]) await sleep(randomBetween(TRACKED_KEYWORD_DELAY), job);
    }

    // CAPTCHA backoff: 6 h, 12 h, 24 h, 48 h max; a clean run resets it
    if (captcha) {
        const strikes = (stored.captchaStrikes || 0) + 1;
        await chrome.storage.local.set({
            captchaStrikes: strikes,
            captchaBackoffUntil: Date.now() + Math.min(CAPTCHA_BACKOFF_MAX, CAPTCHA_BACKOFF_BASE * 2 ** (strikes - 1))
        });
    } else if (checked > 0 && (stored.captchaStrikes || stored.captchaBackoffUntil)) {
        await chrome.storage.local.remove(['captchaStrikes', 'captchaBackoffUntil']);
    }

    const summary = stopReason
        ? `Checked ${checked} of ${entries.length}. ${stopReason}`
        : `Checked ${checked} keyword${checked === 1 ? '' : 's'}. ${changes.length ? `${changes.length} changed.` : 'No changes.'}`;
    await setScheduleStatus({ running: false, lastRun: Date.now(), message: summary, changes });

    const fmt = (r) => (r ? `#${r}` : 'not found');
    const notable = changes.filter(c => c.notable);
    if (notable.length) {
        const lines = notable.slice(0, 4).map(c => `${c.direction === 'up' ? '▲' : '▼'} ${c.keyword}: ${fmt(c.from)} → ${fmt(c.to)}`);
        if (notable.length > 4) lines.push(`+${notable.length - 4} more`);
        notify('rank-changes', `${notable.length} ranking${notable.length === 1 ? '' : 's'} changed`, lines.join('\n'));
    } else if (stopReason && stopReason !== 'Stopped.') {
        notify(captcha ? 'rank-check-captcha' : 'rank-check-stopped', captcha ? 'Google asked for a CAPTCHA' : 'Rank check paused', summary);
    } else if (manual && !stopReason && notifyMode !== 'off') {
        notify('rank-check-done', 'Rank check complete', summary);
    }
}

// CAPTCHA notification: bring the Google tab forward. Others: open the tracked view.
chrome.notifications.onClicked.addListener(async (id) => {
    chrome.notifications.clear(id);
    if (id === 'rank-check-captcha') {
        const { captchaTabId } = await chrome.storage.local.get('captchaTabId');
        const tab = captchaTabId ? await chrome.tabs.get(captchaTabId).catch(() => null) : null;
        if (tab) {
            await chrome.tabs.update(tab.id, { active: true }).catch(() => { });
            await chrome.windows.update(tab.windowId, { focused: true }).catch(() => { });
            return;
        }
        chrome.tabs.create({ url: 'https://www.google.com/' });
        return;
    }
    const win = await chrome.windows.getLastFocused({}).catch(() => null);
    if (!win) return;
    chrome.sidePanel.open({ windowId: win.id }).catch(() => {
        chrome.tabs.create({ url: chrome.runtime.getURL('popup.html#tracked') });
    });
});
