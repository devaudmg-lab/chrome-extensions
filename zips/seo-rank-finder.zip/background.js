// SEO Rank Finder Background Service Worker
importScripts('shared.js');

const SCHEDULE_ALARM = 'scheduledRankCheck';
const SCHEDULE_PERIODS = { daily: 24 * 60, weekly: 7 * 24 * 60 };
// Time of the last manual scan request, so a scheduled run doesn't overlap it
let lastManualScanAt = 0;
let scheduledRunning = false;

// Open side panel when icon is clicked
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch((error) => console.error(error));

// Set when the side panel asks to stop the running scan
let cancelRequested = false;

const escapeRegExp = (str) => str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

// Helper function to check if a URL matches any of the target domains accurately.
// "example.com" matches example.com and its subdomains; "example.com/blog" matches that path prefix.
function getMatch(foundUrl, targets) {
    const found = foundUrl.toLowerCase().replace(/^(https?:\/\/)?(www\.)?/, '');
    for (const target of targets) {
        const targetClean = target.toLowerCase().trim().replace(/^(https?:\/\/)?(www\.)?/, '').replace(/\/+$/, '');
        if (!targetClean) continue;
        const domainPattern = new RegExp(`(^|\\.)` + escapeRegExp(targetClean) + `([/?#:]|$)`);
        if (domainPattern.test(found)) {
            return target;
        }
    }
    return null;
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'cancelScan') {
        cancelRequested = true;
        sendResponse({ ok: true });
        return false;
    }
    if (request.action === 'scheduleChanged') {
        applySchedule().then(() => sendResponse({ ok: true }));
        return true;
    }
    if (request.action === 'runTrackedNow') {
        if (scheduledRunning) {
            sendResponse({ ok: false, error: 'A tracked-keyword check is already running.' });
            return false;
        }
        runScheduledCheck(true);
        sendResponse({ ok: true });
        return false;
    }
    if (request.action === 'findRank') {
        cancelRequested = false;
        lastManualScanAt = Date.now();
        const targets = Array.isArray(request.targetUrl) ? request.targetUrl : [request.targetUrl];
        const maxPages = Math.min(10, Math.max(1, parseInt(request.maxPages, 10) || 10));
        findRanking(request.keyword, targets, request.country, request.mode, maxPages)
            .then(sendResponse)
            .catch(error => {
                console.error('Background search error:', error);
                sendResponse({ found: false, error: 'Search failed.' });
            });
        return true;
    }
});

// Google no longer serves result HTML to plain fetch() requests (it returns an
// "enable JavaScript" interstitial), so each SERP page is loaded in a background
// tab and the rendered result links are read with chrome.scripting.

// Runs inside the Google results page. Must be self-contained.
function extractSerpResults(mode) {
    if (location.pathname.startsWith('/sorry') || document.querySelector('#captcha-form, form[action*="/sorry/"]')) {
        return { captcha: true };
    }
    const root = mode === 'strict' ? (document.querySelector('#search') || document.body) : document.body;
    const withTitle = (a) => a.querySelector('h3');
    let anchors = [];
    if (mode === 'strict') {
        anchors = Array.from(root.querySelectorAll('.yuRUbf a[href], .MjjYud a[href]')).filter(withTitle);
        if (anchors.length === 0) anchors = Array.from(root.querySelectorAll('a[href]')).filter(withTitle);
    } else {
        anchors = Array.from(root.querySelectorAll('a[href]')).filter(withTitle);
    }
    // Google may obfuscate result hrefs (/goto?url=<token>); fall back to the visible <cite> breadcrumb
    const urlFromCite = (a) => {
        const scope = a.closest('.yuRUbf, .MjjYud') || a.parentElement;
        const cite = a.querySelector('cite') || (scope && scope.querySelector('cite'));
        if (!cite) return null;
        const parts = cite.textContent.split('›').map(p => p.trim()).filter(Boolean);
        if (parts.length === 0) return null;
        const host = /^https?:\/\//.test(parts[0]) ? parts[0] : 'https://' + parts[0];
        return [host].concat(parts.slice(1).map(p => p.replace(/(\.\.\.|…)$/, ''))).join('/');
    };
    const results = anchors.map((a) => {
        let type = 'organic';
        if (a.closest('.ULSxy, .v5y61')) type = 'snippet';
        if (a.closest('.related-question-pair')) type = 'paa';
        let url = a.href;
        try {
            const u = new URL(url);
            if (/(^|\.)google\./.test(u.hostname) && u.pathname === '/goto') url = urlFromCite(a) || url;
        } catch (e) { /* keep raw href */ }
        return { url, type };
    });
    return { captcha: false, results, hasNext: !!document.querySelector('#pnnext') };
}

// Navigate a tab and resolve once the new page has finished loading
function loadInTab(tabId, url) {
    return new Promise((resolve, reject) => {
        let sawLoading = false;
        const timer = setTimeout(() => { cleanup(); reject(new Error('Timed out loading Google results.')); }, 30000);
        const listener = (id, info) => {
            if (id !== tabId) return;
            if (info.status === 'loading') sawLoading = true;
            if (info.status === 'complete' && sawLoading) { cleanup(); resolve(); }
        };
        const cleanup = () => { clearTimeout(timer); chrome.tabs.onUpdated.removeListener(listener); };
        chrome.tabs.onUpdated.addListener(listener);
        chrome.tabs.update(tabId, { url }).catch((e) => { cleanup(); reject(e); });
    });
}

async function findRanking(keyword, targets, country, mode, maxPages = 10) {
    const maxResults = maxPages * 10;
    const resultsPerPage = 10;
    const allOrganicResults = [];
    const foundMatches = [];
    const seenUrls = new Set();

    const scanTab = await chrome.tabs.create({ url: 'about:blank', active: false });
    let keepTabOpen = false;
    // Let the blank tab settle so its own load events are not mistaken for the first SERP load
    for (let i = 0; i < 20 && (await chrome.tabs.get(scanTab.id)).status !== 'complete'; i++) {
        await new Promise(resolve => setTimeout(resolve, 100));
    }

    try {
        for (let start = 0; start < maxResults; start += resultsPerPage) {
            if (cancelRequested) {
                return { found: foundMatches.length > 0, matches: foundMatches, cancelled: true, scanned: allOrganicResults.length };
            }
            chrome.runtime.sendMessage({
                action: 'progress',
                status: `Scanning Page ${Math.floor(start / 10) + 1}/${maxPages}...`
            }).catch(() => { });

            let searchUrl = `https://www.google.com/search?q=${encodeURIComponent(keyword)}&start=${start}`;
            if (country) {
                searchUrl += `&gl=${country}&hl=en`;
            }

            await loadInTab(scanTab.id, searchUrl);

            let page;
            try {
                const [injection] = await chrome.scripting.executeScript({
                    target: { tabId: scanTab.id },
                    func: extractSerpResults,
                    args: [mode]
                });
                page = injection && injection.result;
            } catch (e) {
                // Usually a redirect away from www.google.com (e.g. the consent screen)
                keepTabOpen = true;
                chrome.tabs.update(scanTab.id, { active: true }).catch(() => { });
                return {
                    found: false,
                    error: 'Could not read Google results. Open google.com, accept any consent prompt, and try again.'
                };
            }

            if (!page || page.captcha) {
                keepTabOpen = true;
                chrome.tabs.update(scanTab.id, { active: true }).catch(() => { });
                return {
                    found: false,
                    error: 'Google CAPTCHA detected. The results tab has been opened for you to solve it. Please solve the CAPTCHA and try again.'
                };
            }

            for (const result of page.results) {
                let url = result.url;
                if (/^https?:\/\/(www\.)?google\.[^/]+\/url\?/.test(url)) {
                    try { url = new URL(url).searchParams.get('q') || new URL(url).searchParams.get('url'); } catch (e) { continue; }
                }
                if (!url || !/^https?:/.test(url) || /^https?:\/\/([^/]+\.)?google\.[^/]+\//.test(url) || url.includes('webcache.googleusercontent.com') || seenUrls.has(url)) continue;
                seenUrls.add(url);
                allOrganicResults.push(url);

                const matchedTarget = getMatch(url, targets);
                if (matchedTarget) {
                    foundMatches.push({
                        url: url,
                        target: matchedTarget,
                        position: allOrganicResults.length,
                        page: Math.ceil(allOrganicResults.length / 10),
                        type: result.type
                    });
                }
            }

            // Stop when Google has no further result pages
            if (!page.hasNext || page.results.length === 0) break;
            const delay = 1200 + Math.random() * 1800;
            await new Promise(resolve => setTimeout(resolve, delay));
        }
    } finally {
        if (!keepTabOpen) chrome.tabs.remove(scanTab.id).catch(() => { });
    }

    return foundMatches.length > 0
        ? { found: true, matches: foundMatches, scanned: allOrganicResults.length }
        : { found: false, scanned: allOrganicResults.length };
}

// ---------------------------------------------------------------------------
// Scheduled re-checks of tracked keywords (chrome.alarms + chrome.notifications)
// ---------------------------------------------------------------------------

async function applySchedule() {
    const { schedule } = await chrome.storage.local.get('schedule');
    const period = SCHEDULE_PERIODS[schedule];
    const existing = await chrome.alarms.get(SCHEDULE_ALARM);
    if (!period) {
        if (existing) await chrome.alarms.clear(SCHEDULE_ALARM);
        return;
    }
    // Keep the existing alarm if its period already matches
    if (existing && existing.periodInMinutes === period) return;
    await chrome.alarms.create(SCHEDULE_ALARM, { delayInMinutes: period, periodInMinutes: period });
}

chrome.runtime.onInstalled.addListener(() => { applySchedule(); });
chrome.runtime.onStartup.addListener(() => { applySchedule(); });

chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === SCHEDULE_ALARM) runScheduledCheck(false);
});

function setScheduleStatus(status) {
    return chrome.storage.local.set({ scheduleStatus: { ...status, updated: Date.now() } });
}

function notify(id, title, message) {
    chrome.notifications.create(id, {
        type: 'basic',
        iconUrl: chrome.runtime.getURL('icons/icon128.png'),
        title,
        message,
        priority: 0
    }, () => void chrome.runtime.lastError);
}

async function runScheduledCheck(manual) {
    if (scheduledRunning) return;
    // Don't compete with a scan the user started in the last 5 minutes
    if (!manual && Date.now() - lastManualScanAt < 5 * 60 * 1000) return;
    const all = await getRankHistory();
    const entries = Object.values(all)
        .filter(e => e.tracked !== false)
        .sort((a, b) => (a.lastChecked || 0) - (b.lastChecked || 0))
        .slice(0, SCHEDULE_MAX_KEYWORDS);
    if (entries.length === 0) {
        await setScheduleStatus({ running: false, lastRun: Date.now(), message: 'No tracked keywords yet.' });
        return;
    }

    scheduledRunning = true;
    cancelRequested = false;
    const changes = [];
    let checked = 0;
    let stopReason = '';
    try {
        for (const entry of entries) {
            await setScheduleStatus({ running: true, message: `Checking ${checked + 1}/${entries.length}: "${entry.keyword}"` });
            let res;
            try {
                res = await findRanking(entry.keyword, [entry.target], entry.country, entry.mode, entry.depth || 10);
            } catch (e) {
                stopReason = 'Could not open a background tab (is a Chrome window open?).';
                break;
            }
            if (res.cancelled) { stopReason = 'Stopped.'; break; }
            if (res.error) {
                stopReason = /CAPTCHA/i.test(res.error)
                    ? 'Google asked for a CAPTCHA. Solve it in the open tab, then click "Check all now".'
                    : res.error;
                break;
            }
            const match = (res.matches || []).find(m => m.target === entry.target);
            const { prev } = await recordRank({
                target: entry.target, keyword: entry.keyword, country: entry.country, mode: entry.mode,
                depth: entry.depth, rank: match ? match.position : null, url: match ? match.url : '', date: Date.now()
            });
            checked++;
            const change = describeChange(prev ? prev.rank : null, match ? match.position : null);
            if (prev && change.direction !== 'same') {
                changes.push({ keyword: entry.keyword, from: prev.rank, to: match ? match.position : null, direction: change.direction });
            }
            await new Promise(r => setTimeout(r, 2500 + Math.random() * 2000));
        }
    } finally {
        scheduledRunning = false;
    }

    const summary = stopReason
        ? `Checked ${checked} of ${entries.length}. ${stopReason}`
        : `Checked ${checked} keyword${checked === 1 ? '' : 's'}. ${changes.length ? `${changes.length} changed.` : 'No changes.'}`;
    await setScheduleStatus({ running: false, lastRun: Date.now(), message: summary, changes });

    const fmt = (r) => (r ? `#${r}` : 'not found');
    if (changes.length) {
        const lines = changes.slice(0, 4).map(c => `${c.direction === 'up' ? '▲' : '▼'} ${c.keyword}: ${fmt(c.from)} → ${fmt(c.to)}`);
        if (changes.length > 4) lines.push(`+${changes.length - 4} more`);
        notify('rank-changes', `${changes.length} ranking${changes.length === 1 ? '' : 's'} changed`, lines.join('\n'));
    } else if (stopReason) {
        notify('rank-check-stopped', 'Rank check paused', summary);
    } else if (manual) {
        notify('rank-check-done', 'Rank check complete', summary);
    }
}

// Open the tracked-keywords view when a notification is clicked
chrome.notifications.onClicked.addListener((id) => {
    chrome.notifications.clear(id);
    chrome.windows.getLastFocused({}, (win) => {
        if (chrome.runtime.lastError || !win) return;
        chrome.sidePanel.open({ windowId: win.id }).catch(() => {
            chrome.tabs.create({ url: chrome.runtime.getURL('popup.html#tracked') });
        });
    });
});
