// SEO Rank Finder Background Service Worker

// Open side panel when icon is clicked
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch((error) => console.error(error));

// Set when the side panel asks to stop the running scan
let cancelRequested = false;

const escapeRegExp = (str) => str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

// Helper function to check if a URL matches any of the target domains accurately.
// "example.com" matches example.com and its subdomains; "example.com/blog" matches that path prefix.
function getMatch(foundUrl, targets) {
    const found = foundUrl.toLowerCase().replace(/^(https?:\/\/)?(www\.)?/, '');
    for (const target of targets) {
        const targetClean = target.toLowerCase().trim().replace(/^(https?:\/\/)?(www\.)?/, '').replace(/\/+$/, '');
        if (!targetClean) continue;
        const domainPattern = new RegExp(`(^|\\.)` + escapeRegExp(targetClean) + `([/?#:]|$)`);
        if (domainPattern.test(found)) {
            return target;
        }
    }
    return null;
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'cancelScan') {
        cancelRequested = true;
        sendResponse({ ok: true });
        return false;
    }
    if (request.action === 'findRank') {
        cancelRequested = false;
        const targets = Array.isArray(request.targetUrl) ? request.targetUrl : [request.targetUrl];
        const maxPages = Math.min(10, Math.max(1, parseInt(request.maxPages, 10) || 10));
        findRanking(request.keyword, targets, request.country, request.mode, maxPages)
            .then(sendResponse)
            .catch(error => {
                console.error('Background search error:', error);
                sendResponse({ found: false, error: 'Search failed.' });
            });
        return true;
    }
});

// Google no longer serves result HTML to plain fetch() requests (it returns an
// "enable JavaScript" interstitial), so each SERP page is loaded in a background
// tab and the rendered result links are read with chrome.scripting.

// Runs inside the Google results page. Must be self-contained.
function extractSerpResults(mode) {
    if (location.pathname.startsWith('/sorry') || document.querySelector('#captcha-form, form[action*="/sorry/"]')) {
        return { captcha: true };
    }
    const root = mode === 'strict' ? (document.querySelector('#search') || document.body) : document.body;
    const withTitle = (a) => a.querySelector('h3');
    let anchors = [];
    if (mode === 'strict') {
        anchors = Array.from(root.querySelectorAll('.yuRUbf a[href], .MjjYud a[href]')).filter(withTitle);
        if (anchors.length === 0) anchors = Array.from(root.querySelectorAll('a[href]')).filter(withTitle);
    } else {
        anchors = Array.from(root.querySelectorAll('a[href]')).filter(withTitle);
    }
    // Google may obfuscate result hrefs (/goto?url=<token>); fall back to the visible <cite> breadcrumb
    const urlFromCite = (a) => {
        const scope = a.closest('.yuRUbf, .MjjYud') || a.parentElement;
        const cite = a.querySelector('cite') || (scope && scope.querySelector('cite'));
        if (!cite) return null;
        const parts = cite.textContent.split('›').map(p => p.trim()).filter(Boolean);
        if (parts.length === 0) return null;
        const host = /^https?:\/\//.test(parts[0]) ? parts[0] : 'https://' + parts[0];
        return [host].concat(parts.slice(1).map(p => p.replace(/(\.\.\.|…)$/, ''))).join('/');
    };
    const results = anchors.map((a) => {
        let type = 'organic';
        if (a.closest('.ULSxy, .v5y61')) type = 'snippet';
        if (a.closest('.related-question-pair')) type = 'paa';
        let url = a.href;
        try {
            const u = new URL(url);
            if (/(^|\.)google\./.test(u.hostname) && u.pathname === '/goto') url = urlFromCite(a) || url;
        } catch (e) { /* keep raw href */ }
        return { url, type };
    });
    return { captcha: false, results, hasNext: !!document.querySelector('#pnnext') };
}

// Navigate a tab and resolve once the new page has finished loading
function loadInTab(tabId, url) {
    return new Promise((resolve, reject) => {
        let sawLoading = false;
        const timer = setTimeout(() => { cleanup(); reject(new Error('Timed out loading Google results.')); }, 30000);
        const listener = (id, info) => {
            if (id !== tabId) return;
            if (info.status === 'loading') sawLoading = true;
            if (info.status === 'complete' && sawLoading) { cleanup(); resolve(); }
        };
        const cleanup = () => { clearTimeout(timer); chrome.tabs.onUpdated.removeListener(listener); };
        chrome.tabs.onUpdated.addListener(listener);
        chrome.tabs.update(tabId, { url }).catch((e) => { cleanup(); reject(e); });
    });
}

async function findRanking(keyword, targets, country, mode, maxPages = 10) {
    const maxResults = maxPages * 10;
    const resultsPerPage = 10;
    const allOrganicResults = [];
    const foundMatches = [];
    const seenUrls = new Set();

    const scanTab = await chrome.tabs.create({ url: 'about:blank', active: false });
    let keepTabOpen = false;
    // Let the blank tab settle so its own load events are not mistaken for the first SERP load
    for (let i = 0; i < 20 && (await chrome.tabs.get(scanTab.id)).status !== 'complete'; i++) {
        await new Promise(resolve => setTimeout(resolve, 100));
    }

    try {
        for (let start = 0; start < maxResults; start += resultsPerPage) {
            if (cancelRequested) {
                return { found: foundMatches.length > 0, matches: foundMatches, cancelled: true, scanned: allOrganicResults.length };
            }
            chrome.runtime.sendMessage({
                action: 'progress',
                status: `Scanning Page ${Math.floor(start / 10) + 1}/${maxPages}...`
            }).catch(() => { });

            let searchUrl = `https://www.google.com/search?q=${encodeURIComponent(keyword)}&start=${start}`;
            if (country) {
                searchUrl += `&gl=${country}&hl=en`;
            }

            await loadInTab(scanTab.id, searchUrl);

            let page;
            try {
                const [injection] = await chrome.scripting.executeScript({
                    target: { tabId: scanTab.id },
                    func: extractSerpResults,
                    args: [mode]
                });
                page = injection && injection.result;
            } catch (e) {
                // Usually a redirect away from www.google.com (e.g. the consent screen)
                keepTabOpen = true;
                chrome.tabs.update(scanTab.id, { active: true }).catch(() => { });
                return {
                    found: false,
                    error: 'Could not read Google results. Open google.com, accept any consent prompt, and try again.'
                };
            }

            if (!page || page.captcha) {
                keepTabOpen = true;
                chrome.tabs.update(scanTab.id, { active: true }).catch(() => { });
                return {
                    found: false,
                    error: 'Google CAPTCHA detected. The results tab has been opened for you to solve it. Please solve the CAPTCHA and try again.'
                };
            }

            for (const result of page.results) {
                let url = result.url;
                if (/^https?:\/\/(www\.)?google\.[^/]+\/url\?/.test(url)) {
                    try { url = new URL(url).searchParams.get('q') || new URL(url).searchParams.get('url'); } catch (e) { continue; }
                }
                if (!url || !/^https?:/.test(url) || /^https?:\/\/([^/]+\.)?google\.[^/]+\//.test(url) || url.includes('webcache.googleusercontent.com') || seenUrls.has(url)) continue;
                seenUrls.add(url);
                allOrganicResults.push(url);

                const matchedTarget = getMatch(url, targets);
                if (matchedTarget) {
                    foundMatches.push({
                        url: url,
                        target: matchedTarget,
                        position: allOrganicResults.length,
                        page: Math.ceil(allOrganicResults.length / 10),
                        type: result.type
                    });
                }
            }

            // Stop when Google has no further result pages
            if (!page.hasNext || page.results.length === 0) break;
            const delay = 1200 + Math.random() * 1800;
            await new Promise(resolve => setTimeout(resolve, delay));
        }
    } finally {
        if (!keepTabOpen) chrome.tabs.remove(scanTab.id).catch(() => { });
    }

    return foundMatches.length > 0
        ? { found: true, matches: foundMatches, scanned: allOrganicResults.length }
        : { found: false, scanned: allOrganicResults.length };
}
