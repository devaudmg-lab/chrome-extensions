// shared.js - rank history helpers used by both the side panel (popup.js) and
// the service worker (background.js, via importScripts). Plain script, no modules.

const RANK_HISTORY_KEY = 'rankHistory';
const RANK_MAX_POINTS = 60;
const SCHEDULE_MAX_KEYWORDS = 25;

// One history entry per target + keyword + region + mode
function rankId(target, keyword, country, mode) {
    return [String(target || '').toLowerCase(), String(keyword || '').toLowerCase().trim(), country || '', mode || 'strict'].join('|');
}

async function getRankHistory() {
    const data = await chrome.storage.local.get(RANK_HISTORY_KEY);
    return data[RANK_HISTORY_KEY] || {};
}

// Append a result (rank null = not found in the scanned depth). Returns the
// updated entry and the previous point so callers can show the change.
async function recordRank({ target, keyword, country, mode, depth, rank, url, date }) {
    const all = await getRankHistory();
    const id = rankId(target, keyword, country, mode);
    let entry = all[id];
    if (!entry) {
        entry = { target, keyword, country: country || '', mode: mode || 'strict', depth, tracked: true, points: [] };
        // Carry over the single "last result" that version 1.1 stored
        const legacyKey = `hist_${target}_${keyword}_${country}_${mode}`;
        const legacy = (await chrome.storage.local.get(legacyKey))[legacyKey];
        if (legacy && legacy.date) entry.points.push({ date: legacy.date, rank: legacy.rank || null, url: '' });
    }
    const prev = entry.points.length ? entry.points[entry.points.length - 1] : null;
    entry.points.push({ date: date || Date.now(), rank: rank || null, url: url || '' });
    entry.points = entry.points.slice(-RANK_MAX_POINTS);
    entry.depth = depth || entry.depth || 10;
    entry.lastChecked = date || Date.now();
    all[id] = entry;
    await chrome.storage.local.set({ [RANK_HISTORY_KEY]: all });
    return { id, entry, prev };
}

// Describe a rank change between two points ("not found" counts as worse than any rank)
function describeChange(prevRank, newRank) {
    if (!prevRank && !newRank) return { direction: 'same', diff: 0 };
    if (!prevRank) return { direction: 'up', diff: null, text: 'entered the results' };
    if (!newRank) return { direction: 'down', diff: null, text: 'dropped out of the results' };
    const diff = prevRank - newRank;
    return { direction: diff > 0 ? 'up' : (diff < 0 ? 'down' : 'same'), diff };
}
