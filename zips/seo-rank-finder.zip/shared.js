// shared.js - rank history helpers used by both the side panel (popup.js) and
// the service worker (background.js, via importScripts). Plain script, no modules.
// History is only WRITTEN by the service worker (one writer, serialised), the
// side panel reads it and asks the worker to change it.

const RANK_HISTORY_KEY = 'rankHistory';
const RANK_MAX_POINTS = 60;
// Hard cap on stored keyword entries; the least recently checked are dropped first
const RANK_MAX_ENTRIES = 300;
const SCHEDULE_MAX_KEYWORDS = 25;

// Turn whatever the user typed ("https://www.Example.com/blog/?x=1") into the
// canonical target form used for matching and for history ids ("example.com/blog").
function normalizeTarget(raw) {
    let t = String(raw || '').trim().toLowerCase();
    if (!t) return '';
    t = t.replace(/^[a-z][a-z0-9+.-]*:\/\//, '')   // protocol
        .replace(/^www\./, '')
        .replace(/[?#].*$/, '')                     // query / fragment
        .replace(/\/+$/, '');                       // trailing slashes
    if (/\s/.test(t) || !/^[^/]+\.[^/.]+(\/|:|$)/.test(t)) return '';
    return t;
}

// One history entry per target + keyword + region + mode
function rankId(target, keyword, country, mode) {
    return [String(target || '').toLowerCase(), String(keyword || '').toLowerCase().trim(), country || '', mode || 'strict'].join('|');
}

async function getRankHistory() {
    const data = await chrome.storage.local.get(RANK_HISTORY_KEY);
    return data[RANK_HISTORY_KEY] || {};
}

// Serialise read-modify-write cycles on the history object so two results
// finishing together cannot overwrite each other.
let historyChain = Promise.resolve();
function withHistoryLock(fn) {
    const run = historyChain.then(fn, fn);
    historyChain = run.catch(() => { });
    return run;
}

// Drop the least recently checked entries above the cap
function pruneHistory(all) {
    const ids = Object.keys(all);
    if (ids.length <= RANK_MAX_ENTRIES) return;
    ids.sort((a, b) => (all[a].lastChecked || 0) - (all[b].lastChecked || 0))
        .slice(0, ids.length - RANK_MAX_ENTRIES)
        .forEach(id => { delete all[id]; });
}

// Append a result (rank null = not found in the scanned depth). Returns the
// updated entry and the previous point so callers can show the change.
function recordRank({ target, keyword, country, mode, depth, rank, url, date }) {
    return withHistoryLock(async () => {
        const all = await getRankHistory();
        const id = rankId(target, keyword, country, mode);
        let entry = all[id];
        if (!entry) {
            entry = { target, keyword, country: country || '', mode: mode || 'strict', depth, tracked: true, points: [] };
            // Carry over the single "last result" that version 1.1 stored, then delete it
            const legacyKey = `hist_${target}_${keyword}_${country}_${mode}`;
            const legacy = (await chrome.storage.local.get(legacyKey))[legacyKey];
            if (legacy && legacy.date) entry.points.push({ date: legacy.date, rank: legacy.rank || null, url: '' });
            if (legacy) await chrome.storage.local.remove(legacyKey);
        }
        const prev = entry.points.length ? entry.points[entry.points.length - 1] : null;
        entry.points.push({ date: date || Date.now(), rank: rank || null, url: url || '' });
        entry.points = entry.points.slice(-RANK_MAX_POINTS);
        entry.depth = depth || entry.depth || 10;
        entry.lastChecked = date || Date.now();
        all[id] = entry;
        pruneHistory(all);
        await chrome.storage.local.set({ [RANK_HISTORY_KEY]: all });
        return { id, entry, prev };
    });
}

// Change one entry (patch = null deletes it)
function updateRankEntry(id, patch) {
    return withHistoryLock(async () => {
        const all = await getRankHistory();
        if (!all[id]) return false;
        if (patch === null) delete all[id];
        else Object.assign(all[id], patch);
        await chrome.storage.local.set({ [RANK_HISTORY_KEY]: all });
        return true;
    });
}

// Describe a rank change between two points ("not found" counts as worse than any rank)
function describeChange(prevRank, newRank) {
    if (!prevRank && !newRank) return { direction: 'same', diff: 0 };
    if (!prevRank) return { direction: 'up', diff: null, text: 'entered the results' };
    if (!newRank) return { direction: 'down', diff: null, text: 'dropped out of the results' };
    const diff = prevRank - newRank;
    return { direction: diff > 0 ? 'up' : (diff < 0 ? 'down' : 'same'), diff };
}

// Should a change trigger a notification? notifyMode: any | 3 | 5 | top10 | off
function isNotableChange(prevRank, newRank, notifyMode) {
    const c = describeChange(prevRank, newRank);
    if (c.direction === 'same' || notifyMode === 'off') return false;
    if (notifyMode === 'top10') return (!!prevRank && prevRank <= 10) !== (!!newRank && newRank <= 10);
    const min = parseInt(notifyMode, 10);
    if (!min || c.diff === null) return true; // "any", or entered / dropped out of the results
    return Math.abs(c.diff) >= min;
}

// Quote a CSV cell and neutralise spreadsheet formulas (=, +, -, @, tab, CR)
function csvCell(v) {
    let s = String(v ?? '');
    if (/^[=+\-@\t\r]/.test(s)) s = "'" + s;
    return `"${s.replace(/"/g, '""')}"`;
}
