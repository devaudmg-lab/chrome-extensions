document.addEventListener('DOMContentLoaded', () => {
    const targetUrlInput = document.getElementById('targetUrl');
    const competitorUrlInput = document.getElementById('competitorUrl');
    const addCompetitorBtn = document.getElementById('addCompetitorBtn');
    const competitorGroup = document.getElementById('competitorGroup');
    const keywordsInput = document.getElementById('keywords');
    const searchBtn = document.getElementById('searchBtn');
    const exportBtn = document.getElementById('exportBtn');
    const countrySelect = document.getElementById('country');
    const modeSelect = document.getElementById('mode');
    const depthSelect = document.getElementById('depth');
    const stopBtn = document.getElementById('stopBtn');
    const footerText = document.getElementById('footerText');
    const resultContainer = document.getElementById('resultContainer');
    const resultsList = document.getElementById('resultsList');
    const loader = document.getElementById('loader');
    const btnText = searchBtn.querySelector('.btn-text');
    const statusMsg = document.getElementById('statusMsg');
    const closePanelBtn = document.getElementById('closePanelBtn');

    let isCompetitorMode = false;
    let currentResults = [];
    let isScanning = false;
    let resumeIndex = 0;
    let stopRequested = false;
    // One row per keyword (including "not found") for the CSV export
    let keywordSummaries = [];

    const updateFooter = () => {
        footerText.textContent = `Scanning top ${parseInt(depthSelect.value, 10) * 10} results per keyword.`;
    };
    depthSelect.addEventListener('change', updateFooter);

    stopBtn.addEventListener('click', () => {
        stopRequested = true;
        stopBtn.disabled = true;
        stopBtn.textContent = 'Stopping...';
        chrome.runtime.sendMessage({ action: 'cancelScan' }).catch(() => { });
    });

    // Close Panel (Note: window.close() works if it's a side panel in some contexts,
    // but the main benefit is that side panels don't auto-close when clicking away)
    closePanelBtn.addEventListener('click', () => {
        window.close();
    });

    // Toggle Competitor Mode
    addCompetitorBtn.addEventListener('click', () => {
        isCompetitorMode = !isCompetitorMode;
        competitorGroup.classList.toggle('hidden', !isCompetitorMode);
        addCompetitorBtn.classList.toggle('active', isCompetitorMode);
        addCompetitorBtn.style.color = isCompetitorMode ? '#f59e0b' : 'currentColor';
    });

    // Load last used values and check for paused scans
    chrome.storage.local.get([
        'lastTargetUrl', 'lastKeywords', 'lastCountry', 'lastMode', 'lastCompetitorUrl', 'lastDepth',
        'pausedResults', 'pausedIndex', 'pausedSummaries'
    ], (data) => {
        if (data.lastDepth) depthSelect.value = String(data.lastDepth);
        updateFooter();
        if (data.lastTargetUrl) targetUrlInput.value = data.lastTargetUrl;
        if (data.lastKeywords) keywordsInput.value = data.lastKeywords;
        if (data.lastCountry) countrySelect.value = data.lastCountry;
        if (data.lastMode) modeSelect.value = data.lastMode;
        if (data.lastCompetitorUrl) {
            competitorUrlInput.value = data.lastCompetitorUrl;
            isCompetitorMode = true;
            competitorGroup.classList.remove('hidden');
            addCompetitorBtn.style.color = '#f59e0b';
        }

        // Check if there's a paused scan to resume
        if (Array.isArray(data.pausedResults) && typeof data.pausedIndex === 'number') {
            currentResults = data.pausedResults;
            keywordSummaries = data.pausedSummaries || [];
            resumeIndex = data.pausedIndex || 0;

            // Re-render the paused results
            renderAllPausedResults(currentResults, targetUrlInput.value.trim().toLowerCase());

            resultContainer.classList.remove('hidden');
            if (currentResults.length > 0 || keywordSummaries.length > 0) exportBtn.classList.remove('hidden');
            statusMsg.textContent = `Paused at keyword ${resumeIndex + 1}. Resolve CAPTCHA and click Resume.`;
            statusMsg.style.color = '#f59e0b';
            btnText.textContent = 'Resume Scanning';
        }
    });

    searchBtn.addEventListener('click', async () => {
        if (isScanning) return;

        const targetUrl = targetUrlInput.value.trim().toLowerCase();
        const competitorUrl = competitorUrlInput.value.trim().toLowerCase();
        const keywordsRaw = keywordsInput.value.trim();
        const country = countrySelect.value;
        const mode = modeSelect.value;
        const maxPages = parseInt(depthSelect.value, 10) || 10;

        if (!targetUrl || !keywordsRaw) {
            alert('Please enter both a target URL and at least one keyword.');
            return;
        }

        const keywords = [...new Set(keywordsRaw.split(/,|\n/).map(k => k.trim()).filter(k => k.length > 0))];
        const targets = [targetUrl];
        if (isCompetitorMode && competitorUrl) targets.push(competitorUrl);

        // If not resuming, reset everything
        if (btnText.textContent !== 'Resume Scanning') {
            currentResults = [];
            keywordSummaries = [];
            resumeIndex = 0;
            resultsList.innerHTML = '';
            chrome.storage.local.remove(['pausedResults', 'pausedIndex', 'pausedSummaries']);
        }

        // Remember the settings for next time
        chrome.storage.local.set({
            lastTargetUrl: targetUrl,
            lastKeywords: keywordsRaw,
            lastCountry: country,
            lastMode: mode,
            lastDepth: maxPages,
            lastCompetitorUrl: isCompetitorMode ? competitorUrl : ''
        });

        isScanning = true;
        stopRequested = false;
        stopBtn.disabled = false;
        stopBtn.textContent = 'Stop scan';
        stopBtn.classList.remove('hidden');
        setLoading(true);
        resultContainer.classList.remove('hidden');
        exportBtn.classList.add('hidden');
        let scanError = null;

        for (let i = resumeIndex; i < keywords.length; i++) {
            if (stopRequested) {
                scanError = 'Scan stopped.';
                break;
            }
            const kw = keywords[i];
            statusMsg.textContent = `Scanning ${i + 1}/${keywords.length}: "${kw}"...`;
            statusMsg.style.color = 'var(--text-muted)';

            try {
                const response = await chrome.runtime.sendMessage({
                    action: 'findRank',
                    targetUrl: targets,
                    keyword: kw,
                    country,
                    mode,
                    maxPages
                });

                if (!response) throw new Error('No response from background worker.');

                if (response.error && response.error.includes('CAPTCHA')) {
                    // PAUSE THE SCAN
                    resumeIndex = i;
                    isScanning = false;
                    stopBtn.classList.add('hidden');
                    setLoading(false);
                    btnText.textContent = 'Resume Scanning';
                    statusMsg.textContent = 'Google Blocked (CAPTCHA). Solve it in the new tab and click Resume.';
                    statusMsg.style.color = '#ef4444';

                    // Save state for persistence
                    chrome.storage.local.set({
                        pausedResults: currentResults,
                        pausedSummaries: keywordSummaries,
                        pausedIndex: resumeIndex
                    });
                    return;
                }

                if (response.error) {
                    scanError = response.error;
                    break;
                }

                const scannedAt = Date.now();
                // A cancelled keyword scan is incomplete: don't record it in history
                const partial = !!response.cancelled;
                const historyKey = `hist_${targetUrl}_${kw}_${country}_${mode}`;
                const historyData = await chrome.storage.local.get(historyKey);
                const lastScan = historyData[historyKey];
                const matches = (response.matches || []);
                const matchesWithKw = matches.map(m => ({ ...m, keyword: kw, scannedAt }));
                currentResults.push(...matchesWithKw);

                let trend = null;
                const primaryMatch = matches.find(m => m.target === targetUrl);
                if (primaryMatch && lastScan && lastScan.rank) {
                    const diff = lastScan.rank - primaryMatch.position;
                    trend = { diff, direction: diff > 0 ? 'up' : (diff < 0 ? 'down' : 'same') };
                }
                if (!partial) {
                    // Store the latest result (rank null = not found) so the next scan can compare
                    chrome.storage.local.set({ [historyKey]: { rank: primaryMatch ? primaryMatch.position : null, date: scannedAt, depth: maxPages } });
                }

                keywordSummaries.push({
                    keyword: kw,
                    found: !!primaryMatch,
                    position: primaryMatch ? primaryMatch.position : '',
                    page: primaryMatch ? primaryMatch.page : '',
                    url: primaryMatch ? primaryMatch.url : '',
                    scanned: response.scanned || 0,
                    partial,
                    scannedAt
                });

                displayKeywordResult(kw, matchesWithKw, trend, targetUrl, lastScan, maxPages, partial);

                // Update storage with progress
                chrome.storage.local.set({ pausedResults: currentResults, pausedSummaries: keywordSummaries, pausedIndex: i + 1 });

                if (partial) {
                    scanError = 'Scan stopped.';
                    break;
                }

                if (i < keywords.length - 1) {
                    await new Promise(r => setTimeout(r, 2500));
                }
            } catch (error) {
                console.error('Search error:', error);
                scanError = 'Scan interrupted.';
                break;
            }
        }

        isScanning = false;
        stopBtn.classList.add('hidden');
        setLoading(false);
        chrome.storage.local.remove(['pausedResults', 'pausedIndex', 'pausedSummaries']);

        if (scanError) {
            if (currentResults.length > 0 || keywordSummaries.length > 0) exportBtn.classList.remove('hidden');
            statusMsg.textContent = scanError;
            statusMsg.style.color = '#ef4444';
        } else if (currentResults.length > 0) {
            exportBtn.classList.remove('hidden');
            statusMsg.textContent = `Bulk scan complete. Found matches for ${[...new Set(currentResults.map(r => r.keyword))].length} keyword(s).`;
            statusMsg.style.color = '#10b981';
        } else {
            if (keywordSummaries.length > 0) exportBtn.classList.remove('hidden');
            statusMsg.textContent = 'No matches found.';
            statusMsg.style.color = '#ef4444';
        }
    });

    exportBtn.addEventListener('click', () => {
        if (currentResults.length === 0 && keywordSummaries.length === 0) return;
        const primary = targetUrlInput.value.trim().toLowerCase();
        const fmtDate = (t) => new Date(t || Date.now()).toLocaleString();
        const rows = [
            ['Keyword', 'Position', 'Type', 'Role', 'Target Domain', 'URL', 'Page', 'Results Scanned', 'Date'],
            ...currentResults.map(m => [
                m.keyword,
                m.position,
                m.type || 'organic',
                m.target === primary ? 'Client' : 'Competitor',
                m.target,
                m.url,
                m.page,
                '',
                fmtDate(m.scannedAt)
            ]),
            // Keywords where the client site was not found at all
            ...keywordSummaries.filter(k => !k.found).map(k => [
                k.keyword,
                k.partial ? 'Not found (scan stopped)' : 'Not found',
                '',
                'Client',
                primary,
                '',
                '',
                k.scanned,
                fmtDate(k.scannedAt)
            ])
        ];
        const csvContent = '\uFEFF' + rows.map(e => e.map(v => `"${String(v ?? '').replace(/"/g, '""')}"`).join(",")).join("\r\n");
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.setAttribute("href", url);
        link.setAttribute("download", `seo_report_${Date.now()}.csv`);
        document.body.appendChild(link);
        link.click();
        link.remove();
        setTimeout(() => URL.revokeObjectURL(url), 1000);
    });

    chrome.runtime.onMessage.addListener((message) => {
        if (message.action === 'progress' && isScanning) {
            btnText.textContent = message.status;
        }
    });

    function escapeHtml(str) {
        return String(str).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    }

    function setLoading(isLoading) {
        if (isLoading) {
            searchBtn.disabled = true;
            loader.style.display = 'block';
        } else {
            searchBtn.disabled = false;
            loader.style.display = 'none';
            btnText.textContent = 'Find Position';
            stopBtn.classList.add('hidden');
        }
    }

    function renderAllPausedResults(results, primaryTarget) {
        resultsList.innerHTML = '';
        const grouped = results.reduce((acc, r) => {
            if (!acc[r.keyword]) acc[r.keyword] = [];
            acc[r.keyword].push(r);
            return acc;
        }, {});

        Object.keys(grouped).forEach(kw => {
            displayKeywordResult(kw, grouped[kw], null, primaryTarget);
        });
    }

    function displayKeywordResult(keyword, matches, trend, primaryTarget, lastScan, maxPages = 10, partial = false) {
        const kwHeader = document.createElement('div');
        kwHeader.className = 'kw-section-header';
        kwHeader.textContent = `Keyword: ${keyword}`;
        resultsList.appendChild(kwHeader);

        if (lastScan && lastScan.date) {
            const prev = document.createElement('div');
            prev.className = 'prev-rank';
            const when = new Date(lastScan.date).toLocaleDateString();
            prev.textContent = lastScan.rank ? `Previous check: #${lastScan.rank} on ${when}` : `Previous check: not found on ${when}`;
            resultsList.appendChild(prev);
        }

        if (trend) {
            const trendEl = document.createElement('div');
            trendEl.className = `trend-indicator ${trend.direction}`;
            const arrow = trend.direction === 'up' ? '↑' : (trend.direction === 'down' ? '↓' : '•');
            const diffText = trend.direction === 'same' ? 'No change' : `${Math.abs(trend.diff)} positions ${trend.direction}`;
            trendEl.innerHTML = `<span>${arrow}</span> ${diffText}`;
            resultsList.appendChild(trendEl);
        }

        if (matches.length === 0) {
            const noMatch = document.createElement('div');
            noMatch.className = 'no-match-msg';
            noMatch.textContent = partial ? 'Not found (scan stopped early)' : `Not found in top ${maxPages * 10}`;
            resultsList.appendChild(noMatch);
            return;
        }

        matches.forEach(match => {
            const isClient = match.target === primaryTarget;
            const safeUrl = /^https?:\/\//i.test(match.url) ? match.url : '#';
            const item = document.createElement('div');
            item.className = `result-item ${isClient ? 'client' : 'competitor'}`;
            item.innerHTML = `
                <div class="item-pos">#${match.position}</div>
                <div class="item-info">
                    <div class="item-badges">
                        <span class="badge ${isClient ? 'badge-client' : 'badge-competitor'}">${isClient ? 'Client' : 'Competitor'}</span>
                        ${match.type === 'snippet' ? '<span class="badge badge-feature">🏆 Snippet</span>' : ''}
                        ${match.type === 'paa' ? '<span class="badge badge-feature">❓ PAA</span>' : ''}
                    </div>
                    <a href="${escapeHtml(safeUrl)}" target="_blank" rel="noopener noreferrer" class="item-url">${escapeHtml(match.url)}</a>
                    <div class="item-page">Page ${escapeHtml(match.page)}</div>
                </div>
            `;
            item.querySelector('.item-url').addEventListener('click', (e) => {
                e.preventDefault();
                if (safeUrl !== '#') chrome.tabs.create({ url: safeUrl });
            });
            resultsList.appendChild(item);
        });
    }
});
