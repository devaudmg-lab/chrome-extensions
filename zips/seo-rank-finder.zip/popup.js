document.addEventListener('DOMContentLoaded', () => {
    const targetUrlInput = document.getElementById('targetUrl');
    const competitorUrlInput = document.getElementById('competitorUrl');
    const addCompetitorBtn = document.getElementById('addCompetitorBtn');
    const competitorGroup = document.getElementById('competitorGroup');
    const keywordsInput = document.getElementById('keywords');
    const searchBtn = document.getElementById('searchBtn');
    const exportBtn = document.getElementById('exportBtn');
    const countrySelect = document.getElementById('country');
    const modeSelect = document.getElementById('mode');
    const depthSelect = document.getElementById('depth');
    const stopBtn = document.getElementById('stopBtn');
    const footerText = document.getElementById('footerText');
    const resultContainer = document.getElementById('resultContainer');
    const resultsList = document.getElementById('resultsList');
    const loader = document.getElementById('loader');
    const btnText = searchBtn.querySelector('.btn-text');
    const statusMsg = document.getElementById('statusMsg');
    const closePanelBtn = document.getElementById('closePanelBtn');

    let isCompetitorMode = false;
    let currentResults = [];
    let isScanning = false;
    let resumeIndex = 0;
    let stopRequested = false;
    // A CAPTCHA-paused scan: resumable only with the same site and keyword list
    let paused = null;
    // One row per keyword (including "not found") for the CSV export
    let keywordSummaries = [];

    const updateFooter = () => {
        footerText.textContent = `Scanning top ${parseInt(depthSelect.value, 10) * 10} results per keyword.`;
    };
    depthSelect.addEventListener('change', updateFooter);

    stopBtn.addEventListener('click', () => {
        stopRequested = true;
        stopBtn.disabled = true;
        stopBtn.textContent = 'Stopping...';
        chrome.runtime.sendMessage({ action: 'cancelScan' }).catch(() => { });
    });

    // Close Panel (Note: window.close() works if it's a side panel in some contexts,
    // but the main benefit is that side panels don't auto-close when clicking away)
    closePanelBtn.addEventListener('click', () => {
        window.close();
    });

    // Toggle Competitor Mode
    addCompetitorBtn.addEventListener('click', () => {
        isCompetitorMode = !isCompetitorMode;
        competitorGroup.classList.toggle('hidden', !isCompetitorMode);
        addCompetitorBtn.classList.toggle('active', isCompetitorMode);
        addCompetitorBtn.setAttribute('aria-expanded', String(isCompetitorMode));
        addCompetitorBtn.style.color = isCompetitorMode ? '#f59e0b' : 'currentColor';
        if (isCompetitorMode) competitorUrlInput.focus();
    });

    // Load last used values and check for paused scans
    chrome.storage.local.get([
        'lastTargetUrl', 'lastKeywords', 'lastCountry', 'lastMode', 'lastCompetitorUrl', 'lastDepth',
        'pausedResults', 'pausedIndex', 'pausedSummaries', 'pausedKey'
    ], (data) => {
        if (data.lastDepth) depthSelect.value = String(data.lastDepth);
        updateFooter();
        if (data.lastTargetUrl) targetUrlInput.value = data.lastTargetUrl;
        if (data.lastKeywords) keywordsInput.value = data.lastKeywords;
        if (data.lastCountry) countrySelect.value = data.lastCountry;
        if (data.lastMode) modeSelect.value = data.lastMode;
        if (data.lastCompetitorUrl) {
            competitorUrlInput.value = data.lastCompetitorUrl;
            isCompetitorMode = true;
            competitorGroup.classList.remove('hidden');
            addCompetitorBtn.setAttribute('aria-expanded', 'true');
            addCompetitorBtn.style.color = '#f59e0b';
        }

        // Check if there's a paused scan to resume
        if (Array.isArray(data.pausedResults) && typeof data.pausedIndex === 'number') {
            currentResults = data.pausedResults;
            keywordSummaries = data.pausedSummaries || [];
            resumeIndex = data.pausedIndex || 0;
            paused = { key: data.pausedKey || '' };

            // Re-render the paused results
            renderAllPausedResults(currentResults, keywordSummaries, normalizeTarget(targetUrlInput.value));

            resultContainer.classList.remove('hidden');
            if (currentResults.length > 0 || keywordSummaries.length > 0) exportBtn.classList.remove('hidden');
            statusMsg.textContent = `Paused at keyword ${resumeIndex + 1}. Resolve CAPTCHA and click Resume.`;
            statusMsg.style.color = '#f59e0b';
            btnText.textContent = 'Resume Scanning';
        }
    });

    searchBtn.addEventListener('click', async () => {
        if (isScanning) return;

        const targetUrl = normalizeTarget(targetUrlInput.value);
        const competitorUrl = normalizeTarget(competitorUrlInput.value);
        const keywordsRaw = keywordsInput.value.trim();
        const country = countrySelect.value;
        const mode = modeSelect.value;
        const maxPages = parseInt(depthSelect.value, 10) || 10;

        if (!targetUrl || !keywordsRaw) {
            resultContainer.classList.remove('hidden');
            resultsList.innerHTML = '';
            exportBtn.classList.add('hidden');
            statusMsg.textContent = !targetUrl
                ? (targetUrlInput.value.trim() ? 'That does not look like a website. Use a domain such as example.com or example.com/blog.' : 'Enter the website you want to find, e.g. example.com.')
                : 'Enter at least one keyword.';
            statusMsg.style.color = '#f59e0b';
            (!targetUrl ? targetUrlInput : keywordsInput).focus();
            return;
        }

        // Show the cleaned-up form so the user sees exactly what is matched
        targetUrlInput.value = targetUrl;
        if (competitorUrl) competitorUrlInput.value = competitorUrl;
        const seenKw = new Set();
        const keywords = keywordsRaw.split(/,|\n/).map(k => k.trim().replace(/\s+/g, ' ').slice(0, 300))
            .filter(k => k.length > 0 && !seenKw.has(k.toLowerCase()) && seenKw.add(k.toLowerCase()));
        const targets = [targetUrl];
        if (isCompetitorMode && competitorUrl && competitorUrl !== targetUrl) targets.push(competitorUrl);
        const scanKey = JSON.stringify([targets, keywords, country, mode, maxPages]);

        // Resume only the exact scan that was paused; anything else starts fresh
        if (!paused || paused.key !== scanKey) {
            currentResults = [];
            keywordSummaries = [];
            resumeIndex = 0;
            resultsList.replaceChildren();
            chrome.storage.local.remove(['pausedResults', 'pausedIndex', 'pausedSummaries', 'pausedKey']);
        }
        paused = null;

        // Remember the settings for next time
        chrome.storage.local.set({
            lastTargetUrl: targetUrl,
            lastKeywords: keywordsRaw,
            lastCountry: country,
            lastMode: mode,
            lastDepth: maxPages,
            lastCompetitorUrl: isCompetitorMode ? competitorUrl : ''
        });

        isScanning = true;
        stopRequested = false;
        stopBtn.disabled = false;
        stopBtn.textContent = 'Stop scan';
        stopBtn.classList.remove('hidden');
        setLoading(true);
        resultContainer.classList.remove('hidden');
        exportBtn.classList.add('hidden');
        let scanError = null;

        for (let i = resumeIndex; i < keywords.length; i++) {
            if (stopRequested) {
                scanError = 'Scan stopped.';
                break;
            }
            const kw = keywords[i];
            statusMsg.textContent = `Scanning ${i + 1}/${keywords.length}: "${kw}"...`;
            statusMsg.style.color = 'var(--text-muted)';

            try {
                const response = await chrome.runtime.sendMessage({
                    action: 'findRank',
                    targetUrl: targets,
                    keyword: kw,
                    country,
                    mode,
                    maxPages,
                    record: true
                });

                if (!response) throw new Error('No response from background worker.');

                if (response.error && response.captcha) {
                    // PAUSE THE SCAN
                    resumeIndex = i;
                    paused = { key: scanKey };
                    isScanning = false;
                    stopBtn.classList.add('hidden');
                    setLoading(false);
                    btnText.textContent = 'Resume Scanning';
                    statusMsg.textContent = 'Google Blocked (CAPTCHA). Solve it in the new tab and click Resume.';
                    statusMsg.style.color = '#ef4444';

                    // Save state for persistence
                    chrome.storage.local.set({
                        pausedResults: currentResults,
                        pausedSummaries: keywordSummaries,
                        pausedIndex: resumeIndex,
                        pausedKey: scanKey
                    });
                    return;
                }

                if (response.error) {
                    scanError = response.error;
                    break;
                }

                const scannedAt = Date.now();
                // A cancelled keyword scan is incomplete: don't record it in history
                const partial = !!response.cancelled;
                const matches = (response.matches || []);
                const matchesWithKw = matches.map(m => ({ ...m, keyword: kw, scannedAt }));
                currentResults.push(...matchesWithKw);
                const primaryMatch = matches.find(m => m.target === targetUrl);

                // The worker saved the result to the rank history and returned the previous check
                let lastScan = null;
                if (response.recorded) {
                    lastScan = response.prev || null;
                } else {
                    const entry = (await getRankHistory())[rankId(targetUrl, kw, country, mode)];
                    lastScan = entry && entry.points.length ? entry.points[entry.points.length - 1] : null;
                }

                let trend = null;
                if (primaryMatch && lastScan && lastScan.rank) {
                    const diff = lastScan.rank - primaryMatch.position;
                    trend = { diff, direction: diff > 0 ? 'up' : (diff < 0 ? 'down' : 'same') };
                }

                keywordSummaries.push({
                    keyword: kw,
                    found: !!primaryMatch,
                    position: primaryMatch ? primaryMatch.position : '',
                    page: primaryMatch ? primaryMatch.page : '',
                    url: primaryMatch ? primaryMatch.url : '',
                    scanned: response.scanned || 0,
                    partial,
                    scannedAt
                });

                displayKeywordResult(kw, matchesWithKw, trend, targetUrl, lastScan, maxPages, partial);

                // Update storage with progress
                chrome.storage.local.set({ pausedResults: currentResults, pausedSummaries: keywordSummaries, pausedIndex: i + 1, pausedKey: scanKey });

                if (partial) {
                    scanError = 'Scan stopped.';
                    break;
                }

                // Polite, slightly random pause between keywords (cut short by Stop)
                if (i < keywords.length - 1) {
                    const until = Date.now() + 2500 + Math.random() * 2000;
                    while (!stopRequested && Date.now() < until) await new Promise(r => setTimeout(r, 200));
                }
            } catch (error) {
                console.error('Search error:', error);
                scanError = 'Scan interrupted.';
                break;
            }
        }

        isScanning = false;
        stopBtn.classList.add('hidden');
        setLoading(false);
        chrome.storage.local.remove(['pausedResults', 'pausedIndex', 'pausedSummaries', 'pausedKey']);

        if (scanError) {
            if (currentResults.length > 0 || keywordSummaries.length > 0) exportBtn.classList.remove('hidden');
            statusMsg.textContent = scanError;
            statusMsg.style.color = '#ef4444';
        } else if (currentResults.length > 0) {
            exportBtn.classList.remove('hidden');
            statusMsg.textContent = `Bulk scan complete. Found matches for ${[...new Set(currentResults.map(r => r.keyword))].length} keyword(s).`;
            statusMsg.style.color = '#10b981';
        } else {
            if (keywordSummaries.length > 0) exportBtn.classList.remove('hidden');
            statusMsg.textContent = 'No matches found.';
            statusMsg.style.color = '#ef4444';
        }
    });

    exportBtn.addEventListener('click', () => {
        if (currentResults.length === 0 && keywordSummaries.length === 0) return;
        const primary = normalizeTarget(targetUrlInput.value);
        const fmtDate = (t) => new Date(t || Date.now()).toLocaleString();
        const rows = [
            ['Keyword', 'Position', 'Type', 'Role', 'Target Domain', 'URL', 'Page', 'Results Scanned', 'Date'],
            ...currentResults.map(m => [
                m.keyword,
                m.position,
                m.type || 'organic',
                m.target === primary ? 'Client' : 'Competitor',
                m.target,
                m.url,
                m.page,
                '',
                fmtDate(m.scannedAt)
            ]),
            // Keywords where the client site was not found at all
            ...keywordSummaries.filter(k => !k.found).map(k => [
                k.keyword,
                k.partial ? 'Not found (scan stopped)' : 'Not found',
                '',
                'Client',
                primary,
                '',
                '',
                k.scanned,
                fmtDate(k.scannedAt)
            ])
        ];
        const csvContent = '\uFEFF' + rows.map(e => e.map(csvCell).join(',')).join('\r\n');
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.setAttribute("href", url);
        link.setAttribute("download", `seo_report_${Date.now()}.csv`);
        document.body.appendChild(link);
        link.click();
        link.remove();
        setTimeout(() => URL.revokeObjectURL(url), 1000);
    });

    chrome.runtime.onMessage.addListener((message) => {
        if (message.action === 'progress' && message.kind === 'manual' && isScanning) {
            btnText.textContent = message.status;
        }
    });

    function escapeHtml(str) {
        return String(str).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    }

    function setLoading(isLoading) {
        if (isLoading) {
            searchBtn.disabled = true;
            loader.style.display = 'block';
        } else {
            searchBtn.disabled = false;
            loader.style.display = 'none';
            btnText.textContent = 'Find Position';
            stopBtn.classList.add('hidden');
        }
    }

    // Re-draw a paused scan: one section per finished keyword, including "not found"
    function renderAllPausedResults(results, summaries, primaryTarget) {
        resultsList.replaceChildren();
        const keywords = summaries.length ? summaries.map(k => k.keyword) : [...new Set(results.map(r => r.keyword))];
        keywords.forEach(kw => {
            const summary = summaries.find(k => k.keyword === kw);
            displayKeywordResult(kw, results.filter(r => r.keyword === kw), null, primaryTarget, null,
                summary && summary.scanned ? Math.ceil(summary.scanned / 10) : 10, !!(summary && summary.partial));
        });
    }

    function displayKeywordResult(keyword, matches, trend, primaryTarget, lastScan, maxPages = 10, partial = false) {
        const kwHeader = document.createElement('div');
        kwHeader.className = 'kw-section-header';
        kwHeader.textContent = `Keyword: ${keyword}`;
        resultsList.appendChild(kwHeader);

        if (lastScan && lastScan.date) {
            const prev = document.createElement('div');
            prev.className = 'prev-rank';
            const when = new Date(lastScan.date).toLocaleDateString();
            prev.textContent = lastScan.rank ? `Previous check: #${lastScan.rank} on ${when}` : `Previous check: not found on ${when}`;
            resultsList.appendChild(prev);
        }

        if (trend) {
            const trendEl = document.createElement('div');
            trendEl.className = `trend-indicator ${trend.direction}`;
            const arrow = trend.direction === 'up' ? '↑' : (trend.direction === 'down' ? '↓' : '•');
            const diffText = trend.direction === 'same' ? 'No change' : `${Math.abs(trend.diff)} positions ${trend.direction}`;
            const arrowEl = document.createElement('span');
            arrowEl.textContent = arrow;
            trendEl.append(arrowEl, ` ${diffText}`);
            resultsList.appendChild(trendEl);
        }

        if (matches.length === 0) {
            const noMatch = document.createElement('div');
            noMatch.className = 'no-match-msg';
            noMatch.textContent = partial ? 'Not found (scan stopped early)' : `Not found in top ${maxPages * 10}`;
            resultsList.appendChild(noMatch);
            return;
        }

        matches.forEach(match => {
            const isClient = match.target === primaryTarget;
            const safeUrl = /^https?:\/\//i.test(match.url) ? match.url : '#';
            const item = document.createElement('div');
            item.className = `result-item ${isClient ? 'client' : 'competitor'}`;
            item.innerHTML = `
                <div class="item-pos">#${escapeHtml(match.position)}</div>
                <div class="item-info">
                    <div class="item-badges">
                        <span class="badge ${isClient ? 'badge-client' : 'badge-competitor'}">${isClient ? 'Client' : 'Competitor'}</span>
                        ${match.type === 'snippet' ? '<span class="badge badge-feature">🏆 Snippet</span>' : ''}
                        ${match.type === 'paa' ? '<span class="badge badge-feature">❓ PAA</span>' : ''}
                    </div>
                    <a href="${escapeHtml(safeUrl)}" target="_blank" rel="noopener noreferrer" class="item-url">${escapeHtml(match.url)}</a>
                    <div class="item-page">Page ${escapeHtml(match.page)}</div>
                </div>
            `;
            item.querySelector('.item-url').addEventListener('click', (e) => {
                e.preventDefault();
                if (safeUrl !== '#') chrome.tabs.create({ url: safeUrl });
            });
            resultsList.appendChild(item);
        });
    }

    // ------------------------------------------------------------------
    // Views: "Check rankings" and "Tracked" (rank history + schedule)
    // ------------------------------------------------------------------
    const tabCheck = document.getElementById('tabCheck');
    const tabTracked = document.getElementById('tabTracked');
    const viewCheck = document.getElementById('viewCheck');
    const viewTracked = document.getElementById('viewTracked');
    const trackedList = document.getElementById('trackedList');
    const trackedEmpty = document.getElementById('trackedEmpty');
    const trackedCount = document.getElementById('trackedCount');
    const scheduleSelect = document.getElementById('schedule');
    const scheduleStatus = document.getElementById('scheduleStatus');
    const runTrackedBtn = document.getElementById('runTrackedBtn');
    const exportHistoryBtn = document.getElementById('exportHistoryBtn');
    const onboarding = document.getElementById('onboarding');
    const useCurrentSite = document.getElementById('useCurrentSite');
    const notifyModeSelect = document.getElementById('notifyMode');
    const trackedToolbar = document.getElementById('trackedToolbar');
    const trackedSearch = document.getElementById('trackedSearch');
    const trackedSort = document.getElementById('trackedSort');
    const trackedNoMatch = document.getElementById('trackedNoMatch');
    const expanded = new Set();
    // A "running" status older than this without a heartbeat is a dead run
    const STATUS_STALE_MS = 3 * 60 * 1000;
    let trackedRunActive = false;
    const SVG_NS = 'http://www.w3.org/2000/svg';

    function showView(view) {
        const tracked = view === 'tracked';
        viewCheck.classList.toggle('hidden', tracked);
        viewTracked.classList.toggle('hidden', !tracked);
        tabCheck.classList.toggle('active', !tracked);
        tabTracked.classList.toggle('active', tracked);
        tabCheck.setAttribute('aria-selected', String(!tracked));
        tabTracked.setAttribute('aria-selected', String(tracked));
        chrome.storage.local.set({ lastView: view });
        if (tracked) renderTracked();
    }
    tabCheck.addEventListener('click', () => showView('check'));
    tabTracked.addEventListener('click', () => showView('tracked'));

    const regionName = (code) => {
        if (!code) return 'Auto';
        const opt = countrySelect.querySelector(`option[value="${CSS.escape(code)}"]`);
        return opt ? opt.textContent : code.toUpperCase();
    };
    const fmtRank = (r) => (r ? `#${r}` : '-');
    const fmtDate = (t) => new Date(t).toLocaleDateString(undefined, { month: 'short', day: 'numeric' });

    function el(tag, className, text) {
        const node = document.createElement(tag);
        if (className) node.className = className;
        if (text !== undefined) node.textContent = text;
        return node;
    }

    // Rank chart: y axis inverted (rank 1 at the top), gaps for "not found"
    function rankChart(points, { width, height, axes }) {
        const svg = document.createElementNS(SVG_NS, 'svg');
        svg.setAttribute('width', width);
        svg.setAttribute('height', height);
        svg.setAttribute('viewBox', `0 0 ${width} ${height}`);
        svg.classList.add('rank-chart');
        const ranks = points.map(p => p.rank).filter(Boolean);
        if (ranks.length === 0) return svg;
        const pad = axes ? { l: 28, r: 8, t: 8, b: 18 } : { l: 2, r: 4, t: 3, b: 3 };
        const best = Math.min(...ranks);
        const worst = Math.max(...ranks);
        const lo = Math.max(1, best - 2);
        const hi = worst + 2;
        const w = width - pad.l - pad.r;
        const h = height - pad.t - pad.b;
        const x = (i) => pad.l + (points.length === 1 ? w / 2 : (i / (points.length - 1)) * w);
        const y = (r) => pad.t + ((r - lo) / (hi - lo || 1)) * h;
        const add = (name, attrs) => {
            const n = document.createElementNS(SVG_NS, name);
            Object.entries(attrs).forEach(([k, v]) => n.setAttribute(k, v));
            svg.appendChild(n);
            return n;
        };
        if (axes) {
            [lo, Math.round((lo + hi) / 2), hi].forEach((r) => {
                add('line', { x1: pad.l, x2: width - pad.r, y1: y(r), y2: y(r), class: 'grid' });
                add('text', { x: pad.l - 6, y: y(r) + 3, 'text-anchor': 'end', class: 'axis' }).textContent = `#${r}`;
            });
            const first = points[0];
            const last = points[points.length - 1];
            add('text', { x: pad.l, y: height - 4, class: 'axis' }).textContent = fmtDate(first.date);
            if (points.length > 1) add('text', { x: width - pad.r, y: height - 4, 'text-anchor': 'end', class: 'axis' }).textContent = fmtDate(last.date);
        }
        let d = '';
        points.forEach((p, i) => {
            if (!p.rank) { d += ' '; return; }
            const prevFound = i > 0 && points[i - 1].rank;
            d += `${prevFound ? 'L' : 'M'}${x(i).toFixed(1)},${y(p.rank).toFixed(1)} `;
        });
        add('path', { d: d.trim(), class: 'line' });
        points.forEach((p, i) => {
            if (!p.rank) return;
            if (axes || i === points.length - 1) {
                const dot = add('circle', { cx: x(i), cy: y(p.rank), r: axes ? 3 : 2.5, class: 'dot' });
                if (axes) {
                    const t = document.createElementNS(SVG_NS, 'title');
                    t.textContent = `#${p.rank} on ${new Date(p.date).toLocaleString()}`;
                    dot.appendChild(t);
                }
            }
        });
        return svg;
    }

    let renderSeq = 0;
    async function renderTracked() {
        const seq = ++renderSeq;
        const all = await getRankHistory();
        if (seq !== renderSeq) return; // a newer render started while we waited
        const allEntries = Object.entries(all).filter(([, e]) => e && e.points && e.points.length);
        trackedCount.textContent = allEntries.length;
        trackedEmpty.classList.toggle('hidden', allEntries.length > 0);
        trackedToolbar.classList.toggle('hidden', allEntries.length < 2);
        exportHistoryBtn.classList.toggle('hidden', allEntries.length === 0);
        if (!trackedRunActive) runTrackedBtn.disabled = allEntries.length === 0;

        // Filter by keyword / site text, then sort
        const q = trackedSearch.value.trim().toLowerCase();
        const lastRank = (e) => e.points[e.points.length - 1].rank || Infinity;
        const movement = (e) => {
            const n = e.points.length;
            if (n < 2) return 0;
            const c = describeChange(e.points[n - 2].rank, e.points[n - 1].rank);
            return c.diff === null ? 1000 : Math.abs(c.diff || 0);
        };
        const sorters = {
            recent: (a, b) => (b.lastChecked || 0) - (a.lastChecked || 0),
            rank: (a, b) => lastRank(a) - lastRank(b) || a.keyword.localeCompare(b.keyword),
            movers: (a, b) => movement(b) - movement(a) || (b.lastChecked || 0) - (a.lastChecked || 0),
            az: (a, b) => a.keyword.localeCompare(b.keyword) || a.target.localeCompare(b.target)
        };
        const sorter = sorters[trackedSort.value] || sorters.recent;
        const entries = allEntries
            .filter(([, e]) => !q || `${e.keyword} ${e.target}`.toLowerCase().includes(q))
            .sort((a, b) => sorter(a[1], b[1]));
        trackedNoMatch.classList.toggle('hidden', entries.length > 0 || allEntries.length === 0);
        trackedList.replaceChildren();

        entries.forEach(([id, e]) => {
            const pts = e.points;
            const last = pts[pts.length - 1];
            const prev = pts.length > 1 ? pts[pts.length - 2] : null;
            const change = prev ? describeChange(prev.rank, last.rank) : { direction: 'same', diff: 0 };
            const found = pts.map(p => p.rank).filter(Boolean);

            const autoCheck = e.tracked !== false;
            const row = el('div', `tracked-item${autoCheck ? '' : ' paused'}`);
            const head = el('button', 'tracked-head');
            head.type = 'button';
            head.title = 'Show ranking history';
            head.setAttribute('aria-expanded', String(expanded.has(id)));
            const rank = el('div', `tracked-rank ${last.rank ? '' : 'nf'}`, last.rank ? `#${last.rank}` : 'n/f');
            const info = el('div', 'tracked-info');
            info.append(el('div', 'tracked-kw', e.keyword), el('div', 'tracked-meta', `${e.target} · ${e.country ? e.country.toUpperCase() : 'Auto'} · ${fmtDate(last.date)}${autoCheck ? '' : ' · auto-check off'}`));
            const delta = el('div', `tracked-delta ${change.direction}`);
            if (prev) {
                delta.textContent = change.direction === 'same' ? '•' : (change.diff ? `${change.direction === 'up' ? '▲' : '▼'}${Math.abs(change.diff)}` : (change.direction === 'up' ? '▲ new' : '▼ lost'));
            }
            head.append(rank, info, rankChart(pts.slice(-12), { width: 64, height: 26, axes: false }), delta);
            row.appendChild(head);

            if (expanded.has(id)) {
                const detail = el('div', 'tracked-detail');
                detail.appendChild(rankChart(pts.slice(-30), { width: 300, height: 120, axes: true }));
                const stats = el('div', 'tracked-stats');
                stats.append(
                    el('span', '', `Best ${found.length ? '#' + Math.min(...found) : '-'}`),
                    el('span', '', `Checks ${pts.length}`),
                    el('span', '', `Depth top ${(e.depth || 10) * 10}`),
                    el('span', '', e.mode === 'broad' ? 'Broad' : 'Strict')
                );
                detail.appendChild(stats);
                if (last.url) {
                    const link = el('a', 'tracked-url', last.url);
                    link.href = /^https?:\/\//i.test(last.url) ? last.url : '#';
                    link.addEventListener('click', (ev) => { ev.preventDefault(); if (link.href !== '#') chrome.tabs.create({ url: last.url }); });
                    detail.appendChild(link);
                }
                const recent = el('div', 'tracked-recent');
                pts.slice(-6).reverse().forEach(p => recent.appendChild(el('span', '', `${fmtDate(p.date)}: ${fmtRank(p.rank)}`)));
                detail.appendChild(recent);
                const actions = el('div', 'tracked-actions');
                const recheck = el('button', 'link-btn', 'Check again');
                recheck.type = 'button';
                recheck.addEventListener('click', () => {
                    targetUrlInput.value = e.target;
                    keywordsInput.value = e.keyword;
                    countrySelect.value = e.country || '';
                    modeSelect.value = e.mode || 'strict';
                    depthSelect.value = String(e.depth || 10);
                    updateFooter();
                    showView('check');
                    searchBtn.click();
                });
                // Include or exclude this keyword from automatic re-checks
                const toggle = el('label', 'auto-toggle');
                const box = document.createElement('input');
                box.type = 'checkbox';
                box.checked = autoCheck;
                box.addEventListener('change', () => {
                    chrome.runtime.sendMessage({ action: 'updateTracked', id, tracked: box.checked }).catch(() => { });
                });
                toggle.append(box, ' Auto-check');
                toggle.title = 'Include this keyword in daily / weekly re-checks';
                // Deleting history needs a second click to confirm
                const remove = el('button', 'link-btn danger', 'Delete history');
                remove.type = 'button';
                remove.addEventListener('click', async () => {
                    if (!remove.dataset.confirm) {
                        remove.dataset.confirm = '1';
                        remove.textContent = `Delete ${pts.length} check${pts.length === 1 ? '' : 's'}? Click again`;
                        setTimeout(() => { if (remove.isConnected) { delete remove.dataset.confirm; remove.textContent = 'Delete history'; } }, 4000);
                        return;
                    }
                    expanded.delete(id);
                    await chrome.runtime.sendMessage({ action: 'updateTracked', id, remove: true }).catch(() => { });
                });
                actions.append(recheck, toggle, remove);
                detail.appendChild(actions);
                row.appendChild(detail);
            }
            head.addEventListener('click', () => {
                if (expanded.has(id)) expanded.delete(id); else expanded.add(id);
                renderTracked();
            });
            trackedList.appendChild(row);
        });
    }

    let lastStatus = null;
    async function renderScheduleStatus(status) {
        lastStatus = status || null;
        const running = !!(status && status.running && Date.now() - (status.updated || 0) < STATUS_STALE_MS);
        trackedRunActive = running;
        runTrackedBtn.disabled = false;
        runTrackedBtn.textContent = running ? 'Stop' : 'Check all now';
        runTrackedBtn.classList.toggle('danger-btn', running);
        scheduleStatus.classList.toggle('running', running);
        if (!status) {
            scheduleStatus.textContent = 'Not run yet.';
        } else if (running) {
            scheduleStatus.textContent = status.message;
        } else {
            const when = status.lastRun ? ` Last run ${new Date(status.lastRun).toLocaleString()}.` : '';
            const msg = status.running ? 'The last check was interrupted.' : (status.message || '');
            scheduleStatus.textContent = `${msg}${when}`;
        }
        if (!running) {
            // Show when the next automatic check is due
            const alarm = await chrome.alarms.get('scheduledRankCheck').catch(() => null);
            if (alarm && lastStatus === (status || null) && !trackedRunActive) {
                scheduleStatus.append(` Next automatic check ${new Date(alarm.scheduledTime).toLocaleString()}.`);
            }
            if (!trackedCount.textContent || trackedCount.textContent === '0') runTrackedBtn.disabled = true;
        }
    }

    scheduleSelect.addEventListener('change', () => {
        chrome.storage.local.set({ schedule: scheduleSelect.value }, async () => {
            await chrome.runtime.sendMessage({ action: 'scheduleChanged' }).catch(() => { });
            renderScheduleStatus(lastStatus);
        });
    });
    notifyModeSelect.addEventListener('change', () => {
        chrome.storage.local.set({ notifyMode: notifyModeSelect.value });
    });
    runTrackedBtn.addEventListener('click', async () => {
        if (trackedRunActive) {
            runTrackedBtn.disabled = true;
            runTrackedBtn.textContent = 'Stopping...';
            chrome.runtime.sendMessage({ action: 'cancelTracked' }).catch(() => { });
            return;
        }
        runTrackedBtn.disabled = true;
        const res = await chrome.runtime.sendMessage({ action: 'runTrackedNow' }).catch(() => null);
        if (!res || !res.ok) {
            runTrackedBtn.disabled = false;
            scheduleStatus.textContent = (res && res.error) || 'Could not start the check.';
        }
    });
    trackedSearch.addEventListener('input', () => renderTracked());
    trackedSort.addEventListener('change', () => {
        chrome.storage.local.set({ trackedSort: trackedSort.value });
        renderTracked();
    });

    exportHistoryBtn.addEventListener('click', async () => {
        const all = await getRankHistory();
        const rows = [['Keyword', 'Target', 'Region', 'Mode', 'Date', 'Position', 'URL', 'Auto-check']];
        Object.values(all).forEach(e => (e.points || []).forEach(p => rows.push([
            e.keyword, e.target, regionName(e.country), e.mode, new Date(p.date).toLocaleString(), p.rank || 'Not found', p.url || '',
            e.tracked === false ? 'off' : 'on'
        ])));
        const csv = '\uFEFF' + rows.map(r => r.map(csvCell).join(',')).join('\r\n');
        const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8;' }));
        const a = document.createElement('a');
        a.href = url;
        a.download = `rank_history_${new Date().toISOString().slice(0, 10)}.csv`;
        document.body.appendChild(a);
        a.click();
        a.remove();
        setTimeout(() => URL.revokeObjectURL(url), 1000);
    });

    // Keep the tracked view and status live while scans run elsewhere
    chrome.storage.onChanged.addListener((changes, area) => {
        if (area !== 'local') return;
        if (changes[RANK_HISTORY_KEY]) {
            if (!viewTracked.classList.contains('hidden')) renderTracked();
            else trackedCount.textContent = Object.keys(changes[RANK_HISTORY_KEY].newValue || {}).length;
        }
        if (changes.scheduleStatus) renderScheduleStatus(changes.scheduleStatus.newValue);
    });

    chrome.storage.local.get(['schedule', 'scheduleStatus', 'onboarded', 'lastView', 'notifyMode', 'trackedSort', RANK_HISTORY_KEY], (data) => {
        scheduleSelect.value = data.schedule || 'off';
        notifyModeSelect.value = data.notifyMode || 'any';
        if (data.trackedSort && trackedSort.querySelector(`option[value="${CSS.escape(data.trackedSort)}"]`)) trackedSort.value = data.trackedSort;
        trackedCount.textContent = Object.keys(data[RANK_HISTORY_KEY] || {}).length;
        renderScheduleStatus(data.scheduleStatus);
        if (!data.onboarded) onboarding.classList.remove('hidden');
        showView(location.hash === '#tracked' ? 'tracked' : (data.lastView || 'check'));
    });

    document.getElementById('dismissOnboarding').addEventListener('click', () => {
        onboarding.classList.add('hidden');
        chrome.storage.local.set({ onboarded: true });
    });

    // Offer the current tab's domain as the target (activeTab grants the URL after an icon click)
    chrome.tabs.query({ active: true, lastFocusedWindow: true }, (tabs) => {
        const tab = tabs && tabs[0];
        if (chrome.runtime.lastError || !tab || !tab.url) return;
        let host;
        try {
            const u = new URL(tab.url);
            if (!/^https?:$/.test(u.protocol) || /(^|\.)google\.[a-z.]+$/.test(u.hostname)) return;
            host = u.hostname.replace(/^www\./, '');
        } catch (e) { return; }
        if (targetUrlInput.value.trim().toLowerCase() === host) return;
        useCurrentSite.textContent = `Use ${host}`;
        useCurrentSite.classList.remove('hidden');
        useCurrentSite.addEventListener('click', () => {
            targetUrlInput.value = host;
            useCurrentSite.classList.add('hidden');
            keywordsInput.focus();
        });
    });

    // Editing the inputs after a CAPTCHA pause turns "Resume" back into a new scan
    [targetUrlInput, competitorUrlInput, keywordsInput].forEach(input => input.addEventListener('input', () => {
        if (paused && !isScanning) {
            paused = null;
            btnText.textContent = 'Find Position';
            chrome.storage.local.remove(['pausedResults', 'pausedIndex', 'pausedSummaries', 'pausedKey']);
        }
    }));

    // Keyboard: Ctrl/Cmd+Enter starts a scan, Esc stops it
    document.addEventListener('keydown', (e) => {
        if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
            e.preventDefault();
            if (viewCheck.classList.contains('hidden')) showView('check');
            if (!isScanning) searchBtn.click();
        } else if (e.key === 'Escape' && isScanning && !stopBtn.disabled) {
            stopBtn.click();
        }
    });
});
