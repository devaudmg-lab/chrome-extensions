# SEO Rank Finder

A Chrome side panel that finds where a website ranks on Google for your keywords. It reports the position and the page, for example "#14, Page 2".

## Features

- **Bulk keywords**: enter one keyword per line or separate them with commas. Duplicates are skipped.
- **Competitor comparison**: click **+** to track a second domain in the same scan.
- **Region**: Auto (Google's default for your location) or one of 36 countries.
- **Use the current site** (new in 1.2): when you open the panel from the toolbar, a "Use example.com" chip fills in the site you are on.
- **Search depth**: top 10, 30, 50 or 100 results. A shallower scan is faster and less likely to trigger a CAPTCHA.
- **Strict or broad mode**: strict counts organic results only. Broad also counts sublinks, and featured snippets and People Also Ask results are labelled.
- **Rank history and charts** (new in 1.2): every check is saved per keyword, site, region and mode (last 60 checks). The **Tracked** tab lists each keyword with its latest position, a trend line and the change since last time. Click a keyword for a full chart, its best rank, the ranking URL and recent checks. Export the whole history as CSV.
- **Automatic re-checks with notifications** (new in 1.2): choose Daily or Weekly and the extension re-checks up to 25 tracked keywords in a background tab, then shows a notification when a position changes. "Check all now" runs it on demand. If Google shows a CAPTCHA, the run stops and tells you.
- **Stop and resume**: stop a long scan at any time. If Google shows a CAPTCHA, the scan pauses, opens the tab for you to solve it, and you can click **Resume Scanning**.
- **CSV export**: includes found positions, keywords that were not found, and the scan date.
- **Domain matching**: `example.com` also matches subdomains such as `blog.example.com`, and `example.com/blog` matches only that section.

## Keyboard shortcuts

| Key | Action |
| --- | --- |
| `Alt+Shift+K` | Open SEO Rank Finder (change it at `chrome://extensions/shortcuts`) |
| `Ctrl+Enter` (`Cmd+Enter` on Mac) | Start the scan |
| `Esc` | Stop a running scan |

## Install (Load unpacked)

1. Download and unzip the release ZIP.
2. Open `chrome://extensions` and turn on **Developer mode** (top right).
3. Click **Load unpacked** and select the unzipped folder (the one containing `manifest.json`).
4. Pin SEO Rank Finder and click its icon to open the side panel. Requires Chrome 116 or newer.

## How it works

Google no longer returns results to plain background requests, so the extension opens each results page in an inactive background tab, reads the result links and closes the tab. There is a random 1-3 second pause between pages and 2.5 seconds between keywords, so Google is not flooded with requests. Results reflect your own Google session (language, consent and login state).

If you see a consent screen or CAPTCHA, solve it in the tab that opens and click Resume.

## Permissions

| Permission | Why |
| --- | --- |
| `sidePanel` | Shows the tool in Chrome's side panel. |
| `scripting` | Reads result links from the Google results tab. |
| `storage` | Saves your last inputs, paused scans, rank history and schedule on this device. |
| `activeTab` | Reads the address of the tab you opened the panel from, only to offer it as the target site. |
| `alarms` | Runs the optional daily or weekly re-check. Nothing is scheduled unless you turn it on. |
| `notifications` | Tells you when a scheduled check finds a position change, or when Google asks for a CAPTCHA. |
| `https://www.google.com/*` | The only site the extension can access, used to load search result pages. |

No data is sent to the developer or any server other than Google.
