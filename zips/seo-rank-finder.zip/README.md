# SEO Rank Finder

A Chrome side panel that finds where a website ranks on Google for your keywords. It reports the position and the page, for example "#14, Page 2".

## Features

- **Bulk keywords**: enter one keyword per line or separate them with commas. Duplicates (ignoring case) are skipped.
- **Competitor comparison**: click **+** to track a second domain in the same scan.
- **Region**: Auto (Google's default for your location) or one of 36 countries.
- **Use the current site** (new in 1.2): when you open the panel from the toolbar, a "Use example.com" chip fills in the site you are on.
- **Search depth**: top 10, 30, 50 or 100 results. A shallower scan is faster and less likely to trigger a CAPTCHA.
- **Strict or broad mode**: strict counts organic results only. Broad also counts sublinks, and featured snippets and People Also Ask results are labelled.
- **Rank history and charts**: every check is saved per keyword, site, region and mode (last 60 checks per keyword, up to 300 keywords; the least recently checked are dropped first). The **Tracked** tab lists each keyword with its latest position, a trend line and the change since last time. Click a keyword for a full chart, its best rank, the ranking URL and recent checks. Export the whole history as CSV.
- **Filter and sort tracked keywords** (new in 1.3): type to filter by keyword or site, and sort by recently checked, best position, biggest change or A-Z.
- **Choose what is auto-checked** (new in 1.3): each keyword has an **Auto-check** switch, so the scheduled runs spend their budget on the keywords you care about.
- **Automatic re-checks with notifications**: choose Daily or Weekly and the extension re-checks your auto-checked keywords in a background tab, oldest first. The panel shows when the next check is due, and you can **Stop** a running check (new in 1.3).
- **Smarter alerts** (new in 1.3): get notified on any change, only when a keyword moves 3+ or 5+ places, only when it enters or leaves the top 10, or never (CAPTCHA alerts only).
- **Polite by design** (1.3): only one Google tab loads at a time, even when a manual scan and a scheduled check overlap. Scheduled runs wait 2.5-5 s between pages and 8-20 s between keywords, load at most 60 result pages per run (the rest are checked next time), and never bring a tab to the front. After a CAPTCHA, automatic checks pause for 6 hours, then 12, 24 and at most 48 hours if it happens again; a clean run resets this.
- **Stop and resume**: stop a long scan at any time. If Google shows a CAPTCHA, the scan pauses, opens the tab for you to solve it, and you can click **Resume Scanning**.
- **CSV export**: includes found positions, keywords that were not found, and the scan date.
- **Domain matching**: `example.com` also matches subdomains such as `blog.example.com`, and `example.com/blog` matches only that section. You can paste a full URL (`https://www.example.com/`); it is cleaned up to `example.com`. Internationalised domains such as `bücher.de` work too.
- **Robust result reading**: ads are never counted, hidden People Also Ask answers are skipped in strict mode, and the parser falls back through several layers of selectors so a Google markup change degrades gracefully instead of finding nothing.

## Keyboard shortcuts

| Key | Action |
| --- | --- |
| `Alt+Shift+K` | Open SEO Rank Finder (change it at `chrome://extensions/shortcuts`) |
| `Ctrl+Enter` (`Cmd+Enter` on Mac) | Start the scan |
| `Esc` | Stop a running scan |
| `Tab` / `Enter` | Every control, including tracked keywords, is reachable and operable from the keyboard |

## Install (Load unpacked)

1. Download and unzip the release ZIP.
2. Open `chrome://extensions` and turn on **Developer mode** (top right).
3. Click **Load unpacked** and select the unzipped folder (the one containing `manifest.json`).
4. Pin SEO Rank Finder and click its icon to open the side panel. Requires Chrome 116 or newer.

## How it works

Google no longer returns results to plain background requests, so the extension opens each results page in an inactive background tab, reads the result links and closes the tab. Manual scans pause a random 1.2-3 seconds between pages and 2.5-4.5 seconds between keywords; scheduled runs are slower still (see "Polite by design"). Results reflect your own Google session (language, consent and login state).

If you see a consent screen or CAPTCHA, solve it in the tab that opens and click Resume.

## Permissions

| Permission | Why |
| --- | --- |
| `sidePanel` | Shows the tool in Chrome's side panel. |
| `scripting` | Reads result links from the Google results tab. |
| `storage` | Saves your last inputs, paused scans, rank history and schedule on this device. Session storage remembers open scan tabs so they can be closed if Chrome restarts the background worker mid-scan. |
| `activeTab` | Reads the address of the tab you opened the panel from, only to offer it as the target site. |
| `alarms` | Runs the optional daily or weekly re-check. Nothing is scheduled unless you turn it on. |
| `notifications` | Tells you when a scheduled check finds a position change (using your alert setting), or when Google asks for a CAPTCHA. |
| `https://www.google.com/*` | The only site the extension can access, used to load search result pages. |

No new permissions were added in 1.3. No data is sent to the developer or any server other than Google.
