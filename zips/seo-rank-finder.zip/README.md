# SEO Rank Finder

A Chrome side panel that finds where a website ranks on Google for your keywords. It reports the position and the page, for example "#14, Page 2".

## Features

- **Bulk keywords**: enter one keyword per line or separate them with commas. Duplicates are skipped.
- **Competitor comparison**: click **+** to track a second domain in the same scan.
- **Region**: Global, US, UK, Australia, India, Canada, Germany, France or UAE.
- **Search depth**: top 10, 30, 50 or 100 results. A shallower scan is faster and less likely to trigger a CAPTCHA.
- **Strict or broad mode**: strict counts organic results only. Broad also counts sublinks, and featured snippets and People Also Ask results are labelled.
- **Rank history**: shows your previous position and its date, plus how much the rank moved.
- **Stop and resume**: stop a long scan at any time. If Google shows a CAPTCHA, the scan pauses, opens the tab for you to solve it, and you can click **Resume Scanning**.
- **CSV export**: includes found positions, keywords that were not found, and the scan date.
- **Domain matching**: `example.com` also matches subdomains such as `blog.example.com`, and `example.com/blog` matches only that section.

## Install (Load unpacked)

1. Download and unzip the release ZIP.
2. Open `chrome://extensions` and turn on **Developer mode** (top right).
3. Click **Load unpacked** and select the unzipped folder (the one containing `manifest.json`).
4. Pin SEO Rank Finder and click its icon to open the side panel. Requires Chrome 116 or newer.

## How it works

Google no longer returns results to plain background requests, so the extension opens each results page in an inactive background tab, reads the result links and closes the tab. There is a random 1-3 second pause between pages and 2.5 seconds between keywords, so Google is not flooded with requests. Results reflect your own Google session (language, consent and login state).

If you see a consent screen or CAPTCHA, solve it in the tab that opens and click Resume.

## Permissions

| Permission | Why |
| --- | --- |
| `sidePanel` | Shows the tool in Chrome's side panel. |
| `scripting` | Reads result links from the Google results tab. |
| `storage` | Saves your last inputs, paused scans and rank history on this device. |
| `https://www.google.com/*` | The only site the extension can access, used to load search result pages. |

No data is sent to the developer or any server other than Google.
