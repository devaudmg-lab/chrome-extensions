// Swatchly colour utilities. Pure functions, no DOM access (except the optional
// canvas fallback in parseColor). Used by the popup and by the Node tests.
(function (root) {
  'use strict';

  const clamp = (n, lo, hi) => Math.min(hi, Math.max(lo, n));
  const round = (n, d = 0) => {
    const f = 10 ** d;
    return Math.round(n * f) / f;
  };

  // A colour is { r, g, b, a } with r/g/b 0-255 integers and a 0-1.
  function make(r, g, b, a = 1) {
    return {
      r: clamp(Math.round(r), 0, 255),
      g: clamp(Math.round(g), 0, 255),
      b: clamp(Math.round(b), 0, 255),
      a: clamp(round(a, 3), 0, 1),
    };
  }

  function hexByte(n) {
    return n.toString(16).padStart(2, '0');
  }

  function toHex(c, withAlpha = c.a < 1) {
    const base = `#${hexByte(c.r)}${hexByte(c.g)}${hexByte(c.b)}`;
    return (withAlpha ? base + hexByte(Math.round(c.a * 255)) : base).toUpperCase();
  }

  function rgbToHsl({ r, g, b }) {
    r /= 255; g /= 255; b /= 255;
    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    const l = (max + min) / 2;
    let h = 0;
    let s = 0;
    if (max !== min) {
      const d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      if (max === r) h = (g - b) / d + (g < b ? 6 : 0);
      else if (max === g) h = (b - r) / d + 2;
      else h = (r - g) / d + 4;
      h *= 60;
    }
    return { h, s: s * 100, l: l * 100 };
  }

  function hslToRgb(h, s, l) {
    h = ((h % 360) + 360) % 360;
    s = clamp(s, 0, 100) / 100;
    l = clamp(l, 0, 100) / 100;
    const k = (n) => (n + h / 30) % 12;
    const a = s * Math.min(l, 1 - l);
    const f = (n) => l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
    return { r: f(0) * 255, g: f(8) * 255, b: f(4) * 255 };
  }

  function alphaPart(c, sep) {
    return c.a < 1 ? `${sep}${round(c.a, 2)}` : '';
  }

  function toRgbString(c) {
    return c.a < 1 ? `rgba(${c.r}, ${c.g}, ${c.b}${alphaPart(c, ', ')})` : `rgb(${c.r}, ${c.g}, ${c.b})`;
  }

  function toHslString(c) {
    const { h, s, l } = rgbToHsl(c);
    const body = `${Math.round(h)}, ${Math.round(s)}%, ${Math.round(l)}%`;
    return c.a < 1 ? `hsla(${body}${alphaPart(c, ', ')})` : `hsl(${body})`;
  }

  function format(c, fmt) {
    if (fmt === 'rgb') return toRgbString(c);
    if (fmt === 'hsl') return toHslString(c);
    return toHex(c);
  }

  function num(str, scale) {
    // "50%" -> 0.5 * scale ; "128" -> 128
    const s = String(str).trim();
    if (s.endsWith('%')) return (parseFloat(s) / 100) * scale;
    return parseFloat(s);
  }

  function parseAlpha(str) {
    if (str === undefined) return 1;
    const s = String(str).trim();
    const v = s.endsWith('%') ? parseFloat(s) / 100 : parseFloat(s);
    return Number.isFinite(v) ? clamp(v, 0, 1) : NaN;
  }

  function parseHue(str) {
    const s = String(str).trim().toLowerCase();
    const v = parseFloat(s);
    if (s.endsWith('turn')) return v * 360;
    if (s.endsWith('rad')) return (v * 180) / Math.PI;
    if (s.endsWith('grad')) return v * 0.9;
    return v;
  }

  // Splits "r g b / a" or "r, g, b, a" into parts.
  function splitArgs(inner) {
    let alpha;
    let main = inner;
    const slash = inner.indexOf('/');
    if (slash !== -1) {
      alpha = inner.slice(slash + 1).trim();
      main = inner.slice(0, slash);
    }
    const parts = main.split(/[\s,]+/).filter(Boolean);
    if (alpha === undefined && parts.length === 4) alpha = parts.pop();
    return { parts, alpha };
  }

  // Parses hex, rgb()/rgba(), hsl()/hsla(). Returns null when it can't.
  // In a browser, any other valid CSS colour (named colours, oklch() ...) is
  // resolved through a 1x1 canvas when `canvasFallback` is true.
  function parseColor(input, canvasFallback = true) {
    if (input && typeof input === 'object' && 'r' in input) return make(input.r, input.g, input.b, input.a);
    if (typeof input !== 'string') return null;
    const s = input.trim().toLowerCase();
    if (!s || s.length > 200) return null;

    let m = /^#?([0-9a-f]{3,4}|[0-9a-f]{6}|[0-9a-f]{8})$/.exec(s);
    if (m) {
      let h = m[1];
      if (h.length <= 4) h = [...h].map((ch) => ch + ch).join('');
      const a = h.length === 8 ? parseInt(h.slice(6, 8), 16) / 255 : 1;
      return make(parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16), a);
    }

    m = /^rgba?\((.*)\)$/.exec(s);
    if (m) {
      const { parts, alpha } = splitArgs(m[1]);
      if (parts.length !== 3) return null;
      const [r, g, b] = parts.map((p) => num(p, 255));
      const a = parseAlpha(alpha);
      if (![r, g, b, a].every(Number.isFinite)) return null;
      return make(r, g, b, a);
    }

    m = /^hsla?\((.*)\)$/.exec(s);
    if (m) {
      const { parts, alpha } = splitArgs(m[1]);
      if (parts.length !== 3) return null;
      const h = parseHue(parts[0]);
      const sat = parseFloat(parts[1]);
      const light = parseFloat(parts[2]);
      const a = parseAlpha(alpha);
      if (![h, sat, light, a].every(Number.isFinite)) return null;
      const { r, g, b } = hslToRgb(h, sat, light);
      return make(r, g, b, a);
    }

    if (canvasFallback && typeof document !== 'undefined' && typeof CSS !== 'undefined' && CSS.supports('color', s)) {
      const canvas = document.createElement('canvas');
      canvas.width = canvas.height = 1;
      const ctx = canvas.getContext('2d', { willReadFrequently: true });
      ctx.clearRect(0, 0, 1, 1);
      ctx.fillStyle = s;
      ctx.fillRect(0, 0, 1, 1);
      const d = ctx.getImageData(0, 0, 1, 1).data;
      return make(d[0], d[1], d[2], d[3] / 255);
    }
    return null;
  }

  // Composites a (possibly translucent) colour over an opaque backdrop.
  function blend(top, bottom) {
    const a = top.a;
    return make(
      top.r * a + bottom.r * (1 - a),
      top.g * a + bottom.g * (1 - a),
      top.b * a + bottom.b * (1 - a),
      1,
    );
  }

  function channel(v) {
    const c = v / 255;
    return c <= 0.04045 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4;
  }

  function luminance(c) {
    return 0.2126 * channel(c.r) + 0.7152 * channel(c.g) + 0.0722 * channel(c.b);
  }

  const WHITE = make(255, 255, 255);

  // WCAG 2.x contrast ratio. A translucent background is laid over white
  // (the browser default canvas); a translucent foreground over the background.
  function contrast(fg, bg) {
    const solidBg = bg.a < 1 ? blend(bg, WHITE) : bg;
    const solidFg = fg.a < 1 ? blend(fg, solidBg) : fg;
    const l1 = luminance(solidFg);
    const l2 = luminance(solidBg);
    return (Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05);
  }

  function grade(ratio) {
    return {
      normalAA: ratio >= 4.5,
      normalAAA: ratio >= 7,
      largeAA: ratio >= 3,
      largeAAA: ratio >= 4.5,
      ui: ratio >= 3,
    };
  }

  // Finds the foreground colour closest in lightness to `fg` (same hue and
  // saturation) that reaches `target` against `bg`. Returns null if even
  // black/white of that hue can't.
  function fixContrast(fg, bg, target = 4.5) {
    const solidFg = make(fg.r, fg.g, fg.b, 1);
    if (contrast(solidFg, bg) >= target) return solidFg;
    const { h, s, l } = rgbToHsl(solidFg);
    const search = (towardDark) => {
      // Contrast changes monotonically with lightness on each side of bg, so
      // binary-search for the passing value nearest the original lightness.
      let lo = towardDark ? 0 : l;
      let hi = towardDark ? l : 100;
      const end = towardDark ? 0 : 100;
      const at = (L) => {
        const { r, g, b } = hslToRgb(h, s, L);
        return make(r, g, b, 1);
      };
      if (contrast(at(end), bg) < target) return null;
      for (let i = 0; i < 30; i++) {
        const mid = (lo + hi) / 2;
        const passes = contrast(at(mid), bg) >= target;
        if (towardDark) { if (passes) lo = mid; else hi = mid; } else if (passes) hi = mid; else lo = mid;
      }
      const L = towardDark ? lo : hi;
      // Rounding to 8-bit can drop us just under the target; nudge outward.
      let best = at(L);
      for (let step = 0.25, L2 = L; contrast(best, bg) < target && step < 100; step += 0.25) {
        L2 = towardDark ? L - step : L + step;
        best = at(clamp(L2, 0, 100));
      }
      return contrast(best, bg) >= target ? { color: best, distance: Math.abs(L - l) } : null;
    };
    const options = [search(true), search(false)].filter(Boolean);
    if (!options.length) return null;
    options.sort((a, b) => a.distance - b.distance);
    return options[0].color;
  }

  // Builds export text for a list of colours ({ hex } or colour objects).
  function exportPalette(colors, kind, fmt = 'hex') {
    const list = colors.map((c) => parseColor(c.hex || c, false)).filter(Boolean);
    if (kind === 'json') {
      return JSON.stringify(list.map((c) => ({ hex: toHex(c), rgb: toRgbString(c), hsl: toHslString(c) })), null, 2);
    }
    if (kind === 'css') {
      const lines = list.map((c, i) => `  --color-${i + 1}: ${format(c, fmt)};`);
      return `:root {\n${lines.join('\n')}\n}`;
    }
    return list.map((c) => format(c, fmt)).join('\n');
  }

  const api = {
    make, parseColor, toHex, toRgbString, toHslString, format, rgbToHsl, hslToRgb,
    luminance, contrast, grade, fixContrast, blend, exportPalette,
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.SwatchColor = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
