# Swatchly: Eyedropper & Page Palette

Pick any colour on screen, see every colour a web page uses, check text contrast, and copy colours as HEX, RGB or HSL. Version 1.0.0, Manifest V3.

> **About the folder name:** this extension lives in `my-first-extension/` for historical reasons. It started as a one-button "Color Changer" sample and grew into Swatchly. The folder name has no meaning for the extension itself.

## Features

- **Eyedropper.** Click **Pick colour** (or press **E**) and click any pixel on screen. The colour is copied right away in your chosen format.
- **Page palette.** Lists the colours the current page actually uses, most used first: backgrounds (weighted by area), text, borders, SVG icons and gradient stops. Modern colour syntaxes (`oklch()`, `lab()`, `color(display-p3 ...)`) are converted to sRGB. Translucent colours keep their alpha (`#RRGGBBAA`).
- **Filters.** Show all colours, or only backgrounds, text & icons, or borders.
- **Export.** Copy the palette as CSS variables, JSON or a plain list (in the selected format), or download it as a `.json` file with usage counts and roles.
- **Contrast checker.** WCAG 2.x ratio for any text and background pair, with pass/fail for normal text (AA 4.5, AAA 7), large text (AA 3, AAA 4.5) and UI components (3). Pick either colour with the eyedropper, type any CSS colour, or swap them. When a pair fails, Swatchly suggests the closest passing text colour (same hue) and applies it in one click.
- **History.** The last 32 colours you picked or copied. Click to copy again, press **Delete** to remove one, or copy them all as CSS.
- **Paint page.** Set the page background to the current colour to preview it, and undo it with one click. Works on pages with a strict Content Security Policy.
- Light and dark popup that follows your system theme, full keyboard support, nothing collected or sent anywhere.

## Keyboard shortcuts

| Shortcut | Action |
| :--- | :--- |
| **Alt+Shift+C** | Open Swatchly (change it at `chrome://extensions/shortcuts`) |
| **E** (in the popup) | Start the eyedropper |
| **C** (in the popup) | Copy the current colour in the selected format |
| **Esc** (while picking) | Cancel the eyedropper |
| **Left / Right arrows** | Move between tabs, formats and filters |
| **Delete** (on a history colour) | Remove it from history |

## Permissions

| Permission | Why it is needed |
| :--- | :--- |
| `activeTab` | Gives Swatchly temporary access to the tab you are on, only after you open the popup. It is used to read the page's colours and to paint its background. No other tabs are touched. |
| `scripting` | Runs the short, built-in palette scan and the "Paint page" function in that tab. No remote code is ever loaded. |

There are no host permissions, no `<all_urls>`, no background service worker and no content scripts that run on every page. The eyedropper is a browser feature (the EyeDropper API) and needs no permission. Settings, history and the contrast pair are kept in the extension's own local storage on your computer.

## Limits

- Browsers do not let extensions read some pages: `chrome://` pages, the Chrome Web Store and the built-in PDF viewer. The eyedropper still works there; the palette and Paint page do not.
- For local `file://` pages, turn on **Allow access to file URLs** in the extension's details.
- The palette reads the top page only, not cross-origin iframes. Images and videos are not sampled (use the eyedropper for those).
- On very large pages the scan stops after 10,000 elements or about 0.7 seconds and says so.

## Files

```
manifest.json   MV3 manifest
popup.html      Popup markup
popup.css       Popup styles (light and dark)
popup.js        Popup logic, palette scan and paint functions injected on demand
color.js        Colour parsing, formatting, WCAG contrast and contrast fixing
icons/          16, 32, 48 and 128 px icons
```

## Install for development

1. Open `chrome://extensions` and turn on **Developer mode**.
2. Click **Load unpacked** and choose this folder.
