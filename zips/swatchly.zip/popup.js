'use strict';
/* global SwatchColor */
const C = SwatchColor;
const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => [...document.querySelectorAll(sel)];

const HISTORY_MAX = 32;
const KEYS = { fmt: 'swatchly.fmt', current: 'swatchly.current', fg: 'swatchly.fg', bg: 'swatchly.bg', history: 'swatchly.history', tab: 'swatchly.tab' };

// localStorage of the extension origin: private to the extension, survives
// restarts, needs no extra permission. Every access is guarded.
const store = {
  get(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      return raw === null ? fallback : JSON.parse(raw);
    } catch { return fallback; }
  },
  set(key, value) {
    try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* storage unavailable: keep working in memory */ }
  },
};

const validHex = (v) => typeof v === 'string' && /^#[0-9A-F]{6}([0-9A-F]{2})?$/i.test(v);
const loadColor = (key, fallback) => {
  const v = store.get(key, fallback);
  return C.parseColor(validHex(v) ? v : fallback, false);
};

const state = {
  fmt: ['hex', 'rgb', 'hsl'].includes(store.get(KEYS.fmt)) ? store.get(KEYS.fmt) : 'hex',
  current: loadColor(KEYS.current, '#D6336C'),
  fg: loadColor(KEYS.fg, '#1F2937'),
  bg: loadColor(KEYS.bg, '#FFFFFF'),
  history: (store.get(KEYS.history, []) || []).filter(validHex).slice(0, HISTORY_MAX),
  palette: null, // { colors: [{hex,count,roles}], ... }
  role: 'all',
  selectedHex: null,
  tab: null,
};

// ---------- feedback ----------
let toastTimer;
function toast(msg) {
  const el = $('#toast');
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), 1600);
}

async function copyText(text, label = text) {
  try {
    await navigator.clipboard.writeText(text);
  } catch {
    // Fallback for when the async clipboard is refused (e.g. document not focused).
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    const ok = document.execCommand('copy');
    ta.remove();
    if (!ok) { toast('Could not copy to the clipboard'); return false; }
  }
  toast(`Copied ${label.length > 40 ? label.slice(0, 40) + '…' : label}`);
  return true;
}

// ---------- current colour ----------
function cssOf(c) { return C.toRgbString(c); }

function renderCurrent() {
  const c = state.current;
  $('#swatch span').style.background = cssOf(c);
  $('#vHex').textContent = C.toHex(c);
  $('#vRgb').textContent = C.toRgbString(c);
  $('#vHsl').textContent = C.toHslString(c);
  $('#swatch').title = C.toHex(c);
}

function setCurrent(c, { remember = true } = {}) {
  state.current = c;
  store.set(KEYS.current, C.toHex(c));
  renderCurrent();
  if (remember) addHistory(c);
}

// ---------- history ----------
function addHistory(c) {
  const hex = C.toHex(c);
  state.history = [hex, ...state.history.filter((h) => h !== hex)].slice(0, HISTORY_MAX);
  store.set(KEYS.history, state.history);
  renderHistory();
}

function makeChip(hex, title, extra) {
  const b = document.createElement('button');
  b.type = 'button';
  b.className = 'chip checker';
  b.dataset.hex = hex;
  b.title = title;
  b.setAttribute('aria-label', title);
  const fill = document.createElement('span');
  fill.style.background = cssOf(C.parseColor(hex, false));
  b.appendChild(fill);
  if (extra) {
    const i = document.createElement('i');
    i.textContent = extra;
    b.appendChild(i);
  }
  return b;
}

function renderHistory() {
  const box = $('#history');
  box.replaceChildren(...state.history.map((hex) => makeChip(hex, `${hex} (Enter to copy, Delete to remove)`)));
  $('#historyEmpty').hidden = state.history.length > 0;
  $$('[data-export-history], #clearHistory').forEach((b) => { b.disabled = !state.history.length; });
}

// ---------- eyedropper ----------
let picking = false;
async function pickColor(target = 'current') {
  if (!('EyeDropper' in window)) {
    toast('This browser has no eyedropper (needs Chrome or Edge 95+)');
    return;
  }
  if (picking) return;
  picking = true;
  try {
    const { sRGBHex } = await new window.EyeDropper().open();
    const c = C.parseColor(sRGBHex);
    if (!c) return;
    if (target === 'fg' || target === 'bg') {
      setPair(target, c);
      addHistory(c);
      toast(`${target === 'fg' ? 'Text' : 'Background'} set to ${C.toHex(c)}`);
    } else {
      setCurrent(c);
      await copyText(C.format(c, state.fmt));
    }
  } catch (err) {
    if (err && err.name !== 'AbortError') toast('The eyedropper could not start');
  } finally {
    picking = false;
  }
}

// ---------- page access ----------
async function activeTab() {
  if (state.tab) return state.tab;
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  state.tab = tab || null;
  return state.tab;
}

function explainScriptError(err, tab) {
  const url = (tab && tab.url) || '';
  if (url.startsWith('file:')) return 'To use this on local files, turn on "Allow access to file URLs" in the extension details.';
  const msg = String((err && err.message) || err);
  if (/cannot be scripted|cannot access|chrome:\/\/|edge:\/\/|Missing host permission|extensions gallery|webstore/i.test(msg) || /^(chrome|edge|about|view-source|devtools|chrome-extension):/.test(url)) {
    return "The browser doesn't let extensions read this page (browser pages, the Web Store, PDFs). The eyedropper still works here.";
  }
  if (/No tab|tab was closed|No frame/i.test(msg)) return 'This tab is no longer available. Reopen the popup.';
  return "Couldn't read this page. Reload it and try again.";
}

async function runInPage(func, args = []) {
  const tab = await activeTab();
  if (!tab || tab.id === undefined) throw new Error('No tab');
  const [res] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func, args });
  return res ? res.result : undefined;
}

// Injected into the page (top frame). Must be self-contained.
function scanPagePalette(maxColors) {
  if (document.contentType === 'application/pdf') return { pdf: true };
  const started = performance.now();
  const TIME_BUDGET = 700;
  const MAX_ELEMENTS = 10000;
  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = 1;
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  const cache = new Map();
  const hx = (n) => Math.round(n).toString(16).padStart(2, '0');

  const keyOf = (v) => {
    if (!v || v === 'transparent' || v === 'none' || v === 'currentcolor' || v.startsWith('url(')) return null;
    if (cache.has(v)) return cache.get(v);
    let r; let g; let b; let a = 1;
    const m = /^rgba?\(([\d.]+),\s*([\d.]+),\s*([\d.]+)(?:,\s*([\d.]+))?\)$/.exec(v);
    if (m) {
      r = +m[1]; g = +m[2]; b = +m[3];
      if (m[4] !== undefined) a = +m[4];
    } else {
      // Any other syntax (oklch(), color(display-p3 ...), lab() ...) -> sRGB via canvas.
      ctx.clearRect(0, 0, 1, 1);
      ctx.fillStyle = 'rgba(0,0,0,0)';
      ctx.fillStyle = v;
      ctx.fillRect(0, 0, 1, 1);
      const d = ctx.getImageData(0, 0, 1, 1).data;
      r = d[0]; g = d[1]; b = d[2]; a = d[3] / 255;
    }
    const key = a < 0.05 ? null : `#${hx(r)}${hx(g)}${hx(b)}${a < 0.995 ? hx(a * 255) : ''}`.toUpperCase();
    cache.set(v, key);
    return key;
  };

  const found = new Map();
  const add = (value, role, weight) => {
    const key = keyOf(value);
    if (!key) return;
    let e = found.get(key);
    if (!e) { e = { hex: key, score: 0, count: 0, roles: {} }; found.set(key, e); }
    e.score += weight;
    e.count += 1;
    e.roles[role] = (e.roles[role] || 0) + 1;
  };

  const SKIP = new Set(['SCRIPT', 'STYLE', 'META', 'LINK', 'HEAD', 'TITLE', 'NOSCRIPT', 'TEMPLATE', 'BR', 'WBR', 'BASE']);
  const SVG_SHAPES = new Set(['path', 'rect', 'circle', 'ellipse', 'polygon', 'polyline', 'line', 'text', 'tspan', 'use']);
  const viewportArea = Math.max(1, innerWidth * innerHeight);
  const root = document.documentElement;
  const all = root.getElementsByTagName('*');
  const total = all.length + 1;
  let scanned = 0;
  let rootBg = null;
  let timedOut = false;

  const hasOwnText = (el) => {
    for (let n = el.firstChild; n; n = n.nextSibling) {
      if (n.nodeType === 3 && n.nodeValue.trim()) return true;
    }
    return false;
  };

  const visit = (el) => {
    if (SKIP.has(el.tagName)) return;
    const cs = getComputedStyle(el);
    if (cs.display === 'none' || cs.visibility === 'hidden' || cs.visibility === 'collapse' || +cs.opacity === 0) return;
    const rect = el.getBoundingClientRect();
    const area = rect.width * rect.height;
    const isSvg = el instanceof SVGElement;
    if (area === 0 && !isSvg && el !== root && el !== document.body) return;

    const bgKey = keyOf(cs.backgroundColor);
    if (bgKey) {
      add(cs.backgroundColor, 'bg', 1 + Math.min(area, viewportArea * 3) / 4000);
      if (el === root || el === document.body) rootBg = rootBg || bgKey;
    }
    if (cs.backgroundImage && cs.backgroundImage.includes('gradient')) {
      const stops = cs.backgroundImage.match(/(rgba?|oklch|oklab|lab|lch|color)\([^()]*\)/g) || [];
      stops.forEach((s) => add(s, 'bg', 1 + Math.min(area, viewportArea) / 20000));
    }
    if (hasOwnText(el)) add(cs.color, 'text', 2);
    const seen = new Set();
    for (const side of ['Top', 'Right', 'Bottom', 'Left']) {
      if (parseFloat(cs[`border${side}Width`]) > 0 && cs[`border${side}Style`] !== 'none' && cs[`border${side}Style`] !== 'hidden') {
        const v = cs[`border${side}Color`];
        if (!seen.has(v)) { seen.add(v); add(v, 'border', 1); }
      }
    }
    if (isSvg && SVG_SHAPES.has(el.tagName.toLowerCase())) {
      add(cs.fill, 'svg', 1);
      add(cs.stroke, 'svg', 1);
    }
  };

  visit(root);
  scanned++;
  for (let i = 0; i < all.length && i < MAX_ELEMENTS; i++) {
    if ((i & 127) === 0 && performance.now() - started > TIME_BUDGET) { timedOut = true; break; }
    visit(all[i]);
    scanned++;
  }

  // No background on <html>/<body>: the page shows the browser's canvas colour.
  if (!rootBg) {
    const dark = getComputedStyle(root).colorScheme.trim() === 'dark';
    add(dark ? 'rgb(18, 18, 18)' : 'rgb(255, 255, 255)', 'bg', 1 + viewportArea / 4000);
  }

  const colors = [...found.values()]
    .sort((x, y) => y.score - x.score)
    .slice(0, maxColors)
    .map(({ hex, count, roles }) => ({ hex, count, roles: Object.keys(roles) }));
  return { colors, scanned, total, truncated: scanned < total || timedOut, distinct: found.size };
}

// Injected: sets or restores the page background (inline CSSOM, works under strict CSP).
function paintPageBackground(color) {
  const els = [document.documentElement, document.body].filter(Boolean);
  const KEY = '__swatchlyPrevBackground';
  if (color === null) {
    const prev = globalThis[KEY];
    if (!prev) return false;
    prev.forEach(({ el, value, priority }) => {
      if (value) el.style.setProperty('background', value, priority);
      else el.style.removeProperty('background');
    });
    delete globalThis[KEY];
    return true;
  }
  if (!/^#[0-9a-f]{6}([0-9a-f]{2})?$/i.test(color)) return false;
  if (!globalThis[KEY]) {
    globalThis[KEY] = els.map((el) => ({
      el, value: el.style.getPropertyValue('background'), priority: el.style.getPropertyPriority('background'),
    }));
  }
  els.forEach((el) => el.style.setProperty('background', color, 'important'));
  return true;
}

// ---------- palette ----------
const ROLE_NAMES = { bg: 'background', text: 'text', border: 'border', svg: 'icon/SVG' };

async function scan() {
  const status = $('#paletteStatus');
  status.classList.remove('error');
  status.textContent = 'Scanning page…';
  $('#rescan').disabled = true;
  try {
    const result = await runInPage(scanPagePalette, [64]);
    if (!result) throw new Error('No result');
    if (result.pdf) {
      state.palette = null;
      status.textContent = "PDF files can't be scanned. Use the eyedropper instead.";
      renderPalette();
      return;
    }
    state.palette = result;
    renderPalette();
  } catch (err) {
    state.palette = null;
    renderPalette();
    status.textContent = explainScriptError(err, state.tab);
    status.classList.add('error');
  } finally {
    $('#rescan').disabled = false;
  }
}

function visibleColors() {
  if (!state.palette) return [];
  const list = state.palette.colors;
  if (state.role === 'all') return list;
  if (state.role === 'bg') return list.filter((c) => c.roles.includes('bg'));
  if (state.role === 'border') return list.filter((c) => c.roles.includes('border'));
  return list.filter((c) => c.roles.includes('text') || c.roles.includes('svg'));
}

function renderPalette() {
  const box = $('#palette');
  const colors = visibleColors();
  box.replaceChildren(...colors.map((c) => {
    const roles = c.roles.map((r) => ROLE_NAMES[r] || r).join(', ');
    const chip = makeChip(c.hex, `${c.hex}, used ${c.count}× as ${roles}`);
    chip.setAttribute('aria-pressed', String(c.hex === state.selectedHex));
    return chip;
  }));
  const p = state.palette;
  const hasColors = colors.length > 0;
  $$('[data-export], #downloadJson').forEach((b) => { b.disabled = !hasColors; });
  if (!p) return;
  const status = $('#paletteStatus');
  if (!p.colors.length) status.textContent = 'No colours found on this page.';
  else if (!hasColors) status.textContent = 'No colours with this role.';
  else {
    const shown = p.distinct > p.colors.length ? `top ${p.colors.length} of ${p.distinct}` : `${p.colors.length}`;
    status.textContent = `${shown} colours, most used first${p.truncated ? ` (scanned ${p.scanned.toLocaleString()} elements)` : ''}. Click to copy.`;
  }
}

function exportText(kind, colors) {
  return C.exportPalette(colors, kind, state.fmt);
}

function downloadJson() {
  const colors = visibleColors();
  if (!colors.length) return;
  const data = {
    source: state.tab && state.tab.url ? state.tab.url : undefined,
    exported: new Date().toISOString(),
    colors: JSON.parse(exportText('json', colors)).map((c, i) => ({ ...c, uses: colors[i].count, roles: colors[i].roles })),
  };
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  let host = 'page';
  try { host = new URL(state.tab.url).hostname.replace(/[^a-z0-9.-]/gi, '') || 'page'; } catch { /* keep default */ }
  const a = document.createElement('a');
  a.href = url;
  a.download = `palette-${host}.json`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
  toast('Palette downloaded');
}

// ---------- contrast ----------
function setPair(which, c, { syncText = true } = {}) {
  state[which] = c;
  store.set(KEYS[which], C.toHex(c));
  if (syncText) {
    $(`#${which}Text`).value = C.format(c, state.fmt);
    $(`#${which}Text`).removeAttribute('aria-invalid');
  }
  $(`#${which}Picker`).value = C.toHex(c, false).toLowerCase();
  renderContrast();
}

function renderContrast() {
  const { fg, bg } = state;
  const ratio = C.contrast(fg, bg);
  const g = C.grade(ratio);
  const preview = $('#preview');
  preview.style.color = cssOf(fg);
  preview.style.background = cssOf(bg.a < 1 ? C.blend(bg, C.make(255, 255, 255)) : bg);
  const shown = Math.floor(ratio * 100) / 100; // never round up into a pass
  $('#ratio').textContent = `${shown.toFixed(2)}:1`;
  const rows = [
    ['Text AA', g.normalAA], ['Text AAA', g.normalAAA],
    ['Large AA', g.largeAA], ['Large AAA', g.largeAAA],
    ['UI & icons', g.ui],
  ];
  $('#grades').replaceChildren(...rows.map(([label, ok]) => {
    const li = document.createElement('li');
    li.className = ok ? 'ok' : 'no';
    const b = document.createElement('b');
    b.textContent = ok ? 'Pass' : 'Fail';
    li.append(b, document.createTextNode(label));
    return li;
  }));

  const target = !g.normalAA ? 4.5 : !g.normalAAA ? 7 : null;
  const fix = target ? C.fixContrast(fg, bg, target) : null;
  const row = $('#fixRow');
  row.hidden = !fix;
  if (fix) {
    row.dataset.hex = C.toHex(fix);
    $('#fixText').textContent = `Closest text colour for ${target === 7 ? 'AAA' : 'AA'}: ${C.format(fix, state.fmt)} (${(Math.floor(C.contrast(fix, bg) * 100) / 100).toFixed(2)}:1)`;
  }
}

function bindPairInputs(which) {
  const text = $(`#${which}Text`);
  text.addEventListener('input', () => {
    const c = C.parseColor(text.value);
    if (c) { text.removeAttribute('aria-invalid'); setPair(which, c, { syncText: false }); } else text.setAttribute('aria-invalid', 'true');
  });
  text.addEventListener('change', () => { if (C.parseColor(text.value)) setPair(which, state[which]); });
  text.addEventListener('blur', () => { setPair(which, state[which]); });
  $(`#${which}Picker`).addEventListener('input', (e) => {
    const c = C.parseColor(e.target.value, false);
    if (c) setPair(which, c);
  });
}

// ---------- format & tabs ----------
function setFormat(fmt) {
  state.fmt = fmt;
  store.set(KEYS.fmt, fmt);
  $$('.seg button').forEach((b) => b.setAttribute('aria-checked', String(b.dataset.fmt === fmt)));
  setPair('fg', state.fg);
  setPair('bg', state.bg);
}

const TABS = ['palette', 'contrast', 'history'];
function showTab(name, focus = false) {
  if (!TABS.includes(name)) name = 'palette';
  TABS.forEach((t) => {
    const btn = $(`#tab-${t}`);
    const on = t === name;
    btn.setAttribute('aria-selected', String(on));
    btn.tabIndex = on ? 0 : -1;
    $(`#panel-${t}`).hidden = !on;
    if (on && focus) btn.focus();
  });
  store.set(KEYS.tab, name);
  if (name === 'palette' && !state.palette && !state.scanStarted) {
    state.scanStarted = true;
    scan();
  }
}

// ---------- wiring ----------
function radioGroupKeys(container, onPick) {
  container.addEventListener('keydown', (e) => {
    if (!['ArrowLeft', 'ArrowRight'].includes(e.key)) return;
    const btns = [...container.querySelectorAll('button')];
    const i = btns.indexOf(document.activeElement);
    if (i === -1) return;
    const next = btns[(i + (e.key === 'ArrowRight' ? 1 : btns.length - 1)) % btns.length];
    e.preventDefault();
    next.focus();
    onPick(next);
  });
}

function chipClick(container, getColor) {
  container.addEventListener('click', async (e) => {
    const chip = e.target.closest('.chip');
    if (!chip) return;
    const c = getColor(chip.dataset.hex);
    if (!c) return;
    state.selectedHex = chip.dataset.hex;
    setCurrent(c);
    if (container.id === 'palette') renderPalette();
    await copyText(C.format(c, state.fmt));
  });
}

function init() {
  renderCurrent();
  renderHistory();
  setFormat(state.fmt);

  $('#pickBtn').addEventListener('click', () => pickColor('current'));
  $$('[data-pick]').forEach((b) => b.addEventListener('click', () => pickColor(b.dataset.pick)));

  $$('.copy').forEach((b) => b.addEventListener('click', () => {
    addHistory(state.current);
    copyText(C.format(state.current, b.dataset.copy));
  }));

  $$('.seg button').forEach((b) => b.addEventListener('click', () => setFormat(b.dataset.fmt)));
  radioGroupKeys($('.seg'), (b) => setFormat(b.dataset.fmt));

  $('#useFg').addEventListener('click', () => { setPair('fg', state.current); showTab('contrast'); });
  $('#useBg').addEventListener('click', () => { setPair('bg', state.current); showTab('contrast'); });
  $('#swap').addEventListener('click', () => {
    const { fg, bg } = state;
    setPair('fg', bg);
    setPair('bg', fg);
  });
  $('#fixBtn').addEventListener('click', () => {
    const c = C.parseColor($('#fixRow').dataset.hex, false);
    if (c) { setPair('fg', c); toast(`Text set to ${C.toHex(c)}`); }
  });
  bindPairInputs('fg');
  bindPairInputs('bg');

  $('#paintBtn').addEventListener('click', async () => {
    try {
      const ok = await runInPage(paintPageBackground, [C.toHex(state.current)]);
      toast(ok ? `Page background set to ${C.toHex(state.current)}` : 'Could not change this page');
    } catch (err) { toast(explainScriptError(err, state.tab)); }
  });
  $('#resetPaint').addEventListener('click', async () => {
    try {
      const ok = await runInPage(paintPageBackground, [null]);
      toast(ok ? 'Page background restored' : 'Nothing to undo on this page');
    } catch (err) { toast(explainScriptError(err, state.tab)); }
  });

  $$('[role="tab"]').forEach((b) => b.addEventListener('click', () => showTab(b.id.replace('tab-', ''))));
  $('.tabs').addEventListener('keydown', (e) => {
    if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(e.key)) return;
    const current = TABS.findIndex((t) => $(`#tab-${t}`).getAttribute('aria-selected') === 'true');
    let i = current;
    if (e.key === 'ArrowRight') i = (current + 1) % TABS.length;
    else if (e.key === 'ArrowLeft') i = (current + TABS.length - 1) % TABS.length;
    else if (e.key === 'Home') i = 0;
    else i = TABS.length - 1;
    e.preventDefault();
    showTab(TABS[i], true);
  });

  $$('.chips button').forEach((b) => b.addEventListener('click', () => {
    state.role = b.dataset.role;
    $$('.chips button').forEach((x) => x.setAttribute('aria-checked', String(x === b)));
    renderPalette();
  }));
  radioGroupKeys($('.chips'), (b) => b.click());
  $('#rescan').addEventListener('click', scan);

  chipClick($('#palette'), (hex) => C.parseColor(hex, false));
  chipClick($('#history'), (hex) => C.parseColor(hex, false));
  $('#history').addEventListener('keydown', (e) => {
    const chip = e.target.closest('.chip');
    if (!chip || (e.key !== 'Delete' && e.key !== 'Backspace')) return;
    const idx = state.history.indexOf(chip.dataset.hex);
    state.history = state.history.filter((h) => h !== chip.dataset.hex);
    store.set(KEYS.history, state.history);
    renderHistory();
    const chips = $$('#history .chip');
    if (chips.length) chips[Math.min(idx, chips.length - 1)].focus();
    else $('#tab-history').focus();
  });

  $$('[data-export]').forEach((b) => b.addEventListener('click', () => {
    const colors = visibleColors();
    if (colors.length) copyText(exportText(b.dataset.export, colors), `${colors.length} colours as ${b.textContent}`);
  }));
  $('#downloadJson').addEventListener('click', downloadJson);
  $('[data-export-history]').addEventListener('click', () => {
    if (state.history.length) copyText(C.exportPalette(state.history, 'css', state.fmt), `${state.history.length} colours as CSS`);
  });
  $('#clearHistory').addEventListener('click', () => {
    state.history = [];
    store.set(KEYS.history, []);
    renderHistory();
    toast('History cleared');
  });

  // Single-key shortcuts while the popup is open (ignored while typing).
  document.addEventListener('keydown', (e) => {
    if (e.ctrlKey || e.metaKey || e.altKey || e.target.matches('input, textarea')) return;
    const k = e.key.toLowerCase();
    if (k === 'e') { e.preventDefault(); pickColor('current'); } else if (k === 'c') { e.preventDefault(); addHistory(state.current); copyText(C.format(state.current, state.fmt)); }
  });

  showTab(store.get(KEYS.tab, 'palette'));
  $('#pickBtn').focus();
}

init();
