/**
 * Blur Remover & DOM Modifier - Shared DOM helpers
 * Used by the content engine, element picker, reader view, popup and options page.
 */

(function (global) {
  'use strict';

  if (global.BlurRemoverDom) return;

  const TOAST_HOST_ID = 'blur-remover-toast-root';

  function escapeHtml(str) {
    if (str === null || str === undefined) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  /** Makes text safe to place inside a CSS comment. */
  function sanitizeCssComment(text) {
    return String(text || '').replace(/\*\//g, '* /').replace(/\/\*/g, '/ *').replace(/[\r\n]+/g, ' ').slice(0, 200);
  }

  /**
   * Splits a selector list on top-level commas only, respecting (), [] and quotes.
   * "a, b:is(c, d), [x='1,2']" -> ["a", "b:is(c, d)", "[x='1,2']"]
   */
  function splitSelectorList(selector) {
    const parts = [];
    let depthParen = 0;
    let depthBracket = 0;
    let quote = null;
    let current = '';
    const s = String(selector || '');
    for (let i = 0; i < s.length; i++) {
      const ch = s[i];
      if (quote) {
        current += ch;
        if (ch === '\\' && i + 1 < s.length) {
          current += s[++i];
        } else if (ch === quote) {
          quote = null;
        }
        continue;
      }
      if (ch === '"' || ch === "'") {
        quote = ch;
      } else if (ch === '(') {
        depthParen++;
      } else if (ch === ')') {
        depthParen = Math.max(0, depthParen - 1);
      } else if (ch === '[') {
        depthBracket++;
      } else if (ch === ']') {
        depthBracket = Math.max(0, depthBracket - 1);
      } else if (ch === ',' && depthParen === 0 && depthBracket === 0) {
        if (current.trim()) parts.push(current.trim());
        current = '';
        continue;
      }
      current += ch;
    }
    if (current.trim()) parts.push(current.trim());
    return parts;
  }

  /** Checks selector syntax without touching the live document. */
  function isValidSelector(selector) {
    if (!selector || typeof selector !== 'string') return false;
    if (/[{}]/.test(selector)) return false;
    try {
      document.createDocumentFragment().querySelector(selector);
      return true;
    } catch (e) {
      return false;
    }
  }

  /**
   * Validates a custom CSS declaration block. Returns the normalised declarations
   * (with original !important flags) or null when the input would escape the rule
   * block or contains no valid declarations.
   */
  function sanitizeDeclarations(css) {
    if (!css || typeof css !== 'string') return null;
    if (/[{}]|<\/?style|@import/i.test(css)) return null;
    try {
      const sheet = new CSSStyleSheet();
      sheet.replaceSync(`x{${css}}`);
      if (sheet.cssRules.length !== 1 || sheet.cssRules[0].selectorText !== 'x') return null;
      const text = sheet.cssRules[0].style.cssText.trim();
      return text || null;
    } catch (e) {
      return null;
    }
  }

  /** Counts matches for a selector in the live document. Returns { valid, count, error }. */
  function testSelector(selector, root) {
    if (!isValidSelector(selector)) return { valid: false, count: 0, error: 'Invalid CSS selector' };
    try {
      const count = (root || document).querySelectorAll(selector).length;
      return { valid: true, count, error: '' };
    } catch (e) {
      return { valid: false, count: 0, error: e.message };
    }
  }

  function isEditableTarget(target) {
    if (!target || target.nodeType !== 1) return false;
    if (target.isContentEditable) return true;
    const tag = target.tagName;
    return tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT';
  }

  /** elementFromPoint that pierces open shadow roots. */
  function deepElementFromPoint(x, y, ignoreHost) {
    let el = document.elementFromPoint(x, y);
    let guard = 0;
    while (el && el.shadowRoot && el !== ignoreHost && guard++ < 20) {
      const inner = el.shadowRoot.elementFromPoint(x, y);
      if (!inner || inner === el) break;
      el = inner;
    }
    return el;
  }

  function isInShadowTree(el) {
    return !!(el && el.getRootNode && el.getRootNode() instanceof ShadowRoot);
  }

  function sendMessage(message) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(message, (response) => {
          if (chrome.runtime.lastError) {
            resolve(null);
            return;
          }
          resolve(response);
        });
      } catch (e) {
        resolve(null);
      }
    });
  }

  // ---------------------------------------------------------------------------
  // Toasts (page context, isolated in a shadow root)
  // ---------------------------------------------------------------------------

  let toastHost = null;
  let toastRoot = null;
  let toastTimer = null;

  function ensureToastHost() {
    if (toastHost && toastHost.isConnected) return;
    toastHost = document.createElement('div');
    toastHost.id = TOAST_HOST_ID;
    toastHost.style.cssText = 'all: initial; position: fixed; z-index: 2147483647; bottom: 0; right: 0; width: 0; height: 0;';
    toastRoot = toastHost.attachShadow({ mode: 'closed' });
    const style = document.createElement('style');
    style.textContent = `
      .toast {
        position: fixed; bottom: 20px; right: 20px; max-width: 360px;
        display: flex; align-items: center; gap: 12px;
        background: #111827; color: #f9fafb; border: 1px solid rgba(255,255,255,.12);
        padding: 10px 14px; border-radius: 10px;
        font: 600 13px/1.4 system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif;
        box-shadow: 0 8px 24px rgba(0,0,0,.35);
        opacity: 0; transform: translateY(8px); transition: opacity .18s ease, transform .18s ease;
        pointer-events: auto;
      }
      .toast.show { opacity: 1; transform: none; }
      .toast.success { border-color: rgba(16,185,129,.6); }
      .toast.error { border-color: rgba(239,68,68,.7); }
      button {
        all: unset; cursor: pointer; color: #a5b4fc; font-weight: 700; padding: 2px 6px; border-radius: 6px;
      }
      button:hover, button:focus-visible { background: rgba(165,180,252,.15); outline: 2px solid #a5b4fc; outline-offset: 1px; }
    `;
    toastRoot.appendChild(style);
    (document.body || document.documentElement).appendChild(toastHost);
  }

  /**
   * Shows a toast. options: { type: 'info'|'success'|'error', duration, actionLabel, onAction }
   */
  function showToast(text, options = {}) {
    if (typeof document === 'undefined') return;
    ensureToastHost();
    const old = toastRoot.querySelector('.toast');
    if (old) old.remove();
    clearTimeout(toastTimer);

    const el = document.createElement('div');
    el.className = `toast ${options.type || 'info'}`;
    el.setAttribute('role', 'status');
    el.setAttribute('aria-live', 'polite');
    const span = document.createElement('span');
    span.textContent = text;
    el.appendChild(span);
    if (options.actionLabel && typeof options.onAction === 'function') {
      const btn = document.createElement('button');
      btn.textContent = options.actionLabel;
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        el.remove();
        options.onAction();
      });
      el.appendChild(btn);
    }
    toastRoot.appendChild(el);
    requestAnimationFrame(() => el.classList.add('show'));
    toastTimer = setTimeout(() => {
      el.classList.remove('show');
      setTimeout(() => el.remove(), 250);
    }, options.duration || 3000);
  }

  // ---------------------------------------------------------------------------
  // Zap (one-off removal without a rule) + undo stack shared by picker & engine
  // ---------------------------------------------------------------------------

  const zapStack = [];
  let lastUndoableAt = 0;
  let undoRuleHandler = null;

  function zap(el) {
    if (!el || el.nodeType !== 1) return false;
    const prev = {
      el,
      value: el.style.getPropertyValue('display'),
      priority: el.style.getPropertyPriority('display')
    };
    el.style.setProperty('display', 'none', 'important');
    el.setAttribute('data-br-zapped', '');
    zapStack.push(prev);
    lastUndoableAt = Date.now();
    undoRuleHandler = null;
    return true;
  }

  function undoZap() {
    const entry = zapStack.pop();
    if (!entry) return false;
    if (entry.value) entry.el.style.setProperty('display', entry.value, entry.priority);
    else entry.el.style.removeProperty('display');
    entry.el.removeAttribute('data-br-zapped');
    return true;
  }

  /** Registers an undo callback for the last saved rule (Ctrl+Z within 15 s). */
  function setRuleUndo(handler) {
    undoRuleHandler = handler;
    lastUndoableAt = Date.now();
  }

  /** Performs the most recent undo action. Returns a description or ''. */
  async function undoLast() {
    if (undoRuleHandler) {
      const fn = undoRuleHandler;
      undoRuleHandler = null;
      await fn();
      return 'rule';
    }
    return undoZap() ? 'zap' : '';
  }

  function hasRecentUndo(windowMs = 15000) {
    return (!!undoRuleHandler || zapStack.length > 0) && Date.now() - lastUndoableAt < windowMs;
  }

  global.BlurRemoverDom = {
    escapeHtml,
    sanitizeCssComment,
    splitSelectorList,
    isValidSelector,
    sanitizeDeclarations,
    testSelector,
    isEditableTarget,
    deepElementFromPoint,
    isInShadowTree,
    sendMessage,
    showToast,
    zap,
    undoZap,
    undoLast,
    setRuleUndo,
    hasRecentUndo,
    TOAST_HOST_ID
  };
})(typeof self !== 'undefined' ? self : this);
