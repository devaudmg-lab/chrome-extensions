/**
 * Blur Remover & DOM Modifier - i18n helper
 * Applies chrome.i18n messages to [data-i18n], [data-i18n-title], [data-i18n-placeholder]
 * and [data-i18n-aria]. The markup text is the fallback when a key is missing.
 */

(function (global) {
  'use strict';

  if (global.BlurRemoverI18n) return;

  function t(key, fallback, subs) {
    let msg = '';
    try {
      if (typeof chrome !== 'undefined' && chrome.i18n && key) msg = chrome.i18n.getMessage(key, subs);
    } catch (e) { /* ignore */ }
    if (msg) return msg;
    let out = fallback === undefined ? key : String(fallback);
    if (subs !== undefined) {
      [].concat(subs).forEach((s, i) => { out = out.replace(new RegExp('\\$' + (i + 1), 'g'), s); });
    }
    return out;
  }

  function apply(root) {
    const scope = root || document;
    scope.querySelectorAll('[data-i18n]').forEach((el) => {
      el.textContent = t(el.getAttribute('data-i18n'), el.textContent.trim());
    });
    [['data-i18n-title', 'title'], ['data-i18n-placeholder', 'placeholder'], ['data-i18n-aria', 'aria-label']].forEach(([attr, target]) => {
      scope.querySelectorAll(`[${attr}]`).forEach((el) => {
        el.setAttribute(target, t(el.getAttribute(attr), el.getAttribute(target) || ''));
      });
    });
  }

  global.BlurRemoverI18n = { t, apply };

  if (typeof document !== 'undefined') {
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => apply());
    else apply();
  }
})(typeof self !== 'undefined' ? self : this);
