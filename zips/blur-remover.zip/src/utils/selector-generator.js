/**
 * Blur Remover & DOM Modifier - Smart CSS Selector Generator
 * Produces ranked selector candidates (with live match counts) for a picked element,
 * skipping unstable tokens such as hashed class names and framework-generated ids.
 */

(function (global) {
  'use strict';

  if (global.BlurRemoverSelector) return;

  const KEYWORD_REGEX = /(blur|backdrop|overlay|modal|paywall|popup|dialog|banner|fixed|sticky|cookie|consent|newsletter)/i;
  const STABLE_ATTRIBUTES = ['data-testid', 'data-test', 'data-qa', 'data-cy', 'aria-label', 'name', 'role'];
  const MAX_TOKEN_LENGTH = 40;
  const MAX_CANDIDATES = 7;

  /** True for class names / ids that are likely generated and will change on the next deploy. */
  function isUnstableToken(token) {
    if (!token || typeof token !== 'string') return true;
    if (token.length > MAX_TOKEN_LENGTH) return true;
    if (token.startsWith('blur-remover')) return true;
    if (/^(css|sc|jsx|emotion|svelte|astro|styled)-/i.test(token)) return true; // CSS-in-JS
    if (/^:r[0-9a-z]+:$/i.test(token) || /^:/.test(token)) return true; // React useId
    if (/[[\]:/!@()%,]/.test(token)) return true; // Tailwind arbitrary values & variants (hover:, md:, w-[10px])
    if (/^_?[a-zA-Z]{1,3}[0-9][a-zA-Z0-9]{3,}$/.test(token)) return true; // _a1b2c, x9f3k2
    if (/[-_][a-zA-Z0-9]{5,}$/.test(token) && /\d/.test(token.split(/[-_]/).pop()) && /[a-zA-Z]/.test(token.split(/[-_]/).pop())) return true; // Button_root__x8Kd2
    if (/\d{4,}/.test(token)) return true; // ids with long numbers
    if (/^[a-f0-9]{6,}$/i.test(token)) return true; // pure hashes
    return false;
  }

  function getValidClasses(el) {
    if (!el) return [];
    let classStr = '';
    if (typeof el.className === 'string') {
      classStr = el.className;
    } else if (el.className && typeof el.className.baseVal === 'string') {
      classStr = el.className.baseVal;
    }
    if (!classStr) return [];
    return classStr.split(/\s+/).filter((c) => c && !isUnstableToken(c));
  }

  function stableId(el) {
    return el && typeof el.id === 'string' && el.id && !isUnstableToken(el.id) ? el.id : '';
  }

  function tagOf(el) {
    return el.tagName.toLowerCase();
  }

  function escAttr(value) {
    return String(value).replace(/\\/g, '\\\\').replace(/"/g, '\\"');
  }

  function rootFor(el) {
    const root = el && el.getRootNode ? el.getRootNode() : document;
    return root && root.querySelectorAll ? root : document;
  }

  function countMatches(selector, root) {
    try {
      return root.querySelectorAll(selector).length;
    } catch (e) {
      return -1;
    }
  }

  function matchesElement(selector, el) {
    try {
      return el.matches(selector);
    } catch (e) {
      return false;
    }
  }

  /** One stable token describing a single element (no ancestors). */
  function elementToken(el) {
    const id = stableId(el);
    if (id) return `#${CSS.escape(id)}`;
    const classes = getValidClasses(el);
    const keyword = classes.find((c) => KEYWORD_REGEX.test(c));
    if (keyword) return `${tagOf(el)}.${CSS.escape(keyword)}`;
    if (classes.length) return `${tagOf(el)}.${CSS.escape(classes[0])}`;
    return tagOf(el);
  }

  // ---------------------------------------------------------------------------
  // Legacy selector shapes (kept for compatibility)
  // ---------------------------------------------------------------------------

  function getConciseSelector(el) {
    if (!el || el.nodeType !== Node.ELEMENT_NODE) return '';
    const id = stableId(el);
    if (id) return `#${CSS.escape(id)}`;
    const classes = getValidClasses(el);
    const keyword = classes.find((c) => KEYWORD_REGEX.test(c));
    if (keyword) return `.${CSS.escape(keyword)}`;
    if (classes.length === 1) return `${tagOf(el)}.${CSS.escape(classes[0])}`;
    if (classes.length > 1) return `.${CSS.escape(classes[0])}.${CSS.escape(classes[1])}`;
    return tagOf(el);
  }

  function getBalancedSelector(el) {
    if (!el || el.nodeType !== Node.ELEMENT_NODE) return '';
    const parts = [];
    let curr = el;
    let depth = 0;
    while (curr && curr.nodeType === Node.ELEMENT_NODE && curr !== document.body && curr !== document.documentElement && depth < 4) {
      const token = elementToken(curr);
      parts.unshift(token);
      if (token.startsWith('#')) break;
      curr = curr.parentElement;
      depth++;
    }
    return parts.join(' > ') || tagOf(el);
  }

  function getExactSelector(el) {
    if (!el || el.nodeType !== Node.ELEMENT_NODE) return '';
    const path = [];
    let curr = el;
    while (curr && curr.nodeType === Node.ELEMENT_NODE && curr !== document.documentElement) {
      const id = stableId(curr);
      if (id) {
        path.unshift(`#${CSS.escape(id)}`);
        break;
      }
      let selector = tagOf(curr);
      const parent = curr.parentElement;
      if (parent) {
        const siblings = Array.from(parent.children).filter((child) => child.tagName === curr.tagName);
        if (siblings.length > 1) selector += `:nth-of-type(${siblings.indexOf(curr) + 1})`;
      }
      path.unshift(selector);
      curr = parent;
    }
    return path.join(' > ');
  }

  function detectBlurStyles(el) {
    if (!el || typeof window === 'undefined' || !window.getComputedStyle) return false;
    try {
      const style = window.getComputedStyle(el);
      const backdrop = style.backdropFilter || style.webkitBackdropFilter || '';
      const filter = style.filter || style.webkitFilter || '';
      return backdrop.includes('blur(') || filter.includes('blur(');
    } catch (e) {
      return false;
    }
  }

  // ---------------------------------------------------------------------------
  // Ranked candidates
  // ---------------------------------------------------------------------------

  function generateCandidates(el) {
    if (!el || el.nodeType !== Node.ELEMENT_NODE) return [];
    const root = rootFor(el);
    const tag = tagOf(el);
    const seen = new Set();
    const candidates = [];

    function add(label, selector, kind) {
      if (!selector || seen.has(selector)) return;
      seen.add(selector);
      if (!matchesElement(selector, el)) return;
      const count = countMatches(selector, root);
      if (count < 1) return;
      candidates.push({ label, selector, count, unique: count === 1, kind: kind || 'element' });
    }

    // 1. Stable id
    const id = stableId(el);
    if (id) add('ID', `#${CSS.escape(id)}`);

    // 2. Stable attributes
    STABLE_ATTRIBUTES.forEach((attr) => {
      const value = el.getAttribute(attr);
      if (!value || value.length > 80 || isUnstableToken(value.replace(/\s+/g, '-')) && attr !== 'aria-label') return;
      add(`Attribute [${attr}]`, `${tag}[${attr}="${escAttr(value)}"]`);
    });

    // 3. Keyword class (also offered as a group candidate)
    const classes = getValidClasses(el);
    const keyword = classes.find((c) => KEYWORD_REGEX.test(c));
    if (keyword) {
      const sel = `.${CSS.escape(keyword)}`;
      const count = countMatches(sel, root);
      add(count > 1 ? `Group: all .${keyword} (${count})` : 'Keyword class', sel, count > 1 ? 'group' : 'element');
    }

    // 4. Tag + class / class combos
    if (classes.length) {
      add('Tag + class', `${tag}.${CSS.escape(classes[0])}`);
      if (classes.length > 1) add('Class combo', `${tag}.${CSS.escape(classes[0])}.${CSS.escape(classes[1])}`);
      if (classes.length > 2) add('Class combo', `${tag}${classes.slice(0, 3).map((c) => '.' + CSS.escape(c)).join('')}`);
    }

    // 5. Ancestor path (balanced)
    add('Balanced path', getBalancedSelector(el));

    // 6. Parent-anchored token (stable ancestor id + element token)
    let anc = el.parentElement;
    let hops = 0;
    while (anc && anc !== document.body && hops < 6) {
      const aid = stableId(anc);
      if (aid) {
        add('Inside #' + aid, `#${CSS.escape(aid)} ${elementToken(el)}`);
        break;
      }
      anc = anc.parentElement;
      hops++;
    }

    // 7. Exact nth-of-type path (always unique, but fragile)
    add('Exact path', getExactSelector(el), 'exact');

    // Rank: stable unique selectors, then the (fragile but precise) exact path, then groups,
    // then other broad selectors. The default choice therefore never hides more than the picked element.
    const rank = (c) => (c.kind === 'exact' ? 1 : c.unique ? 0 : c.kind === 'group' ? 2 : 3);
    candidates.sort((a, b) => rank(a) - rank(b) || a.selector.length - b.selector.length);

    // Make sure the exact path stays available even when trimming.
    const exact = candidates.find((c) => c.kind === 'exact');
    let result = candidates.slice(0, MAX_CANDIDATES);
    if (exact && !result.includes(exact)) result = result.slice(0, MAX_CANDIDATES - 1).concat(exact);
    return result;
  }

  global.BlurRemoverSelector = {
    generateCandidates,
    generateSelectors(el) {
      return {
        concise: getConciseSelector(el),
        balanced: getBalancedSelector(el),
        exact: getExactSelector(el),
        hasBlur: detectBlurStyles(el)
      };
    },
    detectBlurStyles,
    isUnstableToken
  };
})(typeof self !== 'undefined' ? self : this);
