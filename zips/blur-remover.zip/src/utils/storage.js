/**
 * Blur Remover & DOM Modifier - Storage Utility (schema v2)
 *
 * Layout:
 *   chrome.storage.sync  `br_core`  small settings (master switch, presets, dark mode, popup theme)
 *   chrome.storage.local `br_core`  fallback copy when sync fails / is over quota (newest `updatedAt` wins)
 *   chrome.storage.local `br_rules` user rules (no 8 KB per-item sync quota)
 *   chrome.storage.local `br_packs` remote / built-in rule packs
 *   chrome.storage.local `br_sites` per-site prefs (paused, dark mode override, auto reader)
 *   chrome.storage.local `br_reader` reader view prefs
 *   chrome.storage.local `br_stats` real usage statistics
 *   chrome.storage.local `hl:<url>` reader highlights & notes
 *
 * Reads work in every context. Writes are serialized in the service worker: other contexts
 * proxy write operations through `chrome.runtime.sendMessage({ type: 'BR_STORAGE' })` so that
 * concurrent writers (popup + picker + content scripts) never lose updates.
 */

(function (global) {
  'use strict';

  if (global.BlurRemoverStorage) return;

  const SCHEMA_VERSION = 2;
  const LEGACY_KEY = 'blur_remover_settings';
  const KEYS = {
    core: 'br_core',
    rules: 'br_rules',
    packs: 'br_packs',
    sites: 'br_sites',
    reader: 'br_reader',
    stats: 'br_stats',
    highlightIndex: 'br_hl_index'
  };
  const HIGHLIGHT_PREFIX = 'hl:';
  const MAX_SITE_STATS = 300;
  const MAX_HIGHLIGHT_PAGES = 1000;
  const MAX_HIGHLIGHTS_PER_PAGE = 500;
  // Presets that can be switched per site (dark mode has its own per-site setting).
  const SITE_PRESET_KEYS = ['magicAutoUnblur', 'globalUnblur', 'scrollUnlock', 'overlayEraser', 'unblurText', 'enableDisabledClicks', 'cookieBannerRemover', 'unlockCopy'];
  // Write operations content scripts may request (picker, reader, stats). Everything else
  // (settings, imports, packs, bulk edits) is only accepted from the extension's own pages.
  const CONTENT_SCRIPT_OPS = ['addRule', 'deleteRule', 'recordStats', 'saveHighlights', 'updateReaderPrefs', 'setAutoReader'];

  const ACTION_TYPES = ['remove-blur', 'hide', 'visibility-hidden', 'unlock-scroll', 'enable-pointer', 'custom-css'];
  const SITE_SCOPES = ['global', 'domain', 'exact'];
  const PRESET_KEYS = [
    'magicAutoUnblur',
    'globalUnblur',
    'scrollUnlock',
    'overlayEraser',
    'unblurText',
    'enableDisabledClicks',
    'forceDarkMode',
    'cookieBannerRemover',
    'unlockCopy'
  ];
  const DARK_MODES = ['filter', 'dynamic'];
  const READER_FONTS = ['serif', 'sans', 'mono', 'atkinson', 'dyslexic'];
  const READER_THEMES = ['system', 'light', 'sepia', 'dark', 'oled'];
  const READER_WIDTHS = ['narrow', 'medium', 'wide'];

  // Seed rules from schema v1 that now ship in the built-in rule pack instead.
  const LEGACY_SEED_RULE_IDS = ['rule-default-blur', 'rule-medium-paywall', 'rule-glassdoor-login', 'rule-quora-backdrop'];

  const DEFAULT_SETTINGS = deepFreeze({
    schemaVersion: SCHEMA_VERSION,
    enabled: true,
    presetsEnabled: {
      magicAutoUnblur: true, // computed-style based, only touches real blur overlays
      globalUnblur: false,
      scrollUnlock: false,
      overlayEraser: false,
      unblurText: false,
      enableDisabledClicks: false,
      forceDarkMode: false,
      cookieBannerRemover: false,
      unlockCopy: false
    },
    darkMode: {
      mode: 'filter',
      brightness: 100,
      contrast: 100,
      sepia: 0,
      grayscale: 0,
      dimImages: true,
      automation: 'always', // 'always' | 'system' | 'schedule'
      scheduleStart: '19:00',
      scheduleEnd: '07:00'
    },
    theme: 'dark',
    showBadge: true,
    rules: [],
    rulePacks: [],
    sites: {
      paused: [],
      pausedUntil: {}, // host -> timestamp (ms) of a timed pause
      darkMode: {}, // host -> 'filter' | 'dynamic' | 'off'
      autoReader: [],
      presets: {} // host -> { presetKey: boolean } overrides of the global presets
    },
    reader: {
      fontSize: 18,
      fontFamily: 'serif',
      theme: 'system',
      width: 'medium',
      lineHeight: 1.7,
      paragraphSpacing: 1
    },
    stats: {
      totalBlursStripped: 0,
      totalOverlaysErased: 0,
      totalScrollsUnlocked: 0,
      sites: {}
    }
  });

  function deepFreeze(obj) {
    Object.values(obj).forEach((v) => {
      if (v && typeof v === 'object') deepFreeze(v);
    });
    return Object.freeze(obj);
  }

  function clone(value) {
    return value === undefined ? undefined : JSON.parse(JSON.stringify(value));
  }

  function hasChromeStorage() {
    return typeof chrome !== 'undefined' && !!chrome.storage;
  }

  function isServiceWorker() {
    return typeof ServiceWorkerGlobalScope !== 'undefined' && global instanceof ServiceWorkerGlobalScope;
  }

  // ---------------------------------------------------------------------------
  // Low level storage helpers
  // ---------------------------------------------------------------------------

  function areaGet(areaName, keys) {
    return new Promise((resolve) => {
      if (!hasChromeStorage() || !chrome.storage[areaName]) {
        const out = {};
        (Array.isArray(keys) ? keys : [keys]).forEach((k) => {
          try {
            const raw = typeof localStorage !== 'undefined' ? localStorage.getItem(`${areaName}:${k}`) : null;
            if (raw) out[k] = JSON.parse(raw);
          } catch (e) { /* ignore */ }
        });
        resolve(out);
        return;
      }
      chrome.storage[areaName].get(keys, (result) => {
        if (chrome.runtime && chrome.runtime.lastError) {
          resolve({});
          return;
        }
        resolve(result || {});
      });
    });
  }

  function areaSet(areaName, items) {
    return new Promise((resolve, reject) => {
      if (!hasChromeStorage() || !chrome.storage[areaName]) {
        try {
          Object.entries(items).forEach(([k, v]) => localStorage.setItem(`${areaName}:${k}`, JSON.stringify(v)));
          resolve(true);
        } catch (e) {
          reject(e);
        }
        return;
      }
      chrome.storage[areaName].set(items, () => {
        if (chrome.runtime && chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        resolve(true);
      });
    });
  }

  function areaRemove(areaName, keys) {
    return new Promise((resolve) => {
      if (!hasChromeStorage() || !chrome.storage[areaName]) {
        (Array.isArray(keys) ? keys : [keys]).forEach((k) => {
          try { localStorage.removeItem(`${areaName}:${k}`); } catch (e) { /* ignore */ }
        });
        resolve(true);
        return;
      }
      chrome.storage[areaName].remove(keys, () => resolve(true));
    });
  }

  // ---------------------------------------------------------------------------
  // Normalisation
  // ---------------------------------------------------------------------------

  function normalizeCore(core) {
    const d = DEFAULT_SETTINGS;
    const c = core || {};
    const presets = {};
    PRESET_KEYS.forEach((k) => {
      presets[k] = c.presetsEnabled && typeof c.presetsEnabled[k] === 'boolean' ? c.presetsEnabled[k] : d.presetsEnabled[k];
    });
    const dm = Object.assign({}, clone(d.darkMode), c.darkMode || {});
    if (!DARK_MODES.includes(dm.mode)) dm.mode = d.darkMode.mode;
    ['brightness', 'contrast'].forEach((k) => { dm[k] = clampNumber(dm[k], 50, 150, 100); });
    ['sepia', 'grayscale'].forEach((k) => { dm[k] = clampNumber(dm[k], 0, 100, 0); });
    if (!['always', 'system', 'schedule'].includes(dm.automation)) dm.automation = 'always';
    if (!/^\d{2}:\d{2}$/.test(dm.scheduleStart)) dm.scheduleStart = d.darkMode.scheduleStart;
    if (!/^\d{2}:\d{2}$/.test(dm.scheduleEnd)) dm.scheduleEnd = d.darkMode.scheduleEnd;
    dm.dimImages = dm.dimImages !== false;
    return {
      schemaVersion: SCHEMA_VERSION,
      enabled: typeof c.enabled === 'boolean' ? c.enabled : d.enabled,
      presetsEnabled: presets,
      darkMode: dm,
      theme: c.theme === 'light' ? 'light' : 'dark',
      showBadge: c.showBadge !== false,
      updatedAt: Number(c.updatedAt) || 0
    };
  }

  function normalizeSites(sites) {
    const s = sites || {};
    const dark = {};
    if (s.darkMode && typeof s.darkMode === 'object') {
      Object.entries(s.darkMode).forEach(([host, mode]) => {
        if (['filter', 'dynamic', 'off'].includes(mode)) dark[host] = mode;
      });
    }
    const until = {};
    if (s.pausedUntil && typeof s.pausedUntil === 'object') {
      const now = Date.now();
      Object.entries(s.pausedUntil).forEach(([host, ts]) => {
        if (Number(ts) > now) until[host] = Number(ts);
      });
    }
    const presets = {};
    if (s.presets && typeof s.presets === 'object' && !Array.isArray(s.presets)) {
      Object.entries(s.presets).forEach(([host, map]) => {
        const h = normalizeHost(host);
        if (!h || !map || typeof map !== 'object') return;
        const clean = {};
        SITE_PRESET_KEYS.forEach((k) => { if (typeof map[k] === 'boolean') clean[k] = map[k]; });
        if (Object.keys(clean).length) presets[h] = Object.assign(presets[h] || {}, clean);
      });
    }
    return {
      paused: Array.isArray(s.paused) ? s.paused.filter((h) => typeof h === 'string') : [],
      pausedUntil: until,
      darkMode: dark,
      autoReader: Array.isArray(s.autoReader) ? s.autoReader.filter((h) => typeof h === 'string') : [],
      presets
    };
  }

  function normalizeReader(reader) {
    const d = DEFAULT_SETTINGS.reader;
    const r = Object.assign({}, clone(d), reader || {});
    r.fontSize = clampNumber(r.fontSize, 12, 32, d.fontSize);
    if (!READER_FONTS.includes(r.fontFamily)) r.fontFamily = d.fontFamily;
    if (!READER_THEMES.includes(r.theme)) r.theme = d.theme;
    if (!READER_WIDTHS.includes(r.width)) r.width = d.width;
    r.lineHeight = clampNumber(r.lineHeight, 1.2, 2.4, d.lineHeight);
    r.paragraphSpacing = clampNumber(r.paragraphSpacing, 0.4, 2.5, d.paragraphSpacing);
    return r;
  }

  function normalizeStats(stats) {
    const s = stats || {};
    return {
      totalBlursStripped: Number(s.totalBlursStripped) || 0,
      totalOverlaysErased: Number(s.totalOverlaysErased) || 0,
      totalScrollsUnlocked: Number(s.totalScrollsUnlocked) || 0,
      sites: s.sites && typeof s.sites === 'object' ? s.sites : {}
    };
  }

  function clampNumber(value, min, max, fallback) {
    const n = Number(value);
    if (!Number.isFinite(n)) return fallback;
    return Math.min(max, Math.max(min, n));
  }

  /**
   * Shape-only validation (usable in the service worker; no DOM required).
   * Returns a cleaned rule or null.
   */
  function sanitizeRuleShape(rule, { keepId = true } = {}) {
    if (!rule || typeof rule !== 'object') return null;
    const selector = typeof rule.selector === 'string' ? rule.selector.trim() : '';
    if (!selector || selector.length > 2000) return null;
    const actionType = ACTION_TYPES.includes(rule.actionType) ? rule.actionType : 'remove-blur';
    const siteScope = SITE_SCOPES.includes(rule.siteScope) ? rule.siteScope : 'global';
    const now = Date.now();
    return {
      id: keepId && typeof rule.id === 'string' && rule.id ? rule.id.slice(0, 120) : generateId(),
      name: (typeof rule.name === 'string' && rule.name.trim() ? rule.name.trim() : 'Custom Rule').slice(0, 200),
      enabled: rule.enabled !== false,
      siteScope,
      domainPattern: siteScope === 'global' ? '*' : (typeof rule.domainPattern === 'string' && rule.domainPattern.trim() ? rule.domainPattern.trim().slice(0, 2000) : '*'),
      selector,
      actionType,
      customCss: actionType === 'custom-css' && typeof rule.customCss === 'string' ? rule.customCss.slice(0, 5000) : '',
      createdAt: Number(rule.createdAt) || now,
      updatedAt: Number(rule.updatedAt) || now
    };
  }

  function generateId(prefix = 'rule') {
    const rand = (typeof crypto !== 'undefined' && crypto.randomUUID)
      ? crypto.randomUUID().slice(0, 8)
      : Math.random().toString(36).slice(2, 10);
    return `${prefix}-${rand}-${Date.now().toString(36)}`;
  }

  // ---------------------------------------------------------------------------
  // Matching helpers
  // ---------------------------------------------------------------------------

  function normalizeHost(hostname) {
    return String(hostname || '').trim().toLowerCase().replace(/^www\./, '');
  }

  function matchDomainPattern(pattern, hostname) {
    if (!pattern || pattern === '*' || pattern === 'global') return true;
    if (!hostname) return false;

    const cleanPattern = pattern.trim().toLowerCase().replace(/^https?:\/\//, '').replace(/[/?#].*$/, '');
    const cleanHost = hostname.trim().toLowerCase();
    const base = cleanPattern.startsWith('*.') ? cleanPattern.slice(2) : cleanPattern;
    if (!base || !base.includes('.')) return false; // never match a whole TLD like "com"

    return cleanHost === base || cleanHost.endsWith('.' + base);
  }

  /** Normalises "https://Site.com/path/?q#h" to "site.com/path" */
  function normalizeUrlForExact(value) {
    let v = String(value || '').trim().replace(/^https?:\/\//i, '');
    v = v.replace(/[?#].*$/, '');
    const slash = v.indexOf('/');
    const host = (slash === -1 ? v : v.slice(0, slash)).toLowerCase().replace(/^www\./, '');
    let path = slash === -1 ? '/' : v.slice(slash);
    if (path.length > 1 && path.endsWith('/') && !path.endsWith('*/')) path = path.slice(0, -1);
    return host + path;
  }

  /**
   * Exact-path matching: "site.com/a" only matches site.com/a (query/hash ignored).
   * A trailing "*" turns it into a prefix match: "site.com/blog/*".
   */
  function matchExactPattern(pattern, url) {
    if (!pattern || !url) return false;
    const raw = String(pattern).trim();
    const isPrefix = raw.endsWith('*');
    const stem = isPrefix ? raw.slice(0, -1) : raw;
    const p = normalizeUrlForExact(stem);
    const target = normalizeUrlForExact(url);
    if (!isPrefix) return target === p;
    // "site.com/blog/*" matches the folder and everything below it, "site.com/blog*" is a plain prefix.
    if (stem.endsWith('/')) return target === p || target.startsWith(p.replace(/\/$/, '') + '/');
    return target.startsWith(p);
  }

  function isSitePaused(settings, hostname) {
    if (!settings || !settings.sites) return false;
    const host = normalizeHost(hostname);
    return settings.sites.paused.some((p) => normalizeHost(p) === host) || getPausedUntil(settings, hostname) > 0;
  }

  /** Timestamp (ms) when a timed pause on this host ends, or 0 if there is none. */
  function getPausedUntil(settings, hostname, now) {
    if (!settings || !settings.sites || !settings.sites.pausedUntil) return 0;
    const host = normalizeHost(hostname);
    const t = now || Date.now();
    let until = 0;
    Object.entries(settings.sites.pausedUntil).forEach(([h, ts]) => {
      if (normalizeHost(h) === host && Number(ts) > t) until = Math.max(until, Number(ts));
    });
    return until;
  }

  /** Builds a shareable rule pack ({ name, version, rules }) from the user rules that apply to a host. */
  function buildSiteRulePack(settings, hostname) {
    const host = normalizeHost(hostname);
    const rules = ((settings && settings.rules) || [])
      .filter((r) => r.selector && r.siteScope !== 'global' && (
        r.siteScope === 'exact'
          ? normalizeUrlForExact(r.domainPattern).split('/')[0] === host
          : matchDomainPattern(r.domainPattern, host)
      ))
      .map((r) => {
        const out = { name: r.name, siteScope: r.siteScope, domainPattern: r.domainPattern, selector: r.selector, actionType: r.actionType };
        if (r.actionType === 'custom-css') out.customCss = r.customCss;
        if (r.enabled === false) out.enabled = false;
        return out;
      });
    return {
      name: `${host} fixes`,
      version: new Date().toISOString().slice(0, 10),
      description: `Blur Remover rules for ${host}. Import it in Options > Backup, or host it on https and add it as a rule pack.`,
      rules
    };
  }

  /** True when an imported JSON file looks like a rule pack rather than a full backup. */
  function isRulePackFile(data) {
    return !!data && typeof data === 'object' && !Array.isArray(data) && Array.isArray(data.rules) &&
      !data.exportedBy && !data.presetsEnabled && !data.darkMode && !data.sites;
  }

  function getAllRules(settings) {
    if (!settings) return [];
    const packRules = [];
    (settings.rulePacks || []).forEach((pack) => {
      if (!pack.enabled || !Array.isArray(pack.rules)) return;
      pack.rules.forEach((r) => packRules.push(Object.assign({}, r, { packId: pack.id, packName: pack.name })));
    });
    return (settings.rules || []).concat(packRules);
  }

  function getRulesForHost(settings, hostname, currentUrl) {
    if (!settings || !settings.enabled) return [];
    if (isSitePaused(settings, hostname)) return [];

    const activeUrl = currentUrl || (typeof location !== 'undefined' && location.href) || '';

    return getAllRules(settings).filter((rule) => {
      if (!rule.enabled || !rule.selector) return false;
      if (rule.siteScope === 'global') return true;
      if (rule.siteScope === 'exact') return !!activeUrl && matchExactPattern(rule.domainPattern, activeUrl);
      return matchDomainPattern(rule.domainPattern, hostname);
    });
  }

  /** Per-site preset overrides for a host ({} when there are none). */
  function getSitePresets(settings, hostname) {
    const host = normalizeHost(hostname);
    const map = settings && settings.sites && settings.sites.presets;
    return (host && map && map[host]) || {};
  }

  /** Global presets with this site's overrides applied. */
  function getEffectivePresets(settings, hostname) {
    const base = (settings && settings.presetsEnabled) || {};
    return Object.assign({}, base, getSitePresets(settings, hostname));
  }

  /** The per-site dark mode choice ('filter' | 'dynamic' | 'off') or null when the site follows the global setting. */
  function getSiteDarkOverride(settings, hostname) {
    const host = normalizeHost(hostname);
    const entry = settings && settings.sites && settings.sites.darkMode
      ? Object.entries(settings.sites.darkMode).find(([h]) => normalizeHost(h) === host)
      : null;
    return entry ? entry[1] : null;
  }

  /** Returns 'filter' | 'dynamic' | null, ignoring time/system automation (evaluated by the page). */
  function getEffectiveDarkMode(settings, hostname) {
    if (!settings || !settings.enabled || isSitePaused(settings, hostname)) return null;
    const override = getSiteDarkOverride(settings, hostname);
    if (override) return override === 'off' ? null : override;
    return settings.presetsEnabled.forceDarkMode ? settings.darkMode.mode : null;
  }

  function isAutoReaderSite(settings, hostname) {
    const host = normalizeHost(hostname);
    return !!(settings && settings.sites && settings.sites.autoReader.some((h) => normalizeHost(h) === host));
  }

  // ---------------------------------------------------------------------------
  // Reading (any context, never writes)
  // ---------------------------------------------------------------------------

  async function readLegacy() {
    const [syncData, localData] = await Promise.all([areaGet('sync', [LEGACY_KEY]), areaGet('local', [LEGACY_KEY])]);
    return syncData[LEGACY_KEY] || localData[LEGACY_KEY] || null;
  }

  function convertLegacy(legacy) {
    const core = normalizeCore({
      enabled: legacy.enabled,
      presetsEnabled: legacy.presetsEnabled,
      theme: legacy.theme
    });
    const rules = (Array.isArray(legacy.rules) ? legacy.rules : [])
      .filter((r) => !(LEGACY_SEED_RULE_IDS.includes(r.id) && r.createdAt === r.updatedAt))
      .map((r) => sanitizeRuleShape(r))
      .filter(Boolean);
    // v1 stats were seeded with fake numbers, start over with real counting.
    return { core, rules, stats: normalizeStats(null) };
  }

  async function getSettings() {
    const [syncData, localData] = await Promise.all([
      areaGet('sync', [KEYS.core]),
      areaGet('local', [KEYS.core, KEYS.rules, KEYS.packs, KEYS.sites, KEYS.reader, KEYS.stats])
    ]);

    let coreRaw = null;
    const syncCore = syncData[KEYS.core];
    const localCore = localData[KEYS.core];
    if (syncCore && localCore) {
      coreRaw = (Number(localCore.updatedAt) || 0) > (Number(syncCore.updatedAt) || 0) ? localCore : syncCore;
    } else {
      coreRaw = syncCore || localCore || null;
    }

    let rules = localData[KEYS.rules];
    let stats = localData[KEYS.stats];

    if (!coreRaw) {
      const legacy = await readLegacy();
      if (legacy) {
        const converted = convertLegacy(legacy);
        coreRaw = converted.core;
        if (!Array.isArray(rules)) rules = converted.rules;
        if (!stats) stats = converted.stats;
      }
    }

    const core = normalizeCore(coreRaw);
    return {
      schemaVersion: SCHEMA_VERSION,
      enabled: core.enabled,
      presetsEnabled: core.presetsEnabled,
      darkMode: core.darkMode,
      theme: core.theme,
      showBadge: core.showBadge,
      rules: Array.isArray(rules) ? clone(rules) : [],
      rulePacks: Array.isArray(localData[KEYS.packs]) ? clone(localData[KEYS.packs]) : [],
      sites: normalizeSites(localData[KEYS.sites]),
      reader: normalizeReader(localData[KEYS.reader]),
      stats: normalizeStats(stats)
    };
  }

  function highlightKey(url) {
    return HIGHLIGHT_PREFIX + normalizeUrlForExact(url);
  }

  async function getHighlights(url) {
    const key = highlightKey(url);
    const data = await areaGet('local', [key]);
    return Array.isArray(data[key]) ? data[key] : [];
  }

  function normalizeHighlightIndex(value) {
    const out = {};
    if (!value || typeof value !== 'object' || Array.isArray(value)) return out;
    Object.entries(value).forEach(([key, v]) => {
      if (!key.startsWith(HIGHLIGHT_PREFIX) || !v || typeof v !== 'object') return;
      out[key] = {
        url: typeof v.url === 'string' ? v.url.slice(0, 2000) : '',
        title: typeof v.title === 'string' ? v.title.slice(0, 300) : '',
        count: Math.max(0, Number(v.count) || 0),
        notes: Math.max(0, Number(v.notes) || 0),
        updatedAt: Number(v.updatedAt) || 0
      };
    });
    return out;
  }

  /** Every page with saved highlights, newest first, including the highlights themselves. */
  async function getHighlightPages() {
    const index = normalizeHighlightIndex((await areaGet('local', [KEYS.highlightIndex]))[KEYS.highlightIndex]);
    const keys = Object.keys(index);
    const data = keys.length ? await areaGet('local', keys) : {};
    return keys
      .map((key) => Object.assign({ key, highlights: Array.isArray(data[key]) ? data[key] : [] }, index[key]))
      .filter((p) => p.highlights.length)
      .sort((a, b) => b.updatedAt - a.updatedAt);
  }

  /** Shape-checks highlights coming from a page (content scripts are not trusted with storage). */
  function sanitizeHighlights(list) {
    const str = (v, max) => (typeof v === 'string' ? v.slice(0, max) : '');
    return (Array.isArray(list) ? list : []).slice(0, MAX_HIGHLIGHTS_PER_PAGE).map((h) => {
      if (!h || typeof h !== 'object' || typeof h.text !== 'string' || !h.text.trim()) return null;
      return {
        id: str(h.id, 64) || generateId('hl'),
        text: str(h.text, 2000),
        prefix: str(h.prefix, 64),
        suffix: str(h.suffix, 64),
        note: str(h.note, 5000),
        createdAt: Number(h.createdAt) || Date.now()
      };
    }).filter(Boolean);
  }

  async function getStorageUsage() {
    const usage = { syncBytes: 0, syncQuota: 102400, syncItemQuota: 8192, coreBytes: 0, localBytes: 0, localQuota: 10485760, syncOk: true };
    if (!hasChromeStorage()) return usage;
    const bytes = (area, keys) => new Promise((resolve) => {
      try {
        chrome.storage[area].getBytesInUse(keys, (n) => resolve(chrome.runtime.lastError ? 0 : n || 0));
      } catch (e) {
        resolve(0);
      }
    });
    usage.syncBytes = await bytes('sync', null);
    usage.coreBytes = await bytes('sync', [KEYS.core]);
    usage.localBytes = await bytes('local', null);
    if (chrome.storage.sync && chrome.storage.sync.QUOTA_BYTES) usage.syncQuota = chrome.storage.sync.QUOTA_BYTES;
    if (chrome.storage.sync && chrome.storage.sync.QUOTA_BYTES_PER_ITEM) usage.syncItemQuota = chrome.storage.sync.QUOTA_BYTES_PER_ITEM;
    if (chrome.storage.local && chrome.storage.local.QUOTA_BYTES) usage.localQuota = chrome.storage.local.QUOTA_BYTES;
    const [syncData, localData] = await Promise.all([areaGet('sync', [KEYS.core]), areaGet('local', [KEYS.core])]);
    const s = syncData[KEYS.core];
    const l = localData[KEYS.core];
    usage.syncOk = !l || (!!s && (Number(s.updatedAt) || 0) >= (Number(l.updatedAt) || 0));
    return usage;
  }

  // ---------------------------------------------------------------------------
  // Writing (service worker only, serialized)
  // ---------------------------------------------------------------------------

  let writeQueue = Promise.resolve();
  function serialize(fn) {
    const run = writeQueue.then(fn, fn);
    writeQueue = run.catch(() => {});
    return run;
  }

  async function writeCore(core) {
    const value = Object.assign({}, core, { updatedAt: Date.now() });
    try {
      await areaSet('sync', { [KEYS.core]: value });
      await areaRemove('local', [KEYS.core]);
    } catch (e) {
      // Sync unavailable or over quota: keep a newer local copy, reads pick the newest.
      await areaSet('local', { [KEYS.core]: value });
    }
  }

  async function readCoreForWrite() {
    const s = await getSettings();
    return { enabled: s.enabled, presetsEnabled: s.presetsEnabled, darkMode: s.darkMode, theme: s.theme, showBadge: s.showBadge };
  }

  async function migrate() {
    const [syncData, localData] = await Promise.all([areaGet('sync', [KEYS.core]), areaGet('local', [KEYS.core])]);
    if (syncData[KEYS.core] || localData[KEYS.core]) return false;
    const legacy = await readLegacy();
    const settings = await getSettings(); // already converts legacy in-memory
    await writeCore({ enabled: settings.enabled, presetsEnabled: settings.presetsEnabled, darkMode: settings.darkMode, theme: settings.theme, showBadge: settings.showBadge });
    await areaSet('local', {
      [KEYS.rules]: settings.rules,
      [KEYS.stats]: settings.stats,
      [KEYS.sites]: settings.sites,
      [KEYS.reader]: settings.reader
    });
    if (legacy) {
      await areaRemove('sync', [LEGACY_KEY]);
      await areaRemove('local', [LEGACY_KEY]);
    }
    return !!legacy;
  }

  async function mutateLocal(key, normalizer, mutator) {
    const data = await areaGet('local', [key]);
    const current = normalizer(data[key]);
    const next = (await mutator(current)) || current;
    await areaSet('local', { [key]: next });
    return next;
  }

  const rulesNormalizer = (v) => (Array.isArray(v) ? v : []);
  const packsNormalizer = (v) => (Array.isArray(v) ? v : []);

  // Stats are recorded often; accumulate and flush in batches.
  let pendingStats = null;
  let statsTimer = null;
  function flushStats() {
    statsTimer = null;
    const pending = pendingStats;
    pendingStats = null;
    if (!pending) return Promise.resolve();
    return serialize(() => mutateLocal(KEYS.stats, normalizeStats, (stats) => {
      Object.entries(pending).forEach(([host, d]) => {
        stats.totalBlursStripped += d.blurs || 0;
        stats.totalOverlaysErased += d.overlays || 0;
        stats.totalScrollsUnlocked += d.scrolls || 0;
        if (!host) return;
        const site = stats.sites[host] || { blurs: 0, overlays: 0, scrolls: 0, lastSeen: 0 };
        site.blurs += d.blurs || 0;
        site.overlays += d.overlays || 0;
        site.scrolls += d.scrolls || 0;
        site.lastSeen = Date.now();
        stats.sites[host] = site;
      });
      const hosts = Object.keys(stats.sites);
      if (hosts.length > MAX_SITE_STATS) {
        hosts.sort((a, b) => (stats.sites[a].lastSeen || 0) - (stats.sites[b].lastSeen || 0))
          .slice(0, hosts.length - MAX_SITE_STATS)
          .forEach((h) => delete stats.sites[h]);
      }
      return stats;
    }));
  }

  function updateSiteList(sites, listName, host, enabled) {
    const h = normalizeHost(host);
    const list = sites[listName].filter((x) => normalizeHost(x) !== h);
    if (enabled && h) list.push(h);
    sites[listName] = list;
    return sites;
  }

  /** Validates a backup object (shape only). Returns { settings, errors }. */
  function validateImport(data) {
    const errors = [];
    if (!data || typeof data !== 'object' || Array.isArray(data)) {
      return { settings: null, errors: ['Backup must be a JSON object.'] };
    }
    if (!Array.isArray(data.rules)) errors.push('Missing "rules" array.');
    const rules = [];
    (Array.isArray(data.rules) ? data.rules : []).forEach((r, i) => {
      const clean = sanitizeRuleShape(r);
      if (clean) rules.push(clean);
      else errors.push(`Rule #${i + 1} is invalid and was skipped.`);
    });
    if (errors.length && !rules.length && !Array.isArray(data.rules)) return { settings: null, errors };
    const packs = (Array.isArray(data.rulePacks) ? data.rulePacks : [])
      .filter((p) => p && typeof p.url === 'string' && /^https:\/\//i.test(p.url))
      .map((p) => ({ id: generateId('pack'), name: String(p.name || p.url).slice(0, 120), url: p.url, enabled: p.enabled !== false, builtIn: false, version: '', lastFetched: 0, error: '', rules: [] }));
    return {
      settings: {
        core: normalizeCore(data),
        rules,
        sites: normalizeSites(data.sites),
        reader: normalizeReader(data.reader),
        packs
      },
      errors
    };
  }

  const WRITE_OPS = {
    async toggleMaster(enabled) {
      const core = await readCoreForWrite();
      core.enabled = !!enabled;
      await writeCore(core);
      return core.enabled;
    },

    async togglePreset(presetKey, enabled) {
      if (!PRESET_KEYS.includes(presetKey)) throw new Error(`Unknown preset: ${presetKey}`);
      const core = await readCoreForWrite();
      core.presetsEnabled[presetKey] = !!enabled;
      await writeCore(core);
      return core.presetsEnabled;
    },

    async updateDarkMode(patch) {
      const core = await readCoreForWrite();
      core.darkMode = Object.assign({}, core.darkMode, patch || {});
      await writeCore(normalizeCore(core));
      return (await getSettings()).darkMode;
    },

    async setTheme(theme) {
      const core = await readCoreForWrite();
      core.theme = theme === 'light' ? 'light' : 'dark';
      await writeCore(core);
      return core.theme;
    },

    async addRule(ruleData) {
      const rule = sanitizeRuleShape(Object.assign({}, ruleData, { createdAt: Date.now(), updatedAt: Date.now() }), { keepId: false });
      if (!rule) throw new Error('Rule needs a CSS selector.');
      await mutateLocal(KEYS.rules, rulesNormalizer, (rules) => { rules.push(rule); return rules; });
      return rule;
    },

    async restoreRule(ruleData) {
      const rule = sanitizeRuleShape(ruleData);
      if (!rule) throw new Error('Invalid rule.');
      await mutateLocal(KEYS.rules, rulesNormalizer, (rules) => rules.filter((r) => r.id !== rule.id).concat(rule));
      return rule;
    },

    async updateRule(id, updatedFields) {
      let result = null;
      await mutateLocal(KEYS.rules, rulesNormalizer, (rules) => {
        const index = rules.findIndex((r) => r.id === id);
        if (index === -1) return rules;
        const merged = sanitizeRuleShape(Object.assign({}, rules[index], updatedFields, { id, updatedAt: Date.now() }));
        if (merged) {
          rules[index] = merged;
          result = merged;
        }
        return rules;
      });
      return result;
    },

    async deleteRule(id) {
      let removed = null;
      await mutateLocal(KEYS.rules, rulesNormalizer, (rules) => {
        removed = rules.find((r) => r.id === id) || null;
        return rules.filter((r) => r.id !== id);
      });
      return removed;
    },

    async bulkUpdateRules(ids, patch) {
      const set = new Set(ids || []);
      const allowed = {};
      if (patch && typeof patch.enabled === 'boolean') allowed.enabled = patch.enabled;
      await mutateLocal(KEYS.rules, rulesNormalizer, (rules) => rules.map((r) => (set.has(r.id) ? Object.assign({}, r, allowed, { updatedAt: Date.now() }) : r)));
      return true;
    },

    async bulkDeleteRules(ids) {
      const set = new Set(ids || []);
      let removed = [];
      await mutateLocal(KEYS.rules, rulesNormalizer, (rules) => {
        removed = rules.filter((r) => set.has(r.id));
        return rules.filter((r) => !set.has(r.id));
      });
      return removed;
    },

    async setSitePaused(host, paused) {
      const h = normalizeHost(host);
      await mutateLocal(KEYS.sites, normalizeSites, (sites) => {
        Object.keys(sites.pausedUntil).forEach((k) => { if (normalizeHost(k) === h) delete sites.pausedUntil[k]; });
        return updateSiteList(sites, 'paused', host, paused);
      });
      return !!paused;
    },

    /** Pauses a site for a number of minutes (removes any permanent pause). Returns the end timestamp. */
    async pauseSiteFor(host, minutes) {
      const h = normalizeHost(host);
      const mins = clampNumber(minutes, 1, 24 * 60, 30);
      const until = Date.now() + mins * 60 * 1000;
      if (!h) throw new Error('No site to pause.');
      await mutateLocal(KEYS.sites, normalizeSites, (sites) => {
        Object.keys(sites.pausedUntil).forEach((k) => { if (normalizeHost(k) === h) delete sites.pausedUntil[k]; });
        sites.pausedUntil[h] = until;
        return updateSiteList(sites, 'paused', h, false);
      });
      return until;
    },

    /** Drops expired timed pauses (normalizeSites filters them), which wakes up content scripts. */
    async clearExpiredPauses() {
      await mutateLocal(KEYS.sites, normalizeSites, (sites) => sites);
      return true;
    },

    async setShowBadge(show) {
      const core = await readCoreForWrite();
      core.showBadge = !!show;
      await writeCore(core);
      return core.showBadge;
    },

    /** Merges the rules of a rule pack file into the user rules, skipping duplicates. */
    async importRulePack(payload) {
      if (!isRulePackFile(payload)) throw new Error('This file is not a rule pack.');
      const errors = [];
      let imported = 0;
      const key = (r) => [r.siteScope, normalizeHost(r.domainPattern || ''), r.selector, r.actionType, r.customCss || ''].join('|');
      await mutateLocal(KEYS.rules, rulesNormalizer, (rules) => {
        const seen = new Set(rules.map(key));
        payload.rules.slice(0, 2000).forEach((r, i) => {
          const clean = sanitizeRuleShape(Object.assign({}, r, { createdAt: Date.now(), updatedAt: Date.now() }), { keepId: false });
          if (!clean) { errors.push(`Rule #${i + 1} is invalid and was skipped.`); return; }
          if (seen.has(key(clean))) return;
          seen.add(key(clean));
          rules.push(clean);
          imported++;
        });
        return rules;
      });
      return { imported, errors };
    },

    async setSiteDarkMode(host, mode) {
      const h = normalizeHost(host);
      await mutateLocal(KEYS.sites, normalizeSites, (sites) => {
        Object.keys(sites.darkMode).forEach((k) => { if (normalizeHost(k) === h) delete sites.darkMode[k]; });
        if (['filter', 'dynamic', 'off'].includes(mode) && h) sites.darkMode[h] = mode;
        return sites;
      });
      return mode || null;
    },

    async setAutoReader(host, enabled) {
      await mutateLocal(KEYS.sites, normalizeSites, (sites) => updateSiteList(sites, 'autoReader', host, enabled));
      return !!enabled;
    },

    async updateReaderPrefs(patch) {
      return mutateLocal(KEYS.reader, normalizeReader, (reader) => normalizeReader(Object.assign({}, reader, patch || {})));
    },

    async saveRulePacks(packs) {
      await areaSet('local', { [KEYS.packs]: Array.isArray(packs) ? packs : [] });
      return true;
    },

    async updateRulePack(id, patch) {
      let result = null;
      await mutateLocal(KEYS.packs, packsNormalizer, (packs) => packs.map((p) => {
        if (p.id !== id) return p;
        result = Object.assign({}, p, patch || {}, { id: p.id, builtIn: p.builtIn });
        return result;
      }));
      return result;
    },

    async removeRulePack(id) {
      await mutateLocal(KEYS.packs, packsNormalizer, (packs) => packs.filter((p) => p.id !== id || p.builtIn));
      return true;
    },

    async recordStats(host, deltas) {
      const h = normalizeHost(host);
      pendingStats = pendingStats || {};
      const cur = pendingStats[h] || { blurs: 0, overlays: 0, scrolls: 0 };
      cur.blurs += Math.max(0, Number(deltas && deltas.blurs) || 0);
      cur.overlays += Math.max(0, Number(deltas && deltas.overlays) || 0);
      cur.scrolls += Math.max(0, Number(deltas && deltas.scrolls) || 0);
      pendingStats[h] = cur;
      if (!statsTimer) statsTimer = setTimeout(flushStats, 3000);
      return true;
    },

    async resetStats() {
      pendingStats = null;
      await areaSet('local', { [KEYS.stats]: normalizeStats(null) });
      return true;
    },

    /** Saves a page's highlights and keeps the library index (capped, oldest pages dropped first). */
    async saveHighlights(url, list, meta) {
      const key = highlightKey(url);
      const clean = sanitizeHighlights(list);
      const data = await areaGet('local', [KEYS.highlightIndex]);
      const index = normalizeHighlightIndex(data[KEYS.highlightIndex]);
      if (clean.length) {
        const prev = index[key] || {};
        const title = meta && typeof meta.title === 'string' && meta.title.trim() ? meta.title.trim() : prev.title;
        index[key] = {
          url: String(url || '').replace(/#.*$/, '').slice(0, 2000),
          title: String(title || '').slice(0, 300),
          count: clean.length,
          notes: clean.filter((h) => h.note).length,
          updatedAt: Date.now()
        };
        await areaSet('local', { [key]: clean });
      } else {
        delete index[key];
        await areaRemove('local', [key]);
      }
      const keys = Object.keys(index);
      if (keys.length > MAX_HIGHLIGHT_PAGES) {
        const drop = keys.sort((a, b) => index[a].updatedAt - index[b].updatedAt).slice(0, keys.length - MAX_HIGHLIGHT_PAGES);
        drop.forEach((k) => delete index[k]);
        await areaRemove('local', drop);
      }
      await areaSet('local', { [KEYS.highlightIndex]: index });
      return true;
    },

    async deleteHighlightPage(key) {
      if (typeof key !== 'string' || !key.startsWith(HIGHLIGHT_PREFIX)) throw new Error('Unknown page.');
      const data = await areaGet('local', [KEYS.highlightIndex]);
      const index = normalizeHighlightIndex(data[KEYS.highlightIndex]);
      delete index[key];
      await areaRemove('local', [key]);
      await areaSet('local', { [KEYS.highlightIndex]: index });
      return true;
    },

    /** Indexes highlights saved before the library existed (v1.3 and older). */
    async rebuildHighlightIndex() {
      if (!hasChromeStorage() || !chrome.storage.local) return 0;
      const all = await new Promise((resolve) => chrome.storage.local.get(null, (r) => resolve(chrome.runtime.lastError ? {} : r || {})));
      const index = normalizeHighlightIndex(all[KEYS.highlightIndex]);
      let added = 0;
      Object.keys(all).forEach((key) => {
        if (!key.startsWith(HIGHLIGHT_PREFIX) || index[key] || !Array.isArray(all[key]) || !all[key].length) return;
        const list = all[key];
        index[key] = {
          url: `https://${key.slice(HIGHLIGHT_PREFIX.length)}`,
          title: '',
          count: list.length,
          notes: list.filter((h) => h && h.note).length,
          updatedAt: Math.max(0, ...list.map((h) => Number(h && h.createdAt) || 0))
        };
        added++;
      });
      if (added) await areaSet('local', { [KEYS.highlightIndex]: index });
      return added;
    },

    /** Turns a preset on/off for one site only; `value` null drops the override (follow the global setting). */
    async setSitePreset(host, presetKey, value) {
      if (!SITE_PRESET_KEYS.includes(presetKey)) throw new Error(`Unknown preset: ${presetKey}`);
      const h = normalizeHost(host);
      if (!h) throw new Error('No site.');
      await mutateLocal(KEYS.sites, normalizeSites, (sites) => {
        const map = Object.assign({}, sites.presets[h] || {});
        if (typeof value === 'boolean') map[presetKey] = value;
        else delete map[presetKey];
        if (Object.keys(map).length) sites.presets[h] = map;
        else delete sites.presets[h];
        return sites;
      });
      return true;
    },

    async clearSitePresets(host) {
      const h = normalizeHost(host);
      await mutateLocal(KEYS.sites, normalizeSites, (sites) => {
        delete sites.presets[h];
        return sites;
      });
      return true;
    },

    async importSettings(data, mode) {
      const { settings, errors } = validateImport(data);
      if (!settings) throw new Error(errors.join(' '));
      if (mode === 'merge') {
        // "Add to my rules": rules, rule packs and site lists are added; presets, dark mode and
        // Reader settings stay as they are.
        await mutateLocal(KEYS.rules, rulesNormalizer, (rules) => {
          const ids = new Set(rules.map((r) => r.id));
          return rules.concat(settings.rules.filter((r) => !ids.has(r.id)));
        });
        await mutateLocal(KEYS.sites, normalizeSites, (sites) => {
          ['paused', 'autoReader'].forEach((list) => {
            settings.sites[list].forEach((h) => { if (!sites[list].some((x) => normalizeHost(x) === normalizeHost(h))) sites[list].push(h); });
          });
          Object.entries(settings.sites.darkMode).forEach(([h, m]) => { if (!(h in sites.darkMode)) sites.darkMode[h] = m; });
          Object.entries(settings.sites.presets).forEach(([h, m]) => { sites.presets[h] = Object.assign({}, m, sites.presets[h] || {}); });
          return sites;
        });
      } else {
        await writeCore(settings.core);
        await areaSet('local', { [KEYS.rules]: settings.rules, [KEYS.sites]: settings.sites, [KEYS.reader]: settings.reader });
      }
      if (settings.packs.length) {
        await mutateLocal(KEYS.packs, packsNormalizer, (packs) => {
          const urls = new Set(packs.map((p) => p.url));
          return packs.concat(settings.packs.filter((p) => !urls.has(p.url)));
        });
      }
      return { imported: settings.rules.length, errors };
    },

    async migrate() {
      return migrate();
    }
  };

  async function exportSettings() {
    const s = await getSettings();
    return {
      exportedBy: 'Blur Remover & DOM Modifier',
      schemaVersion: SCHEMA_VERSION,
      exportedAt: new Date().toISOString(),
      enabled: s.enabled,
      presetsEnabled: s.presetsEnabled,
      darkMode: s.darkMode,
      theme: s.theme,
      showBadge: s.showBadge,
      rules: s.rules,
      sites: s.sites,
      reader: s.reader,
      rulePacks: s.rulePacks.filter((p) => !p.builtIn).map((p) => ({ name: p.name, url: p.url, enabled: p.enabled }))
    };
  }

  function runWrite(op, args) {
    const fn = WRITE_OPS[op];
    if (!fn) return Promise.reject(new Error(`Unknown storage op: ${op}`));
    if (op === 'recordStats') return fn(...args); // batched internally
    return serialize(() => fn(...args));
  }

  function proxyWrite(op, args) {
    if (isServiceWorker() || typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.sendMessage) {
      return runWrite(op, args);
    }
    return new Promise((resolve, reject) => {
      try {
        chrome.runtime.sendMessage({ type: 'BR_STORAGE', op, args }, (response) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
            return;
          }
          if (!response) {
            reject(new Error('No response from background.'));
            return;
          }
          if (response.ok) resolve(response.result);
          else reject(new Error(response.error || 'Storage operation failed.'));
        });
      } catch (e) {
        reject(e);
      }
    });
  }

  const StorageAPI = {
    SCHEMA_VERSION,
    KEYS,
    ACTION_TYPES,
    SITE_SCOPES,
    PRESET_KEYS,
    SITE_PRESET_KEYS,
    CONTENT_SCRIPT_OPS,
    DEFAULT_SETTINGS,
    LEGACY_KEY,

    getSettings,
    getHighlights,
    getHighlightPages,
    highlightKey,
    getStorageUsage,
    exportSettings,
    validateImport,
    sanitizeRuleShape,
    generateId,

    normalizeHost,
    matchDomainPattern,
    matchExactPattern,
    normalizeUrlForExact,
    isSitePaused,
    getPausedUntil,
    buildSiteRulePack,
    isRulePackFile,
    isAutoReaderSite,
    getAllRules,
    getRulesForHost,
    getEffectiveDarkMode,
    getSiteDarkOverride,
    getSitePresets,
    getEffectivePresets,

    /** Service worker only: executes a proxied write. */
    handleStorageMessage(message) {
      return runWrite(message.op, Array.isArray(message.args) ? message.args : []);
    },
    flushStats
  };

  Object.keys(WRITE_OPS).forEach((op) => {
    StorageAPI[op] = (...args) => proxyWrite(op, args);
  });

  global.BlurRemoverStorage = StorageAPI;
})(typeof self !== 'undefined' ? self : this);
