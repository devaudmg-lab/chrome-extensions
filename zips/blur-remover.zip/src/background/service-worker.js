/**
 * Blur Remover & DOM Modifier - Background Service Worker
 * Serializes storage writes, injects on-demand features (picker, reader) into the top frame,
 * owns per-tab state (instant unblur), badges, keyboard shortcuts, context menus and rule packs.
 */

importScripts('../utils/storage.js');

const Store = self.BlurRemoverStorage;

const FILES = {
  core: ['src/utils/storage.js', 'src/utils/dom-utils.js', 'src/content/dark-mode.js', 'src/content/content-engine.js'],
  picker: ['src/utils/storage.js', 'src/utils/dom-utils.js', 'src/utils/selector-generator.js', 'src/content/element-picker.js'],
  reader: ['src/utils/storage.js', 'src/utils/dom-utils.js', 'src/vendor/Readability.js', 'src/vendor/Readability-readerable.js', 'src/content/reader-view.js']
};

const BUILT_IN_PACK_ID = 'pack-built-in';
const BUILT_IN_PACK_PATH = 'rule-packs/default.json';
const PACK_ALARM = 'refresh-rule-packs';
const RESUME_ALARM = 'resume-paused-sites';
const TIMED_PAUSE_MINUTES = 30;
const SESSION_INSTANT_KEY = 'instantUnblurTabs';
const MAX_FETCH_BYTES = 2 * 1024 * 1024;

const FONT_FILES = {
  'atkinson-400': 'src/fonts/atkinson-hyperlegible-latin-400-normal.woff2',
  'atkinson-700': 'src/fonts/atkinson-hyperlegible-latin-700-normal.woff2',
  'dyslexic-400': 'src/fonts/opendyslexic-latin-400-normal.woff2',
  'dyslexic-700': 'src/fonts/opendyslexic-latin-700-normal.woff2'
};

// ---------------------------------------------------------------------------
// Install / startup
// ---------------------------------------------------------------------------

chrome.runtime.onInstalled.addListener(async (details) => {
  try {
    await Store.migrate();
    await Store.handleStorageMessage({ op: 'rebuildHighlightIndex', args: [] });
  } catch (e) {
    console.error('[BlurRemover] Migration failed:', e);
  }
  setupContextMenus();
  // Alarms are not guaranteed to survive an update, so (re)create them every time.
  chrome.alarms.create(PACK_ALARM, { periodInMinutes: 24 * 60 });
  await scheduleResumeAlarm().catch(() => {});
  await refreshRulePacks({ force: true }).catch((e) => console.warn('[BlurRemover] Rule pack refresh failed:', e.message));
  // Tabs that were open before the install / update have no (or an orphaned) content script.
  if (details.reason === 'install' || details.reason === 'update') injectIntoOpenTabs();
  if (details.reason === 'install') {
    chrome.tabs.create({ url: chrome.runtime.getURL('src/onboarding/welcome.html') });
  }
});

chrome.runtime.onStartup.addListener(async () => {
  try {
    await Store.migrate();
  } catch (e) { /* already migrated */ }
  // Alarms may be cleared when the browser restarts.
  if (!(await chrome.alarms.get(PACK_ALARM))) chrome.alarms.create(PACK_ALARM, { periodInMinutes: 24 * 60 });
  await scheduleResumeAlarm().catch(() => {});
  await refreshRulePacks({ force: false }).catch(() => {});
});

/** Loads the content engine into already open tabs (after install or update), so no reload is needed. */
async function injectIntoOpenTabs() {
  let tabs = [];
  try {
    tabs = await chrome.tabs.query({ url: ['http://*/*', 'https://*/*'] });
  } catch (e) {
    return;
  }
  for (const tab of tabs) {
    if (tab.discarded || !isInjectableUrl(tab.url)) continue;
    chrome.scripting.executeScript({ target: { tabId: tab.id, frameIds: [0] }, files: FILES.core }).catch(() => {});
  }
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === PACK_ALARM) refreshRulePacks({ force: true });
  if (alarm.name === RESUME_ALARM) {
    Store.handleStorageMessage({ op: 'clearExpiredPauses', args: [] })
      .catch(() => {})
      .then(scheduleResumeAlarm);
  }
});

/** One alarm for the earliest timed pause; expired pauses are dropped when it fires. */
async function scheduleResumeAlarm() {
  const settings = await Store.getSettings();
  const ends = Object.values(settings.sites.pausedUntil || {}).map(Number).filter((t) => t > Date.now());
  if (!ends.length) {
    await chrome.alarms.clear(RESUME_ALARM);
    return;
  }
  // +1 s so normalizeSites already sees the pause as expired.
  chrome.alarms.create(RESUME_ALARM, { when: Math.min(...ends) + 1000 });
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.br_sites) scheduleResumeAlarm().catch(() => {});
});

function setupContextMenus() {
  chrome.contextMenus.removeAll(() => {
    const items = [
      { id: 'br_pick_element', title: chrome.i18n.getMessage('menuPickElement') || 'Pick this element to unblur / hide', contexts: ['page', 'selection', 'link', 'image', 'video'] },
      { id: 'br_zap_element', title: chrome.i18n.getMessage('menuZapElement') || 'Zap this element (one-off, Ctrl+Z to undo)', contexts: ['page', 'selection', 'link', 'image', 'video'] },
      { id: 'br_unblur_page', title: chrome.i18n.getMessage('menuUnblurPage') || 'Toggle instant unblur for this tab (Alt+U)', contexts: ['page'] },
      { id: 'br_reader_view', title: chrome.i18n.getMessage('menuReaderView') || 'Toggle Reader View (Alt+R)', contexts: ['page', 'selection'] },
      { id: 'br_dark_site', title: chrome.i18n.getMessage('menuDarkSite') || 'Toggle dark mode on this site (Alt+Shift+D)', contexts: ['page'] },
      { id: 'br_pause_site', title: chrome.i18n.getMessage('menuPauseSite') || 'Pause / resume Blur Remover on this site', contexts: ['page'] },
      { id: 'br_pause_site_timed', title: chrome.i18n.getMessage('menuPauseSiteTimed') || 'Pause on this site for 30 minutes', contexts: ['page'] }
    ];
    items.forEach((item) => chrome.contextMenus.create(item));
  });
}

// ---------------------------------------------------------------------------
// Tab messaging helpers (always the top frame)
// ---------------------------------------------------------------------------

// Chrome never lets extensions script the Web Store.
const BLOCKED_PAGES = /^https:\/\/(chromewebstore\.google\.com|chrome\.google\.com\/webstore)(\/|$)/i;

function isInjectableUrl(url) {
  return typeof url === 'string' && /^https?:\/\//i.test(url) && !BLOCKED_PAGES.test(url);
}

/** True for messages from the extension's own pages (popup, options, onboarding), not content scripts. */
function isExtensionPage(sender) {
  return !!sender && sender.id === chrome.runtime.id && typeof sender.url === 'string' && sender.url.startsWith(chrome.runtime.getURL(''));
}

function hostOf(url) {
  try {
    return Store.normalizeHost(new URL(url).hostname);
  } catch (e) {
    return '';
  }
}

/**
 * Storage writes requested by a content script: only the few operations the picker / reader /
 * stats need, and only for the page the script runs in.
 */
function checkContentStorageOp(message, sender) {
  const op = message.op;
  const args = Array.isArray(message.args) ? message.args : [];
  if (!Store.CONTENT_SCRIPT_OPS.includes(op)) throw new Error('Not allowed from a web page.');
  const pageHost = hostOf(sender.url || (sender.tab && sender.tab.url) || '');
  if (op === 'saveHighlights' && hostOf(String(args[0] || '')) !== pageHost) throw new Error('Not allowed.');
  if (op === 'setAutoReader' && Store.normalizeHost(args[0]) !== pageHost) throw new Error('Not allowed.');
}

/** Makes sure the content engine runs in the tab (popup asks after install or on restricted pages). */
async function ensureCore(tabId) {
  const tab = await chrome.tabs.get(tabId);
  if (!isInjectableUrl(tab.url)) throw new Error('restricted');
  try {
    const [{ result } = {}] = await chrome.scripting.executeScript({ target: { tabId, frameIds: [0] }, func: () => !!self.BlurRemoverEngine });
    if (!result) await chrome.scripting.executeScript({ target: { tabId, frameIds: [0] }, files: FILES.core });
  } catch (e) {
    // PDF viewer, error pages, pages blocked by policy, ...
    throw new Error('restricted');
  }
  return true;
}

async function sendToTab(tabId, message, files) {
  try {
    return await chrome.tabs.sendMessage(tabId, message, { frameId: 0 });
  } catch (err) {
    if (!files) throw err;
    await chrome.scripting.executeScript({ target: { tabId, frameIds: [0] }, files });
    return chrome.tabs.sendMessage(tabId, message, { frameId: 0 });
  }
}

/** Ensures a feature's scripts are present in the top frame, then sends the message. */
async function runFeature(tabId, feature, message) {
  const files = FILES[feature];
  // Feature scripts are loaded on demand, so make sure they exist before messaging.
  const [{ result: loaded } = {}] = await chrome.scripting.executeScript({
    target: { tabId, frameIds: [0] },
    func: (globalName) => !!self[globalName],
    args: [feature === 'picker' ? 'BlurRemoverPicker' : feature === 'reader' ? 'BlurRemoverReader' : 'BlurRemoverEngine']
  });
  if (!loaded) {
    await chrome.scripting.executeScript({ target: { tabId, frameIds: [0] }, files });
  }
  return chrome.tabs.sendMessage(tabId, message, { frameId: 0 });
}

async function getInstantTabs() {
  const data = await chrome.storage.session.get(SESSION_INSTANT_KEY);
  return new Set(data[SESSION_INSTANT_KEY] || []);
}

async function setInstantTab(tabId, on) {
  const tabs = await getInstantTabs();
  if (on) tabs.add(tabId);
  else tabs.delete(tabId);
  await chrome.storage.session.set({ [SESSION_INSTANT_KEY]: Array.from(tabs) });
}

async function toggleInstantUnblur(tab) {
  const tabs = await getInstantTabs();
  const on = !tabs.has(tab.id);
  await setInstantTab(tab.id, on);
  await sendToTab(tab.id, { action: 'SET_INSTANT_UNBLUR', on, announce: true }, FILES.core).catch(() => {});
  return on;
}

async function toggleSitePause(tab) {
  const host = new URL(tab.url).hostname;
  const settings = await Store.getSettings();
  const paused = !Store.isSitePaused(settings, host);
  await Store.handleStorageMessage({ op: 'setSitePaused', args: [host, paused] });
  sendToTab(tab.id, { action: 'SHOW_TOAST', text: paused ? `Paused on ${host}` : `Resumed on ${host}` }).catch(() => {});
  return paused;
}

async function pauseSiteFor(tab, minutes) {
  const host = new URL(tab.url).hostname;
  const until = await Store.handleStorageMessage({ op: 'pauseSiteFor', args: [host, minutes || TIMED_PAUSE_MINUTES] });
  const time = new Date(until).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  sendToTab(tab.id, { action: 'SHOW_TOAST', text: `Paused on ${host} until ${time}` }).catch(() => {});
  return { until };
}

/**
 * Flips dark mode for the tab's site: an active mode becomes a per-site "off", otherwise the
 * globally preferred mode (filter / dynamic) is switched on for this site only.
 */
async function toggleSiteDarkMode(tab) {
  const host = new URL(tab.url).hostname;
  const settings = await Store.getSettings();
  if (!settings.enabled || Store.isSitePaused(settings, host)) {
    sendToTab(tab.id, { action: 'SHOW_TOAST', text: 'Blur Remover is paused or off here' }).catch(() => {});
    return { mode: null };
  }
  const active = Store.getEffectiveDarkMode(settings, host);
  const next = active ? 'off' : (settings.darkMode.mode || 'filter');
  await Store.handleStorageMessage({ op: 'setSiteDarkMode', args: [host, next] });
  sendToTab(tab.id, { action: 'SHOW_TOAST', text: next === 'off' ? `Dark mode off on ${host}` : `Dark mode (${next}) on ${host}` }).catch(() => {});
  return { mode: next };
}

/** Runs a user-facing action on a tab. Used by commands, context menus and the popup. */
async function runAction(action, tab, extra = {}) {
  if (!tab || !tab.id || !isInjectableUrl(tab.url)) {
    throw new Error('This page cannot be modified by extensions.');
  }
  switch (action) {
    case 'TOGGLE_INSTANT_UNBLUR':
      return { on: await toggleInstantUnblur(tab) };
    case 'START_PICKER':
      return runFeature(tab.id, 'picker', { action: 'START_PICKER', useContextTarget: !!extra.useContextTarget });
    case 'TOGGLE_READER':
      return runFeature(tab.id, 'reader', { action: 'TOGGLE_READER' });
    case 'OPEN_READER':
      return runFeature(tab.id, 'reader', { action: 'START_READER_VIEW', auto: !!extra.auto });
    case 'ZAP_CONTEXT_TARGET':
      return sendToTab(tab.id, { action: 'ZAP_CONTEXT_TARGET' }, FILES.core);
    case 'TOGGLE_SITE_PAUSE':
      return { paused: await toggleSitePause(tab) };
    case 'PAUSE_SITE_TIMED':
      return pauseSiteFor(tab, extra.minutes);
    case 'TOGGLE_SITE_DARK':
      return toggleSiteDarkMode(tab);
    default:
      throw new Error(`Unknown action: ${action}`);
  }
}

// ---------------------------------------------------------------------------
// Commands & context menus
// ---------------------------------------------------------------------------

const COMMAND_ACTIONS = {
  'toggle-instant-unblur': 'TOGGLE_INSTANT_UNBLUR',
  'start-element-picker': 'START_PICKER',
  'start-reader-view': 'TOGGLE_READER',
  'toggle-site-pause': 'TOGGLE_SITE_PAUSE',
  'toggle-site-dark-mode': 'TOGGLE_SITE_DARK'
};

chrome.commands.onCommand.addListener(async (command, tabFromEvent) => {
  const action = COMMAND_ACTIONS[command];
  if (!action) return;
  const tab = tabFromEvent || (await chrome.tabs.query({ active: true, currentWindow: true }))[0];
  runAction(action, tab).catch((e) => console.warn('[BlurRemover] Command failed:', e.message));
});

const MENU_ACTIONS = {
  br_pick_element: ['START_PICKER', { useContextTarget: true }],
  br_zap_element: ['ZAP_CONTEXT_TARGET', {}],
  br_unblur_page: ['TOGGLE_INSTANT_UNBLUR', {}],
  br_reader_view: ['TOGGLE_READER', {}],
  br_pause_site: ['TOGGLE_SITE_PAUSE', {}],
  br_pause_site_timed: ['PAUSE_SITE_TIMED', { minutes: TIMED_PAUSE_MINUTES }],
  br_dark_site: ['TOGGLE_SITE_DARK', {}]
};

chrome.contextMenus.onClicked.addListener((info, tab) => {
  const entry = MENU_ACTIONS[info.menuItemId];
  if (!entry) return;
  runAction(entry[0], tab, entry[1]).catch((e) => console.warn('[BlurRemover] Menu action failed:', e.message));
});

// ---------------------------------------------------------------------------
// Badge: reported by the content script (rules that matched elements on the page)
// ---------------------------------------------------------------------------

function setBadge(tabId, text, color, title) {
  chrome.action.setBadgeText({ tabId, text }).catch(() => {});
  if (color) chrome.action.setBadgeBackgroundColor({ tabId, color }).catch(() => {});
  chrome.action.setTitle({ tabId, title: title || chrome.i18n.getMessage('extName') || 'Blur Remover' }).catch(() => {});
}

// Last report per tab, so a change of the "show badge" setting applies to open tabs right away.
const lastReports = new Map();

chrome.storage.onChanged.addListener((changes) => {
  if (!changes.br_core) return;
  lastReports.forEach((report, tabId) => updateBadgeFromReport(tabId, report).catch(() => {}));
});

async function updateBadgeFromReport(tabId, report) {
  if (!report) return;
  lastReports.set(tabId, report);
  // The badge text can be hidden in Options; the tooltip still tells what is going on.
  const settings = await Store.getSettings().catch(() => null);
  const show = !settings || settings.showBadge !== false;
  const text = (value) => (show ? value : '');
  if (!report.enabled) return setBadge(tabId, text('OFF'), '#64748b', chrome.i18n.getMessage('badgeOff'));
  if (report.paused) return setBadge(tabId, text('||'), '#f59e0b', chrome.i18n.getMessage('badgePaused'));
  const n = report.matchCount || 0;
  setBadge(tabId, text(n > 0 ? String(n) : ''), '#6366f1', n > 0 ? chrome.i18n.getMessage('badgeMatched', [String(n)]) : '');
}

chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.status === 'loading' && changeInfo.url) {
    lastReports.delete(tabId);
    setBadge(tabId, '');
  }
});

chrome.tabs.onRemoved.addListener((tabId) => {
  lastReports.delete(tabId);
  setInstantTab(tabId, false).catch(() => {});
});

// ---------------------------------------------------------------------------
// Rule packs
// ---------------------------------------------------------------------------

function sanitizePackPayload(payload) {
  if (!payload || typeof payload !== 'object' || !Array.isArray(payload.rules)) {
    throw new Error('Pack must be JSON with a "rules" array.');
  }
  const rules = payload.rules.slice(0, 2000).map((r, i) => {
    const clean = Store.sanitizeRuleShape(Object.assign({}, r, { id: `r${i}` }));
    return clean;
  }).filter(Boolean);
  return {
    name: typeof payload.name === 'string' ? payload.name.slice(0, 120) : '',
    version: typeof payload.version === 'string' || typeof payload.version === 'number' ? String(payload.version).slice(0, 40) : '',
    rules
  };
}

async function fetchJson(url) {
  const res = await fetch(url, { cache: 'no-cache', credentials: 'omit' });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const text = await res.text();
  if (text.length > MAX_FETCH_BYTES) throw new Error('Pack is too large.');
  return JSON.parse(text);
}

async function fetchPack(pack) {
  try {
    const payload = sanitizePackPayload(await fetchJson(pack.url));
    return Object.assign({}, pack, {
      name: pack.builtIn ? (payload.name || pack.name) : (pack.name || payload.name || pack.url),
      version: payload.version,
      rules: payload.rules.map((r) => Object.assign(r, { id: `${pack.id}:${r.id}` })),
      lastFetched: Date.now(),
      error: ''
    });
  } catch (e) {
    return Object.assign({}, pack, { error: e.message, lastFetched: Date.now() });
  }
}

async function refreshRulePacks({ force = false, onlyId = null } = {}) {
  const settings = await Store.getSettings();
  let packs = settings.rulePacks.slice();

  if (!packs.some((p) => p.id === BUILT_IN_PACK_ID)) {
    packs.unshift({
      id: BUILT_IN_PACK_ID,
      name: 'Built-in site fixes',
      url: chrome.runtime.getURL(BUILT_IN_PACK_PATH),
      enabled: true,
      builtIn: true,
      version: '',
      lastFetched: 0,
      error: '',
      rules: []
    });
  }
  // The extension URL changes between installs (unpacked dev builds), keep it current.
  packs = packs.map((p) => (p.builtIn ? Object.assign({}, p, { url: chrome.runtime.getURL(BUILT_IN_PACK_PATH) }) : p));

  const DAY = 24 * 60 * 60 * 1000;
  const updated = await Promise.all(packs.map((p) => {
    if (onlyId && p.id !== onlyId) return p;
    if (!force && !p.builtIn && p.lastFetched && Date.now() - p.lastFetched < DAY) return p;
    return fetchPack(p);
  }));

  // Merge with the latest stored packs so toggles made while fetching are kept.
  const latest = (await Store.getSettings()).rulePacks;
  const merged = updated.map((p) => {
    const cur = latest.find((x) => x.id === p.id);
    return cur ? Object.assign({}, p, { enabled: cur.enabled, name: p.builtIn ? p.name : cur.name }) : p;
  }).filter((p) => p.builtIn || latest.some((x) => x.id === p.id) || !settings.rulePacks.length);
  await Store.handleStorageMessage({ op: 'saveRulePacks', args: [merged] });
  return merged;
}

async function addRulePack(url, name) {
  if (!/^https:\/\//i.test(url)) throw new Error('Rule pack URLs must start with https://');
  const settings = await Store.getSettings();
  if (settings.rulePacks.some((p) => p.url === url)) throw new Error('This rule pack is already added.');
  const pack = await fetchPack({
    id: Store.generateId('pack'),
    name: name || '',
    url,
    enabled: true,
    builtIn: false,
    version: '',
    lastFetched: 0,
    error: '',
    rules: []
  });
  if (pack.error) throw new Error(`Could not load pack: ${pack.error}`);
  const latest = (await Store.getSettings()).rulePacks;
  await Store.handleStorageMessage({ op: 'saveRulePacks', args: [latest.concat(pack)] });
  return pack;
}

// ---------------------------------------------------------------------------
// Fetch helpers for content scripts
// ---------------------------------------------------------------------------

/** True for loopback, private, link-local and local-only hosts the page could abuse us to reach. */
function isPrivateHost(hostname) {
  const h = hostname.toLowerCase().replace(/^\[|\]$/g, '');
  if (h === 'localhost' || h.endsWith('.localhost') || h.endsWith('.local') || h.endsWith('.internal') || !h.includes('.') && !h.includes(':')) return true;
  if (h.includes(':')) {
    // IPv6: loopback, unspecified, unique-local (fc00::/7), link-local (fe80::/10), IPv4-mapped
    return h === '::1' || h === '::' || /^f[cd]/.test(h) || /^fe[89ab]/.test(h) || h.startsWith('::ffff:');
  }
  const m = h.match(/^(\d+)\.(\d+)\.(\d+)\.(\d+)$/);
  if (!m) return false;
  const [a, b] = [Number(m[1]), Number(m[2])];
  return a === 10 || a === 127 || a === 0 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) ||
    (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127) || a >= 224;
}

/**
 * Fetches a cross-origin stylesheet for dynamic dark mode. The URL comes from page content, so
 * only public http(s) hosts are allowed, redirects are refused and the response must be CSS.
 */
async function fetchStylesheet(url, senderTab) {
  if (!senderTab || !isInjectableUrl(senderTab.url)) throw new Error('Not allowed.');
  let parsed;
  try {
    parsed = new URL(url);
  } catch (e) {
    throw new Error('Invalid URL.');
  }
  if (!/^https?:$/.test(parsed.protocol)) throw new Error('Only http(s) stylesheets can be fetched.');
  if (parsed.username || parsed.password) throw new Error('Not allowed.');
  if (isPrivateHost(parsed.hostname) && !isPrivateHost(new URL(senderTab.url).hostname)) {
    // A public page may not use us to reach the local network (intranet pages may load their own CSS).
    throw new Error('Private network stylesheets are not fetched for public pages.');
  }
  const res = await fetch(parsed.href, { credentials: 'omit', redirect: 'error', referrerPolicy: 'no-referrer' });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const type = res.headers.get('content-type') || '';
  if (!/^text\/css\b/i.test(type)) throw new Error('Not a stylesheet.');
  const text = await res.text();
  if (text.length > MAX_FETCH_BYTES) throw new Error('Stylesheet too large.');
  return text;
}

async function readFontAsBase64(name) {
  const path = FONT_FILES[name];
  if (!path) throw new Error('Unknown font');
  const buf = await (await fetch(chrome.runtime.getURL(path))).arrayBuffer();
  const bytes = new Uint8Array(buf);
  let binary = '';
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
}

// ---------------------------------------------------------------------------
// Message router
// ---------------------------------------------------------------------------

function respond(promise, sendResponse) {
  Promise.resolve(promise)
    .then((result) => sendResponse({ ok: true, result }))
    .catch((e) => sendResponse({ ok: false, error: e && e.message ? e.message : String(e) }));
  return true;
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || !message.type) return false;
  const tab = sender.tab;

  switch (message.type) {
    case 'BR_STORAGE':
      if (!isExtensionPage(sender)) {
        try {
          checkContentStorageOp(message, sender);
        } catch (e) {
          return respond(Promise.reject(e), sendResponse);
        }
      }
      return respond(Store.handleStorageMessage(message), sendResponse);

    case 'MATCH_COUNT':
      if (tab && sender.frameId === 0) updateBadgeFromReport(tab.id, message).catch(() => {});
      return false;

    case 'GET_TAB_STATE':
      return respond(getInstantTabs().then((tabs) => ({ instantUnblur: !!(tab && tabs.has(tab.id)) })), sendResponse);

    case 'AUTO_OPEN_READER':
      if (!tab) return false;
      return respond(runAction('OPEN_READER', tab, { auto: true }), sendResponse);

    case 'RUN_ACTION':
      if (!isExtensionPage(sender)) return false;
      return respond(
        chrome.tabs.get(message.tabId).then((t) => runAction(message.action, t, message.extra || {})),
        sendResponse
      );

    case 'FETCH_STYLESHEET':
      if (!tab || sender.frameId !== 0) return false;
      return respond(fetchStylesheet(message.url, tab), sendResponse);

    case 'GET_FONT':
      return respond(readFontAsBase64(message.name), sendResponse);

    case 'ENSURE_CORE':
      if (!isExtensionPage(sender)) return false;
      return respond(ensureCore(message.tabId), sendResponse);

    case 'REFRESH_RULE_PACKS':
      if (!isExtensionPage(sender)) return false;
      return respond(refreshRulePacks({ force: true, onlyId: message.id || null }), sendResponse);

    case 'ADD_RULE_PACK':
      if (!isExtensionPage(sender)) return false;
      return respond(addRulePack(message.url, message.name), sendResponse);

    case 'OPEN_OPTIONS':
      // Optional section, e.g. "highlights" from the Reader View notes panel.
      if (typeof message.section === 'string' && /^[a-z]{1,20}$/.test(message.section)) {
        chrome.tabs.create({ url: chrome.runtime.getURL(`src/options/options.html#${message.section}`) });
      } else {
        chrome.runtime.openOptionsPage();
      }
      return false;

    case 'OPEN_SHORTCUTS':
      if (!isExtensionPage(sender)) return false;
      chrome.tabs.create({ url: 'chrome://extensions/shortcuts' });
      return false;

    default:
      return false;
  }
});
