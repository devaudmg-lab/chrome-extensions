/**
 * Blur Remover & DOM Modifier - Popup controller
 */

(function () {
  'use strict';

  const Storage = window.BlurRemoverStorage;
  const UI = window.BlurRemoverUI;
  const { t } = UI;

  const $ = (id) => document.getElementById(id);

  const els = {
    brandMark: $('brandMark'),
    versionTag: $('versionTag'),
    themeToggle: $('themeToggle'),
    masterToggle: $('masterToggle'),
    masterLabel: $('masterLabel'),
    site: document.querySelector('.site'),
    siteHost: $('siteHost'),
    siteSub: $('siteSub'),
    siteActiveToggle: $('siteActiveToggle'),
    siteActiveLabel: $('siteActiveLabel'),
    pauseTimedBtn: $('pauseTimedBtn'),
    rulesFoot: $('rulesFoot'),
    exportSiteRulesBtn: $('exportSiteRulesBtn'),
    errorBanner: $('errorBanner'),
    pickBtn: $('pickBtn'),
    readerBtn: $('readerBtn'),
    instantBtn: $('instantBtn'),
    instantState: $('instantState'),
    statBlurs: $('statBlurs'),
    statOverlays: $('statOverlays'),
    statScrolls: $('statScrolls'),
    statsSite: $('statsSite'),
    presetList: $('presetList'),
    presetCount: $('presetCount'),
    darkStatus: $('darkStatus'),
    darkModeSelect: $('darkModeSelect'),
    darkSiteSelect: $('darkSiteSelect'),
    darkAutomation: $('darkAutomation'),
    scheduleRow: $('scheduleRow'),
    darkStart: $('darkStart'),
    darkEnd: $('darkEnd'),
    darkDimImages: $('darkDimImages'),
    darkPageStatus: $('darkPageStatus'),
    ruleCount: $('ruleCount'),
    ruleSearch: $('ruleSearch'),
    ruleFilter: $('ruleFilter'),
    addRuleBtn: $('addRuleBtn'),
    ruleList: $('ruleList'),
    autoReaderToggle: $('autoReaderToggle'),
    syncStatus: $('syncStatus'),
    openOptionsBtn: $('openOptionsBtn'),
    shortcutsBtn: $('shortcutsBtn'),
    ruleDialog: $('ruleDialog'),
    ruleForm: $('ruleForm'),
    ruleDialogTitle: $('ruleDialogTitle'),
    ruleDialogClose: $('ruleDialogClose'),
    ruleId: $('ruleId'),
    ruleName: $('ruleName'),
    ruleNameHint: $('ruleNameHint'),
    ruleSelector: $('ruleSelector'),
    ruleSelectorHint: $('ruleSelectorHint'),
    ruleAction: $('ruleAction'),
    ruleScope: $('ruleScope'),
    ruleDomainField: $('ruleDomainField'),
    ruleDomainLabel: $('ruleDomainLabel'),
    ruleDomain: $('ruleDomain'),
    ruleDomainHint: $('ruleDomainHint'),
    ruleCssField: $('ruleCssField'),
    ruleCss: $('ruleCss'),
    ruleCssHint: $('ruleCssHint'),
    ruleWarnings: $('ruleWarnings'),
    ruleCancel: $('ruleCancel')
  };

  const SLIDERS = ['brightness', 'contrast', 'sepia', 'grayscale'];

  let settings = null;
  let tab = { id: null, url: '', host: '', path: '' };
  let injectable = false;
  let pageInfo = null;
  let formTouched = false;

  // ---------------------------------------------------------------------------
  // Data
  // ---------------------------------------------------------------------------

  function queryActiveTab() {
    return new Promise((resolve) => {
      if (typeof chrome === 'undefined' || !chrome.tabs) {
        resolve(null);
        return;
      }
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => resolve(tabs && tabs[0]));
    });
  }

  function fetchPageInfo() {
    return new Promise((resolve) => {
      if (!injectable || !tab.id) {
        resolve(null);
        return;
      }
      try {
        chrome.tabs.sendMessage(tab.id, { action: 'GET_PAGE_INFO' }, { frameId: 0 }, (res) => {
          resolve(chrome.runtime.lastError ? null : res || null);
        });
      } catch (e) {
        resolve(null);
      }
    });
  }

  async function refreshPageInfo() {
    pageInfo = await fetchPageInfo();
    renderSite();
    renderActions();
    renderDarkStatus();
    renderRules();
  }
  const refreshPageInfoSoon = UI.debounce(refreshPageInfo, 400);

  // ---------------------------------------------------------------------------
  // Rendering
  // ---------------------------------------------------------------------------

  function showError(message, kind) {
    if (!message) {
      els.errorBanner.classList.add('hidden');
      return;
    }
    els.errorBanner.textContent = message;
    els.errorBanner.classList.toggle('info', kind === 'info');
    els.errorBanner.classList.remove('hidden');
  }

  function isPaused() {
    return !!(settings && tab.host && Storage.isSitePaused(settings, tab.host));
  }

  function renderHeader() {
    UI.applyTheme(settings.theme);
    // eslint-disable-next-line no-unsanitized/property -- audited: static markup / escaped or sanitized values only
    els.themeToggle.innerHTML = settings.theme === 'light' ? UI.ICONS.moon : UI.ICONS.sun;
    els.themeToggle.title = settings.theme === 'light' ? t('useDarkTheme', 'Use dark theme') : t('useLightTheme', 'Use light theme');
    els.masterToggle.checked = settings.enabled;
    els.masterLabel.textContent = settings.enabled ? t('masterOn', 'On') : t('masterOff', 'Off');
    document.body.classList.toggle('is-off', !settings.enabled);
  }

  function renderSite() {
    if (!injectable) {
      els.siteHost.textContent = tab.host || t('browserPage', 'Browser page');
      els.siteSub.textContent = t('notInjectable', 'Extensions can\'t change this page. Open a website to use Blur Remover.');
      els.siteActiveToggle.disabled = true;
      els.siteActiveToggle.checked = false;
      els.site.classList.remove('paused');
      els.pauseTimedBtn.classList.add('hidden');
      return;
    }
    els.siteHost.textContent = tab.host.replace(/^www\./, '');
    els.siteHost.title = tab.url;
    const paused = isPaused();
    els.siteActiveToggle.disabled = !settings.enabled;
    els.siteActiveToggle.checked = !paused;
    els.siteActiveLabel.textContent = paused ? t('pausedHere', 'Paused here') : t('activeHere', 'Active here');
    els.site.classList.toggle('paused', paused || !settings.enabled);

    const until = Storage.getPausedUntil(settings, tab.host);
    els.pauseTimedBtn.classList.toggle('hidden', !settings.enabled);
    els.pauseTimedBtn.textContent = paused ? t('resumeNow', 'Resume now') : t('pauseTimed', 'Pause for 30 min');

    let sub;
    if (!settings.enabled) sub = t('subMasterOff', 'Blur Remover is switched off everywhere.');
    else if (until) sub = t('subPausedUntil', 'Paused until $1. It switches back on by itself.', [formatTime(until)]);
    else if (paused) sub = t('subPaused', 'Paused on this site. Nothing is changed here.');
    else if (!pageInfo) sub = t('subReload', 'Reload the page to apply your rules here.');
    else if (pageInfo.matchCount === 1) sub = t('subOneMatch', '1 rule is changing this page.');
    else if (pageInfo.matchCount > 1) sub = t('subMatches', '$1 rules are changing this page.', [pageInfo.matchCount]);
    else sub = t('subNoMatch', 'No rules match this page. Presets still apply.');
    els.siteSub.textContent = sub;
  }

  function formatTime(ts) {
    return new Date(ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  }

  function siteRulePack() {
    return Storage.buildSiteRulePack(settings, tab.host);
  }

  function renderActions() {
    [els.pickBtn, els.readerBtn, els.instantBtn].forEach((b) => { b.disabled = !injectable; });
    els.instantBtn.disabled = !injectable || !settings.enabled || isPaused();
    const on = !!(pageInfo && pageInfo.instantUnblur);
    els.instantBtn.setAttribute('aria-pressed', String(on));
    els.instantState.textContent = on ? t('stateOn', 'On') : t('stateOff', 'Off');
  }

  function renderStats() {
    const s = settings.stats;
    els.statBlurs.textContent = UI.formatNumber(s.totalBlursStripped);
    els.statOverlays.textContent = UI.formatNumber(s.totalOverlaysErased);
    els.statScrolls.textContent = UI.formatNumber(s.totalScrollsUnlocked);
    const host = Storage.normalizeHost(tab.host);
    const site = host && s.sites ? s.sites[host] : null;
    if (site && (site.blurs || site.overlays || site.scrolls)) {
      els.statsSite.textContent = t('statsSite', 'On $1: $2 blurs, $3 overlays, $4 scroll locks.', [host, site.blurs || 0, site.overlays || 0, site.scrolls || 0]);
    } else if (!s.totalBlursStripped && !s.totalOverlaysErased && !s.totalScrollsUnlocked) {
      els.statsSite.textContent = t('statsEmpty', 'Counts start as soon as something is unblurred.');
    } else {
      els.statsSite.textContent = host ? t('statsSiteNone', 'Nothing removed on $1 yet.', [host]) : '';
    }
  }

  function buildPresetList() {
    els.presetList.innerHTML = '';
    Storage.PRESET_KEYS.forEach((key) => {
      const meta = UI.PRESETS[key];
      if (!meta) return;
      const li = document.createElement('li');
      li.className = 'preset';
      const inputId = `preset-${key}`;
      const descId = `preset-desc-${key}`;

      const label = document.createElement('label');
      label.className = 'preset-title';
      label.setAttribute('for', inputId);
      label.textContent = meta.title();

      const info = document.createElement('button');
      info.type = 'button';
      info.className = 'icon-btn';
      // eslint-disable-next-line no-unsanitized/property -- audited: static markup / escaped or sanitized values only
      info.innerHTML = UI.ICONS.info;
      info.title = meta.desc();
      info.setAttribute('aria-label', t('aboutPreset', 'About $1', [meta.title()]));
      info.setAttribute('aria-expanded', 'false');
      info.setAttribute('aria-controls', descId);

      const sw = document.createElement('span');
      sw.className = 'switch';
      const input = document.createElement('input');
      input.type = 'checkbox';
      input.id = inputId;
      input.setAttribute('role', 'switch');
      input.setAttribute('aria-describedby', descId);
      input.dataset.preset = key;
      const track = document.createElement('span');
      track.className = 'track';
      sw.append(input, track);

      const desc = document.createElement('p');
      desc.className = 'preset-desc hidden';
      desc.id = descId;
      desc.textContent = meta.desc();

      info.addEventListener('click', () => {
        const open = desc.classList.toggle('hidden') === false;
        info.setAttribute('aria-expanded', String(open));
      });
      input.addEventListener('change', () => togglePreset(key, input.checked));

      li.append(label, info, sw, desc);
      els.presetList.appendChild(li);
    });
  }

  function renderPresets() {
    let on = 0;
    els.presetList.querySelectorAll('input[data-preset]').forEach((input) => {
      input.checked = !!settings.presetsEnabled[input.dataset.preset];
      input.disabled = !settings.enabled;
      if (input.checked) on++;
    });
    els.presetCount.textContent = t('presetsOn', '$1 on', [on]);
  }

  function renderDark() {
    const dm = settings.darkMode;
    els.darkModeSelect.value = dm.mode;
    els.darkAutomation.value = dm.automation;
    els.scheduleRow.classList.toggle('hidden', dm.automation !== 'schedule');
    if (document.activeElement !== els.darkStart) els.darkStart.value = dm.scheduleStart;
    if (document.activeElement !== els.darkEnd) els.darkEnd.value = dm.scheduleEnd;
    els.darkDimImages.checked = dm.dimImages;
    SLIDERS.forEach((key) => {
      const input = $(`dark${cap(key)}`);
      if (document.activeElement !== input) input.value = dm[key];
      $(`dark${cap(key)}Out`).textContent = `${input.value}%`;
    });
    const host = Storage.normalizeHost(tab.host);
    const override = host ? Object.entries(settings.sites.darkMode).find(([h]) => Storage.normalizeHost(h) === host) : null;
    els.darkSiteSelect.value = override ? override[1] : '';
    els.darkSiteSelect.disabled = !injectable;
    renderDarkStatus();
  }

  function renderDarkStatus() {
    const configured = injectable && tab.host ? Storage.getEffectiveDarkMode(settings, tab.host) : (settings.presetsEnabled.forceDarkMode ? settings.darkMode.mode : null);
    const status = pageInfo && pageInfo.dark ? pageInfo.dark : null;
    let pill = t('darkOff', 'Off');
    let pillClass = 'pill';
    let hint = '';

    if (status && status.active) {
      pill = status.mode === 'dynamic' ? t('darkOnDynamic', 'On, dynamic') : t('darkOnFilter', 'On, filter');
      pillClass = 'pill accent';
    } else if (status && status.skippedReason === 'already-dark') {
      pill = t('darkSkipped', 'Skipped');
      pillClass = 'pill warn';
      hint = t('darkSkippedHint', 'Skipped here: this page is already dark.');
    } else if (configured) {
      pill = t('darkScheduled', 'Waiting');
      if (settings.darkMode.automation === 'system') hint = t('darkWaitSystem', 'Turns on when your system theme is dark.');
      else if (settings.darkMode.automation === 'schedule') hint = t('darkWaitSchedule', 'Turns on between $1 and $2.', [settings.darkMode.scheduleStart, settings.darkMode.scheduleEnd]);
      else if (!pageInfo && injectable) hint = t('subReload', 'Reload the page to apply your rules here.');
      else pill = t('darkOnFilter', 'On, filter');
    }
    els.darkStatus.className = pillClass;
    els.darkStatus.textContent = pill;
    els.darkPageStatus.textContent = hint;
  }

  function ruleAppliesHere(rule) {
    if (!tab.host) return rule.siteScope === 'global';
    if (rule.siteScope === 'global') return true;
    if (rule.siteScope === 'exact') return Storage.matchExactPattern(rule.domainPattern, tab.url);
    return Storage.matchDomainPattern(rule.domainPattern, tab.host);
  }

  function renderRules() {
    if (!settings) return;
    const all = Storage.getAllRules(settings);
    const q = els.ruleSearch.value.trim().toLowerCase();
    const filter = els.ruleFilter.value;
    const matched = new Set(pageInfo && pageInfo.matchedRuleIds ? pageInfo.matchedRuleIds : []);

    const list = all.filter((rule) => {
      if (filter === 'this-site' && !ruleAppliesHere(rule)) return false;
      if (filter === 'global' && rule.siteScope !== 'global') return false;
      if (!q) return true;
      return [rule.name, rule.selector, rule.domainPattern, rule.packName].some((v) => String(v || '').toLowerCase().includes(q));
    }).sort((a, b) => (matched.has(b.id) - matched.has(a.id)) || (!!a.packId - !!b.packId));

    els.ruleCount.textContent = String(list.length);
    els.ruleList.innerHTML = '';
    els.rulesFoot.classList.toggle('hidden', !injectable || !siteRulePack().rules.length);

    if (!list.length) {
      const li = document.createElement('li');
      li.className = 'empty';
      const p = document.createElement('div');
      p.textContent = q ? t('rulesNoSearch', 'No rules match "$1".', [q])
        : filter === 'this-site' ? t('rulesNoneHere', 'No rules for this site yet. Pick the element that blocks the page, or add a rule by selector.')
          : t('rulesNone', 'No rules yet.');
      li.appendChild(p);
      if (!q && injectable) {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'btn btn-sm';
        btn.textContent = t('actionPick', 'Pick element');
        btn.addEventListener('click', () => runAction('START_PICKER', true));
        li.appendChild(btn);
      }
      els.ruleList.appendChild(li);
      return;
    }

    list.forEach((rule) => els.ruleList.appendChild(buildRuleCard(rule, matched.has(rule.id))));
  }

  function buildRuleCard(rule, isMatched) {
    const li = document.createElement('li');
    li.className = 'rule';
    li.classList.toggle('matched', isMatched);
    li.classList.toggle('disabled', !rule.enabled);

    const name = document.createElement('span');
    name.className = 'rule-name';
    name.textContent = rule.name || t('unnamedRule', 'Unnamed rule');
    name.title = rule.name || '';

    const controls = document.createElement('div');
    controls.className = 'rule-controls';

    if (!rule.packId) {
      const edit = iconButton(UI.ICONS.edit, t('editRuleNamed', 'Edit $1', [rule.name]));
      edit.addEventListener('click', () => openRuleDialog(rule));
      const del = iconButton(UI.ICONS.trash, t('deleteRuleNamed', 'Delete $1', [rule.name]));
      del.addEventListener('click', () => deleteRule(rule));
      const sw = document.createElement('label');
      sw.className = 'switch';
      const input = document.createElement('input');
      input.type = 'checkbox';
      input.checked = rule.enabled;
      input.setAttribute('role', 'switch');
      input.setAttribute('aria-label', t('toggleRuleNamed', 'Enable $1', [rule.name]));
      input.addEventListener('change', () => {
        Storage.updateRule(rule.id, { enabled: input.checked }).catch((e) => UI.toast(e.message, { type: 'error' }));
      });
      const track = document.createElement('span');
      track.className = 'track';
      sw.append(input, track);
      controls.append(edit, del, sw);
    }

    const selector = document.createElement('code');
    selector.className = 'rule-selector';
    selector.textContent = rule.selector;
    selector.title = rule.selector;

    const meta = document.createElement('div');
    meta.className = 'rule-meta';
    meta.appendChild(pill((UI.ACTION_LABELS[rule.actionType] || UI.ACTION_LABELS['remove-blur'])(), ''));
    meta.appendChild(pill(rule.siteScope === 'global' ? t('scopeEverySite', 'Every site') : rule.domainPattern, ''));
    if (rule.packId) meta.appendChild(pill(t('fromPack', 'Pack: $1', [rule.packName || '']), 'warn'));
    if (isMatched) meta.appendChild(pill(t('matchedHere', 'Active on this page'), 'accent'));

    li.append(name, controls, selector, meta);
    return li;
  }

  function pill(text, kind) {
    const s = document.createElement('span');
    s.className = `pill ${kind || ''}`;
    s.textContent = text;
    return s;
  }

  function iconButton(svg, label) {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'icon-btn';
    // eslint-disable-next-line no-unsanitized/property -- audited: static markup / escaped or sanitized values only
    b.innerHTML = svg;
    b.setAttribute('aria-label', label);
    b.title = label;
    return b;
  }

  function renderMore() {
    els.autoReaderToggle.checked = !!(tab.host && Storage.isAutoReaderSite(settings, tab.host));
    els.autoReaderToggle.disabled = !injectable;
  }

  async function renderSync() {
    try {
      const usage = await Storage.getStorageUsage();
      const pct = usage.syncItemQuota ? Math.round((usage.coreBytes / usage.syncItemQuota) * 100) : 0;
      const warn = !usage.syncOk || pct > 80;
      els.syncStatus.classList.toggle('warn', warn);
      els.syncStatus.textContent = !usage.syncOk
        ? t('syncFailed', 'Settings sync is unavailable. Changes are saved on this device only.')
        : pct > 80
          ? t('syncNearQuota', 'Synced settings are at $1% of Chrome\'s limit.', [pct])
          : t('syncOk', 'Settings sync across your Chrome profile. Rules stay on this device; use Export to move them.');
    } catch (e) {
      els.syncStatus.textContent = '';
    }
  }

  function renderAll() {
    renderHeader();
    renderSite();
    renderActions();
    renderStats();
    renderPresets();
    renderDark();
    renderRules();
    renderMore();
  }

  function cap(s) {
    return s.charAt(0).toUpperCase() + s.slice(1);
  }

  // ---------------------------------------------------------------------------
  // Actions
  // ---------------------------------------------------------------------------

  async function runAction(action, closeAfter) {
    showError('');
    const res = await UI.sendMessage({ type: 'RUN_ACTION', action, tabId: tab.id });
    if (!res || res.ok === false) {
      showError((res && res.error) || t('actionFailed', 'That didn\'t work on this page. Reload the page and try again.'));
      return null;
    }
    if (closeAfter) window.close();
    return res.result;
  }

  async function togglePreset(key, enabled) {
    try {
      await Storage.togglePreset(key, enabled);
    } catch (e) {
      UI.toast(e.message, { type: 'error' });
    }
  }

  async function deleteRule(rule) {
    try {
      const removed = await Storage.deleteRule(rule.id);
      UI.toast(t('ruleDeleted', 'Deleted "$1"', [rule.name]), {
        actionLabel: t('undo', 'Undo'),
        onAction: () => Storage.restoreRule(removed || rule).then(() => UI.toast(t('ruleRestored', 'Rule restored')))
      });
    } catch (e) {
      UI.toast(e.message, { type: 'error' });
    }
  }

  const saveDark = UI.debounce((patch) => {
    Storage.updateDarkMode(patch).catch((e) => UI.toast(e.message, { type: 'error' }));
  }, 250);

  // ---------------------------------------------------------------------------
  // Rule dialog
  // ---------------------------------------------------------------------------

  function fillActionOptions() {
    els.ruleAction.innerHTML = '';
    Storage.ACTION_TYPES.forEach((type) => {
      const o = document.createElement('option');
      o.value = type;
      o.textContent = UI.ACTION_LABELS[type]();
      els.ruleAction.appendChild(o);
    });
  }

  function defaultPatternFor(scope) {
    if (scope === 'global') return '*';
    if (scope === 'exact') return tab.host ? Storage.normalizeUrlForExact(tab.url) : '';
    return tab.host ? Storage.normalizeHost(tab.host) : '';
  }

  function updateScopeField() {
    const scope = els.ruleScope.value;
    els.ruleDomainField.classList.toggle('hidden', scope === 'global');
    els.ruleDomainLabel.textContent = scope === 'exact' ? t('rulePageAddress', 'Page address') : t('ruleDomain', 'Domain');
    els.ruleDomainHint.className = 'hint';
    els.ruleDomainHint.textContent = scope === 'exact'
      ? t('exactHint', 'End with * to include every page below it, for example example.com/blog/*')
      : t('domainHint', 'Subdomains are included automatically.');
  }

  function openRuleDialog(rule) {
    formTouched = false;
    els.ruleDialogTitle.textContent = rule ? t('editRuleTitle', 'Edit rule') : t('addRuleTitle', 'Add rule');
    els.ruleId.value = rule ? rule.id : '';
    els.ruleName.value = rule ? rule.name : '';
    els.ruleSelector.value = rule ? rule.selector : '';
    els.ruleAction.value = rule ? rule.actionType : 'remove-blur';
    els.ruleScope.value = rule ? rule.siteScope : (injectable ? 'domain' : 'global');
    els.ruleDomain.value = rule ? (rule.domainPattern === '*' ? '' : rule.domainPattern) : defaultPatternFor(els.ruleScope.value);
    els.ruleCss.value = rule ? rule.customCss || '' : '';
    els.ruleCssField.classList.toggle('hidden', els.ruleAction.value !== 'custom-css');
    updateScopeField();
    [els.ruleNameHint, els.ruleCssHint, els.ruleWarnings].forEach((h) => { h.textContent = ''; });
    els.ruleSelectorHint.textContent = '';
    els.ruleSelectorHint.className = 'hint';
    [els.ruleName, els.ruleSelector, els.ruleDomain, els.ruleCss].forEach((i) => i.classList.remove('invalid'));
    els.ruleDialog.showModal();
    els.ruleName.focus();
    if (rule) validateForm();
  }

  function readDraft() {
    const scope = els.ruleScope.value;
    return {
      id: els.ruleId.value || '__draft__',
      name: els.ruleName.value.trim(),
      selector: els.ruleSelector.value.trim(),
      actionType: els.ruleAction.value,
      siteScope: scope,
      domainPattern: scope === 'global' ? '*' : els.ruleDomain.value.trim(),
      customCss: els.ruleAction.value === 'custom-css' ? els.ruleCss.value.trim() : ''
    };
  }

  let validateSeq = 0;
  async function validateForm(showAll) {
    const draft = readDraft();
    const { errors, warnings } = UI.validateRule(draft, Storage.getAllRules(settings));
    const show = showAll || formTouched;

    const setFieldError = (input, hint, msg) => {
      input.classList.toggle('invalid', !!(msg && show));
      if (hint) {
        hint.className = 'hint error';
        hint.textContent = show ? msg || '' : '';
      }
    };
    setFieldError(els.ruleName, els.ruleNameHint, errors.name);
    setFieldError(els.ruleCss, els.ruleCssHint, errors.customCss);
    els.ruleDomain.classList.toggle('invalid', !!(errors.domainPattern && show));
    if (errors.domainPattern && show) {
      els.ruleDomainHint.className = 'hint error';
      els.ruleDomainHint.textContent = errors.domainPattern;
    } else {
      updateScopeField();
    }

    els.ruleSelector.classList.toggle('invalid', !!(errors.selector && (show || draft.selector)));
    if (errors.selector) {
      els.ruleSelectorHint.className = 'hint error';
      els.ruleSelectorHint.textContent = (show || draft.selector) ? errors.selector : '';
    } else if (draft.selector && injectable) {
      const seq = ++validateSeq;
      const res = await UI.testSelectorOnTab(tab.id, draft.selector);
      if (seq !== validateSeq) return errors;
      if (!res) {
        els.ruleSelectorHint.className = 'hint';
        els.ruleSelectorHint.textContent = t('selectorValidNoTab', 'Valid selector. Reload the page to count matches.');
      } else if (res.count > 0) {
        els.ruleSelectorHint.className = 'hint ok';
        els.ruleSelectorHint.textContent = res.count === 1
          ? t('selectorMatchesOne', 'Matches 1 element on this page.')
          : t('selectorMatchesMany', 'Matches $1 elements on this page.', [res.count]);
      } else {
        els.ruleSelectorHint.className = 'hint warn';
        els.ruleSelectorHint.textContent = t('selectorMatchesNone', 'Valid, but matches nothing on this page right now.');
      }
    } else {
      els.ruleSelectorHint.className = 'hint';
      els.ruleSelectorHint.textContent = draft.selector ? t('selectorValid', 'Valid selector.') : '';
    }

    els.ruleWarnings.textContent = warnings.join(' ');
    return errors;
  }
  const validateSoon = UI.debounce(() => validateForm(), 250);

  async function submitRule(e) {
    e.preventDefault();
    formTouched = true;
    const errors = await validateForm(true);
    const first = ['name', 'selector', 'domainPattern', 'customCss'].find((k) => errors[k]);
    if (first) {
      ({ name: els.ruleName, selector: els.ruleSelector, domainPattern: els.ruleDomain, customCss: els.ruleCss })[first].focus();
      return;
    }
    const draft = readDraft();
    const id = els.ruleId.value;
    delete draft.id;
    try {
      if (id) {
        await Storage.updateRule(id, draft);
        UI.toast(t('ruleSaved', 'Rule saved'));
      } else {
        await Storage.addRule(draft);
        UI.toast(t('ruleAdded', 'Rule added'));
      }
      els.ruleDialog.close();
    } catch (err) {
      els.ruleWarnings.textContent = err.message;
    }
  }

  // ---------------------------------------------------------------------------
  // Events
  // ---------------------------------------------------------------------------

  function bindEvents() {
    els.themeToggle.addEventListener('click', () => {
      const next = settings.theme === 'light' ? 'dark' : 'light';
      settings.theme = next;
      renderHeader();
      Storage.setTheme(next).catch(() => {});
    });

    els.masterToggle.addEventListener('change', () => {
      Storage.toggleMaster(els.masterToggle.checked).catch((e) => UI.toast(e.message, { type: 'error' }));
    });

    els.siteActiveToggle.addEventListener('change', () => {
      Storage.setSitePaused(tab.host, !els.siteActiveToggle.checked)
        .then(() => UI.toast(els.siteActiveToggle.checked ? t('resumedOn', 'Resumed on $1', [tab.host]) : t('pausedOn', 'Paused on $1', [tab.host])))
        .catch((e) => UI.toast(e.message, { type: 'error' }));
    });

    els.pauseTimedBtn.addEventListener('click', () => {
      const write = isPaused()
        ? Storage.setSitePaused(tab.host, false).then(() => t('resumedOn', 'Resumed on $1', [tab.host]))
        : Storage.pauseSiteFor(tab.host, 30).then((until) => t('pausedUntilToast', 'Paused on $1 until $2', [tab.host, formatTime(until)]));
      write.then((msg) => UI.toast(msg)).catch((e) => UI.toast(e.message, { type: 'error' }));
    });

    els.exportSiteRulesBtn.addEventListener('click', () => {
      const pack = siteRulePack();
      if (!pack.rules.length) return;
      const host = Storage.normalizeHost(tab.host).replace(/[^a-z0-9.-]/gi, '_');
      UI.downloadJson(pack, `blur-remover-${host}-rules.json`);
      UI.toast(pack.rules.length === 1 ? t('exportedSiteRuleOne', 'Exported 1 rule') : t('exportedSiteRules', 'Exported $1 rules', [pack.rules.length]));
    });

    els.pickBtn.addEventListener('click', () => runAction('START_PICKER', true));
    els.readerBtn.addEventListener('click', () => runAction('TOGGLE_READER', true));
    els.instantBtn.addEventListener('click', async () => {
      const result = await runAction('TOGGLE_INSTANT_UNBLUR', false);
      if (result) {
        pageInfo = Object.assign({}, pageInfo || {}, { instantUnblur: !!result.on });
        renderActions();
        UI.toast(result.on ? t('instantOn', 'Instant unblur is on for this tab') : t('instantOff', 'Instant unblur is off for this tab'));
      }
    });

    els.darkModeSelect.addEventListener('change', () => saveDark({ mode: els.darkModeSelect.value }));
    els.darkAutomation.addEventListener('change', () => {
      els.scheduleRow.classList.toggle('hidden', els.darkAutomation.value !== 'schedule');
      saveDark({ automation: els.darkAutomation.value });
    });
    els.darkStart.addEventListener('change', () => saveDark({ scheduleStart: els.darkStart.value }));
    els.darkEnd.addEventListener('change', () => saveDark({ scheduleEnd: els.darkEnd.value }));
    els.darkDimImages.addEventListener('change', () => saveDark({ dimImages: els.darkDimImages.checked }));
    SLIDERS.forEach((key) => {
      const input = $(`dark${cap(key)}`);
      input.addEventListener('input', () => {
        $(`dark${cap(key)}Out`).textContent = `${input.value}%`;
        saveDark({ [key]: Number(input.value) });
      });
    });
    els.darkSiteSelect.addEventListener('change', () => {
      Storage.setSiteDarkMode(tab.host, els.darkSiteSelect.value || null).catch((e) => UI.toast(e.message, { type: 'error' }));
    });

    els.ruleSearch.addEventListener('input', renderRules);
    els.ruleFilter.addEventListener('change', renderRules);
    els.addRuleBtn.addEventListener('click', () => openRuleDialog(null));

    els.autoReaderToggle.addEventListener('change', () => {
      Storage.setAutoReader(tab.host, els.autoReaderToggle.checked).catch((e) => UI.toast(e.message, { type: 'error' }));
    });
    els.openOptionsBtn.addEventListener('click', () => chrome.runtime.openOptionsPage());
    els.shortcutsBtn.addEventListener('click', () => UI.sendMessage({ type: 'OPEN_SHORTCUTS' }));

    // eslint-disable-next-line no-unsanitized/property -- audited: static markup / escaped or sanitized values only
    els.ruleDialogClose.innerHTML = UI.ICONS.close;
    els.ruleDialogClose.addEventListener('click', () => els.ruleDialog.close());
    els.ruleCancel.addEventListener('click', () => els.ruleDialog.close());
    els.ruleForm.addEventListener('submit', submitRule);
    els.ruleAction.addEventListener('change', () => {
      els.ruleCssField.classList.toggle('hidden', els.ruleAction.value !== 'custom-css');
      validateSoon();
    });
    els.ruleScope.addEventListener('change', () => {
      els.ruleDomain.value = els.ruleScope.value === 'global' ? '' : defaultPatternFor(els.ruleScope.value);
      updateScopeField();
      validateSoon();
    });
    [els.ruleName, els.ruleSelector, els.ruleDomain, els.ruleCss].forEach((input) => {
      input.addEventListener('input', validateSoon);
      input.addEventListener('blur', () => { formTouched = formTouched || !!input.value; validateSoon(); });
    });

    if (chrome.storage && chrome.storage.onChanged) {
      chrome.storage.onChanged.addListener(async () => {
        settings = await Storage.getSettings();
        renderAll();
        renderSync();
        refreshPageInfoSoon();
      });
    }
  }

  // ---------------------------------------------------------------------------
  // Init
  // ---------------------------------------------------------------------------

  async function init() {
    // eslint-disable-next-line no-unsanitized/property -- audited: static markup / escaped or sanitized values only
    els.brandMark.innerHTML = UI.ICONS.lens;
    try {
      els.versionTag.textContent = `v${chrome.runtime.getManifest().version}`;
    } catch (e) {
      els.versionTag.textContent = '';
    }

    const activeTab = await queryActiveTab();
    if (activeTab && activeTab.url) {
      tab.id = activeTab.id;
      tab.url = activeTab.url;
      try {
        const u = new URL(activeTab.url);
        injectable = /^https?:$/.test(u.protocol);
        tab.host = injectable ? u.hostname : '';
        tab.path = u.pathname;
      } catch (e) {
        injectable = false;
      }
    }

    settings = await Storage.getSettings();
    fillActionOptions();
    buildPresetList();
    renderAll();
    bindEvents();
    renderSync();
    await refreshPageInfo();
  }

  document.addEventListener('DOMContentLoaded', init);
})();
