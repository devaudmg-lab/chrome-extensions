/**
 * Blur Remover & DOM Modifier - Onboarding page
 */

(function () {
  'use strict';

  const UI = window.BlurRemoverUI;
  const Storage = window.BlurRemoverStorage;
  const { t } = UI;
  const $ = (id) => document.getElementById(id);

  async function init() {
    // eslint-disable-next-line no-unsanitized/property -- audited: static markup / escaped or sanitized values only
    $('brandMark').innerHTML = UI.ICONS.lens;
    try {
      const settings = await Storage.getSettings();
      UI.applyTheme(settings.theme);
    } catch (e) {
      UI.applyTheme(window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark');
    }

    const demo = document.querySelector('.demo');
    const demoBtn = $('demoBtn');
    demoBtn.addEventListener('click', () => {
      const clear = demo.classList.toggle('clear');
      demoBtn.setAttribute('aria-pressed', String(clear));
      demoBtn.textContent = clear ? t('demoBlurAgain', 'Blur it again') : t('demoUnblur', 'Unblur this article');
    });

    $('shortcutsBtn').addEventListener('click', () => UI.sendMessage({ type: 'OPEN_SHORTCUTS' }));
    $('optionsBtn').addEventListener('click', () => chrome.runtime.openOptionsPage());
    $('startBtn').addEventListener('click', () => window.close());
  }

  document.addEventListener('DOMContentLoaded', init);
})();
