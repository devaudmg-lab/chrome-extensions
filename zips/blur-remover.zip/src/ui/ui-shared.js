/**
 * Blur Remover - shared UI helpers for popup, options and onboarding pages.
 * Preset metadata, toasts, icons, rule validation & duplicate detection.
 */

(function (global) {
  'use strict';

  if (global.BlurRemoverUI) return;

  const t = (key, fallback, subs) => (global.BlurRemoverI18n ? global.BlurRemoverI18n.t(key, fallback, subs) : fallback);

  const PRESETS = {
    magicAutoUnblur: {
      title: () => t('presetMagicTitle', 'Magic auto-unblur'),
      desc: () => t('presetMagicDesc', 'Finds elements that are actually blurred (large blurred areas, frosted overlays, blurred text) and sharpens them. Leaves normal design filters alone.')
    },
    globalUnblur: {
      title: () => t('presetGlobalTitle', 'Unblur everything'),
      desc: () => t('presetGlobalDesc', 'Removes every blur filter on every page, including small decorative ones. Use when magic unblur misses something.')
    },
    unblurText: {
      title: () => t('presetTextTitle', 'Unblur text'),
      desc: () => t('presetTextDesc', 'Reveals text hidden with transparent colour and a blurred shadow, a common paywall trick.')
    },
    overlayEraser: {
      title: () => t('presetOverlayTitle', 'Erase overlays'),
      desc: () => t('presetOverlayDesc', 'Hides empty full-screen scrims and modal backdrops that dim or block the page.')
    },
    scrollUnlock: {
      title: () => t('presetScrollTitle', 'Unlock scrolling'),
      desc: () => t('presetScrollDesc', 'Restores scrolling when a site freezes the page behind a popup.')
    },
    enableDisabledClicks: {
      title: () => t('presetClicksTitle', 'Re-enable pagination'),
      desc: () => t('presetClicksDesc', 'Makes disabled "next page" links and pagination buttons clickable again. Form buttons are never touched.')
    },
    cookieBannerRemover: {
      title: () => t('presetCookieTitle', 'Hide cookie & newsletter popups'),
      desc: () => t('presetCookieDesc', 'Hides common cookie-consent banners and newsletter sign-up popups, and unlocks scrolling they block.')
    },
    unlockCopy: {
      title: () => t('presetCopyTitle', 'Allow copy & right-click'),
      desc: () => t('presetCopyDesc', 'Re-enables text selection, copying and the right-click menu on sites that block them.')
    },
    forceDarkMode: {
      title: () => t('presetDarkTitle', 'Dark mode'),
      desc: () => t('presetDarkDesc', 'Turns light pages dark. Filter mode inverts the page and keeps photos natural; Dynamic mode recolours the site\'s own styles.')
    }
  };

  const ACTION_LABELS = {
    'remove-blur': () => t('actionRemoveBlur', 'Remove blur'),
    hide: () => t('actionHide', 'Hide'),
    'visibility-hidden': () => t('actionInvisible', 'Make invisible'),
    'unlock-scroll': () => t('actionUnlockScroll', 'Unlock scroll'),
    'enable-pointer': () => t('actionEnableClick', 'Enable clicks'),
    'custom-css': () => t('actionCustomCss', 'Custom CSS')
  };

  const ICONS = {
    edit: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="M10.5 2.5l3 3L6 13H3v-3z"/></svg>',
    trash: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="M3 4.5h10M6.5 4.5V3h3v1.5M4.5 4.5l.7 8.5h5.6l.7-8.5"/></svg>',
    info: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><circle cx="8" cy="8" r="6"/><path d="M8 7.2V11M8 5v.2"/></svg>',
    sun: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><circle cx="8" cy="8" r="3"/><path d="M8 1.5v1.5M8 13v1.5M1.5 8H3M13 8h1.5M3.4 3.4l1 1M11.6 11.6l1 1M3.4 12.6l1-1M11.6 4.4l1-1"/></svg>',
    moon: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="M13 9.5A5.5 5.5 0 016.5 3a5.5 5.5 0 106.5 6.5z"/></svg>',
    close: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M4 4l8 8M12 4l-8 8"/></svg>',
    refresh: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="M13 8a5 5 0 11-1.5-3.6M13 2.5V5h-2.5"/></svg>',
    lens: '<svg viewBox="0 0 32 32" aria-hidden="true"><circle cx="16" cy="16" r="13" fill="none" stroke="currentColor" stroke-width="2.4"/><circle cx="16" cy="16" r="6.5" fill="currentColor" opacity=".9"/><circle cx="13.6" cy="13.6" r="2" fill="var(--bg)"/></svg>'
  };

  // ---------------------------------------------------------------------------
  // Toasts
  // ---------------------------------------------------------------------------

  let region = null;
  function toast(text, options = {}) {
    if (!region) {
      region = document.createElement('div');
      region.className = 'toast-region';
      region.setAttribute('role', 'status');
      region.setAttribute('aria-live', 'polite');
      document.body.appendChild(region);
    }
    region.innerHTML = '';
    const el = document.createElement('div');
    el.className = `toast ${options.type || ''}`;
    const span = document.createElement('span');
    span.textContent = text;
    el.appendChild(span);
    if (options.actionLabel && typeof options.onAction === 'function') {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.textContent = options.actionLabel;
      btn.addEventListener('click', () => {
        el.remove();
        options.onAction();
      });
      el.appendChild(btn);
    }
    region.appendChild(el);
    setTimeout(() => el.remove(), options.duration || (options.actionLabel ? 7000 : 3000));
  }

  // ---------------------------------------------------------------------------
  // Rule helpers
  // ---------------------------------------------------------------------------

  function normalizeSelector(sel) {
    const Dom = global.BlurRemoverDom;
    const parts = Dom ? Dom.splitSelectorList(sel) : String(sel || '').split(',');
    return parts
      .map((part) => part.replace(/\s+/g, ' ').replace(/\s*([>+~])\s*/g, '$1').trim().toLowerCase())
      .filter(Boolean)
      .sort()
      .join(',');
  }

  function scopesOverlap(a, b) {
    if (a.siteScope === 'global' || b.siteScope === 'global') return true;
    const da = String(a.domainPattern || '').toLowerCase().replace(/^www\./, '');
    const db = String(b.domainPattern || '').toLowerCase().replace(/^www\./, '');
    return da === db || da.endsWith('.' + db) || db.endsWith('.' + da) || da.startsWith(db) || db.startsWith(da);
  }

  /** Rules that would do the same thing as `rule` (same selector + action, overlapping scope). */
  function findDuplicates(rule, rules) {
    const sel = normalizeSelector(rule.selector);
    return (rules || []).filter((r) => r.id !== rule.id
      && normalizeSelector(r.selector) === sel
      && r.actionType === rule.actionType
      && scopesOverlap(r, rule));
  }

  /** Returns { errors: {field: msg}, warnings: [] } for a rule draft. */
  function validateRule(draft, existingRules) {
    const Dom = global.BlurRemoverDom;
    const errors = {};
    const warnings = [];
    if (!draft.name || !draft.name.trim()) errors.name = t('errNameRequired', 'Give the rule a name.');
    if (!draft.selector || !draft.selector.trim()) {
      errors.selector = t('errSelectorRequired', 'Enter a CSS selector, for example .paywall-overlay');
    } else if (Dom && !Dom.isValidSelector(draft.selector.trim())) {
      errors.selector = t('errSelectorInvalid', 'This is not a valid CSS selector. Check brackets, quotes and commas.');
    }
    if (draft.actionType === 'custom-css') {
      if (!draft.customCss || !draft.customCss.trim()) {
        errors.customCss = t('errCssRequired', 'Add at least one CSS declaration, for example opacity: 1 !important;');
      } else if (Dom && !Dom.sanitizeDeclarations(draft.customCss)) {
        errors.customCss = t('errCssInvalid', 'Only property: value; declarations are allowed. Remove braces, @import and selectors.');
      }
    }
    if (draft.siteScope !== 'global' && (!draft.domainPattern || draft.domainPattern.trim() === '*')) {
      errors.domainPattern = draft.siteScope === 'exact'
        ? t('errExactRequired', 'Enter a page address, for example example.com/articles/*')
        : t('errDomainRequired', 'Enter a domain, for example example.com');
    }
    if (draft.selector && /^(\*|html|body|div|span|p|a)$/i.test(draft.selector.trim()) && draft.actionType === 'hide') {
      warnings.push(t('warnBroadHide', 'This selector hides a very common element and may blank the page.'));
    }
    const dupes = findDuplicates(draft, existingRules);
    if (dupes.length) {
      warnings.push(t('warnDuplicate', 'A rule with the same selector and action already applies here: "$1".', [dupes[0].name]));
    }
    return { errors, warnings };
  }

  function testSelectorOnTab(tabId, selector) {
    return new Promise((resolve) => {
      if (!tabId || typeof chrome === 'undefined' || !chrome.tabs || !chrome.tabs.sendMessage) {
        resolve(null);
        return;
      }
      try {
        chrome.tabs.sendMessage(tabId, { action: 'TEST_SELECTOR', selector }, { frameId: 0 }, (res) => {
          if (chrome.runtime.lastError) resolve(null);
          else resolve(res || null);
        });
      } catch (e) {
        resolve(null);
      }
    });
  }

  function sendMessage(message) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(message, (res) => {
          if (chrome.runtime.lastError) resolve({ ok: false, error: chrome.runtime.lastError.message });
          else resolve(res === undefined ? { ok: true } : res);
        });
      } catch (e) {
        resolve({ ok: false, error: e.message });
      }
    });
  }

  function formatNumber(n) {
    return Number(n || 0).toLocaleString();
  }

  function timeAgo(ts) {
    if (!ts) return t('never', 'never');
    const s = Math.round((Date.now() - ts) / 1000);
    if (s < 60) return t('justNow', 'just now');
    if (s < 3600) return t('minutesAgo', '$1 min ago', [Math.round(s / 60)]);
    if (s < 86400) return t('hoursAgo', '$1 h ago', [Math.round(s / 3600)]);
    return t('daysAgo', '$1 d ago', [Math.round(s / 86400)]);
  }

  function debounce(fn, ms) {
    let timer = null;
    return (...args) => {
      clearTimeout(timer);
      timer = setTimeout(() => fn(...args), ms);
    };
  }

  function downloadJson(data, filename) {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme === 'light' ? 'light' : 'dark');
  }

  global.BlurRemoverUI = {
    t,
    PRESETS,
    ACTION_LABELS,
    ICONS,
    toast,
    findDuplicates,
    validateRule,
    testSelectorOnTab,
    sendMessage,
    formatNumber,
    timeAgo,
    debounce,
    downloadJson,
    applyTheme
  };
})(typeof self !== 'undefined' ? self : this);
