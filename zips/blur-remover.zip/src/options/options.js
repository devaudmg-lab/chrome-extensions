/**
 * Blur Remover & DOM Modifier - Options page controller
 */

(function () {
  'use strict';

  const Storage = window.BlurRemoverStorage;
  const UI = window.BlurRemoverUI;
  const { t } = UI;
  const $ = (id) => document.getElementById(id);

  const SLIDERS = ['brightness', 'contrast', 'sepia', 'grayscale'];
  const selected = new Set();
  let settings = null;
  let formTouched = false;

  // ---------------------------------------------------------------------------
  // Helpers
  // ---------------------------------------------------------------------------

  function el(tag, attrs = {}, children = []) {
    const node = document.createElement(tag);
    Object.entries(attrs).forEach(([k, v]) => {
      if (v === undefined || v === null || v === false) return;
      if (k === 'class') node.className = v;
      else if (k === 'text') node.textContent = v;
      // eslint-disable-next-line no-unsanitized/property -- audited: static markup / escaped or sanitized values only
      else if (k === 'html') node.innerHTML = v; // only used with static icon SVGs
      else if (k.startsWith('on')) node.addEventListener(k.slice(2), v);
      else node.setAttribute(k, v === true ? '' : v);
    });
    [].concat(children).forEach((c) => { if (c) node.append(c); });
    return node;
  }

  function iconButton(svg, label, onclick, extraClass) {
    return el('button', { type: 'button', class: `icon-btn ${extraClass || ''}`, html: svg, 'aria-label': label, title: label, onclick });
  }

  function switchInput(checked, label, onchange) {
    const input = el('input', { type: 'checkbox', role: 'switch', 'aria-label': label, onchange });
    input.checked = checked;
    return el('label', { class: 'switch' }, [input, el('span', { class: 'track' })]);
  }

  function pill(text, kind) {
    return el('span', { class: `pill ${kind || ''}`, text });
  }

  function cap(s) {
    return s.charAt(0).toUpperCase() + s.slice(1);
  }

  function fail(e) {
    UI.toast(e && e.message ? e.message : String(e), { type: 'error' });
  }

  function groupKey(rule) {
    if (rule.siteScope === 'global') return '*';
    const host = String(rule.domainPattern || '').replace(/^https?:\/\//, '').split('/')[0].replace(/^\*\./, '').replace(/^www\./, '').toLowerCase();
    return host || '*';
  }

  // ---------------------------------------------------------------------------
  // Rules
  // ---------------------------------------------------------------------------

  function renderRules() {
    const container = $('ruleGroups');
    const q = $('ruleSearch').value.trim().toLowerCase();
    const action = $('ruleActionFilter').value;
    const rules = settings.rules.filter((r) => {
      if (action && r.actionType !== action) return false;
      if (!q) return true;
      return [r.name, r.selector, r.domainPattern].some((v) => String(v || '').toLowerCase().includes(q));
    });

    // Drop selections that no longer exist.
    Array.from(selected).forEach((id) => { if (!settings.rules.some((r) => r.id === id)) selected.delete(id); });

    container.innerHTML = '';
    if (!rules.length) {
      container.append(el('div', { class: 'empty', text: q || action ? t('rulesNoSearchPlain', 'No rules match your filters.') : t('rulesNoneOptions', 'No rules yet. Use the element picker on any page (Alt+P) or add one here.') }));
      renderBulk();
      return;
    }

    const groups = new Map();
    rules.forEach((r) => {
      const key = groupKey(r);
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key).push(r);
    });
    const keys = Array.from(groups.keys()).sort((a, b) => (a === '*' ? -1 : b === '*' ? 1 : a.localeCompare(b)));

    keys.forEach((key) => {
      const list = groups.get(key);
      const groupCheck = el('input', {
        type: 'checkbox',
        'aria-label': t('selectGroup', 'Select all rules for $1', [key === '*' ? t('scopeEverySite', 'Every site') : key]),
        onchange: (e) => {
          list.forEach((r) => (e.target.checked ? selected.add(r.id) : selected.delete(r.id)));
          renderRules();
        }
      });
      const allSel = list.every((r) => selected.has(r.id));
      groupCheck.checked = allSel;
      groupCheck.indeterminate = !allSel && list.some((r) => selected.has(r.id));

      const tbody = el('tbody');
      list.forEach((rule) => tbody.append(buildRuleRow(rule)));

      container.append(el('section', { class: 'group' }, [
        el('h3', {}, [
          el('label', {}, [groupCheck, el('span', { text: key === '*' ? t('scopeEverySite', 'Every site') : key })]),
          pill(String(list.length))
        ]),
        el('table', { class: 'rule-table' }, [tbody])
      ]));
    });
    renderBulk();
  }

  function buildRuleRow(rule) {
    const check = el('input', {
      type: 'checkbox',
      'aria-label': t('selectRuleNamed', 'Select $1', [rule.name]),
      onchange: (e) => {
        if (e.target.checked) selected.add(rule.id);
        else selected.delete(rule.id);
        renderRules();
      }
    });
    check.checked = selected.has(rule.id);

    const dupes = UI.findDuplicates(rule, settings.rules);
    const nameCell = el('td', { class: 'c-name' }, [
      el('div', { text: rule.name }),
      dupes.length ? el('div', { class: 'dup', text: t('duplicateOf', 'Same as "$1"', [dupes[0].name]) }) : null
    ]);
    const scopeText = rule.siteScope === 'exact' ? rule.domainPattern : rule.siteScope === 'global' ? t('scopeEverySite', 'Every site') : t('scopeDomainAndSub', '$1 and subdomains', [rule.domainPattern]);

    return el('tr', { class: rule.enabled ? '' : 'off' }, [
      el('td', { class: 'c-check' }, [check]),
      nameCell,
      el('td', { class: 'c-sel' }, [el('code', { text: rule.selector })]),
      el('td', {}, [pill((UI.ACTION_LABELS[rule.actionType] || UI.ACTION_LABELS['remove-blur'])())]),
      el('td', {}, [pill(scopeText)]),
      el('td', { class: 'c-ctl' }, [
        switchInput(rule.enabled, t('toggleRuleNamed', 'Enable $1', [rule.name]), (e) => Storage.updateRule(rule.id, { enabled: e.target.checked }).catch(fail)),
        iconButton(UI.ICONS.edit, t('editRuleNamed', 'Edit $1', [rule.name]), () => openRuleDialog(rule)),
        iconButton(UI.ICONS.trash, t('deleteRuleNamed', 'Delete $1', [rule.name]), () => deleteRules([rule.id]))
      ])
    ]);
  }

  function renderBulk() {
    $('bulkBar').classList.toggle('hidden', selected.size === 0);
    $('bulkCount').textContent = selected.size === 1 ? t('oneSelected', '1 rule selected') : t('manySelected', '$1 rules selected', [selected.size]);
  }

  async function deleteRules(ids) {
    try {
      const removed = ids.length === 1 ? [await Storage.deleteRule(ids[0])].filter(Boolean) : await Storage.bulkDeleteRules(ids);
      ids.forEach((id) => selected.delete(id));
      UI.toast(removed.length === 1 ? t('ruleDeleted', 'Deleted "$1"', [removed[0].name]) : t('rulesDeleted', 'Deleted $1 rules', [removed.length]), {
        actionLabel: t('undo', 'Undo'),
        onAction: async () => {
          for (const r of removed) await Storage.restoreRule(r);
          UI.toast(t('rulesRestored', 'Restored'));
        }
      });
    } catch (e) {
      fail(e);
    }
  }

  // ---------------------------------------------------------------------------
  // Rule dialog
  // ---------------------------------------------------------------------------

  function updateScopeField() {
    const scope = $('ruleScope').value;
    $('ruleDomainField').classList.toggle('hidden', scope === 'global');
    $('ruleDomainLabel').textContent = scope === 'exact' ? t('rulePageAddress', 'Page address') : t('ruleDomain', 'Domain');
    const hint = $('ruleDomainHint');
    hint.className = 'hint';
    hint.textContent = scope === 'exact'
      ? t('exactHint', 'End with * to include every page below it, for example example.com/blog/*')
      : t('domainHint', 'Subdomains are included automatically.');
  }

  function openRuleDialog(rule) {
    formTouched = false;
    $('ruleDialogTitle').textContent = rule ? t('editRuleTitle', 'Edit rule') : t('addRuleTitle', 'Add rule');
    $('ruleId').value = rule ? rule.id : '';
    $('ruleName').value = rule ? rule.name : '';
    $('ruleSelector').value = rule ? rule.selector : '';
    $('ruleAction').value = rule ? rule.actionType : 'remove-blur';
    $('ruleScope').value = rule ? rule.siteScope : 'domain';
    $('ruleDomain').value = rule && rule.domainPattern !== '*' ? rule.domainPattern : '';
    $('ruleCss').value = rule ? rule.customCss || '' : '';
    $('ruleCssField').classList.toggle('hidden', $('ruleAction').value !== 'custom-css');
    ['ruleNameHint', 'ruleSelectorHint', 'ruleCssHint', 'ruleWarnings'].forEach((id) => { $(id).textContent = ''; });
    ['ruleName', 'ruleSelector', 'ruleDomain', 'ruleCss'].forEach((id) => $(id).classList.remove('invalid'));
    updateScopeField();
    $('ruleDialog').showModal();
    $('ruleName').focus();
    if (rule) validateForm();
  }

  function readDraft() {
    const scope = $('ruleScope').value;
    return {
      id: $('ruleId').value || '__draft__',
      name: $('ruleName').value.trim(),
      selector: $('ruleSelector').value.trim(),
      actionType: $('ruleAction').value,
      siteScope: scope,
      domainPattern: scope === 'global' ? '*' : $('ruleDomain').value.trim(),
      customCss: $('ruleAction').value === 'custom-css' ? $('ruleCss').value.trim() : ''
    };
  }

  function validateForm(showAll) {
    const draft = readDraft();
    const { errors, warnings } = UI.validateRule(draft, Storage.getAllRules(settings));
    const show = showAll || formTouched;
    const setErr = (inputId, hintId, msg) => {
      $(inputId).classList.toggle('invalid', !!(msg && show));
      if (hintId) {
        $(hintId).className = 'hint error';
        $(hintId).textContent = show ? msg || '' : '';
      }
    };
    setErr('ruleName', 'ruleNameHint', errors.name);
    setErr('ruleCss', 'ruleCssHint', errors.customCss);
    if (errors.domainPattern && show) {
      $('ruleDomain').classList.add('invalid');
      $('ruleDomainHint').className = 'hint error';
      $('ruleDomainHint').textContent = errors.domainPattern;
    } else {
      $('ruleDomain').classList.remove('invalid');
      updateScopeField();
    }
    const selHint = $('ruleSelectorHint');
    $('ruleSelector').classList.toggle('invalid', !!(errors.selector && (show || draft.selector)));
    if (errors.selector) {
      selHint.className = 'hint error';
      selHint.textContent = show || draft.selector ? errors.selector : '';
    } else {
      selHint.className = 'hint ok';
      selHint.textContent = draft.selector ? t('selectorValidOptions', 'Valid selector. Use the popup on a page to see how many elements it matches.') : '';
    }
    $('ruleWarnings').textContent = warnings.join(' ');
    return errors;
  }
  const validateSoon = UI.debounce(() => validateForm(), 200);

  async function submitRule(e) {
    e.preventDefault();
    formTouched = true;
    const errors = validateForm(true);
    const first = [['name', 'ruleName'], ['selector', 'ruleSelector'], ['domainPattern', 'ruleDomain'], ['customCss', 'ruleCss']].find(([k]) => errors[k]);
    if (first) {
      $(first[1]).focus();
      return;
    }
    const draft = readDraft();
    const id = $('ruleId').value;
    delete draft.id;
    try {
      if (id) await Storage.updateRule(id, draft);
      else await Storage.addRule(draft);
      UI.toast(id ? t('ruleSaved', 'Rule saved') : t('ruleAdded', 'Rule added'));
      $('ruleDialog').close();
    } catch (err) {
      $('ruleWarnings').textContent = err.message;
    }
  }

  // ---------------------------------------------------------------------------
  // Packs
  // ---------------------------------------------------------------------------

  function renderPacks() {
    const list = $('packList');
    list.innerHTML = '';
    if (!settings.rulePacks.length) {
      list.append(el('li', { class: 'empty', text: t('packsNone', 'No rule packs yet. The built-in pack loads after the extension starts.') }));
      return;
    }
    settings.rulePacks.forEach((pack) => {
      const meta = el('div', { class: 'pack-meta' }, [
        pill((pack.rules || []).length === 1 ? t('packRuleCountOne', '1 rule') : t('packRuleCount', '$1 rules', [(pack.rules || []).length])),
        pack.version ? pill(t('packVersion', 'Version $1', [pack.version])) : null,
        pill(t('packUpdated', 'Updated $1', [UI.timeAgo(pack.lastFetched)])),
        pack.builtIn ? pill(t('packBuiltIn', 'Included'), 'accent') : null,
        pack.error ? pill(t('packError', 'Update failed: $1', [pack.error]), 'danger') : null
      ]);

      const ctl = el('div', { class: 'pack-ctl' }, [
        iconButton(UI.ICONS.refresh, t('refreshPackNamed', 'Check $1 for updates', [pack.name]), () => refreshPacks(pack.id)),
        pack.builtIn ? null : iconButton(UI.ICONS.trash, t('removePackNamed', 'Remove $1', [pack.name]), async () => {
          try {
            await Storage.removeRulePack(pack.id);
            UI.toast(t('packRemoved', 'Removed "$1"', [pack.name]));
          } catch (e) {
            fail(e);
          }
        }),
        switchInput(pack.enabled, t('togglePackNamed', 'Use $1', [pack.name]), (e) => Storage.updateRulePack(pack.id, { enabled: e.target.checked }).catch(fail))
      ]);

      const preview = (pack.rules || []).length
        ? el('details', { class: 'pack-meta' }, [
          el('summary', { text: t('packShowRules', 'Show rules') }),
          el('ul', {}, pack.rules.map((r) => el('li', {}, [
            el('span', { text: `${r.name} ` }),
            el('code', { class: 'muted', text: `${r.siteScope === 'global' ? '*' : r.domainPattern} · ${r.selector}` })
          ])))
        ])
        : null;

      list.append(el('li', { class: 'pack' }, [
        el('div', { class: 'pack-name', text: pack.name || pack.url }),
        ctl,
        el('div', { class: 'pack-url', text: pack.builtIn ? t('packBuiltInHint', 'Ships with the extension and updates with it.') : pack.url }),
        meta,
        preview
      ]));
    });
  }

  async function refreshPacks(id) {
    UI.toast(t('packChecking', 'Checking for updates…'));
    const res = await UI.sendMessage({ type: 'REFRESH_RULE_PACKS', id: id || null });
    if (!res || res.ok === false) fail(new Error((res && res.error) || t('packRefreshFailed', 'Could not check for updates.')));
    else UI.toast(t('packChecked', 'Rule packs are up to date'));
  }

  async function addPack(e) {
    e.preventDefault();
    const url = $('packUrl').value.trim();
    const name = $('packName').value.trim();
    $('packError').textContent = '';
    if (!/^https:\/\/\S+$/i.test(url)) {
      $('packError').textContent = t('packUrlInvalid', 'Enter a full https:// address to a JSON rule pack.');
      $('packUrl').focus();
      return;
    }
    $('packAddBtn').disabled = true;
    const res = await UI.sendMessage({ type: 'ADD_RULE_PACK', url, name });
    $('packAddBtn').disabled = false;
    if (!res || res.ok === false) {
      $('packError').textContent = (res && res.error) || t('packAddFailed', 'Could not add this pack.');
      return;
    }
    $('packUrl').value = '';
    $('packName').value = '';
    UI.toast(t('packAdded', 'Added "$1"', [(res.result && res.result.name) || url]));
  }

  // ---------------------------------------------------------------------------
  // Dark mode & reader
  // ---------------------------------------------------------------------------

  function renderDark() {
    const dm = settings.darkMode;
    $('darkEnabled').checked = settings.presetsEnabled.forceDarkMode;
    $('darkMode').value = dm.mode;
    $('darkAutomation').value = dm.automation;
    document.querySelectorAll('.schedule-field').forEach((f) => { f.hidden = dm.automation !== 'schedule'; });
    if (document.activeElement !== $('darkStart')) $('darkStart').value = dm.scheduleStart;
    if (document.activeElement !== $('darkEnd')) $('darkEnd').value = dm.scheduleEnd;
    $('darkDimImages').checked = dm.dimImages;
    SLIDERS.forEach((k) => {
      const input = $(`dark${cap(k)}`);
      if (document.activeElement !== input) input.value = dm[k];
      $(`dark${cap(k)}Out`).textContent = `${input.value}%`;
    });
  }

  const saveDark = UI.debounce((patch) => Storage.updateDarkMode(patch).catch(fail), 250);
  const saveReader = UI.debounce((patch) => Storage.updateReaderPrefs(patch).catch(fail), 250);

  const READER_FONTS = {
    serif: 'Georgia, "Iowan Old Style", "Times New Roman", serif',
    sans: 'var(--font)',
    mono: 'var(--font-code)',
    atkinson: '"Atkinson Hyperlegible", var(--font)',
    dyslexic: '"OpenDyslexic", var(--font)'
  };

  function renderReader() {
    const r = settings.reader;
    $('readerFont').value = r.fontFamily;
    $('readerTheme').value = r.theme;
    $('readerWidth').value = r.width;
    [['readerSize', r.fontSize, (v) => `${v}px`], ['readerLineHeight', r.lineHeight, (v) => Number(v).toFixed(2)], ['readerSpacing', r.paragraphSpacing, (v) => `${Number(v).toFixed(1)}em`]].forEach(([id, val, fmt]) => {
      if (document.activeElement !== $(id)) $(id).value = val;
      $(`${id}Out`).textContent = fmt($(id).value);
    });
    const p = $('readerPreview');
    p.style.fontFamily = READER_FONTS[r.fontFamily] || READER_FONTS.serif;
    p.style.fontSize = `${$('readerSize').value}px`;
    p.style.lineHeight = $('readerLineHeight').value;
  }

  // ---------------------------------------------------------------------------
  // Sites, stats, backup, shortcuts
  // ---------------------------------------------------------------------------

  function chipList(container, items, onRemove) {
    container.innerHTML = '';
    if (!items.length) {
      container.append(el('li', { class: 'chip-empty', text: t('noneYet', 'None yet.') }));
      return;
    }
    items.forEach(({ host, label }) => {
      container.append(el('li', { class: 'chip' }, [
        el('span', { text: label || host }),
        iconButton(UI.ICONS.close, t('removeSite', 'Remove $1', [host]), () => onRemove(host).catch(fail))
      ]));
    });
  }

  function renderSites() {
    const s = settings.sites;
    const timed = Object.entries(s.pausedUntil || {}).map(([host, until]) => ({
      host,
      label: t('pausedUntilChip', '$1 (until $2)', [host, new Date(until).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })])
    }));
    chipList($('pausedList'), s.paused.map((host) => ({ host })).concat(timed), (host) => Storage.setSitePaused(host, false));
    $('showBadge').checked = settings.showBadge !== false;
    const modeLabel = { filter: t('darkSiteFilter', 'Always filter'), dynamic: t('darkSiteDynamic', 'Always dynamic'), off: t('darkSiteOff', 'Never') };
    chipList($('darkSiteList'), Object.entries(s.darkMode).map(([host, mode]) => ({ host, label: `${host}: ${modeLabel[mode] || mode}` })), (host) => Storage.setSiteDarkMode(host, null));
    chipList($('autoReaderList'), s.autoReader.map((host) => ({ host })), (host) => Storage.setAutoReader(host, false));
    const presetLabel = (key) => (UI.PRESETS[key] ? UI.PRESETS[key].title() : key);
    chipList($('sitePresetList'), Object.entries(s.presets || {}).map(([host, map]) => ({
      host,
      label: `${host}: ${Object.entries(map).map(([k, on]) => `${presetLabel(k)} ${on ? t('stateOn', 'On').toLowerCase() : t('stateOff', 'Off').toLowerCase()}`).join(', ')}`
    })), (host) => Storage.clearSitePresets(host));
  }

  // ---------------------------------------------------------------------------
  // Highlights library
  // ---------------------------------------------------------------------------

  let hlPages = [];

  function safePageUrl(url) {
    try {
      const u = new URL(url);
      return /^https?:$/.test(u.protocol) ? u.href : '';
    } catch (e) {
      return '';
    }
  }

  function pageHost(page) {
    try {
      return new URL(page.url).hostname.replace(/^www\./, '');
    } catch (e) {
      return page.key.slice(3).split('/')[0];
    }
  }

  function mdEscape(text) {
    return String(text || '').replace(/([\\`*_[\]])/g, '\\$1');
  }

  function pageMarkdown(page) {
    const title = mdEscape(page.title || pageHost(page));
    const url = safePageUrl(page.url);
    const lines = [url ? `## [${title}](<${url}>)` : `## ${title}`, ''];
    page.highlights.forEach((h) => {
      lines.push(...String(h.text).trim().split(/\n+/).map((l) => `> ${l}`));
      if (h.note) lines.push('>', ...String(h.note).trim().split(/\n+/).map((l, i) => (i ? `> ${l}` : `> **${t('hlNoteLabel', 'Note:')}** ${l}`)));
      lines.push('');
    });
    return lines.join('\n');
  }

  function downloadText(text, filename, type) {
    const blob = new Blob([text], { type });
    const url = URL.createObjectURL(blob);
    const a = el('a', { href: url, download: filename });
    document.body.append(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  /** Text with the search term wrapped in <mark>, built with DOM nodes (never innerHTML). */
  function withHits(text, q) {
    const frag = document.createDocumentFragment();
    const str = String(text || '');
    if (!q) {
      frag.append(str);
      return frag;
    }
    const lower = str.toLowerCase();
    let i = 0;
    let at = lower.indexOf(q);
    while (at !== -1) {
      frag.append(str.slice(i, at), el('mark', { class: 'hl-hit', text: str.slice(at, at + q.length) }));
      i = at + q.length;
      at = lower.indexOf(q, i);
    }
    frag.append(str.slice(i));
    return frag;
  }

  async function loadHighlights() {
    try {
      hlPages = await Storage.getHighlightPages();
    } catch (e) {
      hlPages = [];
    }
    renderHighlights();
  }

  function renderHighlights() {
    const list = $('hlPages');
    const q = $('hlSearch').value.trim().toLowerCase();
    list.innerHTML = '';
    const total = hlPages.reduce((n, p) => n + p.highlights.length, 0);
    $('hlExportBtn').disabled = !total;
    if (!total) {
      $('hlSummary').textContent = '';
      list.append(el('li', { class: 'empty', text: t('hlEmpty', 'No highlights yet. Open Reader view (Alt+R), select text and choose Highlight or Add note.') }));
      return;
    }
    let shownPages = 0;
    let shownItems = 0;
    hlPages.forEach((page) => {
      const pageMatch = !q || `${page.title} ${page.url}`.toLowerCase().includes(q);
      const items = page.highlights.filter((h) => pageMatch || `${h.text} ${h.note || ''}`.toLowerCase().includes(q));
      if (!items.length) return;
      shownPages++;
      shownItems += items.length;
      const url = safePageUrl(page.url);
      const notes = items.filter((h) => h.note).length;
      const meta = [
        pageHost(page),
        items.length === 1 ? t('hlCountOne', '1 highlight') : t('hlCount', '$1 highlights', [items.length]),
        notes ? (notes === 1 ? t('hlNotesOne', '1 note') : t('hlNotes', '$1 notes', [notes])) : '',
        UI.timeAgo(page.updatedAt)
      ].filter(Boolean).join(' · ');
      const title = page.title || pageHost(page);
      const ctl = el('div', { class: 'hl-ctl' }, [
        url ? el('a', { class: 'btn btn-sm btn-ghost', href: url, target: '_blank', rel: 'noopener noreferrer', text: t('hlOpen', 'Open page') }) : null,
        el('button', {
          type: 'button',
          class: 'btn btn-sm btn-ghost',
          text: t('hlCopyMd', 'Copy as Markdown'),
          onclick: async (e) => {
            e.preventDefault();
            try {
              await navigator.clipboard.writeText(pageMarkdown(page));
              UI.toast(t('hlCopied', 'Copied as Markdown'));
            } catch (err) {
              fail(new Error(t('hlCopyFailed', 'Copy failed: the browser blocked clipboard access.')));
            }
          }
        }),
        iconButton(UI.ICONS.trash, t('hlDeletePage', 'Delete highlights on $1', [title]), (e) => {
          e.preventDefault();
          deleteHighlightPage(page);
        })
      ]);
      // Stop clicks on the controls from toggling the <details>.
      ctl.addEventListener('click', (e) => e.stopPropagation());
      const items$ = el('ul', { class: 'hl-items' }, items.map((h) => el('li', {}, [
        el('blockquote', {}, [withHits(h.text, q)]),
        h.note ? el('p', { class: 'hl-note' }, [el('strong', { text: `${t('hlNoteLabel', 'Note:')} ` }), withHits(h.note, q)]) : null
      ])));
      const details = el('details', q ? { open: true } : {}, [
        el('summary', {}, [
          el('span', { class: 'hl-title', title }, [withHits(title, q)]),
          ctl,
          el('span', { class: 'hl-meta', text: meta })
        ]),
        items$
      ]);
      list.append(el('li', { class: 'hl-page' }, [details]));
    });
    $('hlSummary').textContent = q
      ? t('hlSummarySearch', '$1 of $2 highlights match, on $3 pages.', [shownItems, total, shownPages])
      : t('hlSummary', '$1 highlights on $2 pages.', [total, hlPages.length]);
    if (!shownPages) list.append(el('li', { class: 'empty', text: t('hlNoSearch', 'Nothing matches your search.') }));
  }

  async function deleteHighlightPage(page) {
    try {
      await Storage.deleteHighlightPage(page.key);
      UI.toast(t('hlDeleted', 'Deleted the highlights on $1', [page.title || pageHost(page)]), {
        actionLabel: t('undo', 'Undo'),
        onAction: () => Storage.saveHighlights(page.url, page.highlights, { title: page.title }).catch(fail)
      });
    } catch (e) {
      fail(e);
    }
  }

  function exportAllHighlights() {
    if (!hlPages.length) return;
    const date = new Date().toISOString().slice(0, 10);
    const md = [`# ${t('hlExportTitle', 'Blur Remover highlights')}`, '', `${t('hlExportedOn', 'Exported $1', [date])}`, '']
      .concat(hlPages.map(pageMarkdown)).join('\n');
    downloadText(md, `blur-remover-highlights-${date}.md`, 'text/markdown;charset=utf-8');
    UI.toast(t('hlExported', 'Highlights exported'));
  }

  function renderStats() {
    const st = settings.stats;
    $('totBlurs').textContent = UI.formatNumber(st.totalBlursStripped);
    $('totOverlays').textContent = UI.formatNumber(st.totalOverlaysErased);
    $('totScrolls').textContent = UI.formatNumber(st.totalScrollsUnlocked);
    const body = $('statsBody');
    body.innerHTML = '';
    const rows = Object.entries(st.sites || {})
      .map(([host, v]) => ({ host, ...v, total: (v.blurs || 0) + (v.overlays || 0) + (v.scrolls || 0) }))
      .sort((a, b) => b.total - a.total)
      .slice(0, 25);
    if (!rows.length) {
      body.append(el('tr', {}, [el('td', { colspan: '5', class: 'muted', text: t('statsEmpty', 'Counts start as soon as something is unblurred.') })]));
      return;
    }
    rows.forEach((r) => body.append(el('tr', {}, [
      el('td', { text: r.host }),
      el('td', { class: 'r', text: UI.formatNumber(r.blurs) }),
      el('td', { class: 'r', text: UI.formatNumber(r.overlays) }),
      el('td', { class: 'r', text: UI.formatNumber(r.scrolls) }),
      el('td', { class: 'r muted', text: UI.timeAgo(r.lastSeen) })
    ])));
  }

  async function renderUsage() {
    const u = await Storage.getStorageUsage();
    const kb = (n) => `${(n / 1024).toFixed(1)} KB`;
    const meter = (label, used, quota, warnAt) => {
      const pct = quota ? Math.min(100, Math.round((used / quota) * 100)) : 0;
      const bar = el('span');
      bar.style.width = `${pct}%`;
      return el('div', { class: `meter ${pct >= warnAt ? 'warn' : ''}` }, [
        el('span', { text: `${label}: ${kb(used)} of ${kb(quota)} (${pct}%)` }),
        el('div', { class: 'meter-bar', role: 'progressbar', 'aria-valuenow': String(pct), 'aria-valuemin': '0', 'aria-valuemax': '100', 'aria-label': label }, [bar])
      ]);
    };
    const box = $('usage');
    box.innerHTML = '';
    box.append(
      meter(t('usageSync', 'Synced settings'), u.coreBytes, u.syncItemQuota, 80),
      meter(t('usageLocal', 'Rules, packs and statistics on this device'), u.localBytes, u.localQuota, 80)
    );
    if (!u.syncOk) box.append(el('p', { class: 'hint warn', text: t('syncFailed', 'Settings sync is unavailable. Changes are saved on this device only.') }));
  }

  function exportSettings() {
    Storage.exportSettings()
      .then((data) => UI.downloadJson(data, `blur-remover-backup-${new Date().toISOString().slice(0, 10)}.json`))
      .then(() => UI.toast(t('exported', 'Settings exported')))
      .catch(fail);
  }

  let importMode = 'merge';
  const MAX_IMPORT_BYTES = 5 * 1024 * 1024;
  function importFile(file) {
    const errorsBox = $('importErrors');
    errorsBox.innerHTML = '';
    if (file.size > MAX_IMPORT_BYTES) {
      errorsBox.append(el('li', { text: t('importTooLarge', 'That file is too large to be a Blur Remover backup.') }));
      return;
    }
    const reader = new FileReader();
    reader.onload = async () => {
      let data;
      try {
        data = JSON.parse(reader.result);
      } catch (e) {
        errorsBox.append(el('li', { text: t('importNotJson', 'That file isn\'t valid JSON. Choose a backup exported from Blur Remover.') }));
        return;
      }
      try {
        // A rule pack only adds rules; a full backup also restores settings.
        const isPack = Storage.isRulePackFile(data);
        const result = isPack ? await Storage.importRulePack(data) : await Storage.importSettings(data, importMode);
        UI.toast(!isPack && importMode === 'replace'
          ? t('restored', 'Backup restored ($1 rules)', [result.imported])
          : t('imported', 'Imported $1 rules', [result.imported]));
        (result.errors || []).forEach((msg) => errorsBox.append(el('li', { text: msg })));
      } catch (e) {
        errorsBox.append(el('li', { text: e.message }));
      }
    };
    reader.readAsText(file);
  }

  async function renderShortcuts() {
    const list = $('shortcutList');
    list.innerHTML = '';
    let commands = [];
    try {
      commands = await chrome.commands.getAll();
    } catch (e) {
      commands = [];
    }
    if (!commands.length) {
      commands = [
        { name: 'toggle-instant-unblur', shortcut: 'Alt+U', description: t('cmdToggleUnblur', 'Toggle instant unblur for this tab') },
        { name: 'start-element-picker', shortcut: 'Alt+P', description: t('cmdPicker', 'Pick an element to unblur, hide or zap') },
        { name: 'start-reader-view', shortcut: 'Alt+R', description: t('cmdReader', 'Toggle Reader View') },
        { name: 'toggle-site-pause', shortcut: '', description: t('cmdPauseSite', 'Pause or resume the extension on this site') },
        { name: 'toggle-site-dark-mode', shortcut: 'Alt+Shift+D', description: t('cmdDarkSite', 'Toggle dark mode on this site') }
      ];
    }
    commands.filter((c) => c.name !== '_execute_action').forEach((c) => {
      const keys = c.shortcut ? c.shortcut.split('+').map((k) => el('kbd', { text: k })) : [el('span', { class: 'muted', text: t('notSet', 'Not set') })];
      const dt = el('dt');
      keys.forEach((k, i) => { if (i) dt.append(' '); dt.append(k); });
      list.append(dt, el('dd', { text: c.description }));
    });
    list.append(el('dt', {}, [el('kbd', { text: 'Ctrl' }), ' ', el('kbd', { text: 'Z' })]), el('dd', { text: t('undoShortcut', 'Undo the last zapped element or saved rule on the page') }));
    list.append(el('dt', {}, [el('kbd', { text: 'Esc' })]), el('dd', { text: t('escShortcut', 'Close the picker or Reader view') }));
  }

  // ---------------------------------------------------------------------------
  // Wiring
  // ---------------------------------------------------------------------------

  function renderAll() {
    UI.applyTheme(settings.theme);
    $('themeToggle').textContent = settings.theme === 'light' ? t('useDarkTheme', 'Use dark theme') : t('useLightTheme', 'Use light theme');
    renderRules();
    renderPacks();
    renderDark();
    renderReader();
    renderSites();
    renderStats();
  }

  function bind() {
    $('themeToggle').addEventListener('click', () => {
      settings.theme = settings.theme === 'light' ? 'dark' : 'light';
      renderAll();
      Storage.setTheme(settings.theme).catch(fail);
    });

    $('addRuleBtn').addEventListener('click', () => openRuleDialog(null));
    $('ruleSearch').addEventListener('input', renderRules);
    $('ruleActionFilter').addEventListener('change', renderRules);
    $('bulkEnable').addEventListener('click', () => Storage.bulkUpdateRules(Array.from(selected), { enabled: true }).then(() => UI.toast(t('bulkEnabled', 'Enabled $1 rules', [selected.size]))).catch(fail));
    $('bulkDisable').addEventListener('click', () => Storage.bulkUpdateRules(Array.from(selected), { enabled: false }).then(() => UI.toast(t('bulkDisabled', 'Disabled $1 rules', [selected.size]))).catch(fail));
    $('bulkDelete').addEventListener('click', () => deleteRules(Array.from(selected)));
    $('bulkClear').addEventListener('click', () => { selected.clear(); renderRules(); });

    // eslint-disable-next-line no-unsanitized/property -- audited: static markup / escaped or sanitized values only
    $('ruleDialogClose').innerHTML = UI.ICONS.close;
    $('ruleDialogClose').addEventListener('click', () => $('ruleDialog').close());
    $('ruleCancel').addEventListener('click', () => $('ruleDialog').close());
    $('ruleForm').addEventListener('submit', submitRule);
    $('ruleAction').addEventListener('change', () => {
      $('ruleCssField').classList.toggle('hidden', $('ruleAction').value !== 'custom-css');
      validateSoon();
    });
    $('ruleScope').addEventListener('change', () => { updateScopeField(); validateSoon(); });
    ['ruleName', 'ruleSelector', 'ruleDomain', 'ruleCss'].forEach((id) => {
      $(id).addEventListener('input', validateSoon);
      $(id).addEventListener('blur', () => { formTouched = formTouched || !!$(id).value; validateSoon(); });
    });

    $('refreshPacksBtn').addEventListener('click', () => refreshPacks(null));
    $('packForm').addEventListener('submit', addPack);

    $('darkEnabled').addEventListener('change', (e) => Storage.togglePreset('forceDarkMode', e.target.checked).catch(fail));
    $('darkMode').addEventListener('change', (e) => saveDark({ mode: e.target.value }));
    $('darkAutomation').addEventListener('change', (e) => {
      document.querySelectorAll('.schedule-field').forEach((f) => { f.hidden = e.target.value !== 'schedule'; });
      saveDark({ automation: e.target.value });
    });
    $('darkStart').addEventListener('change', (e) => saveDark({ scheduleStart: e.target.value }));
    $('darkEnd').addEventListener('change', (e) => saveDark({ scheduleEnd: e.target.value }));
    $('darkDimImages').addEventListener('change', (e) => saveDark({ dimImages: e.target.checked }));
    SLIDERS.forEach((k) => {
      $(`dark${cap(k)}`).addEventListener('input', (e) => {
        $(`dark${cap(k)}Out`).textContent = `${e.target.value}%`;
        saveDark({ [k]: Number(e.target.value) });
      });
    });

    $('readerFont').addEventListener('change', (e) => saveReader({ fontFamily: e.target.value }));
    $('readerTheme').addEventListener('change', (e) => saveReader({ theme: e.target.value }));
    $('readerWidth').addEventListener('change', (e) => saveReader({ width: e.target.value }));
    [['readerSize', 'fontSize'], ['readerLineHeight', 'lineHeight'], ['readerSpacing', 'paragraphSpacing']].forEach(([id, key]) => {
      $(id).addEventListener('input', (e) => {
        settings.reader[key] = Number(e.target.value);
        renderReader();
        saveReader({ [key]: Number(e.target.value) });
      });
    });

    $('resetStatsBtn').addEventListener('click', async () => {
      const before = settings.stats;
      try {
        await Storage.resetStats();
        UI.toast(t('statsReset', 'Statistics reset'), {
          actionLabel: t('undo', 'Undo'),
          onAction: () => Storage.recordStats('', { blurs: before.totalBlursStripped, overlays: before.totalOverlaysErased, scrolls: before.totalScrollsUnlocked })
        });
      } catch (e) {
        fail(e);
      }
    });

    $('exportBtn').addEventListener('click', exportSettings);
    $('showBadge').addEventListener('change', (e) => {
      Storage.setShowBadge(e.target.checked)
        .then(() => UI.toast(e.target.checked ? t('badgeShown', 'Badge shown') : t('badgeHidden', 'Badge hidden')))
        .catch(fail);
    });
    $('importMergeBtn').addEventListener('click', () => { importMode = 'merge'; $('importFile').click(); });
    $('importReplaceBtn').addEventListener('click', () => { importMode = 'replace'; $('importFile').click(); });
    $('importFile').addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (file) importFile(file);
      e.target.value = '';
    });
    $('shortcutsBtn').addEventListener('click', () => UI.sendMessage({ type: 'OPEN_SHORTCUTS' }));
    $('hlSearch').addEventListener('input', UI.debounce(renderHighlights, 150));
    $('hlExportBtn').addEventListener('click', exportAllHighlights);

    // Highlight the section in view.
    const links = Array.from(document.querySelectorAll('.nav a'));
    const io = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        links.forEach((a) => a.classList.toggle('current', a.getAttribute('href') === `#${entry.target.id}`));
      });
    }, { rootMargin: '-20% 0px -70% 0px' });
    document.querySelectorAll('.section').forEach((s) => io.observe(s));

    if (chrome.storage && chrome.storage.onChanged) {
      chrome.storage.onChanged.addListener(async (changes) => {
        const keys = Object.keys(changes);
        if (keys.some((k) => k === Storage.KEYS.highlightIndex || k.startsWith('hl:'))) loadHighlights();
        if (keys.every((k) => k === Storage.KEYS.highlightIndex || k.startsWith('hl:'))) {
          renderUsage();
          return;
        }
        settings = await Storage.getSettings();
        renderAll();
        renderUsage();
      });
    }
  }

  async function init() {
    // eslint-disable-next-line no-unsanitized/property -- audited: static markup / escaped or sanitized values only
    $('brandMark').innerHTML = UI.ICONS.lens;
    try {
      $('versionTag').textContent = t('versionLabel', 'Version $1', [chrome.runtime.getManifest().version]);
    } catch (e) { /* ignore */ }

    Storage.ACTION_TYPES.forEach((type) => {
      $('ruleAction').append(el('option', { value: type, text: UI.ACTION_LABELS[type]() }));
      $('ruleActionFilter').append(el('option', { value: type, text: UI.ACTION_LABELS[type]() }));
    });

    settings = await Storage.getSettings();
    renderAll();
    bind();
    renderUsage();
    renderShortcuts();
    await loadHighlights();
    // Opened from Reader view ("All my highlights"): the section is filled now, so jump to it.
    if (location.hash === '#highlights') $('highlights').scrollIntoView();
  }

  document.addEventListener('DOMContentLoaded', init);
})();
