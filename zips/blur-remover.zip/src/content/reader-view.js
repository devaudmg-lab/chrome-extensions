/**
 * Blur Remover & DOM Modifier - Reader View
 *
 * Article mode: Mozilla Readability on a cloned document (after lazy-media preprocessing),
 *               then an allowlist sanitiser and structure heuristics.
 * Full page mode: walks the live document (accordions/FAQs/tab panels included) for pages
 *                 that are not articles.
 * Extras: TOC sidebar, text-to-speech with word highlight, Markdown/HTML/print export,
 *         highlights & notes per URL, persisted typography prefs, auto-open per site.
 *
 * Injected on demand into the top frame only (see service-worker.js FILES.reader).
 */

(function () {
  'use strict';

  if (self.BlurRemoverReader) return;
  if (window.top !== window) return;

  const Storage = self.BlurRemoverStorage || null;
  const Dom = self.BlurRemoverDom || null;

  const ROOT_ID = 'blur-remover-reader-root';
  const LOCK_ATTR = 'data-br-reader-lock';
  const MIN_IMAGE = 120;
  const WORDS_PER_MINUTE = 230;

  const DEFAULT_PREFS = { fontSize: 18, fontFamily: 'serif', theme: 'system', width: 'medium', lineHeight: 1.7, paragraphSpacing: 1 };

  const FONT_STACKS = {
    serif: "Charter, 'Iowan Old Style', Georgia, Cambria, 'Times New Roman', serif",
    sans: "system-ui, -apple-system, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif",
    mono: "ui-monospace, 'Cascadia Code', 'SF Mono', Consolas, 'Liberation Mono', monospace",
    atkinson: "'BR Atkinson Hyperlegible', system-ui, -apple-system, 'Segoe UI', sans-serif",
    dyslexic: "'BR OpenDyslexic', system-ui, -apple-system, 'Segoe UI', sans-serif"
  };
  const FONT_FILES = {
    atkinson: ['BR Atkinson Hyperlegible', 'atkinson'],
    dyslexic: ['BR OpenDyslexic', 'dyslexic']
  };
  const WIDTHS = { narrow: '58ch', medium: '68ch', wide: '80ch' };

  const ALLOWED_TAGS = new Set([
    'P', 'H1', 'H2', 'H3', 'H4', 'H5', 'H6', 'UL', 'OL', 'LI', 'DL', 'DT', 'DD', 'BLOCKQUOTE', 'PRE', 'CODE',
    'FIGURE', 'FIGCAPTION', 'IMG', 'TABLE', 'THEAD', 'TBODY', 'TFOOT', 'CAPTION', 'TR', 'TH', 'TD', 'A',
    'STRONG', 'B', 'EM', 'I', 'U', 'SUP', 'SUB', 'BR', 'HR'
  ]);
  const DROP_TAGS = new Set([
    'SCRIPT', 'STYLE', 'NOSCRIPT', 'IFRAME', 'OBJECT', 'EMBED', 'FORM', 'INPUT', 'BUTTON', 'SELECT', 'TEXTAREA',
    'SVG', 'CANVAS', 'VIDEO', 'AUDIO', 'TEMPLATE', 'DIALOG', 'LINK', 'META', 'HEAD', 'TITLE', 'MATH', 'MAP', 'AREA'
  ]);
  const BLOCK_TAGS = new Set([
    'ADDRESS', 'ARTICLE', 'ASIDE', 'BLOCKQUOTE', 'DETAILS', 'DIV', 'DL', 'FIELDSET', 'FIGURE', 'FOOTER', 'FORM',
    'H1', 'H2', 'H3', 'H4', 'H5', 'H6', 'HEADER', 'HR', 'LI', 'MAIN', 'NAV', 'OL', 'P', 'PRE', 'SECTION',
    'SUMMARY', 'TABLE', 'UL', 'CENTER'
  ]);
  const ATTRS = {
    '*': ['title'],
    A: ['href'],
    IMG: ['src', 'alt'],
    TD: ['colspan', 'rowspan'],
    TH: ['colspan', 'rowspan'],
    OL: ['start']
  };

  const FULL_SKIP = [
    'nav', 'aside', 'form', 'script', 'style', 'noscript', 'template', 'svg', 'iframe', 'select', 'input', 'textarea',
    '[role="navigation"]', '[role="banner"]', '[role="contentinfo"]', '[role="complementary"]', '[role="search"]',
    '[role="dialog"]', '[aria-modal="true"]', '.slick-cloned', '.swiper-slide-duplicate', '.owl-item.cloned',
    '[id^="blur-remover"]', '.screen-reader-text', '.sr-only', '.visually-hidden'
  ].join(',');
  const ACCORDION_TRIGGER = [
    'summary', '[aria-controls][aria-expanded]', '.elementor-tab-title', '.accordion-button', '.accordion-header',
    '.accordion-title', '[class*="accordion__title"]', '[class*="accordion-title"]', '[class*="toggle-title"]',
    '[class*="faq-question"]', '[class*="faq__question"]', '.e-n-accordion-item-title'
  ].join(',');
  const ACCORDION_PANEL = [
    '[role="tabpanel"]', '[role="region"][aria-labelledby]', '.elementor-tab-content', '.accordion-collapse',
    '.accordion-body', '.collapse', '[class*="accordion__panel"]', '[class*="accordion-content"]',
    '[class*="accordion-panel"]', '[class*="toggle-content"]', '[class*="faq-answer"]', '[class*="faq__answer"]',
    '.tab-pane'
  ].join(',');
  const FULL_EMIT = new Set(['P', 'H1', 'H2', 'H3', 'H4', 'H5', 'H6', 'UL', 'OL', 'DL', 'TABLE', 'BLOCKQUOTE', 'PRE', 'FIGURE']);
  const TTS_BLOCKS = 'p, li, h1, h2, h3, h4, h5, h6, blockquote, dt, dd, figcaption, td, th, pre';

  const state = {
    open: false,
    opening: false,
    host: null,
    shadow: null,
    els: {},
    settings: null,
    prefs: Object.assign({}, DEFAULT_PREFS),
    mode: 'article',
    cache: {},
    data: null,
    highlights: [],
    tocObserver: null,
    lastScroll: 0,
    lock: null,
    pushed: false,
    ignorePop: false,
    prevFocus: null,
    prefsTimer: null,
    mq: window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null,
    tts: { active: false, paused: false, blocks: [], index: 0, chunks: [], chunk: 0, utter: null, textIndex: null }
  };

  // ---------------------------------------------------------------------------
  // Small helpers
  // ---------------------------------------------------------------------------

  function esc(s) {
    return Dom ? Dom.escapeHtml(s) : String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  function norm(s) {
    return String(s || '').replace(/\s+/g, ' ').trim();
  }

  function toast(text, type) {
    if (Dom) Dom.showToast(text, { type: type || 'info' });
  }

  function absUrl(u, base) {
    try {
      return new URL(String(u).trim(), base || location.href).href;
    } catch (e) {
      return '';
    }
  }

  function isPlaceholder(url) {
    if (!url) return true;
    const u = String(url).trim();
    if (!u) return true;
    if (/^data:/i.test(u)) return u.length < 3000;
    if (/^(about:|javascript:|blob:)/i.test(u)) return true;
    return /(?:^|\/)(?:blank|spacer|placeholder|transparent|pixel|lazy)[\w-]*\.(?:gif|png|svg)(?:$|\?)/i.test(u);
  }

  function largestFromSrcset(srcset) {
    if (!srcset) return '';
    let best = '';
    let bestVal = -1;
    srcset.split(/,\s+|,(?=https?:|\/)/).forEach((entry) => {
      const parts = entry.trim().split(/\s+/);
      if (!parts[0]) return;
      const d = parts[1] || '1x';
      const val = parseFloat(d) * (/w$/i.test(d) ? 1 : 1000);
      if (Number.isFinite(val) && val > bestVal) {
        bestVal = val;
        best = parts[0];
      }
    });
    return best;
  }

  function resolveImgSrc(img) {
    const direct = ['data-src', 'data-lazy-src', 'data-original', 'data-lazyload', 'data-url', 'data-hi-res-src', 'data-full-src'];
    for (const a of direct) {
      const v = img.getAttribute(a);
      if (v && !isPlaceholder(v)) return absUrl(v);
    }
    for (const a of ['data-srcset', 'data-lazy-srcset', 'srcset']) {
      const v = largestFromSrcset(img.getAttribute(a));
      if (v && !isPlaceholder(v)) return absUrl(v);
    }
    const pic = img.parentElement && img.parentElement.tagName === 'PICTURE' ? img.parentElement : null;
    if (pic) {
      for (const source of pic.querySelectorAll('source')) {
        const v = largestFromSrcset(source.getAttribute('srcset') || source.getAttribute('data-srcset'));
        if (v && !isPlaceholder(v)) return absUrl(v);
      }
    }
    const src = img.getAttribute('src');
    if (src && !isPlaceholder(src)) return absUrl(src);
    const sib = [img.nextElementSibling, img.previousElementSibling, img.parentElement && img.parentElement.nextElementSibling]
      .find((n) => n && n.tagName === 'NOSCRIPT');
    if (sib) {
      const html = sib.textContent || sib.innerHTML;
      const m = /<img[^>]+src=["']([^"']+)["']/i.exec(html || '');
      if (m && !isPlaceholder(m[1])) return absUrl(m[1]);
    }
    return '';
  }

  /** Dedup key: strips query, hash and WordPress size suffixes (-1024x683). */
  function imageKey(url) {
    return String(url).toLowerCase().replace(/[?#].*$/, '').replace(/-\d+x\d+(?=\.\w+$)/, '').replace(/^https?:/, '');
  }

  function buildImageSizeMap() {
    const map = new Map();
    document.querySelectorAll('img').forEach((img) => {
      if (img.closest('[id^="blur-remover"]')) return;
      const url = resolveImgSrc(img);
      if (!url) return;
      const r = img.getBoundingClientRect();
      const real = !isPlaceholder(img.currentSrc || img.src);
      // The rendered size wins: logos often carry large width/height attributes but display tiny.
      const size = r.width > 0 && r.height > 0
        ? Math.max(r.width, r.height)
        : Math.max(
          parseInt(img.getAttribute('width'), 10) || 0,
          parseInt(img.getAttribute('height'), 10) || 0,
          real ? Math.max(img.naturalWidth || 0, img.naturalHeight || 0) : 0
        );
      const key = imageKey(url);
      map.set(key, Math.max(map.get(key) || 0, size));
    });
    return map;
  }

  function isVisible(el) {
    if (typeof el.checkVisibility === 'function') {
      return el.checkVisibility({ visibilityProperty: true, checkVisibilityCSS: true });
    }
    if (!el.getClientRects().length) return false;
    return getComputedStyle(el).visibility !== 'hidden';
  }

  function similarText(a, b) {
    const na = String(a || '').toLowerCase().replace(/[^\p{L}\p{N}]+/gu, '');
    const nb = String(b || '').toLowerCase().replace(/[^\p{L}\p{N}]+/gu, '');
    if (!na || !nb) return false;
    if (na === nb) return true;
    return Math.min(na.length, nb.length) >= 15 && (na.includes(nb) || nb.includes(na));
  }

  // ---------------------------------------------------------------------------
  // Metadata
  // ---------------------------------------------------------------------------

  function meta(selector) {
    const el = document.querySelector(selector);
    return el ? norm(el.getAttribute('content') || el.getAttribute('datetime') || '') : '';
  }

  function siteName() {
    return meta('meta[property="og:site_name"]') || meta('meta[name="application-name"]') || location.hostname.replace(/^www\./, '');
  }

  function stripSiteSuffix(title) {
    const t = norm(title);
    const site = siteName().toLowerCase();
    const hostCore = location.hostname.replace(/^www\./, '').split('.')[0].toLowerCase();
    const parts = t.split(/\s+[|\-–—:·»]\s+/);
    if (parts.length < 2) return t;
    const last = parts[parts.length - 1].toLowerCase();
    const first = parts[0].toLowerCase();
    const matches = (s) => s === site || s.replace(/\s+/g, '').includes(hostCore) || site.includes(s);
    if (matches(last)) return parts.slice(0, -1).join(' - ');
    if (matches(first)) return parts.slice(1).join(' - ');
    return t;
  }

  function pickTitle(articleTitle) {
    const candidates = [
      norm(articleTitle),
      meta('meta[property="og:title"]') ? stripSiteSuffix(meta('meta[property="og:title"]')) : '',
      (() => {
        const h1 = Array.from(document.querySelectorAll('h1')).find((h) => !h.closest('[id^="blur-remover"]') && isVisible(h) && norm(h.innerText));
        return h1 ? norm(h1.innerText) : '';
      })(),
      stripSiteSuffix(document.title),
      location.hostname
    ];
    return candidates.find((c) => c && c.length > 1) || 'Untitled';
  }

  function publishedDate(article) {
    let raw = (article && article.publishedTime) ||
      meta('meta[property="article:published_time"]') ||
      meta('meta[name="date"]') ||
      meta('meta[itemprop="datePublished"]');
    if (!raw) {
      for (const s of document.querySelectorAll('script[type="application/ld+json"]')) {
        const m = /"datePublished"\s*:\s*"([^"]+)"/.exec(s.textContent || '');
        if (m) {
          raw = m[1];
          break;
        }
      }
    }
    if (!raw) {
      const t = document.querySelector('article time[datetime], time[datetime]');
      raw = t ? t.getAttribute('datetime') : '';
    }
    if (!raw) return '';
    const d = new Date(raw);
    return Number.isNaN(d.getTime()) ? '' : d.toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' });
  }

  // ---------------------------------------------------------------------------
  // Sanitiser (allowlist)
  // ---------------------------------------------------------------------------

  function hasDirectText(node) {
    for (const c of node.childNodes) {
      if (c.nodeType === 3 && c.nodeValue.trim()) return true;
    }
    return false;
  }

  function hasBlockChild(node) {
    for (const c of node.children) {
      if (BLOCK_TAGS.has(c.tagName.toUpperCase())) return true;
    }
    return false;
  }

  function safeHref(href) {
    if (!href) return '';
    const url = absUrl(href);
    return /^(https?:|mailto:)/i.test(url) ? url : '';
  }

  function sanitizeImg(node, ctx) {
    const url = resolveImgSrc(node);
    if (!url) return null;
    const key = imageKey(url);
    if (ctx.seenImages.has(key)) return null;
    const known = ctx.sizeMap.get(key);
    const attrW = parseInt(node.getAttribute('width'), 10) || 0;
    const attrH = parseInt(node.getAttribute('height'), 10) || 0;
    if (known && known < MIN_IMAGE) return null;
    if (!known && attrW && attrH && Math.max(attrW, attrH) < MIN_IMAGE) return null;
    ctx.seenImages.add(key);
    const img = document.createElement('img');
    img.setAttribute('src', url);
    img.setAttribute('alt', node.getAttribute('alt') || '');
    img.setAttribute('loading', 'lazy');
    img.setAttribute('decoding', 'async');
    return img;
  }

  function sanitizeChildren(src, ctx, out) {
    const target = out || document.createDocumentFragment();
    Array.from(src.childNodes).forEach((child) => {
      const n = sanitizeNode(child, ctx);
      if (n) target.appendChild(n);
    });
    return target;
  }

  function sanitizeNode(node, ctx) {
    if (node.nodeType === 3) return document.createTextNode(node.nodeValue);
    if (node.nodeType !== 1) return null;
    const tag = node.tagName.toUpperCase();
    if (DROP_TAGS.has(tag)) return null;
    if (node.id && String(node.id).startsWith('blur-remover')) return null;
    if (ctx.live && node.matches && node.matches('.screen-reader-text, .sr-only, .visually-hidden')) return null;
    if (tag === 'IMG') return sanitizeImg(node, ctx);
    if (tag === 'PICTURE') {
      const img = node.querySelector('img');
      return img ? sanitizeImg(img, ctx) : null;
    }
    if (!ALLOWED_TAGS.has(tag)) {
      const frag = sanitizeChildren(node, ctx);
      if (BLOCK_TAGS.has(tag) && hasDirectText(node) && !hasBlockChild(node)) {
        const p = document.createElement('p');
        p.appendChild(frag);
        return p;
      }
      return frag;
    }
    if (tag === 'A') {
      const href = safeHref(node.getAttribute('href'));
      if (!href) return sanitizeChildren(node, ctx);
      const a = document.createElement('a');
      a.setAttribute('href', href);
      a.setAttribute('target', '_blank');
      a.setAttribute('rel', 'noopener noreferrer');
      if (node.getAttribute('title')) a.setAttribute('title', node.getAttribute('title'));
      sanitizeChildren(node, ctx, a);
      return a;
    }
    const el = document.createElement(tag.toLowerCase());
    (ATTRS['*'].concat(ATTRS[tag] || [])).forEach((attr) => {
      const v = node.getAttribute(attr);
      if (v !== null && v !== '') el.setAttribute(attr, v.slice(0, 500));
    });
    sanitizeChildren(node, ctx, el);
    if (['P', 'LI', 'H1', 'H2', 'H3', 'H4', 'H5', 'H6', 'BLOCKQUOTE', 'FIGURE', 'FIGCAPTION', 'DT', 'DD', 'UL', 'OL', 'STRONG', 'B', 'EM', 'I'].includes(tag) &&
      !el.textContent.trim() && !el.querySelector('img')) {
      return null;
    }
    return el;
  }

  // ---------------------------------------------------------------------------
  // Structure heuristics
  // ---------------------------------------------------------------------------

  function isInlineNode(n) {
    return n.nodeType === 3 || (n.nodeType === 1 && !BLOCK_TAGS.has(n.tagName.toUpperCase()) && !['IMG', 'TABLE', 'DIV'].includes(n.tagName.toUpperCase()));
  }

  /** Wraps loose inline runs at the container level in <p>, and loose images in <figure>. */
  function normalizeContainer(root) {
    let run = [];
    const flushRun = () => {
      if (run.length && run.some((n) => n.textContent.trim())) {
        const p = document.createElement('p');
        run[0].parentNode.insertBefore(p, run[0]);
        run.forEach((n) => p.appendChild(n));
      } else {
        run.forEach((n) => { if (n.nodeType === 3) n.remove(); });
      }
      run = [];
    };
    Array.from(root.childNodes).forEach((n) => {
      if (isInlineNode(n)) {
        run.push(n);
      } else {
        flushRun();
      }
    });
    flushRun();

    root.querySelectorAll('img').forEach((img) => {
      if (img.closest('figure')) return;
      const parent = img.parentElement;
      if (parent && parent.tagName === 'P' && !parent.textContent.trim() && parent.querySelectorAll('img').length === 1) {
        const fig = document.createElement('figure');
        parent.replaceWith(fig);
        fig.appendChild(img);
      } else if (parent === root) {
        const fig = document.createElement('figure');
        root.insertBefore(fig, img);
        fig.appendChild(img);
      }
    });
  }

  function textSplit(el) {
    let bold = '';
    let plain = '';
    const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
    let n;
    while ((n = walker.nextNode())) {
      const inBold = n.parentElement && n.parentElement.closest('b, strong');
      if (inBold && el.contains(inBold)) bold += n.nodeValue;
      else plain += n.nodeValue;
    }
    return { bold: norm(bold), plain: norm(plain) };
  }

  function isBoldOnly(el) {
    const { bold, plain } = textSplit(el);
    return !!bold && plain.replace(/[\s:.\-–—]/g, '') === '';
  }

  function startsWithBoldLabel(el) {
    const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
    let n;
    while ((n = walker.nextNode())) {
      if (!n.nodeValue.trim()) continue;
      const b = n.parentElement && n.parentElement.closest('b, strong');
      if (!b || !el.contains(b)) return false;
      const label = norm(b.textContent);
      const total = norm(el.textContent);
      const afterLabel = total.slice(total.indexOf(label) + label.length);
      const hasColon = label.endsWith(':') || /^\s*:/.test(afterLabel);
      return hasColon && afterLabel.replace(/^\s*:/, '').trim().length > 3 && label.length <= 80;
    }
    return false;
  }

  function isLabelPara(el) {
    if (el.tagName !== 'P') return false;
    const t = norm(el.textContent);
    return t.length > 1 && t.length <= 80 && t.endsWith(':');
  }

  function isIntro(el) {
    const t = norm(el.textContent);
    return t.endsWith(':') && (/^H[2-6]$/.test(el.tagName) || (el.tagName === 'P' && t.length > 80));
  }

  /** Collects a run of short paragraphs into label groups. */
  function collectRun(start) {
    const groups = [];
    let el = start;
    let mode = null;
    while (el) {
      if (isLabelPara(el)) {
        groups.push({ label: el, items: [] });
        mode = null;
        el = el.nextElementSibling;
        continue;
      }
      if (el.tagName !== 'P' || el.querySelector('img')) break;
      const t = norm(el.textContent);
      if (isIntro(el)) break;
      const m = startsWithBoldLabel(el) ? 'bold' : 'plain';
      if (mode && m !== mode) break;
      if (m === 'plain' && t.length > 160) break;
      if (m === 'bold' && t.length > 450) break;
      mode = m;
      if (!groups.length) groups.push({ label: null, items: [] });
      groups[groups.length - 1].items.push(el);
      el = el.nextElementSibling;
    }
    while (groups.length && groups[groups.length - 1].label && !groups[groups.length - 1].items.length) groups.pop();
    const total = groups.reduce((s, g) => s + g.items.length, 0);
    if (total < 2 || groups.some((g) => g.label && !g.items.length)) return null;
    return groups;
  }

  function moveChildren(from, to) {
    while (from.firstChild) to.appendChild(from.firstChild);
  }

  function buildList(groups) {
    const ul = document.createElement('ul');
    groups.forEach((g) => {
      if (!g.label) {
        g.items.forEach((p) => {
          const li = document.createElement('li');
          moveChildren(p, li);
          ul.appendChild(li);
        });
        return;
      }
      const li = document.createElement('li');
      const strong = document.createElement('strong');
      strong.textContent = norm(g.label.textContent);
      li.appendChild(strong);
      const sub = document.createElement('ul');
      g.items.forEach((p) => {
        const item = document.createElement('li');
        moveChildren(p, item);
        sub.appendChild(item);
      });
      li.appendChild(sub);
      ul.appendChild(li);
    });
    return ul;
  }

  function convertParagraphRuns(root) {
    let el = root.firstElementChild;
    while (el) {
      let start = null;
      if (isLabelPara(el)) start = el;
      else if (/^(P|H[2-6])$/.test(el.tagName) && norm(el.textContent).endsWith(':')) start = el.nextElementSibling;
      const groups = start ? collectRun(start) : null;
      if (!groups) {
        el = el.nextElementSibling;
        continue;
      }
      const first = groups[0].label || groups[0].items[0];
      const all = [];
      groups.forEach((g) => { if (g.label) all.push(g.label); all.push(...g.items); });
      const ul = buildList(groups);
      first.parentNode.insertBefore(ul, first);
      all.forEach((n) => n.remove());
      el = ul.nextElementSibling;
    }
  }

  function promoteBoldParagraphs(root) {
    let prevLevel = 2;
    Array.from(root.children).forEach((el) => {
      const m = /^H([1-6])$/.exec(el.tagName);
      if (m) {
        prevLevel = Number(m[1]);
        return;
      }
      if (el.tagName !== 'P') return;
      const t = norm(el.textContent);
      if (!t || t.length > 90 || el.querySelector('img') || !isBoldOnly(el)) return;
      const level = Math.min(Math.max(prevLevel + 1, 3), 4);
      const h = document.createElement(`h${level}`);
      h.textContent = t.replace(/:$/, '');
      el.replaceWith(h);
    });
  }

  function restructure(root, title) {
    normalizeContainer(root);
    // Drop a leading heading (or any h1) that repeats the title.
    const first = root.firstElementChild;
    if (first && /^H[1-3]$/.test(first.tagName) && similarText(first.textContent, title)) first.remove();
    root.querySelectorAll('h1').forEach((h) => { if (similarText(h.textContent, title)) h.remove(); });
    // Layout leftovers such as step numbers ("02") or single characters.
    root.querySelectorAll('p').forEach((p) => {
      const t = norm(p.textContent);
      if (!p.querySelector('img') && (t.length <= 2 || /^\d+$/.test(t))) p.remove();
    });
    convertParagraphRuns(root);
    promoteBoldParagraphs(root);
    root.querySelectorAll('table').forEach((t) => {
      if (t.parentElement && t.parentElement.classList.contains('table-wrap')) return;
      const wrap = document.createElement('div');
      wrap.className = 'table-wrap';
      wrap.setAttribute('tabindex', '0');
      wrap.setAttribute('role', 'region');
      wrap.setAttribute('aria-label', 'Table');
      t.replaceWith(wrap);
      wrap.appendChild(t);
    });
    // Remaining h1s become h2 (the page title is the only h1).
    root.querySelectorAll('h1').forEach((h) => {
      const h2 = document.createElement('h2');
      moveChildren(h, h2);
      h.replaceWith(h2);
    });
  }

  // ---------------------------------------------------------------------------
  // Extraction: article mode (Readability)
  // ---------------------------------------------------------------------------

  /**
   * Unwraps heading wrappers such as Wikipedia's <div class="mw-heading"><h2/><span class="mw-editsection"/></div>
   * or CMS "heading + permalink button" blocks. Readability scores those wrapper divs as boilerplate and
   * drops them, losing most section headings.
   */
  function unwrapHeadingWrappers(doc) {
    doc.querySelectorAll('.mw-editsection, .editsection, .headerlink, .anchor-link, a.anchor[aria-hidden="true"]').forEach((n) => n.remove());
    doc.querySelectorAll('h1, h2, h3, h4, h5, h6').forEach((h) => {
      const wrap = h.parentElement;
      if (!wrap || wrap.tagName !== 'DIV' || wrap.children.length > 3) return;
      const others = Array.from(wrap.children).filter((c) => c !== h);
      const onlyChrome = others.every((c) => /^(A|BUTTON|SPAN|SVG)$/i.test(c.tagName) && (c.textContent || '').trim().length <= 12);
      const textOutside = (wrap.textContent || '').trim().length - (h.textContent || '').trim().length;
      if (onlyChrome && textOutside <= 12) {
        others.forEach((c) => c.remove());
        wrap.replaceWith(h);
      }
    });
  }

  function preprocessClone(doc) {
    doc.querySelectorAll('[id^="blur-remover"]').forEach((n) => n.remove());
    unwrapHeadingWrappers(doc);
    doc.querySelectorAll('noscript').forEach((ns) => {
      const html = ns.textContent || '';
      if (!/<img/i.test(html)) return;
      const m = /<img[^>]+src=["']([^"']+)["'][^>]*>/i.exec(html);
      if (!m) return;
      const altM = /alt=["']([^"']*)["']/i.exec(m[0]);
      const prev = ns.previousElementSibling;
      if (prev && prev.tagName === 'IMG') {
        if (isPlaceholder(prev.getAttribute('src')) && !resolveImgSrc(prev)) prev.setAttribute('src', absUrl(m[1]));
      } else {
        const img = doc.createElement('img');
        img.setAttribute('src', absUrl(m[1]));
        if (altM) img.setAttribute('alt', altM[1]);
        ns.replaceWith(img);
      }
    });
    doc.querySelectorAll('img').forEach((img) => {
      const url = resolveImgSrc(img);
      if (url) img.setAttribute('src', url);
      ['srcset', 'sizes', 'loading', 'data-srcset', 'data-lazy-srcset'].forEach((a) => img.removeAttribute(a));
    });
    doc.querySelectorAll('picture source').forEach((s) => s.remove());
  }

  /**
   * Readability's cleaning often removes image widgets (e.g. page builders wrap images in
   * link-only divs). Put large images from the article region back after the paragraph that
   * precedes them in the original page.
   */
  function reinsertDroppedImages(body, ctx) {
    const paras = Array.from(body.querySelectorAll('p')).filter((p) => norm(p.textContent).length > 60);
    if (paras.length < 2) return;
    const livePs = Array.from(document.querySelectorAll('p'));
    const findLive = (text) => {
      const key = text.slice(0, 60);
      return livePs.find((p) => norm(p.textContent).startsWith(key));
    };
    const a = findLive(norm(paras[0].textContent));
    const b = findLive(norm(paras[paras.length - 1].textContent));
    if (!a || !b) return;
    let root = a;
    while (root && !root.contains(b)) root = root.parentElement;
    if (!root) return;

    const blocks = Array.from(body.querySelectorAll('p, h2, h3, h4, h5, h6, li'));
    root.querySelectorAll('img').forEach((img) => {
      const url = resolveImgSrc(img);
      if (!url) return;
      const key = imageKey(url);
      if (ctx.seenImages.has(key) || (ctx.sizeMap.get(key) || 0) < 300) return;
      const walker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT);
      walker.currentNode = img;
      let prev = walker.previousNode();
      while (prev && !(/^(P|H[1-6]|LI)$/.test(prev.tagName) && norm(prev.textContent).length > 20)) prev = walker.previousNode();
      if (!prev) return;
      const anchorKey = norm(prev.textContent).slice(0, 60);
      let target = blocks.find((el) => norm(el.textContent).startsWith(anchorKey));
      if (!target) return;
      while (target.parentElement && target.parentElement !== body) target = target.parentElement;
      const clean = sanitizeImg(img, ctx);
      if (!clean) return;
      const fig = document.createElement('figure');
      fig.appendChild(clean);
      target.after(fig);
    });
  }

  function extractArticle(sizeMap) {
    if (typeof Readability !== 'function') return null;
    let article = null;
    try {
      const clone = document.cloneNode(true);
      preprocessClone(clone);
      article = new Readability(clone, { charThreshold: 300, keepClasses: false }).parse();
    } catch (e) {
      console.warn('[BlurRemover] Readability failed:', e);
      return null;
    }
    if (!article || !article.content) return null;
    const parsed = new DOMParser().parseFromString(article.content, 'text/html');
    const title = pickTitle(article.title);
    const body = document.createElement('div');
    const ctx = { sizeMap, seenImages: new Set(), live: false };
    sanitizeChildren(parsed.body, ctx, body);
    normalizeContainer(body);
    reinsertDroppedImages(body, ctx);
    restructure(body, title);
    return {
      mode: 'article',
      title,
      byline: norm(article.byline || ''),
      date: publishedDate(article),
      site: norm(article.siteName || '') || siteName(),
      body,
      textLength: norm(body.textContent).length
    };
  }

  // ---------------------------------------------------------------------------
  // Extraction: full page mode (live document walk)
  // ---------------------------------------------------------------------------

  function linkDensity(el) {
    const total = norm(el.textContent).length || 1;
    let links = 0;
    el.querySelectorAll('a').forEach((a) => { links += norm(a.textContent).length; });
    return links / total;
  }

  /** Slide-out menus / side panels parked outside the viewport horizontally. */
  function isOffCanvas(el) {
    const r = el.getBoundingClientRect();
    if (!r.width && !r.height) return false;
    if (r.right > 0 && r.left < window.innerWidth) return false;
    let n = el;
    while (n && n !== document.body) {
      const pos = getComputedStyle(n).position;
      if (pos === 'fixed' || pos === 'sticky') return true;
      n = n.parentElement;
    }
    return false;
  }

  function extractFull(sizeMap) {
    const title = pickTitle('');
    const body = document.createElement('div');
    const ctx = { sizeMap, seenImages: new Set(), live: true };
    const seen = new Set();
    const controlled = new Set();
    document.querySelectorAll('[aria-controls]').forEach((e) => {
      (e.getAttribute('aria-controls') || '').split(/\s+/).forEach((id) => id && controlled.add(id));
    });

    const emit = (node, key) => {
      if (!node) return;
      const k = (key || norm(node.textContent)).toLowerCase();
      // Headings may legitimately repeat (e.g. "Benefits" in two sections), so only dedupe content.
      if (k && /^H[1-6]$/.test(node.tagName)) {
        body.appendChild(node);
        return;
      }
      if (k) {
        if (seen.has(k)) return;
        seen.add(k);
      } else if (!(node.querySelector && node.querySelector('img')) && node.tagName !== 'IMG') {
        return;
      }
      body.appendChild(node);
    };

    const isTrigger = (el) => {
      if (!el.matches(ACCORDION_TRIGGER)) return false;
      const t = norm(el.textContent);
      if (t.length < 3 || t.length > 300) return false;
      const id = el.getAttribute('aria-controls');
      if (id) {
        try {
          if (el.querySelector('#' + CSS.escape(id.split(/\s+/)[0]))) return false;
        } catch (e) { /* ignore */ }
      }
      return !hasBlockChild(el) || el.tagName === 'SUMMARY' || el.children.length <= 2;
    };

    const isPanel = (el) => el.matches(ACCORDION_PANEL) || (el.id && controlled.has(el.id)) ||
      (el.parentElement && el.parentElement.tagName === 'DETAILS' && el.tagName !== 'SUMMARY');

    const skip = (el) => {
      if (el.matches(FULL_SKIP)) return true;
      const tag = el.tagName;
      if ((tag === 'HEADER' || tag === 'FOOTER') && !el.closest('main, article, [role="main"]')) return true;
      if (tag === 'BUTTON' && !el.matches(ACCORDION_TRIGGER)) return true;
      if (el.getAttribute('aria-hidden') === 'true' && !isPanel(el)) return true;
      return false;
    };

    const walk = (node, forced) => {
      Array.from(node.childNodes).forEach((child) => {
        if (child.nodeType === 3) {
          const t = norm(child.nodeValue);
          if (t.length > 40) {
            const p = document.createElement('p');
            p.textContent = t;
            emit(p);
          }
          return;
        }
        if (child.nodeType !== 1 || skip(child)) return;
        const tag = child.tagName.toUpperCase();
        const panel = isPanel(child) || tag === 'DETAILS';
        const f = forced || panel;
        if (!f && !isVisible(child)) return;
        if (!f && isOffCanvas(child)) return;

        if (isTrigger(child)) {
          const h = document.createElement('h3');
          h.textContent = norm(child.textContent);
          emit(h);
          return;
        }
        if (FULL_EMIT.has(tag)) {
          if ((tag === 'UL' || tag === 'OL') && child.children.length > 3 && linkDensity(child) > 0.6) return;
          const clean = sanitizeNode(child, ctx);
          if (clean && clean.nodeType === 1) emit(clean);
          return;
        }
        if (tag === 'IMG' || tag === 'PICTURE') {
          const img = sanitizeNode(child, ctx);
          if (img) {
            const fig = document.createElement('figure');
            fig.appendChild(img);
            emit(fig, 'img:' + img.getAttribute('src'));
          }
          return;
        }
        if (!hasBlockChild(child)) {
          const t = norm(child.textContent);
          if (t.length >= 40 && linkDensity(child) < 0.6) {
            const p = document.createElement('p');
            sanitizeChildren(child, ctx, p);
            emit(p);
            return;
          }
          if (child.querySelector('img, picture')) walk(child, f);
          return;
        }
        walk(child, f);
      });
    };

    walk(document.body, false);
    restructure(body, title);
    return {
      mode: 'full',
      title,
      byline: '',
      date: publishedDate(null),
      site: siteName(),
      body,
      textLength: norm(body.textContent).length
    };
  }

  function getData(mode) {
    if (state.cache[mode]) return state.cache[mode];
    if (!state.cache.sizeMap) state.cache.sizeMap = buildImageSizeMap();
    const data = mode === 'article' ? extractArticle(state.cache.sizeMap) : extractFull(state.cache.sizeMap);
    state.cache[mode] = data;
    return data;
  }

  // ---------------------------------------------------------------------------
  // Styles
  // ---------------------------------------------------------------------------

  const CSS_TEXT = `
    :host { all: initial; }
    * { box-sizing: border-box; }
    [hidden] { display: none !important; }

    .rv-viewport {
      position: fixed; inset: 0; overflow-y: auto; overflow-x: hidden;
      overscroll-behavior: contain;
      background: var(--bg); color: var(--fg);
      font-family: system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif;
      scrollbar-width: thin; scrollbar-color: var(--muted) transparent;
      outline: none;
      -webkit-font-smoothing: antialiased;
    }
    .theme-light { --bg:#fbfbf9; --fg:#1f2328; --muted:#5b6370; --accent:#4f46e5; --link:#2349c4; --toolbar:#f1f1ec; --panel:#ffffff; --border:rgba(0,0,0,.12); --hl:#fde68a; --code:#eef0f2; --tts:#c7d2fe; }
    .theme-sepia { --bg:#fbf0d9; --fg:#3a2d21; --muted:#6f5b46; --accent:#b45309; --link:#8a4410; --toolbar:#f3e6ce; --panel:#fdf6e7; --border:rgba(58,45,33,.18); --hl:#f3cf7a; --code:#f1e3c6; --tts:#f2c88f; }
    .theme-dark { --bg:#11141b; --fg:#d6dae3; --muted:#8b93a3; --accent:#8b9cff; --link:#93b4ff; --toolbar:#171b24; --panel:#191e28; --border:rgba(255,255,255,.1); --hl:rgba(250,204,21,.32); --code:#1b2030; --tts:rgba(139,156,255,.4); }
    .theme-oled { --bg:#000000; --fg:#cfd3da; --muted:#7c8494; --accent:#8b9cff; --link:#93b4ff; --toolbar:#0b0b0b; --panel:#0e0e0e; --border:rgba(255,255,255,.12); --hl:rgba(250,204,21,.3); --code:#111111; --tts:rgba(139,156,255,.4); }

    .rv-viewport::-webkit-scrollbar { width: 8px; }
    .rv-viewport::-webkit-scrollbar-thumb { background: var(--muted); border-radius: 8px; }

    :focus-visible { outline: 2px solid var(--accent); outline-offset: 2px; }

    .rv-progress { position: fixed; top: 0; left: 0; right: 0; height: 3px; z-index: 30; pointer-events: none; }
    .rv-progress-bar { height: 100%; width: 0; background: var(--accent); }

    .rv-toolbar {
      position: sticky; top: 0; z-index: 20;
      display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 8px;
      padding: 8px 16px; background: var(--toolbar); border-bottom: 1px solid var(--border);
      transition: transform .2s ease;
    }
    .rv-toolbar.rv-hidden { transform: translateY(-110%); }
    .rv-group { display: flex; flex-wrap: wrap; align-items: center; gap: 6px; }
    .rv-btn, .rv-seg button, .rv-settings button, .rv-pop button, .rv-tabs button, .rv-note-actions button {
      font: 600 12.5px/1.2 system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif;
      color: var(--fg); background: transparent; border: 1px solid var(--border);
      padding: 6px 10px; border-radius: 7px; cursor: pointer; white-space: nowrap;
    }
    .rv-btn:hover, .rv-seg button:hover, .rv-settings button:hover, .rv-pop button:hover, .rv-tabs button:hover { border-color: var(--accent); }
    .rv-btn[aria-pressed="true"], .rv-seg button[aria-pressed="true"], .rv-settings button[aria-pressed="true"], .rv-tabs button[aria-selected="true"] {
      background: var(--accent); border-color: var(--accent); color: var(--bg);
    }
    .rv-btn:disabled { opacity: .45; cursor: not-allowed; }
    .rv-seg { display: inline-flex; }
    .rv-seg button { border-radius: 0; }
    .rv-seg button:first-child { border-radius: 7px 0 0 7px; }
    .rv-seg button:last-child { border-radius: 0 7px 7px 0; border-left: none; }

    .rv-settings {
      position: fixed; top: 56px; right: 16px; z-index: 40; width: 300px;
      background: var(--panel); color: var(--fg); border: 1px solid var(--border); border-radius: 12px;
      padding: 14px; box-shadow: 0 12px 32px rgba(0,0,0,.25);
      font: 13px/1.4 system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif;
      display: flex; flex-direction: column; gap: 12px;
    }
    .rv-settings label, .rv-settings .rv-row-label { font-weight: 700; font-size: 11px; text-transform: uppercase; letter-spacing: .04em; color: var(--muted); display: block; margin-bottom: 6px; }
    .rv-row { display: flex; align-items: center; gap: 6px; flex-wrap: wrap; }
    .rv-settings select { width: 100%; padding: 6px 8px; border-radius: 7px; border: 1px solid var(--border); background: var(--bg); color: var(--fg); font: inherit; }
    .rv-settings input[type="range"] { width: 100%; accent-color: var(--accent); }
    .rv-value { min-width: 38px; text-align: center; font-weight: 700; }

    .rv-layout { display: flex; align-items: flex-start; min-height: calc(100vh - 60px); }
    .rv-sidebar {
      position: sticky; top: var(--rv-toolbar-h, 52px); flex: none; width: 270px;
      max-height: calc(100vh - var(--rv-toolbar-h, 52px)); overflow-y: auto;
      padding: 16px 12px 40px 16px; border-right: 1px solid var(--border);
      font: 13px/1.45 system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif;
      scrollbar-width: thin;
    }
    .rv-tabs { display: flex; gap: 6px; margin-bottom: 12px; }
    .rv-toc ol { list-style: none; margin: 0; padding: 0; }
    .rv-toc a { display: block; color: var(--muted); text-decoration: none; padding: 4px 8px; border-left: 2px solid transparent; border-radius: 0 6px 6px 0; }
    .rv-toc a:hover { color: var(--fg); }
    .rv-toc a[aria-current="true"] { color: var(--fg); border-left-color: var(--accent); background: color-mix(in srgb, var(--accent) 12%, transparent); font-weight: 600; }
    .rv-toc .lvl-3 { padding-left: 20px; }
    .rv-toc .lvl-4 { padding-left: 32px; font-size: 12px; }
    .rv-empty { color: var(--muted); font-style: italic; }
    .rv-note { border: 1px solid var(--border); border-radius: 8px; padding: 8px; margin-bottom: 8px; }
    .rv-note blockquote { margin: 0 0 6px; padding-left: 8px; border-left: 3px solid var(--hl); color: var(--fg); }
    .rv-note p { margin: 0 0 6px; color: var(--muted); white-space: pre-wrap; }
    .rv-note-actions { display: flex; gap: 6px; }
    .rv-note-actions button { padding: 3px 8px; font-size: 11.5px; }
    .rv-library { margin-top: 14px; }
    .rv-library button { background: transparent; border: 0; padding: 0; color: var(--accent); font: inherit; font-size: 12.5px; text-decoration: underline; cursor: pointer; }
    .rv-library button:focus-visible { outline: 2px solid var(--accent); outline-offset: 2px; border-radius: 3px; }

    .rv-main { flex: 1; min-width: 0; }
    .rv-article {
      max-width: var(--rv-width, 68ch); margin: 0 auto; padding: 32px 24px 120px;
      font-size: var(--rv-font-size, 18px); line-height: var(--rv-line-height, 1.7);
      font-family: var(--rv-font, Georgia, serif);
      overflow-wrap: break-word;
    }
    .rv-meta { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; font: 600 12.5px/1.4 system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif; color: var(--muted); margin-bottom: 14px; }
    .rv-meta .rv-site { color: var(--accent); text-transform: uppercase; letter-spacing: .05em; }
    .rv-title { font-size: 2em; line-height: 1.2; margin: 0 0 .4em; font-weight: 800; letter-spacing: -.01em; }
    .rv-byline { color: var(--muted); font-size: .85em; margin-bottom: 1.6em; }
    .rv-notice { font: 13px/1.4 system-ui, sans-serif; color: var(--muted); border: 1px dashed var(--border); border-radius: 8px; padding: 8px 12px; margin-bottom: 1.4em; }

    .rv-body > :first-child { margin-top: 0; }
    .rv-body p, .rv-body ul, .rv-body ol, .rv-body dl, .rv-body blockquote, .rv-body pre, .rv-body figure, .rv-body .table-wrap {
      margin: 0 0 calc(var(--rv-para, 1) * 1em);
    }
    .rv-body h1, .rv-body h2, .rv-body h3, .rv-body h4, .rv-body h5, .rv-body h6 {
      line-height: 1.25; margin: 1.8em 0 .5em; font-weight: 700; scroll-margin-top: 80px; color: var(--fg);
    }
    .rv-body h2 { font-size: 1.6em; }
    .rv-body h3 { font-size: 1.3em; }
    .rv-body h4 { font-size: 1.1em; }
    .rv-body h5, .rv-body h6 { font-size: 1em; text-transform: uppercase; font-variant: small-caps; letter-spacing: .04em; }
    .rv-body a { color: var(--link); text-decoration: underline; text-underline-offset: .2em; text-decoration-thickness: 1px; }
    .rv-body a:hover { text-decoration-thickness: 2px; }
    .rv-body ul, .rv-body ol { padding-left: 1.4em; }
    .rv-body li + li { margin-top: .35em; }
    .rv-body li > ul, .rv-body li > ol { margin: .35em 0 0; }
    .rv-body li::marker { color: var(--accent); }
    .rv-body blockquote { border-left: 4px solid var(--accent); padding: .2em 0 .2em 1em; color: var(--fg); font-style: italic; }
    .rv-body pre { background: var(--code); padding: 14px; border-radius: 8px; overflow-x: auto; font-size: .82em; line-height: 1.5; }
    .rv-body code { font-family: ui-monospace, 'Cascadia Code', Consolas, monospace; font-size: .88em; background: var(--code); padding: .1em .3em; border-radius: 4px; }
    .rv-body pre code { background: none; padding: 0; }
    .rv-body figure { text-align: center; }
    .rv-body img { display: block; margin: 0 auto; max-width: 100%; max-height: 70vh; height: auto; object-fit: contain; border-radius: 6px; cursor: zoom-in; }
    .rv-body figcaption { font-size: .8em; color: var(--muted); margin-top: .5em; }
    .rv-body hr { border: none; border-top: 1px solid var(--border); margin: 2em 0; }
    .rv-body .table-wrap { overflow-x: auto; }
    .rv-body table { border-collapse: collapse; width: 100%; font-size: .9em; line-height: 1.45; }
    .rv-body th, .rv-body td { border: 1px solid var(--border); padding: .45em .65em; text-align: left; vertical-align: top; }
    .rv-body th { background: var(--code); }
    .rv-body dt { font-weight: 700; }
    .rv-body dd { margin: 0 0 .6em 1.2em; }

    mark.rv-hl { background: var(--hl); color: inherit; border-radius: 2px; padding: 0 .05em; cursor: pointer; }
    mark.rv-hl.rv-has-note { border-bottom: 2px dotted var(--accent); }
    .rv-speaking { background: color-mix(in srgb, var(--accent) 9%, transparent); border-radius: 4px; box-shadow: 0 0 0 4px color-mix(in srgb, var(--accent) 9%, transparent); }
    ::highlight(rv-tts) { background-color: var(--tts); color: var(--fg); }
    ::selection { background: color-mix(in srgb, var(--accent) 30%, transparent); }

    .rv-pop {
      position: fixed; z-index: 50; display: flex; flex-direction: column; gap: 6px; max-width: 320px;
      background: var(--panel); color: var(--fg); border: 1px solid var(--border); border-radius: 10px;
      padding: 8px; box-shadow: 0 10px 28px rgba(0,0,0,.28);
      font: 13px/1.4 system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif;
    }
    .rv-pop .rv-row { gap: 6px; }
    .rv-pop textarea { width: 280px; min-height: 70px; resize: vertical; font: inherit; color: var(--fg); background: var(--bg); border: 1px solid var(--border); border-radius: 7px; padding: 6px; }
    .rv-pop p { margin: 0; white-space: pre-wrap; max-width: 280px; }

    .rv-lightbox { position: fixed; inset: 0; z-index: 60; background: rgba(0,0,0,.88); display: flex; align-items: center; justify-content: center; cursor: zoom-out; }
    .rv-lightbox img { max-width: 95vw; max-height: 95vh; object-fit: contain; }

    @media (max-width: 900px) {
      .rv-sidebar { position: fixed; top: 0; bottom: 0; left: 0; z-index: 45; max-height: none; background: var(--panel); box-shadow: 0 0 30px rgba(0,0,0,.35); padding-top: 20px; }
      .rv-label { display: none; }
      .rv-article { padding: 20px 16px 100px; }
    }
    @media (prefers-reduced-motion: reduce) {
      .rv-toolbar { transition: none; }
    }
  `;

  const EXPORT_CSS = `
    body { margin: 0; background: #fbfbf9; color: #1f2328; font: 18px/1.7 Charter, Georgia, 'Times New Roman', serif; }
    article { max-width: 68ch; margin: 0 auto; padding: 40px 24px 80px; }
    h1 { font-size: 2em; line-height: 1.2; margin: 0 0 .4em; }
    h2 { font-size: 1.6em; } h3 { font-size: 1.3em; } h4 { font-size: 1.1em; }
    h2, h3, h4, h5, h6 { line-height: 1.25; margin: 1.8em 0 .5em; }
    p, ul, ol, blockquote, pre, figure, table { margin: 0 0 1em; }
    a { color: #2349c4; text-underline-offset: .2em; }
    img { max-width: 100%; height: auto; display: block; margin: 0 auto; }
    figcaption, .meta { color: #5b6370; font-size: .85em; }
    blockquote { border-left: 4px solid #4f46e5; margin-left: 0; padding-left: 1em; font-style: italic; }
    pre { background: #eef0f2; padding: 12px; overflow-x: auto; }
    table { border-collapse: collapse; width: 100%; } th, td { border: 1px solid #ccc; padding: .4em .6em; text-align: left; }
    mark { background: #fde68a; }
    @media print { body { background: #fff; } article { padding: 0; } a { color: inherit; } }
  `;

  // ---------------------------------------------------------------------------
  // UI
  // ---------------------------------------------------------------------------

  const TEMPLATE = `
    <div class="rv-viewport" tabindex="-1" role="dialog" aria-modal="true" aria-label="Reader View">
      <div class="rv-progress" aria-hidden="true"><div class="rv-progress-bar"></div></div>
      <div class="rv-toolbar" role="toolbar" aria-label="Reader View controls">
        <div class="rv-group">
          <button class="rv-btn" data-act="sidebar" aria-pressed="false" aria-label="Show contents and notes" title="Contents & notes">☰ <span class="rv-label">Contents</span></button>
          <div class="rv-seg" role="group" aria-label="Extraction mode">
            <button data-act="mode" data-mode="article" aria-pressed="true" title="Main article only">Article</button>
            <button data-act="mode" data-mode="full" aria-pressed="false" title="Everything on the page, accordions expanded">Full page</button>
          </div>
        </div>
        <div class="rv-group">
          <button class="rv-btn" data-act="settings" aria-haspopup="dialog" aria-expanded="false" aria-label="Text and theme settings" title="Text & theme">Aa</button>
          <button class="rv-btn" data-act="tts" aria-label="Listen: read the article aloud" title="Listen">▶ <span class="rv-label">Listen</span></button>
          <button class="rv-btn" data-act="tts-stop" aria-label="Stop reading aloud" title="Stop" hidden>■</button>
        </div>
        <div class="rv-group">
          <button class="rv-btn" data-act="copy" aria-label="Copy as Markdown" title="Copy as Markdown">⧉ <span class="rv-label">Copy MD</span></button>
          <button class="rv-btn" data-act="save" aria-label="Save as HTML file" title="Save HTML">⤓ <span class="rv-label">Save</span></button>
          <button class="rv-btn" data-act="print" aria-label="Print or save as PDF" title="Print / PDF">⎙ <span class="rv-label">Print</span></button>
          <button class="rv-btn" data-act="auto" aria-pressed="false" aria-label="Always open Reader View on this site" title="Auto-open on this site">★ <span class="rv-label">Auto-open</span></button>
          <button class="rv-btn" data-act="close" aria-label="Close Reader View (Esc)" title="Close (Esc)">✕</button>
        </div>
      </div>

      <div class="rv-settings" role="dialog" aria-label="Reader settings" hidden>
        <div>
          <span class="rv-row-label">Font size</span>
          <div class="rv-row">
            <button data-pref-act="font-dec" aria-label="Decrease font size">A−</button>
            <span class="rv-value" data-out="fontSize">18</span>
            <button data-pref-act="font-inc" aria-label="Increase font size">A+</button>
          </div>
        </div>
        <div>
          <label for="rvFont">Font</label>
          <select id="rvFont" data-pref="fontFamily">
            <option value="serif">Serif</option>
            <option value="sans">Sans-serif</option>
            <option value="mono">Monospace</option>
            <option value="atkinson">Atkinson Hyperlegible</option>
            <option value="dyslexic">OpenDyslexic</option>
          </select>
        </div>
        <div>
          <span class="rv-row-label">Theme</span>
          <div class="rv-row" role="radiogroup" aria-label="Theme">
            <button data-theme="system" aria-pressed="false">System</button>
            <button data-theme="light" aria-pressed="false">Light</button>
            <button data-theme="sepia" aria-pressed="false">Sepia</button>
            <button data-theme="dark" aria-pressed="false">Dark</button>
            <button data-theme="oled" aria-pressed="false">OLED</button>
          </div>
        </div>
        <div>
          <span class="rv-row-label">Width</span>
          <div class="rv-row" role="radiogroup" aria-label="Content width">
            <button data-width="narrow" aria-pressed="false">Narrow</button>
            <button data-width="medium" aria-pressed="false">Medium</button>
            <button data-width="wide" aria-pressed="false">Wide</button>
          </div>
        </div>
        <div>
          <label for="rvLine">Line height <span data-out="lineHeight"></span></label>
          <input id="rvLine" type="range" min="1.2" max="2.4" step="0.1" data-pref="lineHeight">
        </div>
        <div>
          <label for="rvPara">Paragraph spacing <span data-out="paragraphSpacing"></span></label>
          <input id="rvPara" type="range" min="0.4" max="2.5" step="0.1" data-pref="paragraphSpacing">
        </div>
      </div>

      <div class="rv-layout">
        <aside class="rv-sidebar" aria-label="Contents and notes" hidden>
          <div class="rv-tabs" role="tablist">
            <button role="tab" data-tab="toc" aria-selected="true">Contents</button>
            <button role="tab" data-tab="notes" aria-selected="false">Notes <span data-out="noteCount"></span></button>
          </div>
          <nav class="rv-toc" aria-label="Table of contents"></nav>
          <div class="rv-notes" hidden></div>
        </aside>
        <main class="rv-main">
          <article class="rv-article">
            <div class="rv-meta"></div>
            <h1 class="rv-title"></h1>
            <div class="rv-byline" hidden></div>
            <div class="rv-notice" hidden></div>
            <div class="rv-body"></div>
          </article>
        </main>
      </div>

      <div class="rv-pop" hidden></div>
      <div class="rv-lightbox" role="dialog" aria-label="Image preview" hidden><img alt=""></div>
    </div>
  `;

  function buildUi() {
    const existing = document.getElementById(ROOT_ID);
    if (existing) existing.remove();

    const host = document.createElement('div');
    host.id = ROOT_ID;
    ['all:initial', 'position:fixed', 'inset:0', 'z-index:2147483647', 'display:block'].forEach((d) => {
      const [k, v] = d.split(':');
      host.style.setProperty(k, v, 'important');
    });
    // Closed: highlights and notes are personal, page scripts must not be able to read them.
    const shadow = host.attachShadow({ mode: 'closed' });
    const style = document.createElement('style');
    style.textContent = CSS_TEXT;
    shadow.appendChild(style);
    const wrap = document.createElement('div');
    // eslint-disable-next-line no-unsanitized/property -- audited: static markup / escaped or sanitized values only
    wrap.innerHTML = TEMPLATE;
    shadow.appendChild(wrap.firstElementChild);
    (document.body || document.documentElement).appendChild(host);

    state.host = host;
    state.shadow = shadow;
    const q = (s) => shadow.querySelector(s);
    state.els = {
      viewport: q('.rv-viewport'),
      progress: q('.rv-progress-bar'),
      toolbar: q('.rv-toolbar'),
      settings: q('.rv-settings'),
      sidebar: q('.rv-sidebar'),
      toc: q('.rv-toc'),
      notes: q('.rv-notes'),
      article: q('.rv-article'),
      meta: q('.rv-meta'),
      title: q('.rv-title'),
      byline: q('.rv-byline'),
      notice: q('.rv-notice'),
      body: q('.rv-body'),
      pop: q('.rv-pop'),
      lightbox: q('.rv-lightbox')
    };
    wireUi();
  }

  function btn(act) {
    return state.shadow.querySelector(`[data-act="${act}"]`);
  }

  function wireUi() {
    const { viewport, toolbar, settings, body, lightbox, sidebar } = state.els;

    // Key isolation: nothing typed in the reader reaches the page's shortcut handlers.
    ['keydown', 'keyup', 'keypress'].forEach((type) => {
      state.host.addEventListener(type, (e) => {
        e.stopPropagation();
        if (type === 'keydown') onKeyDown(e);
      });
    });

    toolbar.addEventListener('click', (e) => {
      const b = e.target.closest('button[data-act]');
      if (!b) return;
      const act = b.getAttribute('data-act');
      if (act === 'close') close();
      else if (act === 'sidebar') toggleSidebar();
      else if (act === 'mode') setMode(b.getAttribute('data-mode'));
      else if (act === 'settings') toggleSettings();
      else if (act === 'tts') ttsToggle();
      else if (act === 'tts-stop') ttsStop();
      else if (act === 'copy') copyMarkdown(b);
      else if (act === 'save') saveHtml();
      else if (act === 'print') printReader();
      else if (act === 'auto') toggleAutoOpen(b);
    });
    toolbar.addEventListener('focusin', () => toolbar.classList.remove('rv-hidden'));

    settings.addEventListener('click', (e) => {
      const b = e.target.closest('button');
      if (!b) return;
      if (b.dataset.prefAct === 'font-dec') updatePrefs({ fontSize: Math.max(12, state.prefs.fontSize - 1) });
      else if (b.dataset.prefAct === 'font-inc') updatePrefs({ fontSize: Math.min(32, state.prefs.fontSize + 1) });
      else if (b.dataset.theme) updatePrefs({ theme: b.dataset.theme });
      else if (b.dataset.width) updatePrefs({ width: b.dataset.width });
    });
    settings.addEventListener('input', (e) => {
      const key = e.target.getAttribute('data-pref');
      if (!key) return;
      const value = key === 'fontFamily' ? e.target.value : Number(e.target.value);
      updatePrefs({ [key]: value });
    });

    sidebar.addEventListener('click', (e) => {
      const tab = e.target.closest('[data-tab]');
      if (tab) {
        showTab(tab.getAttribute('data-tab'));
        return;
      }
      const link = e.target.closest('a[data-target]');
      if (link) {
        e.preventDefault();
        const target = state.shadow.getElementById(link.getAttribute('data-target'));
        if (target) {
          target.scrollIntoView({ block: 'start', behavior: prefersReducedMotion() ? 'auto' : 'smooth' });
          if (window.innerWidth <= 900) toggleSidebar(false);
        }
        return;
      }
      const jump = e.target.closest('[data-jump]');
      if (jump) {
        const mark = body.querySelector(`mark[data-hl="${CSS.escape(jump.getAttribute('data-jump'))}"]`);
        if (mark) mark.scrollIntoView({ block: 'center', behavior: prefersReducedMotion() ? 'auto' : 'smooth' });
        return;
      }
      if (e.target.closest('[data-library]')) {
        if (Dom) Dom.sendMessage({ type: 'OPEN_OPTIONS', section: 'highlights' });
        return;
      }
      const del = e.target.closest('[data-del]');
      if (del) removeHighlight(del.getAttribute('data-del'));
      const edit = e.target.closest('[data-edit]');
      if (edit) {
        const mark = body.querySelector(`mark[data-hl="${CSS.escape(edit.getAttribute('data-edit'))}"]`);
        if (mark) showMarkPopover(mark, true);
      }
    });

    viewport.addEventListener('scroll', onScroll, { passive: true });
    viewport.addEventListener('mousemove', (e) => {
      if (e.clientY < 70) toolbar.classList.remove('rv-hidden');
    });
    viewport.addEventListener('mousedown', (e) => {
      const path = e.composedPath();
      if (!state.els.pop.hidden && !path.includes(state.els.pop)) hidePopover();
      if (!settings.hidden && !path.includes(settings) && !path.includes(btn('settings'))) toggleSettings(false);
    });

    body.addEventListener('click', (e) => {
      const mark = e.target.closest('mark.rv-hl');
      if (mark && !hasSelection()) {
        showMarkPopover(mark, false);
        return;
      }
      if (e.target.tagName === 'IMG') {
        lightbox.querySelector('img').src = e.target.currentSrc || e.target.src;
        lightbox.querySelector('img').alt = e.target.alt || '';
        lightbox.hidden = false;
        lightbox.focus && lightbox.setAttribute('tabindex', '-1');
        lightbox.focus();
      }
    });
    body.addEventListener('mouseup', () => setTimeout(onSelectionEnd, 0));
    body.addEventListener('keyup', (e) => { if (e.shiftKey) setTimeout(onSelectionEnd, 0); });
    lightbox.addEventListener('click', () => { lightbox.hidden = true; viewport.focus({ preventScroll: true }); });
  }

  function prefersReducedMotion() {
    return !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
  }

  function onKeyDown(e) {
    if (e.key !== 'Escape') return;
    e.preventDefault();
    if (!state.els.lightbox.hidden) {
      state.els.lightbox.hidden = true;
      state.els.viewport.focus({ preventScroll: true });
    } else if (!state.els.pop.hidden) {
      hidePopover();
    } else if (!state.els.settings.hidden) {
      toggleSettings(false);
    } else if (window.innerWidth <= 900 && !state.els.sidebar.hidden) {
      toggleSidebar(false);
    } else {
      close();
    }
  }

  function onScroll() {
    const { viewport, progress, toolbar } = state.els;
    const st = viewport.scrollTop;
    const max = viewport.scrollHeight - viewport.clientHeight;
    progress.style.width = `${max > 0 ? Math.min(100, (st / max) * 100) : 0}%`;
    const dy = st - state.lastScroll;
    if (st < 80 || dy < -6) toolbar.classList.remove('rv-hidden');
    else if (dy > 6 && state.els.settings.hidden) toolbar.classList.add('rv-hidden');
    state.lastScroll = st;
    if (!state.els.pop.hidden && !state.els.pop.querySelector('textarea')) hidePopover();
  }

  function toggleSettings(force) {
    const panel = state.els.settings;
    const show = typeof force === 'boolean' ? force : panel.hidden;
    panel.hidden = !show;
    btn('settings').setAttribute('aria-expanded', String(show));
    if (show) {
      state.els.toolbar.classList.remove('rv-hidden');
      const r = btn('settings').getBoundingClientRect();
      panel.style.top = `${Math.round(r.bottom + 8)}px`;
      panel.style.left = `${Math.round(Math.max(8, Math.min(window.innerWidth - 308, r.left - 120)))}px`;
      panel.style.right = 'auto';
      const first = panel.querySelector('button');
      if (first) first.focus();
    } else {
      btn('settings').focus();
    }
  }

  function toggleSidebar(force) {
    const sb = state.els.sidebar;
    const show = typeof force === 'boolean' ? force : sb.hidden;
    sb.hidden = !show;
    btn('sidebar').setAttribute('aria-pressed', String(show));
    updateToolbarHeight();
  }

  function showTab(name) {
    state.shadow.querySelectorAll('.rv-tabs [data-tab]').forEach((t) => t.setAttribute('aria-selected', String(t.getAttribute('data-tab') === name)));
    state.els.toc.hidden = name !== 'toc';
    state.els.notes.hidden = name !== 'notes';
  }

  function updateToolbarHeight() {
    const h = state.els.toolbar.getBoundingClientRect().height || 52;
    state.els.viewport.style.setProperty('--rv-toolbar-h', `${Math.round(h)}px`);
  }

  // ---------------------------------------------------------------------------
  // Preferences
  // ---------------------------------------------------------------------------

  function effectiveTheme() {
    const t = state.prefs.theme;
    if (t === 'system') return state.mq && state.mq.matches ? 'dark' : 'light';
    return t;
  }

  function applyPrefs() {
    if (!state.shadow) return;
    const p = state.prefs;
    const { viewport, article, settings } = state.els;
    viewport.className = `rv-viewport theme-${effectiveTheme()}`;
    article.style.setProperty('--rv-font-size', `${p.fontSize}px`);
    article.style.setProperty('--rv-line-height', String(p.lineHeight));
    article.style.setProperty('--rv-para', String(p.paragraphSpacing));
    article.style.setProperty('--rv-width', WIDTHS[p.width] || WIDTHS.medium);
    article.style.setProperty('--rv-font', FONT_STACKS[p.fontFamily] || FONT_STACKS.serif);
    ensureFont(p.fontFamily);

    settings.querySelector('[data-out="fontSize"]').textContent = String(p.fontSize);
    settings.querySelector('[data-out="lineHeight"]').textContent = Number(p.lineHeight).toFixed(1);
    settings.querySelector('[data-out="paragraphSpacing"]').textContent = Number(p.paragraphSpacing).toFixed(1);
    settings.querySelector('[data-pref="fontFamily"]').value = p.fontFamily;
    settings.querySelector('[data-pref="lineHeight"]').value = String(p.lineHeight);
    settings.querySelector('[data-pref="paragraphSpacing"]').value = String(p.paragraphSpacing);
    settings.querySelectorAll('[data-theme]').forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.theme === p.theme)));
    settings.querySelectorAll('[data-width]').forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.width === p.width)));
  }

  function updatePrefs(patch) {
    state.prefs = Object.assign({}, state.prefs, patch);
    applyPrefs();
    clearTimeout(state.prefsTimer);
    state.prefsTimer = setTimeout(() => {
      if (Storage && Storage.updateReaderPrefs) {
        Storage.updateReaderPrefs(state.prefs).catch(() => toast('Could not save reader settings.', 'error'));
      }
    }, 400);
  }

  const fontLoads = {};
  function ensureFont(key) {
    if (!FONT_FILES[key] || fontLoads[key] || !Dom || typeof FontFace === 'undefined') return fontLoads[key];
    const [family, prefix] = FONT_FILES[key];
    fontLoads[key] = Promise.all(['400', '700'].map(async (weight) => {
      const res = await Dom.sendMessage({ type: 'GET_FONT', name: `${prefix}-${weight}` });
      if (!res || !res.ok) throw new Error((res && res.error) || 'font unavailable');
      const bin = atob(res.result);
      const bytes = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
      const face = new FontFace(family, bytes.buffer, { weight, style: 'normal', display: 'swap' });
      await face.load();
      document.fonts.add(face);
    })).catch((e) => {
      delete fontLoads[key];
      console.warn('[BlurRemover] Font load failed:', e);
      toast('Could not load that font, using a fallback.', 'error');
    });
    return fontLoads[key];
  }

  // ---------------------------------------------------------------------------
  // Rendering
  // ---------------------------------------------------------------------------

  function wordCount(text) {
    return norm(text).split(' ').filter(Boolean).length;
  }

  /** Accordion/FAQ questions on the page whose text the extracted article doesn't contain. */
  function countUncoveredAccordions(articleBody) {
    const text = norm(articleBody.textContent).toLowerCase();
    let missed = 0;
    document.querySelectorAll(ACCORDION_TRIGGER).forEach((el) => {
      if (el.closest(FULL_SKIP) || el.closest('header, footer')) return;
      const t = norm(el.textContent).toLowerCase();
      if (t.length < 3 || t.length > 300) return;
      if (!text.includes(t)) missed++;
    });
    return missed;
  }

  function render() {
    ttsStop();
    let data = getData(state.mode);
    let notice = '';
    if (state.mode === 'article' && (!data || data.textLength < 200)) {
      notice = 'This page doesn’t look like an article, so the full page is shown. Switch back with “Article”.';
      state.mode = 'full';
      data = getData('full');
    } else if (state.mode === 'article' && !state.modeChosen && countUncoveredAccordions(data.body) >= 2) {
      notice = 'Showing the full page so FAQ and accordion content is included. Switch with “Article”.';
      state.mode = 'full';
      data = getData('full');
    }
    state.modeChosen = true;
    state.data = data;
    const { meta, title, byline, body, notice: noticeEl, viewport } = state.els;

    state.shadow.querySelectorAll('[data-act="mode"]').forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.mode === state.mode)));

    title.textContent = data.title;
    const words = wordCount(data.body.textContent);
    const minutes = Math.max(1, Math.round(words / WORDS_PER_MINUTE));
    // eslint-disable-next-line no-unsanitized/property -- audited: static markup / escaped or sanitized values only
    meta.innerHTML = [
      `<span class="rv-site">${esc(data.site)}</span>`,
      data.date ? `<span>${esc(data.date)}</span>` : '',
      `<span>${minutes} min read · ${words.toLocaleString()} words</span>`
    ].filter(Boolean).join('<span aria-hidden="true">•</span>');
    byline.hidden = !data.byline;
    byline.textContent = data.byline ? `By ${data.byline.replace(/^by\s+/i, '')}` : '';
    noticeEl.hidden = !notice;
    noticeEl.textContent = notice;

    body.replaceChildren(...Array.from(data.body.cloneNode(true).childNodes));
    restoreHighlights();
    buildToc();
    viewport.scrollTop = 0;
    onScroll();
  }

  function setMode(mode) {
    if (mode === state.mode || !['article', 'full'].includes(mode)) return;
    state.mode = mode;
    render();
  }

  // ---------------------------------------------------------------------------
  // Table of contents
  // ---------------------------------------------------------------------------

  function buildToc() {
    const { body, toc, viewport } = state.els;
    if (state.tocObserver) state.tocObserver.disconnect();
    const headings = Array.from(body.querySelectorAll('h2, h3, h4'));
    if (headings.length < 2) {
      toc.innerHTML = '<p class="rv-empty">No sections found.</p>';
      return;
    }
    // eslint-disable-next-line no-unsanitized/property -- audited: static markup / escaped or sanitized values only
    toc.innerHTML = '<ol>' + headings.map((h, i) => {
      h.id = `rv-h-${i}`;
      return `<li><a href="#rv-h-${i}" data-target="rv-h-${i}" class="lvl-${h.tagName[1]}">${esc(norm(h.textContent))}</a></li>`;
    }).join('') + '</ol>';

    const links = new Map(Array.from(toc.querySelectorAll('a')).map((a) => [a.getAttribute('data-target'), a]));
    const visible = new Set();
    const setActive = (id) => {
      links.forEach((a, key) => a.setAttribute('aria-current', String(key === id)));
      const a = links.get(id);
      if (a && !state.els.sidebar.hidden) {
        const r = a.getBoundingClientRect();
        const sr = state.els.sidebar.getBoundingClientRect();
        if (r.top < sr.top || r.bottom > sr.bottom) a.scrollIntoView({ block: 'nearest' });
      }
    };
    state.tocObserver = new IntersectionObserver((entries) => {
      entries.forEach((en) => {
        if (en.isIntersecting) visible.add(en.target.id);
        else visible.delete(en.target.id);
      });
      const firstVisible = headings.find((h) => visible.has(h.id));
      if (firstVisible) {
        setActive(firstVisible.id);
        return;
      }
      const top = viewport.getBoundingClientRect().top + 100;
      const above = headings.filter((h) => h.getBoundingClientRect().top < top).pop();
      if (above) setActive(above.id);
    }, { root: viewport, rootMargin: '-60px 0px -65% 0px', threshold: 0 });
    headings.forEach((h) => state.tocObserver.observe(h));
    setActive(headings[0].id);
  }

  // ---------------------------------------------------------------------------
  // Text index helpers (highlights + TTS)
  // ---------------------------------------------------------------------------

  function buildTextIndex(root) {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    const nodes = [];
    let text = '';
    let n;
    while ((n = walker.nextNode())) {
      nodes.push({ node: n, start: text.length });
      text += n.nodeValue;
    }
    return { text, nodes };
  }

  function rangeFromOffsets(index, start, end) {
    let a = null;
    let b = null;
    for (const entry of index.nodes) {
      const len = entry.node.nodeValue.length;
      if (!a && start < entry.start + len) a = entry;
      if (end <= entry.start + len) {
        b = entry;
        break;
      }
    }
    if (!a || !b) return null;
    const range = document.createRange();
    range.setStart(a.node, Math.max(0, start - a.start));
    range.setEnd(b.node, Math.min(b.node.nodeValue.length, end - b.start));
    return range;
  }

  function offsetsFromRange(root, range) {
    const pre = document.createRange();
    pre.selectNodeContents(root);
    pre.setEnd(range.startContainer, range.startOffset);
    const start = pre.toString().length;
    return { start, end: start + range.toString().length };
  }

  // ---------------------------------------------------------------------------
  // Highlights & notes
  // ---------------------------------------------------------------------------

  function getSelectionObj() {
    return state.shadow && state.shadow.getSelection ? state.shadow.getSelection() : document.getSelection();
  }

  function hasSelection() {
    const sel = getSelectionObj();
    return !!(sel && sel.rangeCount && !sel.isCollapsed && sel.toString().trim());
  }

  function onSelectionEnd() {
    const sel = getSelectionObj();
    if (!sel || !sel.rangeCount || sel.isCollapsed) return;
    const range = sel.getRangeAt(0);
    const body = state.els.body;
    if (!body.contains(range.commonAncestorContainer)) return;
    const text = range.toString();
    if (!text.trim() || text.length > 2000) return;
    const offsets = offsetsFromRange(body, range);
    const rect = range.getBoundingClientRect();
    showPopover(rect, `
      <div class="rv-row">
        <button data-pop="highlight">Highlight</button>
        <button data-pop="note">Add note</button>
      </div>`, (act, pop) => {
      if (act === 'highlight') {
        addHighlight(offsets, '');
        hidePopover();
      } else if (act === 'note') {
        showNoteEditor(rect, '', (note) => addHighlight(offsets, note));
      }
    });
  }

  function showPopover(rect, html, onAction) {
    const pop = state.els.pop;
    // eslint-disable-next-line no-unsanitized/property -- audited: static markup / escaped or sanitized values only
    pop.innerHTML = html;
    pop.hidden = false;
    const w = pop.offsetWidth;
    const h = pop.offsetHeight;
    let top = rect.top - h - 8;
    if (top < 8) top = rect.bottom + 8;
    const left = Math.max(8, Math.min(window.innerWidth - w - 8, rect.left + rect.width / 2 - w / 2));
    pop.style.top = `${Math.round(top)}px`;
    pop.style.left = `${Math.round(left)}px`;
    pop.onclick = (e) => {
      const b = e.target.closest('[data-pop]');
      if (b) onAction(b.getAttribute('data-pop'), pop);
    };
    const first = pop.querySelector('textarea, button');
    if (first) first.focus({ preventScroll: true });
  }

  function hidePopover() {
    state.els.pop.hidden = true;
    state.els.pop.innerHTML = '';
  }

  function showNoteEditor(rect, initial, onSave) {
    showPopover(rect, `
      <label class="rv-row-label" for="rvNoteText">Note</label>
      <textarea id="rvNoteText" aria-label="Note text">${esc(initial)}</textarea>
      <div class="rv-row">
        <button data-pop="save">Save note</button>
        <button data-pop="cancel">Cancel</button>
      </div>`, (act, pop) => {
      if (act === 'save') {
        onSave(pop.querySelector('textarea').value.trim());
        hidePopover();
      } else {
        hidePopover();
      }
    });
  }

  function showMarkPopover(mark, editNow) {
    const id = mark.getAttribute('data-hl');
    const hl = state.highlights.find((h) => h.id === id);
    if (!hl) return;
    const rect = mark.getBoundingClientRect();
    if (editNow) {
      showNoteEditor(rect, hl.note || '', (note) => updateHighlightNote(id, note));
      return;
    }
    showPopover(rect, `
      ${hl.note ? `<p>${esc(hl.note)}</p>` : ''}
      <div class="rv-row">
        <button data-pop="edit">${hl.note ? 'Edit note' : 'Add note'}</button>
        <button data-pop="delete">Remove highlight</button>
      </div>`, (act) => {
      if (act === 'edit') showNoteEditor(rect, hl.note || '', (note) => updateHighlightNote(id, note));
      else if (act === 'delete') {
        removeHighlight(id);
        hidePopover();
      }
    });
  }

  function wrapRange(range, hl) {
    const nodes = [];
    const rootNode = range.commonAncestorContainer.nodeType === 3 ? range.commonAncestorContainer.parentNode : range.commonAncestorContainer;
    const walker = document.createTreeWalker(rootNode, NodeFilter.SHOW_TEXT);
    let n;
    while ((n = walker.nextNode())) {
      if (range.intersectsNode(n)) nodes.push(n);
    }
    const { startContainer, startOffset, endContainer, endOffset } = range;
    nodes.forEach((node) => {
      let s = node === startContainer ? startOffset : 0;
      let e = node === endContainer ? endOffset : node.nodeValue.length;
      if (s >= e || !node.nodeValue.slice(s, e).trim()) return;
      let target = node;
      if (e < target.nodeValue.length) target.splitText(e);
      if (s > 0) target = target.splitText(s);
      const mark = document.createElement('mark');
      mark.className = 'rv-hl' + (hl.note ? ' rv-has-note' : '');
      mark.setAttribute('data-hl', hl.id);
      mark.setAttribute('tabindex', '0');
      if (hl.note) mark.title = hl.note;
      target.parentNode.insertBefore(mark, target);
      mark.appendChild(target);
    });
  }

  function unwrapHighlight(id) {
    state.els.body.querySelectorAll(`mark[data-hl="${CSS.escape(id)}"]`).forEach((m) => {
      const parent = m.parentNode;
      while (m.firstChild) parent.insertBefore(m.firstChild, m);
      m.remove();
      parent.normalize();
    });
  }

  function persistHighlights() {
    renderNotes();
    if (Storage && Storage.saveHighlights) {
      const title = (state.data && state.data.title) || document.title;
      Storage.saveHighlights(location.href, state.highlights, { title }).catch(() => toast('Could not save highlights.', 'error'));
    }
  }

  function addHighlight(offsets, note) {
    const body = state.els.body;
    const index = buildTextIndex(body);
    const text = index.text.slice(offsets.start, offsets.end);
    if (!text.trim()) return;
    const hl = {
      id: `hl-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`,
      text,
      prefix: index.text.slice(Math.max(0, offsets.start - 32), offsets.start),
      suffix: index.text.slice(offsets.end, offsets.end + 32),
      note: note || '',
      createdAt: Date.now()
    };
    const range = rangeFromOffsets(index, offsets.start, offsets.end);
    if (!range) return;
    const sel = getSelectionObj();
    if (sel && sel.removeAllRanges) sel.removeAllRanges();
    wrapRange(range, hl);
    state.highlights.push(hl);
    persistHighlights();
    toast(note ? 'Note saved' : 'Highlighted', 'success');
  }

  function updateHighlightNote(id, note) {
    const hl = state.highlights.find((h) => h.id === id);
    if (!hl) return;
    hl.note = note;
    state.els.body.querySelectorAll(`mark[data-hl="${CSS.escape(id)}"]`).forEach((m) => {
      m.classList.toggle('rv-has-note', !!note);
      m.title = note || '';
    });
    persistHighlights();
  }

  function removeHighlight(id) {
    unwrapHighlight(id);
    state.highlights = state.highlights.filter((h) => h.id !== id);
    persistHighlights();
  }

  function commonSuffixLen(a, b) {
    let i = 0;
    while (i < a.length && i < b.length && a[a.length - 1 - i] === b[b.length - 1 - i]) i++;
    return i;
  }

  function commonPrefixLen(a, b) {
    let i = 0;
    while (i < a.length && i < b.length && a[i] === b[i]) i++;
    return i;
  }

  function restoreHighlights() {
    const body = state.els.body;
    let placed = 0;
    state.highlights.forEach((hl) => {
      const index = buildTextIndex(body);
      let best = -1;
      let bestScore = -1;
      let pos = index.text.indexOf(hl.text);
      while (pos !== -1) {
        const score = commonSuffixLen(index.text.slice(Math.max(0, pos - 32), pos), hl.prefix || '') +
          commonPrefixLen(index.text.slice(pos + hl.text.length, pos + hl.text.length + 32), hl.suffix || '');
        if (score > bestScore) {
          bestScore = score;
          best = pos;
        }
        pos = index.text.indexOf(hl.text, pos + 1);
      }
      if (best === -1) return;
      const range = rangeFromOffsets(index, best, best + hl.text.length);
      if (range) {
        wrapRange(range, hl);
        placed++;
      }
    });
    state.placedHighlights = placed;
    renderNotes();
  }

  function renderNotes() {
    const { notes } = state.els;
    const count = state.highlights.length;
    state.shadow.querySelector('[data-out="noteCount"]').textContent = count ? `(${count})` : '';
    const library = '<p class="rv-library"><button type="button" data-library="1">All my highlights</button></p>';
    if (!count) {
      notes.innerHTML = '<p class="rv-empty">Select text in the article to highlight it or add a note.</p>' + library;
      return;
    }
    // eslint-disable-next-line no-unsanitized/property -- audited: static markup / escaped or sanitized values only
    notes.innerHTML = state.highlights.map((h) => `
      <div class="rv-note">
        <blockquote>${esc(h.text.length > 220 ? h.text.slice(0, 220) + '…' : h.text)}</blockquote>
        ${h.note ? `<p>${esc(h.note)}</p>` : ''}
        <div class="rv-note-actions">
          <button data-jump="${esc(h.id)}" aria-label="Go to highlight">Go to</button>
          <button data-edit="${esc(h.id)}">${h.note ? 'Edit note' : 'Add note'}</button>
          <button data-del="${esc(h.id)}" aria-label="Delete highlight">Delete</button>
        </div>
      </div>`).join('') +
      (state.placedHighlights < count ? `<p class="rv-empty">${count - state.placedHighlights} highlight(s) are not in this view (try the other mode).</p>` : '') +
      library;
  }

  // ---------------------------------------------------------------------------
  // Text to speech
  // ---------------------------------------------------------------------------

  function ttsSupported() {
    return typeof speechSynthesis !== 'undefined' && typeof SpeechSynthesisUtterance !== 'undefined';
  }

  function ttsUpdateButtons() {
    const play = btn('tts');
    const stop = btn('tts-stop');
    if (!play) return;
    const t = state.tts;
    // eslint-disable-next-line no-unsanitized/property -- audited: static markup / escaped or sanitized values only
    play.innerHTML = !t.active ? '▶ <span class="rv-label">Listen</span>' : t.paused ? '▶ <span class="rv-label">Resume</span>' : '❚❚ <span class="rv-label">Pause</span>';
    play.setAttribute('aria-label', !t.active ? 'Listen: read the article aloud' : t.paused ? 'Resume reading aloud' : 'Pause reading aloud');
    stop.hidden = !t.active;
  }

  function ttsToggle() {
    if (!ttsSupported()) {
      toast('Text to speech is not available in this browser.', 'error');
      return;
    }
    const t = state.tts;
    if (!t.active) {
      ttsStart();
    } else if (t.paused) {
      speechSynthesis.resume();
      t.paused = false;
    } else {
      speechSynthesis.pause();
      t.paused = true;
    }
    ttsUpdateButtons();
  }

  function ttsStart() {
    const t = state.tts;
    const blocks = Array.from(state.els.body.querySelectorAll(TTS_BLOCKS)).filter((el) => !el.querySelector(TTS_BLOCKS) && el.textContent.trim());
    if (!blocks.length) return;
    const top = state.els.toolbar.getBoundingClientRect().bottom;
    let startAt = blocks.findIndex((b) => b.getBoundingClientRect().bottom > top + 10);
    if (startAt < 0) startAt = 0;
    speechSynthesis.cancel();
    Object.assign(t, { active: true, paused: false, blocks, index: startAt });
    ttsSpeakBlock();
  }

  function splitChunks(text) {
    const chunks = [];
    const re = /[^.!?;]+[.!?;]*\s*/g;
    let m;
    let cur = null;
    while ((m = re.exec(text))) {
      if (!m[0]) break;
      if (cur && m.index + m[0].length - cur.start <= 220) {
        cur.end = m.index + m[0].length;
      } else {
        if (cur) chunks.push(cur);
        cur = { start: m.index, end: m.index + m[0].length };
      }
    }
    if (cur) chunks.push(cur);
    return chunks.length ? chunks : [{ start: 0, end: text.length }];
  }

  function ttsSpeakBlock() {
    const t = state.tts;
    state.els.body.querySelectorAll('.rv-speaking').forEach((el) => el.classList.remove('rv-speaking'));
    if (!t.active || t.index >= t.blocks.length) {
      ttsStop();
      return;
    }
    const block = t.blocks[t.index];
    block.classList.add('rv-speaking');
    const r = block.getBoundingClientRect();
    if (r.top < 60 || r.bottom > window.innerHeight - 20) block.scrollIntoView({ block: 'center', behavior: prefersReducedMotion() ? 'auto' : 'smooth' });
    t.textIndex = buildTextIndex(block);
    t.chunks = splitChunks(t.textIndex.text);
    t.chunk = 0;
    ttsSpeakChunk();
  }

  function ttsSpeakChunk() {
    const t = state.tts;
    if (!t.active) return;
    if (t.chunk >= t.chunks.length) {
      t.index++;
      ttsSpeakBlock();
      return;
    }
    const { start, end } = t.chunks[t.chunk];
    const text = t.textIndex.text.slice(start, end);
    if (!text.trim()) {
      t.chunk++;
      ttsSpeakChunk();
      return;
    }
    const u = new SpeechSynthesisUtterance(text);
    u.lang = document.documentElement.lang || navigator.language || 'en';
    u.onboundary = (e) => {
      if (e.name && e.name !== 'word') return;
      const local = text.slice(e.charIndex);
      const len = e.charLength || ((/^\S+/.exec(local) || [''])[0].length);
      highlightWord(t.textIndex, start + e.charIndex, start + e.charIndex + len);
    };
    u.onend = () => {
      if (!t.active || t.utter !== u) return;
      t.chunk++;
      ttsSpeakChunk();
    };
    u.onerror = (e) => {
      if (!t.active || t.utter !== u || e.error === 'interrupted' || e.error === 'canceled') return;
      t.chunk++;
      ttsSpeakChunk();
    };
    t.utter = u;
    speechSynthesis.speak(u);
  }

  function highlightWord(index, start, end) {
    if (typeof CSS === 'undefined' || !CSS.highlights || typeof Highlight === 'undefined') return;
    const range = rangeFromOffsets(index, start, end);
    if (range) CSS.highlights.set('rv-tts', new Highlight(range));
  }

  function ttsStop() {
    const t = state.tts;
    const wasActive = t.active;
    t.active = false;
    t.paused = false;
    t.utter = null;
    if (wasActive && ttsSupported()) speechSynthesis.cancel();
    if (typeof CSS !== 'undefined' && CSS.highlights) CSS.highlights.delete('rv-tts');
    if (state.els.body) state.els.body.querySelectorAll('.rv-speaking').forEach((el) => el.classList.remove('rv-speaking'));
    ttsUpdateButtons();
  }

  // ---------------------------------------------------------------------------
  // Export: Markdown, HTML, print
  // ---------------------------------------------------------------------------

  function mdInline(node) {
    let out = '';
    node.childNodes.forEach((c) => {
      if (c.nodeType === 3) {
        out += c.nodeValue.replace(/\s+/g, ' ').replace(/([*_`[\]])/g, '\\$1');
        return;
      }
      if (c.nodeType !== 1) return;
      const tag = c.tagName;
      const inner = mdInline(c);
      if (tag === 'STRONG' || tag === 'B') out += inner.trim() ? `**${inner.trim()}**` : inner;
      else if (tag === 'EM' || tag === 'I') out += inner.trim() ? `*${inner.trim()}*` : inner;
      else if (tag === 'CODE') out += '`' + c.textContent + '`';
      else if (tag === 'A') out += `[${inner.trim() || c.getAttribute('href')}](${c.getAttribute('href')})`;
      else if (tag === 'BR') out += '  \n';
      else if (tag === 'IMG') out += `![${c.getAttribute('alt') || ''}](${c.getAttribute('src')})`;
      else if (tag === 'UL' || tag === 'OL') out += '';
      else out += inner;
    });
    return out;
  }

  function mdList(list, depth) {
    const ordered = list.tagName === 'OL';
    const start = Number(list.getAttribute('start')) || 1;
    return Array.from(list.children).filter((li) => li.tagName === 'LI').map((li, i) => {
      const pad = '  '.repeat(depth);
      const bullet = ordered ? `${start + i}. ` : '- ';
      const own = mdInline(li).trim();
      const nested = Array.from(li.children).filter((c) => c.tagName === 'UL' || c.tagName === 'OL').map((c) => mdList(c, depth + 1)).join('\n');
      return `${pad}${bullet}${own}${nested ? '\n' + nested : ''}`;
    }).join('\n');
  }

  function mdTable(table) {
    const rows = Array.from(table.querySelectorAll('tr')).map((tr) => Array.from(tr.children).map((c) => mdInline(c).trim().replace(/\|/g, '\\|')));
    if (!rows.length) return '';
    const width = Math.max(...rows.map((r) => r.length));
    const pad = (r) => r.concat(Array(width - r.length).fill(''));
    const lines = [`| ${pad(rows[0]).join(' | ')} |`, `| ${Array(width).fill('---').join(' | ')} |`];
    rows.slice(1).forEach((r) => lines.push(`| ${pad(r).join(' | ')} |`));
    return lines.join('\n');
  }

  function mdBlock(el) {
    const tag = el.tagName;
    const h = /^H([1-6])$/.exec(tag);
    if (h) return `${'#'.repeat(Number(h[1]))} ${mdInline(el).trim()}`;
    if (tag === 'P') return mdInline(el).trim();
    if (tag === 'UL' || tag === 'OL') return mdList(el, 0);
    if (tag === 'BLOCKQUOTE') return Array.from(el.children).length
      ? Array.from(el.children).map(mdBlock).join('\n\n').split('\n').map((l) => `> ${l}`).join('\n')
      : `> ${mdInline(el).trim()}`;
    if (tag === 'PRE') return '```\n' + el.textContent.replace(/\n$/, '') + '\n```';
    if (tag === 'FIGURE') {
      const img = el.querySelector('img');
      const cap = el.querySelector('figcaption');
      return [img ? `![${img.getAttribute('alt') || ''}](${img.getAttribute('src')})` : '', cap ? `*${mdInline(cap).trim()}*` : ''].filter(Boolean).join('\n');
    }
    if (tag === 'TABLE') return mdTable(el);
    if (tag === 'HR') return '---';
    if (tag === 'DL') return Array.from(el.children).map((c) => (c.tagName === 'DT' ? `**${mdInline(c).trim()}**` : `: ${mdInline(c).trim()}`)).join('\n');
    if (tag === 'DIV') return Array.from(el.children).map(mdBlock).filter(Boolean).join('\n\n');
    return mdInline(el).trim();
  }

  function toMarkdown() {
    const d = state.data;
    const blocks = Array.from(state.els.body.children).map(mdBlock).filter(Boolean);
    return `# ${d.title}\n\n> Source: ${location.href}\n\n${blocks.join('\n\n')}\n`;
  }

  async function copyMarkdown(button) {
    const md = toMarkdown();
    let ok = false;
    try {
      await navigator.clipboard.writeText(md);
      ok = true;
    } catch (e) {
      try {
        const ta = document.createElement('textarea');
        ta.value = md;
        ta.setAttribute('readonly', '');
        ta.style.cssText = 'position:fixed;left:-9999px;top:0;';
        state.shadow.appendChild(ta);
        ta.select();
        ok = document.execCommand('copy');
        ta.remove();
      } catch (err) {
        ok = false;
      }
    }
    const label = button.querySelector('.rv-label');
    const original = 'Copy MD';
    if (label) label.textContent = ok ? 'Copied' : 'Copy failed';
    toast(ok ? 'Copied as Markdown' : 'Copy failed: the browser blocked clipboard access.', ok ? 'success' : 'error');
    setTimeout(() => { if (label) label.textContent = original; }, 2000);
    state.els.viewport.focus({ preventScroll: true });
  }

  function standaloneHtml() {
    const d = state.data;
    const lang = esc(document.documentElement.lang || 'en');
    const metaLine = [d.site, d.byline ? `By ${d.byline}` : '', d.date].filter(Boolean).map(esc).join(' · ');
    const clone = state.els.body.cloneNode(true);
    clone.querySelectorAll('[id^="rv-h-"]').forEach((h) => h.removeAttribute('id'));
    clone.querySelectorAll('.rv-speaking').forEach((el) => el.classList.remove('rv-speaking'));
    clone.querySelectorAll('mark').forEach((m) => { m.removeAttribute('tabindex'); m.removeAttribute('data-hl'); m.removeAttribute('class'); });
    return `<!doctype html>
<html lang="${lang}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${esc(d.title)}</title>
<style>${EXPORT_CSS}</style>
</head>
<body>
<article>
<p class="meta"><a href="${esc(location.href)}">${esc(location.href)}</a></p>
<h1>${esc(d.title)}</h1>
<p class="meta">${metaLine}</p>
${clone.innerHTML}
</article>
</body>
</html>`;
  }

  function slug(s) {
    return String(s || 'article').toLowerCase().replace(/[^\p{L}\p{N}]+/gu, '-').replace(/^-+|-+$/g, '').slice(0, 80) || 'article';
  }

  function saveHtml() {
    try {
      const blob = new Blob([standaloneHtml()], { type: 'text/html;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${slug(state.data.title)}.html`;
      state.shadow.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 10000);
      toast('Saved as HTML', 'success');
    } catch (e) {
      toast('Could not save the file.', 'error');
    }
  }

  function printReader() {
    const w = window.open('', '_blank');
    if (!w) {
      toast('Pop-up blocked. Allow pop-ups or use Save instead.', 'error');
      return;
    }
    try {
      w.document.open();
      // eslint-disable-next-line no-unsanitized/method -- audited: static markup / escaped or sanitized values only
      w.document.write(standaloneHtml());
      w.document.close();
      let printed = false;
      const doPrint = () => {
        if (printed) return;
        printed = true;
        w.focus();
        w.print();
      };
      w.addEventListener('load', () => setTimeout(doPrint, 150), { once: true });
      setTimeout(doPrint, 1500);
    } catch (e) {
      toast('Could not open the print view.', 'error');
    }
  }

  // ---------------------------------------------------------------------------
  // Auto-open per site
  // ---------------------------------------------------------------------------

  function syncAutoButton() {
    const b = btn('auto');
    if (!b) return;
    const on = !!(Storage && state.settings && Storage.isAutoReaderSite(state.settings, location.hostname));
    b.setAttribute('aria-pressed', String(on));
    b.title = on ? 'Reader View opens automatically on this site (click to turn off)' : 'Auto-open on this site';
  }

  async function toggleAutoOpen(b) {
    if (!Storage || !Storage.setAutoReader) return;
    const on = b.getAttribute('aria-pressed') !== 'true';
    try {
      await Storage.setAutoReader(location.hostname, on);
      state.settings = await Storage.getSettings();
      syncAutoButton();
      toast(on ? `Reader View will open automatically on ${location.hostname}` : 'Auto-open turned off for this site', 'success');
    } catch (e) {
      toast('Could not save the setting.', 'error');
    }
  }

  // ---------------------------------------------------------------------------
  // Page lock & history
  // ---------------------------------------------------------------------------

  function saveProp(el, prop) {
    return [el.style.getPropertyValue(prop), el.style.getPropertyPriority(prop)];
  }

  function restoreProp(el, prop, saved) {
    if (saved[0]) el.style.setProperty(prop, saved[0], saved[1]);
    else el.style.removeProperty(prop);
  }

  function lockPage() {
    if (state.lock) return;
    const html = document.documentElement;
    const body = document.body;
    state.lock = {
      hadAttr: html.hasAttribute(LOCK_ATTR),
      html: { x: saveProp(html, 'overflow-x'), y: saveProp(html, 'overflow-y') },
      body: body ? { x: saveProp(body, 'overflow-x'), y: saveProp(body, 'overflow-y') } : null
    };
    html.setAttribute(LOCK_ATTR, '');
    html.style.setProperty('overflow', 'hidden', 'important');
    if (body) body.style.setProperty('overflow', 'hidden', 'important');
  }

  function unlockPage() {
    const lock = state.lock;
    if (!lock) return;
    const html = document.documentElement;
    const body = document.body;
    html.style.removeProperty('overflow');
    restoreProp(html, 'overflow-x', lock.html.x);
    restoreProp(html, 'overflow-y', lock.html.y);
    if (body && lock.body) {
      body.style.removeProperty('overflow');
      restoreProp(body, 'overflow-x', lock.body.x);
      restoreProp(body, 'overflow-y', lock.body.y);
    }
    if (!lock.hadAttr) html.removeAttribute(LOCK_ATTR);
    state.lock = null;
  }

  function pushHistory() {
    try {
      const cur = history.state && typeof history.state === 'object' ? history.state : {};
      history.pushState(Object.assign({}, cur, { brReader: true }), '');
      state.pushed = true;
    } catch (e) {
      state.pushed = false;
    }
  }

  window.addEventListener('popstate', () => {
    if (state.ignorePop) {
      state.ignorePop = false;
      return;
    }
    if (state.open) close({ fromHistory: true });
  });

  // Escape fallback when focus somehow sits outside the reader.
  window.addEventListener('keydown', (e) => {
    if (!state.open || e.key !== 'Escape') return;
    if (state.host && e.composedPath().includes(state.host)) return;
    close();
  }, true);

  // ---------------------------------------------------------------------------
  // Open / close
  // ---------------------------------------------------------------------------

  function onSystemThemeChange() {
    if (state.prefs.theme === 'system') applyPrefs();
  }

  async function open(opts = {}) {
    if (state.open || state.opening) return state.open;
    state.opening = true;
    try {
      state.settings = Storage ? await Storage.getSettings().catch(() => null) : null;
      state.prefs = Object.assign({}, DEFAULT_PREFS, state.settings && state.settings.reader ? state.settings.reader : {});
      state.cache = {};
      state.modeChosen = false;
      state.highlights = [];
      state.placedHighlights = 0;
      state.prevFocus = document.activeElement;

      let readerable = true;
      try {
        if (typeof isProbablyReaderable === 'function') readerable = isProbablyReaderable(document, { minContentLength: 140, minScore: 20 });
      } catch (e) { /* keep default */ }
      state.mode = readerable ? 'article' : 'full';

      if (Storage && Storage.getHighlights) {
        state.highlights = await Storage.getHighlights(location.href).catch(() => []);
      }

      buildUi();
      lockPage();
      applyPrefs();
      render();
      syncAutoButton();
      ttsUpdateButtons();
      if (!ttsSupported()) btn('tts').disabled = true;
      updateToolbarHeight();
      if (window.innerWidth >= 1200 && state.els.body.querySelectorAll('h2, h3, h4').length >= 3) toggleSidebar(true);
      if (state.mq && state.mq.addEventListener) state.mq.addEventListener('change', onSystemThemeChange);
      window.addEventListener('resize', updateToolbarHeight);
      state.els.viewport.focus({ preventScroll: true });
      pushHistory();
      state.open = true;
      if (opts.auto) toast('Reader View opened automatically (★ in the toolbar turns it off)');
      return true;
    } catch (e) {
      console.error('[BlurRemover] Reader View failed:', e);
      if (state.host) state.host.remove();
      unlockPage();
      toast('Reader View could not read this page.', 'error');
      return false;
    } finally {
      state.opening = false;
    }
  }

  function close(opts = {}) {
    if (!state.open) return;
    state.open = false;
    ttsStop();
    if (state.tocObserver) state.tocObserver.disconnect();
    if (state.mq && state.mq.removeEventListener) state.mq.removeEventListener('change', onSystemThemeChange);
    window.removeEventListener('resize', updateToolbarHeight);
    if (state.host) state.host.remove();
    state.host = null;
    state.shadow = null;
    state.els = {};
    unlockPage();
    if (state.pushed && !opts.fromHistory) {
      state.pushed = false;
      if (history.state && history.state.brReader) {
        state.ignorePop = true;
        history.back();
      }
    }
    state.pushed = false;
    if (state.prevFocus && state.prevFocus.focus && state.prevFocus.isConnected) {
      try { state.prevFocus.focus({ preventScroll: true }); } catch (e) { /* ignore */ }
    }
  }

  async function toggle() {
    if (state.open) {
      close();
      return false;
    }
    return open();
  }

  self.BlurRemoverReader = {
    open,
    close,
    toggle,
    isOpen: () => state.open,
    // The UI lives in a closed shadow root; this isolated-world accessor is for the e2e tests.
    _root: () => state.shadow
  };

  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (!message || !message.action) return false;
      if (message.action === 'TOGGLE_READER') {
        toggle().then((isOpen) => sendResponse({ status: 'ok', open: !!isOpen }));
        return true;
      }
      if (message.action === 'START_READER_VIEW') {
        if (state.open) {
          sendResponse({ status: 'already-open', open: true });
          return false;
        }
        open({ auto: !!message.auto }).then((ok) => sendResponse({ status: ok ? 'started' : 'error', open: !!ok }));
        return true;
      }
      if (message.action === 'CLOSE_READER') {
        close();
        sendResponse({ status: 'closed', open: false });
        return false;
      }
      return false;
    });
  }
})();
