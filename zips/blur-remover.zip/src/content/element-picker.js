/**
 * Blur Remover & DOM Modifier - Visual Element Picker & Inspector
 * Hover highlight, keyboard navigation (↑ parent, ↓ child, ←/→ siblings), zap without saving,
 * and a docked side panel that previews every match of the chosen selector before saving a rule.
 */

(function () {
  'use strict';

  if (self.BlurRemoverPicker) return;

  const PICKER_ROOT_ID = 'blur-remover-picker-root';
  const MAX_MATCH_BOXES = 300;
  const POINTER_EVENTS = ['click', 'mousedown', 'mouseup', 'pointerdown', 'pointerup', 'dblclick', 'auxclick', 'contextmenu'];

  const Dom = self.BlurRemoverDom;
  const Storage = () => self.BlurRemoverStorage;
  const Selector = () => self.BlurRemoverSelector;

  const ACTIONS = [
    { id: 'remove-blur', label: 'Remove blur', icon: '🪄' },
    { id: 'hide', label: 'Hide element', icon: '👁️' },
    { id: 'visibility-hidden', label: 'Make invisible', icon: '🔒' },
    { id: 'unlock-scroll', label: 'Unlock scroll', icon: '🔓' },
    { id: 'enable-pointer', label: 'Enable clicks', icon: '🖱️' },
    { id: 'custom-css', label: 'Custom CSS', icon: '🎨' }
  ];

  let active = false;
  let hovered = null;
  let locked = null;
  let host = null;
  let shadow = null;
  let outlineEl = null;
  let tooltipEl = null;
  let hintEl = null;
  let matchLayer = null;
  let panelEl = null;
  let panelState = null;
  let rafPending = false;
  let previouslyFocused = null;
  let dockLeft = false;

  const STYLES = `
    :host { all: initial; }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    .layer { position: fixed; inset: 0; pointer-events: none; z-index: 2147483646;
      font: 12px/1.45 system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif; color: #f8fafc; }
    .outline { position: fixed; pointer-events: none; display: none;
      border: 2px dashed #8b5cf6; background: rgba(139,92,246,.16); border-radius: 3px;
      box-shadow: 0 0 0 1px rgba(15,23,42,.6), 0 0 14px rgba(139,92,246,.6); }
    .outline.blur { border-color: #f59e0b; background: rgba(245,158,11,.18); box-shadow: 0 0 0 1px rgba(15,23,42,.6), 0 0 16px rgba(245,158,11,.7); }
    .outline.locked { border-style: solid; }
    .tooltip { position: fixed; pointer-events: none; display: none; max-width: min(560px, 90vw);
      background: #0f172a; border: 1px solid #6366f1; border-radius: 6px; padding: 4px 8px;
      box-shadow: 0 4px 14px rgba(0,0,0,.5); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .tag { color: #22d3ee; font-weight: 700; margin-right: 6px; }
    .badge { margin-left: 6px; background: rgba(245,158,11,.2); color: #fbbf24; font-size: 10px; font-weight: 700; padding: 1px 6px; border-radius: 999px; }
    .match { position: fixed; pointer-events: none; border: 2px solid #22d3ee; background: rgba(34,211,238,.12); border-radius: 2px; }
    .hint { position: fixed; left: 12px; bottom: 12px; pointer-events: none; background: rgba(15,23,42,.92);
      border: 1px solid rgba(255,255,255,.14); border-radius: 8px; padding: 6px 10px; font-size: 11px; color: #cbd5e1; }
    .hint kbd { font: 700 10px/1 ui-monospace, monospace; background: #1e293b; color: #f8fafc; border-radius: 4px; padding: 2px 5px; margin: 0 2px; border: 1px solid #334155; }

    .panel { position: fixed; top: 12px; right: 12px; bottom: 12px; width: 380px; max-width: calc(100vw - 24px);
      pointer-events: auto; overflow-y: auto; z-index: 2147483647;
      background: #111827; border: 1px solid rgba(139,92,246,.45); border-radius: 14px; padding: 16px;
      box-shadow: 0 16px 40px rgba(0,0,0,.55); display: flex; flex-direction: column; gap: 12px;
      font: 12px/1.45 system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif; color: #f8fafc; }
    .panel.left { right: auto; left: 12px; }
    .row { display: flex; align-items: center; justify-content: space-between; gap: 8px; }
    h2 { font-size: 14px; font-weight: 700; }
    h2 code { color: #22d3ee; }
    .icon-btn { background: transparent; border: 1px solid transparent; color: #94a3b8; font-size: 15px; cursor: pointer;
      border-radius: 6px; padding: 2px 7px; }
    .icon-btn:hover { color: #fff; background: rgba(255,255,255,.08); }
    .group { display: flex; flex-direction: column; gap: 5px; }
    .label { font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: .04em; color: #94a3b8; }
    input[type=text], textarea, select { width: 100%; background: #0b1220; border: 1px solid rgba(255,255,255,.14);
      border-radius: 7px; padding: 7px 9px; color: #f8fafc; font: inherit; }
    textarea { font-family: ui-monospace, 'Cascadia Code', monospace; resize: vertical; }
    input.mono { font-family: ui-monospace, 'Cascadia Code', monospace; }
    input.invalid, textarea.invalid { border-color: #ef4444; }
    .candidates { display: flex; flex-direction: column; gap: 4px; background: #0b1220; padding: 6px; border-radius: 8px; }
    .cand { display: grid; grid-template-columns: auto 1fr auto; align-items: center; gap: 8px; padding: 5px 6px;
      border-radius: 6px; cursor: pointer; border: 1px solid transparent; }
    .cand:hover { background: rgba(139,92,246,.12); }
    .cand input { accent-color: #8b5cf6; cursor: pointer; }
    .cand-label { font-size: 10px; color: #94a3b8; display: block; }
    .cand-sel { font-family: ui-monospace, monospace; color: #67e8f9; word-break: break-all; font-size: 11px; }
    .count { font-size: 10px; font-weight: 700; padding: 2px 7px; border-radius: 999px; white-space: nowrap;
      background: rgba(34,211,238,.15); color: #67e8f9; }
    .count.many { background: rgba(245,158,11,.18); color: #fbbf24; }
    .status { font-size: 11px; color: #94a3b8; min-height: 16px; }
    .status.ok { color: #34d399; }
    .status.warn { color: #fbbf24; }
    .status.err { color: #f87171; }
    .actions { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; }
    .action { background: #1a2336; border: 1px solid rgba(255,255,255,.1); color: #f8fafc; border-radius: 7px;
      padding: 8px 6px; font: 600 11px/1.2 inherit; cursor: pointer; text-align: center; }
    .action:hover { border-color: #8b5cf6; background: rgba(139,92,246,.18); }
    .action[aria-pressed="true"] { background: #6366f1; border-color: #6366f1; color: #fff; }
    .hidden { display: none !important; }
    .note { font-size: 11px; color: #94a3b8; }
    .warning { background: rgba(245,158,11,.12); border: 1px solid rgba(245,158,11,.45); color: #fde68a;
      padding: 8px 10px; border-radius: 8px; font-size: 11px; }
    .footer { display: flex; gap: 8px; justify-content: flex-end; margin-top: auto; padding-top: 4px; flex-wrap: wrap; }
    .btn { border-radius: 7px; padding: 8px 14px; font: 700 12px/1 inherit; cursor: pointer; border: 1px solid transparent; }
    .btn-ghost { background: transparent; color: #cbd5e1; border-color: rgba(255,255,255,.16); }
    .btn-ghost:hover { background: rgba(255,255,255,.06); }
    .btn-zap { background: #3f1d2b; color: #fecdd3; border-color: rgba(244,63,94,.4); margin-right: auto; }
    .btn-zap:hover { background: #5b2235; }
    .btn-save { background: linear-gradient(135deg, #6366f1, #8b5cf6); color: #fff; }
    .btn-save:disabled { opacity: .5; cursor: not-allowed; }
    button:focus-visible, input:focus-visible, select:focus-visible, textarea:focus-visible, .cand:focus-within {
      outline: 2px solid #a5b4fc; outline-offset: 2px; }
  `;

  // ---------------------------------------------------------------------------
  // Shadow DOM
  // ---------------------------------------------------------------------------

  function ensureHost() {
    if (host && host.isConnected && shadow) return;
    const existing = document.getElementById(PICKER_ROOT_ID);
    if (existing) existing.remove();

    host = document.createElement('div');
    host.id = PICKER_ROOT_ID;
    host.style.cssText = 'all: initial; position: fixed; top: 0; left: 0; width: 0; height: 0; z-index: 2147483647;';
    // Closed: page scripts must not be able to drive the panel (e.g. save a rule for every site).
    shadow = host.attachShadow({ mode: 'closed' });

    const style = document.createElement('style');
    style.textContent = STYLES;
    shadow.appendChild(style);

    const layer = document.createElement('div');
    layer.className = 'layer';
    matchLayer = document.createElement('div');
    outlineEl = document.createElement('div');
    outlineEl.className = 'outline';
    tooltipEl = document.createElement('div');
    tooltipEl.className = 'tooltip';
    tooltipEl.setAttribute('aria-hidden', 'true');
    hintEl = document.createElement('div');
    hintEl.className = 'hint';
    hintEl.innerHTML = 'Click to select · <kbd>↑</kbd><kbd>↓</kbd><kbd>←</kbd><kbd>→</kbd> navigate · <kbd>Enter</kbd> open · <kbd>Z</kbd> zap · <kbd>Ctrl+Z</kbd> undo · <kbd>Esc</kbd> exit';
    layer.append(matchLayer, outlineEl, tooltipEl, hintEl);
    shadow.appendChild(layer);

    // Keep keystrokes typed in the panel away from page shortcut handlers.
    ['keydown', 'keyup', 'keypress'].forEach((type) => {
      shadow.addEventListener(type, (e) => {
        if (panelEl && e.composedPath().includes(panelEl)) e.stopPropagation();
      });
    });

    (document.body || document.documentElement).appendChild(host);
  }

  function pathIncludesHost(e) {
    return !!host && e.composedPath().includes(host);
  }

  // ---------------------------------------------------------------------------
  // Start / stop
  // ---------------------------------------------------------------------------

  function start(options = {}) {
    ensureHost();
    if (!active) {
      active = true;
      previouslyFocused = document.activeElement;
      document.addEventListener('mousemove', onMouseMove, true);
      POINTER_EVENTS.forEach((type) => window.addEventListener(type, onPointer, true));
      window.addEventListener('keydown', onKeyDown, true);
      window.addEventListener('scroll', scheduleReposition, true);
      window.addEventListener('resize', scheduleReposition, true);
    }
    hintEl.classList.remove('hidden');

    const engine = self.BlurRemoverEngine;
    const target = options.useContextTarget && engine && engine.getContextTarget ? engine.getContextTarget() : null;
    if (target && target !== document.documentElement && target !== document.body) {
      setHovered(target);
      openPanel(target);
    }
  }

  function stop() {
    if (!active && !host) return;
    active = false;
    closePanel();
    hovered = null;
    locked = null;
    document.removeEventListener('mousemove', onMouseMove, true);
    POINTER_EVENTS.forEach((type) => window.removeEventListener(type, onPointer, true));
    window.removeEventListener('keydown', onKeyDown, true);
    window.removeEventListener('scroll', scheduleReposition, true);
    window.removeEventListener('resize', scheduleReposition, true);
    if (host) host.remove();
    host = shadow = outlineEl = tooltipEl = hintEl = matchLayer = null;
    if (previouslyFocused && previouslyFocused.focus && previouslyFocused.isConnected) {
      try { previouslyFocused.focus({ preventScroll: true }); } catch (e) { /* ignore */ }
    }
  }

  // ---------------------------------------------------------------------------
  // Hover outline & tooltip
  // ---------------------------------------------------------------------------

  function isPickable(el) {
    return el && el.nodeType === 1 && el !== host && el !== document.documentElement && !(host && host.contains(el));
  }

  function setHovered(el) {
    if (!isPickable(el)) return;
    hovered = el;
    drawOutline();
  }

  function drawOutline() {
    const target = locked || hovered;
    if (!outlineEl) return;
    if (!target || !target.isConnected) {
      outlineEl.style.display = 'none';
      tooltipEl.style.display = 'none';
      return;
    }
    const rect = target.getBoundingClientRect();
    Object.assign(outlineEl.style, {
      display: 'block',
      top: `${rect.top}px`,
      left: `${rect.left}px`,
      width: `${rect.width}px`,
      height: `${rect.height}px`
    });
    const SelectorGen = Selector();
    const hasBlur = SelectorGen ? SelectorGen.detectBlurStyles(target) : false;
    outlineEl.classList.toggle('blur', hasBlur);
    outlineEl.classList.toggle('locked', !!locked);

    if (locked) {
      tooltipEl.style.display = 'none';
      return;
    }
    const concise = SelectorGen ? SelectorGen.generateSelectors(target).concise : target.tagName.toLowerCase();
    // eslint-disable-next-line no-unsanitized/property -- audited: static markup / escaped or sanitized values only
    tooltipEl.innerHTML = `<span class="tag">&lt;${Dom.escapeHtml(target.tagName.toLowerCase())}&gt;</span>${Dom.escapeHtml(concise)}${hasBlur ? '<span class="badge">✨ Blur detected</span>' : ''}`;
    tooltipEl.style.display = 'block';
    const tipHeight = tooltipEl.offsetHeight || 24;
    // Flip below the element when there is no room above (headers, cookie bars).
    let top = rect.top - tipHeight - 6;
    if (top < 4) top = Math.min(rect.bottom + 6, window.innerHeight - tipHeight - 4);
    if (top < 4) top = 4;
    const left = Math.max(4, Math.min(rect.left, window.innerWidth - tooltipEl.offsetWidth - 4));
    tooltipEl.style.top = `${top}px`;
    tooltipEl.style.left = `${left}px`;
  }

  function scheduleReposition() {
    if (rafPending) return;
    rafPending = true;
    requestAnimationFrame(() => {
      rafPending = false;
      drawOutline();
      if (panelState) drawMatches(panelState.matches);
    });
  }

  // ---------------------------------------------------------------------------
  // Input handlers
  // ---------------------------------------------------------------------------

  function onMouseMove(e) {
    if (!active || panelEl) return;
    const el = Dom.deepElementFromPoint(e.clientX, e.clientY, host);
    if (!isPickable(el) || el === hovered) return;
    setHovered(el);
  }

  function onPointer(e) {
    if (!active || pathIncludesHost(e)) return;
    e.preventDefault();
    e.stopImmediatePropagation();
    if (e.type !== 'click' && e.type !== 'contextmenu') return;

    const el = Dom.deepElementFromPoint(e.clientX, e.clientY, host) || hovered;
    if (!isPickable(el)) return;
    setHovered(el);
    openPanel(el); // clicking another element while the panel is open re-targets it
  }

  function navigate(direction) {
    const current = locked || hovered;
    if (!current) return;
    let next = null;
    if (direction === 'up') next = current.parentElement;
    else if (direction === 'down') next = current.firstElementChild;
    else if (direction === 'left') next = current.previousElementSibling;
    else if (direction === 'right') next = current.nextElementSibling;
    if (!next || next === document.documentElement || !isPickable(next)) return;
    if (panelEl) {
      openPanel(next);
    } else {
      setHovered(next);
      next.scrollIntoView({ block: 'nearest', inline: 'nearest' });
    }
  }

  function onKeyDown(e) {
    if (!active) return;
    const inPanel = panelEl && e.composedPath().includes(panelEl);

    if (e.key === 'Escape') {
      e.preventDefault();
      e.stopImmediatePropagation();
      if (panelEl) closePanel();
      else stop();
      return;
    }

    if (inPanel) {
      if (e.key === 'Tab') trapFocus(e);
      return; // typing in the panel is handled by the panel itself
    }

    const key = (e.key || '').toLowerCase();
    if ((e.ctrlKey || e.metaKey) && !e.shiftKey && key === 'z') {
      if (e.defaultPrevented) return; // the engine already handled this undo
      e.preventDefault();
      e.stopImmediatePropagation();
      Dom.undoLast().then((what) => {
        if (what) Dom.showToast(what === 'rule' ? 'Rule removed (undo)' : 'Element restored', { type: 'success' });
      });
      return;
    }
    if (e.ctrlKey || e.metaKey || e.altKey) return;

    const arrows = { ArrowUp: 'up', ArrowDown: 'down', ArrowLeft: 'left', ArrowRight: 'right' };
    if (arrows[e.key]) {
      e.preventDefault();
      e.stopImmediatePropagation();
      navigate(arrows[e.key]);
      return;
    }
    if (e.key === 'Enter' && hovered) {
      e.preventDefault();
      e.stopImmediatePropagation();
      openPanel(hovered);
      return;
    }
    if ((key === 'z' || e.key === 'Delete') && hovered && !panelEl) {
      e.preventDefault();
      e.stopImmediatePropagation();
      zapElement(hovered);
    }
  }

  function trapFocus(e) {
    const focusables = Array.from(panelEl.querySelectorAll('button, input, select, textarea, [tabindex]:not([tabindex="-1"])'))
      .filter((el) => !el.disabled && el.offsetParent !== null);
    if (!focusables.length) return;
    const first = focusables[0];
    const last = focusables[focusables.length - 1];
    const current = shadow.activeElement;
    if (e.shiftKey && (current === first || !panelEl.contains(current))) {
      e.preventDefault();
      last.focus();
    } else if (!e.shiftKey && (current === last || !panelEl.contains(current))) {
      e.preventDefault();
      first.focus();
    }
  }

  function zapElement(el) {
    const parent = el.parentElement;
    Dom.zap(el);
    Dom.showToast('Element zapped for this visit.', {
      type: 'success',
      duration: 6000,
      actionLabel: 'Undo',
      onAction: () => {
        Dom.undoZap();
        drawOutline();
      }
    });
    hovered = parent && isPickable(parent) ? parent : null;
    drawOutline();
  }

  // ---------------------------------------------------------------------------
  // Match highlighting
  // ---------------------------------------------------------------------------

  function drawMatches(elements) {
    if (!matchLayer) return;
    const list = (elements || []).slice(0, MAX_MATCH_BOXES);
    while (matchLayer.childElementCount > list.length) matchLayer.lastElementChild.remove();
    while (matchLayer.childElementCount < list.length) {
      const box = document.createElement('div');
      box.className = 'match';
      matchLayer.appendChild(box);
    }
    list.forEach((el, i) => {
      const rect = el.getBoundingClientRect();
      const box = matchLayer.children[i];
      const visible = rect.width > 0 && rect.height > 0 && rect.bottom > 0 && rect.top < window.innerHeight;
      box.style.display = visible ? 'block' : 'none';
      if (!visible) return;
      box.style.top = `${rect.top}px`;
      box.style.left = `${rect.left}px`;
      box.style.width = `${rect.width}px`;
      box.style.height = `${rect.height}px`;
    });
  }

  // ---------------------------------------------------------------------------
  // Action panel
  // ---------------------------------------------------------------------------

  function closePanel() {
    if (panelEl) panelEl.remove();
    panelEl = null;
    panelState = null;
    locked = null;
    drawMatches([]);
    if (hintEl) hintEl.classList.remove('hidden');
    drawOutline();
  }

  function countLabel(n) {
    return `${n} match${n === 1 ? '' : 'es'}`;
  }

  function openPanel(el) {
    if (!isPickable(el)) return;
    if (panelEl) panelEl.remove();
    locked = el;
    hovered = el;
    hintEl.classList.add('hidden');
    drawOutline();

    const SelectorGen = Selector();
    const inShadow = Dom.isInShadowTree(el);
    const candidates = SelectorGen && !inShadow ? SelectorGen.generateCandidates(el) : [];
    const hasBlur = SelectorGen ? SelectorGen.detectBlurStyles(el) : false;
    const hostname = Storage() ? Storage().normalizeHost(location.hostname) : location.hostname;
    const exactPath = location.hostname + location.pathname;
    const tag = el.tagName.toLowerCase();
    const first = candidates[0] ? candidates[0].selector : tag;
    const defaultAction = hasBlur ? 'remove-blur' : 'hide';
    const esc = Dom.escapeHtml;

    // Dock away from the picked element so it stays visible.
    const rect = el.getBoundingClientRect();
    dockLeft = rect.left + rect.width / 2 > window.innerWidth * 0.55 && rect.width < window.innerWidth * 0.6;

    panelEl = document.createElement('div');
    panelEl.className = `panel${dockLeft ? ' left' : ''}`;
    panelEl.setAttribute('role', 'dialog');
    panelEl.setAttribute('aria-modal', 'false');
    panelEl.setAttribute('aria-labelledby', 'brPickerTitle');

    const candidateHtml = candidates.map((c, i) => `
      <label class="cand">
        <input type="radio" name="cand" value="${i}" ${i === 0 ? 'checked' : ''} aria-label="${esc(c.label)}: ${esc(c.selector)}, ${esc(countLabel(c.count))}">
        <span><span class="cand-label">${esc(c.label)}</span><span class="cand-sel">${esc(c.selector)}</span></span>
        <span class="count ${c.count > 1 ? 'many' : ''}">${esc(countLabel(c.count))}</span>
      </label>`).join('');

    const actionHtml = ACTIONS.map((a) => `
      <button type="button" class="action" data-action="${esc(a.id)}" aria-pressed="${a.id === defaultAction}">${a.icon} ${esc(a.label)}</button>`).join('');

    // eslint-disable-next-line no-unsanitized/property -- audited: static markup / escaped or sanitized values only
    panelEl.innerHTML = `
      <div class="row">
        <h2 id="brPickerTitle">Create rule for <code>&lt;${esc(tag)}&gt;</code></h2>
        <div>
          <button type="button" class="icon-btn" data-ref="dock" aria-label="Move panel to the other side" title="Move panel">⇆</button>
          <button type="button" class="icon-btn" data-ref="close" aria-label="Close panel (Esc)" title="Close (Esc)">✕</button>
        </div>
      </div>

      ${inShadow ? `<div class="warning" role="note">This element is inside a shadow DOM component. Page-wide CSS rules can't reach it, so it can only be zapped for this visit.</div>` : `
      <div class="group">
        <label class="label" for="brName">Rule name</label>
        <input type="text" id="brName" data-ref="name" value="${esc(`Modify ${first}`.slice(0, 120))}">
      </div>

      <div class="group">
        <span class="label" id="brCandLabel">Suggested selectors</span>
        <div class="candidates" role="radiogroup" aria-labelledby="brCandLabel">${candidateHtml || '<span class="note">No stable selector found, edit one below.</span>'}</div>
      </div>

      <div class="group">
        <label class="label" for="brSelector">Target selector</label>
        <input type="text" id="brSelector" class="mono" data-ref="selector" value="${esc(first)}" spellcheck="false" aria-describedby="brSelStatus">
        <div class="status" id="brSelStatus" data-ref="status" aria-live="polite"></div>
      </div>

      <div class="group">
        <span class="label" id="brActionLabel">Action</span>
        <div class="actions" role="group" aria-labelledby="brActionLabel">${actionHtml}</div>
      </div>

      <div class="group hidden" data-ref="cssGroup">
        <label class="label" for="brCss">Custom CSS declarations</label>
        <textarea id="brCss" data-ref="css" rows="3" spellcheck="false" placeholder="opacity: 1 !important; filter: none !important;" aria-describedby="brCssStatus"></textarea>
        <div class="status" id="brCssStatus" data-ref="cssStatus" aria-live="polite"></div>
      </div>

      <div class="group">
        <label class="label" for="brScope">Site scope</label>
        <select id="brScope" data-ref="scope">
          <option value="domain">This domain (${esc(hostname)})</option>
          <option value="exact">Exact page (${esc(exactPath)})</option>
          <option value="global">Global (all sites)</option>
        </select>
      </div>

      <div class="group hidden" data-ref="exactGroup">
        <label class="label" for="brExact">Exact URL / path</label>
        <input type="text" id="brExact" class="mono" data-ref="exact" value="${esc(exactPath)}" spellcheck="false">
        <span class="note">End with <code>*</code> to match every page under this path, e.g. <code>${esc(hostname)}/blog/*</code></span>
      </div>`}

      <div class="footer">
        <button type="button" class="btn btn-zap" data-ref="zap" title="Hide just this element for this visit, without saving a rule">💥 Zap once</button>
        <button type="button" class="btn btn-ghost" data-ref="cancel">Cancel</button>
        ${inShadow ? '' : '<button type="button" class="btn btn-save" data-ref="save">Save rule</button>'}
      </div>
    `;
    shadow.appendChild(panelEl);

    const ref = (name) => panelEl.querySelector(`[data-ref="${name}"]`);
    panelState = { el, candidates, action: defaultAction, matches: [], validSelector: true, timer: null };

    ref('close').addEventListener('click', closePanel);
    ref('cancel').addEventListener('click', closePanel);
    ref('dock').addEventListener('click', () => {
      dockLeft = !dockLeft;
      panelEl.classList.toggle('left', dockLeft);
    });
    ref('zap').addEventListener('click', () => {
      const target = panelState.el;
      closePanel();
      zapElement(target);
    });

    if (inShadow) {
      ref('zap').focus();
      return;
    }

    const selectorInput = ref('selector');
    const status = ref('status');
    const saveBtn = ref('save');

    function validateSelector() {
      const value = selectorInput.value.trim();
      const result = Dom.testSelector(value);
      if (!value || !result.valid) {
        selectorInput.classList.add('invalid');
        status.className = 'status err';
        status.textContent = value ? 'Invalid CSS selector.' : 'Enter a CSS selector.';
        panelState.validSelector = false;
        panelState.matches = [];
        saveBtn.disabled = true;
        drawMatches([]);
        return;
      }
      selectorInput.classList.remove('invalid');
      panelState.validSelector = true;
      let matches = [];
      try {
        matches = Array.from(document.querySelectorAll(value));
      } catch (e) { /* validated above */ }
      panelState.matches = matches;
      const includesPicked = matches.includes(panelState.el);
      if (result.count === 0) {
        status.className = 'status warn';
        status.textContent = 'Matches nothing on this page right now.';
      } else if (!includesPicked) {
        status.className = 'status warn';
        status.textContent = `${countLabel(result.count)}, but not the element you picked.`;
      } else {
        status.className = `status ${result.count > 1 ? 'warn' : 'ok'}`;
        status.textContent = result.count > 1
          ? `${countLabel(result.count)} on this page (all highlighted).`
          : '1 match: only the element you picked.';
      }
      saveBtn.disabled = !!(panelState.action === 'custom-css' && !panelState.cssValid);
      drawMatches(matches);
    }

    let nameEdited = false;
    ref('name').addEventListener('input', () => { nameEdited = true; });

    selectorInput.addEventListener('input', () => {
      if (!nameEdited) ref('name').value = `Modify ${selectorInput.value.trim()}`.slice(0, 120);
      clearTimeout(panelState.timer);
      panelState.timer = setTimeout(validateSelector, 200);
      panelEl.querySelectorAll('input[name="cand"]').forEach((r) => {
        r.checked = candidates[Number(r.value)] && candidates[Number(r.value)].selector === selectorInput.value.trim();
      });
    });

    panelEl.querySelectorAll('input[name="cand"]').forEach((radio) => {
      radio.addEventListener('change', () => {
        if (!radio.checked) return;
        const c = candidates[Number(radio.value)];
        selectorInput.value = c.selector;
        if (!nameEdited) ref('name').value = `Modify ${c.selector}`.slice(0, 120);
        validateSelector();
      });
    });

    const cssGroup = ref('cssGroup');
    const cssInput = ref('css');
    const cssStatus = ref('cssStatus');
    panelState.cssValid = true;

    function validateCss() {
      if (panelState.action !== 'custom-css') {
        panelState.cssValid = true;
        return;
      }
      const clean = Dom.sanitizeDeclarations(cssInput.value.trim());
      panelState.cssValid = !!clean;
      cssInput.classList.toggle('invalid', !clean);
      cssStatus.className = `status ${clean ? 'ok' : 'err'}`;
      cssStatus.textContent = clean ? 'Valid declarations.' : 'Enter valid declarations (no { } blocks), e.g. opacity: 1 !important;';
      saveBtn.disabled = !panelState.validSelector || !clean;
    }
    cssInput.addEventListener('input', validateCss);

    const actionBtns = panelEl.querySelectorAll('.action');
    actionBtns.forEach((btn) => {
      btn.addEventListener('click', () => {
        actionBtns.forEach((b) => b.setAttribute('aria-pressed', 'false'));
        btn.setAttribute('aria-pressed', 'true');
        panelState.action = btn.getAttribute('data-action');
        cssGroup.classList.toggle('hidden', panelState.action !== 'custom-css');
        validateCss();
        if (panelState.action !== 'custom-css') saveBtn.disabled = !panelState.validSelector;
      });
    });

    ref('scope').addEventListener('change', (e) => {
      ref('exactGroup').classList.toggle('hidden', e.target.value !== 'exact');
    });

    saveBtn.addEventListener('click', () => saveRule(ref));

    validateSelector();
    ref('name').focus();
  }

  async function saveRule(ref) {
    const StorageAPI = Storage();
    const selector = ref('selector').value.trim();
    if (!Dom.isValidSelector(selector)) {
      ref('status').className = 'status err';
      ref('status').textContent = 'Invalid CSS selector.';
      return;
    }
    const action = panelState.action;
    let customCss = '';
    if (action === 'custom-css') {
      customCss = Dom.sanitizeDeclarations(ref('css').value.trim()) || '';
      if (!customCss) return;
    }
    const siteScope = ref('scope').value;
    let domainPattern = '*';
    if (siteScope === 'domain') domainPattern = StorageAPI ? StorageAPI.normalizeHost(location.hostname) : location.hostname;
    else if (siteScope === 'exact') domainPattern = ref('exact').value.trim() || (location.hostname + location.pathname);

    if (!StorageAPI) {
      Dom.showToast('Storage is unavailable. Reload the page and try again.', { type: 'error' });
      return;
    }

    const saveBtn = ref('save');
    saveBtn.disabled = true;
    try {
      const rule = await StorageAPI.addRule({
        name: ref('name').value.trim() || 'Custom Rule',
        selector,
        actionType: action,
        siteScope,
        domainPattern,
        customCss
      });
      const refresh = () => self.BlurRemoverEngine && self.BlurRemoverEngine.refresh && self.BlurRemoverEngine.refresh();
      const undo = async () => {
        await StorageAPI.deleteRule(rule.id);
        refresh();
      };
      const matchCount = panelState ? panelState.matches.length : 0;
      Dom.setRuleUndo(undo);
      refresh();
      stop();
      Dom.showToast(`Rule saved and applied (${matchCount ? countLabel(matchCount) : 'no matches yet'}).`, {
        type: 'success',
        duration: 7000,
        actionLabel: 'Undo',
        onAction: () => {
          Dom.setRuleUndo(null);
          undo().then(() => Dom.showToast('Rule removed.', { type: 'info' }));
        }
      });
    } catch (err) {
      saveBtn.disabled = false;
      Dom.showToast(`Could not save rule: ${err.message}`, { type: 'error' });
    }
  }

  // ---------------------------------------------------------------------------
  // Messaging
  // ---------------------------------------------------------------------------

  self.BlurRemoverPicker = {
    start,
    stop,
    isActive: () => active
  };

  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (!message || message.action !== 'START_PICKER') return false;
      start({ useContextTarget: !!message.useContextTarget });
      sendResponse({ status: 'started' });
      return false;
    });
  }
})();
