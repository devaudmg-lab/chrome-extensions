/**
 * Blur Remover & DOM Modifier - Content Script Engine (top frame only)
 *
 * Tier 1: declarative CSS from rules + presets, delivered as a constructed stylesheet
 *         (adoptedStyleSheets; sites cannot remove it) with a <style> fallback.
 * Tier 2: a throttled MutationObserver that only processes nodes that actually changed:
 *         computed-style blur/overlay detection, scroll-lock repair, pagination re-enabling.
 * Also: per-tab instant unblur, zap + undo, match-count badge reports, real statistics,
 *       dark mode orchestration (see dark-mode.js) and auto-open Reader View.
 */

(function () {
  'use strict';

  if (window.top !== window) return;

  // After an extension update the old content script keeps running without a connection to the
  // extension ("orphaned"). Ask any such engine to remove its styles and listeners first; a live
  // engine ignores this (see onTakeover), so duplicate injections stay harmless.
  const TAKEOVER_EVENT = 'blur-remover-takeover';
  document.dispatchEvent(new CustomEvent(TAKEOVER_EVENT));
  if (self.BlurRemoverEngine) return;

  const Storage = self.BlurRemoverStorage;
  const Dom = self.BlurRemoverDom;
  if (!Storage || !Dom) return;

  const STYLE_ID = 'blur-remover-dynamic-styles';
  const OWN_ID_PREFIX = 'blur-remover';
  const READER_LOCK_ATTR = 'data-br-reader-lock';
  const FLUSH_DELAY = 250;
  const REPORT_DELAY = 1000;
  const SCAN_SLICE = 400;
  const RELEVANT_STORAGE_KEYS = ['br_core', 'br_rules', 'br_packs', 'br_sites'];

  const PAGINATION = '[class*="pagination"], [class*="pager"], nav[aria-label*="pag" i]';
  const CLICK_TARGETS = [
    `:is(${PAGINATION}) :is(a, button, [role="button"], li, span)`,
    'a[href][aria-disabled="true"]',
    'a[href].disabled'
  ].join(', ');

  const COOKIE_BANNER_SELECTORS = [
    '#onetrust-banner-sdk', '#onetrust-consent-sdk', '.onetrust-pc-dark-filter',
    '#CybotCookiebotDialog', '#CybotCookiebotDialogBodyUnderlay',
    '#usercentrics-root', '#didomi-host', '.didomi-popup-backdrop',
    '.qc-cmp2-container', '#qc-cmp2-container', '.fc-consent-root',
    '#truste-consent-track', '.truste_overlay', '.truste_box_overlay',
    '#cookie-law-info-bar', '.cli-modal-backdrop', '#cookie-notice',
    '#cmplz-cookiebanner-container', '.cmplz-cookiebanner', '#moove_gdpr_cookie_info_bar',
    '.osano-cm-window', '#hs-eu-cookie-confirmation', '#iubenda-cs-banner', '.iubenda-cs-container',
    '.cc-window', '.cc-banner', '[id^="sp_message_container"]', '.sp_veil',
    '[class*="cookie-banner"]', '[id*="cookie-banner"]', '[id*="cookie-consent"]', '[class*="cookie-consent"]',
    '[role="dialog"][aria-label*="cookie" i]', '[role="dialog"][aria-describedby*="cookie" i]',
    '[class*="newsletter-popup"]', '[id*="newsletter-popup"]', '[class*="newsletter-modal"]', '[id*="newsletter-modal"]',
    '.pum-overlay'
  ];

  const COPY_EVENTS = ['copy', 'cut', 'paste', 'contextmenu', 'selectstart', 'dragstart'];
  const COPY_BLOCK_ATTRS = ['oncopy', 'oncut', 'onpaste', 'oncontextmenu', 'onselectstart', 'ondragstart'];

  let settings = null;
  let instantUnblur = false;
  let domReady = false;
  let currentHref = location.href;

  let sheet = null;
  let styleEl = null;
  const supportsAdopted = 'adoptedStyleSheets' in Document.prototype && 'replaceSync' in CSSStyleSheet.prototype;

  let observer = null;
  let flushTimer = null;
  const pendingRoots = new Set();
  const pendingTargets = new Set();

  const scanQueue = [];
  let scanScheduled = false;
  const countedBlur = new WeakSet();
  const countedOverlay = new WeakSet();
  const reenabled = new WeakSet();
  const pendingStats = { blurs: 0, overlays: 0, scrolls: 0 };
  let statsTimer = null;

  let reportTimer = null;
  let lastReport = '';
  let lastContextTarget = null;
  let copyUnlockActive = false;
  let darkTimer = null;
  let autoReaderTried = false;
  let urlTimer = null;
  let tornDown = false;

  // ---------------------------------------------------------------------------
  // State helpers
  // ---------------------------------------------------------------------------

  function host() {
    return location.hostname;
  }

  function isActive() {
    return !!(settings && settings.enabled && !Storage.isSitePaused(settings, host()));
  }

  /** Global presets with this site's own overrides applied. */
  function presets() {
    return settings ? Storage.getEffectivePresets(settings, host()) : {};
  }

  function isOwnNode(el) {
    if (!el || el.nodeType !== 1) return false;
    const root = el.closest ? el.closest(`[id^="${OWN_ID_PREFIX}"]`) : null;
    return !!root;
  }

  function needsScan() {
    const p = presets();
    return isActive() && (p.magicAutoUnblur || p.globalUnblur || p.unblurText || p.overlayEraser || instantUnblur);
  }

  function addStat(key, n = 1) {
    pendingStats[key] += n;
    if (!statsTimer) {
      statsTimer = setTimeout(() => {
        statsTimer = null;
        const deltas = Object.assign({}, pendingStats);
        pendingStats.blurs = pendingStats.overlays = pendingStats.scrolls = 0;
        if (deltas.blurs || deltas.overlays || deltas.scrolls) {
          Storage.recordStats(host(), deltas).catch(() => {});
        }
      }, 5000);
    }
  }

  // ---------------------------------------------------------------------------
  // Tier 1: stylesheet
  // ---------------------------------------------------------------------------

  function ruleCss(rule) {
    const sel = rule.selector;
    if (!Dom.isValidSelector(sel)) {
      console.warn('[BlurRemover] Skipping invalid selector:', sel);
      return '';
    }
    const header = `/* Rule: ${Dom.sanitizeCssComment(rule.name || rule.id)} */\n`;
    switch (rule.actionType) {
      case 'hide':
        return `${header}${sel} { display: none !important; }`;
      case 'visibility-hidden':
        return `${header}${sel} { visibility: hidden !important; }`;
      case 'unlock-scroll':
        return `${header}${sel} { overflow: auto !important; height: auto !important; max-height: none !important; }`;
      case 'enable-pointer': {
        const list = Dom.splitSelectorList(sel).flatMap((part) => [part, `${part} *`]).join(', ');
        return `${header}${list} { pointer-events: auto !important; cursor: pointer !important; opacity: 1 !important; user-select: auto !important; }`;
      }
      case 'custom-css': {
        const decls = Dom.sanitizeDeclarations(rule.customCss);
        if (!decls) {
          console.warn('[BlurRemover] Skipping rule with invalid custom CSS:', rule.name);
          return '';
        }
        return `${header}${sel} { ${decls} }`;
      }
      case 'remove-blur':
      default:
        return `${header}${sel} { backdrop-filter: none !important; -webkit-backdrop-filter: none !important; filter: none !important; -webkit-filter: none !important; }`;
    }
  }

  function buildStylesheet() {
    if (!isActive()) return '';
    const p = presets();
    const parts = ['/* Blur Remover: rules & presets */'];

    Storage.getRulesForHost(settings, host(), location.href).forEach((rule) => {
      const css = ruleCss(rule);
      if (css) parts.push(css);
    });

    // Markers set by the computed-style scanner.
    parts.push(`[data-br-unblur] { filter: none !important; -webkit-filter: none !important; backdrop-filter: none !important; -webkit-backdrop-filter: none !important; }
[data-br-unblur-text] { color: inherit !important; text-shadow: none !important; filter: none !important; user-select: text !important; }
[data-br-overlay] { display: none !important; }`);

    if (p.globalUnblur || instantUnblur) {
      parts.push(`/* Global unblur (inline styles, before the scanner runs) */
[style*="blur("] { filter: none !important; -webkit-filter: none !important; backdrop-filter: none !important; -webkit-backdrop-filter: none !important; }`);
    }

    if (p.scrollUnlock) {
      parts.push(`/* Scroll unlock */
html:not([${READER_LOCK_ATTR}]) { overflow-y: auto !important; max-height: none !important; }
html:not([${READER_LOCK_ATTR}]) > body { overflow-y: visible !important; overflow-x: clip !important; max-height: none !important; }`);
      // body must not become its own scroll box (html/body { height: 100% } sites): the viewport scrolls via <html>.
      // overflow-x: clip (not hidden) keeps horizontal clipping without turning overflow-y: visible into auto.
    }

    if (p.overlayEraser) {
      parts.push(`/* Overlay eraser */
.modal-backdrop, [class*="modal-backdrop"], [class*="overlay-bg"], .fancybox-overlay, .reveal-overlay, .ReactModal__Overlay--after-open:empty { display: none !important; }`);
    }

    if (p.unblurText) {
      parts.push(`/* Unblur text */
[class*="blur-text"], [class*="text-blur"], [class*="blurred-text"] { filter: none !important; -webkit-filter: none !important; color: inherit !important; text-shadow: none !important; user-select: text !important; }`);
    }

    if (p.enableDisabledClicks) {
      parts.push(`/* Enable clicks (pagination & disabled links, never form controls) */
:is(${CLICK_TARGETS}):not(form *):not([type="submit"]) { pointer-events: auto !important; cursor: pointer !important; opacity: 1 !important; }`);
    }

    if (p.cookieBannerRemover) {
      parts.push(`/* Cookie banners & newsletter popups */
${COOKIE_BANNER_SELECTORS.join(',\n')} { display: none !important; }`);
    }

    if (p.unlockCopy) {
      parts.push(`/* Re-enable text selection */
html *:not(input):not(textarea) { -webkit-user-select: text !important; user-select: text !important; -webkit-touch-callout: default !important; }`);
    }

    return parts.join('\n');
  }

  function ensureSheetAttached() {
    if (sheet && supportsAdopted) {
      try {
        const list = document.adoptedStyleSheets;
        if (!list.includes(sheet)) document.adoptedStyleSheets = [...list, sheet];
        return;
      } catch (e) { /* fall through to <style> */ }
    }
    if (styleEl && !styleEl.isConnected) {
      (document.head || document.documentElement).appendChild(styleEl);
    }
  }

  function setCss(css) {
    if (supportsAdopted) {
      try {
        if (!sheet) sheet = new CSSStyleSheet();
        sheet.replaceSync(css || '');
        if (css) {
          ensureSheetAttached();
        } else if (document.adoptedStyleSheets.includes(sheet)) {
          document.adoptedStyleSheets = document.adoptedStyleSheets.filter((s) => s !== sheet);
        }
        return;
      } catch (e) {
        sheet = null; // fallback below
      }
    }
    if (!css) {
      if (styleEl) styleEl.remove();
      return;
    }
    if (!styleEl) {
      styleEl = document.createElement('style');
      styleEl.id = STYLE_ID;
      styleEl.setAttribute('data-extension', 'blur-remover');
    }
    styleEl.textContent = css;
    // Append last so equal-specificity site rules don't win.
    (document.head || document.documentElement).appendChild(styleEl);
  }

  // ---------------------------------------------------------------------------
  // Dark mode orchestration (rendering lives in dark-mode.js)
  // ---------------------------------------------------------------------------

  function timeToMinutes(value) {
    const [h, m] = String(value || '0:0').split(':').map(Number);
    return (h || 0) * 60 + (m || 0);
  }

  function isWithinSchedule(start, end) {
    const now = new Date();
    const cur = now.getHours() * 60 + now.getMinutes();
    const s = timeToMinutes(start);
    const e = timeToMinutes(end);
    return s <= e ? cur >= s && cur < e : cur >= s || cur < e;
  }

  const systemDark = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;

  function computeDarkConfig() {
    if (!isActive()) return null;
    const mode = Storage.getEffectiveDarkMode(settings, host());
    if (!mode) return null;
    const dm = settings.darkMode;
    if (dm.automation === 'system' && !(systemDark && systemDark.matches)) return null;
    if (dm.automation === 'schedule' && !isWithinSchedule(dm.scheduleStart, dm.scheduleEnd)) return null;
    return {
      mode,
      // Dark mode switched on for this site on purpose: don't skip it as "already dark".
      force: !!Storage.getSiteDarkOverride(settings, host()),
      brightness: dm.brightness,
      contrast: dm.contrast,
      sepia: dm.sepia,
      grayscale: dm.grayscale,
      dimImages: dm.dimImages
    };
  }

  function applyDarkMode() {
    const Dark = self.BlurRemoverDarkMode;
    if (!Dark) return;
    const config = computeDarkConfig();
    if (config) Dark.apply(config);
    else Dark.remove();

    clearInterval(darkTimer);
    darkTimer = null;
    if (isActive() && Storage.getEffectiveDarkMode(settings, host()) && settings.darkMode.automation === 'schedule') {
      darkTimer = setInterval(applyDarkMode, 60 * 1000);
    }
  }

  if (systemDark && systemDark.addEventListener) {
    systemDark.addEventListener('change', () => {
      if (settings && settings.darkMode.automation === 'system') applyDarkMode();
    });
  }

  // ---------------------------------------------------------------------------
  // Copy / right-click unlock
  // ---------------------------------------------------------------------------

  function stopSiteHandler(e) {
    if (isOwnNode(e.target)) return;
    // Stopping the event here also hides it from our own document-level listener, so keep
    // track of the right-clicked element for "Pick / Zap this element".
    if (e.type === 'contextmenu') lastContextTarget = e.composedPath ? e.composedPath()[0] : e.target;
    e.stopImmediatePropagation();
  }

  function setCopyUnlock(on) {
    if (on === copyUnlockActive) return;
    copyUnlockActive = on;
    COPY_EVENTS.forEach((type) => {
      if (on) window.addEventListener(type, stopSiteHandler, true);
      else window.removeEventListener(type, stopSiteHandler, true);
    });
    if (on && domReady) stripCopyBlockAttributes(document);
  }

  function stripCopyBlockAttributes(root) {
    const selector = COPY_BLOCK_ATTRS.map((a) => `[${a}]`).join(',');
    const nodes = [];
    if (root.nodeType === 1 && root.matches(selector)) nodes.push(root);
    if (root.querySelectorAll) nodes.push(...root.querySelectorAll(selector));
    nodes.forEach((el) => COPY_BLOCK_ATTRS.forEach((a) => el.removeAttribute(a)));
  }

  // ---------------------------------------------------------------------------
  // Tier 2: targeted dynamic fixes
  // ---------------------------------------------------------------------------

  function cookieBannerPresent() {
    if (!presets().cookieBannerRemover) return false;
    try {
      return !!document.querySelector(COOKIE_BANNER_SELECTORS.join(','));
    } catch (e) {
      return false;
    }
  }

  /** Repairs scroll locks. Only writes when something is actually locked. */
  function enforceScroll() {
    if (!isActive()) return;
    const html = document.documentElement;
    const body = document.body;
    if (!html || !body || html.hasAttribute(READER_LOCK_ATTR)) return;
    if (!presets().scrollUnlock && !cookieBannerPresent()) return;

    let unlocked = false;
    const htmlStyle = getComputedStyle(html);
    if (htmlStyle.overflowY === 'hidden' || htmlStyle.overflowY === 'clip') {
      html.style.setProperty('overflow-y', 'auto', 'important');
      unlocked = true;
    }
    // Unlock <body> by making it non-scrolling, so the viewport (via <html>) does the scrolling.
    const bodyOverflow = getComputedStyle(body);
    if (bodyOverflow.overflowY === 'hidden' || bodyOverflow.overflowY === 'clip') {
      body.style.setProperty('overflow-y', 'visible', 'important');
      body.style.setProperty('overflow-x', 'clip', 'important');
      unlocked = true;
    }

    // iOS-style lock: body { position: fixed; top: -<scrollY>px }
    const bodyStyle = getComputedStyle(body);
    if (bodyStyle.position === 'fixed') {
      const top = parseFloat(body.style.top) || 0;
      body.style.setProperty('position', 'static', 'important');
      body.style.setProperty('top', 'auto', 'important');
      if (top < 0) window.scrollTo(0, -top);
      unlocked = true;
    }

    if (unlocked) addStat('scrolls');
  }

  function processClickTargets(root) {
    if (!isActive() || !presets().enableDisabledClicks || !root || root.nodeType !== 1) return;
    const candidates = [];
    try {
      if (root.matches(CLICK_TARGETS)) candidates.push(root);
      candidates.push(...root.querySelectorAll(CLICK_TARGETS));
    } catch (e) {
      return;
    }
    candidates.forEach((el) => {
      if (el.closest('form') || el.getAttribute('type') === 'submit' || isOwnNode(el)) return;
      let changed = false;
      if (el.hasAttribute('disabled')) { el.removeAttribute('disabled'); changed = true; }
      if (el.getAttribute('aria-disabled') === 'true') { el.removeAttribute('aria-disabled'); changed = true; }
      if (el.style.getPropertyValue('pointer-events') !== 'auto') {
        el.style.setProperty('pointer-events', 'auto', 'important');
        changed = true;
      }
      if (changed) reenabled.add(el);
    });
  }

  /** Falls back to navigation when a site swallows clicks on pagination we re-enabled. */
  function onPaginationClick(e) {
    if (!isActive() || !presets().enableDisabledClicks) return;
    if (e.button !== 0 || e.ctrlKey || e.metaKey || e.shiftKey || e.altKey) return;

    let target = e.composedPath ? e.composedPath()[0] : e.target;
    while (target && target.nodeType === 1 && target !== document.body) {
      if (reenabled.has(target)) {
        const raw = target.getAttribute('href') || target.getAttribute('data-href') || target.getAttribute('data-url');
        if (!raw || raw === '#' || /^javascript:/i.test(raw)) return;
        let url;
        try {
          url = new URL(raw, location.href);
        } catch (err) {
          return;
        }
        if (!/^https?:$/.test(url.protocol)) return;
        e.preventDefault();
        e.stopPropagation();
        location.href = url.href;
        return;
      }
      target = target.parentElement;
    }
  }
  document.addEventListener('click', onPaginationClick, true);

  // ---------------------------------------------------------------------------
  // Computed-style scanner (magic unblur, global unblur, text unblur, overlays)
  // ---------------------------------------------------------------------------

  function hasOwnText(el) {
    for (const node of el.childNodes) {
      if (node.nodeType === 3 && node.textContent.trim().length > 1) return true;
    }
    return false;
  }

  function examine(el) {
    if (el.hasAttribute('data-br-unblur') || el.hasAttribute('data-br-overlay') || isOwnNode(el)) return;
    const p = presets();
    const cs = getComputedStyle(el);
    const filter = cs.filter || '';
    const backdrop = cs.backdropFilter || cs.webkitBackdropFilter || '';
    const filterBlur = filter.includes('blur(');
    const backdropBlur = backdrop.includes('blur(');
    const aggressive = p.globalUnblur || instantUnblur;

    if (filterBlur || backdropBlur) {
      let mark = aggressive;
      if (!mark && p.magicAutoUnblur) {
        if (backdropBlur) {
          mark = true;
        } else {
          const rect = el.getBoundingClientRect();
          const area = rect.width * rect.height;
          const viewport = window.innerWidth * window.innerHeight;
          mark = area > viewport * 0.3 || (el.textContent || '').trim().length > 40;
        }
      }
      if (mark) {
        el.setAttribute('data-br-unblur', '');
        if (!countedBlur.has(el)) {
          countedBlur.add(el);
          addStat('blurs');
        }
      }
    }

    // Blurred text trick: transparent glyphs + blurred text-shadow (not gradient text).
    if ((p.magicAutoUnblur || p.unblurText || aggressive) && cs.textShadow !== 'none' && /rgba\(0, 0, 0, 0\)|transparent/.test(cs.color)) {
      const clip = cs.webkitBackgroundClip || cs.backgroundClip || '';
      if (clip !== 'text' && hasOwnText(el) && !el.hasAttribute('data-br-unblur-text')) {
        el.setAttribute('data-br-unblur-text', '');
        if (!countedBlur.has(el)) {
          countedBlur.add(el);
          addStat('blurs');
        }
      }
    }

    // Empty full-screen scrims.
    if (p.overlayEraser && cs.position === 'fixed') {
      const rect = el.getBoundingClientRect();
      const coversViewport = rect.width >= window.innerWidth * 0.7 && rect.height >= window.innerHeight * 0.7;
      if (coversViewport && (el.textContent || '').trim().length < 20 && !el.querySelector('img, video, canvas, iframe')) {
        const bg = cs.backgroundColor.match(/rgba?\(([^)]+)\)/);
        const alpha = bg ? Number((bg[1].split(',')[3] || '1').trim()) : 0;
        if (backdropBlur || (alpha > 0.05 && alpha < 0.98)) {
          el.setAttribute('data-br-overlay', '');
          if (!countedOverlay.has(el)) {
            countedOverlay.add(el);
            addStat('overlays');
          }
        }
      }
    }
  }

  function queueScan(root, deep) {
    if (!root || root.nodeType !== 1 || !needsScan()) return;
    scanQueue.push({ root, deep });
    if (!scanScheduled) {
      scanScheduled = true;
      (window.requestIdleCallback || ((cb) => setTimeout(cb, 50)))(runScanSlice, { timeout: 300 });
    }
  }

  let activeWalker = null;

  function runScanSlice() {
    scanScheduled = false;
    let budget = SCAN_SLICE;
    while (budget > 0) {
      if (!activeWalker) {
        const job = scanQueue.shift();
        if (!job) break;
        if (!job.root.isConnected) continue;
        examine(job.root);
        budget--;
        if (!job.deep) continue;
        activeWalker = document.createTreeWalker(job.root, NodeFilter.SHOW_ELEMENT);
      }
      const next = activeWalker.nextNode();
      if (!next) {
        activeWalker = null;
        continue;
      }
      examine(next);
      budget--;
    }
    if (activeWalker || scanQueue.length) {
      scanScheduled = true;
      (window.requestIdleCallback || ((cb) => setTimeout(cb, 50)))(runScanSlice, { timeout: 300 });
    }
  }

  // ---------------------------------------------------------------------------
  // Observer
  // ---------------------------------------------------------------------------

  function setupObserver() {
    if (observer) observer.disconnect();
    observer = new MutationObserver((records) => {
      for (const record of records) {
        if (record.type === 'childList') {
          record.addedNodes.forEach((node) => {
            if (node.nodeType === 1 && !isOwnNode(node)) pendingRoots.add(node);
          });
        } else if (record.target.nodeType === 1 && !isOwnNode(record.target)) {
          pendingTargets.add(record.target);
        }
      }
      if (!flushTimer) flushTimer = setTimeout(flush, FLUSH_DELAY);
    });
    observer.observe(document.documentElement, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ['style', 'class', 'disabled', 'aria-disabled', 'hidden']
    });
  }

  function flush() {
    flushTimer = null;
    if (location.href !== currentHref) {
      onUrlChange();
    }

    const roots = Array.from(pendingRoots);
    const targets = Array.from(pendingTargets);
    pendingRoots.clear();
    pendingTargets.clear();

    if (!isActive()) return;
    ensureSheetAttached();

    const html = document.documentElement;
    if (targets.some((t) => t === html || t === document.body) || roots.length) enforceScroll();

    roots.forEach((root) => {
      processClickTargets(root);
      queueScan(root, true);
      if (copyUnlockActive) stripCopyBlockAttributes(root);
    });
    targets.forEach((t) => {
      processClickTargets(t);
      queueScan(t, false);
    });

    scheduleReport();
  }

  function fullPass() {
    if (!domReady) return;
    enforceScroll();
    if (isActive()) {
      processClickTargets(document.documentElement);
      queueScan(document.documentElement, true);
      if (copyUnlockActive) stripCopyBlockAttributes(document);
    }
    scheduleReport(true);
  }

  function onUrlChange() {
    currentHref = location.href;
    applyAll(); // exact-path rules depend on the URL
  }

  // SPA navigations without DOM mutations near the root; also notices when the extension was
  // updated or removed (orphaned script) and then cleans up after itself.
  urlTimer = setInterval(() => {
    if (isOrphaned()) {
      teardown();
      return;
    }
    if (location.href !== currentHref) onUrlChange();
    else if (isActive()) ensureSheetAttached();
  }, 1500);
  function onPopState() {
    setTimeout(() => { if (location.href !== currentHref) onUrlChange(); }, 50);
  }
  window.addEventListener('popstate', onPopState);

  // ---------------------------------------------------------------------------
  // Badge reports
  // ---------------------------------------------------------------------------

  function computeMatches() {
    if (!isActive()) return [];
    return Storage.getRulesForHost(settings, host(), location.href).filter((rule) => {
      if (!Dom.isValidSelector(rule.selector)) return false;
      try {
        return !!document.querySelector(rule.selector);
      } catch (e) {
        return false;
      }
    });
  }

  function scheduleReport(force) {
    if (reportTimer && !force) return;
    clearTimeout(reportTimer);
    reportTimer = setTimeout(sendReport, force ? 50 : REPORT_DELAY);
  }

  function sendReport() {
    reportTimer = null;
    if (!settings) return;
    const report = {
      type: 'MATCH_COUNT',
      enabled: settings.enabled,
      paused: Storage.isSitePaused(settings, host()),
      matchCount: computeMatches().length,
      url: location.href
    };
    const key = JSON.stringify(report);
    if (key === lastReport) return;
    lastReport = key;
    Dom.sendMessage(report);
  }

  // ---------------------------------------------------------------------------
  // Apply everything
  // ---------------------------------------------------------------------------

  let scanSignature = '';

  /** When the scanner's criteria change (e.g. instant unblur turned off), drop old markers and rescan. */
  function resetMarkersIfNeeded() {
    const p = presets();
    const signature = JSON.stringify([isActive(), p.magicAutoUnblur, p.globalUnblur, p.unblurText, p.overlayEraser, instantUnblur]);
    if (signature === scanSignature) return;
    const first = scanSignature === '';
    scanSignature = signature;
    scanQueue.length = 0;
    activeWalker = null;
    if (first) return;
    document.querySelectorAll('[data-br-unblur], [data-br-unblur-text], [data-br-overlay]').forEach((el) => {
      el.removeAttribute('data-br-unblur');
      el.removeAttribute('data-br-unblur-text');
      el.removeAttribute('data-br-overlay');
    });
  }

  function applyAll() {
    if (!settings) return;
    setCss(buildStylesheet());
    applyDarkMode();
    setCopyUnlock(isActive() && !!presets().unlockCopy);
    resetMarkersIfNeeded();
    fullPass();
    scheduleReport(true);
  }

  async function reloadSettings() {
    if (tornDown) return;
    settings = await Storage.getSettings();
    applyAll();
  }

  let reloadTimer = null;
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.onChanged) {
    chrome.storage.onChanged.addListener((changes) => {
      if (!Object.keys(changes).some((k) => RELEVANT_STORAGE_KEYS.includes(k))) return;
      clearTimeout(reloadTimer);
      reloadTimer = setTimeout(reloadSettings, 80);
    });
  }

  // ---------------------------------------------------------------------------
  // Messages, context menu target, undo
  // ---------------------------------------------------------------------------

  function onContextMenu(e) {
    lastContextTarget = e.composedPath ? e.composedPath()[0] : e.target;
  }
  document.addEventListener('contextmenu', onContextMenu, true);

  function onUndoKey(e) {
    if (!(e.ctrlKey || e.metaKey) || e.shiftKey || !e.key || e.key.toLowerCase() !== 'z') return;
    const target = e.composedPath ? e.composedPath()[0] : e.target;
    if (Dom.isEditableTarget(target) || !Dom.hasRecentUndo()) return;
    e.preventDefault();
    e.stopPropagation();
    Dom.undoLast().then((what) => {
      if (what) Dom.showToast(what === 'rule' ? 'Rule removed (undo)' : 'Element restored', { type: 'success' });
    });
  }
  window.addEventListener('keydown', onUndoKey, true);

  // ---------------------------------------------------------------------------
  // Orphaned script clean-up (extension updated, reloaded or removed)
  // ---------------------------------------------------------------------------

  function isOrphaned() {
    try {
      return !chrome.runtime || !chrome.runtime.id;
    } catch (e) {
      return true;
    }
  }

  function teardown() {
    if (tornDown) return;
    tornDown = true;
    if (observer) observer.disconnect();
    observer = null;
    [flushTimer, reportTimer, statsTimer, reloadTimer].forEach(clearTimeout);
    clearInterval(urlTimer);
    clearInterval(darkTimer);
    scanQueue.length = 0;
    activeWalker = null;
    setCopyUnlock(false);
    setCss('');
    if (self.BlurRemoverDarkMode) {
      try { self.BlurRemoverDarkMode.remove(); } catch (e) { /* ignore */ }
    }
    document.removeEventListener('click', onPaginationClick, true);
    document.removeEventListener('contextmenu', onContextMenu, true);
    document.removeEventListener(TAKEOVER_EVENT, onTakeover);
    window.removeEventListener('keydown', onUndoKey, true);
    window.removeEventListener('popstate', onPopState);
    document.querySelectorAll('[data-br-unblur], [data-br-unblur-text], [data-br-overlay]').forEach((el) => {
      el.removeAttribute('data-br-unblur');
      el.removeAttribute('data-br-unblur-text');
      el.removeAttribute('data-br-overlay');
    });
    delete self.BlurRemoverEngine;
    delete self.BlurRemoverDarkMode;
  }

  /** A newer copy of the engine was injected: step aside if this one has lost the extension. */
  function onTakeover() {
    if (isOrphaned()) teardown();
  }
  document.addEventListener(TAKEOVER_EVENT, onTakeover);

  function zapContextTarget() {
    const el = lastContextTarget && lastContextTarget.isConnected ? lastContextTarget : null;
    if (!el || el === document.documentElement || el === document.body) {
      Dom.showToast('Right-click the element you want to zap first.', { type: 'error' });
      return false;
    }
    Dom.zap(el);
    Dom.showToast('Element zapped for this visit.', {
      type: 'success',
      duration: 6000,
      actionLabel: 'Undo',
      onAction: () => Dom.undoZap()
    });
    return true;
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!message || !message.action) return false;
    switch (message.action) {
      case 'REFRESH_STYLES':
        reloadSettings().then(() => sendResponse({ status: 'ok' }));
        return true;

      case 'SET_INSTANT_UNBLUR':
        instantUnblur = !!message.on;
        applyAll();
        if (message.announce) {
          Dom.showToast(instantUnblur ? 'Instant unblur ON for this tab' : 'Instant unblur OFF for this tab', { type: instantUnblur ? 'success' : 'info' });
        }
        sendResponse({ status: 'ok', on: instantUnblur });
        return false;

      case 'GET_PAGE_INFO': {
        const Dark = self.BlurRemoverDarkMode;
        const matched = computeMatches();
        sendResponse({
          host: host(),
          url: location.href,
          enabled: !!(settings && settings.enabled),
          paused: settings ? Storage.isSitePaused(settings, host()) : false,
          instantUnblur,
          matchCount: matched.length,
          matchedRuleIds: matched.map((r) => r.id),
          dark: Dark ? Dark.getStatus() : { active: false, mode: null, skippedReason: '' }
        });
        return false;
      }

      case 'TEST_SELECTOR':
        sendResponse(Dom.testSelector(message.selector));
        return false;

      case 'ZAP_CONTEXT_TARGET':
        sendResponse({ status: zapContextTarget() ? 'ok' : 'no-target' });
        return false;

      case 'SHOW_TOAST':
        Dom.showToast(message.text, { type: message.toastType || 'info' });
        sendResponse({ status: 'ok' });
        return false;

      default:
        return false;
    }
  });

  // ---------------------------------------------------------------------------
  // Public API for the picker / reader (same isolated world)
  // ---------------------------------------------------------------------------

  self.BlurRemoverEngine = {
    getSettings: () => settings,
    getPresets: presets,
    getContextTarget: () => (lastContextTarget && lastContextTarget.isConnected ? lastContextTarget : null),
    refresh: reloadSettings,
    READER_LOCK_ATTR
  };

  // ---------------------------------------------------------------------------
  // Init
  // ---------------------------------------------------------------------------

  function onDomReady() {
    domReady = true;
    setupObserver();
    fullPass();
    maybeAutoOpenReader();
  }

  function maybeAutoOpenReader() {
    if (autoReaderTried || !isActive() || !Storage.isAutoReaderSite(settings, host())) return;
    autoReaderTried = true;
    const open = () => Dom.sendMessage({ type: 'AUTO_OPEN_READER' });
    if (document.readyState === 'complete') setTimeout(open, 300);
    else window.addEventListener('load', () => setTimeout(open, 300), { once: true });
  }

  (async function init() {
    settings = await Storage.getSettings();
    const state = await Dom.sendMessage({ type: 'GET_TAB_STATE' });
    instantUnblur = !!(state && state.ok && state.result && state.result.instantUnblur);
    applyAll();

    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', onDomReady, { once: true });
    } else {
      onDomReady();
    }
  })();
})();
