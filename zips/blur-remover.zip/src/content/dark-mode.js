/**
 * Blur Remover & DOM Modifier - Dark Mode renderer (top frame only)
 *
 * Two modes, driven by content-engine.js through self.BlurRemoverDarkMode:
 *   filter  - inverts the whole page with a root filter and re-inverts media, so outlined
 *             text, icons and brand colours keep their relationships. Fast, works everywhere.
 *   dynamic - rewrites the page's own colours: every stylesheet rule (and inline style) is
 *             re-emitted with HSL-remapped colours. Light backgrounds become dark, dark text
 *             becomes light, saturated brand colours keep their hue and only shift lightness.
 *
 * Pages that are already dark are detected and left alone.
 */

(function () {
  'use strict';

  if (self.BlurRemoverDarkMode) return;

  const OWN_HOSTS = '#blur-remover-picker-root, #blur-remover-reader-root, #blur-remover-toast-root';
  const MEDIA = 'img, video, picture, canvas, iframe, embed, object, svg image, [data-br-media]';
  const MEDIA_CONTAINERS = 'picture, iframe, embed, object, [data-br-media]';
  const MEDIA_ATTR = 'data-br-media';
  const DYN_ATTR = 'data-br-dyn';
  const DARK_BG = { r: 18, g: 20, b: 24 };
  const BASE_TEXT = 'rgb(227, 230, 234)';
  const SLICE = 300;

  const supportsAdopted = 'adoptedStyleSheets' in Document.prototype && 'replaceSync' in CSSStyleSheet.prototype;

  let config = null;
  let configKey = '';
  let active = false;
  let skippedReason = '';
  let sheet = null;
  let styleEl = null;
  let sheetAttached = false;
  let observer = null;
  let pollTimer = null;
  let renderTimer = null;
  let readyHooked = false;

  // ---------------------------------------------------------------------------
  // Stylesheet plumbing
  // ---------------------------------------------------------------------------

  function attachSheet() {
    if (sheet) {
      try {
        if (!document.adoptedStyleSheets.includes(sheet)) document.adoptedStyleSheets = [...document.adoptedStyleSheets, sheet];
        sheetAttached = true;
        return;
      } catch (e) { /* fallback */ }
    }
    if (styleEl && !styleEl.isConnected) (document.head || document.documentElement).appendChild(styleEl);
    sheetAttached = true;
  }

  function detachSheet() {
    if (sheet) {
      try {
        if (document.adoptedStyleSheets.includes(sheet)) document.adoptedStyleSheets = document.adoptedStyleSheets.filter((s) => s !== sheet);
      } catch (e) { /* ignore */ }
    }
    if (styleEl) styleEl.remove();
    sheetAttached = false;
  }

  function setCss(css) {
    if (supportsAdopted && styleEl === null) {
      try {
        if (!sheet) sheet = new CSSStyleSheet();
        sheet.replaceSync(css);
        attachSheet();
        return;
      } catch (e) {
        sheet = null;
      }
    }
    if (!styleEl) {
      styleEl = document.createElement('style');
      styleEl.id = 'blur-remover-dark-mode';
      styleEl.setAttribute('data-extension', 'blur-remover');
    }
    styleEl.textContent = css;
    (document.head || document.documentElement).appendChild(styleEl);
    sheetAttached = true;
  }

  // ---------------------------------------------------------------------------
  // Colour maths
  // ---------------------------------------------------------------------------

  const KEYWORDS = new Set(['transparent', 'currentcolor', 'inherit', 'initial', 'unset', 'revert', 'revert-layer', 'none', 'auto']);
  const colorCache = new Map();
  let ctx2d = null;

  function canvasCtx() {
    if (!ctx2d) {
      try {
        ctx2d = document.createElement('canvas').getContext('2d');
      } catch (e) {
        ctx2d = null;
      }
    }
    return ctx2d;
  }

  function clamp(v, min, max) {
    return Math.min(max, Math.max(min, v));
  }

  function parseNumber(part, scale) {
    if (part.endsWith('%')) return (parseFloat(part) / 100) * scale;
    return parseFloat(part);
  }

  function hslToRgb(h, s, l) {
    h = ((h % 360) + 360) % 360 / 360;
    if (s === 0) {
      const v = Math.round(l * 255);
      return { r: v, g: v, b: v };
    }
    const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
    const p = 2 * l - q;
    const t = (x) => {
      if (x < 0) x += 1;
      if (x > 1) x -= 1;
      if (x < 1 / 6) return p + (q - p) * 6 * x;
      if (x < 1 / 2) return q;
      if (x < 2 / 3) return p + (q - p) * (2 / 3 - x) * 6;
      return p;
    };
    return { r: Math.round(t(h + 1 / 3) * 255), g: Math.round(t(h) * 255), b: Math.round(t(h - 1 / 3) * 255) };
  }

  function rgbToHsl({ r, g, b }) {
    r /= 255; g /= 255; b /= 255;
    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    const l = (max + min) / 2;
    if (max === min) return { h: 0, s: 0, l };
    const d = max - min;
    const s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    let h;
    if (max === r) h = (g - b) / d + (g < b ? 6 : 0);
    else if (max === g) h = (b - r) / d + 2;
    else h = (r - g) / d + 4;
    return { h: h * 60, s, l };
  }

  function parseFunctional(str) {
    const m = str.match(/^(rgba?|hsla?)\((.*)\)$/);
    if (!m) return null;
    const parts = m[2].split(/[\s,/]+/).filter(Boolean);
    if (parts.length < 3 || parts.some((p) => /[a-z(]/i.test(p.replace(/(deg|%)$/, '')))) return null;
    const alpha = parts[3] !== undefined ? clamp(parseNumber(parts[3], 1), 0, 1) : 1;
    if (m[1].startsWith('rgb')) {
      return {
        r: clamp(Math.round(parseNumber(parts[0], 255)), 0, 255),
        g: clamp(Math.round(parseNumber(parts[1], 255)), 0, 255),
        b: clamp(Math.round(parseNumber(parts[2], 255)), 0, 255),
        a: alpha
      };
    }
    const rgb = hslToRgb(parseFloat(parts[0]), clamp(parseFloat(parts[1]) / 100, 0, 1), clamp(parseFloat(parts[2]) / 100, 0, 1));
    return Object.assign(rgb, { a: alpha });
  }

  function parseHex(str) {
    let hex = str.slice(1);
    if (![3, 4, 6, 8].includes(hex.length) || /[^0-9a-f]/i.test(hex)) return null;
    if (hex.length <= 4) hex = hex.split('').map((c) => c + c).join('');
    return {
      r: parseInt(hex.slice(0, 2), 16),
      g: parseInt(hex.slice(2, 4), 16),
      b: parseInt(hex.slice(4, 6), 16),
      a: hex.length === 8 ? parseInt(hex.slice(6, 8), 16) / 255 : 1
    };
  }

  /** Parses any CSS colour token into {r,g,b,a}; returns null for keywords / non-colours. */
  function parseColor(token) {
    const s = String(token || '').trim().toLowerCase();
    if (!s || KEYWORDS.has(s)) return null;
    if (colorCache.has(s)) return colorCache.get(s);
    let c = null;
    if (s[0] === '#') c = parseHex(s);
    else if (/^(rgba?|hsla?)\(/.test(s)) c = parseFunctional(s);
    else if (/^[a-z]+$/.test(s)) {
      const ctx = canvasCtx();
      if (ctx) {
        ctx.fillStyle = '#010203';
        ctx.fillStyle = s;
        const out = ctx.fillStyle;
        if (out !== '#010203') c = out[0] === '#' ? parseHex(out) : parseFunctional(out);
      }
    }
    colorCache.set(s, c);
    return c;
  }

  function toCss(c) {
    const r = Math.round(c.r);
    const g = Math.round(c.g);
    const b = Math.round(c.b);
    return c.a < 1 ? `rgba(${r}, ${g}, ${b}, ${Math.round(c.a * 1000) / 1000})` : `rgb(${r}, ${g}, ${b})`;
  }

  function luminance({ r, g, b }) {
    const f = (v) => {
      v /= 255;
      return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
    };
    return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b);
  }

  function contrast(a, b) {
    const la = luminance(a);
    const lb = luminance(b);
    return (Math.max(la, lb) + 0.05) / (Math.min(la, lb) + 0.05);
  }

  function withHsl(c, h, s, l) {
    return Object.assign(hslToRgb(h, clamp(s, 0, 1), clamp(l, 0, 1)), { a: c.a });
  }

  function mapBg(c) {
    if (c.a === 0) return null;
    const { h, s, l } = rgbToHsl(c);
    if (l > 0.6) return withHsl(c, h, s * 0.6, 0.06 + (1 - l) * 0.25);
    if (s > 0.4 && l >= 0.25) return l > 0.36 ? withHsl(c, h, s, 0.36) : null; // brand colour: keep hue
    if (l >= 0.25) return withHsl(c, h, s, 0.16 + (0.6 - l) * 0.2);
    return null; // already dark
  }

  function mapFg(c) {
    if (c.a === 0) return null;
    const { h, s, l } = rgbToHsl(c);
    if (s > 0.4) {
      // Coloured text / links: keep hue, lift lightness until readable on the dark base.
      let nl = l;
      let out = withHsl(c, h, s, nl);
      while (contrast(out, DARK_BG) < 4.5 && nl < 0.95) {
        nl += 0.03;
        out = withHsl(c, h, s, nl);
      }
      return nl === l ? null : out;
    }
    if (l < 0.5) return withHsl(c, h, s, 0.9 - l * 0.35);
    return null;
  }

  function mapBorder(c) {
    if (c.a === 0) return null;
    const { h, s, l } = rgbToHsl(c);
    if (l > 0.6) return withHsl(c, h, s * 0.6, 0.2 + (1 - l) * 0.3);
    if (l < 0.3 && s < 0.3) return withHsl(c, h, s, 0.38);
    return null;
  }

  const TOKEN_RE = /#[0-9a-f]{3,8}\b|(?:rgba?|hsla?)\([^()]*\)|\b[a-z]+\b/gi;

  /**
   * Replaces every colour token in a value using `mapper`. Returns null when nothing changed.
   * Colours inside var() fallbacks are remapped too (`var(--body-color, #011a3c)` with an undefined
   * variable renders the fallback), while custom-property names are never treated as colour keywords.
   */
  function remapValue(value, mapper) {
    if (!value || /url\(|env\(|attr\(/i.test(value)) return null;
    let changed = false;
    const out = value
      .split(/(--[\w-]+)/)
      .map((part) => {
        if (part.startsWith('--')) return part;
        return part.replace(TOKEN_RE, (tok) => {
          if (/^var$/i.test(tok)) return tok;
          const c = parseColor(tok);
          if (!c) return tok;
          const mapped = mapper(c);
          if (!mapped) return tok;
          changed = true;
          return toCss(mapped);
        });
      })
      .join('');
    return changed ? out : null;
  }

  // ---------------------------------------------------------------------------
  // Dynamic mode: rule rewriting
  // ---------------------------------------------------------------------------

  const PROP_KIND = {
    color: 'fg',
    'caret-color': 'fg',
    'text-decoration-color': 'fg',
    'column-rule-color': 'border',
    'outline-color': 'border',
    '-webkit-text-stroke-color': 'fg',
    '-webkit-text-fill-color': 'fg',
    fill: 'fg',
    stroke: 'fg',
    'background-color': 'bg',
    'background-image': 'bg',
    'box-shadow': 'bg',
    'text-shadow': 'bg',
    'border-top-color': 'border',
    'border-right-color': 'border',
    'border-bottom-color': 'border',
    'border-left-color': 'border',
    'border-block-start-color': 'border',
    'border-block-end-color': 'border',
    'border-inline-start-color': 'border',
    'border-inline-end-color': 'border'
  };
  const MAPPERS = { bg: mapBg, fg: mapFg, border: mapBorder };

  function kindOfProperty(prop) {
    if (PROP_KIND[prop]) return PROP_KIND[prop];
    if (/^background/.test(prop)) return 'bg';
    if (/^border|^outline/.test(prop)) return 'border';
    if (/shadow$/.test(prop)) return 'bg';
    if (/color$|^fill|^stroke/.test(prop)) return 'fg';
    return null;
  }

  // Custom property usage: --name -> Set(kind)
  const varUsage = new Map();

  function collectVarUsage(cssText) {
    const re = /([a-z-]+)\s*:\s*([^;{}]*var\(--[^;{}]*)/gi;
    let m;
    while ((m = re.exec(cssText))) {
      if (m[1].startsWith('--')) continue;
      const kind = kindOfProperty(m[1].toLowerCase());
      if (!kind) continue;
      const vars = m[2].match(/var\(\s*(--[\w-]+)/g) || [];
      vars.forEach((v) => {
        const name = v.replace(/var\(\s*/, '');
        if (!varUsage.has(name)) varUsage.set(name, new Set());
        varUsage.get(name).add(kind);
      });
    }
  }

  function mapCustomProperty(name, value) {
    const v = value.trim();
    if (!v || /var\(/.test(v)) return null;
    const tokens = v.match(TOKEN_RE) || [];
    if (tokens.length !== 1 || tokens[0].length !== v.length) return null; // only pure colours
    const c = parseColor(v);
    if (!c) return null;
    const kinds = varUsage.get(name);
    let kind;
    if (kinds && kinds.size === 1) kind = Array.from(kinds)[0];
    else kind = rgbToHsl(c).l > 0.5 ? 'bg' : 'fg';
    const mapped = MAPPERS[kind](c);
    return mapped ? toCss(mapped) : null;
  }

  function isClipText(style) {
    const clip = style.getPropertyValue('-webkit-background-clip') || style.getPropertyValue('background-clip');
    return /text/.test(clip);
  }

  /** Builds override declarations for one CSSStyleDeclaration. */
  function overrideDeclarations(style) {
    const out = [];
    const clipText = isClipText(style);
    for (let i = 0; i < style.length; i++) {
      const prop = style[i];
      const value = style.getPropertyValue(prop);
      if (!value) continue;
      const important = style.getPropertyPriority(prop) === 'important' ? ' !important' : '';
      if (prop.startsWith('--')) {
        const mapped = mapCustomProperty(prop, value);
        if (mapped) out.push(`${prop}: ${mapped}${important}`);
        continue;
      }
      let kind = kindOfProperty(prop);
      if (!kind) continue;
      // Gradient text (background-clip: text) is read as text colour, never darkened.
      if (clipText && kind === 'bg' && /^background/.test(prop)) kind = 'fg';
      const mapped = remapValue(value, MAPPERS[kind]);
      if (mapped) out.push(`${prop}: ${mapped}${important}`);
    }
    return out.join('; ');
  }

  function idle() {
    return new Promise((resolve) => (self.requestIdleCallback || ((cb) => setTimeout(cb, 16)))(() => resolve(), { timeout: 200 }));
  }

  /** Converts a CSSRuleList to override CSS text. Yields to the event loop every SLICE rules. */
  async function processRules(rules, budget) {
    let css = '';
    for (const rule of Array.from(rules)) {
      if (--budget.left <= 0) {
        budget.left = SLICE;
        await idle();
        if (!active) return '';
      }
      try {
        if (rule.type === CSSRule.STYLE_RULE) {
          const decls = overrideDeclarations(rule.style);
          const nested = rule.cssRules && rule.cssRules.length ? await processRules(rule.cssRules, budget) : '';
          if (decls || nested) css += `${rule.selectorText} { ${decls}${decls && nested ? '; ' : ''}${nested} }\n`;
        } else if (rule.type === CSSRule.MEDIA_RULE) {
          const inner = await processRules(rule.cssRules, budget);
          if (inner) css += `@media ${rule.conditionText || rule.media.mediaText} {\n${inner}}\n`;
        } else if (rule.type === CSSRule.SUPPORTS_RULE) {
          const inner = await processRules(rule.cssRules, budget);
          if (inner) css += `@supports ${rule.conditionText} {\n${inner}}\n`;
        } else if (rule.type === CSSRule.IMPORT_RULE) {
          if (rule.styleSheet) {
            const inner = await processSheetRules(rule.styleSheet, budget);
            const media = rule.media && rule.media.mediaText;
            if (inner) css += media ? `@media ${media} {\n${inner}}\n` : inner;
          }
        } else if (rule.cssRules && rule.cssRules.length) {
          // @layer blocks, @container, etc. Unlayered overrides win over layers anyway.
          const inner = await processRules(rule.cssRules, budget);
          if (inner) {
            css += rule.conditionText && typeof CSSContainerRule !== 'undefined' && rule instanceof CSSContainerRule
              ? `@container ${rule.containerName ? rule.containerName + ' ' : ''}${rule.conditionText} {\n${inner}}\n`
              : inner;
          }
        }
      } catch (e) { /* skip unreadable rule */ }
    }
    return css;
  }

  async function processSheetRules(styleSheet, budget) {
    let rules;
    try {
      rules = styleSheet.cssRules;
    } catch (e) {
      rules = null; // cross-origin
    }
    if (rules) {
      collectVarUsage(Array.from(rules).map((r) => r.cssText).join('\n'));
      return processRules(rules, budget);
    }
    const href = styleSheet.href;
    if (!href) return '';
    const text = await fetchCrossOriginCss(href);
    if (!text) return '';
    try {
      const parsed = new CSSStyleSheet({ baseURL: href });
      await parsed.replace(text.replace(/@import[^;]+;/gi, ''));
      collectVarUsage(text);
      return processRules(parsed.cssRules, budget);
    } catch (e) {
      return '';
    }
  }

  async function fetchCrossOriginCss(href) {
    const Dom = self.BlurRemoverDom;
    if (!Dom || !Dom.sendMessage) return '';
    const res = await Dom.sendMessage({ type: 'FETCH_STYLESHEET', url: href });
    return res && res.ok && typeof res.result === 'string' ? res.result : '';
  }

  // Per-sheet cache. Key: owner node (link/style) + a cheap fingerprint.
  const sheetCache = new WeakMap(); // ownerNode -> { key, css }
  let sheetOrder = []; // ownerNodes in document order
  const inlineRules = new Map(); // id -> declarations
  let inlineCounter = 0;
  let processing = false;
  let processAgain = false;

  function sheetFingerprint(s) {
    let n = -1;
    try {
      n = s.cssRules.length;
    } catch (e) { /* cross-origin */ }
    const owner = s.ownerNode;
    const textLen = owner && owner.tagName === 'STYLE' ? owner.textContent.length : 0;
    return `${s.href || ''}|${n}|${textLen}|${s.media ? s.media.mediaText : ''}`;
  }

  function ownSheet(s) {
    const owner = s.ownerNode;
    return !owner || (owner.id && owner.id.startsWith('blur-remover')) || (owner.getAttribute && owner.getAttribute('data-extension') === 'blur-remover');
  }

  async function processAllSheets() {
    if (processing) {
      processAgain = true;
      return;
    }
    processing = true;
    try {
      do {
        processAgain = false;
        const budget = { left: SLICE };
        const sheets = Array.from(document.styleSheets).filter((s) => !ownSheet(s) && !s.disabled);
        sheetOrder = sheets.map((s) => s.ownerNode);
        for (const s of sheets) {
          if (!active || !config || config.mode !== 'dynamic') return;
          const key = sheetFingerprint(s);
          const cached = sheetCache.get(s.ownerNode);
          if (cached && cached.key === key) continue;
          let css = await processSheetRules(s, budget);
          const media = s.media && s.media.mediaText;
          if (css && media && media !== 'all') css = `@media ${media} {\n${css}}\n`;
          sheetCache.set(s.ownerNode, { key, css });
          scheduleRender();
        }
      } while (processAgain);
    } finally {
      processing = false;
    }
    scheduleRender();
  }

  function processInlineStyles(root) {
    if (!root || root.nodeType !== 1) return;
    const nodes = [];
    if (root.hasAttribute('style')) nodes.push(root);
    nodes.push(...root.querySelectorAll('[style]'));
    let changed = false;
    nodes.forEach((el) => {
      if (isOwn(el)) return;
      const decls = overrideDeclarations(el.style)
        .split('; ')
        .filter(Boolean)
        .map((d) => (d.endsWith('!important') ? d : `${d} !important`))
        .join('; ');
      let id = el.getAttribute(DYN_ATTR);
      if (!decls) {
        if (id) {
          inlineRules.delete(id);
          el.removeAttribute(DYN_ATTR);
          changed = true;
        }
        return;
      }
      if (!id) {
        id = String(++inlineCounter);
        el.setAttribute(DYN_ATTR, id);
      }
      if (inlineRules.get(id) !== decls) {
        inlineRules.set(id, decls);
        changed = true;
      }
    });
    if (changed) scheduleRender();
  }

  // ---------------------------------------------------------------------------
  // CSS builders
  // ---------------------------------------------------------------------------

  function userFilter(cfg) {
    const parts = [];
    if (cfg.brightness !== 100) parts.push(`brightness(${cfg.brightness / 100})`);
    if (cfg.contrast !== 100) parts.push(`contrast(${cfg.contrast / 100})`);
    if (cfg.sepia) parts.push(`sepia(${cfg.sepia / 100})`);
    if (cfg.grayscale) parts.push(`grayscale(${cfg.grayscale / 100})`);
    return parts.join(' ');
  }

  function filterModeCss(cfg) {
    const dim = cfg.dimImages ? ' brightness(0.85)' : '';
    const nestedMedia = `:is(${MEDIA_CONTAINERS}) :is(${MEDIA})`;
    return `/* Blur Remover dark mode: filter */
html {
  filter: invert(0.92) hue-rotate(180deg) ${userFilter(cfg)} !important;
  color-scheme: dark !important;
}
/* The root canvas is painted from the root background before the filter, give it a light base so it inverts to dark. */
html { background-color: #fff !important; }
:is(${MEDIA}), :is(${OWN_HOSTS}) {
  filter: invert(1) hue-rotate(180deg)${dim} !important;
}
${nestedMedia}, :is(${OWN_HOSTS}) :is(${MEDIA}) { filter: none !important; }
/* Top-layer fullscreen content is painted outside the root filter. */
:is(${MEDIA}):fullscreen, :fullscreen :is(${MEDIA}) { filter: none !important; }
`;
  }

  function dynamicModeCss(cfg) {
    const extra = userFilter(cfg);
    let css = `/* Blur Remover dark mode: dynamic */
:where(html) { background-color: rgb(${DARK_BG.r}, ${DARK_BG.g}, ${DARK_BG.b}); color: ${BASE_TEXT}; color-scheme: dark; }
html { color-scheme: dark !important; }
:where(a:link) { color: #8ab4f8; }
:where(a:visited) { color: #c58af9; }
:where(input, textarea, select, button) { color-scheme: dark; }
`;
    if (extra) css += `html { filter: ${extra} !important; }\n`;
    if (cfg.dimImages) css += `:where(img, video, canvas, picture > img) { filter: brightness(0.85); }\n`;
    // Text drawn over photos (heroes, sliders, inline background images) is lightened like all text but the
    // photo is not darkened, so give it a soft dark halo to stay readable on light imagery.
    css += `:is([style*="background-image"], [style*="url("], rs-module, .rs-layer, [class*="hero"], [class*="banner"], [class*="slider"], [class*="carousel"])
  :is(h1, h2, h3, h4, h5, h6, p, li, span, a, strong, em, small, blockquote),
rs-layer, .rs-layer, rs-layer *, .rs-layer * { text-shadow: 0 1px 2px rgba(0, 0, 0, .85), 0 0 14px rgba(0, 0, 0, .65); }\n`;
    sheetOrder.forEach((node) => {
      const entry = node && sheetCache.get(node);
      if (entry && entry.css) css += entry.css;
    });
    inlineRules.forEach((decls, id) => {
      css += `[${DYN_ATTR}="${id}"] { ${decls} }\n`;
    });
    return css;
  }

  function render() {
    renderTimer = null;
    if (!active || !config) return;
    setCss(config.mode === 'dynamic' ? dynamicModeCss(config) : filterModeCss(config));
  }

  function scheduleRender() {
    if (!renderTimer) renderTimer = setTimeout(render, 60);
  }

  // ---------------------------------------------------------------------------
  // Filter mode: mark elements with photographic backgrounds
  // ---------------------------------------------------------------------------

  function isOwn(el) {
    return !!(el.closest && el.closest('[id^="blur-remover"]'));
  }

  const mediaQueue = [];
  let mediaScheduled = false;
  let mediaWalker = null;

  function examineBackground(el) {
    if (el === document.documentElement || el === document.body || el.hasAttribute(MEDIA_ATTR) || isOwn(el)) return;
    const bg = getComputedStyle(el).backgroundImage;
    if (!bg || bg === 'none' || !bg.includes('url(')) return;
    // Large text-heavy sections with a texture background are inverted with the page instead.
    const rect = el.getBoundingClientRect();
    const big = rect.width * rect.height > window.innerWidth * window.innerHeight * 0.5;
    if (big && (el.textContent || '').trim().length > 200) return;
    el.setAttribute(MEDIA_ATTR, '');
  }

  function queueMediaScan(root) {
    if (!root || root.nodeType !== 1) return;
    mediaQueue.push(root);
    if (!mediaScheduled) {
      mediaScheduled = true;
      (self.requestIdleCallback || ((cb) => setTimeout(cb, 30)))(runMediaSlice, { timeout: 250 });
    }
  }

  function runMediaSlice() {
    mediaScheduled = false;
    if (!active || !config || config.mode !== 'filter') {
      mediaQueue.length = 0;
      mediaWalker = null;
      return;
    }
    let budget = SLICE;
    while (budget > 0) {
      if (!mediaWalker) {
        const root = mediaQueue.shift();
        if (!root) break;
        if (!root.isConnected) continue;
        examineBackground(root);
        budget--;
        mediaWalker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT);
      }
      const next = mediaWalker.nextNode();
      if (!next) {
        mediaWalker = null;
        continue;
      }
      examineBackground(next);
      budget--;
    }
    if (mediaWalker || mediaQueue.length) {
      mediaScheduled = true;
      (self.requestIdleCallback || ((cb) => setTimeout(cb, 30)))(runMediaSlice, { timeout: 250 });
    }
  }

  // ---------------------------------------------------------------------------
  // Observation
  // ---------------------------------------------------------------------------

  function startObserving() {
    stopObserving();
    if (!document.documentElement) return;
    observer = new MutationObserver((records) => {
      if (!active || !config) return;
      let sheetsChanged = false;
      for (const rec of records) {
        if (rec.type === 'childList') {
          rec.addedNodes.forEach((n) => {
            if (n.nodeType !== 1 || isOwn(n)) return;
            if (n.tagName === 'STYLE' || (n.tagName === 'LINK' && /stylesheet/i.test(n.rel))) sheetsChanged = true;
            if (config.mode === 'filter') queueMediaScan(n);
            else processInlineStyles(n);
          });
          rec.removedNodes.forEach((n) => {
            if (n.nodeType === 1 && (n.tagName === 'STYLE' || n.tagName === 'LINK')) sheetsChanged = true;
          });
          if (rec.target && rec.target.tagName === 'STYLE') sheetsChanged = true;
        } else if (rec.type === 'characterData') {
          const parent = rec.target.parentNode;
          if (parent && parent.tagName === 'STYLE') sheetsChanged = true;
        } else if (rec.type === 'attributes' && rec.target.nodeType === 1 && !isOwn(rec.target)) {
          if (config.mode === 'filter') {
            if (rec.attributeName === 'class' || rec.attributeName === 'style') {
              rec.target.removeAttribute(MEDIA_ATTR);
              queueMediaScan(rec.target);
            }
          } else if (rec.attributeName === 'style') {
            processInlineStyles(rec.target);
          }
        }
      }
      if (sheetsChanged && config.mode === 'dynamic') processAllSheets();
    });
    observer.observe(document.documentElement, {
      childList: true,
      subtree: true,
      characterData: true,
      attributes: true,
      attributeFilter: ['style', 'class']
    });

    // CSS-in-JS libraries insert rules through CSSOM, which no observer sees.
    pollTimer = setInterval(() => {
      if (!active || !config) return;
      attachSheetIfMissing();
      if (config.mode !== 'dynamic') return;
      const sheets = Array.from(document.styleSheets).filter((s) => !ownSheet(s));
      const stale = sheets.length !== sheetOrder.length || sheets.some((s) => {
        const cached = sheetCache.get(s.ownerNode);
        return !cached || cached.key !== sheetFingerprint(s);
      });
      if (stale) processAllSheets();
    }, 2000);
  }

  function attachSheetIfMissing() {
    if (sheet) {
      try {
        if (!document.adoptedStyleSheets.includes(sheet)) attachSheet();
      } catch (e) { /* ignore */ }
    } else if (styleEl && !styleEl.isConnected) {
      attachSheet();
    }
  }

  function stopObserving() {
    if (observer) observer.disconnect();
    observer = null;
    clearInterval(pollTimer);
    pollTimer = null;
  }

  // ---------------------------------------------------------------------------
  // Already-dark detection
  // ---------------------------------------------------------------------------

  function pageIsAlreadyDark() {
    const wasAttached = sheetAttached;
    if (wasAttached) detachSheet();
    try {
      const candidates = [document.body, document.documentElement].filter(Boolean);
      for (const el of candidates) {
        const c = parseColor(getComputedStyle(el).backgroundColor);
        if (c && c.a > 0.5) return luminance(c) < 0.2;
      }
      return false; // transparent everywhere: white canvas
    } finally {
      if (wasAttached) attachSheet();
    }
  }

  function checkAlreadyDark() {
    if (!config || skippedReason) return;
    if (!document.body) return;
    if (pageIsAlreadyDark()) {
      skippedReason = 'already-dark';
      teardown();
    }
  }

  function hookReady() {
    if (readyHooked) return;
    readyHooked = true;
    const onReady = () => {
      checkAlreadyDark();
      if (active && config) startContent();
    };
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', onReady, { once: true });
    else onReady();
    if (document.readyState !== 'complete') window.addEventListener('load', checkAlreadyDark, { once: true });
  }

  // ---------------------------------------------------------------------------
  // Lifecycle
  // ---------------------------------------------------------------------------

  function clearMarkers() {
    document.querySelectorAll(`[${MEDIA_ATTR}]`).forEach((el) => el.removeAttribute(MEDIA_ATTR));
    document.querySelectorAll(`[${DYN_ATTR}]`).forEach((el) => el.removeAttribute(DYN_ATTR));
    inlineRules.clear();
    mediaQueue.length = 0;
    mediaWalker = null;
  }

  function teardown() {
    active = false;
    stopObserving();
    clearTimeout(renderTimer);
    renderTimer = null;
    detachSheet();
    if (document.documentElement) clearMarkers();
  }

  /** Starts DOM-dependent work (needs <body>). */
  function startContent() {
    if (!active || !config || document.readyState === 'loading') return;
    startObserving();
    if (config.mode === 'filter') {
      queueMediaScan(document.body || document.documentElement);
    } else {
      processInlineStyles(document.documentElement);
      processAllSheets();
    }
  }

  function apply(newConfig) {
    if (!newConfig || !['filter', 'dynamic'].includes(newConfig.mode)) {
      remove();
      return;
    }
    const cfg = {
      mode: newConfig.mode,
      brightness: Number(newConfig.brightness) || 100,
      contrast: Number(newConfig.contrast) || 100,
      sepia: Number(newConfig.sepia) || 0,
      grayscale: Number(newConfig.grayscale) || 0,
      dimImages: newConfig.dimImages !== false
    };
    const key = JSON.stringify(cfg);
    if (key === configKey && (active || skippedReason)) {
      if (active) attachSheetIfMissing();
      return;
    }
    const modeChanged = !config || config.mode !== cfg.mode;
    config = cfg;
    configKey = key;
    if (skippedReason) return; // page is already dark; keep skipping until remove()

    if (modeChanged && active) {
      stopObserving();
      clearMarkers();
    }
    active = true;
    render();
    hookReady();
    if (modeChanged || !observer) startContent();
  }

  function remove() {
    config = null;
    configKey = '';
    skippedReason = '';
    readyHooked = false;
    teardown();
  }

  self.BlurRemoverDarkMode = {
    apply,
    remove,
    isActive: () => active && !skippedReason,
    getStatus: () => ({ active: active && !skippedReason, mode: config ? config.mode : null, skippedReason }),
    // Exposed for tests.
    _internals: { parseColor, mapBg, mapFg, mapBorder, remapValue, contrast }
  };
})();
