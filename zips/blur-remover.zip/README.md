# Blur Remover & DOM Modifier (Chrome extension, Manifest V3)

Remove backdrop blurs and modal overlays, unlock scrolling, read any page in a clean Reader View, apply a
proper dark mode, and write your own CSS rules, per site or globally.

![Extension Icon](walkthroughs/icon.png)

## Features

- **Presets**: Magic auto-unblur (computed-style based, only real blur overlays), Global unblur, Scroll unlock
  (including iOS-style `position:fixed` locks), Overlay eraser, Unblur text, Enable clicks (pagination only, never
  form controls), Cookie banner & newsletter popup remover, Re-enable copy / right-click / text selection.
- **Per-site control**: pause everything on a site, per-site dark mode override, auto-open Reader View on chosen sites.
- **Instant unblur (Alt+U)**: a real per-tab toggle with a toast.
- **Element picker (Alt+P)**: ranked selector candidates with live match counts and highlighting, keyboard
  navigation (↑ parent, ↓ child, ←/→ siblings), **Zap** (Z / Delete) for one-off removal, **Ctrl+Z undo** for zaps
  and saved rules, right-click → "Pick this element" / "Zap this element".
- **Reader View (Alt+R)**: Mozilla Readability extraction, lazy-image recovery, inline formatting and links kept,
  real heading hierarchy, Full-page mode for landing/FAQ pages, table of contents, text-to-speech, highlights & notes,
  copy as Markdown, save HTML, print/PDF, width / line-height / spacing / font controls (incl. Atkinson Hyperlegible
  and OpenDyslexic), themes that follow the system.
- **Dark mode on/off per site (Alt+Shift+D)**: one shortcut or right-click item flips dark mode for the current site.
- **Icon tooltip**: hovering the toolbar icon tells you how many rules matched on the page, or that the site is paused.
- **Dark mode**: *Filter* mode (fast, works everywhere, media re-inverted) and *Dynamic* mode (HSL colour remapping
  that keeps brand colours and outlined text), brightness / contrast / sepia / grayscale, follow system or schedule,
  automatic skip on pages that are already dark.
- **Rules & rule packs**: domain / exact-path (`site.com/blog/*` prefix) / global scopes, custom CSS that is
  validated, a built-in pack (`rule-packs/default.json`) and remote packs over https with daily refresh.
- **Options page, onboarding, real statistics** (per site and total), import / export with validation, storage usage
  and sync status, English i18n via `_locales`.

## Install (unpacked)

1. Download the ZIP and extract it to a folder you will keep (Chrome loads the extension from that folder).
2. Open `chrome://extensions`, enable **Developer mode** (top right), click **Load unpacked** and pick the extracted
   folder (the one that contains `manifest.json`).
3. Pin the extension from the puzzle-piece menu. Shortcuts can be changed at `chrome://extensions/shortcuts`.

## Permissions

| Permission | Why |
|------------|-----|
| `storage` | Saves your settings, rules, statistics and Reader View highlights (nothing leaves your browser except Chrome sync of the core settings). |
| `scripting` | Loads the element picker and Reader View into a page only when you use them. |
| `contextMenus` | The right-click items (pick / zap element, Reader View, dark mode, pause site). |
| `alarms` | Refreshes rule packs once a day. |
| Access to all sites | Needed to remove blurs and overlays and apply your rules on whatever site you visit, and to download rule packs you add. |

No analytics, no accounts, no server of our own.

## Development

```bash
npm install                 # also points git hooks at .githooks (pre-commit runs verify + lint + unit tests)
npm run verify              # syntax, manifest/locale/file references, no inline handlers (MV3 CSP)
npm run lint                # ESLint + no-unsanitized
npm run test:unit           # node:test, storage / matching / selector utilities
npx playwright install chromium
npm run test:e2e            # loads the real unpacked extension against fixture pages
```

## Architecture

```
manifest.json                 MV3; content scripts top frame only; options page; i18n
_locales/en/messages.json     UI + manifest strings
rule-packs/default.json       built-in rule pack (same format as remote packs)
src/background/service-worker.js
                              serialized storage writes, on-demand injection (frameId 0), per-tab state,
                              badge from content reports, commands, context menus, rule-pack fetching
src/content/content-engine.js rules + presets as a constructed stylesheet, throttled MutationObserver that
                              only processes changed nodes, computed-style scanner, stats, zap/undo
src/content/dark-mode.js      filter + dynamic dark mode
src/content/element-picker.js picker UI (injected on demand)
src/content/reader-view.js    Reader View (injected on demand with src/vendor/Readability*.js)
src/utils/storage.js          schema v2 storage API (see below)
src/utils/dom-utils.js        escaping, selector splitting/validation, CSS sanitising, toasts, zap stack
src/utils/selector-generator.js ranked, stability-filtered selector candidates
src/utils/i18n.js, src/ui/*   shared UI helpers, theme tokens
src/popup, src/options, src/onboarding
```

### Storage (schema v2)

| Area | Key | Content |
|------|-----|---------|
| sync (local fallback, newest wins) | `br_core` | master switch, presets, dark mode settings, popup theme |
| local | `br_rules` | user rules |
| local | `br_packs` | rule packs with their fetched rules |
| local | `br_sites` | `paused[]`, `darkMode{host: filter\|dynamic\|off}`, `autoReader[]` |
| local | `br_reader` | Reader View preferences |
| local | `br_stats` | real totals + per-site counts |
| local | `hl:<host/path>` | Reader highlights & notes |

Writes from the popup, options page and content scripts are proxied to the service worker
(`{type: 'BR_STORAGE', op, args}`) and serialized there, so concurrent writers never lose updates. Settings from
v1.0 (`blur_remover_settings`) are migrated automatically on install/update.

Rule shape: `{ id, name, enabled, siteScope: 'global'|'domain'|'exact', domainPattern, selector,
actionType: 'remove-blur'|'hide'|'visibility-hidden'|'unlock-scroll'|'enable-pointer'|'custom-css', customCss }`.

## Third-party

- Mozilla Readability 0.5.0 (Apache-2.0), `src/vendor/`
- Atkinson Hyperlegible and OpenDyslexic fonts (SIL OFL 1.1), `src/fonts/`

## License

Released under the MIT License.
