# Blur Remover & DOM Modifier (Chrome extension, Manifest V3)

Remove backdrop blurs and modal overlays, unlock scrolling, read any page in a clean Reader View, apply a
proper dark mode, and write your own CSS rules, per site or globally.

![Extension Icon](walkthroughs/icon.png)

## Features

- **Presets**: Magic auto-unblur (computed-style based, only real blur overlays), Global unblur, Scroll unlock
  (including iOS-style `position:fixed` locks), Overlay eraser, Unblur text, Enable clicks (pagination only, never
  form controls), Cookie banner & newsletter popup remover, Re-enable copy / right-click / text selection.
- **Per-site control**: pause everything on a site, or **pause it for 30 minutes** (popup link or right-click menu; it
  switches back on by itself), per-site dark mode override, auto-open Reader View on chosen sites.
- **Presets per site**: the popup's "Everywhere / Only this site" switch above the presets turns any preset on or off for
  the current site only (for example "Allow copy & right-click" on one site). Presets changed for a site are tagged
  "site" and have a reset button; Options > Sites lists them.
- **Highlights library** (Options > Highlights): every Reader View highlight and note across all pages, searchable, with
  "Open page", "Copy as Markdown" per page and "Export all as Markdown". Reader View's Notes tab links to it.
- **Share a site's fixes**: "Export this site's rules" in the popup saves the rules for the current site as a small rule
  pack file. Import it on another computer from Options > Backup (only the rules are added, settings stay untouched), or
  host it on https and add it as a rule pack.
- **Instant unblur (Alt+U)**: a real per-tab toggle with a toast.
- **Element picker (Alt+P)**: ranked selector candidates with live match counts and highlighting, keyboard
  navigation (↑ parent, ↓ child, ←/→ siblings), **Zap** (Z / Delete) for one-off removal, **Ctrl+Z undo** for zaps
  and saved rules, right-click → "Pick this element" / "Zap this element".
- **Reader View (Alt+R)**: Mozilla Readability extraction, lazy-image recovery, inline formatting and links kept,
  real heading hierarchy, Full-page mode for landing/FAQ pages, table of contents, text-to-speech, highlights & notes,
  copy as Markdown, save HTML, print/PDF, width / line-height / spacing / font controls (incl. Atkinson Hyperlegible
  and OpenDyslexic), themes that follow the system.
- **Dark mode on/off per site (Alt+Shift+D)**: one shortcut or right-click item flips dark mode for the current site.
- **Icon tooltip and badge**: the toolbar icon shows how many rules matched on the page (or that the site is paused);
  the badge number can be hidden in Options > Sites, the tooltip keeps the information.
- **Dark mode**: *Filter* mode (fast, works everywhere, media re-inverted) and *Dynamic* mode (HSL colour remapping
  that keeps brand colours and outlined text), brightness / contrast / sepia / grayscale, follow system or schedule,
  automatic skip on pages that are already dark.
- **Rules & rule packs**: domain / exact-path (`site.com/blog/*` prefix) / global scopes, custom CSS that is
  validated, a built-in pack (`rule-packs/default.json`) and remote packs over https with daily refresh.
- **Options page, onboarding, real statistics** (per site and total), import / export with validation ("Add to my
  rules" adds rules, packs and site lists; "Restore a backup" replaces rules and settings), storage usage and sync
  status, English i18n via `_locales`.
- **Works in tabs that were already open**: after install or update the content engine is loaded into open tabs (an
  outdated copy from the previous version removes itself), so no reload is needed.

## Install (unpacked)

1. Download the ZIP and extract it to a folder you will keep (Chrome loads the extension from that folder).
2. Open `chrome://extensions`, enable **Developer mode** (top right), click **Load unpacked** and pick the extracted
   folder (the one that contains `manifest.json`).
3. Pin the extension from the puzzle-piece menu. Shortcuts can be changed at `chrome://extensions/shortcuts`.

## Keyboard shortcuts

| Shortcut | Action |
|----------|--------|
| `Alt+U` | Instant unblur for the current tab (toggle) |
| `Alt+P` | Element picker (↑ ↓ ← → navigate, Enter open, Z zap, Ctrl+Z undo, Esc exit) |
| `Alt+R` | Reader View (toggle) |
| `Alt+Shift+D` | Dark mode on/off for the current site |
| not set | Pause / resume on this site (assign one at `chrome://extensions/shortcuts`) |
| `Ctrl+Z` | Undo the last zap or picked rule on the page |

## Permissions

| Permission | Why |
|------------|-----|
| `storage` | Saves your settings, rules, statistics and Reader View highlights (nothing leaves your browser except Chrome sync of the core settings). |
| `scripting` | Loads the element picker and Reader View into a page only when you use them. |
| `contextMenus` | The right-click items (pick / zap element, Reader View, dark mode, pause site). |
| `alarms` | Refreshes rule packs once a day, and switches a site back on when a 30-minute pause ends. |
| Access to all sites | Needed to remove blurs and overlays and apply your rules on whatever site you visit, to load the engine into already open tabs after install/update, and to download rule packs you add. |

No new permissions in 1.4.0.

### Security notes

- Web pages never get a channel into the extension: content scripts may only ask the service worker for a short list of
  storage writes (save a picked rule, undo it, stats, Reader highlights / prefs / auto-open for their own site).
  Settings, imports, rule packs, bulk edits and tab actions are only accepted from the extension's own pages.
- The element picker and Reader View live in **closed** shadow roots, so page scripts can't read your highlights and
  notes or drive the picker. Toasts were already closed.

No analytics, no accounts, no server of our own.

## Development

```bash
npm install                 # also points git hooks at .githooks (pre-commit runs verify + lint + unit tests)
npm run verify              # syntax, manifest/locale/file references, no inline handlers (MV3 CSP)
npm run lint                # ESLint + no-unsanitized
npm run test:unit           # node:test, storage / matching / selector utilities
npx playwright install chromium
npm run test:e2e            # loads the real unpacked extension against fixture pages
```

## Architecture

```
manifest.json                 MV3; content scripts top frame only; options page; i18n
_locales/en/messages.json     UI + manifest strings
rule-packs/default.json       built-in rule pack (same format as remote packs)
src/background/service-worker.js
                              serialized storage writes, on-demand injection (frameId 0), per-tab state,
                              badge from content reports, commands, context menus, rule-pack fetching
src/content/content-engine.js rules + presets as a constructed stylesheet, throttled MutationObserver that
                              only processes changed nodes, computed-style scanner, stats, zap/undo
src/content/dark-mode.js      filter + dynamic dark mode
src/content/element-picker.js picker UI (injected on demand)
src/content/reader-view.js    Reader View (injected on demand with src/vendor/Readability*.js)
src/utils/storage.js          schema v2 storage API (see below)
src/utils/dom-utils.js        escaping, selector splitting/validation, CSS sanitising, toasts, zap stack
src/utils/selector-generator.js ranked, stability-filtered selector candidates
src/utils/i18n.js, src/ui/*   shared UI helpers, theme tokens
src/popup, src/options, src/onboarding
```

### Storage (schema v2)

| Area | Key | Content |
|------|-----|---------|
| sync (local fallback, newest wins) | `br_core` | master switch, presets, dark mode settings, popup theme, `showBadge` |
| local | `br_rules` | user rules |
| local | `br_packs` | rule packs with their fetched rules |
| local | `br_sites` | `paused[]`, `pausedUntil{host: timestamp}`, `darkMode{host: filter\|dynamic\|off}`, `autoReader[]` |
| local | `br_reader` | Reader View preferences |
| local | `br_stats` | real totals + per-site counts |
| local | `br_sites.presets` | `{host: {presetKey: boolean}}` per-site preset overrides |
| local | `hl:<host/path>` | Reader highlights & notes (max 500 per page, shape-checked) |
| local | `br_hl_index` | highlights library index `{key: {url, title, count, notes, updatedAt}}`, max 1000 pages (oldest dropped) |

Writes from the popup, options page and content scripts are proxied to the service worker
(`{type: 'BR_STORAGE', op, args}`) and serialized there, so concurrent writers never lose updates. Settings from
v1.0 (`blur_remover_settings`) are migrated automatically on install/update.

Rule shape: `{ id, name, enabled, siteScope: 'global'|'domain'|'exact', domainPattern, selector,
actionType: 'remove-blur'|'hide'|'visibility-hidden'|'unlock-scroll'|'enable-pointer'|'custom-css', customCss }`.

## Third-party

- Mozilla Readability 0.5.0 (Apache-2.0), `src/vendor/`
- Atkinson Hyperlegible and OpenDyslexic fonts (SIL OFL 1.1), `src/fonts/`

## License

Released under the MIT License.
