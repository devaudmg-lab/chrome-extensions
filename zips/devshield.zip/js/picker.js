(() => {
  // src/content/picker.js
  (function picker() {
    if (window.__devshieldPicker) return;
    window.__devshieldPicker = true;
    const host = document.createElement("devshield-picker");
    host.style.cssText = "all:initial;position:fixed;inset:0;z-index:2147483647;";
    const root = host.attachShadow({ mode: "closed" });
    root.innerHTML = `
      <style>
        :host{all:initial}
        .layer{position:fixed;inset:0;cursor:crosshair}
        .hl{position:fixed;pointer-events:none;background:rgba(239,68,68,.25);outline:2px solid #ef4444;border-radius:2px;transition:all .05s}
        .panel{position:fixed;right:16px;bottom:16px;width:360px;font:13px/1.4 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;
          color:#f3f4f6;background:#0b1020;border:1px solid rgba(255,255,255,.12);border-radius:14px;padding:12px;
          box-shadow:0 10px 40px rgba(0,0,0,.45);display:none;cursor:default}
        .panel.show{display:block}
        h3{margin:0 0 8px;font-size:13px}
        textarea{width:100%;box-sizing:border-box;min-height:60px;background:#111827;color:#e5e7eb;border:1px solid #374151;
          border-radius:8px;padding:6px;font:12px ui-monospace,Consolas,monospace;resize:vertical}
        .row{display:flex;gap:8px;margin-top:8px;align-items:center}
        .grow{flex:1}
        button{font:inherit;font-weight:600;border-radius:8px;border:1px solid rgba(255,255,255,.15);background:rgba(255,255,255,.06);
          color:#f3f4f6;padding:6px 12px;cursor:pointer}
        button.primary{background:#ef4444;border-color:#ef4444}
        .muted{color:#9ca3af;font-size:12px}
        input[type=range]{width:100%}
        .hint{position:fixed;top:12px;left:50%;transform:translateX(-50%);font:13px system-ui,sans-serif;color:#fff;
          background:#0b1020;border:1px solid rgba(255,255,255,.12);border-radius:999px;padding:6px 14px;pointer-events:none}
        button:focus-visible,textarea:focus-visible,input:focus-visible{outline:2px solid #60a5fa;outline-offset:1px}
        @media (prefers-color-scheme: light){
          .panel{color:#0f172a;background:#fff;border-color:rgba(15,23,42,.14);box-shadow:0 10px 40px rgba(15,23,42,.25)}
          textarea{background:#f8fafc;color:#0f172a;border-color:#cbd5e1}
          button{color:#0f172a;border-color:rgba(15,23,42,.2);background:rgba(15,23,42,.04)}
          button.primary{color:#fff}
          .muted{color:#475569}
          .hint{color:#0f172a;background:#fff;border-color:rgba(15,23,42,.14)}
        }
      </style>
      <div class="layer"></div>
      <div class="hl"></div>
      <div class="hint">Click an element to block it \xB7 Esc to cancel</div>
      <div class="panel">
        <h3 id="t">Block element</h3>
        <textarea spellcheck="false" aria-label="CSS selector of the elements to block"></textarea>
        <div class="muted matches" role="status"></div>
        <label class="muted" for="depth">Broader \u27F5 depth \u27F6 narrower</label>
        <input type="range" id="depth" min="0" max="0" value="0">
        <div class="row"><span class="grow"></span><button class="cancel">Cancel</button><button class="once" title="Hide these elements until the page reloads, without saving a filter">Hide for now</button><button class="primary save" title="Save a filter so they stay hidden on this site">Block</button></div>
      </div>`;
    const layer = root.querySelector(".layer");
    const hl = root.querySelector(".hl");
    const panel = root.querySelector(".panel");
    const hint = root.querySelector(".hint");
    const textarea = root.querySelector("textarea");
    const range = root.querySelector("input");
    const matchesEl = root.querySelector(".matches");
    document.documentElement.append(host);
    let chain = [];
    let picked = false;
    const elementAt = (x, y) => {
      host.style.pointerEvents = "none";
      layer.style.pointerEvents = "none";
      const el = document.elementFromPoint(x, y);
      host.style.pointerEvents = "";
      layer.style.pointerEvents = "";
      return el && el !== host ? el : null;
    };
    const highlight = (el) => {
      if (!el) {
        hl.style.display = "none";
        return;
      }
      const r = el.getBoundingClientRect();
      Object.assign(hl.style, { display: "block", left: `${r.left}px`, top: `${r.top}px`, width: `${r.width}px`, height: `${r.height}px` });
    };
    const goodClass = (c) => /^[a-zA-Z][\w-]{1,40}$/.test(c) && !/\d{3,}/.test(c) && !/^(active|selected|hover|focus|open|show|visible)$/.test(c);
    const goodId = (id) => /^[a-zA-Z][\w-]{1,60}$/.test(id) && !/\d{4,}/.test(id);
    const selectorFor = (el) => {
      if (el.id && goodId(el.id)) return `#${CSS.escape(el.id)}`;
      const tag = el.localName;
      const classes = Array.from(el.classList).filter(goodClass).slice(0, 3).map((c) => "." + CSS.escape(c)).join("");
      let sel = tag + classes;
      for (const attr of ["data-ad", "data-testid", "aria-label", "name", "role"]) {
        if (!classes && el.hasAttribute(attr)) {
          const v = el.getAttribute(attr);
          if (v && v.length < 60) sel += `[${attr}="${CSS.escape(v)}"]`;
          break;
        }
      }
      return sel;
    };
    const uniqueSelector = (el) => {
      let sel = selectorFor(el);
      let cur = el;
      let guard = 0;
      while (document.querySelectorAll(sel).length > 1 && cur.parentElement && cur.parentElement !== document.body && guard++ < 5) {
        cur = cur.parentElement;
        sel = `${selectorFor(cur)} > ${sel}`;
      }
      return sel;
    };
    const update = () => {
      const el = chain[Number(range.value)];
      if (!el) return;
      const sel = uniqueSelector(el);
      textarea.value = sel;
      preview();
    };
    const preview = () => {
      let n = 0;
      try {
        const list = document.querySelectorAll(textarea.value);
        n = list.length;
        highlight(list[0] || null);
      } catch {
        n = -1;
      }
      matchesEl.textContent = n < 0 ? "Invalid selector" : `${n} element${n === 1 ? "" : "s"} match`;
    };
    const stop = () => {
      document.removeEventListener("keydown", onKey, true);
      host.remove();
      window.__devshieldPicker = false;
    };
    const onKey = (e) => {
      if (e.key === "Escape") {
        e.preventDefault();
        stop();
      }
    };
    document.addEventListener("keydown", onKey, true);
    layer.addEventListener("mousemove", (e) => {
      if (picked) return;
      highlight(elementAt(e.clientX, e.clientY));
    });
    layer.addEventListener("click", (e) => {
      e.preventDefault();
      const el = elementAt(e.clientX, e.clientY);
      if (!el) return;
      picked = true;
      chain = [];
      for (let cur = el; cur && cur !== document.body && cur !== document.documentElement; cur = cur.parentElement) chain.push(cur);
      if (chain.length === 0) {
        picked = false;
        return;
      }
      chain.reverse();
      range.max = String(chain.length - 1);
      range.value = String(chain.length - 1);
      layer.style.display = "none";
      hint.style.display = "none";
      panel.classList.add("show");
      update();
      range.focus();
    });
    range.addEventListener("input", update);
    textarea.addEventListener("input", preview);
    root.querySelector(".cancel").addEventListener("click", stop);
    root.querySelector(".once").addEventListener("click", () => {
      let list;
      try {
        list = document.querySelectorAll(textarea.value.trim());
      } catch {
        matchesEl.textContent = "Invalid selector";
        return;
      }
      for (const el of list) el.style.setProperty("display", "none", "important");
      stop();
    });
    root.querySelector(".save").addEventListener("click", () => {
      const selector = textarea.value.trim();
      try {
        document.querySelector(selector);
      } catch {
        matchesEl.textContent = "Invalid selector";
        return;
      }
      chrome.runtime.sendMessage({ type: "picker:save", host: location.hostname, selector }).then((ok) => {
        if (!ok) {
          matchesEl.textContent = "Selector not accepted \u2014 use a plain CSS selector";
          return;
        }
        for (const el of document.querySelectorAll(selector)) el.style.setProperty("display", "none", "important");
        stop();
      }, () => {
        matchesEl.textContent = "Could not save \u2014 reload the page and try again";
      });
    });
  })();
})();
