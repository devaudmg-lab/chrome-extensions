(() => {
  // src/shared/channel.js
  var ATTR = "data-dsn";
  var PROBE = "devshield-channel-probe";
  function openChannel(side) {
    const doc = document;
    const dispatch = EventTarget.prototype.dispatchEvent;
    const listen = EventTarget.prototype.addEventListener;
    const CE = CustomEvent;
    const stringify = JSON.stringify;
    const parse = JSON.parse;
    const objectKeys = Object.keys;
    const getDetail = Object.getOwnPropertyDescriptor(CustomEvent.prototype, "detail").get;
    const call = Function.prototype.call.bind(Function.prototype.call);
    const removeListener = EventTarget.prototype.removeEventListener;
    const getDefaultPrevented = Object.getOwnPropertyDescriptor(Event.prototype, "defaultPrevented").get;
    const preventDefault = Event.prototype.preventDefault;
    const root2 = doc.documentElement;
    if (!root2) return null;
    const probe = new CE(PROBE, { cancelable: true });
    call(dispatch, doc, probe);
    let nonce;
    if (call(getDefaultPrevented, probe)) {
      nonce = root2.getAttribute(ATTR) || "";
      root2.removeAttribute(ATTR);
      if (!/^[0-9a-f]{32}$/.test(nonce)) return null;
    } else {
      const bytes = new Uint8Array(16);
      crypto.getRandomValues(bytes);
      nonce = Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
      root2.setAttribute(ATTR, nonce);
      const answer = (ev) => {
        call(preventDefault, ev);
        call(removeListener, doc, PROBE, answer);
      };
      call(listen, doc, PROBE, answer);
      const cleanup = () => {
        call(removeListener, doc, PROBE, answer);
        if (root2.getAttribute(ATTR) === nonce) root2.removeAttribute(ATTR);
      };
      call(listen, doc, "DOMContentLoaded", cleanup, { once: true });
    }
    const outType = `${nonce}:${side === "main" ? "m" : "i"}`;
    const inType = `${nonce}:${side === "main" ? "i" : "m"}`;
    const handlers = [];
    call(listen, doc, inType, (ev) => {
      let msg;
      try {
        msg = parse(call(getDetail, ev));
      } catch {
        return;
      }
      for (let i = 0; i < handlers.length; i++) {
        try {
          handlers[i](msg);
        } catch {
        }
      }
    });
    const flat = (msg) => {
      const keys = objectKeys(msg);
      let out = "{";
      for (let i = 0; i < keys.length; i++) {
        const v = msg[keys[i]];
        const t = typeof v;
        if (v !== null && t !== "string" && t !== "number" && t !== "boolean") continue;
        out += (out === "{" ? "" : ",") + stringify(keys[i]) + ":" + stringify(v);
      }
      return out + "}";
    };
    return {
      send(msg) {
        try {
          const detail = side === "main" ? flat(msg) : stringify(msg);
          call(dispatch, doc, new CE(outType, { detail }));
        } catch {
        }
      },
      on(fn) {
        handlers[handlers.length] = fn;
      }
    };
  }

  // src/shared/filters/selector.js
  var CLASS_TEST = { "\\w": /\w/, "\\d": /\d/, "\\s": /\s/ };
  function firstsOverlap(a, b) {
    if (a === b) return true;
    for (const [x, y] of [[a, b], [b, a]]) {
      if (x === "." || x === "[" || /^\\[WDS]$/.test(x)) return true;
      const re = CLASS_TEST[x];
      if (re) {
        if (y in CLASS_TEST) return x === "\\w" ? y !== "\\s" : y === "\\w";
        const ch = y[0] === "\\" ? y[1] : y;
        if (/^\\[a-zA-Z]$/.test(y) && !(y in CLASS_TEST)) continue;
        if (re.test(ch)) return true;
      }
    }
    return false;
  }
  function hasAmbiguousAlternation(src) {
    const groups = /\((?:\?:)?((?:[^()\\]|\\.)*)\)\s*(?:[+*]|\{\d+,\d*\})/g;
    for (let m = groups.exec(src); m; m = groups.exec(src)) {
      if (!m[1].includes("|")) continue;
      const alts = m[1].split(/(?<!\\)\|/);
      const firsts = [];
      for (const a of alts) {
        if (a === "" || /[?*]$/.test(a)) return true;
        const first = a[0] === "\\" ? a.slice(0, 2) : a[0];
        if (firsts.some((f) => firstsOverlap(f, first))) return true;
        firsts.push(first);
      }
    }
    return false;
  }
  var QUANT_AFTER = /^(?:[+*]|\{\d+,\d*\})/;
  function hasNestedQuantifier(src) {
    const stack = [];
    let inClass = false;
    for (let i = 0; i < src.length; i++) {
      const c = src[i];
      if (c === "\\") {
        i++;
        continue;
      }
      if (inClass) {
        if (c === "]") inClass = false;
        continue;
      }
      if (c === "[") {
        inClass = true;
      } else if (c === "(") {
        stack.push(false);
      } else if (c === ")") {
        const had = stack.pop() || false;
        const quantified = QUANT_AFTER.test(src.slice(i + 1, i + 16));
        if (had && quantified) return true;
        if (stack.length && (had || quantified)) stack[stack.length - 1] = true;
      } else if (stack.length && (c === "+" || c === "*" || c === "{" && QUANT_AFTER.test(src.slice(i, i + 16)))) {
        stack[stack.length - 1] = true;
      }
    }
    return false;
  }
  function isSafeRegexSource(src) {
    if (typeof src !== "string" || src.length > 1e3) return false;
    if (/\\[1-9]/.test(src)) return false;
    if (hasAmbiguousAlternation(src)) return false;
    if (hasNestedQuantifier(src)) return false;
    return !/\((?:[^()\\]|\\.)*(?:[+*]|\{\d+,\d*\})(?:[^()\\]|\\.)*\)\s*(?:[+*]|\{\d+,\d*\})/.test(src);
  }

  // src/content/procedural.js
  var OPERATORS = /* @__PURE__ */ new Set([
    "has-text",
    "has",
    "not",
    "if",
    "if-not",
    "upward",
    "nth-ancestor",
    "matches-css",
    "matches-css-before",
    "matches-css-after",
    "matches-attr",
    "matches-path",
    "matches-media",
    "min-text-length",
    "xpath",
    "watch-attr",
    "others",
    "remove",
    "remove-attr",
    "remove-class",
    "style",
    "matches-prop"
  ]);
  var ACTIONS = /* @__PURE__ */ new Set(["remove", "remove-attr", "remove-class", "style"]);
  var PROCEDURAL_IN_ARG = /:(?:has-text|upward|xpath|matches-css|min-text-length|matches-attr|matches-path|matches-media|nth-ancestor|if|if-not|remove)\(/;
  function findClose(s, open) {
    let depth = 0;
    let q = null;
    for (let i = open; i < s.length; i++) {
      const c = s[i];
      if (c === "\\") {
        i++;
        continue;
      }
      if (q) {
        if (c === q) q = null;
        continue;
      }
      if (c === '"' || c === "'") q = c;
      else if (c === "(") depth++;
      else if (c === ")") {
        depth--;
        if (depth === 0) return i;
      }
    }
    return -1;
  }
  var MAX_TEXT = 1e5;
  var matcherCache = /* @__PURE__ */ new Map();
  function textMatcher(arg, exact = false) {
    const key = (exact ? "=" : "~") + arg;
    let fn = matcherCache.get(key);
    if (!fn) {
      fn = buildTextMatcher(arg, exact);
      matcherCache.set(key, fn);
    }
    return fn;
  }
  function buildTextMatcher(arg, exact) {
    const m = /^\/(.+)\/([imsu]*)$/.exec(arg);
    if (m) {
      if (!isSafeRegexSource(m[1])) return () => false;
      const re = new RegExp(m[1], m[2]);
      return (s) => re.test(s.length > MAX_TEXT ? s.slice(0, MAX_TEXT) : s);
    }
    if (exact) {
      const want = arg.toLowerCase();
      return (s) => s.toLowerCase() === want;
    }
    return (s) => s.includes(arg);
  }
  function compileProcedural(sel) {
    let i = 0;
    let css = "";
    const tasks = [];
    let prefix = null;
    let action = null;
    const flushCss = () => {
      if (!css) return;
      if (prefix === null && tasks.length === 0) prefix = css;
      else tasks.push(["spath", css]);
      css = "";
    };
    while (i < sel.length) {
      const c = sel[i];
      if (c === ":" && sel[i + 1] !== ":") {
        const m = /^:([a-z-]+)\(/.exec(sel.slice(i));
        if (m && OPERATORS.has(m[1])) {
          const name = m[1];
          const open = i + m[0].length - 1;
          const close = findClose(sel, open);
          if (close === -1) return null;
          let arg = sel.slice(open + 1, close);
          const nativeHas = (name === "has" || name === "not") && !PROCEDURAL_IN_ARG.test(arg);
          if (nativeHas) {
            css += sel.slice(i, close + 1);
            i = close + 1;
            continue;
          }
          flushCss();
          if (/^(["']).*\1$/.test(arg)) arg = arg.slice(1, -1);
          if (ACTIONS.has(name)) {
            action = [name, arg];
          } else if (name === "has" || name === "if" || name === "not" || name === "if-not") {
            const inner = compileProcedural(arg.trim().startsWith(">") ? ":scope " + arg.trim() : arg);
            if (!inner) return null;
            tasks.push([name === "if" ? "has" : name === "if-not" ? "not-has" : name === "not" ? "not" : "has", inner]);
          } else if (name === "others" || name === "watch-attr" || name === "matches-prop") {
            if (name === "others") return null;
          } else {
            tasks.push([name, arg]);
          }
          i = close + 1;
          continue;
        }
      }
      css += c;
      i++;
    }
    flushCss();
    if (prefix !== null && !prefix.trim()) prefix = null;
    return { prefix: prefix && prefix.trim(), tasks, action };
  }
  function applyTask(task, nodes) {
    const [op, arg] = task;
    const out = [];
    switch (op) {
      case "spath": {
        const s = arg.trim();
        const anchored = /^[+~:]/.test(s);
        for (const n of nodes) {
          try {
            let q;
            if (n === document) {
              q = document.querySelectorAll(s);
            } else if (anchored) {
              const p = n.parentElement;
              if (!p) continue;
              let pos = 1;
              for (let e = n.previousElementSibling; e; e = e.previousElementSibling) pos++;
              q = p.querySelectorAll(`:scope > :nth-child(${pos})${s}`);
            } else {
              q = n.querySelectorAll(":scope " + s);
            }
            for (const e of q) out.push(e);
          } catch {
          }
        }
        return out;
      }
      case "has-text": {
        const match = textMatcher(arg);
        return nodes.filter((n) => match(n.textContent || ""));
      }
      case "min-text-length": {
        const len = parseInt(arg, 10) || 0;
        return nodes.filter((n) => (n.textContent || "").length >= len);
      }
      case "has":
        return nodes.filter((n) => runCompiled(arg, n).length > 0);
      case "not-has":
        return nodes.filter((n) => runCompiled(arg, n).length === 0);
      case "not":
        return nodes.filter((n) => !matchesCompiled(arg, n));
      case "upward":
      case "nth-ancestor": {
        const k = /^\d+$/.test(arg) ? parseInt(arg, 10) : 0;
        for (const n of nodes) {
          let p = null;
          if (k > 0) {
            p = n;
            for (let j = 0; j < k && p; j++) p = p.parentElement;
          } else if (arg) {
            try {
              p = n.parentElement && n.parentElement.closest(arg);
            } catch {
              p = null;
            }
          }
          if (p && p !== document.documentElement && p !== document.body) out.push(p);
        }
        return out;
      }
      case "matches-css":
      case "matches-css-before":
      case "matches-css-after": {
        const colon = arg.indexOf(":");
        if (colon === -1) return [];
        const prop = arg.slice(0, colon).trim();
        const match = textMatcher(arg.slice(colon + 1).trim(), true);
        const pseudo = op === "matches-css-before" ? "::before" : op === "matches-css-after" ? "::after" : null;
        return nodes.filter((n) => {
          try {
            return match(getComputedStyle(n, pseudo).getPropertyValue(prop));
          } catch {
            return false;
          }
        });
      }
      case "matches-attr": {
        const m = /^\s*"?(.+?)"?\s*=\s*"?(.+?)"?\s*$/.exec(arg);
        const nameMatch = textMatcher(m ? m[1] : arg, true);
        const valueMatch = m ? textMatcher(m[2], true) : () => true;
        return nodes.filter((n) => {
          for (const a of n.attributes || []) if (nameMatch(a.name) && valueMatch(a.value)) return true;
          return false;
        });
      }
      case "matches-path": {
        const match = textMatcher(arg);
        return match(location.pathname + location.search) ? nodes : [];
      }
      case "matches-media":
        try {
          return matchMedia(arg).matches ? nodes : [];
        } catch {
          return [];
        }
      case "xpath":
        for (const n of nodes) {
          try {
            const r = document.evaluate(arg, n, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
            for (let j = 0; j < r.snapshotLength; j++) {
              const e = r.snapshotItem(j);
              if (e.nodeType === 1) out.push(e);
            }
          } catch {
          }
        }
        return out;
      default:
        return [];
    }
  }
  function runCompiled(c, root2 = document) {
    let nodes;
    if (c.prefix) {
      try {
        nodes = Array.from(root2 === document ? document.querySelectorAll(c.prefix) : root2.querySelectorAll(c.prefix.startsWith(":scope") ? c.prefix : ":scope " + c.prefix));
      } catch {
        return [];
      }
    } else {
      nodes = [root2];
    }
    for (const t of c.tasks) {
      if (nodes.length === 0) break;
      nodes = applyTask(t, nodes);
    }
    return nodes.filter((n) => n && n.nodeType === 1);
  }
  function matchesCompiled(c, el) {
    if (c.prefix) {
      try {
        if (!el.matches(c.prefix)) return false;
      } catch {
        return false;
      }
    }
    let nodes = [el];
    for (const t of c.tasks) {
      nodes = applyTask(t, nodes);
      if (nodes.length === 0) return false;
    }
    return true;
  }
  var ProceduralEngine = class {
    constructor(selectors, hideAttr, onHidden) {
      this.filters = [];
      for (const s of selectors) {
        try {
          const c = compileProcedural(s);
          if (c) this.filters.push(c);
        } catch {
        }
      }
      this.hideAttr = hideAttr;
      this.onHidden = onHidden;
      this.timer = 0;
      this.hidden = /* @__PURE__ */ new WeakSet();
    }
    run() {
      let count2 = 0;
      for (const f of this.filters) {
        let nodes;
        try {
          nodes = runCompiled(f);
        } catch {
          continue;
        }
        for (const n of nodes) {
          if (n === document.documentElement || n === document.body) continue;
          const a = f.action;
          if (!a) {
            if (!n.hasAttribute(this.hideAttr)) {
              n.setAttribute(this.hideAttr, "");
              count2++;
            }
          } else if (a[0] === "remove") {
            n.remove();
            count2++;
          } else if (a[0] === "remove-attr") {
            for (const attr of a[1].split("|")) n.removeAttribute(attr.trim());
          } else if (a[0] === "remove-class") {
            for (const cls of a[1].split("|")) n.classList.remove(cls.trim());
          } else if (a[0] === "style") {
            const cur = n.getAttribute("style") || "";
            if (!cur.includes(a[1])) n.setAttribute("style", cur + ";" + a[1]);
          }
        }
      }
      if (count2 && this.onHidden) this.onHidden(count2);
    }
    start() {
      if (this.filters.length === 0) return;
      const schedule = () => {
        if (this.timer) return;
        this.timer = setTimeout(() => {
          this.timer = 0;
          this.run();
        }, 120);
      };
      const begin = () => {
        this.run();
        new MutationObserver(schedule).observe(document.documentElement, { childList: true, subtree: true });
      };
      if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", begin, { once: true });
      else begin();
    }
  };

  // src/content/cosmetic.js
  function startCosmetic(init, send) {
    const { hideAttr, procedural, lowGeneric, countSelectors } = init;
    let hiddenProcedural = 0;
    const extraSelectors = [];
    let countTimer = 0;
    let lastSent = -1;
    const countHidden = () => {
      countTimer = 0;
      const sels = countSelectors.concat(extraSelectors);
      let n = 0;
      const seenEls = /* @__PURE__ */ new Set();
      for (let i = 0; i < sels.length; i += 200) {
        const chunk = sels.slice(i, i + 200).join(",");
        let list;
        try {
          list = document.querySelectorAll(chunk);
        } catch {
          list = [];
          for (const s of sels.slice(i, i + 200)) {
            try {
              list = list.concat(Array.from(document.querySelectorAll(s)));
            } catch {
            }
          }
        }
        for (const el of list) {
          if (!seenEls.has(el)) {
            seenEls.add(el);
            n++;
          }
        }
      }
      n += hiddenProcedural;
      if (n !== lastSent) {
        lastSent = n;
        send({ type: "cosmetic:hidden", count: n }).catch(() => {
        });
      }
    };
    const scheduleCount = () => {
      if (countTimer) return;
      countTimer = setTimeout(() => {
        if ("requestIdleCallback" in window) requestIdleCallback(countHidden, { timeout: 2e3 });
        else countHidden();
      }, 1500);
    };
    if (procedural && procedural.length) {
      const engine = new ProceduralEngine(procedural, hideAttr, (n) => {
        hiddenProcedural += n;
        scheduleCount();
      });
      engine.start();
    }
    const seen = /* @__PURE__ */ new Set();
    let pending = [];
    let flushTimer = 0;
    const flush = () => {
      flushTimer = 0;
      if (pending.length === 0) return;
      const tokens = pending;
      pending = [];
      send({ type: "cosmetic:tokens", tokens }).then((res) => {
        if (res && res.selectors && res.selectors.length) {
          extraSelectors.push(...res.selectors);
          scheduleCount();
        }
      }).catch(() => {
      });
    };
    const MAX_TOKENS = 2e4;
    const HASHED = /^\.(?:css|sc|jsx|emotion|styled|svelte|astro)-[a-zA-Z0-9_-]{4,}$/;
    const addToken = (t) => {
      if (seen.has(t) || seen.size >= MAX_TOKENS || t.length > 128 || HASHED.test(t)) return;
      seen.add(t);
      pending.push(t);
    };
    const scanElement = (el) => {
      if (el.id) addToken("#" + el.id);
      const cl = el.classList;
      if (cl) for (let i = 0; i < cl.length; i++) addToken("." + cl[i]);
    };
    const scanTree = (root2) => {
      if (root2.nodeType !== 1) return;
      scanElement(root2);
      for (const el of root2.querySelectorAll("[id],[class]")) scanElement(el);
    };
    const scheduleFlush = () => {
      if (!flushTimer) flushTimer = setTimeout(flush, 60);
    };
    if (lowGeneric) {
      const begin = () => {
        scanTree(document.documentElement);
        flush();
        new MutationObserver((records) => {
          for (const r of records) {
            if (r.type === "attributes") scanElement(r.target);
            else for (const n of r.addedNodes) scanTree(n);
          }
          if (pending.length) scheduleFlush();
        }).observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ["id", "class"] });
      };
      begin();
    }
    if (document.readyState === "complete") scheduleCount();
    else window.addEventListener("load", scheduleCount, { once: true });
    document.addEventListener("DOMContentLoaded", scheduleCount, { once: true });
  }

  // src/content/notice.js
  var host = null;
  var root = null;
  var hideTimer = 0;
  var count = 0;
  var CLICK_DELAY_MS = 600;
  function genuinelyVisible(button, e) {
    try {
      const r = button.getBoundingClientRect();
      if (r.width > 160 || r.height > 60 || r.width < 8 || r.height < 8) return false;
      if (e.detail !== 0 && document.elementFromPoint(e.clientX, e.clientY) !== host) return false;
      for (let n = host.parentElement; n; n = n.parentElement) {
        const cs = getComputedStyle(n);
        if (Number(cs.opacity) < 0.95 || cs.visibility !== "visible" || cs.filter !== "none" || cs.clipPath !== "none" || cs.mask && cs.mask !== "none") return false;
      }
      return true;
    } catch {
      return false;
    }
  }
  function ensure() {
    if (host && host.isConnected) return;
    host = document.createElement("devshield-notice");
    root = host.attachShadow({ mode: "closed" });
    const style = document.createElement("style");
    style.textContent = `
      :host{all:initial!important;position:fixed!important;z-index:2147483647!important;right:16px!important;
        bottom:16px!important;left:auto!important;top:auto!important;width:auto!important;height:auto!important;
        display:block!important;transform:none!important;opacity:1!important;filter:none!important;
        clip-path:none!important;mask:none!important;visibility:visible!important;pointer-events:auto!important;
        zoom:1!important;scale:none!important;rotate:none!important;translate:none!important}
      .box{font:13px/1.4 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;color:#f3f4f6;background:#0b1020;
        border:1px solid rgba(255,255,255,.12);border-radius:12px;padding:10px 12px;display:flex;gap:10px;
        align-items:center;box-shadow:0 8px 30px rgba(0,0,0,.35);max-width:360px}
      .dot{width:8px;height:8px;border-radius:50%;background:#10b981;flex:none}
      .txt{flex:1;min-width:0}
      .host{font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;display:block}
      button{font:inherit;font-weight:600;border-radius:8px;border:1px solid rgba(255,255,255,.15);
        background:rgba(255,255,255,.06);color:#f3f4f6;padding:4px 10px;cursor:pointer}
      button:hover{background:rgba(255,255,255,.12)}
      .x{border:none;background:none;color:#9ca3af;padding:2px 4px}
      button:focus-visible{outline:2px solid #2563eb;outline-offset:2px}
      @media (prefers-color-scheme: light){
        .box{color:#0f172a;background:#fff;border-color:rgba(15,23,42,.14);box-shadow:0 8px 30px rgba(15,23,42,.18)}
        .dot{background:#059669}
        button{color:#0f172a;border-color:rgba(15,23,42,.2);background:rgba(15,23,42,.04)}
        button:hover{background:rgba(15,23,42,.09)}
        .x{color:#475569;background:none}
      }`;
    root.append(style);
    (document.body || document.documentElement).append(host);
  }
  var LABELS = {
    popup: "Blocked a pop-up",
    popunder: "Blocked a pop-under",
    redirect: "Blocked a redirect",
    form: "Blocked a form redirect",
    "tab-closed": "Closed a pop-under tab"
  };
  function showNotice({ kind, url }, onAllow) {
    if (window !== window.top) return;
    let destHost = url;
    try {
      destHost = new URL(url).hostname;
    } catch {
    }
    ensure();
    count++;
    root.querySelectorAll(".box").forEach((b) => b.remove());
    const box = document.createElement("div");
    box.className = "box";
    box.setAttribute("role", "status");
    const dot = document.createElement("span");
    dot.className = "dot";
    const txt = document.createElement("div");
    txt.className = "txt";
    txt.textContent = `${LABELS[kind] || "Blocked"}${count > 1 ? ` (${count})` : ""} to`;
    const h = document.createElement("span");
    h.className = "host";
    h.textContent = destHost;
    txt.append(h);
    box.append(dot, txt);
    if (onAllow && kind !== "tab-closed" && /^https?:/.test(url)) {
      const allow = document.createElement("button");
      allow.textContent = "Open";
      allow.title = url;
      allow.addEventListener("click", (e) => {
        if (!e.isTrusted || performance.now() - shownAt < CLICK_DELAY_MS || !genuinelyVisible(allow, e)) return;
        box.remove();
        onAllow();
      });
      box.append(allow);
    }
    const close = document.createElement("button");
    close.className = "x";
    close.textContent = "\u2715";
    close.title = "Dismiss";
    close.setAttribute("aria-label", "Dismiss");
    close.addEventListener("click", () => box.remove());
    box.append(close);
    root.append(box);
    const shownAt = performance.now();
    clearTimeout(hideTimer);
    hideTimer = setTimeout(() => box.remove(), 7e3);
  }

  // src/content/index.js
  (function isolated() {
    let channel = null;
    try {
      channel = openChannel("isolated");
    } catch {
    }
    const send = (msg) => {
      try {
        return chrome.runtime.sendMessage(msg).catch(() => null);
      } catch {
        return Promise.resolve(null);
      }
    };
    if (channel) {
      channel.on((msg) => {
        if (!msg || typeof msg !== "object") return;
        if (msg.type === "blocked") send({ type: "blocked", kind: msg.kind, url: msg.url, reason: msg.reason });
        else if (msg.type === "yt") send({ type: "yt", what: msg.what });
        else if (msg.type === "tab-intent") send({ type: "tab-intent" });
      });
    }
    chrome.runtime.onMessage.addListener((msg) => {
      if (msg && msg.type === "notice" && window === window.top) {
        showNotice(msg, async () => {
          if ((msg.kind === "redirect" || msg.kind === "form") && channel) {
            channel.send({ type: "open-blocked", url: msg.url, kind: msg.kind });
          } else if (msg.kind === "redirect" || msg.kind === "form") {
            location.href = msg.url;
          } else {
            await send({ type: "allow-tab", url: msg.url }).catch(() => {
            });
            window.open(msg.url, "_blank", "noopener");
          }
        });
      }
    });
    send({ type: "page:init", top: window === window.top }).then((init) => {
      if (!init || !init.active) return;
      if (channel && init.config) channel.send({ type: "config", config: init.config });
      if (init.cosmetic) startCosmetic(init.cosmetic, send);
    }).catch(() => {
    });
  })();
})();
