(() => {
  // src/shared/filters/dnr.js
  var HOST_RE = /^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)*$/;
  var IPV4_RE = /^\d{1,3}(\.\d{1,3}){3}$/;
  function isValidHost(h) {
    return !!h && h.length <= 253 && (HOST_RE.test(h) || IPV4_RE.test(h));
  }

  // src/shared/settings.js
  var DEFAULT_SETTINGS = {
    shieldEnabled: true,
    // Hostnames (or registrable domains) where DevShield is fully off.
    allowlist: [],
    // Ruleset id → enabled. Missing ids fall back to the ruleset's default.
    rulesets: {},
    // Redirect engine strictness: 'standard' | 'strict'.
    redirectMode: "standard",
    // Hosts where same-site new-tab links open in the current tab.
    focusModeSites: [],
    // Extra hosts that may be reached by programmatic navigation.
    redirectSafeHosts: [],
    // [{ site, host }]: requests to host are allowed when made by site.
    siteAllows: [],
    // Privacy.
    gpc: true,
    stripTrackingParams: true,
    // YouTube.
    ytHideShorts: false,
    ytHidePremiumUpsell: true,
    ytSkipWatchdog: true,
    // Custom filters (ABP syntax subset) and list subscriptions (URLs).
    customFilters: "",
    customListUrls: [],
    autoUpdate: true,
    // Show an in-page notice when a pop-up is blocked.
    showBlockNotices: true
  };
  function normalizeHost(value) {
    if (typeof value !== "string") return "";
    let v = value.trim().toLowerCase();
    if (!v) return "";
    try {
      v = new URL(v.includes("://") ? v : `https://${v}`).hostname;
    } catch {
      return "";
    }
    v = v.replace(/\.$/, "");
    const last = v.slice(v.lastIndexOf(".") + 1);
    if (/^\d+$/.test(last) && !/^(?:(?:25[0-5]|2[0-4]\d|1?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|1?\d?\d)$/.test(v)) return "";
    return isValidHost(v) ? v : "";
  }
  var hostArray = (v) => [...new Set((Array.isArray(v) ? v : []).map(normalizeHost).filter(Boolean))];
  function normalizeSettings(input) {
    const src = input && typeof input === "object" ? input : {};
    const out = { ...DEFAULT_SETTINGS };
    for (const k of Object.keys(DEFAULT_SETTINGS)) {
      if (!(k in src)) continue;
      const d = DEFAULT_SETTINGS[k];
      const v = src[k];
      if (typeof d === "boolean" && typeof v === "boolean") out[k] = v;
      else if (typeof d === "string" && typeof v === "string") out[k] = v;
    }
    if (!["standard", "strict"].includes(out.redirectMode)) out.redirectMode = DEFAULT_SETTINGS.redirectMode;
    out.allowlist = hostArray(src.allowlist);
    out.focusModeSites = hostArray(src.focusModeSites);
    out.redirectSafeHosts = hostArray(src.redirectSafeHosts);
    out.siteAllows = (Array.isArray(src.siteAllows) ? src.siteAllows : []).map((a) => a && typeof a === "object" ? { site: normalizeHost(a.site), host: normalizeHost(a.host) } : null).filter((a) => a && a.site && a.host);
    out.customListUrls = [...new Set((Array.isArray(src.customListUrls) ? src.customListUrls : []).filter((u) => {
      try {
        return typeof u === "string" && new URL(u).protocol === "https:";
      } catch {
        return false;
      }
    }))];
    out.rulesets = {};
    if (src.rulesets && typeof src.rulesets === "object" && !Array.isArray(src.rulesets)) {
      for (const [id, on] of Object.entries(src.rulesets)) if (typeof on === "boolean") out.rulesets[id] = on;
    }
    return out;
  }

  // src/ui/options.js
  var $ = (id) => document.getElementById(id);
  var send = (msg) => chrome.runtime.sendMessage(msg);
  var settings = null;
  var lastSubs = {};
  var loadedFilters = "";
  var filtersChangedElsewhere = false;
  function el(tag, cls, text) {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== void 0) e.textContent = text;
    return e;
  }
  function toast(text) {
    const t = $("toast");
    t.textContent = text;
    t.classList.add("show");
    setTimeout(() => t.classList.remove("show"), 1800);
  }
  async function loadSettings() {
    const stored = await chrome.storage.local.get(Object.keys(DEFAULT_SETTINGS));
    settings = normalizeSettings(stored);
  }
  async function save(patch, message = "Saved") {
    Object.assign(settings, patch);
    await chrome.storage.local.set(patch);
    toast(message);
  }
  function hostLines(text) {
    return [...new Set(text.split("\n").map(normalizeHost).filter(Boolean))];
  }
  function switchRow(label, desc, checked, onChange) {
    const row = el("div", "row");
    const text = el("div", "row-text", label);
    if (desc) text.append(el("small", "", desc));
    const sw = el("label", "switch");
    const input = el("input");
    input.type = "checkbox";
    input.setAttribute("aria-label", label);
    input.checked = checked;
    input.addEventListener("change", () => onChange(input.checked));
    sw.append(input, el("span", "slider"));
    row.append(text, sw);
    return row;
  }
  async function renderLists() {
    const st = await send({ type: "options:state" });
    if (!st) return;
    const rows = $("rulesetRows");
    rows.replaceChildren();
    const errors = new Map((st.errors || []).map((e) => [e.id, e.error]));
    let enabledRules = 0;
    for (const m of st.index) {
      const on = settings.rulesets[m.id] ?? m.enabled;
      if (on) enabledRules += m.rules;
      const desc = `${m.description} \xB7 ${m.rules.toLocaleString()} network rules` + (m.scriptlets ? ` \xB7 ${m.scriptlets.toLocaleString()} scriptlets` : "") + (m.cosmetic && m.cosmetic.specificHosts ? ` \xB7 cosmetic rules for ${m.cosmetic.specificHosts.toLocaleString()} site${m.cosmetic.specificHosts === 1 ? "" : "s"}` : "");
      const row = switchRow(m.name, desc, on, async (v) => {
        await save({ rulesets: { ...settings.rulesets, [m.id]: v } }, v ? `${m.name} enabled` : `${m.name} disabled`);
        setTimeout(renderLists, 800);
      });
      if (errors.has(m.id)) row.querySelector(".row-text").append(el("span", "badge err", "Could not enable: rule limit reached"));
      rows.append(row);
    }
    const guaranteed = 3e4;
    const pct = Math.min(100, Math.round(enabledRules / guaranteed * 100));
    $("budgetBar").style.width = `${pct}%`;
    $("budgetText").textContent = `${enabledRules.toLocaleString()} static rules enabled (Chrome guarantees ${guaranteed.toLocaleString()} per extension, more when available` + (st.availableStatic !== null ? `; ${st.availableStatic.toLocaleString()} more available now` : "") + `) \xB7 ${st.dynamicCount.toLocaleString()} / ${st.dynamicMax.toLocaleString()} custom rules.`;
    lastSubs = st.subscriptions || {};
    renderSubs(lastSubs);
  }
  function renderSubs(subs) {
    const table = $("subsTable");
    table.replaceChildren();
    if (settings.customListUrls.length === 0) {
      const tr = el("tr");
      const td = el("td", "muted", "No subscribed lists.");
      tr.append(td);
      table.append(tr);
      return;
    }
    for (const url of settings.customListUrls) {
      const s = subs[url];
      const tr = el("tr");
      const info = el("td");
      info.append(el("div", "mono", url));
      const meta = s ? s.error ? `Error: ${s.error}` : `Updated ${new Date(s.updated).toLocaleString()} \xB7 ${(s.size / 1024).toFixed(0)} KB` : "Not downloaded yet";
      info.append(el("small", s && s.error ? "badge err" : "muted", meta));
      const act = el("td");
      const rm = el("button", "btn small danger", "Remove");
      rm.addEventListener("click", async () => {
        await save({ customListUrls: settings.customListUrls.filter((u) => u !== url) }, "Removed");
        await send({ type: "lists:update" });
        renderLists();
      });
      act.append(rm);
      tr.append(info, act);
      table.append(tr);
    }
  }
  function renderSites() {
    const table = $("allowTable");
    table.replaceChildren();
    if (settings.allowlist.length === 0) {
      const tr = el("tr");
      tr.append(el("td", "muted", "No trusted sites."));
      table.append(tr);
    }
    for (const host of [...settings.allowlist].sort()) {
      const tr = el("tr");
      const act = el("td");
      const rm = el("button", "btn small danger", "Remove");
      rm.addEventListener("click", async () => {
        await save({ allowlist: settings.allowlist.filter((h) => h !== host) }, `${host} removed`);
        renderSites();
      });
      act.append(rm);
      tr.append(el("td", "mono", host), act);
      table.append(tr);
    }
    const sa = $("siteAllowTable");
    sa.replaceChildren();
    if (settings.siteAllows.length === 0) {
      const tr = el("tr");
      tr.append(el("td", "muted", "None."));
      sa.append(tr);
    }
    for (const a of settings.siteAllows) {
      const tr = el("tr");
      const act = el("td");
      const rm = el("button", "btn small danger", "Remove");
      rm.addEventListener("click", async () => {
        await save({ siteAllows: settings.siteAllows.filter((x) => !(x.site === a.site && x.host === a.host)) }, "Removed");
        renderSites();
      });
      act.append(rm);
      tr.append(el("td", "mono", `${a.host} on ${a.site}`), act);
      sa.append(tr);
    }
  }
  function renderForms() {
    $("customFilters").value = settings.customFilters;
    loadedFilters = settings.customFilters;
    filtersChangedElsewhere = false;
    $("redirectMode").value = settings.redirectMode;
    $("showBlockNotices").checked = settings.showBlockNotices;
    $("redirectSafeHosts").value = settings.redirectSafeHosts.join("\n");
    $("focusModeSites").value = settings.focusModeSites.join("\n");
    for (const id of ["gpc", "stripTrackingParams", "autoUpdate"]) $(id).checked = settings[id];
  }
  function wire() {
    for (const b of document.querySelectorAll("#nav button")) {
      b.addEventListener("click", () => {
        document.querySelectorAll("#nav button").forEach((x) => x.classList.toggle("active", x === b));
        document.querySelectorAll("[data-panel]").forEach((p) => p.classList.toggle("hidden", p.dataset.panel !== b.dataset.tab));
      });
    }
    $("saveCustom").addEventListener("click", async () => {
      if (filtersChangedElsewhere) {
        toast("Filters were changed in another tab \u2014 reload this page first");
        return;
      }
      await save({ customFilters: $("customFilters").value }, "Filters applied");
      loadedFilters = $("customFilters").value;
      setTimeout(async () => {
        const st = await send({ type: "options:state" });
        if (st) $("customStatus").textContent = `${st.customCount.toLocaleString()} custom network rules active`;
      }, 1e3);
    });
    $("importFilters").addEventListener("click", () => $("importFiltersFile").click());
    $("importFiltersFile").addEventListener("change", async (e) => {
      const f = e.target.files[0];
      e.target.value = "";
      if (f) await importFilterFile(f);
    });
    $("exportFilters").addEventListener("click", () => {
      const text = $("customFilters").value;
      if (!text.trim()) {
        toast("You have no filters to export yet");
        return;
      }
      const blob = new Blob([`! DevShield: My filters
! Exported ${(/* @__PURE__ */ new Date()).toISOString()}
${text}
`], { type: "text/plain" });
      const a = el("a");
      a.href = URL.createObjectURL(blob);
      a.download = `devshield-my-filters-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.txt`;
      a.click();
      setTimeout(() => URL.revokeObjectURL(a.href), 1e3);
    });
    $("addSub").addEventListener("click", async () => {
      const url = $("subUrl").value.trim();
      try {
        if (new URL(url).protocol !== "https:") throw new Error();
      } catch {
        toast("Enter an https:// URL");
        return;
      }
      if (!settings.customListUrls.includes(url)) await save({ customListUrls: [...settings.customListUrls, url] }, "Downloading\u2026");
      $("subUrl").value = "";
      await send({ type: "lists:update" });
      toast("List updated");
      renderLists();
    });
    $("updateSubs").addEventListener("click", async () => {
      toast("Updating\u2026");
      await send({ type: "lists:update" });
      toast("Lists updated");
      renderLists();
    });
    $("addAllow").addEventListener("click", async () => {
      const v = normalizeHost($("allowInput").value);
      if (!v || !v.includes(".")) {
        toast("Enter a domain like example.com");
        return;
      }
      if (!settings.allowlist.includes(v)) await save({ allowlist: [...settings.allowlist, v] }, `${v} trusted`);
      $("allowInput").value = "";
      renderSites();
    });
    $("saveRedirects").addEventListener("click", () => save({
      redirectMode: $("redirectMode").value,
      redirectSafeHosts: hostLines($("redirectSafeHosts").value),
      focusModeSites: hostLines($("focusModeSites").value)
    }).then(renderForms));
    $("redirectMode").addEventListener("change", () => save({ redirectMode: $("redirectMode").value }));
    $("showBlockNotices").addEventListener("change", (e) => save({ showBlockNotices: e.target.checked }));
    for (const id of ["gpc", "stripTrackingParams", "autoUpdate"]) {
      $(id).addEventListener("change", (e) => save({ [id]: e.target.checked }));
    }
    $("shortcutsBtn").addEventListener("click", () => {
      chrome.tabs.create({ url: "chrome://extensions/shortcuts" }).catch(() => {
      });
    });
    chrome.commands.getAll().then((cmds) => {
      const set = cmds.filter((c) => c.shortcut).map((c) => `${c.shortcut}: ${c.description}`);
      if (set.length) $("shortcutText").textContent = `${set.join(" \xB7 ")}. Other actions (on/off everywhere, block element) can be given a shortcut too.`;
    }).catch(() => {
    });
    $("exportBtn").addEventListener("click", () => {
      const blob = new Blob([JSON.stringify({ devshield: 3, settings }, null, 2)], { type: "application/json" });
      const a = el("a");
      a.href = URL.createObjectURL(blob);
      a.download = `devshield-settings-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.json`;
      a.click();
      setTimeout(() => URL.revokeObjectURL(a.href), 1e3);
    });
    $("importBtn").addEventListener("click", () => $("importFile").click());
    $("importFile").addEventListener("change", async (e) => {
      const f = e.target.files[0];
      if (!f) return;
      try {
        const data = JSON.parse(await f.text());
        const incoming = data && data.settings;
        if (!incoming || typeof incoming !== "object" || Array.isArray(incoming)) throw new Error();
        const shapeOk = (k, v) => {
          const d = DEFAULT_SETTINGS[k];
          if (Array.isArray(d)) return Array.isArray(v);
          if (d && typeof d === "object") return !!v && typeof v === "object" && !Array.isArray(v);
          return typeof v === typeof d;
        };
        const merged = { ...settings };
        for (const k of Object.keys(DEFAULT_SETTINGS)) if (k in incoming && shapeOk(k, incoming[k])) merged[k] = incoming[k];
        const clean = normalizeSettings(merged);
        const patch = {};
        for (const k of Object.keys(DEFAULT_SETTINGS)) if (k in incoming) patch[k] = clean[k];
        await save(patch, "Settings imported");
        renderAll();
      } catch {
        toast("Not a DevShield settings file");
      }
    });
    $("resetStats").addEventListener("click", async () => {
      await send({ type: "stats:reset" });
      toast("Statistics reset");
    });
    $("resetAll").addEventListener("click", async () => {
      if (!confirm("Reset all DevShield settings?")) return;
      await chrome.storage.local.set({ ...DEFAULT_SETTINGS });
      const all = await chrome.storage.local.get(null);
      const stale = Object.keys(all).filter((k) => k.startsWith("subText:") || k === "subscriptions" || k === "rulesetErrors");
      if (stale.length) await chrome.storage.local.remove(stale);
      settings = { ...DEFAULT_SETTINGS };
      renderAll();
      toast("Defaults restored");
    });
  }
  function parseFilterImport(text) {
    const out = { filters: [], trusted: [] };
    const addTrusted = (entries) => {
      for (const e of entries) {
        const v = normalizeHost(String(e || "").trim().replace(/^\*\./, "").replace(/\/.*$/, ""));
        if (v && v.includes(".")) out.trusted.push(v);
      }
    };
    const trimmed = text.replace(/^\uFEFF/, "").trim();
    let lines = null;
    if (trimmed.startsWith("{")) {
      const data = JSON.parse(trimmed);
      if (data && typeof data.userFilters === "string") {
        lines = data.userFilters.split(/\r?\n/);
        const wl = Array.isArray(data.whitelist) ? data.whitelist : typeof data.netWhitelist === "string" ? data.netWhitelist.split(/\r?\n/) : [];
        addTrusted(wl.filter((w) => typeof w === "string" && !w.startsWith("#") && !w.includes("-scheme")));
      } else if (data && data.filters && typeof data.filters === "object") {
        const uf = data.filters["user-filter"];
        if (uf && typeof uf.rules === "string") lines = uf.rules.split(/\r?\n/);
        const al = data.filters.allowlist;
        if (al && Array.isArray(al.domains)) addTrusted(al.domains);
      }
      if (!lines && !out.trusted.length) throw new Error("unknown-json");
    } else {
      lines = trimmed.split(/\r?\n/);
    }
    for (const raw of lines || []) {
      const l = raw.trim();
      if (!l || l.startsWith("!") || /^\[adblock/i.test(l) || l.length > 4096) continue;
      out.filters.push(l);
    }
    out.filters = [...new Set(out.filters)];
    out.trusted = [...new Set(out.trusted)];
    return out;
  }
  async function importFilterFile(file) {
    if (file.size > 4 * 1024 * 1024) {
      toast("That file is too large (4 MB max)");
      return;
    }
    if (filtersChangedElsewhere || $("customFilters").value !== loadedFilters) {
      toast("Apply or reload your current filters first");
      return;
    }
    let parsed;
    try {
      parsed = parseFilterImport(await file.text());
    } catch {
      toast("Not a filter list or a uBlock Origin / AdGuard backup");
      return;
    }
    const current = settings.customFilters ? settings.customFilters.replace(/\n+$/, "").split("\n") : [];
    const have = new Set(current.map((l) => l.trim()));
    const fresh = parsed.filters.filter((l) => !have.has(l));
    const patch = {};
    if (fresh.length) {
      const name = file.name.replace(/[\r\n]/g, " ").slice(0, 80);
      const header = `! Imported from ${name} on ${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}`;
      patch.customFilters = [...current, ...current.length ? [""] : [], header, ...fresh].join("\n");
    }
    const newTrusted = parsed.trusted.filter((h) => !settings.allowlist.includes(h));
    if (newTrusted.length) patch.allowlist = [...settings.allowlist, ...newTrusted];
    if (!Object.keys(patch).length) {
      toast(parsed.filters.length || parsed.trusted.length ? "Nothing new: you already have all of these" : "No filters found in that file");
      return;
    }
    const parts = [];
    if (fresh.length) parts.push(`${fresh.length.toLocaleString()} filter${fresh.length === 1 ? "" : "s"}`);
    if (newTrusted.length) parts.push(`${newTrusted.length} trusted site${newTrusted.length === 1 ? "" : "s"}`);
    const summary = `Imported ${parts.join(" and ")}`;
    await save(patch, summary);
    renderForms();
    renderSites();
    $("customStatus").textContent = `${summary}.`;
    setTimeout(async () => {
      const st = await send({ type: "options:state" });
      if (st) $("customStatus").textContent = `${summary} \xB7 ${st.customCount.toLocaleString()} custom network rules active`;
    }, 1500);
  }
  function renderAll() {
    renderForms();
    renderSites();
    renderLists();
  }
  document.addEventListener("DOMContentLoaded", async () => {
    await loadSettings();
    wire();
    renderAll();
    let refreshTimer = 0;
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local" || !Object.keys(changes).some((k) => k in DEFAULT_SETTINGS)) return;
      clearTimeout(refreshTimer);
      refreshTimer = setTimeout(async () => {
        await loadSettings();
        renderSites();
        renderSubs(lastSubs);
        if (settings.customFilters !== loadedFilters) {
          if ($("customFilters").value === loadedFilters) {
            $("customFilters").value = settings.customFilters;
            loadedFilters = settings.customFilters;
            filtersChangedElsewhere = false;
          } else {
            filtersChangedElsewhere = true;
            $("customStatus").textContent = "Changed in another tab \u2014 reload to see the latest filters.";
          }
        }
      }, 200);
    });
  });
})();
