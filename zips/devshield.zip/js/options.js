(() => {
  // src/shared/filters/dnr.js
  var PRIORITY = {
    removeparam: 1,
    block: 10,
    redirect: 20,
    allow: 30,
    importantBlock: 40,
    importantRedirect: 45,
    importantAllow: 50
  };
  var TYPE_MAP = {
    script: ["script"],
    image: ["image"],
    stylesheet: ["stylesheet"],
    css: ["stylesheet"],
    object: ["object"],
    "object-subrequest": ["object"],
    xmlhttprequest: ["xmlhttprequest"],
    xhr: ["xmlhttprequest"],
    subdocument: ["sub_frame"],
    frame: ["sub_frame"],
    ping: ["ping"],
    beacon: ["ping"],
    websocket: ["websocket"],
    media: ["media"],
    font: ["font"],
    other: ["other"],
    document: ["main_frame", "sub_frame"],
    doc: ["main_frame", "sub_frame"]
  };
  var ALL_TYPES = [
    "main_frame",
    "sub_frame",
    "stylesheet",
    "script",
    "image",
    "font",
    "object",
    "xmlhttprequest",
    "ping",
    "csp_report",
    "media",
    "websocket",
    "webtransport",
    "webbundle",
    "other"
  ];
  var REDIRECT_RESOURCES = {
    "noopjs": "noop.js",
    "noop.js": "noop.js",
    "abp-resource:blank-js": "noop.js",
    "noopframe": "noop.html",
    "noop.html": "noop.html",
    "noopcss": "noop.css",
    "noop.css": "noop.css",
    "nooptext": "noop.txt",
    "noop.txt": "noop.txt",
    "empty": "noop.txt",
    "1x1.gif": "1x1.gif",
    "1x1-transparent.gif": "1x1.gif",
    "2x2.png": "2x2.png",
    "2x2-transparent.png": "2x2.png",
    "3x2.png": "2x2.png",
    "3x2-transparent.png": "2x2.png",
    "32x32.png": "2x2.png",
    "32x32-transparent.png": "2x2.png",
    "noopvmap-1.0": "noop-vmap1.xml",
    "noop-vmap1.0.xml": "noop-vmap1.xml",
    "noopvast-2.0": "noop-vast2.xml",
    "noop-vast2.xml": "noop-vast2.xml",
    "noopvast-3.0": "noop-vast3.xml",
    "noop-vast3.xml": "noop-vast3.xml",
    "noopvast-4.0": "noop-vast4.xml",
    "noop-vast4.xml": "noop-vast4.xml",
    "googlesyndication_adsbygoogle.js": "googlesyndication_adsbygoogle.js",
    "googlesyndication.com/adsbygoogle.js": "googlesyndication_adsbygoogle.js",
    "googletagservices_gpt.js": "googletagservices_gpt.js",
    "googletagservices.com/gpt.js": "googletagservices_gpt.js",
    "google-analytics_analytics.js": "google-analytics_analytics.js",
    "google-analytics.com/analytics.js": "google-analytics_analytics.js",
    "googletagmanager_gtm.js": "google-analytics_analytics.js",
    "googletagmanager.com/gtm.js": "google-analytics_analytics.js",
    "google-analytics_ga.js": "google-analytics_ga.js",
    "google-analytics.com/ga.js": "google-analytics_ga.js",
    "google-analytics_inpage_linkid.js": "noop.js",
    "google-analytics_cx_api.js": "noop.js",
    "google-ima.js": "google-ima.js",
    "google-ima3": "google-ima.js",
    "amazon_ads.js": "amazon_ads.js",
    "amazon-adsystem.com/aax2/amzn_ads.js": "amazon_ads.js",
    "amazon_apstag.js": "amazon_apstag.js",
    "fingerprint2.js": "fingerprint2.js",
    "fingerprint3.js": "fingerprint3.js",
    "prebid-ads.js": "prebid-ads.js",
    "ampproject_v0.js": "ampproject_v0.js",
    "ampproject.org/v0.js": "ampproject_v0.js",
    "scorecardresearch_beacon.js": "scorecardresearch_beacon.js",
    "scorecardresearch.com/beacon.js": "scorecardresearch_beacon.js",
    "doubleclick_instream_ad_status.js": "doubleclick_instream_ad_status.js",
    "outbrain-widget.js": "noop.js",
    "hd-main.js": "noop.js",
    "nobab.js": "noop.js",
    "noeval.js": "noop.js",
    "click2load.html": "noop.html"
  };
  var DNR_METHODS = /* @__PURE__ */ new Set(["connect", "delete", "get", "head", "options", "patch", "post", "put", "other"]);
  var COSMETIC_OPTS = /* @__PURE__ */ new Set(["generichide", "ghide", "elemhide", "ehide", "specifichide", "shide"]);
  var IGNORED_OPTS = /* @__PURE__ */ new Set(["reason", "_", "stealth", "cookie"]);
  function toAsciiHost(h) {
    if (/^[\x00-\x7f]*$/.test(h)) return h.toLowerCase();
    try {
      return new URL("http://" + h).hostname;
    } catch {
      return null;
    }
  }
  var HOST_RE = /^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)*$/;
  var IPV4_RE = /^\d{1,3}(\.\d{1,3}){3}$/;
  function isValidHost(h) {
    return !!h && h.length <= 253 && (HOST_RE.test(h) || IPV4_RE.test(h));
  }
  function parseDomainList(value, sep = "|") {
    const pos = [];
    const neg = [];
    let entities = 0;
    let regex = 0;
    for (let d of value.split(sep)) {
      d = d.trim();
      if (!d) continue;
      let negated = false;
      if (d.startsWith("~")) {
        negated = true;
        d = d.slice(1);
      }
      if (d.startsWith("/")) {
        regex++;
        continue;
      }
      if (d.endsWith(".*")) {
        entities++;
        continue;
      }
      const a = toAsciiHost(d);
      if (!a || !isValidHost(a)) continue;
      (negated ? neg : pos).push(a);
    }
    return { pos, neg, entities, regex };
  }
  function isRe2Compatible(re) {
    if (/\(\?[=!]|\(\?<[=!]|\\[1-9]/.test(re)) return false;
    if (re.length > 120) return false;
    for (const m of re.matchAll(/\{(\d+)(?:,(\d*))?\}/g)) {
      if (Number(m[1]) >= 20 || m[2] && Number(m[2]) >= 20) return false;
    }
    try {
      new RegExp(re);
    } catch {
      return false;
    }
    return true;
  }
  function convertPattern(pattern, matchCase) {
    if (pattern === "" || pattern === "*" || pattern === "|" || pattern === "||") return {};
    if (/^\/.+\/$/.test(pattern)) {
      const re = pattern.slice(1, -1);
      if (!isRe2Compatible(re)) return { error: "regex-unsupported" };
      return { regexFilter: re };
    }
    if (!/^[\x20-\x7e]*$/.test(pattern)) return { error: "non-ascii" };
    const pure = /^\|\|([a-z0-9.-]+)\^\|?$/i.exec(pattern);
    if (pure) {
      const host = pure[1].toLowerCase().replace(/\.$/, "");
      if (isValidHost(host)) return { domain: host };
    }
    let f = pattern;
    if (f.startsWith("||*")) f = f.slice(3).replace(/^\*+/, "") || "*";
    while (f.startsWith("*") && f.length > 1) f = f.slice(1);
    while (f.endsWith("*") && f.length > 1 && !f.endsWith("\\*")) f = f.slice(0, -1);
    if (!matchCase) f = f.toLowerCase();
    const literal = f.replace(/^\|\|?/, "").replace(/[\^*|]/g, "");
    if (literal.length < 3) return { error: "too-generic" };
    return { urlFilter: f };
  }
  function convertNetwork(entry) {
    const { exception, pattern, options } = entry;
    const resourceTypes = /* @__PURE__ */ new Set();
    const excludedResourceTypes = /* @__PURE__ */ new Set();
    const condition = {};
    let important = false;
    let matchCase = false;
    let redirect = null;
    let redirectRule = false;
    let removeparam = null;
    let csp = null;
    let hasCosmeticOpt = false;
    const cosmeticOpts = [];
    let docException = false;
    let popupOnly = false;
    let hadTypes = false;
    for (const opt of options) {
      const { name, value, negated } = opt;
      if (TYPE_MAP[name]) {
        hadTypes = true;
        if (name === "document" || name === "doc") {
          if (exception) docException = true;
        }
        for (const t of TYPE_MAP[name]) (negated ? excludedResourceTypes : resourceTypes).add(t);
        continue;
      }
      switch (name) {
        case "third-party":
        case "3p":
        case "strict3p":
          condition.domainType = negated ? "firstParty" : "thirdParty";
          break;
        case "first-party":
        case "1p":
        case "strict1p":
          condition.domainType = negated ? "thirdParty" : "firstParty";
          break;
        case "domain":
        case "from": {
          if (!value) return { skip: "bad-domain" };
          const d = parseDomainList(value);
          if (d.pos.length === 0 && (d.entities || d.regex) && d.neg.length === 0) return { skip: "entity-only" };
          if (d.pos.length === 0 && (d.entities || d.regex)) return { skip: "entity-only" };
          if (d.pos.length === 0 && d.neg.length === 0) return { skip: "bad-domain" };
          if (d.pos.length) condition.initiatorDomains = d.pos;
          if (d.neg.length) condition.excludedInitiatorDomains = d.neg;
          break;
        }
        case "to": {
          if (!value) return { skip: "bad-to" };
          const d = parseDomainList(value);
          if (d.pos.length === 0 && (d.entities || d.regex)) return { skip: "entity-only" };
          if (d.pos.length === 0 && d.neg.length === 0) return { skip: "bad-to" };
          if (d.pos.length) condition.requestDomains = d.pos;
          if (d.neg.length) condition.excludedRequestDomains = d.neg;
          break;
        }
        case "denyallow": {
          if (!value) return { skip: "bad-denyallow" };
          const d = parseDomainList(value);
          if (d.pos.length) condition.excludedRequestDomains = (condition.excludedRequestDomains || []).concat(d.pos);
          break;
        }
        case "important":
          important = true;
          break;
        case "match-case":
          matchCase = true;
          break;
        case "method": {
          if (!value) return { skip: "bad-method" };
          const pos = [];
          const neg = [];
          for (let m of value.split("|")) {
            m = m.trim().toLowerCase();
            const n = m.startsWith("~");
            if (n) m = m.slice(1);
            if (!DNR_METHODS.has(m)) return { skip: "bad-method" };
            (n ? neg : pos).push(m);
          }
          if (pos.length) condition.requestMethods = pos;
          if (neg.length) condition.excludedRequestMethods = neg;
          break;
        }
        case "all":
          hadTypes = true;
          for (const t of ALL_TYPES) resourceTypes.add(t);
          break;
        case "popup":
          hadTypes = true;
          popupOnly = true;
          break;
        case "redirect":
        case "redirect-rule": {
          if (!value) return { skip: "bad-redirect" };
          const res = value.split(":")[0];
          if (res === "none") return { skip: "redirect-none" };
          redirect = res;
          redirectRule = name === "redirect-rule";
          break;
        }
        case "empty":
          redirect = "empty";
          break;
        case "mp4":
          redirect = "mp4";
          resourceTypes.add("media");
          hadTypes = true;
          break;
        case "removeparam":
        case "queryprune":
          removeparam = value ?? "";
          break;
        case "csp":
          csp = value ?? "";
          break;
        case "badfilter":
          return { skip: "badfilter" };
        default:
          if (COSMETIC_OPTS.has(name)) {
            hasCosmeticOpt = true;
            cosmeticOpts.push(name);
            break;
          }
          if (IGNORED_OPTS.has(name)) break;
          return { skip: `option:${name}` };
      }
    }
    if (popupOnly && resourceTypes.size === 0) return { skip: "popup" };
    if (hasCosmeticOpt) {
      if (!exception) return { skip: "cosmetic-opt-on-block" };
      const hosts = [];
      const conv2 = convertPattern(pattern, false);
      if (conv2.domain) hosts.push(conv2.domain);
      if (condition.initiatorDomains) hosts.push(...condition.initiatorDomains);
      if (hosts.length === 0) return { skip: "cosmetic-opt-no-host" };
      return { cosmeticException: { hosts, opts: cosmeticOpts } };
    }
    if (removeparam !== null) {
      if (exception) {
        const conv3 = convertPattern(pattern, false);
        if (conv3.error || conv3.regexFilter) return { skip: "removeparam-exception-pattern" };
        const c = { resourceTypes: ["main_frame", "sub_frame"] };
        if (conv3.domain) c.requestDomains = [conv3.domain];
        else if (conv3.urlFilter) c.urlFilter = conv3.urlFilter;
        if (condition.initiatorDomains) c.initiatorDomains = condition.initiatorDomains;
        if (condition.excludedInitiatorDomains) c.excludedInitiatorDomains = condition.excludedInitiatorDomains;
        if (!c.requestDomains && !c.urlFilter && !c.initiatorDomains) return { skip: "removeparam-exception-too-broad" };
        return { rules: [{ priority: PRIORITY.removeparam + 1, action: { type: "allow" }, condition: c }] };
      }
      if (condition.excludedInitiatorDomains || condition.domainType) return { skip: "removeparam-complex" };
      if (!removeparam || removeparam.startsWith("/") || removeparam.startsWith("~") || removeparam.includes("|")) {
        return { skip: "removeparam-complex" };
      }
      const conv2 = convertPattern(pattern, false);
      if (conv2.error || conv2.regexFilter || conv2.urlFilter) return { skip: "removeparam-pattern" };
      return {
        removeparam: {
          param: removeparam,
          host: conv2.domain || null,
          initiatorDomains: condition.initiatorDomains || null
        }
      };
    }
    const conv = convertPattern(pattern, matchCase);
    if (conv.error) return { skip: conv.error };
    if (conv.domain) {
      condition.requestDomains = [conv.domain];
    } else if (conv.urlFilter) {
      condition.urlFilter = conv.urlFilter;
    } else if (conv.regexFilter) {
      condition.regexFilter = conv.regexFilter;
    }
    if (matchCase && (condition.urlFilter || condition.regexFilter)) condition.isUrlFilterCaseSensitive = true;
    if (resourceTypes.size) {
      for (const t of excludedResourceTypes) resourceTypes.delete(t);
      if (resourceTypes.size === 0) return { skip: "no-types" };
      condition.resourceTypes = [...resourceTypes].sort();
    } else if (excludedResourceTypes.size) {
      condition.excludedResourceTypes = [...excludedResourceTypes].sort();
    }
    const constrained = condition.urlFilter || condition.regexFilter || condition.requestDomains || condition.initiatorDomains || condition.resourceTypes && condition.resourceTypes.every((t) => t === "ping" || t === "csp_report");
    if (!constrained) return { skip: "too-broad" };
    if (csp !== null) {
      if (exception || !csp) return { skip: "csp-exception" };
      condition.resourceTypes = ["main_frame", "sub_frame"];
      delete condition.excludedResourceTypes;
      return {
        rules: [{
          priority: important ? PRIORITY.importantBlock : PRIORITY.block,
          action: {
            type: "modifyHeaders",
            responseHeaders: [{ header: "content-security-policy", operation: "append", value: csp }]
          },
          condition
        }]
      };
    }
    if (exception) {
      if (docException) {
        return {
          rules: [{
            priority: important ? PRIORITY.importantAllow : PRIORITY.allow,
            action: { type: "allowAllRequests" },
            condition: { ...condition, resourceTypes: ["main_frame", "sub_frame"] }
          }],
          docException: true
        };
      }
      return {
        rules: [{
          priority: important ? PRIORITY.importantAllow : PRIORITY.allow,
          action: { type: "allow" },
          condition
        }]
      };
    }
    if (redirect) {
      const res = REDIRECT_RESOURCES[redirect];
      if (!res) {
        if (redirectRule) return { skip: `redirect-resource:${redirect}` };
      } else {
        return {
          rules: [{
            priority: important ? PRIORITY.importantRedirect : PRIORITY.redirect,
            action: { type: "redirect", redirect: { extensionPath: `/web_accessible_resources/${res}` } },
            condition
          }]
        };
      }
    }
    return {
      rules: [{
        priority: important ? PRIORITY.importantBlock : PRIORITY.block,
        action: { type: "block" },
        condition
      }]
    };
  }

  // src/shared/settings.js
  var DEFAULT_SETTINGS = {
    shieldEnabled: true,
    // Hostnames (or registrable domains) where DevShield is fully off.
    allowlist: [],
    // Ruleset id → enabled. Missing ids fall back to the ruleset's default.
    rulesets: {},
    // Redirect engine strictness: 'standard' | 'strict'.
    redirectMode: "standard",
    // Hosts where same-site new-tab links open in the current tab.
    focusModeSites: [],
    // Extra hosts that may be reached by programmatic navigation.
    redirectSafeHosts: [],
    // [{ site, host }]: requests to host are allowed when made by site.
    siteAllows: [],
    // Privacy.
    gpc: true,
    stripTrackingParams: true,
    // YouTube.
    ytHideShorts: false,
    ytHidePremiumUpsell: true,
    ytSkipWatchdog: true,
    // Custom filters (ABP syntax subset) and list subscriptions (URLs).
    customFilters: "",
    customListUrls: [],
    autoUpdate: true,
    // Show an in-page notice when a pop-up is blocked.
    showBlockNotices: true
  };
  function normalizeHost(value) {
    if (typeof value !== "string") return "";
    let v = value.trim().toLowerCase();
    if (!v) return "";
    try {
      v = new URL(v.includes("://") ? v : `https://${v}`).hostname;
    } catch {
      return "";
    }
    v = v.replace(/\.$/, "");
    const last = v.slice(v.lastIndexOf(".") + 1);
    if (/^\d+$/.test(last) && !/^(?:(?:25[0-5]|2[0-4]\d|1?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|1?\d?\d)$/.test(v)) return "";
    return isValidHost(v) ? v : "";
  }
  var hostArray = (v) => [...new Set((Array.isArray(v) ? v : []).map(normalizeHost).filter(Boolean))];
  function normalizeSettings(input) {
    const src = input && typeof input === "object" ? input : {};
    const out = { ...DEFAULT_SETTINGS };
    for (const k of Object.keys(DEFAULT_SETTINGS)) {
      if (!(k in src)) continue;
      const d = DEFAULT_SETTINGS[k];
      const v = src[k];
      if (typeof d === "boolean" && typeof v === "boolean") out[k] = v;
      else if (typeof d === "string" && typeof v === "string") out[k] = v;
    }
    if (!["standard", "strict"].includes(out.redirectMode)) out.redirectMode = DEFAULT_SETTINGS.redirectMode;
    out.allowlist = hostArray(src.allowlist);
    out.focusModeSites = hostArray(src.focusModeSites);
    out.redirectSafeHosts = hostArray(src.redirectSafeHosts);
    out.siteAllows = (Array.isArray(src.siteAllows) ? src.siteAllows : []).map((a) => a && typeof a === "object" ? { site: normalizeHost(a.site), host: normalizeHost(a.host) } : null).filter((a) => a && a.site && a.host);
    out.customListUrls = [...new Set((Array.isArray(src.customListUrls) ? src.customListUrls : []).filter((u) => {
      try {
        return typeof u === "string" && new URL(u).protocol === "https:";
      } catch {
        return false;
      }
    }))];
    out.rulesets = {};
    if (src.rulesets && typeof src.rulesets === "object" && !Array.isArray(src.rulesets)) {
      for (const [id, on] of Object.entries(src.rulesets)) if (typeof on === "boolean") out.rulesets[id] = on;
    }
    return out;
  }

  // src/shared/filters/parser.js
  var ENV = {
    env_chromium: true,
    env_mv3: true,
    env_edge: false,
    env_firefox: false,
    env_legacy: false,
    env_mobile: false,
    env_safari: false,
    env_opera: false,
    ext_ublock: true,
    ext_abp: false,
    ext_devbuild: false,
    ext_ubol: true,
    cap_html_filtering: false,
    cap_user_stylesheet: true,
    cap_ipaddress: false,
    adguard: false,
    adguard_app_windows: false,
    adguard_app_mac: false,
    adguard_app_android: false,
    adguard_app_ios: false,
    adguard_ext_chromium: false,
    adguard_ext_firefox: false,
    adguard_ext_edge: false,
    adguard_ext_safari: false,
    adguard_ext_opera: false,
    adguard_ext_android_cb: false,
    false: false,
    true: true
  };
  function evalCondition(expr) {
    if (typeof expr !== "string" || expr.length > 500) return false;
    try {
      return evalTokens(expr);
    } catch {
      return false;
    }
  }
  function evalTokens(expr) {
    const tokens = expr.match(/!|&&|\|\||\(|\)|[\w-]+/g) || [];
    let i = 0;
    const peek = () => tokens[i];
    const next = () => tokens[i++];
    function primary() {
      const t = next();
      if (t === "!") return !primary();
      if (t === "(") {
        const v = orExpr();
        next();
        return v;
      }
      return ENV[t] === true;
    }
    function andExpr() {
      let v = primary();
      while (peek() === "&&") {
        next();
        const r = primary();
        v = v && r;
      }
      return v;
    }
    function orExpr() {
      let v = andExpr();
      while (peek() === "||") {
        next();
        const r = andExpr();
        v = v || r;
      }
      return v;
    }
    return orExpr();
  }
  function splitScriptletArgs(s) {
    const out = [];
    let i = 0;
    const n = s.length;
    while (i <= n) {
      while (i < n && s[i] === " ") i++;
      let arg = "";
      const q = s[i];
      if ((q === '"' || q === "'" || q === "`") && i < n) {
        let j2 = i + 1;
        let found = -1;
        while (j2 < n) {
          if (s[j2] === "\\") {
            j2 += 2;
            continue;
          }
          if (s[j2] === q) {
            let k = j2 + 1;
            while (k < n && s[k] === " ") k++;
            if (k === n || s[k] === ",") {
              found = j2;
              break;
            }
          }
          j2++;
        }
        if (found !== -1) {
          arg = s.slice(i + 1, found).replace(new RegExp("\\\\" + q, "g"), q);
          i = found + 1;
          while (i < n && s[i] === " ") i++;
          out.push(arg);
          i++;
          if (i > n) break;
          continue;
        }
      }
      let j = i;
      while (j < n) {
        if (s[j] === "\\" && s[j + 1] === ",") {
          arg += ",";
          j += 2;
          continue;
        }
        if (s[j] === ",") break;
        arg += s[j];
        j++;
      }
      out.push(arg.trim());
      i = j + 1;
      if (j >= n) break;
    }
    return out;
  }
  var COSMETIC_RE = /^([^#\s]*?)(#@?#|#@?\?#|#@?\$#|#@?\$\?#|#@?%#)(.*)$/;
  var HOSTS_RE = /^[\w.*~,\-\[\]\/:|%]*$/;
  function splitHosts(s) {
    const hosts = [];
    const notHosts = [];
    if (!s) return { hosts, notHosts };
    for (let h of s.split(",")) {
      h = h.trim().toLowerCase();
      if (!h) continue;
      if (h.startsWith("~")) notHosts.push(h.slice(1));
      else hosts.push(h);
    }
    return { hosts, notHosts };
  }
  function normalizeSelector(sel) {
    return sel.replace(/:-abp-has\(/g, ":has(").replace(/:-abp-contains\(/g, ":has-text(").replace(/:contains\(/g, ":has-text(").replace(/:-abp-properties\(/g, ":matches-css(");
  }
  function parseCosmetic(line, m) {
    const [, hostPart, sep, body] = m;
    if (!HOSTS_RE.test(hostPart)) return null;
    const exception = sep.includes("@");
    if (sep.includes("$") || sep.includes("%")) {
      return { kind: "unsupported", reason: "adguard-injection", raw: line };
    }
    const { hosts, notHosts } = splitHosts(hostPart);
    const text = body.trim();
    if (!text) return { kind: "unsupported", reason: "empty-selector", raw: line };
    if (text.startsWith("^")) return { kind: "unsupported", reason: "html-filter", raw: line };
    if (text.startsWith("+js(")) {
      if (!text.endsWith(")")) return { kind: "unsupported", reason: "bad-scriptlet", raw: line };
      const inner = text.slice(4, -1);
      if (inner.trim() === "") {
        return { kind: "scriptlet", exception, hosts, notHosts, name: "", args: [], raw: line };
      }
      const parts = splitScriptletArgs(inner);
      let name = parts.shift().trim();
      if (name.endsWith(".js")) name = name.slice(0, -3);
      return { kind: "scriptlet", exception, hosts, notHosts, name, args: parts, raw: line };
    }
    return {
      kind: "cosmetic",
      exception,
      hosts,
      notHosts,
      selector: normalizeSelector(text),
      raw: line
    };
  }
  function splitOptions(s) {
    const out = [];
    let cur = "";
    let inRegex = false;
    for (let i = 0; i < s.length; i++) {
      const c = s[i];
      if (!inRegex && c === "/" && (cur.endsWith("=") || cur.endsWith("|"))) inRegex = true;
      else if (inRegex && c === "/" && s[i - 1] !== "\\") inRegex = false;
      if (c === "," && !inRegex) {
        out.push(cur);
        cur = "";
        continue;
      }
      cur += c;
    }
    if (cur) out.push(cur);
    return out;
  }
  function parseNetwork(line) {
    let s = line;
    let exception = false;
    if (s.startsWith("@@")) {
      exception = true;
      s = s.slice(2);
    }
    let pattern = s;
    let optionText = "";
    let regexSplit = -1;
    if (s.startsWith("/")) {
      for (let p = s.indexOf("/$", 1); p !== -1; p = s.indexOf("/$", p + 1)) {
        if (/^~?[a-z][a-z0-9-]*(?:[=,]|$)/.test(s.slice(p + 2))) {
          regexSplit = p;
          break;
        }
      }
    }
    const isBareRegex = regexSplit === -1 && /^\/.+\/$/.test(s);
    if (regexSplit !== -1) {
      pattern = s.slice(0, regexSplit + 1);
      optionText = s.slice(regexSplit + 2);
    } else if (!isBareRegex) {
      const i = s.lastIndexOf("$");
      if (i !== -1) {
        pattern = s.slice(0, i);
        optionText = s.slice(i + 1);
      }
    }
    const options = [];
    if (optionText) {
      for (const raw of splitOptions(optionText)) {
        const o = raw.trim();
        if (!o) continue;
        const eq = o.indexOf("=");
        let name = eq === -1 ? o : o.slice(0, eq);
        const value = eq === -1 ? null : o.slice(eq + 1);
        let negated = false;
        if (name.startsWith("~")) {
          negated = true;
          name = name.slice(1);
        }
        options.push({ name: name.toLowerCase(), value, negated });
      }
    }
    return { kind: "network", exception, pattern, options, raw: line };
  }
  function parseList(text) {
    const entries = [];
    const lines = text.split(/\r?\n/);
    const stack = [];
    const active = () => stack.every(Boolean);
    for (let raw of lines) {
      const line = raw.trim();
      if (!line) continue;
      if (line.startsWith("!#if ")) {
        stack.push(evalCondition(line.slice(5)));
        continue;
      }
      if (line.startsWith("!#else")) {
        if (stack.length) stack[stack.length - 1] = !stack[stack.length - 1];
        continue;
      }
      if (line.startsWith("!#endif")) {
        stack.pop();
        continue;
      }
      if (line.startsWith("!") || line.startsWith("[")) continue;
      if (!active()) continue;
      const hostsLine = /^(?:0\.0\.0\.0|127\.0\.0\.1|::1?)\s+([\w.-]+)/.exec(line);
      if (hostsLine) {
        if (hostsLine[1] !== "localhost" && hostsLine[1].includes(".")) {
          entries.push({ kind: "network", exception: false, pattern: `||${hostsLine[1]}^`, options: [], raw: line });
        }
        continue;
      }
      if (line.includes("$$") || line.includes("$@$")) {
        entries.push({ kind: "unsupported", reason: "html-filter", raw: line });
        continue;
      }
      const m = COSMETIC_RE.exec(line);
      if (m && m[1].startsWith("/")) {
        entries.push({ kind: "unsupported", reason: "regex-host", raw: line });
        continue;
      }
      if (m) {
        const e = parseCosmetic(line, m);
        if (e) {
          entries.push(e);
          continue;
        }
      }
      entries.push(parseNetwork(line));
    }
    return entries;
  }

  // src/shared/filters/selector.js
  var PROCEDURAL_RE = /:(?:has-text|upward|xpath|matches-css(?:-before|-after)?|min-text-length|remove|remove-attr|remove-class|matches-attr|matches-path|matches-prop|watch-attr|others|if|if-not|nth-ancestor|matches-media)\(/;
  var STYLE_RE = /^(.*?):style\((.+)\)$/;
  var CSS_FUNCTIONS = /* @__PURE__ */ new Set([
    "not",
    "is",
    "where",
    "has",
    "nth-child",
    "nth-last-child",
    "nth-of-type",
    "nth-last-of-type",
    "lang",
    "dir",
    "-webkit-any",
    "host",
    "host-context",
    "slotted",
    "part",
    "state"
  ]);
  function walk(s, visit) {
    let paren = 0;
    const stack = [];
    let q = null;
    for (let i = 0; i < s.length; i++) {
      const c = s[i];
      if (c === "\n" || c === "\r" || c === "\f" || c === "\0") return false;
      if (c === "\\") {
        const next = s[i + 1];
        if (next === void 0 || next === "\n" || next === "\r" || next === "\f" || next === "\0") return false;
        i++;
        continue;
      }
      if (q) {
        if (c === q) q = null;
        continue;
      }
      if (c === '"' || c === "'") {
        q = c;
        continue;
      }
      if (c === "(" || c === "[") {
        stack.push(c === "(" ? ")" : "]");
        if (c === "(") paren++;
      } else if (c === ")" || c === "]") {
        if (stack.pop() !== c) return false;
        if (c === ")") paren--;
      }
      if (visit(c, paren, s, i) === false) return false;
    }
    return stack.length === 0 && !q;
  }
  function nestedOk(s) {
    const stack = [];
    for (const c of s) {
      if (c === "(" || c === "[") stack.push(c === "(" ? ")" : "]");
      else if ((c === ")" || c === "]") && stack.pop() !== c) return false;
    }
    return stack.length === 0;
  }
  function isSaneSelector(sel) {
    if (typeof sel !== "string" || !sel || sel.length > 1500) return false;
    if (sel.includes("</")) return false;
    return walk(sel, (c, depth, s, i) => {
      if (c === "/" && s[i + 1] === "*") return false;
      if (depth === 0 && (c === "{" || c === "}" || c === ";" || c === "@")) return false;
      return true;
    });
  }
  function isCssSafeSelector(sel) {
    if (!isSaneSelector(sel)) return false;
    let bracketDepth = 0;
    for (let i = 0, q = null; i < sel.length; i++) {
      const c = sel[i];
      if (c === "\\") {
        i++;
        continue;
      }
      if (q) {
        if (c === q) q = null;
        continue;
      }
      if (c === '"' || c === "'") {
        if (bracketDepth === 0) return false;
        q = c;
        continue;
      }
      if (c === "[") bracketDepth++;
      else if (c === "]") bracketDepth--;
      else if (c === "{" || c === "}" || c === ";" || c === "@" || c === "<") return false;
      else if (c === "(") {
        if (bracketDepth !== 0) return false;
        const m = /:([a-zA-Z-]+)$/.exec(sel.slice(0, i));
        if (!m || !CSS_FUNCTIONS.has(m[1].toLowerCase())) return false;
      }
    }
    return true;
  }
  function isSafeStyle(decl) {
    if (typeof decl !== "string" || !decl.trim() || decl.length > 1e3) return false;
    if (/[{}@\\<"'\n\r]|\/\*/.test(decl)) return false;
    if (!nestedOk(decl)) return false;
    return !/(?:url|image-set|image|-webkit-image-set|expression|element|src)\s*\(|-moz-binding/i.test(decl);
  }

  // src/shared/filters/lint.js
  var UNSUPPORTED = {
    "adguard-injection": "AdGuard CSS/JS injection rules are not supported",
    "html-filter": "HTML filters cannot work in Chrome (Manifest V3)",
    "regex-host": "Regex site patterns are not supported for element hiding",
    "empty-selector": "Empty selector",
    "bad-scriptlet": 'Broken scriptlet filter (missing ")")'
  };
  function networkReason(skip) {
    if (skip.startsWith("option:")) return `Option $${skip.slice(7)} is not supported`;
    if (skip.startsWith("redirect-resource:")) return `Unknown $redirect resource "${skip.slice(18)}"`;
    switch (skip) {
      case "too-broad":
        return "Too broad: it would block every site. Add a domain, path or resource type";
      case "popup":
        return "$popup is not supported in My filters (the pop-up guard handles pop-ups)";
      case "no-types":
        return "Every resource type is excluded, so it can never match";
      case "badfilter":
        return "$badfilter only works inside the built-in lists";
      case "cosmetic-opt-on-block":
        return "$generichide / $elemhide only work on @@ exception rules";
      case "cosmetic-opt-no-host":
        return "$generichide / $elemhide need a domain";
      case "csp-exception":
        return "$csp exceptions are not supported";
      case "entity-only":
        return "Wildcard domains (example.*) are not supported in network rules";
      case "regex-unsupported":
      case "re2":
        return "Chrome cannot run this regular expression (RE2 syntax only)";
      default:
        if (skip.startsWith("removeparam")) return "This $removeparam form is not supported";
        if (skip.startsWith("bad-")) return `Invalid $${skip.slice(4)}= value`;
        return `Not supported (${skip})`;
    }
  }
  function cosmeticReason(e) {
    const sel = e.selector.trim();
    if (!isSaneSelector(sel)) return "Invalid selector";
    const style = STYLE_RE.exec(sel);
    if (style) {
      if (PROCEDURAL_RE.test(style[1]) || !isCssSafeSelector(style[1])) return ":style() needs a plain CSS selector";
      if (!isSafeStyle(style[2])) return ":style() declarations may not load resources or contain { } @ \\ quotes";
      if (!e.exception && e.hosts.length === 0) return ":style() filters need a site (example.com##\u2026)";
      return null;
    }
    if (PROCEDURAL_RE.test(sel)) {
      if (!e.exception && e.hosts.length === 0) return "Procedural filters need a site (example.com##\u2026)";
      return null;
    }
    if (!isCssSafeSelector(sel)) return "Selector not accepted (unsupported function or characters)";
    return null;
  }
  function lintFilters(text, max = 200) {
    const problems = [];
    let checked = 0;
    const lines = String(text || "").split(/\r?\n/);
    for (let i = 0; i < lines.length; i++) {
      const raw = lines[i].trim();
      if (!raw || raw.startsWith("!") || raw.startsWith("[")) continue;
      checked++;
      let reason = null;
      if (raw.length > 4096) {
        reason = "Line is too long";
      } else {
        const [e] = parseList(raw);
        if (!e) continue;
        if (e.kind === "unsupported") reason = UNSUPPORTED[e.reason] || `Not supported (${e.reason})`;
        else if (e.kind === "scriptlet") reason = "Scriptlets (##+js) only run from the built-in lists, not from My filters";
        else if (e.kind === "cosmetic") reason = cosmeticReason(e);
        else if (e.kind === "network") {
          const res = convertNetwork(e);
          if (res.skip) reason = networkReason(res.skip);
        }
      }
      if (reason) {
        problems.push({ line: i + 1, text: raw.length > 200 ? raw.slice(0, 200) + "\u2026" : raw, reason });
        if (problems.length >= max) break;
      }
    }
    return { checked, problems };
  }

  // src/ui/options.js
  var $ = (id) => document.getElementById(id);
  var send = (msg) => chrome.runtime.sendMessage(msg);
  var settings = null;
  var lastSubs = {};
  var loadedFilters = "";
  var filtersChangedElsewhere = false;
  function el(tag, cls, text) {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== void 0) e.textContent = text;
    return e;
  }
  function toast(text) {
    const t = $("toast");
    t.textContent = text;
    t.classList.add("show");
    setTimeout(() => t.classList.remove("show"), 1800);
  }
  async function loadSettings() {
    const stored = await chrome.storage.local.get(Object.keys(DEFAULT_SETTINGS));
    settings = normalizeSettings(stored);
  }
  async function save(patch, message = "Saved") {
    Object.assign(settings, patch);
    await chrome.storage.local.set(patch);
    toast(message);
  }
  function hostLines(text) {
    return [...new Set(text.split("\n").map(normalizeHost).filter(Boolean))];
  }
  function switchRow(label, desc, checked, onChange) {
    const row = el("div", "row");
    const text = el("div", "row-text", label);
    if (desc) text.append(el("small", "", desc));
    const sw = el("label", "switch");
    const input = el("input");
    input.type = "checkbox";
    input.setAttribute("aria-label", label);
    input.checked = checked;
    input.addEventListener("change", () => onChange(input.checked));
    sw.append(input, el("span", "slider"));
    row.append(text, sw);
    return row;
  }
  async function renderLists() {
    const st = await send({ type: "options:state" });
    if (!st) return;
    const rows = $("rulesetRows");
    rows.replaceChildren();
    const errors = new Map((st.errors || []).map((e) => [e.id, e.error]));
    let enabledRules = 0;
    for (const m of st.index) {
      const on = settings.rulesets[m.id] ?? m.enabled;
      if (on) enabledRules += m.rules;
      const desc = `${m.description} \xB7 ${m.rules.toLocaleString()} network rules` + (m.scriptlets ? ` \xB7 ${m.scriptlets.toLocaleString()} scriptlets` : "") + (m.cosmetic && m.cosmetic.specificHosts ? ` \xB7 cosmetic rules for ${m.cosmetic.specificHosts.toLocaleString()} site${m.cosmetic.specificHosts === 1 ? "" : "s"}` : "");
      const row = switchRow(m.name, desc, on, async (v) => {
        await save({ rulesets: { ...settings.rulesets, [m.id]: v } }, v ? `${m.name} enabled` : `${m.name} disabled`);
        setTimeout(renderLists, 800);
      });
      if (errors.has(m.id)) row.querySelector(".row-text").append(el("span", "badge err", "Could not enable: rule limit reached"));
      rows.append(row);
    }
    const guaranteed = 3e4;
    const pct = Math.min(100, Math.round(enabledRules / guaranteed * 100));
    $("budgetBar").style.width = `${pct}%`;
    $("budgetText").textContent = `${enabledRules.toLocaleString()} static rules enabled (Chrome guarantees ${guaranteed.toLocaleString()} per extension, more when available` + (st.availableStatic !== null ? `; ${st.availableStatic.toLocaleString()} more available now` : "") + `) \xB7 ${st.dynamicCount.toLocaleString()} / ${st.dynamicMax.toLocaleString()} custom rules.`;
    lastSubs = st.subscriptions || {};
    renderSubs(lastSubs);
  }
  function renderSubs(subs) {
    const table = $("subsTable");
    table.replaceChildren();
    if (settings.customListUrls.length === 0) {
      const tr = el("tr");
      const td = el("td", "muted", "No subscribed lists.");
      tr.append(td);
      table.append(tr);
      return;
    }
    for (const url of settings.customListUrls) {
      const s = subs[url];
      const tr = el("tr");
      const info = el("td");
      info.append(el("div", "mono", url));
      const meta = s ? s.error ? `Error: ${s.error}` : `Updated ${new Date(s.updated).toLocaleString()} \xB7 ${(s.size / 1024).toFixed(0)} KB` : "Not downloaded yet";
      info.append(el("small", s && s.error ? "badge err" : "muted", meta));
      const act = el("td");
      const rm = el("button", "btn small danger", "Remove");
      rm.addEventListener("click", async () => {
        await save({ customListUrls: settings.customListUrls.filter((u) => u !== url) }, "Removed");
        renderSubs(lastSubs);
        setTimeout(renderLists, 800);
      });
      act.append(rm);
      tr.append(info, act);
      table.append(tr);
    }
  }
  function renderSites() {
    const table = $("allowTable");
    table.replaceChildren();
    if (settings.allowlist.length === 0) {
      const tr = el("tr");
      tr.append(el("td", "muted", "No trusted sites."));
      table.append(tr);
    }
    for (const host of [...settings.allowlist].sort()) {
      const tr = el("tr");
      const act = el("td");
      const rm = el("button", "btn small danger", "Remove");
      rm.addEventListener("click", async () => {
        await save({ allowlist: settings.allowlist.filter((h) => h !== host) }, `${host} removed`);
        renderSites();
      });
      act.append(rm);
      tr.append(el("td", "mono", host), act);
      table.append(tr);
    }
    const sa = $("siteAllowTable");
    sa.replaceChildren();
    if (settings.siteAllows.length === 0) {
      const tr = el("tr");
      tr.append(el("td", "muted", "None."));
      sa.append(tr);
    }
    for (const a of settings.siteAllows) {
      const tr = el("tr");
      const act = el("td");
      const rm = el("button", "btn small danger", "Remove");
      rm.addEventListener("click", async () => {
        await save({ siteAllows: settings.siteAllows.filter((x) => !(x.site === a.site && x.host === a.host)) }, "Removed");
        renderSites();
      });
      act.append(rm);
      tr.append(el("td", "mono", `${a.host} on ${a.site}`), act);
      sa.append(tr);
    }
  }
  function renderForms() {
    $("customFilters").value = settings.customFilters;
    loadedFilters = settings.customFilters;
    filtersChangedElsewhere = false;
    $("redirectMode").value = settings.redirectMode;
    $("showBlockNotices").checked = settings.showBlockNotices;
    $("redirectSafeHosts").value = settings.redirectSafeHosts.join("\n");
    $("focusModeSites").value = settings.focusModeSites.join("\n");
    for (const id of ["gpc", "stripTrackingParams", "autoUpdate"]) $(id).checked = settings[id];
  }
  function wire() {
    for (const b of document.querySelectorAll("#nav button")) {
      b.addEventListener("click", () => {
        document.querySelectorAll("#nav button").forEach((x) => {
          x.classList.toggle("active", x === b);
          if (x === b) x.setAttribute("aria-current", "true");
          else x.removeAttribute("aria-current");
        });
        document.querySelectorAll("[data-panel]").forEach((p) => p.classList.toggle("hidden", p.dataset.panel !== b.dataset.tab));
      });
    }
    $("saveCustom").addEventListener("click", async () => {
      if (filtersChangedElsewhere) {
        toast("Filters were changed in another tab \u2014 reload this page first");
        return;
      }
      await save({ customFilters: $("customFilters").value }, "Filters applied");
      loadedFilters = $("customFilters").value;
      showLint(loadedFilters);
      setTimeout(async () => {
        const st = await send({ type: "options:state" });
        if (st) $("customStatus").textContent = `${st.customCount.toLocaleString()} custom network rules active`;
      }, 1e3);
    });
    $("importFilters").addEventListener("click", () => $("importFiltersFile").click());
    $("importFiltersFile").addEventListener("change", async (e) => {
      const f = e.target.files[0];
      e.target.value = "";
      if (f) await importFilterFile(f);
    });
    $("exportFilters").addEventListener("click", () => {
      const text = $("customFilters").value;
      if (!text.trim()) {
        toast("You have no filters to export yet");
        return;
      }
      const blob = new Blob([`! DevShield: My filters
! Exported ${(/* @__PURE__ */ new Date()).toISOString()}
${text}
`], { type: "text/plain" });
      const a = el("a");
      a.href = URL.createObjectURL(blob);
      a.download = `devshield-my-filters-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.txt`;
      a.click();
      setTimeout(() => URL.revokeObjectURL(a.href), 1e3);
    });
    $("addSub").addEventListener("click", async () => {
      const url = $("subUrl").value.trim();
      try {
        if (new URL(url).protocol !== "https:") throw new Error();
      } catch {
        toast("Enter an https:// URL");
        return;
      }
      if (!settings.customListUrls.includes(url)) await save({ customListUrls: [...settings.customListUrls, url] }, "Downloading\u2026");
      $("subUrl").value = "";
      await send({ type: "lists:update" });
      toast("List updated");
      renderLists();
    });
    $("updateSubs").addEventListener("click", async () => {
      toast("Updating\u2026");
      await send({ type: "lists:update" });
      toast("Lists updated");
      renderLists();
    });
    $("addAllow").addEventListener("click", async () => {
      const v = normalizeHost($("allowInput").value);
      if (!v || !v.includes(".")) {
        toast("Enter a domain like example.com");
        return;
      }
      if (!settings.allowlist.includes(v)) await save({ allowlist: [...settings.allowlist, v] }, `${v} trusted`);
      $("allowInput").value = "";
      renderSites();
    });
    $("saveRedirects").addEventListener("click", () => save({
      redirectMode: $("redirectMode").value,
      redirectSafeHosts: hostLines($("redirectSafeHosts").value),
      focusModeSites: hostLines($("focusModeSites").value)
    }).then(renderForms));
    $("redirectMode").addEventListener("change", () => save({ redirectMode: $("redirectMode").value }));
    $("showBlockNotices").addEventListener("change", (e) => save({ showBlockNotices: e.target.checked }));
    for (const id of ["gpc", "stripTrackingParams", "autoUpdate"]) {
      $(id).addEventListener("change", (e) => save({ [id]: e.target.checked }));
    }
    $("shortcutsBtn").addEventListener("click", () => {
      chrome.tabs.create({ url: "chrome://extensions/shortcuts" }).catch(() => {
      });
    });
    chrome.commands.getAll().then((cmds) => {
      const set = cmds.filter((c) => c.shortcut).map((c) => `${c.shortcut}: ${c.description}`);
      if (set.length) $("shortcutText").textContent = `${set.join(" \xB7 ")}. Other actions (on/off everywhere, block element) can be given a shortcut too.`;
    }).catch(() => {
    });
    $("exportBtn").addEventListener("click", () => {
      const blob = new Blob([JSON.stringify({ devshield: 3, settings }, null, 2)], { type: "application/json" });
      const a = el("a");
      a.href = URL.createObjectURL(blob);
      a.download = `devshield-settings-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.json`;
      a.click();
      setTimeout(() => URL.revokeObjectURL(a.href), 1e3);
    });
    $("importBtn").addEventListener("click", () => $("importFile").click());
    $("importFile").addEventListener("change", async (e) => {
      const f = e.target.files[0];
      if (!f) return;
      try {
        const data = JSON.parse(await f.text());
        const incoming = data && data.settings;
        if (!incoming || typeof incoming !== "object" || Array.isArray(incoming)) throw new Error();
        const shapeOk = (k, v) => {
          const d = DEFAULT_SETTINGS[k];
          if (Array.isArray(d)) return Array.isArray(v);
          if (d && typeof d === "object") return !!v && typeof v === "object" && !Array.isArray(v);
          return typeof v === typeof d;
        };
        const merged = { ...settings };
        for (const k of Object.keys(DEFAULT_SETTINGS)) if (k in incoming && shapeOk(k, incoming[k])) merged[k] = incoming[k];
        const clean = normalizeSettings(merged);
        const patch = {};
        for (const k of Object.keys(DEFAULT_SETTINGS)) if (k in incoming) patch[k] = clean[k];
        await save(patch, "Settings imported");
        renderAll();
      } catch {
        toast("Not a DevShield settings file");
      }
    });
    $("resetStats").addEventListener("click", async () => {
      await send({ type: "stats:reset" });
      toast("Statistics reset");
    });
    $("resetAll").addEventListener("click", async () => {
      if (!confirm("Reset all DevShield settings?")) return;
      await chrome.storage.local.set({ ...DEFAULT_SETTINGS });
      const all = await chrome.storage.local.get(null);
      const stale = Object.keys(all).filter((k) => k.startsWith("subText:") || k === "subscriptions" || k === "rulesetErrors");
      if (stale.length) await chrome.storage.local.remove(stale);
      settings = { ...DEFAULT_SETTINGS };
      renderAll();
      toast("Defaults restored");
    });
  }
  function parseFilterImport(text) {
    const out = { filters: [], trusted: [] };
    const addTrusted = (entries) => {
      for (const e of entries) {
        const v = normalizeHost(String(e || "").trim().replace(/^\*\./, "").replace(/\/.*$/, ""));
        if (v && v.includes(".")) out.trusted.push(v);
      }
    };
    const trimmed = text.replace(/^\uFEFF/, "").trim();
    let lines = null;
    if (trimmed.startsWith("{")) {
      const data = JSON.parse(trimmed);
      if (data && typeof data.userFilters === "string") {
        lines = data.userFilters.split(/\r?\n/);
        const wl = Array.isArray(data.whitelist) ? data.whitelist : typeof data.netWhitelist === "string" ? data.netWhitelist.split(/\r?\n/) : [];
        addTrusted(wl.filter((w) => typeof w === "string" && !w.startsWith("#") && !w.includes("-scheme")));
      } else if (data && data.filters && typeof data.filters === "object") {
        const uf = data.filters["user-filter"];
        if (uf && typeof uf.rules === "string") lines = uf.rules.split(/\r?\n/);
        const al = data.filters.allowlist;
        if (al && Array.isArray(al.domains)) addTrusted(al.domains);
      }
      if (!lines && !out.trusted.length) throw new Error("unknown-json");
    } else {
      lines = trimmed.split(/\r?\n/);
    }
    for (const raw of lines || []) {
      const l = raw.trim();
      if (!l || l.startsWith("!") || /^\[adblock/i.test(l) || l.length > 4096) continue;
      out.filters.push(l);
    }
    out.filters = [...new Set(out.filters)];
    out.trusted = [...new Set(out.trusted)];
    return out;
  }
  async function importFilterFile(file) {
    if (file.size > 4 * 1024 * 1024) {
      toast("That file is too large (4 MB max)");
      return;
    }
    if (filtersChangedElsewhere || $("customFilters").value !== loadedFilters) {
      toast("Apply or reload your current filters first");
      return;
    }
    let parsed;
    try {
      parsed = parseFilterImport(await file.text());
    } catch {
      toast("Not a filter list or a uBlock Origin / AdGuard backup");
      return;
    }
    const current = settings.customFilters ? settings.customFilters.replace(/\n+$/, "").split("\n") : [];
    const have = new Set(current.map((l) => l.trim()));
    const fresh = parsed.filters.filter((l) => !have.has(l));
    const patch = {};
    if (fresh.length) {
      const name = file.name.replace(/[\r\n]/g, " ").slice(0, 80);
      const header = `! Imported from ${name} on ${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}`;
      patch.customFilters = [...current, ...current.length ? [""] : [], header, ...fresh].join("\n");
    }
    const newTrusted = parsed.trusted.filter((h) => !settings.allowlist.includes(h));
    if (newTrusted.length) patch.allowlist = [...settings.allowlist, ...newTrusted];
    if (!Object.keys(patch).length) {
      toast(parsed.filters.length || parsed.trusted.length ? "Nothing new: you already have all of these" : "No filters found in that file");
      return;
    }
    const parts = [];
    if (fresh.length) parts.push(`${fresh.length.toLocaleString()} filter${fresh.length === 1 ? "" : "s"}`);
    if (newTrusted.length) parts.push(`${newTrusted.length} trusted site${newTrusted.length === 1 ? "" : "s"}`);
    const summary = `Imported ${parts.join(" and ")}`;
    await save(patch, summary);
    renderForms();
    showLint(settings.customFilters);
    renderSites();
    $("customStatus").textContent = `${summary}.`;
    setTimeout(async () => {
      const st = await send({ type: "options:state" });
      if (st) $("customStatus").textContent = `${summary} \xB7 ${st.customCount.toLocaleString()} custom network rules active`;
    }, 1500);
  }
  function showLint(text) {
    const { problems } = lintFilters(text);
    const box = $("lint");
    box.classList.toggle("hidden", problems.length === 0);
    if (problems.length === 0) return;
    $("lintSummary").textContent = `${problems.length >= 200 ? "200+" : problems.length} filter${problems.length === 1 ? "" : "s"} cannot be applied: show why`;
    const list = $("lintList");
    list.replaceChildren();
    for (const p of problems) {
      const li = el("li");
      li.append(el("span", "ln", `Line ${p.line}`), el("span", "src", p.text), el("span", "why", p.reason));
      list.append(li);
    }
  }
  function renderAll() {
    renderForms();
    renderSites();
    renderLists();
    showLint(settings.customFilters);
  }
  document.addEventListener("DOMContentLoaded", async () => {
    await loadSettings();
    wire();
    renderAll();
    let refreshTimer = 0;
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local" || !Object.keys(changes).some((k) => k in DEFAULT_SETTINGS)) return;
      clearTimeout(refreshTimer);
      refreshTimer = setTimeout(async () => {
        await loadSettings();
        renderSites();
        renderSubs(lastSubs);
        $("redirectMode").value = settings.redirectMode;
        $("showBlockNotices").checked = settings.showBlockNotices;
        for (const id of ["gpc", "stripTrackingParams", "autoUpdate"]) $(id).checked = settings[id];
        if (settings.customFilters !== loadedFilters) {
          if ($("customFilters").value === loadedFilters) {
            $("customFilters").value = settings.customFilters;
            loadedFilters = settings.customFilters;
            filtersChangedElsewhere = false;
          } else {
            filtersChangedElsewhere = true;
            $("customStatus").textContent = "Changed in another tab \u2014 reload to see the latest filters.";
          }
        }
      }, 200);
    });
  });
})();
