(() => {
  // src/ui/popup.js
  var $ = (id) => document.getElementById(id);
  var send = (msg) => chrome.runtime.sendMessage(msg);
  var KIND_LABEL = {
    popup: "Pop-up",
    popunder: "Pop-under",
    redirect: "Redirect",
    form: "Form",
    "tab-closed": "Tab closed",
    "link-hijack": "Link swap"
  };
  var FILTERS = {
    all: () => true,
    popup: (k) => k === "popup" || k === "popunder",
    redirect: (k) => k === "redirect" || k === "form" || k === "link-hijack",
    "tab-closed": (k) => k === "tab-closed"
  };
  var state = null;
  var filter = "all";
  function el(tag, cls, text) {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== void 0) e.textContent = text;
    return e;
  }
  function fmt(n) {
    if (n >= 1e6) return (n / 1e6).toFixed(1) + "M";
    if (n >= 1e4) return (n / 1e3).toFixed(1) + "k";
    return String(n);
  }
  function timeAgo(t) {
    const s = Math.round((Date.now() - t) / 1e3);
    if (s < 60) return `${s}s ago`;
    if (s < 3600) return `${Math.round(s / 60)}m ago`;
    if (s < 86400) return `${Math.round(s / 3600)}h ago`;
    return new Date(t).toLocaleDateString();
  }
  function renderStatus() {
    const on = state.settings.shieldEnabled;
    $("shieldToggle").checked = on;
    $("status").classList.toggle("on", on);
    $("statusTitle").textContent = on ? "PROTECTION ON" : "PROTECTION OFF";
    const paused = !on && state.pauseUntil > Date.now();
    const until = paused ? new Date(state.pauseUntil).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) : "";
    $("statusSub").textContent = on ? "Ads, trackers and pop-ups are blocked" : paused ? `Paused until ${until}` : "DevShield is paused everywhere";
    $("pauseLabel").textContent = paused ? `Resumes at ${until}` : on ? "Pause everywhere:" : "Turn on to block again";
    for (const b of document.querySelectorAll("[data-pause]")) b.classList.toggle("hidden", !on);
    $("resumeBtn").classList.toggle("hidden", on);
  }
  function renderSite() {
    const tab = state.tab;
    if (!tab || !tab.web) {
      $("siteHost").textContent = "Browser page";
      $("siteLabel").textContent = "DevShield does not run on browser pages.";
      $("siteToggle").disabled = true;
      $("pickBtn").disabled = true;
      return;
    }
    $("siteHost").textContent = tab.host;
    $("siteToggle").checked = !tab.allowlisted;
    $("siteToggle").disabled = !state.settings.shieldEnabled;
    $("siteLabel").textContent = tab.allowlisted ? `Protection is off for ${tab.site} (trusted)` : `Protection is on for ${tab.site}`;
    $("pickBtn").disabled = tab.allowlisted || !state.settings.shieldEnabled;
  }
  function renderStats() {
    const s = state.tab && state.tab.stats || { ads: 0, trackers: 0, popups: 0, hidden: 0, hosts: [] };
    $("sAds").textContent = fmt(s.ads);
    $("sTrackers").textContent = fmt(s.trackers);
    $("sPopups").textContent = fmt(s.popups);
    $("sHidden").textContent = fmt(s.hidden);
    const l = state.lifetime;
    $("lifetime").textContent = `All time: ${fmt(l.ads)} ads \xB7 ${fmt(l.trackers)} trackers \xB7 ${fmt(l.popups)} pop-ups \xB7 ${fmt(l.ytAds)} YouTube ads`;
    const list = $("hostsList");
    list.replaceChildren();
    $("hostsCount").textContent = s.hosts.length ? `${s.hosts.length} host${s.hosts.length === 1 ? "" : "s"}` : "";
    if (s.hosts.length === 0) {
      list.append(el("div", "empty", "Nothing blocked on this page yet."));
      return;
    }
    for (const [host, n] of s.hosts) {
      const item = el("div", "list-item");
      const main = el("div", "list-main");
      main.append(el("div", "list-title mono", host), el("div", "list-meta", `${n} request${n === 1 ? "" : "s"}`));
      const allow = el("button", "btn small", "Allow");
      allow.title = `Allow ${host} on ${state.tab.site}`;
      allow.addEventListener("click", async () => {
        allow.disabled = true;
        await send({ type: "popup:allow-host", site: state.tab.host, host });
        allow.textContent = "Allowed";
      });
      item.append(main, allow);
      list.append(item);
    }
  }
  function renderYouTube() {
    const tab = state.tab;
    const show = !!(tab && tab.youtube && !tab.allowlisted);
    $("ytCard").classList.toggle("hidden", !show);
    if (!show) return;
    $("ytCount").textContent = tab.stats.ytAds ? `${tab.stats.ytAds} ad${tab.stats.ytAds === 1 ? "" : "s"} skipped` : "";
    $("ytShorts").checked = state.settings.ytHideShorts;
    $("ytUpsell").checked = state.settings.ytHidePremiumUpsell;
    $("ytWatchdog").checked = state.settings.ytSkipWatchdog;
  }
  function renderHistory() {
    const list = $("historyList");
    list.replaceChildren();
    const items = state.history.filter((h) => FILTERS[filter](h.kind));
    if (items.length === 0) {
      list.append(el("div", "empty", "No pop-ups or redirects blocked yet."));
      return;
    }
    for (const h of items.slice(0, 40)) {
      const item = el("div", "list-item");
      const main = el("div", "list-main");
      const title = el("div", "list-title", h.host || h.url || "(blank)");
      title.title = h.url;
      main.append(title, el("div", "list-meta", `${h.site ? "on " + h.site + " \xB7 " : ""}${timeAgo(h.time)}`));
      item.append(main, el("span", `pill ${h.kind}`, KIND_LABEL[h.kind] || h.kind));
      if (isOpenable(h.url)) item.append(openButton(h.url));
      list.append(item);
    }
  }
  function isOpenable(url) {
    try {
      return /^https?:$/.test(new URL(url).protocol);
    } catch {
      return false;
    }
  }
  function openButton(url) {
    const b = el("button", "btn small", "Open");
    b.title = `Open anyway: ${url}`;
    b.addEventListener("click", async () => {
      const opts = { url, active: true };
      if (state && state.tab && state.tab.index >= 0) opts.index = state.tab.index + 1;
      try {
        await chrome.tabs.create(opts);
      } catch {
        await chrome.tabs.create({ url }).catch(() => {
        });
      }
      window.close();
    });
    return b;
  }
  function render() {
    renderStatus();
    renderSite();
    renderStats();
    renderYouTube();
    renderHistory();
  }
  async function load() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    try {
      state = await send({ type: "popup:state", tabId: tab ? tab.id : -1 });
    } catch {
      state = null;
    }
    if (state && state.tab && tab) state.tab.index = tab.index;
    $("errorCard").classList.toggle("hidden", !!state);
    if (state) render();
  }
  async function showWelcome() {
    const { onboarded } = await chrome.storage.local.get("onboarded").catch(() => ({}));
    $("welcome").classList.toggle("hidden", !!onboarded);
  }
  function onKey(e) {
    if (e.ctrlKey || e.metaKey || e.altKey || e.repeat) return;
    if (e.target && /^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName) && e.target.type !== "checkbox") return;
    const key = e.key.toLowerCase();
    if (key === "s" && !$("siteToggle").disabled) {
      e.preventDefault();
      $("siteToggle").click();
    } else if (key === "b" && !$("pickBtn").disabled) {
      e.preventDefault();
      $("pickBtn").click();
    } else if (key === "o") {
      e.preventDefault();
      chrome.runtime.openOptionsPage();
    }
  }
  document.addEventListener("DOMContentLoaded", () => {
    $("version").textContent = "v" + chrome.runtime.getManifest().version;
    $("shieldToggle").addEventListener("change", async (e) => {
      await chrome.storage.local.set({ shieldEnabled: e.target.checked });
      if (!state) return load();
      state.settings.shieldEnabled = e.target.checked;
      if (e.target.checked) state.pauseUntil = 0;
      render();
    });
    for (const b of document.querySelectorAll("[data-pause]")) {
      b.addEventListener("click", async () => {
        const until = await send({ type: "popup:pause", minutes: Number(b.dataset.pause) });
        if (!state) return load();
        state.settings.shieldEnabled = false;
        state.pauseUntil = typeof until === "number" ? until : 0;
        render();
      });
    }
    $("resumeBtn").addEventListener("click", async () => {
      await send({ type: "popup:resume" });
      await load();
    });
    $("siteToggle").addEventListener("change", async () => {
      if (!state || !state.tab) return;
      await send({ type: "popup:toggle-site", host: state.tab.host, tabId: state.tab.id });
      await load();
    });
    $("pickBtn").addEventListener("click", async () => {
      if (!state || !state.tab) return;
      await send({ type: "popup:pick", tabId: state.tab.id });
      window.close();
    });
    for (const [id, key] of [["ytShorts", "ytHideShorts"], ["ytUpsell", "ytHidePremiumUpsell"], ["ytWatchdog", "ytSkipWatchdog"]]) {
      $(id).addEventListener("change", (e) => chrome.storage.local.set({ [key]: e.target.checked }));
    }
    $("clearHistory").addEventListener("click", async () => {
      await send({ type: "history:clear" });
      if (!state) return;
      state.history = [];
      renderHistory();
    });
    for (const chip of document.querySelectorAll(".chip")) {
      chip.addEventListener("click", () => {
        filter = chip.dataset.filter;
        document.querySelectorAll(".chip").forEach((c) => c.classList.toggle("active", c === chip));
        renderHistory();
      });
    }
    const openOptions = (e) => {
      e.preventDefault();
      chrome.runtime.openOptionsPage();
    };
    $("openOptions").addEventListener("click", openOptions);
    $("optionsLink").addEventListener("click", openOptions);
    $("welcomeDone").addEventListener("click", async () => {
      $("welcome").classList.add("hidden");
      await chrome.storage.local.set({ onboarded: true });
    });
    $("retryBtn").addEventListener("click", () => load());
    document.addEventListener("keydown", onKey);
    showWelcome();
    load();
  });
})();
