(function () {
    window.canRunAds = true;
    window.isAdBlockActive = false;
})();
