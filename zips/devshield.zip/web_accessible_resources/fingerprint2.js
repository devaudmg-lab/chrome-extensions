// DevShield stand-in for fingerprintjs2: returns a random, per-load value so
// sites that require the library keep working without fingerprinting.
(function () {
    'use strict';
    const rand = () => Array.from(crypto.getRandomValues(new Uint8Array(16)), (b) => b.toString(16).padStart(2, '0')).join('');
    const Fingerprint2 = function () {};
    Fingerprint2.get = function (opts, cb) {
        const done = typeof opts === 'function' ? opts : cb;
        if (typeof done === 'function') setTimeout(() => done([]), 1);
    };
    Fingerprint2.getPromise = function () { return Promise.resolve([]); };
    Fingerprint2.getV18 = function (opts, cb) {
        const done = typeof opts === 'function' ? opts : cb;
        if (typeof done === 'function') setTimeout(() => done(rand(), []), 1);
    };
    Fingerprint2.x64hash128 = rand;
    Fingerprint2.VERSION = '2.1.0';
    Fingerprint2.prototype = { get(cb) { setTimeout(() => cb(rand(), []), 1); } };
    window.Fingerprint2 = Fingerprint2;
})();
