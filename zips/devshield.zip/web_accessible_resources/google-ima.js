// DevShield stand-in for the Google IMA SDK (ima3.js). Players that use it
// get an immediate AD_ERROR for every ad request and fall back to content.
(function () {
    'use strict';
    if (window.google && window.google.ima && window.google.ima.__devshield) return;
    const noop = function () {};

    class EventTarget_ {
        constructor() { this._l = new Map(); }
        addEventListener(type, fn) {
            for (const t of [].concat(type)) {
                if (!this._l.has(t)) this._l.set(t, []);
                this._l.get(t).push(fn);
            }
        }
        removeEventListener(type, fn) {
            for (const t of [].concat(type)) {
                const a = this._l.get(t);
                if (a) this._l.set(t, a.filter((f) => f !== fn));
            }
        }
        _emit(type, ev) {
            for (const fn of this._l.get(type) || []) {
                try { fn(ev); } catch (e) { /* ignore */ }
            }
        }
    }

    const AdErrorCodes = { VAST_EMPTY_RESPONSE: 1009, UNKNOWN_ERROR: 900 };
    class AdError {
        getErrorCode() { return AdErrorCodes.VAST_EMPTY_RESPONSE; }
        getVastErrorCode() { return 303; }
        getInnerError() { return null; }
        getMessage() { return 'No ads'; }
        getType() { return 'adLoadError'; }
        toString() { return 'AdError 1009: No ads'; }
    }
    class AdErrorEvent {
        constructor(ctx) { this._ctx = ctx; }
        getError() { return new AdError(); }
        getUserRequestContext() { return this._ctx || {}; }
    }
    AdErrorEvent.Type = { AD_ERROR: 'adError' };

    class AdsLoader extends EventTarget_ {
        constructor() { super(); this._settings = new ImaSdkSettings(); }
        contentComplete() {}
        destroy() {}
        getSettings() { return this._settings; }
        getVersion() { return '3.0.0'; }
        requestAds(request, ctx) {
            setTimeout(() => this._emit(AdErrorEvent.Type.AD_ERROR, new AdErrorEvent(ctx)), 0);
        }
    }
    class AdDisplayContainer { constructor() {} initialize() {} destroy() {} }
    class ImaSdkSettings {
        getCompanionBackfill() { return 'always'; }
        getDisableCustomPlaybackForIOS10Plus() { return false; }
        getFeatureFlags() { return {}; }
        getLocale() { return 'en'; }
        getNumRedirects() { return 1; }
        getPlayerType() { return ''; }
        getPlayerVersion() { return ''; }
        getPpid() { return ''; }
        isCookiesEnabled() { return false; }
        isVpaidAdapter() { return false; }
    }
    for (const m of ['setAutoPlayAdBreaks', 'setCompanionBackfill', 'setCookiesEnabled', 'setDisableCustomPlaybackForIOS10Plus',
        'setFeatureFlags', 'setLocale', 'setNumRedirects', 'setPageCorrelator', 'setPlayerType', 'setPlayerVersion',
        'setPpid', 'setSessionId', 'setVpaidAllowed', 'setVpaidMode']) ImaSdkSettings.prototype[m] = noop;
    ImaSdkSettings.CompanionBackfillMode = { ALWAYS: 'always', ON_MASTER_AD: 'on_master_ad' };
    ImaSdkSettings.VpaidMode = { DISABLED: 0, ENABLED: 1, INSECURE: 2 };

    class AdsRequest { constructor() {} setAdWillAutoPlay() {} setAdWillPlayMuted() {} setContinuousPlayback() {} }
    class AdsRenderingSettings { constructor() {} }
    class AdsManagerLoadedEvent { getAdsManager() { return null; } getUserRequestContext() { return {}; } }
    AdsManagerLoadedEvent.Type = { ADS_MANAGER_LOADED: 'adsManagerLoaded' };
    class AdEvent { getAd() { return null; } getAdData() { return {}; } }
    AdEvent.Type = {
        AD_BREAK_READY: 'adBreakReady', AD_BUFFERING: 'adBuffering', AD_CAN_PLAY: 'adCanPlay', AD_METADATA: 'adMetadata',
        ALL_ADS_COMPLETED: 'allAdsCompleted', CLICK: 'click', COMPLETE: 'complete', CONTENT_PAUSE_REQUESTED: 'contentPauseRequested',
        CONTENT_RESUME_REQUESTED: 'contentResumeRequested', DURATION_CHANGE: 'durationChange', FIRST_QUARTILE: 'firstQuartile',
        IMPRESSION: 'impression', LOADED: 'loaded', LOG: 'log', MIDPOINT: 'midpoint', PAUSED: 'pause', RESUMED: 'resume',
        SKIPPABLE_STATE_CHANGED: 'skippableStateChanged', SKIPPED: 'skip', STARTED: 'start', THIRD_QUARTILE: 'thirdQuartile',
        USER_CLOSE: 'userClose', VOLUME_CHANGED: 'volumeChange', VOLUME_MUTED: 'mute',
    };

    window.google = window.google || {};
    window.google.ima = {
        __devshield: true,
        AdDisplayContainer,
        AdError,
        AdErrorEvent,
        AdEvent,
        AdsLoader,
        AdsManagerLoadedEvent,
        AdsRenderingSettings,
        AdsRequest,
        ImaSdkSettings,
        settings: new ImaSdkSettings(),
        UiElements: { AD_ATTRIBUTION: 'adAttribution', COUNTDOWN: 'countdown' },
        ViewMode: { FULLSCREEN: 'fullscreen', NORMAL: 'normal' },
        OmidAccessMode: { DOMAIN: 'domain', FULL: 'full', LIMITED: 'limited' },
        CompanionAdSelectionSettings: function () {},
        VERSION: '3.0.0',
    };
})();
