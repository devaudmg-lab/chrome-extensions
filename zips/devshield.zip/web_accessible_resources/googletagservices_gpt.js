// DevShield stand-in for Google Publisher Tag (gpt.js): same API surface,
// no network, no ads. Queued googletag.cmd callbacks still run.
(function () {
    'use strict';
    const noop = function () {};
    const noopThis = function () { return this; };
    const noopNull = function () { return null; };
    const noopArray = function () { return []; };
    const noopStr = function () { return ''; };
    const assign = (proto, names, fn) => { for (const n of names) proto[n] = fn; };

    function PassbackSlot() {}
    assign(PassbackSlot.prototype, ['set', 'setClickUrl', 'setTagForChildDirectedTreatment', 'setTargeting', 'updateTargetingFromMap'], noopThis);
    PassbackSlot.prototype.display = noop;
    PassbackSlot.prototype.get = noopNull;

    function SizeMappingBuilder() {}
    SizeMappingBuilder.prototype.addSize = noopThis;
    SizeMappingBuilder.prototype.build = noopNull;

    function Slot() {}
    assign(Slot.prototype, ['addService', 'clearCategoryExclusions', 'clearTargeting', 'defineSizeMapping', 'set',
        'setCategoryExclusion', 'setClickUrl', 'setCollapseEmptyDiv', 'setForceSafeFrame', 'setSafeFrameConfig',
        'setTargeting', 'updateTargetingFromMap', 'setConfig'], noopThis);
    assign(Slot.prototype, ['get', 'getResponseInformation'], noopNull);
    assign(Slot.prototype, ['getAttributeKeys', 'getCategoryExclusions', 'getTargeting', 'getTargetingKeys', 'getSizes'], noopArray);
    assign(Slot.prototype, ['getAdUnitPath', 'getSlotElementId'], noopStr);

    const pubads = {};
    assign(pubads, ['addEventListener', 'removeEventListener', 'clearCategoryExclusions', 'clearTagForChildDirectedTreatment',
        'clearTargeting', 'set', 'setCategoryExclusion', 'setCookieOptions', 'setForceSafeFrame', 'setLocation',
        'setPublisherProvidedId', 'setPrivacySettings', 'setRequestNonPersonalizedAds', 'setSafeFrameConfig',
        'setTagForChildDirectedTreatment', 'setTargeting', 'setVideoContent', 'setConfig'], noopThis);
    assign(pubads, ['clear', 'collapseEmptyDivs', 'disableInitialLoad', 'display', 'enableAsyncRendering', 'enableLazyLoad',
        'enableSingleRequest', 'enableSyncRendering', 'enableVideoAds', 'refresh', 'setCentering', 'updateCorrelator'], noop);
    assign(pubads, ['getAttributeKeys', 'getTargeting', 'getTargetingKeys', 'getSlots'], noopArray);
    pubads.get = noopNull;
    pubads.isInitialLoadDisabled = function () { return true; };
    pubads.defineOutOfPagePassback = function () { return new PassbackSlot(); };
    pubads.definePassback = function () { return new PassbackSlot(); };

    const companionAds = { addEventListener: noopThis, enableSyncLoading: noop, setRefreshUnfilledSlots: noop };
    const content = { addEventListener: noopThis, setContent: noop };

    const gt = window.googletag instanceof Object ? window.googletag : {};
    const pending = Array.isArray(gt.cmd) ? gt.cmd.slice() : [];
    gt.apiReady = true;
    gt.pubadsReady = true;
    gt.cmd = [];
    gt.cmd.push = function (fn) {
        try { if (typeof fn === 'function') fn(); } catch (e) { /* page callback failed */ }
        return 1;
    };
    gt.companionAds = function () { return companionAds; };
    gt.content = function () { return content; };
    gt.pubads = function () { return pubads; };
    gt.defineOutOfPageSlot = function () { return new Slot(); };
    gt.defineSlot = function () { return new Slot(); };
    gt.sizeMapping = function () { return new SizeMappingBuilder(); };
    gt.destroySlots = noop;
    gt.disablePublisherConsole = noop;
    gt.display = noop;
    gt.enableServices = noop;
    gt.getVersion = noopStr;
    gt.setAdIframeTitle = noop;
    gt.setConfig = noop;
    gt.enums = { OutOfPageFormat: {} };
    gt.secureSignalProviders = { push: noop, clearAllCache: noop };
    window.googletag = gt;
    for (const fn of pending) gt.cmd.push(fn);
})();
