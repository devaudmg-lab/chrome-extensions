// DevShield stand-in for Amazon's amzn_ads.js.
(function () {
    'use strict';
    const noop = function () {};
    const amznads = {
        appendScriptTag: noop,
        appendTargetingToAdServerUrl: noop,
        appendTargetingToQueryString: noop,
        clearTargetingFromGPTAsync: noop,
        doAllTasks: noop,
        doGetAdsAsync: noop,
        doTask: noop,
        detectIframeAndGetURL: noop,
        getAds: noop,
        getAdsAsync: noop,
        getAdForSlot: noop,
        getAdsCallback: function (name, cb) { if (typeof cb === 'function') { try { cb(); } catch (e) { /* ignore */ } } },
        getDisplayAds: noop,
        getDisplayAdsAsync: noop,
        getDisplayAdsCallback: noop,
        getKeys: noop,
        getReferrerURL: noop,
        getScriptSource: noop,
        getTargeting: function () { return {}; },
        getTokens: noop,
        getValidMilliseconds: noop,
        getVideoAds: noop,
        getVideoAdsAsync: noop,
        getVideoAdsCallback: noop,
        handleCallBack: noop,
        hasAds: function () { return false; },
        renderAd: noop,
        saveAds: noop,
        setTargeting: noop,
        setTargetingForGPTAsync: noop,
        setTargetingForGPTSync: noop,
        tryGetAdsAsync: noop,
        updateAds: noop,
    };
    window.amznads = amznads;
    window.amzn_ads = window.amzn_ads || noop;
    window.aax_getad_mpb = window.aax_getad_mpb || noop;
    window.aax_write = window.aax_write || noop;
    window.aax_render_ad = window.aax_render_ad || noop;
})();
