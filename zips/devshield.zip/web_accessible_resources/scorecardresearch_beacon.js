(function () {
    window.COMSCORE = { purge() {}, beacon() {} };
})();
