// DevShield stand-in for legacy ga.js (_gaq / _gat).
(function () {
    'use strict';
    const noop = function () {};
    const tracker = new Proxy({}, { get: () => noop });
    const run = (item) => {
        if (typeof item === 'function') {
            try { item(); } catch (e) { /* ignore */ }
        } else if (Array.isArray(item) && item[0] === '_set' && item[1] === 'hitCallback' && typeof item[2] === 'function') {
            try { item[2](); } catch (e) { /* ignore */ }
        }
    };
    const old = Array.isArray(window._gaq) ? window._gaq.slice() : [];
    window._gaq = { push: function () { for (const a of arguments) run(a); return 0; } };
    window._gat = { _createTracker: () => tracker, _getTracker: () => tracker, _getTrackerByName: () => tracker, _anonymizeIp: noop };
    for (const a of old) run(a);
})();
