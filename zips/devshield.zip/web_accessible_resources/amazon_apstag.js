// DevShield stand-in for Amazon Publisher Services apstag.js: bids resolve
// empty so header-bidding wrappers stop waiting and render content.
(function () {
    'use strict';
    const noop = function () {};
    const apstag = {
        debug: noop,
        deleteId: noop,
        init: noop,
        punt: noop,
        renderImp: noop,
        rpa: noop,
        setDisplayBids: noop,
        targetingKeys: function () { return []; },
        thirdPartyData: {},
        upa: noop,
        updateId: noop,
        fetchBids: function (cfg, cb) {
            if (typeof cb === 'function') setTimeout(() => { try { cb([]); } catch (e) { /* ignore */ } }, 1);
        },
    };
    const q = window.apstag && Array.isArray(window.apstag._Q) ? window.apstag._Q : [];
    window.apstag = apstag;
    for (const [fn, args] of q) {
        if (typeof apstag[fn] === 'function') {
            try { apstag[fn].apply(apstag, args); } catch (e) { /* ignore */ }
        }
    }
})();
