// DevShield stand-in for analytics.js / gtm.js: nothing is sent, but
// hitCallback / eventCallback functions still fire so pages that wait for
// them (e.g. outbound-link handlers) keep working.
(function () {
    'use strict';
    const noop = function () {};
    function Tracker() {}
    Tracker.prototype.get = noop;
    Tracker.prototype.set = noop;
    Tracker.prototype.send = noop;

    const w = window;
    const name = w.GoogleAnalyticsObject || 'ga';
    const queued = w[name];
    const ga = function () {
        const args = Array.prototype.slice.call(arguments);
        if (args.length === 0) return;
        const last = args[args.length - 1];
        let cb = null;
        if (last instanceof Object && typeof last.hitCallback === 'function') cb = last.hitCallback;
        else if (typeof last === 'function') cb = function () { last(ga.create()); };
        else {
            const i = args.indexOf('hitCallback');
            if (i !== -1 && typeof args[i + 1] === 'function') cb = args[i + 1];
        }
        if (cb) {
            try { cb(); } catch (e) { /* ignore */ }
        }
    };
    ga.create = function () { return new Tracker(); };
    ga.getByName = function () { return new Tracker(); };
    ga.getAll = function () { return [new Tracker()]; };
    ga.remove = noop;
    ga.loaded = true;
    w[name] = ga;

    const dl = w.dataLayer;
    if (dl instanceof Object) {
        if (dl.hide instanceof Object && typeof dl.hide.end === 'function') {
            dl.hide.end();
            dl.hide.end = noop;
        }
        const fire = (item) => {
            if (item instanceof Object && typeof item.eventCallback === 'function') {
                setTimeout(item.eventCallback, 1);
                item.eventCallback = noop;
            }
        };
        if (typeof dl.push === 'function') {
            const push = dl.push;
            dl.push = function () {
                for (const item of arguments) fire(item);
                return push.apply(this, arguments);
            };
        }
        if (Array.isArray(dl)) for (const item of dl.slice()) fire(item);
    }
    if (typeof queued === 'function' && Array.isArray(queued.q)) {
        const q = queued.q.slice();
        queued.q.length = 0;
        for (const entry of q) ga.apply(null, entry);
    }
})();
