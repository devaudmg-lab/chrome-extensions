// DevShield stand-in for FingerprintJS v3: a random visitorId per load.
(function () {
    'use strict';
    const rand = () => Array.from(crypto.getRandomValues(new Uint8Array(16)), (b) => b.toString(16).padStart(2, '0')).join('');
    const agent = { get: () => Promise.resolve({ visitorId: rand(), confidence: { score: 0 }, components: {}, version: '3.4.2' }) };
    window.FingerprintJS = {
        load: () => Promise.resolve(agent),
        hashComponents: rand,
        componentsToDebugString: () => '',
    };
})();
