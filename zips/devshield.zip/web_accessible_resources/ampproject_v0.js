(function () {
    // AMP pages hide <body> until the runtime loads; reveal it.
    const style = document.createElement("style");
    style.textContent = "body{animation:none!important;visibility:visible!important;opacity:1!important}";
    (document.head || document.documentElement).appendChild(style);
})();
