// DevShield stand-in for AdSense adsbygoogle.js: pages that check
// `adsbygoogle.loaded` see a loaded library, and <ins> slots are marked done.
(function () {
    'use strict';
    const markSlots = () => {
        for (const ins of document.querySelectorAll('ins.adsbygoogle')) {
            if (ins.hasAttribute('data-adsbygoogle-status')) continue;
            ins.setAttribute('data-adsbygoogle-status', 'done');
            ins.setAttribute('data-ad-status', 'unfilled');
        }
    };
    window.adsbygoogle = {
        loaded: true,
        push: function () { markSlots(); },
    };
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', markSlots, { once: true });
    else markSlots();
})();
