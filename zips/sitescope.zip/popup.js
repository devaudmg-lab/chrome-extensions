// SiteScope Popup Controller Script

document.addEventListener('DOMContentLoaded', async () => {
  // Elements
  const keywordInput = document.getElementById('keywordInput');
  const caseSensitiveCheckbox = document.getElementById('caseSensitiveCheckbox');
  const robotsCheckbox = document.getElementById('robotsCheckbox');
  const sitemapCheckbox = document.getElementById('sitemapCheckbox');
  const jsRenderingCheckbox = document.getElementById('jsRenderingCheckbox');
  const matchModeSelect = document.getElementById('matchModeSelect');
  const scanScopeSelect = document.getElementById('scanScopeSelect');
  const maxPagesInput = document.getElementById('maxPagesInput');
  const maxPagesGroup = document.getElementById('maxPagesGroup');
  const startBtn = document.getElementById('startBtn');
  const stopBtn = document.getElementById('stopBtn');
  const excludeInput = document.getElementById('excludeInput');
  const popupError = document.getElementById('popupError');
  const speedSelect = document.getElementById('speedSelect');
  const termCountHint = document.getElementById('termCountHint');
  const onboardingCard = document.getElementById('onboardingCard');
  const onboardingDismiss = document.getElementById('onboardingDismiss');

  // Split the keyword box into terms (one per line), matching the background's rules
  function getTerms() {
    const seen = new Set();
    return keywordInput.value.split(/\r?\n/).map(t => t.trim()).filter(t => {
      if (!t || seen.has(t)) return false;
      seen.add(t);
      return true;
    }).slice(0, 20);
  }

  function updateTermHint() {
    const n = getTerms().length;
    termCountHint.textContent = n > 1 ? `${n} terms, one crawl` : 'one per line, up to 20';
  }

  // Short summary of non-default advanced options, shown while the section is collapsed
  const advancedSummary = document.getElementById('advancedSummary');
  function updateAdvancedSummary() {
    const parts = [];
    if (excludeInput.value.trim()) parts.push('excludes');
    if (caseSensitiveCheckbox.checked) parts.push('case');
    if (!robotsCheckbox.checked) parts.push('no robots');
    if (!sitemapCheckbox.checked) parts.push('no sitemap');
    if (jsRenderingCheckbox.checked) parts.push('JS');
    advancedSummary.textContent = parts.length ? `(${parts.join(', ')})` : '';
  }

  // ---- Persisted settings: the form is restored the next time the popup opens ----
  const SETTINGS_KEY = 'popupSettings';
  function collectSettings() {
    return {
      keyword: keywordInput.value,
      matchMode: matchModeSelect.value,
      scanScope: scanScopeSelect.value,
      maxPages: maxPagesInput.value,
      speed: speedSelect.value,
      exclude: excludeInput.value,
      caseSensitive: caseSensitiveCheckbox.checked,
      respectRobots: robotsCheckbox.checked,
      useSitemap: sitemapCheckbox.checked,
      jsRendering: jsRenderingCheckbox.checked
    };
  }
  let saveTimer = null;
  function saveSettings() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => {
      chrome.storage.local.set({ [SETTINGS_KEY]: collectSettings() });
    }, 250);
  }
  function applySettings(cfg) {
    if (!cfg) return;
    if (typeof cfg.keyword === 'string') keywordInput.value = cfg.keyword;
    if (cfg.matchMode) matchModeSelect.value = cfg.matchMode;
    if (cfg.scanScope) scanScopeSelect.value = cfg.scanScope;
    if (cfg.maxPages) maxPagesInput.value = cfg.maxPages;
    if (cfg.speed) speedSelect.value = cfg.speed;
    if (typeof cfg.exclude === 'string') excludeInput.value = cfg.exclude;
    caseSensitiveCheckbox.checked = !!cfg.caseSensitive;
    if (cfg.respectRobots !== undefined) robotsCheckbox.checked = cfg.respectRobots;
    if (cfg.useSitemap !== undefined) sitemapCheckbox.checked = cfg.useSitemap;
    jsRenderingCheckbox.checked = !!cfg.jsRendering;
    matchModeSelect.dispatchEvent(new Event('change'));
    scanScopeSelect.dispatchEvent(new Event('change'));
  }

  function showError(msg) {
    popupError.textContent = msg || '';
    popupError.style.display = msg ? 'block' : 'none';
  }

  // Disable case sensitive toggle if fuzzy mode is chosen
  matchModeSelect.addEventListener('change', () => {
    if (matchModeSelect.value === 'fuzzy') {
      caseSensitiveCheckbox.checked = false;
      caseSensitiveCheckbox.disabled = true;
    } else {
      caseSensitiveCheckbox.disabled = false;
    }
  });

  // Disable sitemap, robots, and max page limit if page-only scan is selected
  scanScopeSelect.addEventListener('change', () => {
    const isPage = scanScopeSelect.value === 'page';
    robotsCheckbox.disabled = isPage;
    sitemapCheckbox.disabled = isPage;
    maxPagesInput.disabled = isPage;
    excludeInput.disabled = isPage;
    maxPagesGroup.style.opacity = isPage ? '0.5' : '1';
  });

  const stored = await chrome.storage.local.get([SETTINGS_KEY, 'onboardingDismissed']);
  applySettings(stored[SETTINGS_KEY]);
  updateTermHint();
  if (!stored.onboardingDismissed) onboardingCard.hidden = false;
  onboardingDismiss.addEventListener('click', () => {
    onboardingCard.hidden = true;
    chrome.storage.local.set({ onboardingDismissed: true });
  });

  [keywordInput, maxPagesInput, excludeInput].forEach(el => el.addEventListener('input', saveSettings));
  [matchModeSelect, scanScopeSelect, speedSelect, caseSensitiveCheckbox, robotsCheckbox, sitemapCheckbox, jsRenderingCheckbox]
    .forEach(el => el.addEventListener('change', saveSettings));
  keywordInput.addEventListener('input', updateTermHint);
  updateAdvancedSummary();
  excludeInput.addEventListener('input', updateAdvancedSummary);
  [caseSensitiveCheckbox, robotsCheckbox, sitemapCheckbox, jsRenderingCheckbox]
    .forEach(el => el.addEventListener('change', updateAdvancedSummary));

  // Ctrl+Enter (Cmd+Enter on Mac) starts the audit; plain Enter adds another term line
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && (e.ctrlKey || e.metaKey) && !startBtn.disabled) {
      e.preventDefault();
      startBtn.click();
    }
  });
  const statusBadge = document.getElementById('statusBadge');
  const statusText = document.getElementById('statusText');
  const progressStatusLabel = document.getElementById('progressStatusLabel');
  const progressPercent = document.getElementById('progressPercent');
  const progressBarFill = document.getElementById('progressBarFill');
  const currentDomainText = document.getElementById('currentDomainText');
  const openReportLink = document.getElementById('openReportLink');

  // Stats
  const statCrawled = document.getElementById('statCrawled');
  const statQueue = document.getElementById('statQueue');
  const statMatches = document.getElementById('statMatches');
  const statErrors = document.getElementById('statErrors');

  let currentTabUrl = '';

  // Get active tab info
  const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (activeTab && activeTab.url) {
    currentTabUrl = activeTab.url;
    try {
      const urlObj = new URL(currentTabUrl);
      if (urlObj.protocol === 'http:' || urlObj.protocol === 'https:') {
        currentDomainText.textContent = `Target: ${urlObj.hostname}`;
        currentDomainText.title = currentTabUrl;
      } else {
        currentDomainText.textContent = "Unsupported page (must be http/https)";
        startBtn.disabled = true;
      }
    } catch (e) {
      currentDomainText.textContent = "Invalid URL";
      startBtn.disabled = true;
    }
  } else {
    currentDomainText.textContent = "Cannot access current tab";
    startBtn.disabled = true;
  }

  // Request latest state from background
  chrome.runtime.sendMessage({ type: 'GET_STATE' }, (response) => {
    void chrome.runtime.lastError;
    if (response && response.state) {
      updateUI(response.state);
    }
  });

  // Start Audit
  startBtn.addEventListener('click', () => {
    const terms = getTerms();
    const keyword = terms.join('\n');
    if (!keyword) {
      keywordInput.style.borderColor = 'var(--color-error)';
      setTimeout(() => {
        keywordInput.style.borderColor = 'var(--border-subtle)';
      }, 2000);
      return;
    }

    if (!currentTabUrl) return;

    if (matchModeSelect.value === 'regex') {
      for (const t of terms) {
        let re;
        try {
          re = new RegExp(t);
        } catch (e) {
          showError(terms.length > 1 ? `"${t}": ${e.message}` : e.message);
          return;
        }
        if (re.test('')) {
          showError(`The pattern "${t}" also matches empty text, so it would match everywhere. Make it more specific.`);
          return;
        }
      }
    }
    showError('');
    startBtn.disabled = true;
    // Reading robots.txt and sitemaps can take a few seconds on large sites
    progressStatusLabel.textContent = scanScopeSelect.value === 'page' ? 'Starting...' : 'Reading robots.txt and sitemap...';

    chrome.runtime.sendMessage({
      type: 'START_AUDIT',
      url: currentTabUrl,
      keyword: keyword,
      caseSensitive: caseSensitiveCheckbox.checked,
      respectRobots: robotsCheckbox.checked,
      useSitemap: sitemapCheckbox.checked,
      jsRendering: jsRenderingCheckbox.checked,
      matchMode: matchModeSelect.value,
      scanScope: scanScopeSelect.value,
      maxPages: clampPages(maxPagesInput.value),
      excludePatterns: excludeInput.value,
      speed: speedSelect.value
    }, (response) => {
      if (chrome.runtime.lastError || !response || !response.success) {
        startBtn.disabled = false;
        showError((response && response.error) || (chrome.runtime.lastError && chrome.runtime.lastError.message) || 'Could not start the audit.');
        return;
      }
      if (response && response.success) {
        // Optimistically set status
        statusText.textContent = 'Scanning...';
        statusBadge.classList.add('active');
      }
    });
  });

  // Stop Audit
  stopBtn.addEventListener('click', () => {
    chrome.runtime.sendMessage({ type: 'STOP_AUDIT' }, (res) => {
      void chrome.runtime.lastError;
      if (res && !res.success && res.error) showError(res.error);
    });
  });

  // Keep the page limit inside 1..1000 so what the user sees is what will be used
  function clampPages(v) {
    return Math.min(Math.max(parseInt(v, 10) || 100, 1), 1000);
  }
  maxPagesInput.addEventListener('change', () => {
    maxPagesInput.value = clampPages(maxPagesInput.value);
    saveSettings();
  });

  // Open Dashboard Report in a new tab
  openReportLink.addEventListener('click', (e) => {
    e.preventDefault();
    chrome.storage.local.get('crawlerState', (data) => {
      let auditParams = '';
      if (data.crawlerState && data.crawlerState.currentAuditId) {
        auditParams = `?id=${data.crawlerState.currentAuditId}`;
      }
      chrome.tabs.create({ url: chrome.runtime.getURL(`report.html${auditParams}`) });
    });
  });

  // Listen for progress updates
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === 'STATUS_UPDATE') {
      updateUI(message.state);
    }
  });

  // Live countdown while the crawl is paused by a server rate limit
  let pauseTimer = null;
  let lastState = null;

  // Sync UI state
  function updateUI(state) {
    lastState = state;
    const isRunning = state.status === 'running';
    const isPaused = state.status === 'paused';
    const isStarting = state.status === 'starting';
    const isBusy = isRunning || isPaused || isStarting;

    // While an audit runs, the form mirrors that audit's settings; otherwise it keeps the
    // user's saved settings (restored from storage when the popup opened).
    if (isRunning || isPaused) {
      keywordInput.value = (Array.isArray(state.terms) && state.terms.length ? state.terms : [state.keyword || '']).join('\n');
      matchModeSelect.value = state.matchMode || matchModeSelect.value;
      scanScopeSelect.value = state.scanScope || 'site';
      maxPagesInput.value = state.maxPages || 100;
      if (state.speed) speedSelect.value = state.speed;
      if (Array.isArray(state.excludePatterns)) excludeInput.value = state.excludePatterns.join(', ');
      caseSensitiveCheckbox.checked = !!state.caseSensitive;
      if (state.respectRobots !== undefined) robotsCheckbox.checked = state.respectRobots;
      if (state.useSitemap !== undefined) sitemapCheckbox.checked = state.useSitemap;
      jsRenderingCheckbox.checked = !!state.jsRendering;
      updateTermHint();
      updateAdvancedSummary();
    }

    keywordInput.disabled = isBusy;
    matchModeSelect.disabled = isBusy;
    if (matchModeSelect.value === 'fuzzy') {
      caseSensitiveCheckbox.checked = false;
      caseSensitiveCheckbox.disabled = true;
    } else {
      caseSensitiveCheckbox.disabled = isBusy;
    }
    scanScopeSelect.disabled = isBusy;
    speedSelect.disabled = isBusy;
    const isPage = scanScopeSelect.value === 'page';
    maxPagesInput.disabled = isBusy || isPage;
    maxPagesGroup.style.opacity = isPage ? '0.5' : '1';
    excludeInput.disabled = isBusy || isPage;
    robotsCheckbox.disabled = isBusy || isPage;
    sitemapCheckbox.disabled = isBusy || isPage;
    jsRenderingCheckbox.disabled = isBusy;

    startBtn.disabled = isBusy || !currentTabUrl || currentDomainText.textContent.includes('Unsupported');
    stopBtn.disabled = !isRunning && !isPaused;

    // Update status badge
    statusText.textContent = (state.status || 'idle').toUpperCase();
    statusBadge.classList.toggle('active', isRunning || isStarting);
    clearTimeout(pauseTimer);
    const crawledCount = state.crawledCount || 0;
    const queueCount = state.queueCount || 0;
    const delayNote = state.crawlDelay > 0 ? ` (robots.txt asks for ${state.crawlDelay}s between pages)` : '';
    if (isStarting) {
      progressStatusLabel.textContent = 'Reading robots.txt and sitemap...';
    } else if (isRunning) {
      progressStatusLabel.textContent = 'Auditing site...' + delayNote;
    } else if (isPaused) {
      const secs = Math.max(0, Math.ceil(((state.resumeAt || 0) - Date.now()) / 1000));
      progressStatusLabel.textContent = `Server asked to slow down: retrying in ${secs}s`;
      pauseTimer = setTimeout(() => { if (lastState === state) updateUI(state); }, 1000);
    } else if (state.status === 'completed') {
      progressStatusLabel.textContent = queueCount || state.queueTruncated ? 'Audit complete (page limit reached)' : 'Audit complete';
    } else if (state.status === 'stopped') {
      progressStatusLabel.textContent = 'Audit stopped';
    } else {
      progressStatusLabel.textContent = 'Idle';
    }
    progressStatusLabel.title = progressStatusLabel.textContent;

    // Update stats
    statCrawled.textContent = crawledCount;
    statQueue.textContent = queueCount;
    statMatches.textContent = state.totalMatches || 0;
    statErrors.textContent = state.errorCount || 0;

    // Update progress bar
    // Progress is measured against the page cap when the queue is larger than it
    const cap = state.scanScope === 'page' ? 1 : (state.maxPages || 100);
    const totalDiscovered = Math.min(crawledCount + queueCount, cap);
    let percent = 0;
    if (state.status === 'completed') {
      percent = 100;
    } else if (totalDiscovered > 0) {
      percent = Math.min(100, Math.round((crawledCount / totalDiscovered) * 100));
    }
    progressPercent.textContent = `${percent}%`;
    progressBarFill.style.width = `${percent}%`;

    // Keep Dashboard link always visible so users can view past history
    openReportLink.style.display = 'inline-block';
  }
});
