// SiteScope Popup Controller Script

document.addEventListener('DOMContentLoaded', async () => {
  // Elements
  const keywordInput = document.getElementById('keywordInput');
  const caseSensitiveCheckbox = document.getElementById('caseSensitiveCheckbox');
  const robotsCheckbox = document.getElementById('robotsCheckbox');
  const sitemapCheckbox = document.getElementById('sitemapCheckbox');
  const jsRenderingCheckbox = document.getElementById('jsRenderingCheckbox');
  const matchModeSelect = document.getElementById('matchModeSelect');
  const scanScopeSelect = document.getElementById('scanScopeSelect');
  const maxPagesInput = document.getElementById('maxPagesInput');
  const maxPagesGroup = document.getElementById('maxPagesGroup');
  const startBtn = document.getElementById('startBtn');
  const stopBtn = document.getElementById('stopBtn');
  const excludeInput = document.getElementById('excludeInput');
  const popupError = document.getElementById('popupError');

  function showError(msg) {
    popupError.textContent = msg || '';
    popupError.style.display = msg ? 'block' : 'none';
  }

  // Disable case sensitive toggle if fuzzy mode is chosen
  matchModeSelect.addEventListener('change', () => {
    if (matchModeSelect.value === 'fuzzy') {
      caseSensitiveCheckbox.checked = false;
      caseSensitiveCheckbox.disabled = true;
    } else {
      caseSensitiveCheckbox.disabled = false;
    }
  });

  // Disable sitemap, robots, and max page limit if page-only scan is selected
  scanScopeSelect.addEventListener('change', () => {
    const isPage = scanScopeSelect.value === 'page';
    robotsCheckbox.disabled = isPage;
    sitemapCheckbox.disabled = isPage;
    maxPagesInput.disabled = isPage;
    excludeInput.disabled = isPage;
    maxPagesGroup.style.opacity = isPage ? '0.5' : '1';
  });
  const statusBadge = document.getElementById('statusBadge');
  const statusText = document.getElementById('statusText');
  const progressStatusLabel = document.getElementById('progressStatusLabel');
  const progressPercent = document.getElementById('progressPercent');
  const progressBarFill = document.getElementById('progressBarFill');
  const currentDomainText = document.getElementById('currentDomainText');
  const openReportLink = document.getElementById('openReportLink');

  // Stats
  const statCrawled = document.getElementById('statCrawled');
  const statQueue = document.getElementById('statQueue');
  const statMatches = document.getElementById('statMatches');
  const statErrors = document.getElementById('statErrors');

  let currentTabUrl = '';

  // Get active tab info
  const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (activeTab && activeTab.url) {
    currentTabUrl = activeTab.url;
    try {
      const urlObj = new URL(currentTabUrl);
      if (urlObj.protocol === 'http:' || urlObj.protocol === 'https:') {
        currentDomainText.textContent = `Target: ${urlObj.hostname}`;
        currentDomainText.title = currentTabUrl;
      } else {
        currentDomainText.textContent = "Unsupported page (must be http/https)";
        startBtn.disabled = true;
      }
    } catch (e) {
      currentDomainText.textContent = "Invalid URL";
      startBtn.disabled = true;
    }
  } else {
    currentDomainText.textContent = "Cannot access current tab";
    startBtn.disabled = true;
  }

  // Request latest state from background
  chrome.runtime.sendMessage({ type: 'GET_STATE' }, (response) => {
    if (response && response.state) {
      updateUI(response.state);
    }
  });

  // Start Audit
  startBtn.addEventListener('click', () => {
    const keyword = keywordInput.value.trim();
    if (!keyword) {
      keywordInput.style.borderColor = 'var(--color-error)';
      setTimeout(() => {
        keywordInput.style.borderColor = 'var(--border-subtle)';
      }, 2000);
      return;
    }

    if (!currentTabUrl) return;

    if (matchModeSelect.value === 'regex') {
      try {
        new RegExp(keyword);
      } catch (e) {
        showError(e.message);
        return;
      }
    }
    showError('');
    startBtn.disabled = true;

    chrome.runtime.sendMessage({
      type: 'START_AUDIT',
      url: currentTabUrl,
      keyword: keyword,
      caseSensitive: caseSensitiveCheckbox.checked,
      respectRobots: robotsCheckbox.checked,
      useSitemap: sitemapCheckbox.checked,
      jsRendering: jsRenderingCheckbox.checked,
      matchMode: matchModeSelect.value,
      scanScope: scanScopeSelect.value,
      maxPages: parseInt(maxPagesInput.value, 10) || 100,
      excludePatterns: excludeInput.value
    }, (response) => {
      if (chrome.runtime.lastError || !response || !response.success) {
        startBtn.disabled = false;
        showError((response && response.error) || (chrome.runtime.lastError && chrome.runtime.lastError.message) || 'Could not start the audit.');
        return;
      }
      if (response && response.success) {
        // Optimistically set status
        statusText.textContent = 'Scanning...';
        statusBadge.classList.add('active');
      }
    });
  });

  // Stop Audit
  stopBtn.addEventListener('click', () => {
    chrome.runtime.sendMessage({ type: 'STOP_AUDIT' }, () => void chrome.runtime.lastError);
  });

  // Open Dashboard Report in a new tab
  openReportLink.addEventListener('click', (e) => {
    e.preventDefault();
    chrome.storage.local.get('crawlerState', (data) => {
      let auditParams = '';
      if (data.crawlerState && data.crawlerState.currentAuditId) {
        auditParams = `?id=${data.crawlerState.currentAuditId}`;
      }
      chrome.tabs.create({ url: chrome.runtime.getURL(`report.html${auditParams}`) });
    });
  });

  // Listen for progress updates
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === 'STATUS_UPDATE') {
      updateUI(message.state);
    }
  });

  // Sync UI state
  function updateUI(state) {
    const isRunning = state.status === 'running';

    // Toggle interactive inputs
    keywordInput.value = state.keyword || keywordInput.value;
    keywordInput.disabled = isRunning;
    matchModeSelect.value = state.matchMode || matchModeSelect.value;
    matchModeSelect.disabled = isRunning;
    
    if (matchModeSelect.value === 'fuzzy') {
      caseSensitiveCheckbox.checked = false;
      caseSensitiveCheckbox.disabled = true;
    } else {
      caseSensitiveCheckbox.checked = state.caseSensitive;
      caseSensitiveCheckbox.disabled = isRunning;
    }
    
    scanScopeSelect.value = state.scanScope || 'site';
    scanScopeSelect.disabled = isRunning;

    maxPagesInput.value = state.maxPages || 100;
    maxPagesInput.disabled = isRunning || scanScopeSelect.value === 'page';
    maxPagesGroup.style.opacity = (scanScopeSelect.value === 'page') ? '0.5' : '1';

    if (Array.isArray(state.excludePatterns) && state.excludePatterns.length && !excludeInput.value) {
      excludeInput.value = state.excludePatterns.join(', ');
    }
    excludeInput.disabled = isRunning || scanScopeSelect.value === 'page';

    robotsCheckbox.checked = state.respectRobots !== undefined ? state.respectRobots : robotsCheckbox.checked;
    robotsCheckbox.disabled = isRunning || scanScopeSelect.value === 'page';
    sitemapCheckbox.checked = state.useSitemap !== undefined ? state.useSitemap : sitemapCheckbox.checked;
    sitemapCheckbox.disabled = isRunning || scanScopeSelect.value === 'page';
    jsRenderingCheckbox.checked = state.jsRendering !== undefined ? state.jsRendering : jsRenderingCheckbox.checked;
    jsRenderingCheckbox.disabled = isRunning;
    
    const isPaused = state.status === 'paused';
    startBtn.disabled = isRunning || isPaused || !currentTabUrl || currentDomainText.textContent.includes('Unsupported');
    stopBtn.disabled = !isRunning && !isPaused;

    // Update status badge
    statusText.textContent = state.status.toUpperCase();
    if (isRunning) {
      statusBadge.classList.add('active');
      progressStatusLabel.textContent = "Auditing Site...";
    } else {
      statusBadge.classList.remove('active');
      progressStatusLabel.textContent = state.status === 'completed' ? "Audit Complete" : 
                                        state.status === 'stopped' ? "Audit Stopped" :
                                        state.status === 'paused' ? "Paused (server rate limit), retrying..." : "Idle";
    }

    // Update stats
    statCrawled.textContent = (state.crawled || []).length;
    statQueue.textContent = (state.queue || []).length;
    statMatches.textContent = state.totalMatches;
    statErrors.textContent = state.errorCount;

    // Update progress bar
    const crawledCount = (state.crawled || []).length;
    const queueCount = (state.queue || []).length;
    // Progress is measured against the page cap when the queue is larger than it
    const cap = state.scanScope === 'page' ? 1 : (state.maxPages || 100);
    const totalDiscovered = Math.min(crawledCount + queueCount, cap);
    let percent = 0;
    if (state.status === 'completed') {
      percent = 100;
    } else if (totalDiscovered > 0) {
      percent = Math.min(100, Math.round((crawledCount / totalDiscovered) * 100));
    }
    progressPercent.textContent = `${percent}%`;
    progressBarFill.style.width = `${percent}%`;

    // Keep Dashboard link always visible so users can view past history
    openReportLink.style.display = 'inline-block';
  }
});
