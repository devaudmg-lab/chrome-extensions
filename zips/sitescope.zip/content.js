// SiteScope Content Script for Visual Keyword Highlighting.
// Injected on demand by "Highlight in Context" (never on every page). The toolbar lives in a
// closed shadow root so page CSS cannot break it and page scripts cannot read it.

(() => {
  // A second injection into the same tab reuses the listener that is already there. After an
  // extension update the old copy's runtime is gone, so a fresh copy takes over.
  const alive = () => {
    try { return !!(chrome.runtime && chrome.runtime.id); } catch (e) { return false; }
  };
  if (window.__sitescopeHighlighter && window.__sitescopeHighlighter.alive()) return;
  window.__sitescopeHighlighter = { alive };

  // Levenshtein function for fuzzy checking
  function getLevenshtein(s1, s2) {
    const m = s1.length;
    const n = s2.length;
    const dp = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));
    for (let i = 0; i <= m; i++) dp[i][0] = i;
    for (let j = 0; j <= n; j++) dp[0][j] = j;

    for (let i = 1; i <= m; i++) {
      for (let j = 1; j <= n; j++) {
        if (s1[i - 1] === s2[j - 1]) {
          dp[i][j] = dp[i - 1][j - 1];
        } else {
          dp[i][j] = Math.min(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + 1);
        }
      }
    }
    return dp[m][n];
  }

  function isFuzzy(w1, w2) {
    const word1 = w1.toLowerCase().trim();
    const word2 = w2.toLowerCase().trim();
    if (word1 === word2) return true;

    const len = Math.max(word1.length, word2.length);
    let maxDist = 0;
    if (len >= 9) maxDist = 2;
    else if (len >= 5) maxDist = 1;
    return getLevenshtein(word1, word2) <= maxDist;
  }

  const PUNCT = /[.,\/#!$%\^&\*;:{}=\-_`~()?"'\[\]]/g;
  const SKIP_PARENTS = new Set(['SCRIPT', 'STYLE', 'TEXTAREA', 'INPUT', 'NOSCRIPT', 'TEMPLATE']);
  const ROOT_ID = 'sitescope-root';

  // Attribute matches: element -> 'name="value"' (kept here, not in the page's DOM)
  let attrInfo = new WeakMap();
  let teardown = null;

  function getTextNodes(node) {
    const textNodes = [];
    const walk = document.createTreeWalker(node, NodeFilter.SHOW_TEXT, null);
    let n;
    while ((n = walk.nextNode())) {
      const parent = n.parentNode;
      if (!parent || SKIP_PARENTS.has(parent.nodeName.toUpperCase())) continue;
      // Skip text already highlighted for an earlier term
      if (parent.classList && parent.classList.contains('sitescope-highlight')) continue;
      textNodes.push(n);
    }
    return textNodes;
  }

  // Phrases in `text` that fuzzily match `keyword`
  function fuzzyPhrases(text, keyword) {
    const keyLen = keyword.toLowerCase().split(/\s+/).filter(Boolean).length;
    const words = text.replace(PUNCT, ' ').split(/\s+/).filter(Boolean);
    const found = [];
    if (keyLen === 1) {
      words.forEach(word => { if (isFuzzy(word, keyword)) found.push(word); });
    } else if (keyLen > 1) {
      for (let i = 0; i <= words.length - keyLen; i++) {
        const slice = words.slice(i, i + keyLen).join(' ');
        if (isFuzzy(slice, keyword)) found.push(slice);
      }
    }
    return found;
  }

  const escapeRegex = (s) => s.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');

  // Highlight every occurrence of one term; returns the number of new highlights
  function highlightTerm(keyword, matchMode, caseSensitive) {
    if (!keyword || !document.body) return 0;

    let regex = null;
    if (matchMode !== 'fuzzy') {
      try {
        regex = matchMode === 'regex'
          ? new RegExp(keyword, caseSensitive ? 'g' : 'gi')
          : new RegExp(escapeRegex(keyword).replace(/\s+/g, '\\s+'), caseSensitive ? 'g' : 'gi');
      } catch (e) {
        return 0;
      }
    }

    const matchesValue = (val) => {
      if (!val) return false;
      if (matchMode === 'fuzzy') return fuzzyPhrases(val, keyword).length > 0;
      const testRegex = new RegExp(regex.source, caseSensitive ? '' : 'i');
      const m = testRegex.exec(val);
      return !!(m && m[0]);
    };

    let matchCount = 0;
    getTextNodes(document.body).forEach(node => {
      const text = node.nodeValue;
      if (!text.trim()) return;
      if (matchMode === 'fuzzy') {
        const phrases = Array.from(new Set(fuzzyPhrases(text, keyword).map(escapeRegex)));
        if (phrases.length) matchCount += applyRegexHighlight(node, new RegExp(`(${phrases.join('|')})`, 'gi'));
      } else {
        matchCount += applyRegexHighlight(node, regex);
      }
    });

    // Elements whose attributes match (alt, aria-label, class, id, data-*, ...)
    document.body.querySelectorAll('*').forEach(el => {
      const tag = el.tagName.toUpperCase();
      if (tag === 'SCRIPT' || tag === 'STYLE' || el.id === ROOT_ID) return;
      if (attrInfo.has(el)) return; // already matched by another term
      for (const attr of el.attributes) {
        if (attr.name === 'data-sitescope-attr-match' || attr.name === 'class' && /^sitescope-/.test(attr.value)) continue;
        if (matchesValue(attr.value)) {
          attrInfo.set(el, `${attr.name}="${attr.value}"`);
          el.setAttribute('data-sitescope-attr-match', '');
          matchCount++;
          break; // Count only once per element
        }
      }
    });

    return matchCount;
  }

  function applyRegexHighlight(textNode, regex) {
    const text = textNode.nodeValue;
    const gRegex = new RegExp(regex.source, regex.flags.includes('g') ? regex.flags : regex.flags + 'g');

    const matches = [];
    let m;
    while ((m = gRegex.exec(text)) !== null) {
      if (m[0]) matches.push({ index: m.index, text: m[0] });
      if (gRegex.lastIndex === m.index) gRegex.lastIndex++; // guard against empty matches
    }
    if (matches.length === 0) return 0;

    const parent = textNode.parentNode;
    if (!parent) return 0;

    const fragment = document.createDocumentFragment();
    let lastIdx = 0;
    matches.forEach(match => {
      if (match.index > lastIdx) {
        fragment.appendChild(document.createTextNode(text.substring(lastIdx, match.index)));
      }
      const mark = document.createElement('mark');
      mark.className = 'sitescope-highlight';
      mark.textContent = match.text;
      fragment.appendChild(mark);
      lastIdx = match.index + match.text.length;
    });
    if (lastIdx < text.length) {
      fragment.appendChild(document.createTextNode(text.substring(lastIdx)));
    }
    parent.replaceChild(fragment, textNode);
    return matches.length;
  }

  // Remove every mark and attribute flag, restoring the page's original text nodes
  function clearHighlights() {
    document.querySelectorAll('mark.sitescope-highlight').forEach(mark => {
      const parent = mark.parentNode;
      if (!parent) return;
      parent.replaceChild(document.createTextNode(mark.textContent), mark);
      parent.normalize();
    });
    document.querySelectorAll('[data-sitescope-attr-match]').forEach(el => {
      el.removeAttribute('data-sitescope-attr-match');
      el.classList.remove('sitescope-focused-attr');
    });
    attrInfo = new WeakMap();
  }

  function collectHighlights() {
    return Array.from(document.querySelectorAll('mark.sitescope-highlight, [data-sitescope-attr-match]'));
  }

  // Highlight all audit terms on the page, then show the navigation toolbar
  function highlightMatches(request, retried) {
    if (teardown) teardown();
    clearHighlights();
    const { keyword, matchMode, caseSensitive } = request;
    const terms = Array.isArray(request.terms) && request.terms.length ? request.terms : [keyword];
    terms.forEach(term => highlightTerm(String(term || ''), matchMode, caseSensitive));

    const highlights = collectHighlights();
    if (highlights.length > 0) {
      createNavigationToolbar(highlights, terms);
    } else if (!retried) {
      // Pages that render their content with JavaScript may not be ready yet: try once more
      setTimeout(() => highlightMatches(request, true), 2000);
    } else {
      const label = terms.length > 1 ? `None of the ${terms.length} terms were` : `"${terms[0]}" was not`;
      showNoticeToast(`SiteScope: ${label} found on this page. The content may have changed since the audit.`);
    }
  }

  // Shadow host shared by the toolbar, the attribute badge and notices
  function getUiRoot() {
    let host = document.getElementById(ROOT_ID);
    if (host && host.__sitescopeShadow) return host.__sitescopeShadow;
    if (host) host.remove();
    host = document.createElement('div');
    host.id = ROOT_ID;
    Object.assign(host.style, {
      all: 'initial',
      position: 'absolute',
      top: '0',
      left: '0',
      width: '0',
      height: '0',
      zIndex: '2147483647'
    });
    const shadow = host.attachShadow({ mode: 'closed' });
    Object.defineProperty(host, '__sitescopeShadow', { value: shadow });
    document.documentElement.appendChild(host);
    return shadow;
  }

  const FONT = "'Segoe UI', system-ui, -apple-system, Roboto, sans-serif";

  // Render floating navigation bar in target tab
  function createNavigationToolbar(highlights, terms) {
    const root = getUiRoot();
    const host = root.host;
    let currentIndex = 0;
    let currentBadge = null;

    const toolbar = document.createElement('div');
    toolbar.setAttribute('role', 'toolbar');
    toolbar.setAttribute('aria-label', 'SiteScope matches');
    Object.assign(toolbar.style, {
      position: 'fixed',
      bottom: '24px',
      left: '50%',
      transform: 'translateX(-50%)',
      backgroundColor: '#0a0f1d',
      border: '1px solid #2b385c',
      borderRadius: '12px',
      padding: '10px 16px',
      display: 'flex',
      alignItems: 'center',
      gap: '12px',
      fontFamily: FONT,
      fontSize: '13px',
      lineHeight: '1.4',
      color: '#ffffff',
      boxShadow: '0 8px 32px rgba(0, 0, 0, 0.6), 0 0 16px rgba(138, 43, 226, 0.2)',
      maxWidth: 'calc(100vw - 32px)',
      flexWrap: 'wrap',
      boxSizing: 'border-box'
    });

    const infoLabel = document.createElement('span');
    infoLabel.setAttribute('aria-live', 'polite');
    infoLabel.style.fontWeight = '600';

    const termCount = Array.isArray(terms) ? terms.length : 1;
    const hintLabel = document.createElement('span');
    hintLabel.textContent = (termCount > 1 ? `${termCount} terms · ` : '') + 'Enter / Shift+Enter · Esc';
    Object.assign(hintLabel.style, { fontSize: '11px', color: '#a5b4cc' });

    const styleButton = (btn, base) => {
      btn.type = 'button';
      Object.assign(btn.style, base, { cursor: 'pointer', fontFamily: FONT, outlineOffset: '2px' });
      btn.addEventListener('focus', () => { btn.style.outline = '2px solid #a78bfa'; });
      btn.addEventListener('blur', () => { btn.style.outline = 'none'; });
    };
    const createNavBtn = (text, label, onClick) => {
      const btn = document.createElement('button');
      btn.textContent = text;
      btn.setAttribute('aria-label', label);
      styleButton(btn, {
        backgroundColor: '#1b2644',
        border: '1px solid #37466f',
        borderRadius: '6px',
        color: '#ffffff',
        padding: '4px 10px',
        fontSize: '12px',
        fontWeight: '600'
      });
      btn.addEventListener('mouseenter', () => { btn.style.backgroundColor = '#2c3b6b'; });
      btn.addEventListener('mouseleave', () => { btn.style.backgroundColor = '#1b2644'; });
      btn.addEventListener('click', onClick);
      return btn;
    };

    const prevBtn = createNavBtn('◀ Prev', 'Previous match', () => navigate(-1));
    const nextBtn = createNavBtn('Next ▶', 'Next match', () => navigate(1));

    const closeBtn = document.createElement('button');
    closeBtn.textContent = '×';
    closeBtn.setAttribute('aria-label', 'Remove highlights');
    closeBtn.title = 'Remove highlights (Esc)';
    styleButton(closeBtn, {
      background: 'none',
      border: 'none',
      color: '#a5b4cc',
      fontSize: '20px',
      padding: '0 4px',
      lineHeight: '1'
    });
    closeBtn.addEventListener('mouseenter', () => { closeBtn.style.color = '#ff6b6b'; });
    closeBtn.addEventListener('mouseleave', () => { closeBtn.style.color = '#a5b4cc'; });
    closeBtn.addEventListener('click', () => {
      if (teardown) teardown();
      clearHighlights();
    });

    toolbar.append(infoLabel, prevBtn, nextBtn, hintLabel, closeBtn);
    root.appendChild(toolbar);

    // Keyboard navigation: Enter / F3 = next, Shift+Enter / Shift+F3 = previous, Esc = close.
    // Enter is only taken when nothing on the page has focus (or the toolbar has), so links,
    // buttons and form fields keep working normally.
    function onKey(e) {
      const t = e.target;
      const onPage = t === document.body || t === document.documentElement || t === document || t === host;
      if (e.key === 'F3') {
        e.preventDefault();
        navigate(e.shiftKey ? -1 : 1);
      } else if (e.key === 'Enter' && onPage && !e.ctrlKey && !e.altKey && !e.metaKey) {
        if (t === host) return; // toolbar buttons handle Enter themselves
        e.preventDefault();
        navigate(e.shiftKey ? -1 : 1);
      } else if (e.key === 'Escape' && (onPage || !(t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName))))) {
        if (teardown) teardown();
        clearHighlights();
      }
    }
    document.addEventListener('keydown', onKey, true);

    function onScroll() {
      if (currentBadge) positionBadge(highlights[currentIndex], currentBadge);
    }
    window.addEventListener('resize', onScroll);

    teardown = () => {
      document.removeEventListener('keydown', onKey, true);
      window.removeEventListener('resize', onScroll);
      removeAttrBadge();
      toolbar.remove();
      teardown = null;
    };

    function showAttrBadge(element) {
      removeAttrBadge();
      const badge = document.createElement('div');
      badge.textContent = `Attribute match: ${attrInfo.get(element) || ''}`;
      Object.assign(badge.style, {
        position: 'absolute',
        backgroundColor: '#8a2be2',
        color: '#ffffff',
        padding: '6px 12px',
        borderRadius: '6px',
        fontSize: '11px',
        fontWeight: '700',
        fontFamily: FONT,
        boxShadow: '0 4px 16px rgba(0,0,0,0.6)',
        pointerEvents: 'none',
        whiteSpace: 'nowrap',
        maxWidth: '60vw',
        overflow: 'hidden',
        textOverflow: 'ellipsis'
      });
      root.appendChild(badge);
      currentBadge = badge;
      positionBadge(element, badge);
    }

    function positionBadge(element, badge) {
      const rect = element.getBoundingClientRect();
      const badgeRect = badge.getBoundingClientRect();
      let top = rect.top + window.scrollY - badgeRect.height - 6;
      if (rect.top < badgeRect.height + 12) top = rect.bottom + window.scrollY + 6;
      badge.style.top = `${Math.max(0, top)}px`;
      badge.style.left = `${Math.max(0, rect.left + window.scrollX)}px`;
    }

    function removeAttrBadge() {
      if (currentBadge) {
        currentBadge.remove();
        currentBadge = null;
      }
    }

    function updateLabel() {
      infoLabel.textContent = `${currentIndex + 1} of ${highlights.length} match${highlights.length === 1 ? '' : 'es'}`;
    }

    function navigate(direction) {
      resetActiveHighlight(currentIndex);
      currentIndex = (currentIndex + direction + highlights.length) % highlights.length;
      updateLabel();
      focusHighlight(currentIndex);
    }

    function focusHighlight(index) {
      const el = highlights[index];
      if (!el || !el.isConnected) return;
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      if (el.hasAttribute('data-sitescope-attr-match')) {
        el.classList.add('sitescope-focused-attr');
        showAttrBadge(el);
        // Re-position once smooth scrolling has settled
        setTimeout(onScroll, 450);
      } else {
        el.classList.add('sitescope-current');
      }
    }

    function resetActiveHighlight(index) {
      const el = highlights[index];
      if (!el) return;
      el.classList.remove('sitescope-focused-attr', 'sitescope-current');
      removeAttrBadge();
    }

    updateLabel();
    focusHighlight(0);
  }

  function showNoticeToast(message) {
    const root = getUiRoot();
    const toast = document.createElement('div');
    toast.setAttribute('role', 'status');
    toast.textContent = message;
    Object.assign(toast.style, {
      position: 'fixed',
      top: '24px',
      right: '24px',
      maxWidth: '360px',
      backgroundColor: '#0a0f1d',
      border: '1px solid #ff6b6b',
      borderRadius: '8px',
      padding: '12px 20px',
      color: '#ffffff',
      fontFamily: FONT,
      fontSize: '13px',
      lineHeight: '1.4',
      boxShadow: '0 4px 12px rgba(0,0,0,0.5)'
    });
    root.appendChild(toast);
    // Web Animations API: not affected by the page's style-src CSP
    try {
      toast.animate([{ transform: 'translateX(50px)', opacity: 0 }, { transform: 'none', opacity: 1 }], { duration: 300, easing: 'ease-out' });
    } catch (e) { /* ignore */ }
    setTimeout(() => toast.remove(), 5000);
  }

  // Messaging listener: only the SiteScope service worker sends HIGHLIGHT_DOM
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!message || message.type !== 'HIGHLIGHT_DOM' || sender.id !== chrome.runtime.id) return false;
    highlightMatches(message, false);
    sendResponse({ success: true });
    return false;
  });
})();
