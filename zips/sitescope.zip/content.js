// SiteScope Content Script for Visual Keyword Highlighting

// Levenshtein function for fuzzy checking
function getLevenshtein(s1, s2) {
  const m = s1.length;
  const n = s2.length;
  const dp = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));
  for (let i = 0; i <= m; i++) dp[i][0] = i;
  for (let j = 0; j <= n; j++) dp[0][j] = j;
  
  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      if (s1[i - 1] === s2[j - 1]) {
        dp[i][j] = dp[i - 1][j - 1];
      } else {
        dp[i][j] = Math.min(
          dp[i - 1][j] + 1,
          dp[i][j - 1] + 1,
          dp[i - 1][j - 1] + 1
        );
      }
    }
  }
  return dp[m][n];
}

function isFuzzy(w1, w2) {
  const word1 = w1.toLowerCase().trim();
  const word2 = w2.toLowerCase().trim();
  if (word1 === word2) return true;
  
  const len = Math.max(word1.length, word2.length);
  let maxDist = 0;
  if (len >= 9) maxDist = 2;
  else if (len >= 5) maxDist = 1;
  return getLevenshtein(word1, word2) <= maxDist;
}

function getTextNodes(node) {
  const textNodes = [];
  const walk = document.createTreeWalker(node, NodeFilter.SHOW_TEXT, null, false);
  let n;
  while (n = walk.nextNode()) {
    const parentName = n.parentNode.nodeName.toUpperCase();
    // Skip text already highlighted for an earlier term, and SiteScope's own toolbar
    if (n.parentNode.classList && n.parentNode.classList.contains('sitescope-highlight')) continue;
    if (n.parentNode.closest && n.parentNode.closest('#sitescope-toolbar')) continue;
    if (parentName !== 'SCRIPT' && parentName !== 'STYLE' && parentName !== 'TEXTAREA' && parentName !== 'INPUT') {
      textNodes.push(n);
    }
  }
  return textNodes;
}

// Highlight every occurrence of one term; returns the number of new highlights
function highlightTerm(keyword, matchMode, caseSensitive) {
  if (!keyword) return 0;

  // Inject style overrides for attribute highlights & badges
  if (!document.getElementById('sitescope-highlight-style')) {
    const style = document.createElement('style');
    style.id = 'sitescope-highlight-style';
    style.innerHTML = `
      [data-sitescope-attr-match] {
        outline: 2px dashed #d4af37 !important;
        outline-offset: 2px !important;
        transition: outline 0.2s ease, outline-offset 0.2s ease, box-shadow 0.2s ease !important;
      }
      [data-sitescope-attr-match].sitescope-focused-attr {
        outline: 3px solid #8a2be2 !important;
        outline-offset: 2px !important;
        box-shadow: 0 0 12px #8a2be2 !important;
      }
    `;
    document.head.appendChild(style);
  }

  // 1. Gather all text nodes
  const textNodes = getTextNodes(document.body);
  let matchCount = 0;
  
  // Determine matching pattern/function
  let regex = null;
  if (matchMode !== 'fuzzy') {
    try {
      if (matchMode === 'regex') {
        regex = new RegExp(keyword, caseSensitive ? 'g' : 'gi');
      } else {
        const escaped = keyword.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
        const spacedRegex = escaped.replace(/\s+/g, '\\s+');
        regex = new RegExp(spacedRegex, caseSensitive ? 'g' : 'gi');
      }
    } catch (e) {
      console.error("Invalid RegEx in highlights:", e);
      return 0;
    }
  }

  // Helper function to check matches in attributes
  function checkStringMatch(val) {
    if (!val) return false;
    if (matchMode === 'fuzzy') {
      const keyWords = keyword.toLowerCase().split(/\s+/).filter(Boolean);
      const textWords = val.replace(/[.,\/#!$%\^&\*;:{}=\-_`~()?"'\[\]]/g, ' ').split(/\s+/).filter(Boolean);
      const keyLen = keyWords.length;
      if (keyLen === 1) {
        return textWords.some(word => isFuzzy(word, keyword));
      } else if (keyLen > 1) {
        for (let i = 0; i <= textWords.length - keyLen; i++) {
          const slice = textWords.slice(i, i + keyLen).join(' ');
          if (isFuzzy(slice, keyword)) return true;
        }
      }
      return false;
    } else {
      const testRegex = new RegExp(regex.source, caseSensitive ? '' : 'i');
      return testRegex.test(val);
    }
  }

  // 2. Loop & Replace nodes
  textNodes.forEach(node => {
    const text = node.nodeValue;
    if (!text.trim()) return;

    if (matchMode === 'fuzzy') {
      // Fuzzy mode DOM highlights: match words
      const keyWords = keyword.toLowerCase().split(/\s+/).filter(Boolean);
      const textWords = text.replace(/[.,\/#!$%\^&\*;:{}=\-_`~()?"'\[\]]/g, ' ').split(/\s+/).filter(Boolean);
      
      const matchedStrings = [];
      const keyLen = keyWords.length;
      if (keyLen === 1) {
        textWords.forEach(word => {
          if (isFuzzy(word, keyword)) {
            matchedStrings.push(word);
          }
        });
      } else {
        for (let i = 0; i <= textWords.length - keyLen; i++) {
          const slice = textWords.slice(i, i + keyLen).join(' ');
          if (isFuzzy(slice, keyword)) {
            matchedStrings.push(slice);
          }
        }
      }

      if (matchedStrings.length > 0) {
        // Construct regex matching any of the matched words/phrases
        const escapedPhrases = matchedStrings.map(p => p.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&'));
        const uniquePhrases = Array.from(new Set(escapedPhrases));
        const fuzzyRegex = new RegExp(`(${uniquePhrases.join('|')})`, 'gi');
        
        matchCount += applyRegexHighlight(node, fuzzyRegex);
      }
    } else if (regex) {
      matchCount += applyRegexHighlight(node, regex);
    }
  });

  // 2.5 Gather all elements with matching attributes
  const allElements = document.body.querySelectorAll('*');
  allElements.forEach(el => {
    // Avoid highlighting scripts, styles, or the sitescope toolbar/badge itself
    const tag = el.tagName.toUpperCase();
    if (tag === 'SCRIPT' || tag === 'STYLE' || el.id === 'sitescope-toolbar' || el.closest('#sitescope-toolbar') || el.id === 'sitescope-attr-badge') {
      return;
    }
    if (el.hasAttribute('data-sitescope-attr-match')) return; // already matched by another term

    for (const attr of el.attributes) {
      const name = attr.name;
      const val = attr.value;

      if (checkStringMatch(val)) {
        let displayName = name;
        if (name === 'class') displayName = 'class';
        else if (name === 'id') displayName = 'id';
        else if (name.startsWith('data-')) displayName = name;

        el.setAttribute('data-sitescope-attr-match', `${displayName}="${val}"`);
        matchCount++;
        break; // Count only once per element
      }
    }
  });

  return matchCount;
}

// Highlight all audit terms on the page, then show the navigation toolbar
function highlightMatches(request) {
  const { keyword, matchMode, caseSensitive } = request;
  const terms = Array.isArray(request.terms) && request.terms.length ? request.terms : [keyword];
  terms.forEach(term => highlightTerm(term, matchMode, caseSensitive));

  // 3. Render toolbar navigation if matches exist
  const highlights = Array.from(document.querySelectorAll('mark.sitescope-highlight, [data-sitescope-attr-match]'));
  if (highlights.length > 0) {
    createNavigationToolbar(highlights, terms);
  } else {
    const label = terms.length > 1 ? `None of the ${terms.length} terms were` : `Keyword "${terms[0]}" was`;
    showNoticeToast(`SiteScope: ${label} found on this page. The content may have changed since the audit.`);
  }
}

function applyRegexHighlight(textNode, regex) {
  const text = textNode.nodeValue;
  // Use fresh regex with 'g' flag
  const gRegex = new RegExp(regex.source, regex.flags.includes('g') ? regex.flags : regex.flags + 'g');
  
  const matches = [];
  let m;
  while ((m = gRegex.exec(text)) !== null) {
    matches.push({
      index: m.index,
      text: m[0]
    });
    if (gRegex.lastIndex === m.index) gRegex.lastIndex++; // guard
  }

  if (matches.length === 0) return 0;

  const parent = textNode.parentNode;
  if (!parent) return 0;
  
  const fragment = document.createDocumentFragment();
  let lastIdx = 0;

  matches.forEach(match => {
    // Add text preceding match
    if (match.index > lastIdx) {
      fragment.appendChild(document.createTextNode(text.substring(lastIdx, match.index)));
    }
    // Add mark highlight node
    const mark = document.createElement('mark');
    mark.className = 'sitescope-highlight';
    mark.textContent = match.text;
    
    // Apply styling
    mark.style.backgroundColor = 'rgba(255, 215, 0, 0.35)';
    mark.style.borderBottom = '2px solid gold';
    mark.style.color = 'inherit';
    mark.style.borderRadius = '2px';
    mark.style.padding = '0px 2px';
    mark.style.transition = 'all 0.2s ease-out';
    
    fragment.appendChild(mark);
    lastIdx = match.index + match.text.length;
  });

  // Add trailing text
  if (lastIdx < text.length) {
    fragment.appendChild(document.createTextNode(text.substring(lastIdx)));
  }

  parent.replaceChild(fragment, textNode);
  return matches.length;
}

// Render floating navigation bar in target tab
function createNavigationToolbar(highlights, terms) {
  // Prevent duplicate bars
  const oldToolbar = document.getElementById('sitescope-toolbar');
  if (oldToolbar) oldToolbar.remove();

  // Floating attribute badge state. Must be declared before the first removeAttrBadge()
  // call below, otherwise it throws a TDZ ReferenceError and no toolbar is shown.
  let currentBadge = null;

  // Remove existing badges
  removeAttrBadge();

  let currentIndex = 0;

  const toolbar = document.createElement('div');
  toolbar.id = 'sitescope-toolbar';
  
  // Floating toolbar styling
  Object.assign(toolbar.style, {
    position: 'fixed',
    bottom: '24px',
    left: '50%',
    transform: 'translateX(-50%)',
    backgroundColor: '#0a0f1d',
    border: '1px solid #2b385c',
    borderRadius: '12px',
    padding: '12px 20px',
    zIndex: '10000000',
    display: 'flex',
    alignItems: 'center',
    gap: '16px',
    fontFamily: "'Outfit', sans-serif",
    color: '#ffffff',
    boxShadow: '0 8px 32px rgba(0, 0, 0, 0.6), 0 0 16px rgba(138, 43, 226, 0.2)',
    transition: 'all 0.3s ease'
  });

  // Info label
  const infoLabel = document.createElement('span');
  infoLabel.textContent = `1 of ${highlights.length} matches`;
  infoLabel.style.fontSize = '13px';
  infoLabel.style.fontWeight = '500';

  const termCount = Array.isArray(terms) ? terms.length : 1;
  const hintLabel = document.createElement('span');
  hintLabel.textContent = (termCount > 1 ? `${termCount} terms · ` : '') + 'Enter / Shift+Enter · Esc';
  Object.assign(hintLabel.style, { fontSize: '11px', color: '#8b9bb4' });

  // Navigation button creator
  const createNavBtn = (text, onClick) => {
    const btn = document.createElement('button');
    btn.textContent = text;
    Object.assign(btn.style, {
      backgroundColor: '#1b2644',
      border: '1px solid #37466f',
      borderRadius: '6px',
      color: '#ffffff',
      cursor: 'pointer',
      padding: '4px 10px',
      fontSize: '12px',
      fontWeight: '600',
      transition: 'all 0.2s'
    });
    btn.addEventListener('mouseenter', () => btn.style.backgroundColor = '#2c3b6b');
    btn.addEventListener('mouseleave', () => btn.style.backgroundColor = '#1b2644');
    btn.addEventListener('click', onClick);
    return btn;
  };

  const prevBtn = createNavBtn('◀ Prev', () => navigate(-1));
  const nextBtn = createNavBtn('Next ▶', () => navigate(1));

  const closeBtn = document.createElement('button');
  closeBtn.textContent = '×';
  Object.assign(closeBtn.style, {
    background: 'none',
    border: 'none',
    color: '#8b9bb4',
    cursor: 'pointer',
    fontSize: '20px',
    padding: '0 4px',
    lineHeight: '1',
    transition: 'color 0.2s'
  });
  closeBtn.addEventListener('mouseenter', () => closeBtn.style.color = '#ff4a4a');
  closeBtn.addEventListener('mouseleave', () => closeBtn.style.color = '#8b9bb4');
  closeBtn.addEventListener('click', () => {
    document.removeEventListener('keydown', onKey, true);
    toolbar.remove();
    removeAttrBadge();
    // Clear styles
    highlights.forEach(h => {
      if (h.hasAttribute('data-sitescope-attr-match')) {
        h.removeAttribute('data-sitescope-attr-match');
        h.classList.remove('sitescope-focused-attr');
      } else {
        h.style.backgroundColor = 'transparent';
        h.style.borderBottom = 'none';
      }
    });
  });

  toolbar.appendChild(infoLabel);
  toolbar.appendChild(prevBtn);
  toolbar.appendChild(nextBtn);
  toolbar.appendChild(hintLabel);
  toolbar.appendChild(closeBtn);
  document.body.appendChild(toolbar);

  // Keyboard navigation: Enter / F3 = next, Shift+Enter / Shift+F3 = previous, Esc = close.
  // Ignored while the user is typing in a form field on the page.
  function onKey(e) {
    const t = e.target;
    if (t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName))) return;
    if (e.key === 'Enter' || e.key === 'F3') {
      e.preventDefault();
      navigate(e.shiftKey ? -1 : 1);
    } else if (e.key === 'Escape') {
      closeBtn.click();
    }
  }
  document.addEventListener('keydown', onKey, true);

  // (currentBadge is declared at the top of this function: removeAttrBadge() runs before this point)

  function showAttrBadge(element, attrInfo) {
    removeAttrBadge();
    
    const badge = document.createElement('div');
    badge.id = 'sitescope-attr-badge';
    badge.textContent = `Attribute Match: ${attrInfo}`;
    
    Object.assign(badge.style, {
      position: 'absolute',
      backgroundColor: '#8a2be2',
      color: '#ffffff',
      padding: '6px 12px',
      borderRadius: '6px',
      fontSize: '11px',
      fontWeight: 'bold',
      fontFamily: "'Outfit', sans-serif",
      zIndex: '10000002',
      boxShadow: '0 4px 16px rgba(0,0,0,0.6)',
      pointerEvents: 'none',
      whiteSpace: 'nowrap',
      transition: 'opacity 0.2s ease'
    });
    
    document.body.appendChild(badge);
    currentBadge = badge;
    
    positionBadge(element, badge);
  }

  function positionBadge(element, badge) {
    const rect = element.getBoundingClientRect();
    const badgeRect = badge.getBoundingClientRect();
    
    let top = rect.top + window.scrollY - badgeRect.height - 6;
    let left = rect.left + window.scrollX;
    
    // Fallback if top is offscreen
    if (rect.top < badgeRect.height + 12) {
      top = rect.bottom + window.scrollY + 6;
    }
    
    badge.style.top = `${top}px`;
    badge.style.left = `${left}px`;
  }

  function removeAttrBadge() {
    if (currentBadge) {
      currentBadge.remove();
      currentBadge = null;
    }
    const oldBadge = document.getElementById('sitescope-attr-badge');
    if (oldBadge) oldBadge.remove();
  }

  // Focus first match immediately
  focusHighlight(0);

  function navigate(direction) {
    // Clear active status on current
    resetActiveHighlight(currentIndex);

    currentIndex = (currentIndex + direction + highlights.length) % highlights.length;
    infoLabel.textContent = `${currentIndex + 1} of ${highlights.length} matches`;

    focusHighlight(currentIndex);
  }

  function focusHighlight(index) {
    const el = highlights[index];
    el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    
    if (el.hasAttribute('data-sitescope-attr-match')) {
      el.classList.add('sitescope-focused-attr');
      showAttrBadge(el, el.getAttribute('data-sitescope-attr-match'));
    } else {
      // Apply energetic glowing state
      el.style.backgroundColor = '#8a2be2'; // vibrant purple
      el.style.color = '#ffffff';
      el.style.boxShadow = '0 0 10px #8a2be2';
    }
  }

  function resetActiveHighlight(index) {
    const el = highlights[index];
    if (el.hasAttribute('data-sitescope-attr-match')) {
      el.classList.remove('sitescope-focused-attr');
      removeAttrBadge();
    } else {
      el.style.backgroundColor = 'rgba(255, 215, 0, 0.35)';
      el.style.color = 'inherit';
      el.style.boxShadow = 'none';
    }
  }
}

function showNoticeToast(message) {
  const toast = document.createElement('div');
  toast.textContent = message;
  Object.assign(toast.style, {
    position: 'fixed',
    top: '24px',
    right: '24px',
    backgroundColor: '#0a0f1d',
    border: '1px solid #ff4a4a',
    borderRadius: '8px',
    padding: '12px 20px',
    color: '#ffffff',
    fontFamily: "'Outfit', sans-serif",
    fontSize: '13px',
    boxShadow: '0 4px 12px rgba(0,0,0,0.5)',
    zIndex: '10000001',
    animation: 'slideIn 0.3s ease-out'
  });
  
  // Simple style inject for keyframe
  if (!document.getElementById('sitescope-toast-style')) {
    const style = document.createElement('style');
    style.id = 'sitescope-toast-style';
    style.innerHTML = `@keyframes slideIn { from { transform: translateX(50px); opacity: 0; } to { transform: translateX(0); opacity: 1; } }`;
    document.head.appendChild(style);
  }
  
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 4000);
}

// Messaging listener
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'HIGHLIGHT_DOM') {
    highlightMatches(message);
    sendResponse({ success: true });
  }
  return true;
});
