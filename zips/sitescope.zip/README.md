# SiteScope - Content Auditor

SiteScope crawls a whole website from inside your own browser and finds every place a word, phrase or pattern appears: visible text, page titles, meta descriptions, image alt text, aria-labels, placeholders, IDs, classes and other HTML attributes. Because it runs in your browser session, it also works on staging sites, intranets and pages behind a login. All results stay on your computer.

## Features

- **Whole-site or single-page scans** with a configurable page limit (up to 1,000 pages).
- **Three search modes**: exact match (whitespace-tolerant), regular expressions, and fuzzy matching (catches typos).
- **Deep search** across visible text, title, meta description, alt text, aria-labels, placeholders, IDs, classes, `data-*` and other attributes.
- **Smart discovery**: reads `sitemap.xml`, sitemap indexes and `Sitemap:` lines in `robots.txt`, then follows same-site links.
- **Polite crawling**: respects `robots.txt` (optional), limits concurrency, and backs off automatically on HTTP 429/503.
- **Exclude URLs**: skip any URL containing the patterns you list (for example `/tag/, /wp-admin`). Images, PDFs and other files are skipped automatically.
- **JS rendering** (optional) for single-page apps: pages are rendered in a background tab before they are searched.
- **Dashboard** with audit history, filters, per-page match breakdown and "Highlight in Context", which opens the page and highlights every match.
- **Export** to CSV, JSON, or PDF (print).

## Install (Load unpacked)

1. Download the ZIP and extract it to a folder.
2. Open `chrome://extensions` in Chrome (or another Chromium browser).
3. Turn on **Developer mode** (top right).
4. Click **Load unpacked** and select the extracted folder (the one that contains `manifest.json`).
5. Pin SiteScope from the extensions menu.

## How to use

1. Open any page of the site you want to audit.
2. Click the SiteScope icon, enter a keyword or pattern, and choose the scope and options.
3. Click **Start Audit**. Progress appears in the popup.
4. Click **Dashboard** to see results, filter them, highlight matches on a page, or export.

## Permissions

| Permission | Why it is needed |
| --- | --- |
| Access to `http://*/*` and `https://*/*` | To fetch the pages of the site you choose to audit, and to read the current tab's address. SiteScope only requests pages from the site you start an audit on. |
| `storage` | Saves the crawl progress so an audit can continue if the browser suspends the background worker. |
| `scripting` | Injects the highlighter when you click "Highlight in Context", and reads the rendered page when JS rendering is on. |
| `offscreen` | Uses a hidden extension page to parse HTML quickly without opening visible tabs. |

## Privacy

SiteScope has no server. Audit history and results are stored in your browser (IndexedDB) and never leave your computer. The only network requests it makes are to the website you are auditing.
