# SiteScope - Content Auditor

SiteScope crawls a whole website from inside your own browser and finds every place a word, phrase or pattern appears: visible text, page titles, meta descriptions, image alt text, aria-labels, placeholders, IDs, classes and other HTML attributes. Because it runs in your browser session, it also works on staging sites, intranets and pages behind a login. All results stay on your computer.

## Features

- **Several terms in one crawl**: put one keyword, phrase or pattern per line (up to 20). The report shows how often each term appears and on how many pages, and you can filter by term.
- **Whole-site or single-page scans** with a configurable page limit (up to 1,000 pages).
- **Crawl speed**: Gentle (one page at a time), Normal, or Fast (four in parallel), so you can be kind to small servers or quick on your own staging site.
- **Three search modes**: exact match (whitespace-tolerant), regular expressions, and fuzzy matching (catches typos).
- **Deep search** across visible text, title, meta description, alt text, aria-labels, placeholders, IDs, classes, `data-*` and other attributes.
- **Smart discovery**: reads `sitemap.xml`, sitemap indexes and `Sitemap:` lines in `robots.txt`, then follows same-site links.
- **Polite crawling**: respects `robots.txt` (optional) including `Allow` overrides and `Crawl-delay`, limits concurrency, backs off automatically on HTTP 429/503 and honours `Retry-After`. If `robots.txt` itself returns a server error, the crawl does not start (RFC 9309).
- **Safe with your login**: pages are fetched with your browser cookies, so members-only and staging pages work, and sign-out links (`/logout`, `sign-out`, ...) are never followed, so an audit cannot log you out.
- **Exclude URLs**: skip any URL containing the patterns you list (for example `/tag/, /wp-admin`). Images, PDFs and other files are skipped automatically.
- **JS rendering** (optional) for single-page apps: pages are rendered in a background tab before they are searched.
- **Dashboard** with audit history, filters, per-page match breakdown and "Highlight in Context", which opens the page and highlights every match.
- **Compare with the previous run**: re-run an audit and the dashboard shows how many pages were fixed, which have new matches, and which have more or fewer, with a filter for each and a change tag on every row. The comparison is also in the CSV, JSON and HTML exports.
- **Sortable results**: sort the table by status, URL or match count. CSV export follows the current filters and order.
- **History that cleans itself up**: keep the last 10, 25, 50 (default) or 100 audits and optionally delete audits older than 7 to 365 days. The sidebar shows how much is stored and has a "Delete all audits" button.
- **Recheck a single page** from the report after you fix it, without re-crawling the whole site.
- **Re-run an audit** with the same settings in one click.
- **Shareable HTML report**: a standalone, light-themed file anyone can open in a browser.
- **Export** to CSV (Excel-friendly UTF-8, formula-safe), JSON, or PDF (print).
- **Remembers your settings** between sessions, and shows a short guide the first time you open it.

## Install (Load unpacked)

1. Download the ZIP and extract it to a folder.
2. Open `chrome://extensions` in Chrome (or another Chromium browser).
3. Turn on **Developer mode** (top right).
4. Click **Load unpacked** and select the extracted folder (the one that contains `manifest.json`).
5. Pin SiteScope from the extensions menu.

## How to use

1. Open any page of the site you want to audit.
2. Click the SiteScope icon, enter a keyword or pattern, and choose the scope and options.
3. Click **Start Audit** (or press `Ctrl+Enter`). Progress appears in the popup.
4. Click **Dashboard** to see results. Click a term chip to filter by term, open **View Matches** for context, **Highlight in Context** to see matches on the live page, or the ↻ button to recheck one page.
5. Use **Share HTML Report**, CSV, JSON or Print/PDF to export, or **Re-run** to repeat the audit later.

Version 1.4.0 adds no new permissions.

## Keyboard shortcuts

| Where | Shortcut | Action |
| --- | --- | --- |
| Anywhere | `Alt+Shift+S` | Open the SiteScope popup (change it at `chrome://extensions/shortcuts`) |
| Popup | `Ctrl+Enter` (`Cmd+Enter` on Mac) | Start the audit |
| Dashboard | `/` | Focus the URL filter |
| Dashboard | `Esc` | Clear the URL filter |
| Dashboard history | `Enter` / `Delete` | Open / delete the focused audit |
| Highlighted page | `Enter` / `F3` | Next match (`Enter` only when no link or field has focus) |
| Highlighted page | `Shift+Enter` / `Shift+F3` | Previous match |
| Highlighted page | `Esc` | Remove highlights and close the toolbar |

## Permissions

| Permission | Why it is needed |
| --- | --- |
| Access to `http://*/*` and `https://*/*` | To fetch the pages of the site you choose to audit, and to read the current tab's address. SiteScope only requests pages from the site you start an audit on. |
| `storage` | Saves the crawl progress so an audit can continue if the browser suspends the background worker, and remembers your popup and history settings. |
| `scripting` | Injects the highlighter (and its stylesheet) when you click "Highlight in Context", and reads the rendered page when JS rendering is on. Nothing is injected into pages otherwise. |
| `offscreen` | Uses a hidden extension page to parse HTML quickly without opening visible tabs. |

## Privacy

SiteScope has no server. Audit history and results are stored in your browser (IndexedDB) and never leave your computer; old audits are deleted automatically according to the history setting in the dashboard. The only network requests it makes are to the website you are auditing. The on-page highlighter toolbar is kept in a closed shadow root, so the audited page's scripts cannot read it.
