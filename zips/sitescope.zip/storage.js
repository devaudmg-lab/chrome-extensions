// SiteScope IndexedDB Storage Utility (ES Module)

const DB_NAME = 'SiteScopeDB';
const DB_VERSION = 1;

let dbPromise = null;

/**
 * Open or upgrade the IndexedDB database.
 * The connection is cached so a long crawl does not open hundreds of connections.
 */
function openDB() {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onerror = () => {
      dbPromise = null;
      reject(request.error);
    };
    request.onsuccess = () => {
      const db = request.result;
      // Drop the cached handle if the browser closes the connection
      db.onclose = () => { dbPromise = null; };
      db.onversionchange = () => { db.close(); dbPromise = null; };
      resolve(db);
    };

    request.onupgradeneeded = (event) => {
      const db = request.result;

      // Audits metadata store
      if (!db.objectStoreNames.contains('audits')) {
        db.createObjectStore('audits', { keyPath: 'id', autoIncrement: true });
      }

      // Detailed page scan results store
      if (!db.objectStoreNames.contains('results')) {
        const resultsStore = db.createObjectStore('results', { keyPath: 'id', autoIncrement: true });
        // Index by auditId to query results for a specific scan session
        resultsStore.createIndex('auditId', 'auditId', { unique: false });
      }
    };
  });
  return dbPromise;
}

/**
 * Create a new audit session in DB and return the generated ID.
 */
export async function createAudit(auditData) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction('audits', 'readwrite');
    const store = transaction.objectStore('audits');
    
    const record = {
      startTime: Date.now(),
      endTime: null,
      domain: auditData.domain || '',
      keyword: auditData.keyword || '',
      caseSensitive: !!auditData.caseSensitive,
      status: 'running',
      totalCrawled: 0,
      totalMatches: 0,
      errorCount: 0,
      ...auditData
    };

    const request = store.add(record);
    request.onsuccess = () => resolve(request.result); // Returns the auto-incremented auditId
    request.onerror = () => reject(request.error);
  });
}

/**
 * Update an existing audit metadata record.
 */
export async function updateAudit(auditId, updateFields) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction('audits', 'readwrite');
    const store = transaction.objectStore('audits');
    
    // Retrieve first
    const getReq = store.get(auditId);
    getReq.onsuccess = () => {
      const data = getReq.result;
      if (!data) {
        reject(new Error(`Audit with ID ${auditId} not found`));
        return;
      }
      
      const updated = { ...data, ...updateFields };
      const putReq = store.put(updated);
      putReq.onsuccess = () => resolve(true);
      putReq.onerror = () => reject(putReq.error);
    };
    getReq.onerror = () => reject(getReq.error);
  });
}

/**
 * Add a page scan result.
 */
export async function addPageResult(resultData) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction('results', 'readwrite');
    const store = transaction.objectStore('results');

    const record = {
      auditId: resultData.auditId,
      url: resultData.url,
      status: resultData.status || 200,
      matchCount: resultData.matchCount || 0,
      matches: resultData.matches || [],
      error: resultData.error || null,
      scannedTime: Date.now()
    };
    // Where the page ended up after redirects (only stored when it differs)
    if (resultData.finalUrl) record.finalUrl = resultData.finalUrl;

    const request = store.add(record);
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

/**
 * Get audit metadata.
 */
export async function getAudit(auditId) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction('audits', 'readonly');
    const store = transaction.objectStore('audits');
    const request = store.get(auditId);
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

/**
 * Get all page results associated with an audit session.
 */
export async function getAuditResults(auditId) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction('results', 'readonly');
    const store = transaction.objectStore('results');
    const index = store.index('auditId');
    const request = index.getAll(IDBKeyRange.only(auditId));
    
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

/**
 * Get the history of all audits sorted by starting time (newest first).
 */
export async function getAuditHistory() {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction('audits', 'readonly');
    const store = transaction.objectStore('audits');
    const request = store.getAll();
    
    request.onsuccess = () => {
      const records = request.result || [];
      // Sort descending by startTime
      records.sort((a, b) => b.startTime - a.startTime);
      resolve(records);
    };
    request.onerror = () => reject(request.error);
  });
}

/**
 * Delete an entire audit and its related page results.
 */
export async function deleteAudit(auditId) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(['audits', 'results'], 'readwrite');
    
    // Delete audit metadata
    const auditStore = transaction.objectStore('audits');
    auditStore.delete(auditId);
    
    // Delete associated page results using a cursor
    const resultsStore = transaction.objectStore('results');
    const index = resultsStore.index('auditId');
    const request = index.openCursor(IDBKeyRange.only(auditId));
    
    request.onsuccess = (event) => {
      const cursor = event.target.result;
      if (cursor) {
        cursor.delete();
        cursor.continue();
      }
    };
    
    transaction.oncomplete = () => resolve(true);
    transaction.onerror = () => reject(transaction.error);
    transaction.onabort = () => reject(transaction.error || new Error('Delete aborted'));
  });
}

/**
 * Merge new fields into a stored page result (used by "Recheck page").
 */
export async function updatePageResult(resultId, updateFields) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction('results', 'readwrite');
    const store = transaction.objectStore('results');
    const getReq = store.get(resultId);
    getReq.onsuccess = () => {
      const data = getReq.result;
      if (!data) {
        reject(new Error(`Result with ID ${resultId} not found`));
        return;
      }
      const putReq = store.put({ ...data, ...updateFields });
      putReq.onsuccess = () => resolve(true);
      putReq.onerror = () => reject(putReq.error);
    };
    getReq.onerror = () => reject(getReq.error);
  });
}

/**
 * Delete every audit (and its page results) that falls outside the retention policy:
 * more than `maxAudits` newest audits, or older than `maxAgeDays`. Audits listed in
 * `keepIds` (the running audit) are never removed. Returns the number of audits deleted.
 */
export async function pruneAudits({ maxAudits = 0, maxAgeDays = 0, keepIds = [], deleteAll = false } = {}) {
  const history = await getAuditHistory(); // newest first
  const keep = new Set(keepIds.filter(id => id != null));
  const cutoff = maxAgeDays > 0 ? Date.now() - maxAgeDays * 86400000 : 0;
  const doomed = [];
  let kept = 0;
  for (const audit of history) {
    if (keep.has(audit.id)) { kept++; continue; }
    const tooMany = deleteAll || (maxAudits > 0 && kept >= maxAudits);
    const tooOld = cutoff > 0 && (audit.startTime || 0) < cutoff;
    if (tooMany || tooOld) doomed.push(audit.id);
    else kept++;
  }
  for (const id of doomed) await deleteAudit(id);

  // Page results whose audit no longer exists (e.g. written while it was being deleted)
  const known = new Set(history.map(a => a.id));
  for (const auditId of await getResultAuditIds()) {
    if (!known.has(auditId)) await deleteAudit(auditId);
  }
  return doomed.length;
}

// Distinct audit ids referenced by stored page results (walks the index keys only)
async function getResultAuditIds() {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const ids = [];
    const tx = db.transaction('results', 'readonly');
    const req = tx.objectStore('results').index('auditId').openKeyCursor(null, 'nextunique');
    req.onsuccess = () => {
      const cursor = req.result;
      if (cursor) {
        ids.push(cursor.key);
        cursor.continue();
      }
    };
    tx.oncomplete = () => resolve(ids);
    tx.onerror = () => reject(tx.error);
  });
}

/**
 * Audits left in the "running" state by a crash, a browser restart or a deleted crawl
 * would show as "Live" forever. Mark every running audit except `activeId` as stopped.
 */
export async function markInterruptedAudits(activeId) {
  const history = await getAuditHistory();
  for (const audit of history) {
    if (audit.status === 'running' && audit.id !== activeId) {
      await updateAudit(audit.id, {
        status: 'stopped',
        interrupted: true,
        endTime: audit.endTime || null
      });
    }
  }
}

/**
 * Number of stored audits and page results (shown in the dashboard's storage panel).
 */
export async function getStorageCounts() {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(['audits', 'results'], 'readonly');
    const counts = { audits: 0, results: 0 };
    const a = tx.objectStore('audits').count();
    const r = tx.objectStore('results').count();
    a.onsuccess = () => { counts.audits = a.result; };
    r.onsuccess = () => { counts.results = r.result; };
    tx.oncomplete = () => resolve(counts);
    tx.onerror = () => reject(tx.error);
  });
}
