// SiteScope Background Crawler Service Worker (Manifest V3)
import {
  createAudit, updateAudit, addPageResult, getAudit, getAuditResults, updatePageResult,
  deleteAudit, pruneAudits, markInterruptedAudits
} from './storage.js';

// State object (persisted to chrome.storage.local so a crawl survives the worker being suspended)
let crawlerState = {
  currentAuditId: null,
  status: 'idle', // 'idle' | 'running' | 'paused' | 'stopped' | 'completed'
  domain: '',
  origin: '',
  keyword: '',
  caseSensitive: false,
  respectRobots: true,
  useSitemap: true,
  jsRendering: false,
  matchMode: 'exact', // 'exact' | 'regex' | 'fuzzy'
  robotsRules: [],
  queue: [],
  crawled: [],
  inFlight: [],
  errorCount: 0,
  totalMatches: 0
};

const CRAWL_LIMIT = 1000;
// Discovered URLs beyond this are dropped: they could never be crawled within the page cap
// and would only bloat the state that is written to storage after every page.
const MAX_QUEUE = 5000;
// Pages bigger than this are cut before parsing, to keep memory and message size bounded
const MAX_HTML_CHARS = 5 * 1024 * 1024;
const FETCH_TIMEOUT = 30000;
const ROBOTS_TIMEOUT = 10000;

// Rate-limit backoff (HTTP 429/503): doubles on each hit, honours Retry-After, capped
const INITIAL_BACKOFF = 5000;
const MAX_BACKOFF = 5 * 60 * 1000;
let backoffDelay = INITIAL_BACKOFF;

// Crawl-delay from robots.txt is honoured up to this many seconds
const MAX_CRAWL_DELAY = 30;

// User-selectable crawl speed: parallel workers and the pause each worker takes between pages
const SPEED_PRESETS = {
  gentle: { concurrency: 1, delay: 1500 },
  normal: { concurrency: 2, delay: 500 },
  fast: { concurrency: 4, delay: 150 }
};
function speedPreset(st = crawlerState) {
  return SPEED_PRESETS[st.speed] || SPEED_PRESETS.normal;
}
// A robots.txt Crawl-delay means one request at a time, at least that far apart
function maxConcurrency(st = crawlerState) {
  return st.crawlDelay > 0 ? 1 : speedPreset(st).concurrency;
}
function politenessDelay(st = crawlerState) {
  return Math.max(speedPreset(st).delay, (st.crawlDelay || 0) * 1000);
}
function pageLimit(st = crawlerState) {
  return st.scanScope === 'page' ? 1 : (st.maxPages || CRAWL_LIMIT);
}
function isBusy(st = crawlerState) {
  return st.status === 'running' || st.status === 'paused';
}

const MAX_TERMS = 20;
// The keyword box accepts one term per line; return a de-duplicated list
function parseTerms(raw) {
  const seen = new Set();
  const terms = [];
  String(raw || '').split(/\r?\n/).forEach(line => {
    const t = line.trim();
    if (t && !seen.has(t) && terms.length < MAX_TERMS) {
      seen.add(t);
      terms.push(t);
    }
  });
  return terms;
}

// Wait without letting the service worker fall asleep: an extension API call every
// 20 s resets the idle timer, so long backoffs and crawl delays do not stall the crawl.
async function sleep(ms) {
  const end = Date.now() + ms;
  for (;;) {
    const left = end - Date.now();
    if (left <= 0) return;
    await new Promise(r => setTimeout(r, Math.min(left, 20000)));
    if (end - Date.now() > 0) chrome.runtime.getPlatformInfo().catch(() => {});
  }
}

// fetch() with a timeout, so one hanging server cannot block a worker forever
async function fetchWithTimeout(url, options = {}, timeout = FETCH_TIMEOUT) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  try {
    return await fetch(url, { ...options, signal: controller.signal });
  } catch (err) {
    if (err && err.name === 'AbortError') throw new Error(`Timed out after ${Math.round(timeout / 1000)}s`);
    throw err;
  } finally {
    clearTimeout(timer);
  }
}

// Page requests carry the user's cookies, so audits work on sites behind a login
function fetchPage(url, extra = {}) {
  return fetchWithTimeout(url, {
    method: 'GET',
    headers: { 'Accept': 'text/html,application/xhtml+xml' },
    credentials: 'include',
    ...extra
  });
}

// Retry-After is either a number of seconds or an HTTP date
function parseRetryAfter(value) {
  if (!value) return 0;
  const secs = Number(value);
  if (Number.isFinite(secs)) return Math.max(0, secs * 1000);
  const date = Date.parse(value);
  return Number.isFinite(date) ? Math.max(0, date - Date.now()) : 0;
}

function cancelBody(response) {
  try { if (response.body) response.body.cancel().catch(() => {}); } catch (e) { /* ignore */ }
}

let creatingOffscreen = null;
// Ensure the offscreen parser document exists. The whole check-and-create sequence is
// shared through one promise, so concurrent workers cannot race into double creation.
function setupOffscreenDocument(path) {
  if (creatingOffscreen) return creatingOffscreen;

  creatingOffscreen = (async () => {
    try {
      const contexts = await chrome.runtime.getContexts({
        contextTypes: ['OFFSCREEN_DOCUMENT'],
        documentUrls: [chrome.runtime.getURL(path)]
      });
      if (contexts.length > 0) return;
    } catch (e) {
      // getContexts unavailable; fall through and try to create
    }

    try {
      await chrome.offscreen.createDocument({
        url: path,
        reasons: ['DOM_PARSER'],
        justification: 'Parse HTML to search for keywords'
      });
    } catch (err) {
      if (!String(err && err.message).includes('Only a single offscreen document')) {
        console.warn('Offscreen creation failed:', err && err.message);
      }
    }
  })().finally(() => {
    creatingOffscreen = null;
  });

  return creatingOffscreen;
}

// The parser page is only needed while pages are being searched; free its memory afterwards
let rescansInProgress = 0;
async function closeOffscreenIfIdle() {
  if (isBusy() || rescansInProgress > 0) return;
  try {
    await chrome.offscreen.closeDocument();
  } catch (e) { /* not open */ }
}

// Send HTML to the offscreen document for parsing, retrying briefly if it is not listening yet
async function parseInOffscreen(payload) {
  for (let attempt = 0; attempt < 3; attempt++) {
    await setupOffscreenDocument('offscreen.html');
    const res = await new Promise((resolve) => {
      chrome.runtime.sendMessage(payload, (r) => {
        void chrome.runtime.lastError; // receiver not ready yet; retried below
        resolve(r);
      });
    });
    if (res) return res;
    await new Promise(r => setTimeout(r, 200 * (attempt + 1)));
  }
  return null;
}

// Helpers to load/save state
async function saveStateToStorage() {
  try {
    await chrome.storage.local.set({ crawlerState });
  } catch (e) {
    console.warn('Could not save crawl state:', e && e.message);
  }
}

// File types that are never HTML pages; skipping them avoids downloading binaries
const NON_HTML_EXT = /\.(pdf|jpe?g|png|gif|webp|svg|ico|bmp|tiff?|avif|mp4|webm|mov|avi|mkv|mp3|wav|ogg|m4a|zip|rar|7z|gz|tar|exe|dmg|msi|apk|iso|docx?|xlsx?|pptx?|csv|json|xml|rss|txt|css|js|woff2?|ttf|otf|eot)$/i;

// Links a crawler must never follow while it carries the user's session: they would
// sign the user out of the site being audited.
const SESSION_ENDING = /(^|[\/_.?&=-])(log-?out|log-?off|sign-?out|signoff)([\/_.?&=#-]|$)/i;

function isCrawlableUrl(url) {
  try {
    const u = new URL(url);
    if (NON_HTML_EXT.test(u.pathname)) return false;
    if (SESSION_ENDING.test(u.pathname + u.search)) return false;
    return true;
  } catch (e) {
    return false;
  }
}

// User-defined exclusions: a URL is skipped when it contains any of the patterns
function isExcluded(url, patterns) {
  if (!patterns || patterns.length === 0) return false;
  const lower = url.toLowerCase();
  return patterns.some(p => lower.includes(p));
}

function parseExcludePatterns(raw) {
  if (Array.isArray(raw)) raw = raw.join(',');
  return String(raw || '')
    .split(/[,\n]/)
    .map(p => p.trim().toLowerCase())
    .filter(Boolean)
    .slice(0, 50);
}

function decodeXmlEntities(str) {
  return str
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&amp;/g, '&');
}

// Should a discovered same-origin URL be queued?
function shouldQueue(url, st = crawlerState) {
  if (!isCrawlableUrl(url)) return false;
  if (isExcluded(url, st.excludePatterns)) return false;
  if (st.respectRobots && !isUrlAllowed(url, st.robotsRules)) return false;
  return true;
}

// Robots.txt parser (RFC 9309). Consecutive User-agent lines form one group; a group
// that names SiteScope wins over the "*" group. Returns the allow/disallow rules of the
// chosen group(s), the global Sitemap entries and the Crawl-delay in seconds.
function parseRobotsTxt(content) {
  const groups = [];
  const sitemaps = [];
  let current = null;
  let lastWasAgent = false;

  for (let line of String(content || '').split(/\r?\n/)) {
    line = line.replace(/#.*$/, '').trim();
    if (!line) continue;
    const colonIdx = line.indexOf(':');
    if (colonIdx === -1) continue;

    const key = line.substring(0, colonIdx).trim().toLowerCase();
    const value = line.substring(colonIdx + 1).trim();

    if (key === 'user-agent') {
      if (!current || !lastWasAgent) {
        current = { agents: [], rules: [], crawlDelay: 0 };
        groups.push(current);
      }
      current.agents.push(value.toLowerCase());
      lastWasAgent = true;
      continue;
    }
    lastWasAgent = false;

    if (key === 'sitemap') {
      // Sitemap directives are global (not tied to a user-agent group)
      if (value) sitemaps.push({ type: 'sitemap', path: value });
    } else if (current && (key === 'disallow' || key === 'allow')) {
      if (value) current.rules.push({ type: key, path: value });
    } else if (current && key === 'crawl-delay') {
      const d = parseFloat(value);
      if (Number.isFinite(d) && d > 0) current.crawlDelay = d;
    }
  }

  const own = groups.filter(g => g.agents.some(a => a.includes('sitescope')));
  const chosen = own.length ? own : groups.filter(g => g.agents.includes('*'));
  const rules = [];
  let crawlDelay = 0;
  chosen.forEach(g => {
    rules.push(...g.rules);
    crawlDelay = Math.max(crawlDelay, g.crawlDelay);
  });
  return {
    rules: rules.concat(sitemaps),
    crawlDelay: Math.min(crawlDelay, MAX_CRAWL_DELAY)
  };
}

// Robots.txt checker: the longest matching rule wins; on a tie, Allow wins
function isUrlAllowed(url, rules) {
  try {
    const parsed = new URL(url);
    const path = parsed.pathname + parsed.search;
    const sortedRules = (rules || [])
      .filter(r => r.type === 'allow' || r.type === 'disallow')
      .sort((a, b) => (b.path.length - a.path.length) || (a.type === 'allow' ? -1 : 1));

    for (const rule of sortedRules) {
      // '*' is a wildcard; a trailing '$' anchors the end of the path (robots.txt spec)
      const anchored = rule.path.endsWith('$');
      const rawPath = anchored ? rule.path.slice(0, -1) : rule.path;
      const rulePathEscaped = rawPath.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&').replace(/\\\*/g, '.*');
      const ruleRegex = new RegExp('^' + rulePathEscaped + (anchored ? '$' : ''));
      if (ruleRegex.test(path)) {
        return rule.type === 'allow';
      }
    }
  } catch (e) {
    // Ignore
  }
  return true;
}

// Extract URLs from XML sitemaps
function extractSitemapUrls(xmlText) {
  const urls = [];
  const regex = /<loc>([\s\S]*?)<\/loc>/gi;
  let match;
  while ((match = regex.exec(xmlText)) !== null) {
    const u = match[1].trim();
    const cleanUrl = decodeXmlEntities(u.replace(/^<!\[CDATA\[([\s\S]*?)\]\]>$/i, '$1').trim());
    if (cleanUrl) urls.push(cleanUrl);
  }
  return urls;
}

// Collect page URLs from sitemaps, following <sitemapindex> files (bounded to avoid runaway fetches)
async function collectSitemapUrls(startUrls, origin, limit) {
  const MAX_SITEMAPS = 20;
  const pending = [...new Set(startUrls)];
  const seen = new Set();
  const pages = [];

  while (pending.length > 0 && seen.size < MAX_SITEMAPS && pages.length < limit) {
    const smUrl = pending.shift();
    if (seen.has(smUrl)) continue;
    seen.add(smUrl);

    try {
      const resp = await fetchWithTimeout(smUrl, { credentials: 'include' }, 15000);
      if (!resp.ok) { cancelBody(resp); continue; }
      const xml = await resp.text();
      const locs = extractSitemapUrls(xml);

      if (/<sitemapindex[\s>]/i.test(xml)) {
        for (const loc of locs) {
          try {
            if (new URL(loc).origin === origin && !seen.has(loc)) pending.push(loc);
          } catch (e) { /* ignore */ }
        }
      } else {
        for (const loc of locs) {
          pages.push(loc);
          if (pages.length >= limit) break;
        }
      }
    } catch (err) {
      // A missing or slow sitemap is normal; link discovery still works
    }
  }
  return pages;
}

// Tabs opened for JS rendering are remembered in session storage, so a tab left open by
// a suspended worker can be closed the next time the worker starts.
async function trackRenderTab(tabId, add) {
  try {
    const { renderTabs = [] } = await chrome.storage.session.get('renderTabs');
    const next = add ? [...renderTabs, tabId] : renderTabs.filter(id => id !== tabId);
    await chrome.storage.session.set({ renderTabs: next });
  } catch (e) { /* ignore */ }
}

async function closeLeftoverRenderTabs() {
  try {
    const { renderTabs = [] } = await chrome.storage.session.get('renderTabs');
    for (const id of renderTabs) await chrome.tabs.remove(id).catch(() => {});
    await chrome.storage.session.set({ renderTabs: [] });
  } catch (e) { /* ignore */ }
}

// Resolve true once the tab has finished loading, false if it is closed or times out.
// The tab may already be complete before the listener is attached, so its status is
// checked right after subscribing.
function waitForTabComplete(tabId, timeout) {
  return new Promise((resolve) => {
    let done = false;
    const finish = (ok) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      chrome.tabs.onUpdated.removeListener(onUpdated);
      chrome.tabs.onRemoved.removeListener(onRemoved);
      resolve(ok);
    };
    const timer = setTimeout(() => finish(false), timeout);
    function onUpdated(id, info) { if (id === tabId && info.status === 'complete') finish(true); }
    function onRemoved(id) { if (id === tabId) finish(false); }
    chrome.tabs.onUpdated.addListener(onUpdated);
    chrome.tabs.onRemoved.addListener(onRemoved);
    chrome.tabs.get(tabId).then(t => {
      if (t && t.status === 'complete' && !t.pendingUrl && t.url && t.url !== 'about:blank') finish(true);
    }).catch(() => finish(false));
  });
}

// Render a page in a background tab and return its final DOM
async function fetchSPA(url) {
  const tab = await chrome.tabs.create({ url, active: false });
  if (!tab) throw new Error('Failed to create background tab');
  const tabId = tab.id;
  await trackRenderTab(tabId, true);

  try {
    if (!(await waitForTabComplete(tabId, 20000))) throw new Error('JS render timeout');
    // Give client-side frameworks a moment to render after the load event
    await new Promise(r => setTimeout(r, 1000));
    const current = await chrome.tabs.get(tabId).catch(() => null);
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      func: () => document.documentElement.outerHTML
    });
    return {
      status: 200,
      html: (results && results[0] && results[0].result) || '',
      url: (current && current.url) || url
    };
  } finally {
    await chrome.tabs.remove(tabId).catch(() => {});
    await trackRenderTab(tabId, false);
  }
}

// ---------------------------------------------------------------------------
// Crawl workers
// ---------------------------------------------------------------------------
// One pool per audit. Workers hold a reference to their pool; when a new audit starts,
// the pool is replaced and old workers (and their in-flight results) become stale.
let pool = null;

function startWorkers() {
  const st = crawlerState;
  const p = {
    auditId: st.currentAuditId,
    state: st,
    active: 0,
    seen: new Set([...(st.crawled || []), ...(st.queue || [])])
  };
  pool = p;
  for (let i = 0; i < maxConcurrency(st); i++) {
    workerLoop(p).catch(err => console.warn('Crawl worker stopped:', err && err.message));
  }
}

function removeFirst(arr, value) {
  const i = arr.indexOf(value);
  if (i !== -1) arr.splice(i, 1);
}

async function workerLoop(p) {
  const st = p.state;
  while (pool === p) {
    if (st.status === 'paused') {
      // Rate-limit backoff: every worker waits until the pause is over
      const wait = (st.resumeAt || 0) - Date.now();
      if (wait > 0) {
        await sleep(Math.min(wait, 1000));
        continue;
      }
      st.status = 'running';
      broadcastUpdate();
      continue;
    }
    if (st.status !== 'running') return;

    const limitReached = st.crawled.length >= pageLimit(st);
    if (limitReached || st.queue.length === 0) {
      if (p.active === 0) {
        await finishAudit(p);
        return;
      }
      // Limit reached: the workers still fetching finish the audit. Empty queue: other
      // workers may still discover links, so keep polling.
      if (limitReached) return;
      await sleep(politenessDelay(st));
      continue;
    }

    const url = st.queue.shift();
    if (st.crawled.includes(url)) continue;
    st.crawled.push(url);
    st.inFlight = st.inFlight || [];
    st.inFlight.push(url);
    p.active++;
    broadcastUpdate();

    let outcome = 'ok';
    try {
      outcome = await processPage(url, p);
    } catch (err) {
      console.warn(`Error auditing ${url}:`, err && err.message);
    } finally {
      p.active--;
      removeFirst(st.inFlight, url);
    }
    if (pool !== p || outcome === 'stale') return;

    await saveStateToStorage();
    broadcastUpdate();
    if (outcome !== 'backoff') await sleep(politenessDelay(st));
  }
}

// Fetch, search and record one page. Returns 'ok', 'backoff' (re-queued after a 429/503)
// or 'stale' (the audit was replaced while the page was in flight).
async function processPage(url, p) {
  const st = p.state;
  const auditId = p.auditId;
  const isStale = () => pool !== p;

  let status = 0;
  let html = '';
  let finalUrl = url;
  let nonHtml = false;

  try {
    if (st.jsRendering) {
      const renderRes = await fetchSPA(url);
      status = renderRes.status;
      html = renderRes.html;
      finalUrl = renderRes.url || url;
    } else {
      const response = await fetchPage(url);
      status = response.status;

      if (status === 429 || status === 503) {
        cancelBody(response);
        st.retries = st.retries || {};
        const retryCount = st.retries[url] || 0;
        if (retryCount < 3 && !isStale()) {
          // Put the page back and pause the whole crawl
          st.retries[url] = retryCount + 1;
          removeFirst(st.crawled, url);
          st.queue.unshift(url);
          triggerBackoff(st, parseRetryAfter(response.headers.get('retry-after')));
          return 'backoff';
        }
        throw new Error(`HTTP ${status} (server asked to slow down)`);
      }

      if (!response.ok) {
        cancelBody(response);
        throw new Error(`HTTP ${response.status}`);
      }

      // Do not try to parse PDFs, images or other binaries served from extension-less URLs
      const contentType = (response.headers.get('content-type') || '').toLowerCase();
      if (contentType && !contentType.includes('html') && !contentType.includes('xml')) {
        nonHtml = true;
        cancelBody(response);
      } else {
        html = await response.text();
      }
      finalUrl = response.url || url;
    }

    backoffDelay = INITIAL_BACKOFF;
    if (isStale()) return 'stale';

    // A redirect target is the same page: never queue it separately
    if (finalUrl !== url) p.seen.add(finalUrl);

    const wantLinks = st.scanScope !== 'page' && !nonHtml;
    const parsed = nonHtml
      ? { success: true, results: { totalMatches: 0, matches: [] } }
      : await parseInOffscreen({
        type: 'PARSE_HTML',
        html: html.length > MAX_HTML_CHARS ? html.slice(0, MAX_HTML_CHARS) : html,
        keyword: st.keyword,
        terms: st.terms,
        matchMode: st.matchMode,
        caseSensitive: st.caseSensitive,
        baseUrl: finalUrl,
        wantLinks
      });

    if (isStale()) return 'stale';
    if (!parsed || !parsed.success) {
      // Record the page as failed rather than silently reporting "0 matches"
      throw new Error(`Parsing failed: ${parsed ? parsed.error : 'parser not responding'}`);
    }

    const searchResult = parsed.results;
    st.totalMatches += searchResult.totalMatches || 0;

    await addPageResult({
      auditId,
      url,
      finalUrl: finalUrl !== url ? finalUrl : undefined,
      status,
      matchCount: searchResult.totalMatches,
      matches: searchResult.matches
    });

    // Queue same-site links (only when the page was not redirected to another site)
    if (wantLinks && Array.isArray(parsed.links) && sameOrigin(finalUrl, st.origin)) {
      for (const link of parsed.links) {
        if (st.queue.length >= MAX_QUEUE) {
          st.queueTruncated = true;
          break;
        }
        if (p.seen.has(link) || !sameOrigin(link, st.origin) || !shouldQueue(link, st)) continue;
        p.seen.add(link);
        st.queue.push(link);
      }
    }
  } catch (error) {
    if (isStale()) return 'stale';
    st.errorCount++;
    try {
      await addPageResult({
        auditId,
        url,
        status: status || 0,
        matchCount: 0,
        matches: [],
        error: String(error && error.message ? error.message : error)
      });
    } catch (e) {
      console.warn('Could not record failed page:', e && e.message);
    }
  }

  try {
    await updateAudit(auditId, {
      totalCrawled: st.crawled.length,
      totalMatches: st.totalMatches,
      errorCount: st.errorCount
    });
  } catch (e) {
    // The audit was deleted while it was running
  }
  return 'ok';
}

function sameOrigin(url, origin) {
  try {
    return new URL(url).origin === origin;
  } catch (e) {
    return false;
  }
}

// Pause the crawl after a 429/503. The pause doubles on every hit and honours Retry-After.
function triggerBackoff(st, retryAfterMs) {
  if (st.status === 'paused') return;
  const wait = Math.min(Math.max(backoffDelay, retryAfterMs || 0), MAX_BACKOFF);
  backoffDelay = Math.min(backoffDelay * 2, MAX_BACKOFF);
  st.status = 'paused';
  st.resumeAt = Date.now() + wait;
  broadcastUpdate();
  saveStateToStorage();
}

async function finishAudit(p) {
  const st = p.state;
  if (pool !== p || st.status !== 'running') return;
  st.status = 'completed';
  st.inFlight = [];
  try {
    await updateAudit(p.auditId, {
      status: 'completed',
      endTime: Date.now(),
      totalCrawled: st.crawled.length,
      totalMatches: st.totalMatches,
      errorCount: st.errorCount,
      queueRemaining: st.queue.length
    });
  } catch (e) {
    // Audit deleted while running
  }
  broadcastUpdate();
  await saveStateToStorage();
  closeOffscreenIfIdle();
}

// ---------------------------------------------------------------------------
// Audit lifecycle
// ---------------------------------------------------------------------------
let startingAudit = false;

async function readRobots(origin) {
  const resp = await fetchWithTimeout(origin + '/robots.txt', { credentials: 'include' }, ROBOTS_TIMEOUT);
  if (resp.ok) return parseRobotsTxt(await resp.text());
  cancelBody(resp);
  // RFC 9309: a server error on robots.txt means "do not crawl"; 4xx means no rules
  if (resp.status >= 500) {
    throw new Error(`robots.txt returned HTTP ${resp.status}, which tells crawlers to stay away for now. Try again later, or turn off "Robots.txt" under More options.`);
  }
  return { rules: [], crawlDelay: 0 };
}

async function startAudit(targetUrl, keyword, caseSensitive, respectRobots = true, useSitemap = true, jsRendering = false, matchMode = 'exact', scanScope = 'site', maxPages = 100, excludePatterns = '', speed = 'normal') {
  if (startingAudit || isBusy()) {
    throw new Error('An audit is already running. Stop it first.');
  }
  const terms = parseTerms(keyword);
  if (terms.length === 0) {
    throw new Error('Please enter a keyword.');
  }
  if (!['exact', 'regex', 'fuzzy'].includes(matchMode)) matchMode = 'exact';
  if (matchMode === 'regex') {
    for (const t of terms) {
      let re;
      try {
        re = new RegExp(t);
      } catch (e) {
        throw new Error(terms.length > 1 ? `"${t}": ${e.message}` : e.message);
      }
      if (re.test('')) {
        throw new Error(`The pattern "${t}" also matches empty text, so it would match everywhere. Make it more specific.`);
      }
    }
  }
  keyword = terms.join(', ');
  if (!SPEED_PRESETS[speed]) speed = 'normal';
  scanScope = scanScope === 'page' ? 'page' : 'site';
  caseSensitive = !!caseSensitive && matchMode !== 'fuzzy';
  respectRobots = respectRobots !== false;
  useSitemap = useSitemap !== false;
  jsRendering = !!jsRendering;
  let parsed;
  try {
    parsed = new URL(targetUrl);
    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') throw new Error('bad protocol');
  } catch (e) {
    throw new Error('Start the audit from an http or https page.');
  }
  parsed.hash = '';
  targetUrl = parsed.href;
  maxPages = Math.min(Math.max(parseInt(maxPages, 10) || 100, 1), CRAWL_LIMIT);
  const excludeList = parseExcludePatterns(excludePatterns);

  startingAudit = true;
  const previousStatus = crawlerState.status;
  crawlerState = { ...crawlerState, status: 'starting', domain: parsed.hostname };
  broadcastUpdate();
  try {
    const origin = parsed.origin;
    const domain = parsed.hostname;
    const isSiteScope = scanScope !== 'page';

    let robotsRules = [];
    let crawlDelay = 0;
    const initialQueue = [targetUrl];

    if (respectRobots && isSiteScope) {
      try {
        const robots = await readRobots(origin);
        robotsRules = robots.rules;
        crawlDelay = robots.crawlDelay;
      } catch (err) {
        if (/robots\.txt returned/.test(err.message)) throw err;
        // Network error or timeout: no robots.txt to honour
      }
    }

    if (useSitemap && isSiteScope) {
      // /sitemap.xml plus any "Sitemap:" entries declared in robots.txt (sitemap indexes are followed).
      // robots.txt is read for its Sitemap lines even when the rules themselves are ignored.
      let sitemapRules = robotsRules;
      if (!respectRobots) {
        try { sitemapRules = (await readRobots(origin)).rules; } catch (e) { sitemapRules = []; }
      }
      const sitemapStarts = [origin + '/sitemap.xml'];
      sitemapRules.filter(r => r.type === 'sitemap').forEach(r => {
        try {
          const u = new URL(r.path, origin);
          if (u.origin === origin) sitemapStarts.push(u.href);
        } catch (e) { /* ignore */ }
      });

      const smUrls = await collectSitemapUrls(sitemapStarts, origin, Math.min(maxPages * 2, MAX_QUEUE));
      const queued = new Set(initialQueue);
      for (const url of smUrls) {
        try {
          const u = new URL(url);
          if (u.origin !== origin) continue;
          u.hash = '';
          const clean = u.href;
          if (!isCrawlableUrl(clean) || isExcluded(clean, excludeList)) continue;
          if (respectRobots && !isUrlAllowed(clean, robotsRules)) continue;
          if (!queued.has(clean)) {
            queued.add(clean);
            initialQueue.push(clean);
          }
        } catch (e) {
          // Ignore
        }
      }
    }

    // Create database audit log
    const auditId = await createAudit({
      domain,
      startUrl: targetUrl,
      keyword,
      terms,
      speed,
      caseSensitive,
      respectRobots,
      useSitemap,
      jsRendering,
      matchMode,
      scanScope,
      maxPages,
      excludePatterns: excludeList,
      crawlDelay,
      status: 'running'
    });

    crawlerState = {
      currentAuditId: auditId,
      status: 'running',
      domain,
      origin,
      keyword,
      terms,
      speed,
      caseSensitive,
      respectRobots,
      useSitemap,
      jsRendering,
      matchMode,
      scanScope,
      maxPages,
      excludePatterns: excludeList,
      robotsRules,
      crawlDelay,
      queue: initialQueue,
      crawled: [],
      inFlight: [],
      retries: {},
      errorCount: 0,
      totalMatches: 0
    };

    backoffDelay = INITIAL_BACKOFF;
    // Marks the crawl as belonging to this browser session (session storage is cleared on restart)
    try { await chrome.storage.session.set({ crawlSession: auditId }); } catch (e) { /* ignore */ }
    await saveStateToStorage();
    broadcastUpdate();
    startWorkers();

    // Keep the history within the user's retention limit
    applyRetention().catch(() => {});
    return auditId;
  } catch (err) {
    if (crawlerState.status === 'starting') {
      crawlerState = { ...crawlerState, status: previousStatus === 'starting' ? 'idle' : previousStatus };
      broadcastUpdate();
    }
    throw err;
  } finally {
    startingAudit = false;
  }
}

// Re-fetch one page of a finished audit and replace its stored result, so a fix can be
// confirmed without re-crawling the whole site.
async function rescanPage(auditId, resultId) {
  const audit = await getAudit(auditId);
  if (!audit) throw new Error('Audit not found.');
  if (crawlerState.currentAuditId === auditId && isBusy()) {
    throw new Error('Wait for this audit to finish before rechecking pages.');
  }
  const results = await getAuditResults(auditId);
  const result = results.find(r => r.id === resultId);
  if (!result) throw new Error('Page not found in this audit.');

  const terms = audit.terms && audit.terms.length ? audit.terms : [audit.keyword];
  let status = 0;
  let html = '';
  let error = null;
  let searchResult = { totalMatches: 0, matches: [] };

  rescansInProgress++;
  try {
    if (audit.jsRendering) {
      const r = await fetchSPA(result.url);
      status = r.status;
      html = r.html;
    } else {
      const resp = await fetchPage(result.url, { cache: 'no-store' });
      status = resp.status;
      if (!resp.ok) {
        cancelBody(resp);
        throw new Error(`HTTP ${resp.status}`);
      }
      const contentType = (resp.headers.get('content-type') || '').toLowerCase();
      if (contentType && !contentType.includes('html') && !contentType.includes('xml')) {
        cancelBody(resp);
      } else {
        html = await resp.text();
      }
    }
    if (html) {
      const parsed = await parseInOffscreen({
        type: 'PARSE_HTML',
        html: html.length > MAX_HTML_CHARS ? html.slice(0, MAX_HTML_CHARS) : html,
        keyword: audit.keyword,
        terms,
        matchMode: audit.matchMode || 'exact',
        caseSensitive: audit.caseSensitive,
        baseUrl: result.url,
        wantLinks: false
      });
      if (!parsed || !parsed.success) {
        throw new Error(`Parsing failed: ${parsed ? parsed.error : 'parser not responding'}`);
      }
      searchResult = parsed.results;
    }
  } catch (err) {
    error = String(err && err.message ? err.message : err);
  } finally {
    rescansInProgress--;
    closeOffscreenIfIdle();
  }

  const previousCount = result.matchCount || 0;
  const matchCount = error ? 0 : searchResult.totalMatches;
  await updatePageResult(resultId, {
    status,
    matchCount,
    matches: error ? [] : searchResult.matches,
    error,
    scannedTime: Date.now(),
    rechecked: true
  });

  // Keep the audit's summary totals consistent with the updated page
  const refreshed = await getAuditResults(auditId);
  await updateAudit(auditId, {
    totalMatches: refreshed.reduce((n, r) => n + (r.matchCount || 0), 0),
    errorCount: refreshed.filter(r => r.status < 200 || r.status >= 300).length
  });

  return { previousCount, matchCount, error };
}

// Stop audit. Pages already being fetched still finish and are recorded.
async function stopAudit() {
  const st = crawlerState;
  if (st.status === 'starting') throw new Error('The audit is still starting; try again in a moment.');
  if (!isBusy(st)) return;
  st.status = 'stopped';

  if (st.currentAuditId) {
    try {
      await updateAudit(st.currentAuditId, {
        status: 'stopped',
        endTime: Date.now(),
        totalCrawled: st.crawled.length,
        totalMatches: st.totalMatches,
        errorCount: st.errorCount,
        queueRemaining: st.queue.length
      });
    } catch (e) { /* deleted */ }
  }

  await saveStateToStorage();
  broadcastUpdate();
  closeOffscreenIfIdle();
}

// Delete an audit; a running audit is stopped first and its in-flight pages are dropped
async function removeAudit(auditId) {
  if (crawlerState.currentAuditId === auditId) {
    if (isBusy()) await stopAudit();
    pool = null;
    crawlerState = { ...crawlerState, currentAuditId: null, status: 'idle', queue: [], crawled: [], inFlight: [], totalMatches: 0, errorCount: 0 };
    await saveStateToStorage();
    broadcastUpdate();
  }
  await deleteAudit(auditId);
}

// History retention (set in the dashboard): keep the newest N audits and/or drop old ones
const DEFAULT_RETENTION = { maxAudits: 50, maxAgeDays: 0 };
async function getRetention() {
  const { retention } = await chrome.storage.local.get('retention');
  return { ...DEFAULT_RETENTION, ...(retention || {}) };
}

async function applyRetention() {
  const r = await getRetention();
  const keepIds = isBusy() ? [crawlerState.currentAuditId] : [];
  return pruneAudits({ maxAudits: r.maxAudits, maxAgeDays: r.maxAgeDays, keepIds });
}

async function clearHistory() {
  const keepIds = isBusy() ? [crawlerState.currentAuditId] : [];
  const removed = await pruneAudits({ deleteAll: true, keepIds });
  if (!isBusy()) {
    crawlerState = { ...crawlerState, currentAuditId: null, status: 'idle', queue: [], crawled: [], inFlight: [], totalMatches: 0, errorCount: 0 };
    await saveStateToStorage();
    broadcastUpdate();
  }
  return removed;
}

// Broadcast progress to open popup or dashboard. The full URL lists are not needed there,
// so only their lengths are sent.
function broadcastUpdate() {
  chrome.runtime.sendMessage({
    type: 'STATUS_UPDATE',
    state: publicState()
  }).catch(() => {
    // Message fails if popup and dashboard are closed; ignore
  });
}

function publicState() {
  const st = crawlerState;
  return {
    currentAuditId: st.currentAuditId,
    status: st.status,
    domain: st.domain,
    keyword: st.keyword,
    terms: st.terms,
    speed: st.speed,
    caseSensitive: st.caseSensitive,
    respectRobots: st.respectRobots,
    useSitemap: st.useSitemap,
    jsRendering: st.jsRendering,
    matchMode: st.matchMode,
    scanScope: st.scanScope,
    maxPages: st.maxPages,
    excludePatterns: st.excludePatterns,
    crawlDelay: st.crawlDelay || 0,
    resumeAt: st.resumeAt || 0,
    crawledCount: (st.crawled || []).length,
    queueCount: (st.queue || []).length,
    queueTruncated: !!st.queueTruncated,
    totalMatches: st.totalMatches || 0,
    errorCount: st.errorCount || 0
  };
}

// Load state when the worker starts. A crawl interrupted by the worker being suspended is
// resumed; one left over from before a browser restart is marked as stopped instead.
async function loadStateFromStorage() {
  const data = await chrome.storage.local.get('crawlerState');
  if (data.crawlerState) {
    crawlerState = data.crawlerState;
    const st = crawlerState;
    st.queue = st.queue || [];
    st.crawled = st.crawled || [];
    if (st.status === 'starting') st.status = 'idle';

    if (isBusy(st)) {
      let sameSession = false;
      try {
        const { crawlSession } = await chrome.storage.session.get('crawlSession');
        sameSession = crawlSession === st.currentAuditId;
      } catch (e) {
        sameSession = true;
      }
      const audit = st.currentAuditId ? await getAudit(st.currentAuditId).catch(() => null) : null;

      // Pages that were being fetched when the worker stopped never got a result
      const inFlight = st.inFlight || [];
      if (inFlight.length) {
        st.crawled = st.crawled.filter(u => !inFlight.includes(u));
        st.queue.unshift(...inFlight);
      }
      st.inFlight = [];

      if (!audit) {
        st.status = 'idle';
        st.currentAuditId = null;
      } else if (!sameSession) {
        st.status = 'stopped';
        await updateAudit(st.currentAuditId, { status: 'stopped', interrupted: true, endTime: Date.now() }).catch(() => {});
      } else {
        st.retries = st.retries || {};
        backoffDelay = INITIAL_BACKOFF;
        startWorkers();
      }
      await saveStateToStorage();
    }
  }
  await closeLeftoverRenderTabs();
  // Audits stuck in "running" (crash, deleted state) are marked stopped
  await markInterruptedAudits(isBusy() ? crawlerState.currentAuditId : null).catch(() => {});
}

const ready = loadStateFromStorage().catch(err => console.warn('Could not restore crawl state:', err && err.message));

chrome.runtime.onInstalled.addListener(() => {
  ready.then(() => applyRetention()).catch(() => {});
});
chrome.runtime.onStartup.addListener(() => {
  ready.then(() => applyRetention()).catch(() => {});
});

// Open a page and highlight the audit's matches in it
async function launchHighlight(message) {
  let url;
  try {
    url = new URL(message.url);
    if (url.protocol !== 'http:' && url.protocol !== 'https:') return;
  } catch (e) {
    return;
  }
  const tab = await chrome.tabs.create({ url: url.href, active: true });
  if (!tab) return;
  const tabId = tab.id;

  if (!(await waitForTabComplete(tabId, 60000))) return;
  try {
    // Styles go in through insertCSS so pages with a strict CSP cannot block them
    await chrome.scripting.insertCSS({ target: { tabId }, files: ['highlight.css'] });
    await chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] });
    await chrome.tabs.sendMessage(tabId, {
      type: 'HIGHLIGHT_DOM',
      keyword: String(message.keyword || ''),
      terms: Array.isArray(message.terms) ? message.terms.map(String).slice(0, MAX_TERMS) : undefined,
      matchMode: message.matchMode,
      caseSensitive: !!message.caseSensitive
    });
  } catch (err) {
    console.warn('Highlight failed:', err && err.message);
  }
}

// Only SiteScope's own pages (popup, dashboard) may control the crawler. Content scripts run
// inside web pages and are never trusted with these commands.
function fromExtensionPage(sender) {
  return sender && sender.id === chrome.runtime.id &&
    typeof sender.url === 'string' && sender.url.startsWith(chrome.runtime.getURL(''));
}

const handlers = {
  START_AUDIT: (m) => startAudit(m.url, m.keyword, m.caseSensitive, m.respectRobots, m.useSitemap,
    m.jsRendering, m.matchMode, m.scanScope, m.maxPages, m.excludePatterns, m.speed)
    .then(auditId => ({ success: true, auditId })),
  STOP_AUDIT: () => stopAudit().then(() => ({ success: true })),
  RESCAN_PAGE: (m) => rescanPage(m.auditId, m.resultId).then(res => ({ success: true, ...res })),
  GET_STATE: () => Promise.resolve({ state: publicState() }),
  DELETE_AUDIT: (m) => removeAudit(m.auditId).then(() => ({ success: true })),
  APPLY_RETENTION: () => applyRetention().then(removed => ({ success: true, removed })),
  CLEAR_HISTORY: () => clearHistory().then(removed => ({ success: true, removed })),
  LAUNCH_HIGHLIGHT: (m) => { launchHighlight(m).catch(() => {}); return Promise.resolve({ success: true }); }
};

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const handler = message && handlers[message.type];
  if (!handler) return false;
  if (!fromExtensionPage(sender)) {
    sendResponse({ success: false, error: 'Not allowed.' });
    return false;
  }
  ready
    .then(() => handler(message))
    .then(sendResponse)
    .catch(err => sendResponse({ success: false, error: (err && err.message) || String(err) }));
  return true;
});
