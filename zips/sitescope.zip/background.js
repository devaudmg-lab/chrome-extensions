// SiteScope Background Crawler Service Worker (Manifest V3)
import { createAudit, updateAudit, addPageResult, getAudit, getAuditResults, updatePageResult } from './storage.js';

// State object
let crawlerState = {
  currentAuditId: null,
  status: 'idle', // 'idle' | 'running' | 'paused' | 'stopped' | 'completed'
  domain: '',
  origin: '',
  keyword: '',
  caseSensitive: false,
  respectRobots: true,
  useSitemap: true,
  jsRendering: false,
  matchMode: 'exact', // 'exact' | 'regex' | 'fuzzy'
  robotsRules: [],
  queue: [],
  crawled: [],
  errorCount: 0,
  totalMatches: 0
};

const CRAWL_LIMIT = 1000;
let isCrawling = false;

// Concurrency and Throttling variables
let activeWorkersCount = 0;
let isBackingOff = false;
let backoffDelay = 5000;

const INITIAL_BACKOFF = 5000;
const MAX_BACKOFF = 60000;

// User-selectable crawl speed: parallel workers and the pause each worker takes between pages
const SPEED_PRESETS = {
  gentle: { concurrency: 1, delay: 1500 },
  normal: { concurrency: 2, delay: 500 },
  fast: { concurrency: 4, delay: 150 }
};
function speedPreset() {
  return SPEED_PRESETS[crawlerState.speed] || SPEED_PRESETS.normal;
}
function maxConcurrency() { return speedPreset().concurrency; }
function politenessDelay() { return speedPreset().delay; }

const MAX_TERMS = 20;
// The keyword box accepts one term per line; return a de-duplicated list
function parseTerms(raw) {
  const seen = new Set();
  const terms = [];
  String(raw || '').split(/\r?\n/).forEach(line => {
    const t = line.trim();
    if (t && !seen.has(t) && terms.length < MAX_TERMS) {
      seen.add(t);
      terms.push(t);
    }
  });
  return terms;
}

let creatingOffscreen = null;
// Ensure the offscreen parser document exists. The whole check-and-create sequence is
// shared through one promise, so concurrent workers cannot race into double creation.
function setupOffscreenDocument(path) {
  if (creatingOffscreen) return creatingOffscreen;

  creatingOffscreen = (async () => {
    try {
      const contexts = await chrome.runtime.getContexts({
        contextTypes: ['OFFSCREEN_DOCUMENT'],
        documentUrls: [chrome.runtime.getURL(path)]
      });
      if (contexts.length > 0) return;
    } catch (e) {
      // getContexts unavailable; fall through and try to create
    }

    try {
      await chrome.offscreen.createDocument({
        url: path,
        reasons: ['DOM_PARSER'],
        justification: 'Parse HTML to search for keywords'
      });
    } catch (err) {
      if (!String(err && err.message).includes('Only a single offscreen document')) {
        console.error("Offscreen creation failed:", err);
      }
    }
  })().finally(() => {
    creatingOffscreen = null;
  });

  return creatingOffscreen;
}

// Send HTML to the offscreen document for parsing, retrying briefly if it is not listening yet
async function parseInOffscreen(payload) {
  for (let attempt = 0; attempt < 3; attempt++) {
    await setupOffscreenDocument('offscreen.html');
    const res = await new Promise((resolve) => {
      chrome.runtime.sendMessage(payload, (r) => {
        void chrome.runtime.lastError; // receiver not ready yet; retried below
        resolve(r);
      });
    });
    if (res) return res;
    await new Promise(r => setTimeout(r, 200 * (attempt + 1)));
  }
  return null;
}

// Helpers to load/save state
async function saveStateToStorage() {
  await chrome.storage.local.set({ crawlerState });
}

async function loadStateFromStorage() {
  const data = await chrome.storage.local.get('crawlerState');
  if (data.crawlerState) {
    crawlerState = data.crawlerState;
    // Resume if it was running (or paused by a rate-limit backoff when the worker was suspended)
    if (crawlerState.status === 'running' || crawlerState.status === 'paused') {
      crawlerState.status = 'running';
      isCrawling = true;
      backoffDelay = INITIAL_BACKOFF;
      for (let i = 0; i < maxConcurrency(); i++) {
        crawlLoop();
      }
    }
  }
}

// File types that are never HTML pages; skipping them avoids downloading binaries
const NON_HTML_EXT = /\.(pdf|jpe?g|png|gif|webp|svg|ico|bmp|tiff?|avif|mp4|webm|mov|avi|mkv|mp3|wav|ogg|m4a|zip|rar|7z|gz|tar|exe|dmg|msi|apk|iso|docx?|xlsx?|pptx?|csv|json|xml|rss|txt|css|js|woff2?|ttf|otf|eot)$/i;

function isCrawlableUrl(url) {
  try {
    return !NON_HTML_EXT.test(new URL(url).pathname);
  } catch (e) {
    return false;
  }
}

// User-defined exclusions: a URL is skipped when it contains any of the patterns
function isExcluded(url, patterns) {
  if (!patterns || patterns.length === 0) return false;
  const lower = url.toLowerCase();
  return patterns.some(p => lower.includes(p));
}

function parseExcludePatterns(raw) {
  if (Array.isArray(raw)) raw = raw.join(',');
  return String(raw || '')
    .split(/[,\n]/)
    .map(p => p.trim().toLowerCase())
    .filter(Boolean)
    .slice(0, 50);
}

function decodeXmlEntities(str) {
  return str
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&amp;/g, '&');
}

// Should a discovered same-origin URL be queued?
function shouldQueue(url) {
  if (!isCrawlableUrl(url)) return false;
  if (isExcluded(url, crawlerState.excludePatterns)) return false;
  if (crawlerState.respectRobots && !isUrlAllowed(url, crawlerState.robotsRules)) return false;
  return true;
}

// Extract links from HTML string
function extractLinks(html, baseUrl) {
  const links = new Set();
  const regex = /<a\s+[^>]*href=["']([^"']*)["']/gi;
  let match;

  while ((match = regex.exec(html)) !== null) {
    let urlStr = decodeXmlEntities(match[1].trim());
    urlStr = urlStr.split('#')[0];
    if (!urlStr) continue;

    try {
      const resolvedUrl = new URL(urlStr, baseUrl);
      if (resolvedUrl.protocol === 'http:' || resolvedUrl.protocol === 'https:') {
        links.add(resolvedUrl.href);
      }
    } catch (e) {
      // Ignore
    }
  }
  return Array.from(links);
}


// Robots.txt Parser
function parseRobotsTxt(content) {
  const rules = [];
  const lines = content.split(/\r?\n/);
  let inUserAgentBlock = false;

  for (let line of lines) {
    line = line.trim();
    if (!line || line.startsWith('#')) continue;

    const colonIdx = line.indexOf(':');
    if (colonIdx === -1) continue;

    const key = line.substring(0, colonIdx).trim().toLowerCase();
    const value = line.substring(colonIdx + 1).trim();

    if (key === 'user-agent') {
      if (value === '*' || value.toLowerCase() === 'sitescope') {
        inUserAgentBlock = true;
      } else {
        inUserAgentBlock = false;
      }
    } else if (key === 'sitemap') {
      // Sitemap directives are global (not tied to a user-agent group)
      if (value) rules.push({ type: 'sitemap', path: value });
    } else if (inUserAgentBlock) {
      if (key === 'disallow' || key === 'allow') {
        if (value) {
          rules.push({
            type: key,
            path: value
          });
        }
      }
    }
  }
  return rules;
}

// Robots.txt checker
function isUrlAllowed(url, rules) {
  try {
    const parsed = new URL(url);
    const path = parsed.pathname + parsed.search;
    const sortedRules = rules
      .filter(r => r.type === 'allow' || r.type === 'disallow')
      .sort((a, b) => b.path.length - a.path.length);

    for (const rule of sortedRules) {
      // '*' is a wildcard; a trailing '$' anchors the end of the path (robots.txt spec)
      const anchored = rule.path.endsWith('$');
      const rawPath = anchored ? rule.path.slice(0, -1) : rule.path;
      let rulePathEscaped = rawPath.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&').replace(/\\\*/g, '.*');
      const ruleRegex = new RegExp('^' + rulePathEscaped + (anchored ? '$' : ''));
      if (ruleRegex.test(path)) {
        return rule.type === 'allow';
      }
    }
  } catch (e) {
    // Ignore
  }
  return true;
}

// Extract URLs from XML sitemaps
function extractSitemapUrls(xmlText) {
  const urls = [];
  const regex = /<loc>([\s\S]*?)<\/loc>/gi;
  let match;
  while ((match = regex.exec(xmlText)) !== null) {
    const u = match[1].trim();
    const cleanUrl = decodeXmlEntities(u.replace(/^<!\[CDATA\[([\s\S]*?)\]\]>$/i, '$1').trim());
    if (cleanUrl) urls.push(cleanUrl);
  }
  return urls;
}

// Collect page URLs from sitemaps, following <sitemapindex> files (bounded to avoid runaway fetches)
async function collectSitemapUrls(startUrls, origin, limit) {
  const MAX_SITEMAPS = 20;
  const pending = [...new Set(startUrls)];
  const seen = new Set();
  const pages = [];

  while (pending.length > 0 && seen.size < MAX_SITEMAPS && pages.length < limit) {
    const smUrl = pending.shift();
    if (seen.has(smUrl)) continue;
    seen.add(smUrl);

    try {
      const resp = await fetch(smUrl);
      if (!resp.ok) continue;
      const xml = await resp.text();
      const locs = extractSitemapUrls(xml);

      if (/<sitemapindex[\s>]/i.test(xml)) {
        for (const loc of locs) {
          try {
            if (new URL(loc).origin === origin && !seen.has(loc)) pending.push(loc);
          } catch (e) { /* ignore */ }
        }
      } else {
        for (const loc of locs) {
          pages.push(loc);
          if (pages.length >= limit) break;
        }
      }
    } catch (err) {
      console.log(`Sitemap fetch skipped (${smUrl}):`, err.message);
    }
  }
  return pages;
}

// Scrape dynamic page content in background tabs
async function fetchSPA(url) {
  return new Promise((resolve, reject) => {
    chrome.tabs.create({ url: url, active: false }, (tab) => {
      if (!tab) {
        reject(new Error("Failed to create background tab"));
        return;
      }

      const tabId = tab.id;
      let timeoutId = null;
      const closeTab = () => chrome.tabs.remove(tabId, () => void chrome.runtime.lastError);

      const listener = async (updatedTabId, changeInfo) => {
        if (updatedTabId === tabId && changeInfo.status === 'complete') {
          chrome.tabs.onUpdated.removeListener(listener);
          clearTimeout(timeoutId);

          try {
            setTimeout(async () => {
              try {
                chrome.tabs.get(tabId, async (currentTab) => {
                  const finalTabUrl = currentTab ? currentTab.url : url;
                  let results;
                  try {
                    results = await chrome.scripting.executeScript({
                      target: { tabId: tabId },
                      func: () => document.documentElement.outerHTML
                    });
                  } catch (e) {
                    closeTab();
                    reject(e);
                    return;
                  }

                  closeTab();

                  if (results && results[0] && results[0].result) {
                    resolve({
                      status: 200,
                      html: results[0].result,
                      url: finalTabUrl
                    });
                  } else {
                    resolve({ status: 200, html: '', url: finalTabUrl });
                  }
                });
              } catch (e) {
                chrome.tabs.remove(tabId);
                reject(e);
              }
            }, 1000);
          } catch (err) {
            chrome.tabs.remove(tabId);
            reject(err);
          }
        }
      };

      chrome.tabs.onUpdated.addListener(listener);

      timeoutId = setTimeout(() => {
        chrome.tabs.onUpdated.removeListener(listener);
        closeTab();
        reject(new Error("JS render timeout"));
      }, 15000);
    });
  });
}

// Main crawl iteration loop
async function crawlLoop() {
  if (!isCrawling || crawlerState.status !== 'running') {
    return;
  }

  if (isBackingOff) {
    return;
  }

  if (crawlerState.queue.length === 0) {
    if (activeWorkersCount === 0) {
      crawlerState.status = 'completed';
      isCrawling = false;

      if (crawlerState.currentAuditId) {
        await updateAudit(crawlerState.currentAuditId, {
          status: 'completed',
          endTime: Date.now(),
          totalCrawled: crawlerState.crawled.length,
          totalMatches: crawlerState.totalMatches,
          errorCount: crawlerState.errorCount
        });
      }
      broadcastUpdate();
      await saveStateToStorage();
    } else {
      // Other workers are still fetching and may discover new links; keep polling
      // instead of exiting, so concurrency is not permanently reduced.
      setTimeout(crawlLoop, politenessDelay());
    }
    return;
  }

  const maxPagesLimit = crawlerState.scanScope === 'page' ? 1 : (crawlerState.maxPages || CRAWL_LIMIT);
  if (crawlerState.crawled.length >= maxPagesLimit) {
    crawlerState.status = 'completed';
    isCrawling = false;

    if (crawlerState.currentAuditId) {
      await updateAudit(crawlerState.currentAuditId, {
        status: 'completed',
        endTime: Date.now(),
        totalCrawled: crawlerState.crawled.length,
        totalMatches: crawlerState.totalMatches,
        errorCount: crawlerState.errorCount
      });
    }
    broadcastUpdate();
    await saveStateToStorage();
    return;
  }

  const currentUrl = crawlerState.queue.shift();
  if (crawlerState.crawled.includes(currentUrl)) {
    setTimeout(crawlLoop, 0);
    return;
  }

  crawlerState.crawled.push(currentUrl);
  activeWorkersCount++;
  broadcastUpdate();

  // If the user stops this audit (or starts a new one) while this page is in flight,
  // its results must not be written into the new session.
  const auditId = crawlerState.currentAuditId;
  const isStale = () => crawlerState.currentAuditId !== auditId;

  let status = 200;
  let html = '';
  let finalUrl = currentUrl;
  let hitRateLimit = false;
  let nonHtml = false;

  try {
    if (crawlerState.jsRendering) {
      const renderRes = await fetchSPA(currentUrl);
      status = renderRes.status;
      html = renderRes.html;
      finalUrl = renderRes.url || currentUrl;
    } else {
      const response = await fetch(currentUrl, {
        method: 'GET',
        headers: {
          'Accept': 'text/html'
        }
      });

      status = response.status;
      if (status === 429 || status === 503) {
        hitRateLimit = true;
        throw new Error(`Rate limit hit ${status}`);
      }

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }

      // Do not try to parse PDFs, images or other binaries served from extension-less URLs
      const contentType = (response.headers.get('content-type') || '').toLowerCase();
      if (contentType && !contentType.includes('html') && !contentType.includes('xml')) {
        nonHtml = true;
        try { response.body && response.body.cancel(); } catch (e) { /* ignore */ }
      } else {
        html = await response.text();
      }
      finalUrl = response.url || currentUrl;
    }

    backoffDelay = INITIAL_BACKOFF;
    if (isStale()) {
      activeWorkersCount--;
      return;
    }

    // Audit parsed page via Offscreen Document
    const responseFromOffscreen = nonHtml
      ? { success: true, results: { totalMatches: 0, matches: [] } }
      : await parseInOffscreen({
        type: 'PARSE_HTML',
        html: html,
        keyword: crawlerState.keyword,
        terms: crawlerState.terms,
        matchMode: crawlerState.matchMode,
        caseSensitive: crawlerState.caseSensitive
      });

    if (isStale()) {
      activeWorkersCount--;
      return;
    }

    let searchResult = { totalMatches: 0, matches: [] };
    if (responseFromOffscreen && responseFromOffscreen.success) {
      searchResult = responseFromOffscreen.results;
    } else {
      // Record the page as failed rather than silently reporting "0 matches"
      throw new Error(`Parsing failed: ${responseFromOffscreen ? responseFromOffscreen.error : 'parser not responding'}`);
    }

    const matchesCount = searchResult.totalMatches;
    const matchDetails = searchResult.matches;

    if (matchesCount > 0) {
      crawlerState.totalMatches += matchesCount;
    }

    if (auditId) {
      await addPageResult({
        auditId: auditId,
        url: currentUrl,
        status: status,
        matchCount: matchesCount,
        matches: matchDetails
      });
    }

    // Extract internal anchors if scanScope !== 'page'
    if (crawlerState.scanScope !== 'page' && !nonHtml) {
      const extracted = extractLinks(html, finalUrl);
      for (const url of extracted) {
        try {
          const parsedUrl = new URL(url);
          if (parsedUrl.origin === crawlerState.origin) {
            if (!shouldQueue(url)) {
              continue;
            }

            if (!crawlerState.crawled.includes(url) && !crawlerState.queue.includes(url)) {
              crawlerState.queue.push(url);
            }
          }
        } catch (e) {
          // Ignore
        }
      }
    }
  } catch (error) {
    console.warn(`Error auditing ${currentUrl}:`, error.message || error);

    if (isStale()) {
      activeWorkersCount--;
      return;
    }

    // Retry rate-limited pages a few times, then record them as failed
    crawlerState.retries = crawlerState.retries || {};
    const retryCount = crawlerState.retries[currentUrl] || 0;
    if (hitRateLimit && retryCount < 3) {
      crawlerState.retries[currentUrl] = retryCount + 1;
      crawlerState.queue.unshift(currentUrl);
      crawlerState.crawled = crawlerState.crawled.filter(u => u !== currentUrl);

      triggerBackoff();
      activeWorkersCount--;
      return;
    } else {
      crawlerState.errorCount++;
      status = status === 200 ? 500 : status;

      if (auditId) {
        await addPageResult({
          auditId: auditId,
          url: currentUrl,
          status: status,
          matchCount: 0,
          matches: [],
          error: String(error && error.message ? error.message : error)
        });
      }
    }
  }

  if (crawlerState.currentAuditId) {
    try {
      await updateAudit(crawlerState.currentAuditId, {
        totalCrawled: crawlerState.crawled.length,
        totalMatches: crawlerState.totalMatches,
        errorCount: crawlerState.errorCount
      });
    } catch (e) {
      console.error("IndexedDB update failed:", e);
    }
  }

  activeWorkersCount--;
  await saveStateToStorage();
  broadcastUpdate();

  setTimeout(crawlLoop, politenessDelay());
}

// Pause during status backoff
function triggerBackoff() {
  if (isBackingOff) return;

  isBackingOff = true;
  crawlerState.status = 'paused';
  broadcastUpdate();

  console.log(`Rate limit detected (429/503). Pausing crawler queue for ${backoffDelay}ms...`);

  setTimeout(async () => {
    isBackingOff = false;
    // Do not resume if the user stopped the audit during the backoff window
    if (crawlerState.status !== 'paused' || !isCrawling) return;
    crawlerState.status = 'running';
    broadcastUpdate();

    backoffDelay = Math.min(backoffDelay * 2, MAX_BACKOFF);

    for (let i = activeWorkersCount; i < maxConcurrency(); i++) {
      crawlLoop();
    }
  }, backoffDelay);
}

// Initialize audit
async function startAudit(targetUrl, keyword, caseSensitive, respectRobots = true, useSitemap = true, jsRendering = false, matchMode = 'exact', scanScope = 'site', maxPages = 100, excludePatterns = '', speed = 'normal') {
  if (isCrawling && (crawlerState.status === 'running' || crawlerState.status === 'paused')) {
    throw new Error('An audit is already running. Stop it first.');
  }
  const terms = parseTerms(keyword);
  if (terms.length === 0) {
    throw new Error('Please enter a keyword.');
  }
  if (matchMode === 'regex') {
    for (const t of terms) {
      try {
        new RegExp(t);
      } catch (e) {
        throw new Error(terms.length > 1 ? `"${t}": ${e.message}` : e.message);
      }
    }
  }
  keyword = terms.join(', ');
  if (!SPEED_PRESETS[speed]) speed = 'normal';
  try {
    const u = new URL(targetUrl);
    if (u.protocol !== 'http:' && u.protocol !== 'https:') throw new Error('bad protocol');
  } catch (e) {
    throw new Error('Start the audit from an http or https page.');
  }
  maxPages = Math.min(Math.max(parseInt(maxPages, 10) || 100, 1), CRAWL_LIMIT);
  const excludeList = parseExcludePatterns(excludePatterns);

  {
    const parsed = new URL(targetUrl);
    const origin = parsed.origin;
    const domain = parsed.hostname;

    let robotsRules = [];
    let initialQueue = [targetUrl];

    const isSiteScope = scanScope !== 'page';

    if (respectRobots && isSiteScope) {
      try {
        const robResp = await fetch(origin + '/robots.txt');
        if (robResp.ok) {
          const robText = await robResp.text();
          robotsRules = parseRobotsTxt(robText);
        }
      } catch (err) {
        console.log("Robots.txt check bypassed. Network error:", err);
      }
    }

    if (useSitemap && isSiteScope) {
      // /sitemap.xml plus any "Sitemap:" entries declared in robots.txt (sitemap indexes are followed)
      const sitemapStarts = [origin + '/sitemap.xml'];
      robotsRules.filter(r => r.type === 'sitemap').forEach(r => {
        try {
          const u = new URL(r.path, origin);
          if (u.origin === origin) sitemapStarts.push(u.href);
        } catch (e) { /* ignore */ }
      });

      const smUrls = await collectSitemapUrls(sitemapStarts, origin, CRAWL_LIMIT * 2);
      const queued = new Set(initialQueue);
      for (const url of smUrls) {
        try {
          const u = new URL(url);
          if (u.origin !== origin) continue;
          if (!isCrawlableUrl(url) || isExcluded(url, excludeList)) continue;
          if (respectRobots && !isUrlAllowed(url, robotsRules)) continue;
          if (!queued.has(url)) {
            queued.add(url);
            initialQueue.push(url);
          }
        } catch (e) {
          // Ignore
        }
      }
    }

    // Create database audit log
    const auditId = await createAudit({
      domain: domain,
      startUrl: targetUrl,
      keyword: keyword,
      terms: terms,
      speed: speed,
      caseSensitive: caseSensitive,
      respectRobots: respectRobots,
      useSitemap: useSitemap,
      jsRendering: jsRendering,
      matchMode: matchMode,
      scanScope: scanScope,
      maxPages: maxPages,
      excludePatterns: excludeList,
      status: 'running'
    });

    // Setup State
    crawlerState = {
      currentAuditId: auditId,
      status: 'running',
      domain: domain,
      origin: origin,
      keyword: keyword,
      terms: terms,
      speed: speed,
      caseSensitive: caseSensitive,
      respectRobots: respectRobots,
      useSitemap: useSitemap,
      jsRendering: jsRendering,
      matchMode: matchMode,
      scanScope: scanScope,
      maxPages: maxPages,
      excludePatterns: excludeList,
      robotsRules: robotsRules,
      queue: initialQueue,
      crawled: [],
      retries: {},
      errorCount: 0,
      totalMatches: 0
    };

    isCrawling = true;
    backoffDelay = INITIAL_BACKOFF;
    await saveStateToStorage();
    broadcastUpdate();

    // Note: activeWorkersCount is not reset here; workers still in flight from a
    // previous (stopped) audit decrement it themselves when they notice they are stale.
    for (let i = 0; i < maxConcurrency(); i++) {
      crawlLoop();
    }
    return auditId;
  }
}

// Re-fetch one page of a finished audit and replace its stored result, so a fix can be
// confirmed without re-crawling the whole site.
async function rescanPage(auditId, resultId) {
  const audit = await getAudit(auditId);
  if (!audit) throw new Error('Audit not found.');
  if (crawlerState.currentAuditId === auditId && (crawlerState.status === 'running' || crawlerState.status === 'paused')) {
    throw new Error('Wait for this audit to finish before rechecking pages.');
  }
  const results = await getAuditResults(auditId);
  const result = results.find(r => r.id === resultId);
  if (!result) throw new Error('Page not found in this audit.');

  const terms = audit.terms && audit.terms.length ? audit.terms : [audit.keyword];
  let status = 200;
  let html = '';
  let error = null;
  let searchResult = { totalMatches: 0, matches: [] };

  try {
    if (audit.jsRendering) {
      const r = await fetchSPA(result.url);
      status = r.status;
      html = r.html;
    } else {
      const resp = await fetch(result.url, { headers: { 'Accept': 'text/html' }, cache: 'no-store' });
      status = resp.status;
      if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
      const contentType = (resp.headers.get('content-type') || '').toLowerCase();
      if (contentType && !contentType.includes('html') && !contentType.includes('xml')) {
        try { resp.body && resp.body.cancel(); } catch (e) { /* ignore */ }
      } else {
        html = await resp.text();
      }
    }
    if (html) {
      const parsed = await parseInOffscreen({
        type: 'PARSE_HTML',
        html: html,
        keyword: audit.keyword,
        terms: terms,
        matchMode: audit.matchMode || 'exact',
        caseSensitive: audit.caseSensitive
      });
      if (!parsed || !parsed.success) {
        throw new Error(`Parsing failed: ${parsed ? parsed.error : 'parser not responding'}`);
      }
      searchResult = parsed.results;
    }
  } catch (err) {
    error = String(err && err.message ? err.message : err);
    if (status >= 200 && status < 300) status = 500;
  }

  const previousCount = result.matchCount || 0;
  const matchCount = error ? 0 : searchResult.totalMatches;
  await updatePageResult(resultId, {
    status: status,
    matchCount: matchCount,
    matches: error ? [] : searchResult.matches,
    error: error,
    scannedTime: Date.now(),
    rechecked: true
  });

  // Keep the audit's summary totals consistent with the updated page
  const refreshed = await getAuditResults(auditId);
  await updateAudit(auditId, {
    totalMatches: refreshed.reduce((n, r) => n + (r.matchCount || 0), 0),
    errorCount: refreshed.filter(r => r.status < 200 || r.status >= 300).length
  });

  return { previousCount, matchCount, error };
}

// Stop audit
async function stopAudit() {
  crawlerState.status = 'stopped';
  isCrawling = false;

  if (crawlerState.currentAuditId) {
    await updateAudit(crawlerState.currentAuditId, {
      status: 'stopped',
      endTime: Date.now(),
      totalCrawled: crawlerState.crawled.length,
      totalMatches: crawlerState.totalMatches,
      errorCount: crawlerState.errorCount
    });
  }

  await saveStateToStorage();
  broadcastUpdate();
}

// Broadcast progress to open popup or dashboard
function broadcastUpdate() {
  chrome.runtime.sendMessage({
    type: 'STATUS_UPDATE',
    state: crawlerState
  }).catch(() => {
    // Message fails if popup and dashboard are closed; ignore
  });
}

// Listen for interactions
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'START_AUDIT') {
    startAudit(
      message.url,
      message.keyword,
      message.caseSensitive,
      message.respectRobots,
      message.useSitemap,
      message.jsRendering,
      message.matchMode,
      message.scanScope,
      message.maxPages,
      message.excludePatterns,
      message.speed
    )
      .then((auditId) => sendResponse({ success: true, auditId }))
      .catch((err) => sendResponse({ success: false, error: err.message }));
    return true;
  } else if (message.type === 'STOP_AUDIT') {
    stopAudit()
      .then(() => sendResponse({ success: true }))
      .catch((err) => sendResponse({ success: false, error: err.message }));
    return true;
  } else if (message.type === 'RESCAN_PAGE') {
    rescanPage(message.auditId, message.resultId)
      .then((res) => sendResponse({ success: true, ...res }))
      .catch((err) => sendResponse({ success: false, error: err.message }));
    return true;
  } else if (message.type === 'GET_STATE') {
    sendResponse({ state: crawlerState });
  } else if (message.type === 'LAUNCH_HIGHLIGHT') {
    chrome.tabs.create({ url: message.url, active: true }, (tab) => {
      if (!tab) return;
      const tabId = tab.id;

      const listener = (updatedTabId, changeInfo) => {
        if (updatedTabId === tabId && changeInfo.status === 'complete') {
          chrome.tabs.onUpdated.removeListener(listener);

          chrome.scripting.executeScript({
            target: { tabId: tabId },
            files: ['content.js']
          }, () => {
            if (chrome.runtime.lastError) {
              console.warn("Highlight injection failed:", chrome.runtime.lastError.message);
              return;
            }
            chrome.tabs.sendMessage(tabId, {
              type: 'HIGHLIGHT_DOM',
              keyword: message.keyword,
              terms: message.terms,
              matchMode: message.matchMode,
              caseSensitive: message.caseSensitive
            }).catch(err => console.error("Highlight message failed:", err));
          });
        }
      };
      chrome.tabs.onUpdated.addListener(listener);
    });
    sendResponse({ success: true });
    return false;
  }
  return false;
});

// Load state on startup
loadStateFromStorage();
