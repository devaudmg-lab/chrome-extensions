// Levenshtein distance for fuzzy matching
function levenshteinDistance(s1, s2) {
  const m = s1.length;
  const n = s2.length;
  const dp = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));

  for (let i = 0; i <= m; i++) dp[i][0] = i;
  for (let j = 0; j <= n; j++) dp[0][j] = j;

  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      if (s1[i - 1] === s2[j - 1]) {
        dp[i][j] = dp[i - 1][j - 1];
      } else {
        dp[i][j] = Math.min(
          dp[i - 1][j] + 1,    // deletion
          dp[i][j - 1] + 1,    // insertion
          dp[i - 1][j - 1] + 1 // substitution
        );
      }
    }
  }
  return dp[m][n];
}

// Check if two words are a fuzzy match
function isFuzzyMatch(phrase1, phrase2) {
  const p1 = phrase1.toLowerCase().trim();
  const p2 = phrase2.toLowerCase().trim();
  if (p1 === p2) return true;

  const len = Math.max(p1.length, p2.length);
  let maxDist = 0;
  if (len >= 9) maxDist = 2;
  else if (len >= 5) maxDist = 1;

  return levenshteinDistance(p1, p2) <= maxDist;
}

// Unified match finder supporting exact, regex, and fuzzy matching
function findMatchesInText(text, keyword, matchMode, caseSensitive) {
  if (!text || !keyword) return { count: 0, snippets: [] };

  if (matchMode === 'fuzzy') {
    const keyWords = keyword.toLowerCase().split(/\s+/).filter(Boolean);
    // Strip common punctuation before word comparison to avoid noise
    const words = text.replace(/[.,\/#!$%\^&\*;:{}=\-_`~()?"'\[\]]/g, ' ').split(/\s+/).filter(Boolean);
    let count = 0;
    const matchedPhrases = [];
    const snippets = [];

    const keyLen = keyWords.length;
    if (keyLen === 1) {
      words.forEach(word => {
        if (isFuzzyMatch(word, keyword)) {
          count++;
          matchedPhrases.push(word);
        }
      });
    } else if (keyLen > 1) {
      for (let i = 0; i <= words.length - keyLen; i++) {
        const slice = words.slice(i, i + keyLen).join(' ');
        if (isFuzzyMatch(slice, keyword)) {
          count++;
          matchedPhrases.push(slice);
        }
      }
    }

    // Find snippet contexts for unique matches
    if (count > 0 && matchedPhrases.length > 0) {
      const uniques = Array.from(new Set(matchedPhrases));
      const snippetLength = 60;

      for (const phrase of uniques) {
        let idx = 0;
        const searchStr = text.toLowerCase();
        const pStr = phrase.toLowerCase();

        while ((idx = searchStr.indexOf(pStr, idx)) !== -1) {
          const start = Math.max(0, idx - snippetLength / 2);
          const end = Math.min(text.length, idx + pStr.length + snippetLength / 2);
          let snippet = text.substring(start, end).trim();
          if (start > 0) snippet = '...' + snippet;
          if (end < text.length) snippet = snippet + '...';
          snippets.push(snippet);
          idx += pStr.length;
          if (snippets.length >= 3) break;
        }
        if (snippets.length >= 3) break;
      }
    }

    return { count, snippets };
  } else {
    // Exact or RegEx search
    let keywordRegex;
    try {
      if (matchMode === 'regex') {
        keywordRegex = new RegExp(keyword, caseSensitive ? 'g' : 'gi');
      } else {
        const escaped = keyword.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
        const spacedRegex = escaped.replace(/\s+/g, '\\s+');
        keywordRegex = new RegExp(spacedRegex, caseSensitive ? 'g' : 'gi');
      }
    } catch (e) {
      // Fallback for invalid regex pattern inputs
      const escaped = keyword.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
      const spacedRegex = escaped.replace(/\s+/g, '\\s+');
      keywordRegex = new RegExp(spacedRegex, caseSensitive ? 'g' : 'gi');
    }

    const matches = text.match(keywordRegex);
    if (!matches) return { count: 0, snippets: [] };

    const count = matches.length;
    const snippets = [];
    const snippetLength = 60;

    const execRegex = new RegExp(keywordRegex.source, keywordRegex.flags.includes('g') ? keywordRegex.flags : keywordRegex.flags + 'g');
    let m;
    let iterations = 0;
    while ((m = execRegex.exec(text)) !== null && iterations < 10) {
      iterations++;
      const idx = m.index;
      const matchStr = m[0];
      const start = Math.max(0, idx - snippetLength / 2);
      const end = Math.min(text.length, idx + matchStr.length + snippetLength / 2);
      let snippet = text.substring(start, end).trim();
      if (start > 0) snippet = '...' + snippet;
      if (end < text.length) snippet = snippet + '...';
      snippets.push(snippet);

      if (execRegex.lastIndex === idx) execRegex.lastIndex++;
      if (snippets.length >= 3) break;
    }

    return { count, snippets };
  }
}

// Multi-layered keyword search using DOMParser
function searchPage(html, keyword, matchMode, caseSensitive) {
  const results = {
    totalMatches: 0,
    matches: []
  };

  try {
    // Accept a pre-parsed Document so several terms can be searched with one parse
    const doc = typeof html === 'string'
      ? new DOMParser().parseFromString(html, 'text/html')
      : html;

    // 1. Page Title
    const titleText = doc.title || '';
    if (titleText) {
      const res = findMatchesInText(titleText, keyword, matchMode, caseSensitive);
      if (res.count > 0) {
        results.totalMatches += res.count;
        results.matches.push({
          location: 'Page Title',
          snippet: titleText,
          count: res.count
        });
      }
    }

    // 2. Meta Description
    const metaDescNode = doc.querySelector('meta[name="description"]');
    const metaDescText = metaDescNode ? (metaDescNode.getAttribute('content') || '').trim() : '';
    if (metaDescText) {
      const res = findMatchesInText(metaDescText, keyword, matchMode, caseSensitive);
      if (res.count > 0) {
        results.totalMatches += res.count;
        results.matches.push({
          location: 'Meta Description',
          snippet: metaDescText,
          count: res.count
        });
      }
    }

    // 3. Image Alt Tags
    let altCount = 0;
    const altSnippets = [];
    doc.querySelectorAll('img[alt]').forEach(el => {
      const val = el.getAttribute('alt').trim();
      if (!val) return;
      const res = findMatchesInText(val, keyword, matchMode, caseSensitive);
      if (res.count > 0) {
        altCount += res.count;
        altSnippets.push(`[alt]: ${val}`);
      }
    });
    if (altCount > 0) {
      results.totalMatches += altCount;
      results.matches.push({
        location: 'Image Alt Tags',
        snippet: `Found ${altCount} match${altCount === 1 ? '' : 'es'} in alt attributes. E.g. ${altSnippets.slice(0, 3).map(s => `"${s}"`).join(', ')}`,
        count: altCount
      });
    }

    // 4. Aria Labels
    let ariaCount = 0;
    const ariaSnippets = [];
    doc.querySelectorAll('[aria-label]').forEach(el => {
      const val = el.getAttribute('aria-label').trim();
      if (!val) return;
      const res = findMatchesInText(val, keyword, matchMode, caseSensitive);
      if (res.count > 0) {
        ariaCount += res.count;
        ariaSnippets.push(`[aria-label]: ${val}`);
      }
    });
    if (ariaCount > 0) {
      results.totalMatches += ariaCount;
      results.matches.push({
        location: 'Aria Labels',
        snippet: `Found ${ariaCount} match${ariaCount === 1 ? '' : 'es'} in aria-labels. E.g. ${ariaSnippets.slice(0, 3).map(s => `"${s}"`).join(', ')}`,
        count: ariaCount
      });
    }

    // 5. Placeholders
    let placeholderCount = 0;
    const placeholderSnippets = [];
    doc.querySelectorAll('[placeholder]').forEach(el => {
      const val = el.getAttribute('placeholder').trim();
      if (!val) return;
      const res = findMatchesInText(val, keyword, matchMode, caseSensitive);
      if (res.count > 0) {
        placeholderCount += res.count;
        placeholderSnippets.push(`[placeholder]: ${val}`);
      }
    });
    if (placeholderCount > 0) {
      results.totalMatches += placeholderCount;
      results.matches.push({
        location: 'Input Placeholders',
        snippet: `Found ${placeholderCount} match${placeholderCount === 1 ? '' : 'es'} in placeholders. E.g. ${placeholderSnippets.slice(0, 3).map(s => `"${s}"`).join(', ')}`,
        count: placeholderCount
      });
    }

    // 6. HTML Attributes (class, id, data-*, and others)
    const classMatches = [];
    const idMatches = [];
    const dataMatches = [];
    const otherMatches = [];

    const allElements = doc.querySelectorAll('*');
    allElements.forEach(el => {
      const tag = el.tagName.toUpperCase();
      if (tag === 'SCRIPT' || tag === 'STYLE') return;

      for (const attr of el.attributes) {
        const name = attr.name.toLowerCase();
        const val = attr.value.trim();
        if (!val) continue;

        const res = findMatchesInText(val, keyword, matchMode, caseSensitive);
        if (res.count > 0) {
          const tagSnippet = `<${el.tagName.toLowerCase()} ${attr.name}="${val}">`;
          if (name === 'class') {
            classMatches.push({ count: res.count, snippet: tagSnippet });
          } else if (name === 'id') {
            idMatches.push({ count: res.count, snippet: tagSnippet });
          } else if (name.startsWith('data-')) {
            dataMatches.push({ count: res.count, snippet: tagSnippet });
          } else {
            // Skip attributes that are already processed in separate visual categories
            if (['alt', 'aria-label', 'placeholder'].includes(name)) {
              continue;
            }
            otherMatches.push({ count: res.count, snippet: tagSnippet });
          }
        }
      }
    });

    if (idMatches.length > 0) {
      const totalIdCount = idMatches.reduce((sum, m) => sum + m.count, 0);
      results.totalMatches += totalIdCount;
      results.matches.push({
        location: 'Element IDs',
        snippet: `Found ${totalIdCount} match${totalIdCount === 1 ? '' : 'es'}. E.g. ${idMatches.map(m => m.snippet).slice(0, 3).join(' | ')}`,
        count: totalIdCount
      });
    }

    if (classMatches.length > 0) {
      const totalClassCount = classMatches.reduce((sum, m) => sum + m.count, 0);
      results.totalMatches += totalClassCount;
      results.matches.push({
        location: 'CSS Classes',
        snippet: `Found ${totalClassCount} match${totalClassCount === 1 ? '' : 'es'}. E.g. ${classMatches.map(m => m.snippet).slice(0, 3).join(' | ')}`,
        count: totalClassCount
      });
    }

    if (dataMatches.length > 0) {
      const totalDataCount = dataMatches.reduce((sum, m) => sum + m.count, 0);
      results.totalMatches += totalDataCount;
      results.matches.push({
        location: 'Data Attributes (data-*)',
        snippet: `Found ${totalDataCount} match${totalDataCount === 1 ? '' : 'es'}. E.g. ${dataMatches.map(m => m.snippet).slice(0, 3).join(' | ')}`,
        count: totalDataCount
      });
    }

    if (otherMatches.length > 0) {
      const totalOtherCount = otherMatches.reduce((sum, m) => sum + m.count, 0);
      results.totalMatches += totalOtherCount;
      results.matches.push({
        location: 'Other Attributes',
        snippet: `Found ${totalOtherCount} match${totalOtherCount === 1 ? '' : 'es'}. E.g. ${otherMatches.map(m => m.snippet).slice(0, 3).join(' | ')}`,
        count: totalOtherCount
      });
    }

    // 7. Visible Content (Layout-aware block text extraction to support phrases split by inline tags)
    function getVisibleTextBlocks(node) {
      const blocks = [];
      let currentBlock = "";

      function traverse(n) {
        if (n.nodeType === 3) { // Node.TEXT_NODE
          currentBlock += n.nodeValue;
        } else if (n.nodeType === 1) { // Node.ELEMENT_NODE
          const tag = n.tagName.toUpperCase();
          if (['SCRIPT', 'STYLE', 'TEXTAREA', 'INPUT', 'SELECT'].includes(tag)) {
            return;
          }
          
          const isBlock = ['P', 'DIV', 'H1', 'H2', 'H3', 'H4', 'H5', 'H6', 'LI', 'TR', 'BR', 'HR', 'TD', 'TH', 'OPTION'].includes(tag);
          if (isBlock && currentBlock.trim()) {
            blocks.push(currentBlock);
            currentBlock = "";
          }
          
          for (let child of n.childNodes) {
            traverse(child);
          }
          
          if (isBlock && currentBlock.trim()) {
            blocks.push(currentBlock);
            currentBlock = "";
          }
        }
      }

      traverse(node);
      if (currentBlock.trim()) {
        blocks.push(currentBlock);
      }
      return blocks;
    }

    const bodyNode = doc.body || doc.documentElement;
    const textBlocks = getVisibleTextBlocks(bodyNode);

    let visibleCount = 0;
    const visibleSnippets = [];
    textBlocks.forEach(text => {
      if (!text.trim()) return;

      const res = findMatchesInText(text, keyword, matchMode, caseSensitive);
      if (res.count > 0) {
        visibleCount += res.count;
        res.snippets.forEach(s => {
          if (visibleSnippets.length < 3) {
            visibleSnippets.push(s);
          }
        });
      }
    });

    if (visibleCount > 0) {
      results.totalMatches += visibleCount;
      results.matches.push({
        location: 'Visible Content',
        snippet: visibleSnippets.join(' | '),
        count: visibleCount
      });
    }

  } catch (e) {
    console.error("DOMParser search failed, falling back to basic text regex matching:", e);
    // Safe fallback if DOMParser has issues or environment differs
    const plainText = typeof html === 'string'
      ? html.replace(/<[^>]+>/g, ' ')
      : ((html && html.documentElement && html.documentElement.textContent) || '');
    const res = findMatchesInText(plainText, keyword, matchMode, caseSensitive);
    if (res.count > 0) {
      results.totalMatches += res.count;
      results.matches.push({
        location: 'Visible Content (Fallback)',
        snippet: res.snippets.join(' | '),
        count: res.count
      });
    }
  }

  return results;
}

// Search one page for several terms. The HTML is parsed once; every match record is
// tagged with the term that produced it, and per-term totals are returned.
function searchPageTerms(html, terms, matchMode, caseSensitive) {
  const list = (Array.isArray(terms) ? terms : [terms]).filter(Boolean);
  const out = { totalMatches: 0, matches: [], termCounts: {} };
  let doc = html;
  try {
    doc = new DOMParser().parseFromString(html, 'text/html');
  } catch (e) {
    // searchPage falls back to plain-text matching when given a string
  }
  for (const term of list) {
    const res = searchPage(doc, term, matchMode, caseSensitive);
    res.matches.forEach(m => { m.term = term; });
    out.totalMatches += res.totalMatches;
    out.matches.push(...res.matches);
    out.termCounts[term] = res.totalMatches;
  }
  return out;
}

// Receive messages and perform parsing/searching
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'PARSE_HTML') {
    try {
      const results = searchPageTerms(
        message.html,
        message.terms && message.terms.length ? message.terms : [message.keyword],
        message.matchMode,
        message.caseSensitive
      );
      sendResponse({ success: true, results });
    } catch (err) {
      sendResponse({ success: false, error: err.message });
    }
    return true; // async response
  }
});
