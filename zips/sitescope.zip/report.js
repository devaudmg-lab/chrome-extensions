// SiteScope Dashboard Controller Script (ES Module)
import { getAudit, getAuditResults, getAuditHistory, deleteAudit } from './storage.js';

document.addEventListener('DOMContentLoaded', () => {
  // DOM Elements
  const historyList = document.getElementById('historyList');
  const activeReportSection = document.getElementById('activeReportSection');
  const noReportSection = document.getElementById('noReportSection');

  const reportDomain = document.getElementById('reportDomain');
  const reportKeyword = document.getElementById('reportKeyword');
  const reportMode = document.getElementById('reportMode');
  const reportCase = document.getElementById('reportCase');
  const reportDate = document.getElementById('reportDate');

  const summaryCrawled = document.getElementById('summaryCrawled');
  const summaryMatches = document.getElementById('summaryMatches');
  const summaryErrors = document.getElementById('summaryErrors');
  const summaryDuration = document.getElementById('summaryDuration');

  const tableSearchInput = document.getElementById('tableSearchInput');
  const matchFilterSelect = document.getElementById('matchFilterSelect');
  const reportTableBody = document.getElementById('reportTableBody');
  const exportCsvBtn = document.getElementById('exportCsvBtn');
  const exportPdfBtn = document.getElementById('exportPdfBtn');
  const exportJsonBtn = document.getElementById('exportJsonBtn');
  const exportHtmlBtn = document.getElementById('exportHtmlBtn');
  const rerunBtn = document.getElementById('rerunBtn');
  const termBreakdown = document.getElementById('termBreakdown');
  const termFilterSelect = document.getElementById('termFilterSelect');
  const reportKeywordLabel = document.getElementById('reportKeywordLabel');
  const toastEl = document.getElementById('toast');

  let toastTimer = null;
  function showToast(msg, isError) {
    toastEl.textContent = msg;
    toastEl.classList.toggle('error', !!isError);
    toastEl.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { toastEl.hidden = true; }, 3500);
  }

  // Terms searched by an audit (audits from before v1.3 stored a single keyword)
  function auditTerms(audit) {
    if (!audit) return [];
    return Array.isArray(audit.terms) && audit.terms.length ? audit.terms : [audit.keyword];
  }

  // Per-term totals: { term: { count, pages } }
  function computeTermStats(audit, results) {
    const terms = auditTerms(audit);
    const stats = {};
    terms.forEach(t => { stats[t] = { count: 0, pages: 0 }; });
    results.forEach(r => {
      const seen = new Set();
      (r.matches || []).forEach(m => {
        const t = m.term || terms[0];
        if (!stats[t]) stats[t] = { count: 0, pages: 0 };
        stats[t].count += m.count || 0;
        seen.add(t);
      });
      seen.forEach(t => { stats[t].pages++; });
    });
    return stats;
  }

  // State
  let activeAuditId = null;
  let activeAudit = null; // Active audit metadata object
  let activeResults = [];
  let expandedRows = new Set(); // Stores result ID of expanded details rows

  // 1. Initial Load: Populate History and check parameters
  loadHistory();
  checkUrlParams();

  // 2. Check for URL parameters (?id=X)
  function checkUrlParams() {
    const urlParams = new URLSearchParams(window.location.search);
    const idParam = urlParams.get('id');
    if (idParam) {
      const auditId = parseInt(idParam, 10);
      if (!isNaN(auditId)) {
        loadAuditDetails(auditId);
      }
    }
  }

  // 3. Load & Render Audit History Sidebar
  async function loadHistory() {
    try {
      const history = await getAuditHistory();
      historyList.innerHTML = '';

      if (history.length === 0) {
        historyList.innerHTML = '<div class="empty-state">No audits recorded.</div>';
        return;
      }

      history.forEach((audit) => {
        const item = document.createElement('div');
        item.className = 'history-item';
        if (audit.id === activeAuditId) {
          item.classList.add('active');
        }

        const dateStr = new Date(audit.startTime).toLocaleDateString(undefined, {
          month: 'short',
          day: 'numeric',
          hour: '2-digit',
          minute: '2-digit'
        });

        let statusTag = '';
        if (audit.status === 'running') {
          statusTag = '<span class="status-badge active"><div class="dot"></div>Live</span>';
        }

        item.innerHTML = `
          <button class="delete-btn" title="Delete Audit" data-id="${audit.id}">×</button>
          <div style="display:flex; justify-content:space-between; align-items:center;">
            <h4>${escapeHtml(audit.domain)}</h4>
            ${statusTag}
          </div>
          <div class="history-keyword">"${escapeHtml(audit.keyword)}"</div>
          <div class="history-meta">
            <span>${dateStr}</span>
            <span>${audit.totalCrawled || 0} pages · ${audit.totalMatches || 0} matches</span>
          </div>
        `;

        item.addEventListener('click', (e) => {
          if (e.target.classList.contains('delete-btn')) return;
          loadAuditDetails(audit.id);
        });

        const delBtn = item.querySelector('.delete-btn');
        delBtn.addEventListener('click', async (e) => {
          e.stopPropagation();
          if (confirm(`Are you sure you want to delete the audit for ${audit.domain}?`)) {
            await deleteAudit(audit.id);
            if (activeAuditId === audit.id) {
              activeAuditId = null;
              activeAudit = null;
              activeReportSection.style.display = 'none';
              noReportSection.style.display = 'flex';
            }
            loadHistory();
          }
        });

        historyList.appendChild(item);
      });
    } catch (e) {
      console.error("Error loading audit history:", e);
    }
  }

  // 4. Load Audit Session Details
  async function loadAuditDetails(auditId) {
    // Keep expanded rows when the same audit is refreshed live
    if (activeAuditId !== auditId) expandedRows.clear();
    activeAuditId = auditId;

    // Highlight selected item in sidebar
    const items = historyList.querySelectorAll('.history-item');
    items.forEach(item => {
      const delBtn = item.querySelector('.delete-btn');
      if (delBtn && parseInt(delBtn.dataset.id, 10) === auditId) {
        item.classList.add('active');
      } else {
        item.classList.remove('active');
      }
    });

    try {
      const audit = await getAudit(auditId);
      if (!audit) {
        activeReportSection.style.display = 'none';
        noReportSection.style.display = 'flex';
        activeAudit = null;
        return;
      }

      activeAudit = audit;

      // Show main dashboard section
      noReportSection.style.display = 'none';
      activeReportSection.style.display = 'flex';

      // Set Metadata Headers
      reportDomain.textContent = audit.domain;
      const terms = auditTerms(audit);
      reportKeywordLabel.textContent = terms.length > 1 ? `Terms (${terms.length})` : 'Keyword';
      reportKeyword.textContent = terms.map(t => `"${t}"`).join(', ');

      // Match mode mapping display
      let modeText = 'Exact Match';
      if (audit.matchMode === 'regex') modeText = 'RegEx';
      else if (audit.matchMode === 'fuzzy') modeText = 'Fuzzy';
      reportMode.textContent = modeText;

      reportCase.textContent = audit.caseSensitive ? 'Yes' : 'No';
      reportDate.textContent = new Date(audit.startTime).toLocaleString();

      // Fetch Detailed Results
      activeResults = await getAuditResults(auditId);

      // Render Summary Stats
      summaryCrawled.textContent = activeResults.length;

      const totalMatches = activeResults.reduce((acc, curr) => acc + (curr.matchCount || 0), 0);
      summaryMatches.textContent = totalMatches;

      const failedCount = activeResults.filter(r => r.status < 200 || r.status >= 300).length;
      summaryErrors.textContent = failedCount;

      // Calculate Scan Duration
      if (audit.endTime) {
        const diffMs = audit.endTime - audit.startTime;
        const seconds = (diffMs / 1000).toFixed(1);
        summaryDuration.textContent = `${seconds}s`;
      } else if (audit.status === 'running') {
        summaryDuration.textContent = 'Scanning...';
      } else {
        summaryDuration.textContent = 'N/A';
      }

      renderTermBreakdown();
      rerunBtn.disabled = audit.status === 'running';

      // Initial Table Render
      renderTable();
    } catch (e) {
      console.error("Error loading audit details:", e);
    }
  }

  // 5. Render Audit Results Table
  function renderTable() {
    const searchTerm = tableSearchInput.value.toLowerCase().trim();
    const filterVal = matchFilterSelect.value;
    const termVal = termFilterSelect.hidden ? 'all' : termFilterSelect.value;
    const terms = auditTerms(activeAudit);
    const multiTerm = terms.length > 1;

    reportTableBody.innerHTML = '';

    if (activeResults.length === 0) {
      const msg = activeAudit && activeAudit.status === 'running'
        ? 'Scanning... pages appear here as soon as they are crawled.'
        : 'This audit has no scanned pages. It may have been stopped before the first page finished.';
      reportTableBody.innerHTML = `<tr><td colspan="4" style="text-align: center; color: var(--text-muted); padding: 40px 20px;">${msg}</td></tr>`;
      return;
    }

    const filtered = activeResults.filter(result => {
      const matchesSearch = result.url.toLowerCase().includes(searchTerm);

      let matchesFilter = true;
      if (filterVal === 'matches') {
        matchesFilter = result.matchCount > 0;
      } else if (filterVal === 'errors') {
        matchesFilter = result.status < 200 || result.status >= 300;
      }

      const matchesTerm = termVal === 'all' ||
        (result.matches || []).some(m => (m.term || terms[0]) === termVal);

      return matchesSearch && matchesFilter && matchesTerm;
    });

    if (filtered.length === 0) {
      reportTableBody.innerHTML = `
        <tr>
          <td colspan="4" style="text-align: center; color: var(--text-muted); padding: 40px 20px;">
            No results match the current search or filters.
          </td>
        </tr>
      `;
      return;
    }

    filtered.forEach(result => {
      const tr = document.createElement('tr');
      tr.className = 'table-row';
      tr.dataset.id = result.id;

      const isSuccess = result.status >= 200 && result.status < 300;
      const statusClass = isSuccess ? 'status-indicator success' : 'status-indicator error';
      const statusDot = isSuccess ? '🟢' : '🔴';

      const showDetailsBtn = result.matchCount > 0;
      const detailsBtnHtml = showDetailsBtn
        ? `<button class="toggle-details-btn" data-id="${result.id}">${expandedRows.has(result.id) ? 'Hide' : 'View'} Matches (${result.matchCount})</button>`
        : result.error
          ? `<span style="color: var(--color-error); font-size: 12px;" title="${escapeHtml(result.error)}">${escapeHtml(result.error.slice(0, 40))}</span>`
          : `<span style="color: var(--text-dimmed); font-size: 12px;">No matches</span>`;
      const recheckHtml = `<button class="recheck-btn" data-id="${result.id}" title="Fetch this page again and update its result">↻</button>`;
      const recheckedTag = result.rechecked ? `<span class="rechecked-tag" title="Rechecked ${escapeHtml(new Date(result.scannedTime).toLocaleString())}">rechecked</span>` : '';
      const safeUrl = escapeHtml(result.url);

      tr.innerHTML = `
        <td>
          <span class="${statusClass}">${statusDot} ${escapeHtml(result.status)}</span>
        </td>
        <td>
          <a href="${safeUrl}" target="_blank" rel="noopener noreferrer" class="page-link" title="Open page in new tab">${safeUrl}</a>${recheckedTag}
        </td>
        <td style="text-align: right; font-weight: 600; padding-right: 30px;">
          ${result.matchCount}
        </td>
        <td style="text-align: center;">
          <div class="details-actions">${detailsBtnHtml}${recheckHtml}</div>
        </td>
      `;

      reportTableBody.appendChild(tr);

      // Collapsible details row
      if (expandedRows.has(result.id) && showDetailsBtn) {
        const detailsTr = document.createElement('tr');
        detailsTr.className = 'details-row';

        let snippetsHtml = '';
        result.matches.forEach(match => {
          if (termVal !== 'all' && (match.term || terms[0]) !== termVal) return;
          const termTag = multiTerm && match.term ? `<span class="term-tag">${escapeHtml(match.term)}</span>` : '';
          snippetsHtml += `
            <div class="snippet-item">
              <div class="snippet-header">${termTag}${escapeHtml(match.location)} (${match.count} match${match.count > 1 ? 'es' : ''})</div>
              <div class="snippet-text">${escapeHtml(String(match.snippet || '').replace(/\s+/g, ' '))}</div>
            </div>
          `;
        });

        detailsTr.innerHTML = `
          <td colspan="4" class="details-cell">
            <div class="details-container">
              <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
                <div class="details-title">Match Context Breakdown</div>
                <button class="btn btn-secondary highlight-btn" data-url="${safeUrl}" style="padding: 4px 8px; font-size: 11px;">Highlight in Context ↗</button>
              </div>
              <div class="snippet-list">
                ${snippetsHtml}
              </div>
            </div>
          </td>
        `;
        reportTableBody.appendChild(detailsTr);
      }
    });

    // Hook collapsible details toggle buttons
    const toggleBtns = reportTableBody.querySelectorAll('.toggle-details-btn');
    toggleBtns.forEach(btn => {
      btn.addEventListener('click', (e) => {
        const id = parseInt(btn.dataset.id, 10);
        if (expandedRows.has(id)) {
          expandedRows.delete(id);
        } else {
          expandedRows.add(id);
        }
        renderTable();
      });
    });

    // Hook Highlight buttons
    const highlightBtns = reportTableBody.querySelectorAll('.highlight-btn');
    highlightBtns.forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const url = btn.dataset.url;
        if (activeAudit) {
          chrome.runtime.sendMessage({
            type: 'LAUNCH_HIGHLIGHT',
            url: url,
            keyword: activeAudit.keyword,
            terms: auditTerms(activeAudit),
            matchMode: activeAudit.matchMode || 'exact',
            caseSensitive: activeAudit.caseSensitive
          });
        }
      });
    });

    // Hook Recheck buttons: re-fetch a single page and refresh its row
    reportTableBody.querySelectorAll('.recheck-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const resultId = parseInt(btn.dataset.id, 10);
        const auditId = activeAuditId;
        btn.disabled = true;
        btn.classList.add('spinning');
        chrome.runtime.sendMessage({ type: 'RESCAN_PAGE', auditId, resultId }, async (res) => {
          void chrome.runtime.lastError;
          if (!res || !res.success) {
            btn.disabled = false;
            btn.classList.remove('spinning');
            showToast((res && res.error) || 'Could not recheck this page.', true);
            return;
          }
          if (res.error) {
            showToast(`Recheck failed: ${res.error}`, true);
          } else {
            showToast(`Rechecked: ${res.previousCount} → ${res.matchCount} match${res.matchCount === 1 ? '' : 'es'}`);
          }
          if (activeAuditId === auditId) await loadAuditDetails(auditId);
          loadHistory();
        });
      });
    });
  }

  // Per-term chips with match and page counts; clicking one filters the table
  function renderTermBreakdown() {
    const terms = auditTerms(activeAudit);
    const prev = termFilterSelect.value;
    termFilterSelect.innerHTML = '<option value="all">All terms</option>';
    terms.forEach(t => {
      const opt = document.createElement('option');
      opt.value = t;
      opt.textContent = t;
      termFilterSelect.appendChild(opt);
    });
    termFilterSelect.value = terms.includes(prev) ? prev : 'all';

    if (terms.length < 2) {
      termBreakdown.hidden = true;
      termFilterSelect.hidden = true;
      termFilterSelect.value = 'all';
      return;
    }
    termFilterSelect.hidden = false;
    termBreakdown.hidden = false;
    const stats = computeTermStats(activeAudit, activeResults);
    termBreakdown.innerHTML = '';
    terms.forEach(t => {
      const st = stats[t] || { count: 0, pages: 0 };
      const chip = document.createElement('button');
      chip.type = 'button';
      chip.className = 'term-chip' + (st.count === 0 ? ' zero' : '') + (termFilterSelect.value === t ? ' active' : '');
      chip.innerHTML = `<span class="term-chip-name">${escapeHtml(t)}</span><span class="term-chip-count">${st.count}</span><span class="term-chip-pages">${st.pages} page${st.pages === 1 ? '' : 's'}</span>`;
      chip.title = st.count === 0 ? 'Not found anywhere on the scanned pages' : `Show only pages containing "${t}"`;
      chip.addEventListener('click', () => {
        termFilterSelect.value = termFilterSelect.value === t ? 'all' : t;
        renderTermBreakdown();
        renderTable();
      });
      termBreakdown.appendChild(chip);
    });
  }

  function escapeHtml(unsafe) {
    return String(unsafe == null ? '' : unsafe)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  tableSearchInput.addEventListener('input', renderTable);
  matchFilterSelect.addEventListener('change', renderTable);
  termFilterSelect.addEventListener('change', () => {
    renderTermBreakdown();
    renderTable();
  });

  // Keyboard: "/" focuses the URL filter, Esc clears it
  document.addEventListener('keydown', (e) => {
    const typing = /^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement && document.activeElement.tagName);
    if (e.key === '/' && !typing && activeReportSection.style.display !== 'none') {
      e.preventDefault();
      tableSearchInput.focus();
    } else if (e.key === 'Escape' && document.activeElement === tableSearchInput) {
      tableSearchInput.value = '';
      tableSearchInput.blur();
      renderTable();
    }
  });

  // Re-run the selected audit with identical settings
  rerunBtn.addEventListener('click', () => {
    if (!activeAudit) return;
    const a = activeAudit;
    rerunBtn.disabled = true;
    showToast('Starting a new run of this audit...');
    chrome.runtime.sendMessage({
      type: 'START_AUDIT',
      url: a.startUrl || `https://${a.domain}/`,
      keyword: auditTerms(a).join('\n'),
      caseSensitive: !!a.caseSensitive,
      respectRobots: a.respectRobots !== false,
      useSitemap: a.useSitemap !== false,
      jsRendering: !!a.jsRendering,
      matchMode: a.matchMode || 'exact',
      scanScope: a.scanScope || 'site',
      maxPages: a.maxPages || 100,
      excludePatterns: a.excludePatterns || [],
      speed: a.speed || 'normal'
    }, async (res) => {
      void chrome.runtime.lastError;
      rerunBtn.disabled = false;
      if (!res || !res.success) {
        showToast((res && res.error) || 'Could not start the audit.', true);
        return;
      }
      history.replaceState(null, '', `report.html?id=${res.auditId}`);
      await loadHistory();
      loadAuditDetails(res.auditId);
    });
  });

  // Standalone, shareable HTML report (inline styles, no scripts, opens in any browser)
  exportHtmlBtn.addEventListener('click', () => {
    if (!activeAudit) return;
    const html = buildHtmlReport(activeAudit, activeResults);
    const blobUrl = URL.createObjectURL(new Blob([html], { type: 'text/html;charset=utf-8' }));
    const link = document.createElement('a');
    link.href = blobUrl;
    link.download = `sitescope_report_${activeAudit.domain}_${new Date().toISOString().slice(0, 10)}.html`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setTimeout(() => URL.revokeObjectURL(blobUrl), 1000);
    showToast('HTML report downloaded.');
  });

  function buildHtmlReport(audit, results) {
    const terms = auditTerms(audit);
    const stats = computeTermStats(audit, results);
    const withMatches = results.filter(r => r.matchCount > 0).sort((a, b) => b.matchCount - a.matchCount);
    const failed = results.filter(r => r.status < 200 || r.status >= 300);
    const clean = results.filter(r => r.matchCount === 0 && r.status >= 200 && r.status < 300);
    const total = results.reduce((n, r) => n + (r.matchCount || 0), 0);
    const modeText = audit.matchMode === 'regex' ? 'Regular expression' : audit.matchMode === 'fuzzy' ? 'Fuzzy' : 'Exact match';
    const duration = audit.endTime ? `${((audit.endTime - audit.startTime) / 1000).toFixed(1)}s` : 'n/a';
    const e = escapeHtml;

    const termRows = terms.map(t => {
      const st = stats[t] || { count: 0, pages: 0 };
      return `<tr><td><code>${e(t)}</code></td><td class="n">${st.count}</td><td class="n">${st.pages}</td></tr>`;
    }).join('');

    const pageBlocks = withMatches.map(r => {
      const snippets = (r.matches || []).map(m => `
        <div class="snip"><div class="loc">${terms.length > 1 && m.term ? `<span class="tag">${e(m.term)}</span>` : ''}${e(m.location)} · ${m.count}</div><div>${e(m.snippet)}</div></div>`).join('');
      return `<section class="page"><h3><a href="${e(r.url)}">${e(r.url)}</a><span class="cnt">${r.matchCount}</span></h3>${snippets}</section>`;
    }).join('');

    const failedRows = failed.map(r => `<li><code>${e(r.status)}</code> ${e(r.url)}${r.error ? ` <span class="muted">(${e(r.error)})</span>` : ''}</li>`).join('');
    const cleanRows = clean.map(r => `<li>${e(r.url)}</li>`).join('');

    return `<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>SiteScope report: ${e(audit.domain)}</title>
<style>
body{font-family:'Segoe UI',system-ui,-apple-system,Roboto,sans-serif;color:#1d2433;background:#f6f7fb;margin:0;padding:32px 16px;line-height:1.5}
main{max-width:960px;margin:0 auto}
h1{margin:0 0 4px;font-size:26px}h2{font-size:17px;margin:32px 0 12px}
.meta{color:#5b6478;font-size:13px}.muted{color:#7a8396}
.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:20px 0}
.stat{background:#fff;border:1px solid #e3e6ef;border-radius:10px;padding:14px;text-align:center}
.stat b{display:block;font-size:24px;color:#6d28d9}.stat span{font-size:11px;text-transform:uppercase;letter-spacing:.05em;color:#5b6478}
table{width:100%;border-collapse:collapse;background:#fff;border:1px solid #e3e6ef;border-radius:10px;overflow:hidden}
th,td{padding:9px 12px;border-bottom:1px solid #eef0f5;text-align:left;font-size:14px}th{background:#f1f3f9;font-size:11px;text-transform:uppercase;letter-spacing:.05em;color:#5b6478}
td.n{text-align:right;font-variant-numeric:tabular-nums}
.page{background:#fff;border:1px solid #e3e6ef;border-radius:10px;padding:12px 16px;margin-bottom:12px;page-break-inside:avoid}
.page h3{font-size:14px;margin:0 0 8px;display:flex;justify-content:space-between;gap:12px;word-break:break-all}
.page a{color:#1d4ed8;text-decoration:none}.cnt{background:#ede9fe;color:#6d28d9;border-radius:20px;padding:0 10px;font-size:12px;white-space:nowrap}
.snip{border-left:3px solid #8b5cf6;background:#faf9ff;padding:6px 10px;margin:6px 0;font-size:13px;word-break:break-word}
.loc{font-size:11px;font-weight:600;text-transform:uppercase;color:#0e7490;letter-spacing:.03em}
.tag{background:#cffafe;color:#155e75;border-radius:4px;padding:0 6px;margin-right:6px;text-transform:none}
ul{background:#fff;border:1px solid #e3e6ef;border-radius:10px;padding:12px 12px 12px 32px;font-size:13px;word-break:break-all}
details summary{cursor:pointer;color:#5b6478;font-size:14px}
footer{margin-top:32px;font-size:12px;color:#7a8396}
@media (max-width:640px){.stats{grid-template-columns:repeat(2,1fr)}}
</style></head><body><main>
<h1>${e(audit.domain)}</h1>
<div class="meta">${terms.length > 1 ? 'Terms' : 'Keyword'}: ${terms.map(t => `<code>${e(t)}</code>`).join(', ')} · ${e(modeText)}${audit.caseSensitive ? ' · case sensitive' : ''} · ${e(new Date(audit.startTime).toLocaleString())}</div>
<div class="stats">
<div class="stat"><b>${results.length}</b><span>Pages scanned</span></div>
<div class="stat"><b>${total}</b><span>Total matches</span></div>
<div class="stat"><b>${withMatches.length}</b><span>Pages with matches</span></div>
<div class="stat"><b>${failed.length}</b><span>Failed pages</span></div>
</div>
<h2>Matches by term</h2>
<table><thead><tr><th>Term</th><th style="text-align:right">Matches</th><th style="text-align:right">Pages</th></tr></thead><tbody>${termRows}</tbody></table>
<h2>Pages with matches (${withMatches.length})</h2>
${pageBlocks || '<p class="muted">No matches were found on any scanned page.</p>'}
${failed.length ? `<h2>Failed pages (${failed.length})</h2><ul>${failedRows}</ul>` : ''}
${clean.length ? `<h2>Pages without matches</h2><details><summary>${clean.length} page${clean.length === 1 ? '' : 's'} scanned with no matches</summary><ul>${cleanRows}</ul></details>` : ''}
<footer>Generated by SiteScope Content Auditor on ${e(new Date().toLocaleString())} · scan duration ${e(duration)}</footer>
</main></body></html>`;
  }

  // CSV Exporter
  exportCsvBtn.addEventListener('click', () => {
    if (!activeAuditId || activeResults.length === 0) return;

    let csvContent =`"Page URL","HTTP Status","Keyword Match Count","Terms Found","Details / Context"\n`;

    activeResults.forEach(r => {
      const escapedUrl = r.url.replace(/"/g, '""');
      const status = r.status;
      const matchCount = r.matchCount;

      const detailsList = r.matches.map(m => `[${m.term ? m.term + ' / ' : ''}${m.location}]: ${m.snippet.replace(/"/g, '""')}`);
      const escapedDetails = `"${detailsList.join(' | ')}"`;
      const termsFound = Array.from(new Set(r.matches.map(m => m.term).filter(Boolean))).join('; ').replace(/"/g, '""');

      csvContent += `"${escapedUrl}",${status},${matchCount},"${termsFound}",${escapedDetails}\n`;
    });

    // Blob URL instead of an encodeURI'd data: URI ('#' in snippets truncated the file)
    const blobUrl = URL.createObjectURL(new Blob([csvContent], { type: 'text/csv;charset=utf-8' }));
    const link = document.createElement("a");
    link.setAttribute("href", blobUrl);

    const dateStamp = new Date().toISOString().slice(0,10);
    link.setAttribute("download", `sitescope_audit_${reportDomain.textContent}_${dateStamp}.csv`);
    document.body.appendChild(link);

    link.click();
    document.body.removeChild(link);
    setTimeout(() => URL.revokeObjectURL(blobUrl), 1000);
  });

  // JSON Exporter: full audit metadata plus every page result, for scripting or archiving
  exportJsonBtn.addEventListener('click', () => {
    if (!activeAuditId || !activeAudit) return;

    const payload = {
      generator: 'SiteScope Content Auditor',
      exportedAt: new Date().toISOString(),
      audit: activeAudit,
      results: activeResults.map(r => ({
        url: r.url,
        rechecked: !!r.rechecked,
        status: r.status,
        matchCount: r.matchCount,
        matches: r.matches,
        error: r.error || null,
        scannedTime: r.scannedTime
      }))
    };

    const blobUrl = URL.createObjectURL(new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' }));
    const link = document.createElement('a');
    link.href = blobUrl;
    const dateStamp = new Date().toISOString().slice(0, 10);
    link.download = `sitescope_audit_${reportDomain.textContent}_${dateStamp}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setTimeout(() => URL.revokeObjectURL(blobUrl), 1000);
  });

  // Print PDF exporter triggering native window print dialog
  exportPdfBtn.addEventListener('click', () => {
    if (!activeAuditId || activeResults.length === 0) return;

    // Expand all items that have matches before printing so details show up
    activeResults.forEach(r => {
      if (r.matchCount > 0) {
        expandedRows.add(r.id);
      }
    });

    renderTable();
    window.print();
  });

  // Listen for progress updates. The crawler broadcasts several times per page, so
  // refreshes are throttled to keep the dashboard responsive during large crawls.
  let refreshTimer = null;
  let pendingState = null;
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === 'STATUS_UPDATE') {
      pendingState = message.state;
      if (refreshTimer) return;
      refreshTimer = setTimeout(() => {
        refreshTimer = null;
        const state = pendingState;
        loadHistory();
        if (state && activeAuditId === state.currentAuditId) {
          loadAuditDetails(state.currentAuditId);
        }
      }, 1500);
    }
  });
});
