// SiteScope Dashboard Controller Script (ES Module)
import { getAudit, getAuditResults, getAuditHistory, getStorageCounts } from './storage.js';

document.addEventListener('DOMContentLoaded', () => {
  // DOM Elements
  const historyList = document.getElementById('historyList');
  const activeReportSection = document.getElementById('activeReportSection');
  const noReportSection = document.getElementById('noReportSection');

  const reportDomain = document.getElementById('reportDomain');
  const reportKeyword = document.getElementById('reportKeyword');
  const reportMode = document.getElementById('reportMode');
  const reportCase = document.getElementById('reportCase');
  const reportDate = document.getElementById('reportDate');
  const reportStatusNote = document.getElementById('reportStatusNote');

  const summaryCrawled = document.getElementById('summaryCrawled');
  const summaryMatches = document.getElementById('summaryMatches');
  const summaryErrors = document.getElementById('summaryErrors');
  const summaryDuration = document.getElementById('summaryDuration');

  const tableSearchInput = document.getElementById('tableSearchInput');
  const matchFilterSelect = document.getElementById('matchFilterSelect');
  const reportTableBody = document.getElementById('reportTableBody');
  const exportCsvBtn = document.getElementById('exportCsvBtn');
  const exportPdfBtn = document.getElementById('exportPdfBtn');
  const exportJsonBtn = document.getElementById('exportJsonBtn');
  const exportHtmlBtn = document.getElementById('exportHtmlBtn');
  const rerunBtn = document.getElementById('rerunBtn');
  const termBreakdown = document.getElementById('termBreakdown');
  const termFilterSelect = document.getElementById('termFilterSelect');
  const reportKeywordLabel = document.getElementById('reportKeywordLabel');
  const toastEl = document.getElementById('toast');
  const compareBanner = document.getElementById('compareBanner');
  const resultCount = document.getElementById('resultCount');
  const sortButtons = Array.from(document.querySelectorAll('.sort-btn'));

  const storageSummary = document.getElementById('storageSummary');
  const retentionCountSelect = document.getElementById('retentionCountSelect');
  const retentionAgeSelect = document.getElementById('retentionAgeSelect');
  const clearHistoryBtn = document.getElementById('clearHistoryBtn');

  let toastTimer = null;
  function showToast(msg, isError) {
    toastEl.textContent = msg;
    toastEl.classList.toggle('error', !!isError);
    toastEl.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { toastEl.hidden = true; }, 3500);
  }

  function sendMessage(msg) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage(msg, (res) => {
        void chrome.runtime.lastError;
        resolve(res);
      });
    });
  }

  // Terms searched by an audit (audits from before v1.3 stored a single keyword)
  function auditTerms(audit) {
    if (!audit) return [];
    return Array.isArray(audit.terms) && audit.terms.length ? audit.terms : [audit.keyword];
  }

  const isOk = (r) => r.status >= 200 && r.status < 300;

  // Per-term totals: { term: { count, pages } }
  function computeTermStats(audit, results) {
    const terms = auditTerms(audit);
    const stats = {};
    terms.forEach(t => { stats[t] = { count: 0, pages: 0 }; });
    results.forEach(r => {
      const seen = new Set();
      (r.matches || []).forEach(m => {
        const t = m.term || terms[0];
        if (!stats[t]) stats[t] = { count: 0, pages: 0 };
        stats[t].count += m.count || 0;
        seen.add(t);
      });
      seen.forEach(t => { stats[t].pages++; });
    });
    return stats;
  }

  // State
  let activeAuditId = null;
  let activeAudit = null; // Active audit metadata object
  let activeResults = [];
  let expandedRows = new Set(); // Stores result ID of expanded details rows
  let loadToken = 0; // guards against out-of-order async loads
  let historyCache = [];
  let sortKey = 'crawl';
  let sortDir = 1;

  // Comparison with the previous run of the same audit (same site, terms and mode)
  let comparison = null; // { prevAudit, changes: Map(url -> change), summary }
  const prevResultsCache = new Map(); // prevAuditId -> results

  // 1. Initial Load: populate history, then open the requested (or newest) audit
  (async () => {
    await loadHistory();
    const idParam = parseInt(new URLSearchParams(window.location.search).get('id'), 10);
    if (!isNaN(idParam)) {
      loadAuditDetails(idParam);
    } else if (historyCache.length) {
      loadAuditDetails(historyCache[0].id);
    }
    loadStoragePanel();
  })();

  function sameTerms(a, b) {
    const x = auditTerms(a).slice().sort().join('\n');
    const y = auditTerms(b).slice().sort().join('\n');
    return x === y;
  }

  // 3. Load & Render Audit History Sidebar
  async function loadHistory() {
    try {
      const audits = await getAuditHistory();
      historyCache = audits;
      historyList.innerHTML = '';

      if (audits.length === 0) {
        historyList.innerHTML = '<div class="empty-state">No audits recorded.</div>';
        return;
      }

      audits.forEach((audit) => {
        const item = document.createElement('div');
        item.className = 'history-item';
        item.tabIndex = 0;
        item.setAttribute('role', 'button');
        item.dataset.id = audit.id;
        if (audit.id === activeAuditId) {
          item.classList.add('active');
          item.setAttribute('aria-current', 'true');
        }

        const dateStr = new Date(audit.startTime).toLocaleDateString(undefined, {
          month: 'short',
          day: 'numeric',
          hour: '2-digit',
          minute: '2-digit'
        });

        let statusTag = '';
        if (audit.status === 'running') {
          statusTag = '<span class="status-badge active"><div class="dot"></div>Live</span>';
        } else if (audit.status === 'stopped') {
          statusTag = `<span class="history-status">${audit.interrupted ? 'Interrupted' : 'Stopped'}</span>`;
        }

        item.innerHTML = `
          <button class="delete-btn" type="button" title="Delete audit" aria-label="Delete audit of ${escapeHtml(audit.domain)}">×</button>
          <div class="history-title-row">
            <h4>${escapeHtml(audit.domain)}</h4>
            ${statusTag}
          </div>
          <div class="history-keyword">"${escapeHtml(audit.keyword)}"</div>
          <div class="history-meta">
            <span>${escapeHtml(dateStr)}</span>
            <span>${audit.totalCrawled || 0} pages · ${audit.totalMatches || 0} matches</span>
          </div>
        `;

        const open = () => {
          window.history.replaceState(null, '', `report.html?id=${audit.id}`);
          loadAuditDetails(audit.id);
        };
        item.addEventListener('click', (e) => {
          if (e.target.closest('.delete-btn')) return;
          open();
        });
        item.addEventListener('keydown', (e) => {
          if (e.target !== item) return;
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            open();
          } else if (e.key === 'Delete') {
            item.querySelector('.delete-btn').click();
          }
        });

        const delBtn = item.querySelector('.delete-btn');
        delBtn.addEventListener('click', async (e) => {
          e.stopPropagation();
          const running = audit.status === 'running';
          const question = running
            ? `The audit of ${audit.domain} is still running. Stop it and delete it?`
            : `Delete the audit of ${audit.domain}?`;
          if (!confirm(question)) return;
          const res = await sendMessage({ type: 'DELETE_AUDIT', auditId: audit.id });
          if (!res || !res.success) {
            showToast((res && res.error) || 'Could not delete the audit.', true);
            return;
          }
          prevResultsCache.delete(audit.id);
          if (activeAuditId === audit.id) showEmptyState();
          await loadHistory();
          loadStoragePanel();
        });

        historyList.appendChild(item);
      });
    } catch (e) {
      console.error('Error loading audit history:', e);
    }
  }

  function showEmptyState() {
    activeAuditId = null;
    activeAudit = null;
    activeResults = [];
    comparison = null;
    activeReportSection.style.display = 'none';
    noReportSection.style.display = 'flex';
  }

  // 4. Load Audit Session Details
  async function loadAuditDetails(auditId) {
    const token = ++loadToken;
    // Keep expanded rows when the same audit is refreshed live
    if (activeAuditId !== auditId) {
      expandedRows.clear();
      comparison = null;
    }
    activeAuditId = auditId;

    historyList.querySelectorAll('.history-item').forEach(item => {
      const on = parseInt(item.dataset.id, 10) === auditId;
      item.classList.toggle('active', on);
      if (on) item.setAttribute('aria-current', 'true');
      else item.removeAttribute('aria-current');
    });

    try {
      const audit = await getAudit(auditId);
      if (token !== loadToken) return;
      if (!audit) {
        showEmptyState();
        return;
      }
      const results = await getAuditResults(auditId);
      const cmp = await buildComparison(audit, results);
      if (token !== loadToken) return; // another audit was selected meanwhile

      activeAudit = audit;
      activeResults = results;
      comparison = cmp;

      noReportSection.style.display = 'none';
      activeReportSection.style.display = 'flex';

      reportDomain.textContent = audit.domain;
      const terms = auditTerms(audit);
      reportKeywordLabel.textContent = terms.length > 1 ? `Terms (${terms.length})` : 'Keyword';
      reportKeyword.textContent = terms.map(t => `"${t}"`).join(', ');

      let modeText = 'Exact Match';
      if (audit.matchMode === 'regex') modeText = 'RegEx';
      else if (audit.matchMode === 'fuzzy') modeText = 'Fuzzy';
      reportMode.textContent = modeText;

      reportCase.textContent = audit.caseSensitive ? 'Yes' : 'No';
      reportDate.textContent = new Date(audit.startTime).toLocaleString();

      // Why the audit may be incomplete
      const notes = [];
      if (audit.status === 'stopped') notes.push(audit.interrupted ? 'Interrupted (browser closed during the crawl)' : 'Stopped before it finished');
      if (audit.status === 'completed' && audit.queueRemaining > 0) notes.push(`Page limit reached: ${audit.queueRemaining} more page${audit.queueRemaining === 1 ? '' : 's'} were found but not scanned`);
      if (audit.crawlDelay > 0) notes.push(`robots.txt Crawl-delay of ${audit.crawlDelay}s was honoured`);
      reportStatusNote.textContent = notes.join(' · ');
      reportStatusNote.hidden = notes.length === 0;

      summaryCrawled.textContent = results.length;
      summaryMatches.textContent = results.reduce((acc, curr) => acc + (curr.matchCount || 0), 0);
      summaryErrors.textContent = results.filter(r => !isOk(r)).length;

      if (audit.endTime) {
        summaryDuration.textContent = formatDuration(audit.endTime - audit.startTime);
      } else if (audit.status === 'running') {
        summaryDuration.textContent = 'Scanning...';
      } else {
        summaryDuration.textContent = 'N/A';
      }

      renderTermBreakdown();
      renderCompareBanner();
      rerunBtn.disabled = audit.status === 'running';
      renderTable();
    } catch (e) {
      console.error('Error loading audit details:', e);
    }
  }

  function formatDuration(ms) {
    const s = Math.max(0, ms) / 1000;
    if (s < 60) return `${s.toFixed(1)}s`;
    const m = Math.floor(s / 60);
    if (m < 60) return `${m}m ${Math.round(s % 60)}s`;
    return `${Math.floor(m / 60)}h ${m % 60}m`;
  }

  // ---- Compare with the previous run ----
  function findPreviousAudit(audit) {
    return historyCache.find(a =>
      a.id !== audit.id &&
      a.startTime < audit.startTime &&
      a.status !== 'running' &&
      a.domain === audit.domain &&
      (a.matchMode || 'exact') === (audit.matchMode || 'exact') &&
      !!a.caseSensitive === !!audit.caseSensitive &&
      sameTerms(a, audit)
    ) || null;
  }

  async function buildComparison(audit, results) {
    if (!historyCache.some(a => a.id === audit.id)) {
      historyCache = await getAuditHistory();
    }
    const prevAudit = findPreviousAudit(audit);
    if (!prevAudit) return null;
    let prevResults = prevResultsCache.get(prevAudit.id);
    if (!prevResults) {
      prevResults = await getAuditResults(prevAudit.id);
      prevResultsCache.set(prevAudit.id, prevResults);
    }
    const before = new Map();
    prevResults.forEach(r => { if (isOk(r)) before.set(r.url, r.matchCount || 0); });

    const changes = new Map();
    const summary = { fixed: 0, added: 0, more: 0, fewer: 0, same: 0, newPages: 0, notRechecked: 0 };
    const seen = new Set();
    results.forEach(r => {
      seen.add(r.url);
      if (!isOk(r)) return;
      const now = r.matchCount || 0;
      if (!before.has(r.url)) {
        if (now > 0) { changes.set(r.url, { type: 'new-page', delta: now }); summary.newPages++; }
        return;
      }
      const was = before.get(r.url);
      if (was > 0 && now === 0) { changes.set(r.url, { type: 'fixed', delta: -was }); summary.fixed++; }
      else if (was === 0 && now > 0) { changes.set(r.url, { type: 'added', delta: now }); summary.added++; }
      else if (now > was) { changes.set(r.url, { type: 'more', delta: now - was }); summary.more++; }
      else if (now < was) { changes.set(r.url, { type: 'fewer', delta: now - was }); summary.fewer++; }
      else if (now > 0) summary.same++;
    });
    // Pages that had matches last time but were not scanned in this run
    before.forEach((count, url) => { if (count > 0 && !seen.has(url)) summary.notRechecked++; });
    return { prevAudit, changes, summary };
  }

  function renderCompareBanner() {
    const showChangeFilters = !!comparison;
    matchFilterSelect.querySelectorAll('.compare-option').forEach(o => { o.hidden = !showChangeFilters; o.disabled = !showChangeFilters; });
    if (!showChangeFilters && /^(fixed|new)$/.test(matchFilterSelect.value)) matchFilterSelect.value = 'all';

    if (!comparison) {
      compareBanner.hidden = true;
      compareBanner.innerHTML = '';
      return;
    }
    const s = comparison.summary;
    const when = new Date(comparison.prevAudit.startTime).toLocaleString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
    const newCount = s.added + s.newPages;
    const parts = [
      `<button type="button" class="compare-stat good" data-filter="fixed"><b>${s.fixed}</b> fixed</button>`,
      `<button type="button" class="compare-stat bad" data-filter="new"><b>${newCount}</b> new</button>`,
      `<span class="compare-stat"><b>${s.fewer}</b> fewer</span>`,
      `<span class="compare-stat"><b>${s.more}</b> more</span>`,
      `<span class="compare-stat"><b>${s.same}</b> unchanged</span>`
    ];
    if (s.notRechecked) parts.push(`<span class="compare-stat muted" title="Pages that had matches last time but were not scanned in this run"><b>${s.notRechecked}</b> not scanned this time</span>`);
    compareBanner.innerHTML = `
      <div class="compare-title">Since the previous run <button type="button" class="link-btn" data-open="${comparison.prevAudit.id}">${escapeHtml(when)}</button></div>
      <div class="compare-stats">${parts.join('')}</div>`;
    compareBanner.hidden = false;
    compareBanner.querySelectorAll('[data-filter]').forEach(btn => {
      btn.addEventListener('click', () => {
        matchFilterSelect.value = matchFilterSelect.value === btn.dataset.filter ? 'all' : btn.dataset.filter;
        renderTable();
      });
    });
    compareBanner.querySelector('[data-open]').addEventListener('click', (e) => {
      const id = parseInt(e.currentTarget.dataset.open, 10);
      window.history.replaceState(null, '', `report.html?id=${id}`);
      loadAuditDetails(id);
    });
  }

  function changeTag(result) {
    if (!comparison) return '';
    const c = comparison.changes.get(result.url);
    if (!c) return '';
    const map = {
      'fixed': ['good', 'fixed', 'Had matches in the previous run, none now'],
      'added': ['bad', 'new', 'No matches in the previous run'],
      'new-page': ['bad', 'new page', 'Not scanned in the previous run'],
      'more': ['bad', `+${c.delta}`, 'More matches than the previous run'],
      'fewer': ['good', `${c.delta}`, 'Fewer matches than the previous run']
    };
    const [cls, label, title] = map[c.type];
    return `<span class="change-tag ${cls}" title="${title}">${escapeHtml(label)}</span>`;
  }

  function changeLabel(result) {
    if (!comparison) return '';
    const c = comparison.changes.get(result.url);
    if (!c) return '';
    return { 'fixed': 'fixed', 'added': 'new', 'new-page': 'new page', 'more': `+${c.delta}`, 'fewer': `${c.delta}` }[c.type];
  }

  // 5. Render Audit Results Table
  function filteredResults() {
    const searchTerm = tableSearchInput.value.toLowerCase().trim();
    const filterVal = matchFilterSelect.value;
    const termVal = termFilterSelect.hidden ? 'all' : termFilterSelect.value;
    const terms = auditTerms(activeAudit);

    const list = activeResults.filter(result => {
      if (searchTerm && !result.url.toLowerCase().includes(searchTerm)) return false;
      if (filterVal === 'matches' && !(result.matchCount > 0)) return false;
      if (filterVal === 'errors' && isOk(result)) return false;
      if (filterVal === 'fixed' || filterVal === 'new') {
        const c = comparison && comparison.changes.get(result.url);
        if (!c) return false;
        if (filterVal === 'fixed' && c.type !== 'fixed') return false;
        if (filterVal === 'new' && c.type !== 'added' && c.type !== 'new-page') return false;
      }
      if (termVal !== 'all' && !(result.matches || []).some(m => (m.term || terms[0]) === termVal)) return false;
      return true;
    });

    if (sortKey !== 'crawl') {
      const cmp = {
        url: (a, b) => a.url.localeCompare(b.url),
        matches: (a, b) => (a.matchCount || 0) - (b.matchCount || 0),
        status: (a, b) => (a.status || 0) - (b.status || 0)
      }[sortKey];
      list.sort((a, b) => cmp(a, b) * sortDir || a.id - b.id);
    }
    return list;
  }

  function renderTable() {
    const terms = auditTerms(activeAudit);
    const multiTerm = terms.length > 1;
    const termVal = termFilterSelect.hidden ? 'all' : termFilterSelect.value;

    reportTableBody.innerHTML = '';
    sortButtons.forEach(btn => {
      const th = btn.closest('th');
      const on = btn.dataset.sort === sortKey;
      th.setAttribute('aria-sort', on ? (sortDir > 0 ? 'ascending' : 'descending') : 'none');
      btn.dataset.dir = on ? (sortDir > 0 ? 'asc' : 'desc') : '';
    });

    if (activeResults.length === 0) {
      const msg = activeAudit && activeAudit.status === 'running'
        ? 'Scanning... pages appear here as soon as they are crawled.'
        : 'This audit has no scanned pages. It may have been stopped before the first page finished.';
      reportTableBody.innerHTML = `<tr><td colspan="4" class="table-message">${msg}</td></tr>`;
      resultCount.textContent = '';
      return;
    }

    const filtered = filteredResults();
    resultCount.textContent = filtered.length === activeResults.length
      ? `${activeResults.length} page${activeResults.length === 1 ? '' : 's'}`
      : `${filtered.length} of ${activeResults.length} pages`;

    if (filtered.length === 0) {
      reportTableBody.innerHTML = '<tr><td colspan="4" class="table-message">No results match the current search or filters.</td></tr>';
      return;
    }

    const fragment = document.createDocumentFragment();
    filtered.forEach(result => {
      const tr = document.createElement('tr');
      tr.className = 'table-row';
      tr.dataset.id = result.id;

      const success = isOk(result);
      const statusClass = success ? 'status-indicator success' : 'status-indicator error';
      const statusDot = success ? '🟢' : '🔴';
      const statusText = result.status ? String(result.status) : 'ERR';

      const showDetailsBtn = result.matchCount > 0;
      const expanded = expandedRows.has(result.id);
      const detailsBtnHtml = showDetailsBtn
        ? `<button class="toggle-details-btn" type="button" data-id="${result.id}" aria-expanded="${expanded}">${expanded ? 'Hide' : 'View'} Matches (${result.matchCount})</button>`
        : result.error
          ? `<span class="row-error" title="${escapeHtml(result.error)}">${escapeHtml(result.error.slice(0, 40))}</span>`
          : '<span class="row-none">No matches</span>';
      const recheckHtml = `<button class="recheck-btn" type="button" data-id="${result.id}" title="Fetch this page again and update its result" aria-label="Recheck ${escapeHtml(result.url)}">↻</button>`;
      const recheckedTag = result.rechecked ? `<span class="rechecked-tag" title="Rechecked ${escapeHtml(new Date(result.scannedTime).toLocaleString())}">rechecked</span>` : '';
      const redirectTag = result.finalUrl ? `<span class="redirect-tag" title="Redirected to ${escapeHtml(result.finalUrl)}">redirect</span>` : '';
      const safeUrl = escapeHtml(result.url);

      tr.innerHTML = `
        <td>
          <span class="${statusClass}">${statusDot} ${escapeHtml(statusText)}</span>
        </td>
        <td class="url-cell">
          <a href="${safeUrl}" target="_blank" rel="noopener noreferrer" class="page-link" title="Open page in new tab">${safeUrl}</a>${redirectTag}${recheckedTag}
        </td>
        <td class="matches-cell">
          ${result.matchCount || 0}${changeTag(result)}
        </td>
        <td class="details-cell-actions">
          <div class="details-actions">${detailsBtnHtml}${recheckHtml}</div>
        </td>
      `;
      fragment.appendChild(tr);

      // Collapsible details row
      if (expanded && showDetailsBtn) {
        const detailsTr = document.createElement('tr');
        detailsTr.className = 'details-row';

        let snippetsHtml = '';
        (result.matches || []).forEach(match => {
          if (termVal !== 'all' && (match.term || terms[0]) !== termVal) return;
          const termTag = multiTerm && match.term ? `<span class="term-tag">${escapeHtml(match.term)}</span>` : '';
          snippetsHtml += `
            <div class="snippet-item">
              <div class="snippet-header">${termTag}${escapeHtml(match.location)} (${match.count} match${match.count > 1 ? 'es' : ''})</div>
              <div class="snippet-text">${escapeHtml(String(match.snippet || '').replace(/\s+/g, ' '))}</div>
            </div>
          `;
        });

        detailsTr.innerHTML = `
          <td colspan="4" class="details-cell">
            <div class="details-container">
              <div class="details-head">
                <div class="details-title">Match Context Breakdown</div>
                <button class="btn btn-secondary highlight-btn" type="button" data-url="${safeUrl}">Highlight in Context ↗</button>
              </div>
              <div class="snippet-list">
                ${snippetsHtml}
              </div>
            </div>
          </td>
        `;
        fragment.appendChild(detailsTr);
      }
    });
    reportTableBody.appendChild(fragment);
  }

  // Row actions are delegated, so re-rendering the table does not re-bind hundreds of listeners
  reportTableBody.addEventListener('click', (e) => {
    const toggle = e.target.closest('.toggle-details-btn');
    if (toggle) {
      const id = parseInt(toggle.dataset.id, 10);
      if (expandedRows.has(id)) expandedRows.delete(id);
      else expandedRows.add(id);
      renderTable();
      const again = reportTableBody.querySelector(`.toggle-details-btn[data-id="${id}"]`);
      if (again) again.focus();
      return;
    }

    const hl = e.target.closest('.highlight-btn');
    if (hl && activeAudit) {
      chrome.runtime.sendMessage({
        type: 'LAUNCH_HIGHLIGHT',
        url: hl.dataset.url,
        keyword: activeAudit.keyword,
        terms: auditTerms(activeAudit),
        matchMode: activeAudit.matchMode || 'exact',
        caseSensitive: activeAudit.caseSensitive
      }, () => void chrome.runtime.lastError);
      return;
    }

    const btn = e.target.closest('.recheck-btn');
    if (btn) {
      const resultId = parseInt(btn.dataset.id, 10);
      const auditId = activeAuditId;
      btn.disabled = true;
      btn.classList.add('spinning');
      sendMessage({ type: 'RESCAN_PAGE', auditId, resultId }).then(async (res) => {
        if (!res || !res.success) {
          btn.disabled = false;
          btn.classList.remove('spinning');
          showToast((res && res.error) || 'Could not recheck this page.', true);
          return;
        }
        if (res.error) {
          showToast(`Recheck failed: ${res.error}`, true);
        } else {
          showToast(`Rechecked: ${res.previousCount} → ${res.matchCount} match${res.matchCount === 1 ? '' : 'es'}`);
        }
        if (activeAuditId === auditId) await loadAuditDetails(auditId);
        loadHistory();
      });
    }
  });

  // Sortable columns: click once for descending (most matches first), again to flip
  sortButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const key = btn.dataset.sort;
      if (sortKey === key) {
        if (sortDir === (key === 'url' ? -1 : 1)) { sortKey = 'crawl'; sortDir = 1; }
        else sortDir = -sortDir;
      } else {
        sortKey = key;
        sortDir = key === 'url' ? 1 : -1;
      }
      renderTable();
    });
  });

  // Per-term chips with match and page counts; clicking one filters the table
  function renderTermBreakdown() {
    const terms = auditTerms(activeAudit);
    const prev = termFilterSelect.value;
    termFilterSelect.innerHTML = '<option value="all">All terms</option>';
    terms.forEach(t => {
      const opt = document.createElement('option');
      opt.value = t;
      opt.textContent = t;
      termFilterSelect.appendChild(opt);
    });
    termFilterSelect.value = terms.includes(prev) ? prev : 'all';

    if (terms.length < 2) {
      termBreakdown.hidden = true;
      termFilterSelect.hidden = true;
      termFilterSelect.value = 'all';
      return;
    }
    termFilterSelect.hidden = false;
    termBreakdown.hidden = false;
    const stats = computeTermStats(activeAudit, activeResults);
    termBreakdown.innerHTML = '';
    terms.forEach(t => {
      const st = stats[t] || { count: 0, pages: 0 };
      const chip = document.createElement('button');
      chip.type = 'button';
      const active = termFilterSelect.value === t;
      chip.className = 'term-chip' + (st.count === 0 ? ' zero' : '') + (active ? ' active' : '');
      chip.setAttribute('aria-pressed', String(active));
      chip.innerHTML = `<span class="term-chip-name">${escapeHtml(t)}</span><span class="term-chip-count">${st.count}</span><span class="term-chip-pages">${st.pages} page${st.pages === 1 ? '' : 's'}</span>`;
      chip.title = st.count === 0 ? 'Not found anywhere on the scanned pages' : `Show only pages containing "${t}"`;
      chip.addEventListener('click', () => {
        termFilterSelect.value = termFilterSelect.value === t ? 'all' : t;
        renderTermBreakdown();
        renderTable();
      });
      termBreakdown.appendChild(chip);
    });
  }

  function escapeHtml(unsafe) {
    return String(unsafe == null ? '' : unsafe)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  tableSearchInput.addEventListener('input', renderTable);
  matchFilterSelect.addEventListener('change', renderTable);
  termFilterSelect.addEventListener('change', () => {
    renderTermBreakdown();
    renderTable();
  });

  // Keyboard: "/" focuses the URL filter, Esc clears it
  document.addEventListener('keydown', (e) => {
    const typing = /^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement && document.activeElement.tagName);
    if (e.key === '/' && !typing && activeReportSection.style.display !== 'none') {
      e.preventDefault();
      tableSearchInput.focus();
    } else if (e.key === 'Escape' && document.activeElement === tableSearchInput) {
      tableSearchInput.value = '';
      tableSearchInput.blur();
      renderTable();
    }
  });

  // Re-run the selected audit with identical settings
  rerunBtn.addEventListener('click', async () => {
    if (!activeAudit) return;
    const a = activeAudit;
    rerunBtn.disabled = true;
    showToast('Starting a new run of this audit...');
    const res = await sendMessage({
      type: 'START_AUDIT',
      url: a.startUrl || `https://${a.domain}/`,
      keyword: auditTerms(a).join('\n'),
      caseSensitive: !!a.caseSensitive,
      respectRobots: a.respectRobots !== false,
      useSitemap: a.useSitemap !== false,
      jsRendering: !!a.jsRendering,
      matchMode: a.matchMode || 'exact',
      scanScope: a.scanScope || 'site',
      maxPages: a.maxPages || 100,
      excludePatterns: a.excludePatterns || [],
      speed: a.speed || 'normal'
    });
    rerunBtn.disabled = false;
    if (!res || !res.success) {
      showToast((res && res.error) || 'Could not start the audit.', true);
      return;
    }
    window.history.replaceState(null, '', `report.html?id=${res.auditId}`);
    await loadHistory();
    loadAuditDetails(res.auditId);
  });

  function download(content, type, filename) {
    const blobUrl = URL.createObjectURL(new Blob([content], { type }));
    const link = document.createElement('a');
    link.href = blobUrl;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setTimeout(() => URL.revokeObjectURL(blobUrl), 1000);
  }

  const fileStem = (kind) => `sitescope_${kind}_${(activeAudit.domain || 'site').replace(/[^\w.-]+/g, '_')}_${new Date().toISOString().slice(0, 10)}`;

  // Standalone, shareable HTML report (inline styles, no scripts, opens in any browser)
  exportHtmlBtn.addEventListener('click', () => {
    if (!activeAudit) return;
    download(buildHtmlReport(activeAudit, activeResults), 'text/html;charset=utf-8', `${fileStem('report')}.html`);
    showToast('HTML report downloaded.');
  });

  function buildHtmlReport(audit, results) {
    const terms = auditTerms(audit);
    const stats = computeTermStats(audit, results);
    const withMatches = results.filter(r => r.matchCount > 0).sort((a, b) => b.matchCount - a.matchCount);
    const failed = results.filter(r => !isOk(r));
    const clean = results.filter(r => r.matchCount === 0 && isOk(r));
    const total = results.reduce((n, r) => n + (r.matchCount || 0), 0);
    const modeText = audit.matchMode === 'regex' ? 'Regular expression' : audit.matchMode === 'fuzzy' ? 'Fuzzy' : 'Exact match';
    const duration = audit.endTime ? formatDuration(audit.endTime - audit.startTime) : 'n/a';
    const e = escapeHtml;

    const termRows = terms.map(t => {
      const st = stats[t] || { count: 0, pages: 0 };
      return `<tr><td><code>${e(t)}</code></td><td class="n">${st.count}</td><td class="n">${st.pages}</td></tr>`;
    }).join('');

    const pageBlocks = withMatches.map(r => {
      const snippets = (r.matches || []).map(m => `
        <div class="snip"><div class="loc">${terms.length > 1 && m.term ? `<span class="tag">${e(m.term)}</span>` : ''}${e(m.location)} · ${m.count}</div><div>${e(m.snippet)}</div></div>`).join('');
      const chg = changeLabel(r);
      return `<section class="page"><h3><a href="${e(r.url)}">${e(r.url)}</a><span class="cnt">${r.matchCount}${chg ? ` · ${e(chg)}` : ''}</span></h3>${snippets}</section>`;
    }).join('');

    const failedRows = failed.map(r => `<li><code>${e(r.status || 'ERR')}</code> ${e(r.url)}${r.error ? ` <span class="muted">(${e(r.error)})</span>` : ''}</li>`).join('');
    const cleanRows = clean.map(r => `<li>${e(r.url)}${changeLabel(r) === 'fixed' ? ' <span class="fixed">fixed</span>' : ''}</li>`).join('');

    let compareHtml = '';
    if (comparison && activeAudit && audit.id === activeAudit.id) {
      const s = comparison.summary;
      compareHtml = `<h2>Changes since the previous run</h2><p class="meta">Compared with the run of ${e(new Date(comparison.prevAudit.startTime).toLocaleString())}: <b>${s.fixed}</b> page${s.fixed === 1 ? '' : 's'} fixed, <b>${s.added + s.newPages}</b> with new matches, <b>${s.fewer}</b> with fewer and <b>${s.more}</b> with more matches, <b>${s.same}</b> unchanged.</p>`;
    }

    return `<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>SiteScope report: ${e(audit.domain)}</title>
<style>
body{font-family:'Segoe UI',system-ui,-apple-system,Roboto,sans-serif;color:#1d2433;background:#f6f7fb;margin:0;padding:32px 16px;line-height:1.5}
main{max-width:960px;margin:0 auto}
h1{margin:0 0 4px;font-size:26px}h2{font-size:17px;margin:32px 0 12px}
.meta{color:#5b6478;font-size:13px}.muted{color:#7a8396}.fixed{color:#15803d;font-weight:600}
.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:20px 0}
.stat{background:#fff;border:1px solid #e3e6ef;border-radius:10px;padding:14px;text-align:center}
.stat b{display:block;font-size:24px;color:#6d28d9}.stat span{font-size:11px;text-transform:uppercase;letter-spacing:.05em;color:#5b6478}
table{width:100%;border-collapse:collapse;background:#fff;border:1px solid #e3e6ef;border-radius:10px;overflow:hidden}
th,td{padding:9px 12px;border-bottom:1px solid #eef0f5;text-align:left;font-size:14px}th{background:#f1f3f9;font-size:11px;text-transform:uppercase;letter-spacing:.05em;color:#5b6478}
td.n{text-align:right;font-variant-numeric:tabular-nums}
.page{background:#fff;border:1px solid #e3e6ef;border-radius:10px;padding:12px 16px;margin-bottom:12px;page-break-inside:avoid}
.page h3{font-size:14px;margin:0 0 8px;display:flex;justify-content:space-between;gap:12px;word-break:break-all}
.page a{color:#1d4ed8;text-decoration:none}.cnt{background:#ede9fe;color:#6d28d9;border-radius:20px;padding:0 10px;font-size:12px;white-space:nowrap}
.snip{border-left:3px solid #8b5cf6;background:#faf9ff;padding:6px 10px;margin:6px 0;font-size:13px;word-break:break-word}
.loc{font-size:11px;font-weight:600;text-transform:uppercase;color:#0e7490;letter-spacing:.03em}
.tag{background:#cffafe;color:#155e75;border-radius:4px;padding:0 6px;margin-right:6px;text-transform:none}
ul{background:#fff;border:1px solid #e3e6ef;border-radius:10px;padding:12px 12px 12px 32px;font-size:13px;word-break:break-all}
details summary{cursor:pointer;color:#5b6478;font-size:14px}
footer{margin-top:32px;font-size:12px;color:#7a8396}
@media (max-width:640px){.stats{grid-template-columns:repeat(2,1fr)}}
</style></head><body><main>
<h1>${e(audit.domain)}</h1>
<div class="meta">${terms.length > 1 ? 'Terms' : 'Keyword'}: ${terms.map(t => `<code>${e(t)}</code>`).join(', ')} · ${e(modeText)}${audit.caseSensitive ? ' · case sensitive' : ''} · ${e(new Date(audit.startTime).toLocaleString())}</div>
<div class="stats">
<div class="stat"><b>${results.length}</b><span>Pages scanned</span></div>
<div class="stat"><b>${total}</b><span>Total matches</span></div>
<div class="stat"><b>${withMatches.length}</b><span>Pages with matches</span></div>
<div class="stat"><b>${failed.length}</b><span>Failed pages</span></div>
</div>
${compareHtml}
<h2>Matches by term</h2>
<table><thead><tr><th>Term</th><th style="text-align:right">Matches</th><th style="text-align:right">Pages</th></tr></thead><tbody>${termRows}</tbody></table>
<h2>Pages with matches (${withMatches.length})</h2>
${pageBlocks || '<p class="muted">No matches were found on any scanned page.</p>'}
${failed.length ? `<h2>Failed pages (${failed.length})</h2><ul>${failedRows}</ul>` : ''}
${clean.length ? `<h2>Pages without matches</h2><details><summary>${clean.length} page${clean.length === 1 ? '' : 's'} scanned with no matches</summary><ul>${cleanRows}</ul></details>` : ''}
<footer>Generated by SiteScope Content Auditor on ${e(new Date().toLocaleString())} · scan duration ${e(duration)}</footer>
</main></body></html>`;
  }

  // CSV cell: quoted, and neutralised when a spreadsheet would read it as a formula
  function csvCell(value) {
    let s = String(value == null ? '' : value);
    if (/^[=+\-@\t\r]/.test(s)) s = `'${s}`;
    return `"${s.replace(/"/g, '""')}"`;
  }

  // CSV Exporter (exports the rows currently shown, in the current order)
  exportCsvBtn.addEventListener('click', () => {
    if (!activeAudit) return;
    const rows = filteredResults();
    if (rows.length === 0) {
      showToast('There are no rows to export with the current filters.', true);
      return;
    }
    const header = ['Page URL', 'HTTP Status', 'Match Count', 'Change vs Previous Run', 'Terms Found', 'Details / Context'];
    let csvContent = header.map(csvCell).join(',') + '\r\n';
    rows.forEach(r => {
      const matches = r.matches || [];
      const details = matches.map(m => `[${m.term ? m.term + ' / ' : ''}${m.location}]: ${String(m.snippet || '').replace(/\s+/g, ' ')}`).join(' | ');
      const termsFound = Array.from(new Set(matches.map(m => m.term).filter(Boolean))).join('; ');
      csvContent += [
        csvCell(r.url),
        csvCell(r.status || 'ERR'),
        csvCell(r.matchCount || 0),
        csvCell(changeLabel(r)),
        csvCell(termsFound),
        csvCell(r.error ? `Error: ${r.error}` : details)
      ].join(',') + '\r\n';
    });
    // The byte-order mark makes Excel read non-English text correctly
    download('﻿' + csvContent, 'text/csv;charset=utf-8', `${fileStem('audit')}.csv`);
    showToast(`CSV exported (${rows.length} row${rows.length === 1 ? '' : 's'}).`);
  });

  // JSON Exporter: full audit metadata plus every page result, for scripting or archiving
  exportJsonBtn.addEventListener('click', () => {
    if (!activeAudit) return;
    const payload = {
      generator: 'SiteScope Content Auditor',
      exportedAt: new Date().toISOString(),
      audit: activeAudit,
      comparedWith: comparison ? { auditId: comparison.prevAudit.id, startTime: comparison.prevAudit.startTime, summary: comparison.summary } : null,
      results: activeResults.map(r => ({
        url: r.url,
        finalUrl: r.finalUrl || null,
        rechecked: !!r.rechecked,
        status: r.status,
        matchCount: r.matchCount,
        change: changeLabel(r) || null,
        matches: r.matches,
        error: r.error || null,
        scannedTime: r.scannedTime
      }))
    };
    download(JSON.stringify(payload, null, 2), 'application/json', `${fileStem('audit')}.json`);
    showToast('JSON exported.');
  });

  // Print PDF exporter triggering native window print dialog
  exportPdfBtn.addEventListener('click', () => {
    if (!activeAudit || activeResults.length === 0) {
      showToast('Nothing to print yet.', true);
      return;
    }
    // Expand all items that have matches before printing so details show up
    const before = new Set(expandedRows);
    activeResults.forEach(r => { if (r.matchCount > 0) expandedRows.add(r.id); });
    renderTable();
    window.print();
    expandedRows = before;
    renderTable();
  });

  // ---- Storage and history retention ----
  function formatBytes(n) {
    if (!n) return '0 KB';
    if (n < 1024 * 1024) return `${Math.max(1, Math.round(n / 1024))} KB`;
    return `${(n / 1024 / 1024).toFixed(1)} MB`;
  }

  async function loadStoragePanel() {
    try {
      const { retention } = await chrome.storage.local.get('retention');
      const r = { maxAudits: 50, maxAgeDays: 0, ...(retention || {}) };
      retentionCountSelect.value = String(r.maxAudits);
      retentionAgeSelect.value = String(r.maxAgeDays);
      const counts = await getStorageCounts();
      const text = `${counts.audits} audit${counts.audits === 1 ? '' : 's'} · ${counts.results} page result${counts.results === 1 ? '' : 's'}`;
      storageSummary.textContent = text;
      clearHistoryBtn.disabled = counts.audits === 0;
      if (navigator.storage && navigator.storage.estimate) {
        const estimate = await navigator.storage.estimate();
        if (estimate && estimate.usage != null) storageSummary.textContent = `${text} · ${formatBytes(estimate.usage)} on disk`;
      }
    } catch (e) {
      // Leave the panel as it is; the settings still work
    }
  }

  async function saveRetention() {
    const retention = {
      maxAudits: parseInt(retentionCountSelect.value, 10) || 0,
      maxAgeDays: parseInt(retentionAgeSelect.value, 10) || 0
    };
    await chrome.storage.local.set({ retention });
    const res = await sendMessage({ type: 'APPLY_RETENTION' });
    if (res && res.success && res.removed) {
      showToast(`Removed ${res.removed} old audit${res.removed === 1 ? '' : 's'}.`);
      await loadHistory();
      if (activeAuditId && !historyCache.some(a => a.id === activeAuditId)) showEmptyState();
    } else {
      showToast('History setting saved.');
    }
    loadStoragePanel();
  }
  retentionCountSelect.addEventListener('change', saveRetention);
  retentionAgeSelect.addEventListener('change', saveRetention);

  clearHistoryBtn.addEventListener('click', async () => {
    if (!confirm('Delete all saved audits and their results? A running audit is kept.')) return;
    const res = await sendMessage({ type: 'CLEAR_HISTORY' });
    if (!res || !res.success) {
      showToast((res && res.error) || 'Could not clear the history.', true);
      return;
    }
    prevResultsCache.clear();
    showToast(`Deleted ${res.removed} audit${res.removed === 1 ? '' : 's'}.`);
    await loadHistory();
    if (!historyCache.some(a => a.id === activeAuditId)) showEmptyState();
    loadStoragePanel();
  });

  // Listen for progress updates. The crawler broadcasts several times per page, so
  // refreshes are throttled to keep the dashboard responsive during large crawls.
  let refreshTimer = null;
  let pendingState = null;
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === 'STATUS_UPDATE') {
      pendingState = message.state;
      if (refreshTimer) return;
      refreshTimer = setTimeout(async () => {
        refreshTimer = null;
        const state = pendingState;
        await loadHistory();
        if (state && activeAuditId === state.currentAuditId) {
          loadAuditDetails(state.currentAuditId);
        }
        if (state && (state.status === 'completed' || state.status === 'stopped')) loadStoragePanel();
      }, 1500);
    }
  });
});
