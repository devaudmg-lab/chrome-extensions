// SiteScope Dashboard Controller Script (ES Module)
import { getAudit, getAuditResults, getAuditHistory, deleteAudit } from './storage.js';

document.addEventListener('DOMContentLoaded', () => {
  // DOM Elements
  const historyList = document.getElementById('historyList');
  const activeReportSection = document.getElementById('activeReportSection');
  const noReportSection = document.getElementById('noReportSection');
  
  const reportDomain = document.getElementById('reportDomain');
  const reportKeyword = document.getElementById('reportKeyword');
  const reportMode = document.getElementById('reportMode');
  const reportCase = document.getElementById('reportCase');
  const reportDate = document.getElementById('reportDate');
  
  const summaryCrawled = document.getElementById('summaryCrawled');
  const summaryMatches = document.getElementById('summaryMatches');
  const summaryErrors = document.getElementById('summaryErrors');
  const summaryDuration = document.getElementById('summaryDuration');
  
  const tableSearchInput = document.getElementById('tableSearchInput');
  const matchFilterSelect = document.getElementById('matchFilterSelect');
  const reportTableBody = document.getElementById('reportTableBody');
  const exportCsvBtn = document.getElementById('exportCsvBtn');
  const exportPdfBtn = document.getElementById('exportPdfBtn');
  const exportJsonBtn = document.getElementById('exportJsonBtn');

  // State
  let activeAuditId = null;
  let activeAudit = null; // Active audit metadata object
  let activeResults = [];
  let expandedRows = new Set(); // Stores result ID of expanded details rows

  // 1. Initial Load: Populate History and check parameters
  loadHistory();
  checkUrlParams();

  // 2. Check for URL parameters (?id=X)
  function checkUrlParams() {
    const urlParams = new URLSearchParams(window.location.search);
    const idParam = urlParams.get('id');
    if (idParam) {
      const auditId = parseInt(idParam, 10);
      if (!isNaN(auditId)) {
        loadAuditDetails(auditId);
      }
    }
  }

  // 3. Load & Render Audit History Sidebar
  async function loadHistory() {
    try {
      const history = await getAuditHistory();
      historyList.innerHTML = '';

      if (history.length === 0) {
        historyList.innerHTML = '<div class="empty-state">No audits recorded.</div>';
        return;
      }

      history.forEach((audit) => {
        const item = document.createElement('div');
        item.className = 'history-item';
        if (audit.id === activeAuditId) {
          item.classList.add('active');
        }

        const dateStr = new Date(audit.startTime).toLocaleDateString(undefined, {
          month: 'short',
          day: 'numeric',
          hour: '2-digit',
          minute: '2-digit'
        });

        let statusTag = '';
        if (audit.status === 'running') {
          statusTag = '<span class="status-badge active"><div class="dot"></div>Live</span>';
        }

        item.innerHTML = `
          <button class="delete-btn" title="Delete Audit" data-id="${audit.id}">×</button>
          <div style="display:flex; justify-content:space-between; align-items:center;">
            <h4>${escapeHtml(audit.domain)}</h4>
            ${statusTag}
          </div>
          <div class="history-keyword">"${escapeHtml(audit.keyword)}"</div>
          <div class="history-meta">
            <span>${dateStr}</span>
            <span>${audit.totalCrawled || 0} pages</span>
          </div>
        `;

        item.addEventListener('click', (e) => {
          if (e.target.classList.contains('delete-btn')) return;
          loadAuditDetails(audit.id);
        });

        const delBtn = item.querySelector('.delete-btn');
        delBtn.addEventListener('click', async (e) => {
          e.stopPropagation();
          if (confirm(`Are you sure you want to delete the audit for ${audit.domain}?`)) {
            await deleteAudit(audit.id);
            if (activeAuditId === audit.id) {
              activeAuditId = null;
              activeAudit = null;
              activeReportSection.style.display = 'none';
              noReportSection.style.display = 'flex';
            }
            loadHistory();
          }
        });

        historyList.appendChild(item);
      });
    } catch (e) {
      console.error("Error loading audit history:", e);
    }
  }

  // 4. Load Audit Session Details
  async function loadAuditDetails(auditId) {
    // Keep expanded rows when the same audit is refreshed live
    if (activeAuditId !== auditId) expandedRows.clear();
    activeAuditId = auditId;
    
    // Highlight selected item in sidebar
    const items = historyList.querySelectorAll('.history-item');
    items.forEach(item => {
      const delBtn = item.querySelector('.delete-btn');
      if (delBtn && parseInt(delBtn.dataset.id, 10) === auditId) {
        item.classList.add('active');
      } else {
        item.classList.remove('active');
      }
    });

    try {
      const audit = await getAudit(auditId);
      if (!audit) {
        activeReportSection.style.display = 'none';
        noReportSection.style.display = 'flex';
        activeAudit = null;
        return;
      }

      activeAudit = audit;

      // Show main dashboard section
      noReportSection.style.display = 'none';
      activeReportSection.style.display = 'flex';

      // Set Metadata Headers
      reportDomain.textContent = audit.domain;
      reportKeyword.textContent = `"${audit.keyword}"`;
      
      // Match mode mapping display
      let modeText = 'Exact Match';
      if (audit.matchMode === 'regex') modeText = 'RegEx';
      else if (audit.matchMode === 'fuzzy') modeText = 'Fuzzy';
      reportMode.textContent = modeText;

      reportCase.textContent = audit.caseSensitive ? 'Yes' : 'No';
      reportDate.textContent = new Date(audit.startTime).toLocaleString();

      // Fetch Detailed Results
      activeResults = await getAuditResults(auditId);

      // Render Summary Stats
      summaryCrawled.textContent = activeResults.length;
      
      const totalMatches = activeResults.reduce((acc, curr) => acc + (curr.matchCount || 0), 0);
      summaryMatches.textContent = totalMatches;

      const failedCount = activeResults.filter(r => r.status < 200 || r.status >= 300).length;
      summaryErrors.textContent = failedCount;

      // Calculate Scan Duration
      if (audit.endTime) {
        const diffMs = audit.endTime - audit.startTime;
        const seconds = (diffMs / 1000).toFixed(1);
        summaryDuration.textContent = `${seconds}s`;
      } else if (audit.status === 'running') {
        summaryDuration.textContent = 'Scanning...';
      } else {
        summaryDuration.textContent = 'N/A';
      }

      // Initial Table Render
      renderTable();
    } catch (e) {
      console.error("Error loading audit details:", e);
    }
  }

  // 5. Render Audit Results Table
  function renderTable() {
    const searchTerm = tableSearchInput.value.toLowerCase().trim();
    const filterVal = matchFilterSelect.value;

    reportTableBody.innerHTML = '';

    const filtered = activeResults.filter(result => {
      const matchesSearch = result.url.toLowerCase().includes(searchTerm);
      
      let matchesFilter = true;
      if (filterVal === 'matches') {
        matchesFilter = result.matchCount > 0;
      } else if (filterVal === 'errors') {
        matchesFilter = result.status < 200 || result.status >= 300;
      }

      return matchesSearch && matchesFilter;
    });

    if (filtered.length === 0) {
      reportTableBody.innerHTML = `
        <tr>
          <td colspan="4" style="text-align: center; color: var(--text-muted); padding: 40px 20px;">
            No results match the current search or filters.
          </td>
        </tr>
      `;
      return;
    }

    filtered.forEach(result => {
      const tr = document.createElement('tr');
      tr.className = 'table-row';
      tr.dataset.id = result.id;

      const isSuccess = result.status >= 200 && result.status < 300;
      const statusClass = isSuccess ? 'status-indicator success' : 'status-indicator error';
      const statusDot = isSuccess ? '🟢' : '🔴';
      
      const showDetailsBtn = result.matchCount > 0;
      const detailsBtnHtml = showDetailsBtn 
        ? `<button class="toggle-details-btn" data-id="${result.id}">View Matches (${result.matchCount})</button>`
        : result.error
          ? `<span style="color: var(--color-error); font-size: 12px;" title="${escapeHtml(result.error)}">${escapeHtml(result.error.slice(0, 40))}</span>`
          : `<span style="color: var(--text-dimmed); font-size: 12px;">No matches</span>`;
      const safeUrl = escapeHtml(result.url);

      tr.innerHTML = `
        <td>
          <span class="${statusClass}">${statusDot} ${escapeHtml(result.status)}</span>
        </td>
        <td>
          <a href="${safeUrl}" target="_blank" rel="noopener noreferrer" class="page-link" title="Open page in new tab">${safeUrl}</a>
        </td>
        <td style="text-align: right; font-weight: 600; padding-right: 30px;">
          ${result.matchCount}
        </td>
        <td style="text-align: center;">
          ${detailsBtnHtml}
        </td>
      `;

      reportTableBody.appendChild(tr);

      // Collapsible details row
      if (expandedRows.has(result.id) && showDetailsBtn) {
        const detailsTr = document.createElement('tr');
        detailsTr.className = 'details-row';
        
        let snippetsHtml = '';
        result.matches.forEach(match => {
          snippetsHtml += `
            <div class="snippet-item">
              <div class="snippet-header">${escapeHtml(match.location)} (${match.count} match${match.count > 1 ? 'es' : ''})</div>
              <div class="snippet-text">${escapeHtml(match.snippet)}</div>
            </div>
          `;
        });

        detailsTr.innerHTML = `
          <td colspan="4" class="details-cell">
            <div class="details-container">
              <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
                <div class="details-title">Match Context Breakdown</div>
                <button class="btn btn-secondary highlight-btn" data-url="${safeUrl}" style="padding: 4px 8px; font-size: 11px;">Highlight in Context ↗</button>
              </div>
              <div class="snippet-list">
                ${snippetsHtml}
              </div>
            </div>
          </td>
        `;
        reportTableBody.appendChild(detailsTr);
      }
    });

    // Hook collapsible details toggle buttons
    const toggleBtns = reportTableBody.querySelectorAll('.toggle-details-btn');
    toggleBtns.forEach(btn => {
      btn.addEventListener('click', (e) => {
        const id = parseInt(btn.dataset.id, 10);
        if (expandedRows.has(id)) {
          expandedRows.delete(id);
        } else {
          expandedRows.add(id);
        }
        renderTable();
      });
    });

    // Hook Highlight buttons
    const highlightBtns = reportTableBody.querySelectorAll('.highlight-btn');
    highlightBtns.forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const url = btn.dataset.url;
        if (activeAudit) {
          chrome.runtime.sendMessage({
            type: 'LAUNCH_HIGHLIGHT',
            url: url,
            keyword: activeAudit.keyword,
            matchMode: activeAudit.matchMode || 'exact',
            caseSensitive: activeAudit.caseSensitive
          });
        }
      });
    });
  }

  function escapeHtml(unsafe) {
    return String(unsafe == null ? '' : unsafe)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  tableSearchInput.addEventListener('input', renderTable);
  matchFilterSelect.addEventListener('change', renderTable);

  // CSV Exporter
  exportCsvBtn.addEventListener('click', () => {
    if (!activeAuditId || activeResults.length === 0) return;

    let csvContent =`"Page URL","HTTP Status","Keyword Match Count","Details / Context"\n`;

    activeResults.forEach(r => {
      const escapedUrl = r.url.replace(/"/g, '""');
      const status = r.status;
      const matchCount = r.matchCount;
      
      const detailsList = r.matches.map(m => `[${m.location}]: ${m.snippet.replace(/"/g, '""')}`);
      const escapedDetails = `"${detailsList.join(' | ')}"`;

      csvContent += `"${escapedUrl}",${status},${matchCount},${escapedDetails}\n`;
    });

    // Blob URL instead of an encodeURI'd data: URI ('#' in snippets truncated the file)
    const blobUrl = URL.createObjectURL(new Blob([csvContent], { type: 'text/csv;charset=utf-8' }));
    const link = document.createElement("a");
    link.setAttribute("href", blobUrl);
    
    const dateStamp = new Date().toISOString().slice(0,10);
    link.setAttribute("download", `sitescope_audit_${reportDomain.textContent}_${dateStamp}.csv`);
    document.body.appendChild(link);
    
    link.click();
    document.body.removeChild(link);
    setTimeout(() => URL.revokeObjectURL(blobUrl), 1000);
  });

  // JSON Exporter: full audit metadata plus every page result, for scripting or archiving
  exportJsonBtn.addEventListener('click', () => {
    if (!activeAuditId || !activeAudit) return;

    const payload = {
      generator: 'SiteScope Content Auditor',
      exportedAt: new Date().toISOString(),
      audit: activeAudit,
      results: activeResults.map(r => ({
        url: r.url,
        status: r.status,
        matchCount: r.matchCount,
        matches: r.matches,
        error: r.error || null,
        scannedTime: r.scannedTime
      }))
    };

    const blobUrl = URL.createObjectURL(new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' }));
    const link = document.createElement('a');
    link.href = blobUrl;
    const dateStamp = new Date().toISOString().slice(0, 10);
    link.download = `sitescope_audit_${reportDomain.textContent}_${dateStamp}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setTimeout(() => URL.revokeObjectURL(blobUrl), 1000);
  });

  // Print PDF exporter triggering native window print dialog
  exportPdfBtn.addEventListener('click', () => {
    if (!activeAuditId || activeResults.length === 0) return;
    
    // Expand all items that have matches before printing so details show up
    activeResults.forEach(r => {
      if (r.matchCount > 0) {
        expandedRows.add(r.id);
      }
    });
    
    renderTable();
    window.print();
  });

  // Listen for progress updates. The crawler broadcasts several times per page, so
  // refreshes are throttled to keep the dashboard responsive during large crawls.
  let refreshTimer = null;
  let pendingState = null;
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === 'STATUS_UPDATE') {
      pendingState = message.state;
      if (refreshTimer) return;
      refreshTimer = setTimeout(() => {
        refreshTimer = null;
        const state = pendingState;
        loadHistory();
        if (state && activeAuditId === state.currentAuditId) {
          loadAuditDetails(state.currentAuditId);
        }
      }, 1500);
    }
  });
});
