// report-page.js - renders the printable report the side panel stored in
// chrome.storage.session, then wires up the Print button (no inline scripts).
(() => {
  const status = document.getElementById('report-status');
  chrome.storage.session.get(['seo_lens_report_html'], (res) => {
    const html = res && res.seo_lens_report_html;
    if (chrome.runtime.lastError || !html) {
      status.textContent = 'No report found. Open the SEO Lens side panel and click "Report" again.';
      return;
    }
    const doc = new DOMParser().parseFromString(html, 'text/html');
    document.title = doc.title || document.title;
    document.head.replaceChildren(...Array.from(doc.head.childNodes).map((n) => document.importNode(n, true)));
    document.body.removeAttribute('style');
    document.body.replaceChildren(...Array.from(doc.body.childNodes).map((n) => document.importNode(n, true)));
    const btn = document.getElementById('print-btn');
    if (btn) btn.addEventListener('click', () => window.print());
  });
})();
