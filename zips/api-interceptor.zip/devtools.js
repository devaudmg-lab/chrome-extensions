chrome.devtools.panels.create(
    "API Monitor Pro",
    "icons/icon16.png",
    "panel.html",
    function(panel) {
        // Can add listeners here when the panel is shown/hidden if needed
    }
);
