(function () {
    'use strict';

    // Runs in the page's MAIN world (manifest content script, document_start), before any
    // page script. It talks to content.js ONLY through a private MessagePort that content.js
    // hands over with a synchronous event at document_start, so page scripts can never get
    // hold of it. Mock rules are matched inside content.js (isolated world); this file only
    // ever receives the one resolved response for a request that matched. Window events and
    // window.postMessage are never used for data.
    const HANDSHAKE_EVENT = 'api-interceptor-pro:port';
    const HELLO_EVENT = 'api-interceptor-pro:hello';
    const MAX_BODY = 100000;

    // Keep our own references so later page code that patches built-ins can't break us
    const portPost = MessagePort.prototype.postMessage;
    const setTimer = window.setTimeout.bind(window);
    const clearTimer = window.clearTimeout.bind(window);
    const now = performance.now.bind(performance);
    const jsonParse = JSON.parse;
    const jsonStringify = JSON.stringify;
    const NativeResponse = window.Response;
    const NativeHeaders = window.Headers;
    const NativeURL = window.URL;
    const NativeBlob = window.Blob;
    const NativeTextDecoder = window.TextDecoder;
    const NativeTextEncoder = window.TextEncoder;
    const originalFetch = window.fetch;

    let postToExtension = null;      // bound postMessage of the private port
    let config = { paused: false, active: false };
    let configLoaded = false;
    let resolveConfig;
    const configReady = new Promise(resolve => { resolveConfig = resolve; });
    // Requests fired during page load wait (max 500 ms) for the rules, so early calls are mocked too
    setTimer(() => resolveConfig(), 500);

    const pendingMatches = new Map();
    let matchSeq = 0;

    function onPortMessage(event) {
        const msg = event.data;
        if (!msg || typeof msg !== 'object') return;
        if (msg.t === 'config') {
            config = { paused: !!msg.paused, active: !!msg.active };
            configLoaded = true;
            resolveConfig();
        } else if (msg.t === 'match') {
            const done = pendingMatches.get(msg.id);
            if (done) {
                pendingMatches.delete(msg.id);
                done(msg.rule && typeof msg.rule === 'object' ? msg.rule : null);
            }
        }
    }

    function onHandshake(event) {
        if (postToExtension || !event.ports || !event.ports[0]) return;
        const port = event.ports[0];
        postToExtension = portPost.bind(port);
        port.onmessage = onPortMessage;
        event.preventDefault();          // tells content.js the port was taken
        event.stopImmediatePropagation();
        window.removeEventListener(HANDSHAKE_EVENT, onHandshake, true);
    }
    window.addEventListener(HANDSHAKE_EVENT, onHandshake, true);
    // In case content.js ran first: ask it (synchronously) to hand the port over now
    window.dispatchEvent(new Event(HELLO_EVENT));

    function post(msg) {
        if (!postToExtension) return;
        try { postToExtension(msg); } catch (e) { /* data could not be cloned */ }
    }

    // Ask content.js whether a rule matches. Resolves to the resolved response or null.
    function askMatch(info) {
        if (!postToExtension || config.paused || !config.active) return Promise.resolve(null);
        return new Promise(resolve => {
            const id = ++matchSeq;
            const timer = setTimer(() => {
                if (pendingMatches.delete(id)) resolve(null);
            }, 1500);
            pendingMatches.set(id, (rule) => { clearTimer(timer); resolve(rule); });
            post({ t: 'match', id, url: info.url, absUrl: absoluteUrl(info.url), method: info.method, gqlOp: info.gqlOp, body: typeof info.body === 'string' ? info.body.slice(0, 65536) : '' });
        });
    }

    function emit(detail) {
        post({ t: 'call', call: detail });
    }

    // Helper functions
    function generateId() {
        return Math.random().toString(36).substring(2, 11);
    }

    function headersToObject(headers) {
        const obj = {};
        if (!headers) return obj;
        try {
            if (typeof headers.forEach === 'function' && !Array.isArray(headers)) {
                headers.forEach((value, key) => { obj[key] = String(value); });
            } else if (Array.isArray(headers)) {
                headers.forEach(pair => { if (pair && pair.length >= 2) obj[String(pair[0])] = String(pair[1]); });
            } else if (typeof headers === 'object') {
                Object.keys(headers).forEach(key => { obj[key] = String(headers[key]); });
            }
        } catch (e) {}
        return obj;
    }

    function parseXhrHeaders(headerStr) {
        const headers = {};
        if (!headerStr) return headers;
        headerStr.trim().split(/[\r\n]+/).forEach(line => {
            const idx = line.indexOf(':');
            if (idx > 0) headers[line.slice(0, idx).trim()] = line.slice(idx + 1).trim();
        });
        return headers;
    }

    function absoluteUrl(url) {
        try {
            return new NativeURL(url, location.href).href;
        } catch (e) {
            return String(url || '');
        }
    }

    function describeBody(body) {
        if (body === undefined || body === null) return null;
        if (typeof body === 'string') return body;
        try {
            if (body instanceof URLSearchParams) return body.toString();
            if (body instanceof FormData) return '[FormData]';
            if (typeof Document !== 'undefined' && body instanceof Document) return '[Document]';
        } catch (e) {}
        return '[Object / Binary Body]';
    }

    // GraphQL operation name from a JSON body ({operationName} or "query Name {...}") or GET params
    function graphqlOperation(url, body) {
        const fromQuery = (q) => {
            const m = typeof q === 'string' && q.match(/(query|mutation|subscription)\s+([A-Za-z_][A-Za-z0-9_]*)/);
            return m ? m[2] : '';
        };
        if (typeof body === 'string' && body && (body[0] === '{' || body[0] === '[')) {
            try {
                const data = jsonParse(body);
                const first = Array.isArray(data) ? data[0] : data;
                if (first && typeof first === 'object') {
                    if (first.operationName) return String(first.operationName);
                    const name = fromQuery(first.query);
                    if (name) return name;
                }
            } catch (e) {}
        }
        try {
            const u = new NativeURL(url, location.href);
            if (u.searchParams.get('operationName')) return u.searchParams.get('operationName');
            return fromQuery(u.searchParams.get('query'));
        } catch (e) {
            return '';
        }
    }

    // JSON Merge Patch (RFC 7386): objects merge, null deletes a key, anything else replaces
    function mergePatch(target, patch) {
        if (patch === null || typeof patch !== 'object' || Array.isArray(patch)) return patch;
        const out = (target && typeof target === 'object' && !Array.isArray(target)) ? { ...target } : {};
        Object.keys(patch).forEach(key => {
            if (patch[key] === null) delete out[key];
            else out[key] = mergePatch(out[key], patch[key]);
        });
        return out;
    }

    // Returns the patched text, or the original text if either side is not JSON
    function applyPatch(text, patchText) {
        let patch;
        try { patch = jsonParse(patchText); } catch (e) { return { text, applied: false }; }
        let data;
        try { data = jsonParse(text); } catch (e) { return { text, applied: false }; }
        return { text: jsonStringify(mergePatch(data, patch)), applied: true };
    }

    function wait(ms, signal) {
        return new Promise((resolve, reject) => {
            if (!(ms > 0)) return resolve();
            const timer = setTimer(resolve, ms);
            if (signal && typeof signal.addEventListener === 'function') {
                signal.addEventListener('abort', () => {
                    clearTimer(timer);
                    reject(signal.reason || new DOMException('The operation was aborted.', 'AbortError'));
                }, { once: true });
            }
        });
    }

    function isTextual(contentType) {
        return !contentType || /json|text\/|javascript|xml|html|graphql|x-www-form-urlencoded/i.test(contentType);
    }

    // Read at most MAX_BODY characters, then stop reading (our clone is cancelled, the page's copy is untouched)
    async function readBodyCapped(response) {
        const contentType = response.headers.get('content-type') || '';
        if (/event-stream/i.test(contentType)) return '[Streaming response (text/event-stream) is not captured]';
        if (!isTextual(contentType)) return `[Binary Content: ${contentType}]`;
        if (!response.body) return '';
        const reader = response.body.getReader();
        const decoder = new NativeTextDecoder();
        let out = '';
        for (;;) {
            const { done, value } = await reader.read();
            if (done) break;
            out += decoder.decode(value, { stream: true });
            if (out.length > MAX_BODY) {
                reader.cancel().catch(() => {});
                return out.slice(0, MAX_BODY) + '... [Truncated]';
            }
        }
        return out + decoder.decode();
    }

    function buildHeaders(obj) {
        try {
            return new NativeHeaders(obj || {});
        } catch (e) {
            return new NativeHeaders({ 'Content-Type': 'application/json' });
        }
    }

    // --- FETCH INTERCEPTION ---
    window.fetch = async function (resource, init) {
        const args = arguments;
        let url = '';
        if (typeof resource === 'string') {
            url = resource;
        } else if (resource instanceof NativeURL) {
            url = resource.toString();
        } else if (resource && typeof resource === 'object') {
            url = String(resource.url || resource);
        } else {
            url = String(resource);
        }
        const method = String((init && init.method) || (resource && resource.method) || 'GET').toUpperCase();
        const signal = (init && init.signal) || (resource && resource.signal) || null;

        if (!configLoaded) await configReady;

        if (config.paused || !postToExtension) {
            return originalFetch.apply(this, args);
        }

        let reqHeaders = {};
        if (init && init.headers) {
            reqHeaders = headersToObject(init.headers);
        } else if (resource && resource.headers) {
            reqHeaders = headersToObject(resource.headers);
        }
        const reqBody = init && init.body !== undefined ? describeBody(init.body) : null;
        const gqlOp = graphqlOperation(url, reqBody);
        const base = { id: generateId(), type: 'fetch', url, method, reqHeaders, reqBody, gqlOp };

        const rule = await askMatch({ url, method, gqlOp, body: reqBody });
        if (rule) {
            const mockDelay = Math.max(0, Number(rule.delay) || 0);
            const started = now();
            await wait(mockDelay, signal);

            if (rule.mode === 'error') {
                emit({ ...base, status: 0, resHeaders: {}, resBody: 'Simulated network error (mock rule)', latency: mockDelay, isMocked: true, error: true, token: rule.token });
                throw new TypeError('Failed to fetch');
            }

            if (rule.mode === 'patch') {
                const real = await originalFetch.apply(this, args);
                let text = '';
                try { text = await real.clone().text(); } catch (e) {}
                const patched = applyPatch(text, rule.patch);
                const headers = new NativeHeaders(real.headers);
                headers.delete('content-length');
                headers.delete('content-encoding');
                const response = new NativeResponse([101, 204, 205, 304].includes(real.status) ? null : patched.text, {
                    status: real.status, statusText: real.statusText, headers
                });
                emit({ ...base, status: real.status, resHeaders: headersToObject(headers), resBody: patched.text.slice(0, MAX_BODY), latency: Math.round(now() - started), isMocked: true, patched: patched.applied, token: rule.token });
                return response;
            }

            const mockHeaders = buildHeaders(rule.headers);
            const response = new NativeResponse(rule.body === null ? null : String(rule.body || ''), {
                status: rule.status,
                statusText: rule.statusText || '',
                headers: mockHeaders
            });
            emit({ ...base, status: rule.status, resHeaders: headersToObject(mockHeaders), resBody: rule.body || '', latency: mockDelay, isMocked: true, token: rule.token });
            return response;
        }

        // Real network fetch. The response is handed to the page right away; the body is
        // read from a clone in the background so streaming responses are never held back.
        const startTime = now();
        let response;
        try {
            response = await originalFetch.apply(this, args);
        } catch (error) {
            emit({ ...base, status: 0, resHeaders: {}, resBody: (error && error.message) || 'Network Error', latency: Math.round(now() - startTime), isMocked: false, error: true });
            throw error;
        }
        const latency = Math.round(now() - startTime);
        let clone = null;
        try { clone = response.clone(); } catch (e) {}
        const record = { ...base, status: response.status, resHeaders: headersToObject(response.headers), latency, isMocked: false };
        if (clone) {
            readBodyCapped(clone)
                .then(resBody => emit({ ...record, resBody }))
                .catch(() => emit({ ...record, resBody: '[Body could not be read]' }));
        } else {
            emit({ ...record, resBody: '[Body already used]' });
        }
        return response;
    };

    // --- XMLHTTPREQUEST INTERCEPTION ---
    const OriginalXHR = window.XMLHttpRequest;
    const FAKE_PROPS = ['status', 'statusText', 'readyState', 'responseText', 'response', 'responseURL'];

    window.XMLHttpRequest = function () {
        const xhr = new OriginalXHR();

        let requestMethod = 'GET';
        let requestUrl = '';
        let isAsync = true;
        let requestHeaders = {};
        let pending = false;     // send() called, but we have not handed it to the network yet
        let aborted = false;

        const originalOpen = xhr.open;
        const originalSend = xhr.send;
        const originalSetRequestHeader = xhr.setRequestHeader;
        const originalAbort = xhr.abort;
        const originalGetAll = xhr.getAllResponseHeaders;
        const originalGetOne = xhr.getResponseHeader;

        // A reused XHR object must not keep the fake values of an earlier mocked response
        function clearFakes() {
            FAKE_PROPS.forEach(prop => { delete xhr[prop]; });
            delete xhr.getAllResponseHeaders;
            delete xhr.getResponseHeader;
        }

        xhr.open = function (method, url, async) {
            clearFakes();
            requestMethod = String(method || 'GET').toUpperCase();
            requestUrl = String(url);
            isAsync = arguments.length < 3 ? true : !!async;
            requestHeaders = {};
            pending = false;
            aborted = false;
            return originalOpen.apply(xhr, arguments);
        };

        xhr.setRequestHeader = function (header, value) {
            requestHeaders[header] = String(value);
            return originalSetRequestHeader.apply(xhr, arguments);
        };

        xhr.abort = function () {
            if (pending) {
                aborted = true;
                pending = false;
                const result = originalAbort.apply(xhr, arguments);
                xhr.dispatchEvent(new ProgressEvent('abort'));
                xhr.dispatchEvent(new ProgressEvent('loadend'));
                return result;
            }
            return originalAbort.apply(xhr, arguments);
        };

        function captureRealResponse(base, startTime) {
            let reason = 'XHR Network Error';
            const onError = () => { reason = 'XHR Network Error'; };
            const onAbort = () => { reason = 'Request aborted'; };
            const onTimeout = () => { reason = 'Request timed out'; };
            xhr.addEventListener('error', onError);
            xhr.addEventListener('abort', onAbort);
            xhr.addEventListener('timeout', onTimeout);
            xhr.addEventListener('loadend', function onLoadEnd() {
                xhr.removeEventListener('loadend', onLoadEnd);
                xhr.removeEventListener('error', onError);
                xhr.removeEventListener('abort', onAbort);
                xhr.removeEventListener('timeout', onTimeout);
                const latency = Math.round(now() - startTime);
                const status = xhr.status;
                if (status === 0) {
                    emit({ ...base, status: 0, resHeaders: {}, resBody: reason, latency, isMocked: false, error: true });
                    return;
                }
                let resBody = '';
                try {
                    if (xhr.responseType === '' || xhr.responseType === 'text') resBody = xhr.responseText;
                    else if (xhr.responseType === 'json') resBody = jsonStringify(xhr.response);
                    else resBody = `[${xhr.responseType} response]`;
                } catch (e) {}
                if (typeof resBody === 'string' && resBody.length > MAX_BODY) resBody = resBody.slice(0, MAX_BODY) + '... [Truncated]';
                emit({ ...base, status, resHeaders: parseXhrHeaders(originalGetAll.call(xhr)), resBody, latency, isMocked: false });
            });
        }

        function fakeResponse(status, statusText, headers, text, responseUrl) {
            let value = text;
            const type = xhr.responseType;
            if (type === 'json') {
                try { value = jsonParse(text); } catch (e) { value = null; }
            } else if (type === 'arraybuffer') {
                value = new NativeTextEncoder().encode(text).buffer;
            } else if (type === 'blob') {
                value = new NativeBlob([text], { type: headers['Content-Type'] || headers['content-type'] || '' });
            } else if (type === 'document') {
                value = null;
            }
            const define = (prop, v) => Object.defineProperty(xhr, prop, { value: v, writable: true, configurable: true });
            define('status', status);
            define('statusText', statusText);
            define('readyState', 4);
            define('responseText', text);
            define('response', value);
            define('responseURL', responseUrl);
            Object.defineProperty(xhr, 'getAllResponseHeaders', {
                configurable: true, writable: true,
                value: () => Object.keys(headers).map(k => `${k.toLowerCase()}: ${headers[k]}`).join('\r\n') + (Object.keys(headers).length ? '\r\n' : '')
            });
            Object.defineProperty(xhr, 'getResponseHeader', {
                configurable: true, writable: true,
                value: (name) => {
                    const wanted = String(name).toLowerCase();
                    const key = Object.keys(headers).find(k => k.toLowerCase() === wanted);
                    return key !== undefined ? String(headers[key]) : null;
                }
            });
            xhr.dispatchEvent(new ProgressEvent('loadstart'));
            xhr.dispatchEvent(new Event('readystatechange'));
            xhr.dispatchEvent(new ProgressEvent('load'));
            xhr.dispatchEvent(new ProgressEvent('loadend'));
        }

        function fakeNetworkError() {
            Object.defineProperty(xhr, 'status', { value: 0, writable: true, configurable: true });
            Object.defineProperty(xhr, 'readyState', { value: 4, writable: true, configurable: true });
            xhr.dispatchEvent(new ProgressEvent('loadstart'));
            xhr.dispatchEvent(new Event('readystatechange'));
            xhr.dispatchEvent(new ProgressEvent('error'));
            xhr.dispatchEvent(new ProgressEvent('loadend'));
        }

        async function handleAsyncSend(body, args) {
            if (!configLoaded) await configReady;
            if (aborted) return;
            if (config.paused || !postToExtension) {
                pending = false;
                return originalSend.apply(xhr, args);
            }

            const reqBody = describeBody(body);
            const gqlOp = graphqlOperation(requestUrl, reqBody);
            const base = { id: generateId(), type: 'xhr', url: requestUrl, method: requestMethod, reqHeaders: { ...requestHeaders }, reqBody, gqlOp };

            const rule = await askMatch({ url: requestUrl, method: requestMethod, gqlOp, body: reqBody });
            if (aborted) return;
            if (!rule) {
                pending = false;
                captureRealResponse(base, now());
                return originalSend.apply(xhr, args);
            }

            const started = now();
            const mockDelay = Math.max(0, Number(rule.delay) || 0);
            await wait(mockDelay);
            if (aborted) return;

            if (rule.mode === 'error') {
                pending = false;
                emit({ ...base, status: 0, resHeaders: {}, resBody: 'Simulated network error (mock rule)', latency: mockDelay, isMocked: true, error: true, token: rule.token });
                fakeNetworkError();
                return;
            }

            if (rule.mode === 'patch') {
                let real;
                try {
                    real = await originalFetch(absoluteUrl(requestUrl), {
                        method: requestMethod,
                        headers: requestHeaders,
                        body: ['GET', 'HEAD'].includes(requestMethod) ? undefined : body,
                        credentials: xhr.withCredentials ? 'include' : 'same-origin'
                    });
                } catch (e) {
                    if (aborted) return;
                    pending = false;
                    emit({ ...base, status: 0, resHeaders: {}, resBody: 'XHR Network Error', latency: Math.round(now() - started), isMocked: true, error: true, token: rule.token });
                    fakeNetworkError();
                    return;
                }
                let text = '';
                try { text = await real.text(); } catch (e) {}
                if (aborted) return;
                pending = false;
                const patched = applyPatch(text, rule.patch);
                const headers = headersToObject(real.headers);
                emit({ ...base, status: real.status, resHeaders: headers, resBody: patched.text.slice(0, MAX_BODY), latency: Math.round(now() - started), isMocked: true, patched: patched.applied, token: rule.token });
                fakeResponse(real.status, real.statusText, headers, patched.text, real.url || absoluteUrl(requestUrl));
                return;
            }

            pending = false;
            const headers = rule.headers && typeof rule.headers === 'object' ? rule.headers : {};
            const text = rule.body === null ? '' : String(rule.body || '');
            emit({ ...base, status: rule.status, resHeaders: headers, resBody: text, latency: mockDelay, isMocked: true, token: rule.token });
            fakeResponse(rule.status, rule.statusText || '', headers, text, absoluteUrl(requestUrl));
        }

        xhr.send = function (body) {
            // Not opened, already sent, etc.: let the native method throw the right error
            if (pending) throw new DOMException("Failed to execute 'send' on 'XMLHttpRequest': The object's state must be OPENED.", 'InvalidStateError');
            if (xhr.readyState !== 1) return originalSend.apply(xhr, arguments);

            // A synchronous XHR can't wait for the rules: pass it through and only record it
            if (!isAsync) {
                if (!config.paused && postToExtension) {
                    const reqBody = describeBody(body);
                    captureRealResponse({ id: generateId(), type: 'xhr', url: requestUrl, method: requestMethod, reqHeaders: { ...requestHeaders }, reqBody, gqlOp: graphqlOperation(requestUrl, reqBody) }, now());
                }
                return originalSend.apply(xhr, arguments);
            }

            pending = true;
            const args = arguments;
            handleAsyncSend(body, args).catch(() => {
                // Something unexpected: never leave the page's request hanging
                if (pending && !aborted) {
                    pending = false;
                    try { originalSend.apply(xhr, args); } catch (e) {}
                }
            });
        };

        return xhr;
    };

    // Maintain prototype chain (instanceof XMLHttpRequest keeps working)
    window.XMLHttpRequest.prototype = OriginalXHR.prototype;

    // Clone all static constants (like DONE, UNSENT etc.)
    Object.getOwnPropertyNames(OriginalXHR).forEach(key => {
        if (key !== 'prototype' && key !== 'name' && key !== 'length') {
            try {
                Object.defineProperty(window.XMLHttpRequest, key, Object.getOwnPropertyDescriptor(OriginalXHR, key));
            } catch (e) {}
        }
    });
})();
