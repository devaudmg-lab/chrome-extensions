(function() {
    // Prevent double injection
    if (window.__apiMonitorInjected) return;
    window.__apiMonitorInjected = true;

    let config = {
        isPaused: false,
        mockRules: []
    };

    // Helper functions
    function generateId() {
        return Math.random().toString(36).substring(2, 9);
    }

    function headersToObject(headers) {
        const obj = {};
        if (headers) {
            if (typeof headers.forEach === 'function') {
                headers.forEach((value, key) => {
                    obj[key] = value;
                });
            } else if (typeof headers === 'object') {
                return { ...headers };
            }
        }
        return obj;
    }

    function parseXhrHeaders(headerStr) {
        const headers = {};
        if (!headerStr) return headers;
        const pairs = headerStr.trim().split(/[\r\n]+/);
        pairs.forEach(pair => {
            const parts = pair.split(': ');
            const key = parts.shift();
            const value = parts.join(': ');
            if (key) headers[key] = value;
        });
        return headers;
    }

    function getStatusText(status) {
        const statuses = {
            200: "OK", 201: "Created", 202: "Accepted", 204: "No Content",
            301: "Moved Permanently", 302: "Found", 304: "Not Modified",
            400: "Bad Request", 401: "Unauthorized", 403: "Forbidden", 404: "Not Found",
            500: "Internal Server Error", 502: "Bad Gateway", 503: "Service Unavailable", 504: "Gateway Timeout"
        };
        return statuses[status] || "Unknown";
    }

    function findMatchingRule(url, method) {
        if (!config.mockRules || config.mockRules.length === 0) return null;
        return config.mockRules.find(rule => {
            if (!rule.enabled) return false;
            
            // Method check
            if (rule.method && rule.method !== "ANY" && rule.method.toUpperCase() !== method.toUpperCase()) {
                return false;
            }
            
            // URL check
            if (rule.matchType === "regex") {
                try {
                    const rx = new RegExp(rule.urlPattern);
                    return rx.test(url);
                } catch (e) {
                    return false;
                }
            } else if (rule.matchType === "exact") {
                return url === rule.urlPattern || absoluteUrl(url) === rule.urlPattern;
            } else {
                return url.includes(rule.urlPattern) || absoluteUrl(url).includes(rule.urlPattern);
            }
        });
    }

    function absoluteUrl(url) {
        try {
            return new URL(url, location.href).href;
        } catch (e) {
            return String(url || "");
        }
    }

    // Normalise a mock rule's status/body/headers so Response/XHR never throw
    function mockParts(rule) {
        let status = Number(rule.statusCode) || 200;
        if (status < 200 || status > 599) status = 200;
        const nullBody = [204, 205, 304].includes(status);
        const body = nullBody ? null : (rule.responseBody || "");
        const headers = rule.headers && typeof rule.headers === 'object' && Object.keys(rule.headers).length > 0
            ? rule.headers
            : { "Content-Type": "application/json" };
        return { status, body, headers };
    }

    function dispatchInterceptedEvent(detail) {
        detail.pageOrigin = location.origin;
        detail.timestamp = Date.now();
        window.dispatchEvent(new CustomEvent('API_DATA_INTERCEPTED', { detail }));
    }

    // Dynamic config updating from Content Script
    window.addEventListener('UPDATE_API_MONITOR_CONFIG', (e) => {
        if (e.detail) {
            config = { ...config, ...e.detail };
        }
    });

    // Ask the content script for config in case it loaded before us
    window.dispatchEvent(new CustomEvent('API_MONITOR_REQUEST_CONFIG'));

    // --- FETCH INTERCEPTION ---
    const originalFetch = window.fetch;
    window.fetch = async function(resource, init) {
        // Parse request detail
        let url = "";
        if (typeof resource === 'string') {
            url = resource;
        } else if (resource instanceof URL) {
            url = resource.toString();
        } else if (resource && typeof resource === 'object') {
            url = resource.url || "";
        }
        
        const method = (init && init.method) || (resource && resource.method) || "GET";

        if (config.isPaused) {
            return originalFetch.apply(this, arguments);
        }

        // Extract Request Headers
        let reqHeaders = {};
        if (init && init.headers) {
            reqHeaders = headersToObject(init.headers);
        } else if (resource && resource.headers) {
            reqHeaders = headersToObject(resource.headers);
        }

        // Extract Request Body
        let reqBody = null;
        if (init && init.body) {
            if (typeof init.body === 'string') {
                reqBody = init.body;
            } else if (init.body instanceof URLSearchParams) {
                reqBody = init.body.toString();
            } else if (init.body instanceof FormData) {
                reqBody = "[FormData]";
            } else {
                reqBody = "[Object / Binary Body]";
            }
        }

        // Check for Mock Rules
        const matchedRule = findMatchingRule(url, method);
        if (matchedRule) {
            const mockDelay = Number(matchedRule.delay) || 0;
            if (mockDelay > 0) {
                await new Promise(resolve => setTimeout(resolve, mockDelay));
            }

            const parts = mockParts(matchedRule);
            const responseData = parts.body;
            const mockStatus = parts.status;
            let mockHeaders;
            try {
                mockHeaders = new Headers(parts.headers);
            } catch (e) {
                mockHeaders = new Headers({ "Content-Type": "application/json" });
            }

            const mockResponse = new Response(responseData, {
                status: mockStatus,
                statusText: getStatusText(mockStatus),
                headers: mockHeaders
            });

            dispatchInterceptedEvent({
                id: generateId(),
                type: "fetch",
                url,
                method,
                reqHeaders,
                reqBody,
                status: mockStatus,
                resHeaders: headersToObject(mockHeaders),
                resBody: responseData || "",
                time: new Date().toLocaleTimeString(),
                latency: mockDelay,
                isMocked: true
            });

            return mockResponse;
        }

        // Original network fetch
        const startTime = performance.now();
        try {
            const response = await originalFetch.apply(this, arguments);
            const latency = Math.round(performance.now() - startTime);

            const clone = response.clone();
            const status = clone.status;
            const resHeaders = headersToObject(clone.headers);
            const contentType = clone.headers.get("content-type") || "";

            let resBody = "";
            if (contentType.includes("application/json") || contentType.includes("text/") || contentType.includes("javascript") || contentType.includes("xml") || contentType.includes("html")) {
                try {
                    resBody = await clone.text();
                    if (resBody.length > 100000) {
                        resBody = resBody.substring(0, 100000) + "... [Truncated]";
                    }
                } catch (e) {}
            } else {
                resBody = `[Binary Content: ${contentType}]`;
            }

            dispatchInterceptedEvent({
                id: generateId(),
                type: "fetch",
                url,
                method,
                reqHeaders,
                reqBody,
                status,
                resHeaders,
                resBody,
                time: new Date().toLocaleTimeString(),
                latency,
                isMocked: false
            });

            return response;
        } catch (error) {
            const latency = Math.round(performance.now() - startTime);
            dispatchInterceptedEvent({
                id: generateId(),
                type: "fetch",
                url,
                method,
                reqHeaders,
                reqBody,
                status: 0,
                resHeaders: {},
                resBody: error.message || "Network Error",
                time: new Date().toLocaleTimeString(),
                latency,
                isMocked: false,
                error: true
            });
            throw error;
        }
    };

    // --- XMLHTTPREQUEST INTERCEPTION ---
    const originalXHR = window.XMLHttpRequest;
    window.XMLHttpRequest = function() {
        const xhr = new originalXHR();
        
        let requestMethod = "GET";
        let requestUrl = "";
        let requestHeaders = {};
        let requestBody = null;
        let startTime = 0;
        const xhrId = generateId();

        const originalOpen = xhr.open;
        const originalSend = xhr.send;
        const originalSetRequestHeader = xhr.setRequestHeader;

        xhr.open = function(method, url, async, user, password) {
            requestMethod = method;
            requestUrl = url;
            return originalOpen.apply(xhr, arguments);
        };

        xhr.setRequestHeader = function(header, value) {
            requestHeaders[header] = value;
            return originalSetRequestHeader.apply(xhr, arguments);
        };

        xhr.send = async function(body) {
            requestBody = body;

            if (config.isPaused) {
                return originalSend.apply(xhr, arguments);
            }

            // Check Mock Rules
            const matchedRule = findMatchingRule(requestUrl, requestMethod);
            if (matchedRule) {
                const mockDelay = Number(matchedRule.delay) || 0;
                if (mockDelay > 0) {
                    await new Promise(resolve => setTimeout(resolve, mockDelay));
                }

                const parts = mockParts(matchedRule);
                const responseData = parts.body || "";
                const mockStatus = parts.status;
                const mockHeaders = parts.headers;
                let responseValue = responseData;
                if (xhr.responseType === "json") {
                    try { responseValue = JSON.parse(responseData); } catch (e) { responseValue = null; }
                }

                // Mock XHR properties directly on the native instance
                Object.defineProperty(xhr, 'status', { value: mockStatus, writable: true });
                Object.defineProperty(xhr, 'statusText', { value: getStatusText(mockStatus), writable: true });
                Object.defineProperty(xhr, 'readyState', { value: 4, writable: true });
                Object.defineProperty(xhr, 'responseText', { value: responseData, writable: true });
                Object.defineProperty(xhr, 'response', { value: responseValue, writable: true });

                xhr.getAllResponseHeaders = function() {
                    return Object.entries(mockHeaders).map(([k, v]) => `${k}: ${v}`).join("\r\n");
                };

                xhr.getResponseHeader = function(header) {
                    const wanted = String(header).toLowerCase();
                    const key = Object.keys(mockHeaders).find(k => k.toLowerCase() === wanted);
                    return key !== undefined ? String(mockHeaders[key]) : null;
                };

                dispatchInterceptedEvent({
                    id: xhrId,
                    type: "xhr",
                    url: requestUrl,
                    method: requestMethod,
                    reqHeaders: requestHeaders,
                    reqBody: requestBody,
                    status: mockStatus,
                    resHeaders: mockHeaders,
                    resBody: responseData,
                    time: new Date().toLocaleTimeString(),
                    latency: mockDelay,
                    isMocked: true
                });

                // Dispatch Mock Events (dispatchEvent also invokes on* handler properties)
                xhr.dispatchEvent(new ProgressEvent('loadstart'));
                xhr.dispatchEvent(new Event('readystatechange'));
                xhr.dispatchEvent(new ProgressEvent('load'));
                xhr.dispatchEvent(new ProgressEvent('loadend'));
                return;
            }

            // Standard capture logic
            startTime = performance.now();

            xhr.addEventListener('readystatechange', function() {
                if (xhr.readyState === 4) {
                    const latency = Math.round(performance.now() - startTime);
                    const status = xhr.status;
                    const responseHeaders = parseXhrHeaders(xhr.getAllResponseHeaders());
                    let resBody = "";
                    try {
                        resBody = (xhr.responseType === "" || xhr.responseType === "text")
                            ? xhr.responseText
                            : (xhr.responseType === "json" ? JSON.stringify(xhr.response) : `[${xhr.responseType} response]`);
                    } catch (e) {}

                    dispatchInterceptedEvent({
                        id: xhrId,
                        type: "xhr",
                        url: requestUrl,
                        method: requestMethod,
                        reqHeaders: requestHeaders,
                        reqBody: requestBody,
                        status: status,
                        resHeaders: responseHeaders,
                        resBody: resBody,
                        time: new Date().toLocaleTimeString(),
                        latency,
                        isMocked: false
                    });
                }
            });

            xhr.addEventListener('error', function() {
                const latency = Math.round(performance.now() - startTime);
                dispatchInterceptedEvent({
                    id: xhrId,
                    type: "xhr",
                    url: requestUrl,
                    method: requestMethod,
                    reqHeaders: requestHeaders,
                    reqBody: requestBody,
                    status: 0,
                    resHeaders: {},
                    resBody: "XHR Network Error",
                    time: new Date().toLocaleTimeString(),
                    latency,
                    isMocked: false,
                    error: true
                });
            });

            return originalSend.apply(xhr, arguments);
        };

        return xhr;
    };

    // Maintain prototype chain
    window.XMLHttpRequest.prototype = originalXHR.prototype;

    // Clone all static constants (like DONE, UNSENT etc.) and properties
    Object.getOwnPropertyNames(originalXHR).forEach(key => {
        if (key !== 'prototype' && key !== 'name' && key !== 'length') {
            try {
                Object.defineProperty(window.XMLHttpRequest, key, Object.getOwnPropertyDescriptor(originalXHR, key));
            } catch (e) {}
        }
    });

})();