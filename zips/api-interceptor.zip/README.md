# API Interceptor Pro

Inspect and mock `fetch` and `XMLHttpRequest` calls inside Chrome, with no proxy to set up. Everything runs locally in your browser. No request data leaves your machine.

## Features

- **Live request monitor** in a DevTools panel (**API Monitor Pro** tab): method, status, URL, latency and type, plus request/response headers, payload and response body.
- **Quick filters**: All / Fetch / XHR / GraphQL / Mocked / Errors, plus text search over URL, method, status and GraphQL operation name.
- **Mock rules**: match a URL by *contains*, *exact URL* or *regex*, filter by method, and return a custom status code, response headers, body and delay. You can toggle, edit and delete rules, and each rule shows how many requests it has mocked.
- **Mock this**: select a captured request and press **Mock this** (or <kbd>M</kbd>); the mock form fills in with its path, method, status, body and GraphQL operation.
- **Template library**: start a rule from common responses: empty list, 201, 204, 400 validation error, 401 expired session, 403, 404, 429 with `Retry-After`, 500, 503, slow network, network failure (offline) and a GraphQL error.
- **GraphQL operation matching**: requests show their operation name (`GetUser`), and a rule can target one or more operations on a shared `/graphql` endpoint.
- **Latency jitter**: add a random extra delay (for example 800 ms + up to 700 ms) to test loading states and race conditions.
- **Simulated network failure**: status `0` makes `fetch` reject with `TypeError: Failed to fetch` and fires the XHR `error` event.
- **Per-site rules**: limit a rule to some hosts (`localhost, staging.example.com`, subdomains included). Rules without sites apply everywhere.
- **Import HAR as mocks**: turn the fetch/XHR calls in a `.har` file (from Chrome DevTools or this extension) into exact-URL mock rules, so you can replay a recorded session offline.
- **Popup rule switches**: flip each mock rule on or off from the toolbar popup, or turn all mocks off at once. The icon badge shows how many mock rules are on (or `OFF` while capture is paused).
- **Replay request**: sends the selected request again from the inspected page.
- **Copy as cURL**: copies the selected request as a `curl` command.
- **Export HAR**: downloads the captured calls as a HAR 1.2 file, which opens in Chrome DevTools, Charles, Insomnia and similar tools.
- **Export / import rules** as JSON, so you can share mock setups with your team.
- **Pause / resume** capture from the popup or the panel.
- **Optional in-page floating widget** with search and filters (off by default; switch it on in the popup).

## Keyboard shortcuts

| Where | Keys | Action |
| --- | --- | --- |
| Anywhere | <kbd>Alt</kbd>+<kbd>Shift</kbd>+<kbd>P</kbd> | Pause / resume capture |
| Anywhere | <kbd>Alt</kbd>+<kbd>Shift</kbd>+<kbd>M</kbd> | Turn all mock rules off, press again to restore them |
| DevTools panel | <kbd>/</kbd> | Focus the filter box (<kbd>Esc</kbd> clears it) |
| DevTools panel | <kbd>↑</kbd> <kbd>↓</kbd> (or <kbd>J</kbd> <kbd>K</kbd>) | Move through requests |
| DevTools panel | <kbd>M</kbd> | Mock the selected request |
| Mock form | <kbd>Ctrl</kbd>+<kbd>Enter</kbd> | Save the rule |

Change the global shortcuts at `chrome://extensions/shortcuts`.

## Install (Load unpacked)

1. Download and unzip the extension.
2. Open `chrome://extensions` and switch on **Developer mode** (top right).
3. Click **Load unpacked** and select the unzipped folder (the one that contains `manifest.json`).
4. Open DevTools (F12) on any page and go to the **API Monitor Pro** tab.

Requires Chrome 111 or newer.

## Permissions

| Permission | Why |
| --- | --- |
| `storage` | Saves your mock rules, settings and the most recent 150 captured calls locally. |
| Keyboard shortcuts (`commands`) | Pause capture and switch mocks off without opening DevTools. Not a permission prompt. |
| Content scripts on all sites | API calls are captured and mocked by wrapping `fetch`/`XMLHttpRequest` on the page you are debugging, so the script has to be able to run on any site. Chrome shows this as "Read and change all your data on all websites". Nothing is sent anywhere. |

## Notes

- Only `fetch` and `XMLHttpRequest` calls made by the page are captured. Requests from service workers, `<img>`/`<script>` tags, WebSockets and the browser itself are not.
- Mock rules apply to every site unless you fill in **Only on sites**. Disable rules you don't need; the icon badge reminds you how many are on.
- Calls made while a page is still loading wait up to 0.5 s for your rules to load, so mocks also apply to the very first requests.
- GraphQL operation names are read from JSON request bodies (`operationName` or `query Name {…}`) and from `GET ?operationName=` / `?query=`. Requests built from a `Request` object with a body are matched by URL only.
- Stored bodies are cut to 20 KB to stay within Chrome's storage quota. The open DevTools panel still shows the full body of live requests.
