# API Interceptor Pro

Inspect and mock `fetch` and `XMLHttpRequest` calls inside Chrome, with no proxy to set up. Everything runs locally in your browser. No request data leaves your machine.

## Features

- **Live request monitor** in a DevTools panel (**API Monitor Pro** tab): method, status, URL, latency and type, plus request/response headers, payload and response body.
- **Mock rules**: match a URL by *contains*, *exact URL* or *regex*, filter by method, and return a custom status code, response headers, body and delay. You can toggle, edit and delete rules.
- **One-click rule from a request**: select a captured request and the mock form fills in with its path, method, status and body.
- **Replay request**: sends the selected request again from the inspected page.
- **Copy as cURL**: copies the selected request as a `curl` command.
- **Export HAR**: downloads the captured calls as a HAR 1.2 file, which opens in Chrome DevTools, Charles, Insomnia and similar tools.
- **Export / import rules** as JSON, so you can share mock setups with your team.
- **Pause / resume** capture from the popup or the panel.
- **Optional in-page floating widget** with search and filters (off by default; switch it on in the popup).

## Install (Load unpacked)

1. Download and unzip the extension.
2. Open `chrome://extensions` and switch on **Developer mode** (top right).
3. Click **Load unpacked** and select the unzipped folder (the one that contains `manifest.json`).
4. Open DevTools (F12) on any page and go to the **API Monitor Pro** tab.

Requires Chrome 111 or newer.

## Permissions

| Permission | Why |
| --- | --- |
| `storage` | Saves your mock rules, settings and the most recent 150 captured calls locally. |
| Content scripts on all sites | API calls are captured and mocked by wrapping `fetch`/`XMLHttpRequest` on the page you are debugging, so the script has to be able to run on any site. Chrome shows this as "Read and change all your data on all websites". Nothing is sent anywhere. |

## Notes

- Only `fetch` and `XMLHttpRequest` calls made by the page are captured. Requests from service workers, `<img>`/`<script>` tags, WebSockets and the browser itself are not.
- Mock rules apply to every site. Disable rules you don't need.
- Stored bodies are cut to 20 KB to stay within Chrome's storage quota. The open DevTools panel still shows the full body of live requests.
