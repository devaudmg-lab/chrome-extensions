document.addEventListener('DOMContentLoaded', () => {
    const mainToggle = document.getElementById('mainToggle');
    const widgetToggle = document.getElementById('widgetToggle');
    const clearBtn = document.getElementById('clearData');
    const callCountDisplay = document.getElementById('callCount');
    const ruleCountDisplay = document.getElementById('ruleCount');
    const statusBadge = document.getElementById('status-badge');

    // 1. Initial State Load
    function loadState() {
        chrome.storage.local.get(['isPaused', 'showWidget', 'apiCalls', 'mockRules'], (result) => {
            const isPaused = !!result.isPaused;
            mainToggle.checked = !isPaused;
            widgetToggle.checked = result.showWidget === true;
            
            const count = result.apiCalls ? result.apiCalls.length : 0;
            callCountDisplay.innerText = count;

            const rules = result.mockRules ? result.mockRules.length : 0;
            ruleCountDisplay.innerText = rules;

            updateStatusBadge(!isPaused);
        });
    }

    function updateStatusBadge(active) {
        if (active) {
            statusBadge.innerText = 'ACTIVE';
            statusBadge.className = 'status-badge status-active';
        } else {
            statusBadge.innerText = 'PAUSED';
            statusBadge.className = 'status-badge status-paused';
        }
    }

    loadState();

    // 2. Monitoring Toggle Listener
    mainToggle.addEventListener('change', () => {
        const isPaused = !mainToggle.checked;
        chrome.storage.local.set({ isPaused: isPaused }, () => {
            updateStatusBadge(!isPaused);
        });
    });

    // 3. Floating Widget Toggle Listener
    widgetToggle.addEventListener('change', () => {
        chrome.storage.local.set({ showWidget: widgetToggle.checked });
    });

    // 4. Handle Clear Data (Send message to background worker)
    clearBtn.addEventListener('click', () => {
        if (confirm("Are you sure you want to clear all logged API requests?")) {
            chrome.runtime.sendMessage({ action: 'clearCalls' }, (response) => {
                if (chrome.runtime.lastError) return;
                if (response && response.success) {
                    callCountDisplay.innerText = '0';
                }
            });
        }
    });

    // 5. Watch storage changes to update UI counters in real-time
    chrome.storage.onChanged.addListener((changes, area) => {
        if (area === 'local') {
            if (changes.apiCalls) {
                callCountDisplay.innerText = changes.apiCalls.newValue ? changes.apiCalls.newValue.length : 0;
            }
            if (changes.mockRules) {
                ruleCountDisplay.innerText = changes.mockRules.newValue ? changes.mockRules.newValue.length : 0;
            }
            if (changes.isPaused) {
                const active = !changes.isPaused.newValue;
                mainToggle.checked = active;
                updateStatusBadge(active);
            }
            if (changes.showWidget) {
                widgetToggle.checked = changes.showWidget.newValue === true;
            }
        }
    });
});