document.addEventListener('DOMContentLoaded', () => {
    const mainToggle = document.getElementById('mainToggle');
    const widgetToggle = document.getElementById('widgetToggle');
    const clearBtn = document.getElementById('clearData');
    const callCountDisplay = document.getElementById('callCount');
    const ruleCountDisplay = document.getElementById('ruleCount');
    const statusBadge = document.getElementById('status-badge');
    const ruleList = document.getElementById('ruleList');
    const allMocksOff = document.getElementById('allMocksOff');
    const onboarding = document.getElementById('onboarding');
    let mockRules = [];

    // First-run hint, hidden once dismissed
    chrome.storage.local.get('popupHintDismissed', (res) => {
        onboarding.hidden = !!res.popupHintDismissed;
    });
    document.getElementById('dismissHint').addEventListener('click', () => {
        onboarding.hidden = true;
        chrome.storage.local.set({ popupHintDismissed: true });
    });

    function escapeHtml(value) {
        return String(value ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    function describeRule(rule) {
        const bits = [];
        const status = Number(rule.statusCode);
        bits.push(status === 0 ? 'Network error' : `Status ${status || 200}`);
        if (rule.graphqlOperation) bits.push(`GraphQL ${rule.graphqlOperation}`);
        if (Number(rule.delay) || Number(rule.jitter)) {
            const d = Number(rule.delay) || 0, j = Number(rule.jitter) || 0;
            bits.push(j ? `${d}-${d + j} ms` : `${d} ms`);
        }
        if (rule.site) bits.push(`on ${rule.site}`);
        return bits.join(' · ');
    }

    // Quick on/off switches so a mock can be flipped without opening DevTools
    function renderRules() {
        ruleCountDisplay.innerText = mockRules.length;
        allMocksOff.disabled = !mockRules.some(r => r.enabled);
        if (mockRules.length === 0) {
            ruleList.innerHTML = '<div class="empty-rules">No mock rules yet. In the DevTools panel, select a request and click <b>Mock this</b>.</div>';
            return;
        }
        ruleList.innerHTML = mockRules.map(rule => `
            <div class="rule-item ${rule.enabled ? '' : 'off'}">
                <span class="rule-method">${escapeHtml(rule.method || 'ANY')}</span>
                <div class="rule-text">
                    <div class="rule-url" title="${escapeHtml(rule.urlPattern)}">${escapeHtml(rule.urlPattern)}</div>
                    <div class="rule-sub">${escapeHtml(describeRule(rule))}</div>
                </div>
                <label class="switch small" title="Enable / disable this rule">
                    <input type="checkbox" data-id="${escapeHtml(rule.id)}" ${rule.enabled ? 'checked' : ''}>
                    <span class="slider"></span>
                </label>
            </div>`).join('');
        ruleList.querySelectorAll('input[type=checkbox]').forEach(box => {
            box.addEventListener('change', () => {
                const rule = mockRules.find(r => r.id === box.dataset.id);
                if (!rule) return;
                rule.enabled = box.checked;
                chrome.storage.local.set({ mockRules });
            });
        });
    }

    allMocksOff.addEventListener('click', () => {
        const ids = mockRules.filter(r => r.enabled).map(r => r.id);
        if (!ids.length) return;
        mockRules.forEach(r => { r.enabled = false; });
        chrome.storage.local.set({ mockRules, mocksSuspended: ids });
    });

    // 1. Initial State Load
    function loadState() {
        chrome.storage.local.get(['isPaused', 'showWidget', 'apiCalls', 'mockRules'], (result) => {
            const isPaused = !!result.isPaused;
            mainToggle.checked = !isPaused;
            widgetToggle.checked = result.showWidget === true;
            
            const count = result.apiCalls ? result.apiCalls.length : 0;
            callCountDisplay.innerText = count;

            mockRules = result.mockRules || [];
            renderRules();

            updateStatusBadge(!isPaused);
        });
    }

    function updateStatusBadge(active) {
        if (active) {
            statusBadge.innerText = 'ACTIVE';
            statusBadge.className = 'status-badge status-active';
        } else {
            statusBadge.innerText = 'PAUSED';
            statusBadge.className = 'status-badge status-paused';
        }
    }

    loadState();

    // 2. Monitoring Toggle Listener
    mainToggle.addEventListener('change', () => {
        const isPaused = !mainToggle.checked;
        chrome.storage.local.set({ isPaused: isPaused }, () => {
            updateStatusBadge(!isPaused);
        });
    });

    // 3. Floating Widget Toggle Listener
    widgetToggle.addEventListener('change', () => {
        chrome.storage.local.set({ showWidget: widgetToggle.checked });
    });

    // 4. Handle Clear Data (Send message to background worker)
    clearBtn.addEventListener('click', () => {
        if (confirm("Are you sure you want to clear all logged API requests?")) {
            chrome.runtime.sendMessage({ action: 'clearCalls' }, (response) => {
                if (chrome.runtime.lastError) return;
                if (response && response.success) {
                    callCountDisplay.innerText = '0';
                }
            });
        }
    });

    // 5. Watch storage changes to update UI counters in real-time
    chrome.storage.onChanged.addListener((changes, area) => {
        if (area === 'local') {
            if (changes.apiCalls) {
                callCountDisplay.innerText = changes.apiCalls.newValue ? changes.apiCalls.newValue.length : 0;
            }
            if (changes.mockRules) {
                mockRules = changes.mockRules.newValue || [];
                renderRules();
            }
            if (changes.isPaused) {
                const active = !changes.isPaused.newValue;
                mainToggle.checked = active;
                updateStatusBadge(active);
            }
            if (changes.showWidget) {
                widgetToggle.checked = changes.showWidget.newValue === true;
            }
        }
    });
});