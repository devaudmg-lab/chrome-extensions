const devtoolsPorts = {};
const MAX_LOGS = 150;
// chrome.storage.local is capped at ~10 MB; keep stored bodies small.
// The live DevTools panel still receives the full body via its port.
const MAX_STORED_BODY = 20000;

function truncateBody(value) {
    if (typeof value !== 'string') return value;
    return value.length > MAX_STORED_BODY ? value.substring(0, MAX_STORED_BODY) + '... [Truncated for storage]' : value;
}
let storageQueue = Promise.resolve();

// Initialize defaults on install
chrome.runtime.onInstalled.addListener(() => {
    chrome.storage.local.get(['isPaused', 'mockRules', 'apiCalls', 'showWidget'], (res) => {
        const updates = {};
        if (res.isPaused === undefined) updates.isPaused = false;
        if (res.mockRules === undefined) updates.mockRules = [];
        if (res.apiCalls === undefined) updates.apiCalls = [];
        if (res.showWidget === undefined) updates.showWidget = false; // in-page overlay is opt-in
        
        if (Object.keys(updates).length > 0) {
            chrome.storage.local.set(updates);
        }
    });
});

// Listen to DevTools Panel connections
chrome.runtime.onConnect.addListener((port) => {
    if (port.name === 'devtools-page') {
        const listener = (message) => {
            if (message.action === 'init' && message.tabId) {
                devtoolsPorts[message.tabId] = port;
                
                // Populate DevTools on load with existing cached logs
                chrome.storage.local.get('apiCalls', (res) => {
                    const calls = (res.apiCalls || []).filter(c => c && c.tabId === message.tabId);
                    try {
                        port.postMessage({ action: 'initCalls', calls });
                    } catch (e) {
                        // Panel closed before storage returned
                    }
                });
            }
        };
        port.onMessage.addListener(listener);
        port.onDisconnect.addListener(() => {
            port.onMessage.removeListener(listener);
            Object.keys(devtoolsPorts).forEach((tabId) => {
                if (devtoolsPorts[tabId] === port) {
                    delete devtoolsPorts[tabId];
                }
            });
        });
    }
});

// Handle incoming messages from Content Script or Popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'newCall') {
        const tabId = sender.tab?.id;
        const newCall = { ...message.data, tabId };
        const storedCall = { ...newCall, reqBody: truncateBody(newCall.reqBody), resBody: truncateBody(newCall.resBody) };

        // Serialize read-modify-write so bursts of calls don't overwrite each other
        storageQueue = storageQueue.then(() => new Promise((resolve) => {
            chrome.storage.local.get('apiCalls', (res) => {
                const apiCalls = res.apiCalls || [];
                apiCalls.unshift(storedCall);

                // Limit total logs in memory/storage
                if (apiCalls.length > MAX_LOGS) {
                    apiCalls.length = MAX_LOGS;
                }

                chrome.storage.local.set({ apiCalls }, () => {
                    if (chrome.runtime.lastError) {
                        console.warn('API Interceptor: could not store call', chrome.runtime.lastError.message);
                    }
                    // Real-time broadcast to DevTools Panel
                    if (tabId && devtoolsPorts[tabId]) {
                        try {
                            devtoolsPorts[tabId].postMessage({ action: 'newCall', call: newCall });
                        } catch (e) {
                            delete devtoolsPorts[tabId];
                        }
                    }
                    sendResponse({ success: true });
                    resolve();
                });
            });
        }));
        return true; // Return true for async response support
    }
    
    if (message.action === 'clearCalls') {
        chrome.storage.local.set({ apiCalls: [] }, () => {
            // Notify DevTools ports
            Object.values(devtoolsPorts).forEach((port) => {
                try {
                    port.postMessage({ action: 'clearCalls' });
                } catch (e) {
                    // Port already closed
                }
            });
            sendResponse({ success: true });
        });
        return true;
    }
});

// --- Icon badge: "OFF" while capture is paused, otherwise the number of enabled mock rules ---
// (a visible reminder that responses on the page may be mocked)
function refreshBadge() {
    chrome.storage.local.get(['isPaused', 'mockRules'], (res) => {
        const enabled = (res.mockRules || []).filter(r => r && r.enabled).length;
        if (res.isPaused) {
            chrome.action.setBadgeText({ text: 'OFF' });
            chrome.action.setBadgeBackgroundColor({ color: '#868e96' });
            chrome.action.setTitle({ title: 'API Interceptor Pro: capture paused' });
        } else if (enabled > 0) {
            chrome.action.setBadgeText({ text: String(enabled) });
            chrome.action.setBadgeBackgroundColor({ color: '#9c36b5' });
            chrome.action.setTitle({ title: `API Interceptor Pro: ${enabled} mock rule${enabled === 1 ? '' : 's'} active` });
        } else {
            chrome.action.setBadgeText({ text: '' });
            chrome.action.setTitle({ title: 'API Interceptor Pro' });
        }
    });
}

chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && (changes.isPaused || changes.mockRules)) refreshBadge();
});
chrome.runtime.onStartup.addListener(refreshBadge);
chrome.runtime.onInstalled.addListener(refreshBadge);

// --- Keyboard shortcuts (chrome://extensions/shortcuts) ---
chrome.commands.onCommand.addListener((command) => {
    if (command === 'toggle-capture') {
        chrome.storage.local.get('isPaused', (res) => {
            chrome.storage.local.set({ isPaused: !res.isPaused });
        });
    } else if (command === 'toggle-mocks') {
        // Master switch for mocks: turn every rule off, or restore the ones that were on
        chrome.storage.local.get(['mockRules', 'mocksSuspended'], (res) => {
            const rules = res.mockRules || [];
            const suspended = res.mocksSuspended || [];
            if (rules.some(r => r.enabled)) {
                const ids = rules.filter(r => r.enabled).map(r => r.id);
                rules.forEach(r => { r.enabled = false; });
                chrome.storage.local.set({ mockRules: rules, mocksSuspended: ids });
            } else if (suspended.length) {
                rules.forEach(r => { if (suspended.includes(r.id)) r.enabled = true; });
                chrome.storage.local.set({ mockRules: rules, mocksSuspended: [] });
            }
        });
    }
});
