const devtoolsPorts = {};
const MAX_LOGS = 150;
// Captured calls live in chrome.storage.session: kept in memory only (auth headers and
// bodies are never written to disk), cleared when the browser closes, and not visible to
// content scripts, so big writes are not broadcast to every open tab. Its quota is 10 MB;
// keep stored bodies small.
// The live DevTools panel still receives the full body via its port.
const MAX_STORED_BODY = 20000;

function truncateBody(value) {
    if (typeof value !== 'string') return value;
    return value.length > MAX_STORED_BODY ? value.substring(0, MAX_STORED_BODY) + '... [Truncated for storage]' : value;
}
let storageQueue = Promise.resolve();


// Initialize defaults on install
chrome.runtime.onInstalled.addListener(() => {
    // Versions before 1.5 kept captured calls in storage.local
    chrome.storage.local.remove('apiCalls');
    chrome.storage.local.get(['isPaused', 'mockRules', 'showWidget'], (res) => {
        const updates = {};
        if (res.isPaused === undefined) updates.isPaused = false;
        if (res.mockRules === undefined) updates.mockRules = [];
        if (res.showWidget === undefined) updates.showWidget = false; // in-page overlay is opt-in
        
        if (Object.keys(updates).length > 0) {
            chrome.storage.local.set(updates);
        }
    });
});

// Captured calls are written in small batches: rewriting the whole list (up to a few MB)
// for every single request made busy pages slow.
let pendingCalls = [];   // oldest first, not yet in storage
let flushTimer = null;

function queueStoredCall(call) {
    pendingCalls.push(call);
    if (!flushTimer) flushTimer = setTimeout(flushCalls, 250);
}

function flushCalls() {
    flushTimer = null;
    const batch = pendingCalls;
    pendingCalls = [];
    if (!batch.length) return storageQueue;
    storageQueue = storageQueue.then(() => new Promise((resolve) => {
        chrome.storage.session.get('apiCalls', (res) => {
            const apiCalls = batch.slice().reverse().concat(res.apiCalls || []).slice(0, MAX_LOGS);
            chrome.storage.session.set({ apiCalls }, () => {
                if (chrome.runtime.lastError) {
                    console.warn('API Interceptor: could not store calls', chrome.runtime.lastError.message);
                }
                resolve();
            });
        });
    }));
    return storageQueue;
}

// Calls of one tab (or of every tab when tabId is null), newest first, including unsaved ones
function callsFor(tabId, callback) {
    storageQueue.then(() => {
        chrome.storage.session.get('apiCalls', (res) => {
            const all = pendingCalls.slice().reverse().concat(res.apiCalls || []);
            callback(tabId === null ? all : all.filter(c => c && c.tabId === tabId));
        });
    });
}

function notifyTabCleared(tabId) {
    chrome.tabs.sendMessage(tabId, { action: 'callsCleared' }, () => void chrome.runtime.lastError);
}

// tabId === null clears every tab
function clearCalls(tabId, done) {
    pendingCalls = tabId === null ? [] : pendingCalls.filter(c => c.tabId !== tabId);
    storageQueue = storageQueue.then(() => new Promise((resolve) => {
        chrome.storage.session.get('apiCalls', (res) => {
            const apiCalls = tabId === null ? [] : (res.apiCalls || []).filter(c => c && c.tabId !== tabId);
            chrome.storage.session.set({ apiCalls }, () => {
                Object.keys(devtoolsPorts).forEach((id) => {
                    if (tabId !== null && Number(id) !== tabId) return;
                    try {
                        devtoolsPorts[id].postMessage({ action: 'clearCalls' });
                    } catch (e) {
                        // Port already closed
                    }
                });
                if (tabId !== null) {
                    notifyTabCleared(tabId);
                } else {
                    chrome.tabs.query({}, (tabs) => (tabs || []).forEach(t => notifyTabCleared(t.id)));
                }
                resolve();
                done();
            });
        });
    }));
}

// Listen to DevTools Panel connections
chrome.runtime.onConnect.addListener((port) => {
    if (port.name !== 'devtools-page' || port.sender?.id !== chrome.runtime.id) return;
    const listener = (message) => {
        if (message && message.action === 'init' && Number.isInteger(message.tabId)) {
            devtoolsPorts[message.tabId] = port;

            // Populate DevTools on load with existing cached logs
            callsFor(message.tabId, (calls) => {
                try {
                    port.postMessage({ action: 'initCalls', calls, keepExisting: !!message.keepExisting });
                } catch (e) {
                    // Panel closed before storage returned
                }
            });
        }
    };
    port.onMessage.addListener(listener);
    port.onDisconnect.addListener(() => {
        port.onMessage.removeListener(listener);
        Object.keys(devtoolsPorts).forEach((tabId) => {
            if (devtoolsPorts[tabId] === port) {
                delete devtoolsPorts[tabId];
            }
        });
    });
});

// Handle incoming messages from Content Script or Popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (sender.id !== chrome.runtime.id || !message) return;

    if (message.action === 'newCall') {
        // Only a content script running in a tab can report a captured call
        const tabId = sender.tab?.id;
        if (!Number.isInteger(tabId) || sender.frameId !== 0 || !message.data || typeof message.data !== 'object') return;
        const newCall = { ...message.data, tabId };

        // Real-time broadcast to DevTools Panel (full body)
        if (devtoolsPorts[tabId]) {
            try {
                devtoolsPorts[tabId].postMessage({ action: 'newCall', call: newCall });
            } catch (e) {
                delete devtoolsPorts[tabId];
            }
        }
        queueStoredCall({ ...newCall, reqBody: truncateBody(newCall.reqBody), resBody: truncateBody(newCall.resBody) });
        sendResponse({ success: true });
        return;
    }

    // The in-page widget asks for the calls already captured in its own tab
    if (message.action === 'getTabCalls') {
        const tabId = sender.tab?.id;
        if (!Number.isInteger(tabId)) return;
        callsFor(tabId, (calls) => sendResponse({ calls }));
        return true;
    }

    if (message.action === 'clearCalls') {
        // A content script (the in-page widget) may only clear its own tab
        const fromExtensionPage = typeof sender.url === 'string' && sender.url.startsWith(`chrome-extension://${chrome.runtime.id}/`);
        let tabId = null;
        if (!fromExtensionPage) {
            if (!Number.isInteger(sender.tab?.id)) return;
            tabId = sender.tab.id;
        } else if (Number.isInteger(message.tabId)) {
            tabId = message.tabId;
        }
        clearCalls(tabId, () => sendResponse({ success: true }));
        return true;
    }
});

// --- Icon badge: "OFF" while capture is paused, otherwise the number of enabled mock rules ---
// (a visible reminder that responses on the page may be mocked)
function refreshBadge() {
    chrome.storage.local.get(['isPaused', 'mockRules'], (res) => {
        const enabled = (res.mockRules || []).filter(r => r && r.enabled).length;
        if (res.isPaused) {
            chrome.action.setBadgeText({ text: 'OFF' });
            chrome.action.setBadgeBackgroundColor({ color: '#868e96' });
            chrome.action.setTitle({ title: 'API Interceptor Pro: capture paused' });
        } else if (enabled > 0) {
            chrome.action.setBadgeText({ text: String(enabled) });
            chrome.action.setBadgeBackgroundColor({ color: '#9c36b5' });
            chrome.action.setTitle({ title: `API Interceptor Pro: ${enabled} mock rule${enabled === 1 ? '' : 's'} active` });
        } else {
            chrome.action.setBadgeText({ text: '' });
            chrome.action.setTitle({ title: 'API Interceptor Pro' });
        }
    });
}

chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && (changes.isPaused || changes.mockRules)) refreshBadge();
});
chrome.runtime.onStartup.addListener(refreshBadge);
chrome.runtime.onInstalled.addListener(refreshBadge);

// --- Keyboard shortcuts (chrome://extensions/shortcuts) ---
chrome.commands.onCommand.addListener((command) => {
    if (command === 'toggle-capture') {
        chrome.storage.local.get('isPaused', (res) => {
            chrome.storage.local.set({ isPaused: !res.isPaused });
        });
    } else if (command === 'toggle-mocks') {
        // Master switch for mocks: turn every rule off, or restore the ones that were on
        chrome.storage.local.get(['mockRules', 'mocksSuspended'], (res) => {
            const rules = res.mockRules || [];
            const suspended = res.mocksSuspended || [];
            if (rules.some(r => r.enabled)) {
                const ids = rules.filter(r => r.enabled).map(r => r.id);
                rules.forEach(r => { r.enabled = false; });
                chrome.storage.local.set({ mockRules: rules, mocksSuspended: ids });
            } else if (suspended.length) {
                rules.forEach(r => { if (suspended.includes(r.id)) r.enabled = true; });
                chrome.storage.local.set({ mockRules: rules, mocksSuspended: [] });
            }
        });
    }
});
