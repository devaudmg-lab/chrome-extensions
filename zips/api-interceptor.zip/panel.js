// Detect theme from Chrome DevTools
if (chrome.devtools && chrome.devtools.panels && chrome.devtools.panels.themeName === 'default') {
    document.body.classList.add('theme-light');
}

// Global states
let callsArray = [];
let selectedCallId = null;
let activeTab = 'headers';
let searchQuery = '';
let isPaused = false;
let mockRules = [];
let showWidget = false;
let editingRuleId = null;
const inspectedTabId = chrome.devtools.inspectedWindow.tabId;

// DOM Elements
const tableBody = document.getElementById("table-body");
const searchInput = document.getElementById("search-toolbar-input");
const clearBtn = document.getElementById("clear-toolbar-btn");
const pauseBtn = document.getElementById("pause-toolbar-btn");
const pauseIcon = document.getElementById("pause-icon");
const pauseText = document.getElementById("pause-text");
const harBtn = document.getElementById("har-toolbar-btn");
const widgetToggle = document.getElementById("widget-toggle");

// Detail DOMs
const detailsReqUrl = document.getElementById("details-request-url");
const replayBtn = document.getElementById("replay-btn");
const curlBtn = document.getElementById("curl-btn");
const headersViewContainer = document.getElementById("headers-view-container");
const headersEmpty = document.getElementById("headers-empty");
const generalHeadersList = document.getElementById("general-headers-list");
const responseHeadersList = document.getElementById("response-headers-list");
const requestHeadersList = document.getElementById("request-headers-list");

const payloadViewContainer = document.getElementById("payload-view-container");
const payloadCodeView = document.getElementById("payload-code-view");
const payloadEmpty = document.getElementById("payload-empty");

const responseViewContainer = document.getElementById("response-view-container");
const responseCodeView = document.getElementById("response-code-view");
const responseEmpty = document.getElementById("response-empty");

// Mock Form DOMs
const mockUrlPattern = document.getElementById("mock-url-pattern");
const mockMethod = document.getElementById("mock-method");
const mockStatus = document.getElementById("mock-status");
const mockDelay = document.getElementById("mock-delay");
const mockBody = document.getElementById("mock-body");
const mockMatchType = document.getElementById("mock-match-type");
const mockHeaders = document.getElementById("mock-headers");
const saveRuleBtn = document.getElementById("save-rule-btn");
const cancelEditBtn = document.getElementById("cancel-edit-btn");
const mockRulesList = document.getElementById("mock-rules-list");
const exportRulesBtn = document.getElementById("export-rules-btn");
const importRulesBtn = document.getElementById("import-rules-btn");
const importRulesFile = document.getElementById("import-rules-file");

// Connect to background coordinator. The MV3 service worker can be stopped
// at any time, which closes the port, so reconnect automatically.
let port = null;
function connectPort(isReconnect) {
    port = chrome.runtime.connect({ name: 'devtools-page' });
    port.onMessage.addListener(handlePortMessage);
    port.onDisconnect.addListener(() => {
        void chrome.runtime.lastError;
        port = null;
        setTimeout(() => connectPort(true), 500);
    });
    // On reconnect keep the in-memory list (it holds full, untruncated bodies)
    port.postMessage({ action: 'init', tabId: inspectedTabId, keepExisting: !!isReconnect });
}

// Sync storage states
chrome.storage.local.get(['isPaused', 'mockRules', 'showWidget'], (res) => {
    isPaused = !!res.isPaused;
    mockRules = res.mockRules || [];
    showWidget = res.showWidget === true;
    
    updatePauseUI();
    widgetToggle.checked = showWidget;
    renderMockRules();
});

// Watch for changes in storage
chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === 'local') {
        if (changes.isPaused) {
            isPaused = !!changes.isPaused.newValue;
            updatePauseUI();
        }
        if (changes.mockRules) {
            mockRules = changes.mockRules.newValue || [];
            renderMockRules();
        }
        if (changes.showWidget) {
            showWidget = changes.showWidget.newValue === true;
            widgetToggle.checked = showWidget;
        }
    }
});

// Listen to network logs from background
function handlePortMessage(msg) {
    if (msg.action === 'initCalls') {
        if (msg.keepExisting && callsArray.length > 0) return;
        callsArray = msg.calls || [];
        scheduleRenderTable();
    } else if (msg.action === 'newCall') {
        callsArray.unshift(msg.call);
        // limit list view size
        if (callsArray.length > 150) {
            callsArray.pop();
        }
        scheduleRenderTable();
    } else if (msg.action === 'clearCalls') {
        callsArray = [];
        selectedCallId = null;
        scheduleRenderTable();
        updateDetailsUI();
    }
}
connectPort(false);

// --- Tab Navigation ---
document.querySelectorAll(".tab").forEach(tab => {
    tab.onclick = () => {
        document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
        tab.classList.add("active");
        activeTab = tab.dataset.tab;
        
        document.querySelectorAll(".tab-content").forEach(content => {
            content.classList.toggle("active", content.id === `tab-${activeTab}`);
        });
    };
});

// --- Toolbar Listeners ---
clearBtn.onclick = () => {
    chrome.runtime.sendMessage({ action: 'clearCalls' });
};

pauseBtn.onclick = () => {
    chrome.storage.local.set({ isPaused: !isPaused });
};

function updatePauseUI() {
    if (isPaused) {
        pauseIcon.innerText = "▶️";
        pauseText.innerText = "Resume";
        pauseBtn.classList.add("active");
    } else {
        pauseIcon.innerText = "⏸️";
        pauseText.innerText = "Pause";
        pauseBtn.classList.remove("active");
    }
}

widgetToggle.onchange = (e) => {
    chrome.storage.local.set({ showWidget: e.target.checked });
};

searchInput.oninput = (e) => {
    searchQuery = e.target.value.toLowerCase();
    scheduleRenderTable();
};

harBtn.onclick = () => {
    exportLogs();
};

function downloadText(filename, text, mime) {
    const blob = new Blob([text], { type: mime || 'application/json' });
    const url = URL.createObjectURL(blob);
    const downloadAnchor = document.createElement('a');
    downloadAnchor.href = url;
    downloadAnchor.download = filename;
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function toHarHeaders(obj) {
    return Object.entries(obj || {}).map(([name, value]) => ({ name, value: String(value) }));
}

function headerValue(obj, name) {
    const key = Object.keys(obj || {}).find(k => k.toLowerCase() === name);
    return key ? String(obj[key]) : '';
}

// Build a HAR 1.2 document from the captured calls (oldest first)
function buildHar(calls) {
    const entries = calls.slice().reverse().map(call => {
        let queryString = [];
        try {
            queryString = Array.from(new URL(call.url).searchParams.entries()).map(([name, value]) => ({ name, value }));
        } catch (e) {}
        const resBody = call.resBody == null ? '' : String(call.resBody);
        const latency = Number(call.latency) || 0;
        const started = call.timestamp ? new Date(call.timestamp) : new Date();
        const entry = {
            startedDateTime: started.toISOString(),
            time: latency,
            request: {
                method: call.method || 'GET',
                url: call.url || '',
                httpVersion: 'HTTP/1.1',
                cookies: [],
                headers: toHarHeaders(call.reqHeaders),
                queryString,
                headersSize: -1,
                bodySize: call.reqBody ? String(call.reqBody).length : 0
            },
            response: {
                status: Number(call.status) || 0,
                statusText: call.isMocked ? 'Mocked' : '',
                httpVersion: 'HTTP/1.1',
                cookies: [],
                headers: toHarHeaders(call.resHeaders),
                content: {
                    size: resBody.length,
                    mimeType: headerValue(call.resHeaders, 'content-type') || 'text/plain',
                    text: resBody
                },
                redirectURL: '',
                headersSize: -1,
                bodySize: resBody.length
            },
            cache: {},
            timings: { send: 0, wait: latency, receive: 0 },
            _resourceType: call.type || 'fetch',
            _mocked: !!call.isMocked
        };
        if (call.reqBody) {
            entry.request.postData = {
                mimeType: headerValue(call.reqHeaders, 'content-type') || 'text/plain',
                text: String(call.reqBody)
            };
        }
        return entry;
    });
    return {
        log: {
            version: '1.2',
            creator: { name: 'API Interceptor Pro', version: chrome.runtime.getManifest().version },
            pages: [],
            entries
        }
    };
}

function exportLogs() {
    const stamp = new Date().toISOString().replace(/[:.]/g, '-');
    downloadText(`api_monitor_${stamp}.har`, JSON.stringify(buildHar(callsArray), null, 2));
}

// --- Copy as cURL ---
function shellQuote(value) {
    return "'" + String(value).replace(/'/g, "'\\''") + "'";
}

function buildCurl(call) {
    const parts = ['curl', shellQuote(call.url)];
    if (call.method && call.method.toUpperCase() !== 'GET') {
        parts.push('-X', shellQuote(call.method.toUpperCase()));
    }
    Object.entries(call.reqHeaders || {}).forEach(([k, v]) => {
        parts.push('-H', shellQuote(`${k}: ${v}`));
    });
    if (call.reqBody && !/^\[(FormData|Object \/ Binary Body)\]$/.test(String(call.reqBody))) {
        parts.push('--data-raw', shellQuote(call.reqBody));
    }
    return parts.join(' ');
}

function copyText(text) {
    // navigator.clipboard is often blocked inside DevTools panels; use a textarea fallback
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    let ok = false;
    try {
        ok = document.execCommand('copy');
    } catch (e) {}
    ta.remove();
    return ok;
}

curlBtn.onclick = () => {
    const call = callsArray.find(c => c.id === selectedCallId);
    if (!call) return;
    const ok = copyText(buildCurl(call));
    const original = curlBtn.textContent;
    curlBtn.textContent = ok ? '✅ Copied' : '⚠️ Copy failed';
    setTimeout(() => { curlBtn.textContent = original; }, 1500);
};

// --- Replay Request snippet executor ---
replayBtn.onclick = () => {
    const call = callsArray.find(c => c.id === selectedCallId);
    if (!call) return;

    let headersObj = call.reqHeaders || {};
    let init = {
        method: call.method,
        headers: headersObj
    };
    if (call.reqBody && ['POST', 'PUT', 'PATCH', 'DELETE'].includes(call.method)) {
        init.body = call.reqBody;
    }

    const fetchSnippet = `
        fetch(${JSON.stringify(call.url)}, ${JSON.stringify(init)})
            .then(res => res.text().then(text => ({ status: res.status, text })))
            .then(data => console.log('%c[API Monitor Replayed]', 'color: #51cf66; font-weight: bold;', data))
            .catch(err => console.error('[API Monitor Replay Error]', err));
    `;

    chrome.devtools.inspectedWindow.eval(fetchSnippet, (result, isException) => {
        if (isException) {
            console.error("Replay exception:", isException);
        }
    });
};

function escapeHtml(value) {
    return String(value ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

// --- Table Rendering ---
let renderTableFrameId = null;
function scheduleRenderTable() {
    if (renderTableFrameId) return;
    renderTableFrameId = requestAnimationFrame(() => {
        renderTable();
        renderTableFrameId = null;
    });
}

function renderTable() {
    // Keep reference of current selected row DOM to re-highlight it
    tableBody.innerHTML = '';
    
    const filtered = callsArray.filter(call => {
        return !searchQuery || 
            (call.url && call.url.toLowerCase().includes(searchQuery)) ||
            (call.method && call.method.toLowerCase().includes(searchQuery));
    });

    if (filtered.length === 0) {
        tableBody.innerHTML = `
            <div class="empty-placeholder">
                <span>🔍</span>
                <div>No matching requests.</div>
            </div>`;
        return;
    }

    filtered.forEach(call => {
        const row = document.createElement("div");
        row.className = `table-row ${selectedCallId === call.id ? 'selected' : ''}`;
        row.dataset.id = call.id;

        const isMock = !!call.isMocked;
        let statusClass = 'status-2xx';
        if (call.status === 0 || call.error) statusClass = 'status-error';
        else if (isMock) statusClass = 'status-mock';
        else if (call.status >= 400) statusClass = 'status-4xx';
        else if (call.status >= 300) statusClass = 'status-3xx';

        const statusDisplay = isMock ? 'MOCK' : (call.status === 0 ? 'FAIL' : call.status);
        const latencyVal = call.latency !== undefined ? `${call.latency}ms` : '';
        const reqType = call.type ? call.type.toUpperCase() : 'FETCH';

        row.innerHTML = `
            <div class="col method-col"><span class="badge badge-${escapeHtml(call.method)}">${escapeHtml(call.method)}</span></div>
            <div class="col status-col ${statusClass}">${escapeHtml(statusDisplay)}</div>
            <div class="col url-col" title="${escapeHtml(call.url)}">${escapeHtml(call.url)}</div>
            <div class="col latency-col">${latencyVal}</div>
            <div class="col type-col">${reqType}</div>
        `;

        row.onclick = () => {
            document.querySelectorAll(".table-row").forEach(r => r.classList.remove("selected"));
            row.classList.add("selected");
            selectedCallId = call.id;
            updateDetailsUI();
            prepopulateMockForm(call);
        };

        tableBody.appendChild(row);
    });
}

// JSON syntax helper
function syntaxHighlight(json) {
    if (typeof json !== 'string') {
        json = JSON.stringify(json, null, 2);
    }
    try {
        json = json.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
        return json.replace(/("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+-]?\d+)?)/g, function (match) {
            let cls = 'number';
            if (/^"/.test(match)) {
                if (/:$/.test(match)) {
                    cls = 'key';
                } else {
                    cls = 'string';
                }
            } else if (/true|false/.test(match)) {
                cls = 'boolean';
            } else if (/null/.test(match)) {
                cls = 'null';
            }
            return '<span class="' + cls + '">' + match + '</span>';
        });
    } catch (e) {
        return json;
    }
}

// --- Detail View Logic ---
function updateDetailsUI() {
    const call = callsArray.find(c => c.id === selectedCallId);
    if (!call) {
        // Hide details container, show empty placeholder
        headersViewContainer.style.display = 'none';
        headersEmpty.style.display = 'flex';
        
        payloadViewContainer.style.display = 'none';
        payloadEmpty.style.display = 'flex';

        responseViewContainer.style.display = 'none';
        responseEmpty.style.display = 'flex';
        return;
    }

    // Populate Headers Tab
    headersEmpty.style.display = 'none';
    headersViewContainer.style.display = 'block';

    detailsReqUrl.innerText = `${call.method} ${call.url}`;

    // General headers list
    generalHeadersList.innerHTML = `
        <div class="header-item">
            <div class="header-name">Request URL</div>
            <div class="header-value">${escapeHtml(call.url)}</div>
        </div>
        <div class="header-item">
            <div class="header-name">Request Method</div>
            <div class="header-value">${escapeHtml(call.method)}</div>
        </div>
        <div class="header-item">
            <div class="header-name">Status Code</div>
            <div class="header-value">${call.status || 'Failed'}</div>
        </div>
        <div class="header-item">
            <div class="header-name">Latency</div>
            <div class="header-value">${call.latency !== undefined ? call.latency + ' ms' : 'unknown'}</div>
        </div>
    `;

    // Response Headers
    responseHeadersList.innerHTML = '';
    const resHeaders = call.resHeaders || {};
    if (Object.keys(resHeaders).length === 0) {
        responseHeadersList.innerHTML = '<div style="color:var(--text-secondary); font-style:italic;">No response headers</div>';
    } else {
        Object.entries(resHeaders).forEach(([k, v]) => {
            const el = document.createElement("div");
            el.className = 'header-item';
            el.innerHTML = `<div class="header-name">${escapeHtml(k)}</div><div class="header-value">${escapeHtml(v)}</div>`;
            responseHeadersList.appendChild(el);
        });
    }

    // Request Headers
    requestHeadersList.innerHTML = '';
    const reqHeaders = call.reqHeaders || {};
    if (Object.keys(reqHeaders).length === 0) {
        requestHeadersList.innerHTML = '<div style="color:var(--text-secondary); font-style:italic;">No request headers</div>';
    } else {
        Object.entries(reqHeaders).forEach(([k, v]) => {
            const el = document.createElement("div");
            el.className = 'header-item';
            el.innerHTML = `<div class="header-name">${escapeHtml(k)}</div><div class="header-value">${escapeHtml(v)}</div>`;
            requestHeadersList.appendChild(el);
        });
    }

    // Populate Payload Tab
    if (call.reqBody) {
        payloadEmpty.style.display = 'none';
        payloadViewContainer.style.display = 'block';
        try {
            const parsed = JSON.parse(call.reqBody);
            payloadCodeView.innerHTML = syntaxHighlight(parsed);
        } catch(e) {
            payloadCodeView.innerText = call.reqBody;
        }
    } else {
        payloadViewContainer.style.display = 'none';
        payloadEmpty.style.display = 'flex';
        payloadEmpty.innerText = 'No request payload for this request type.';
    }

    // Populate Response Tab
    if (call.resBody !== undefined && call.resBody !== null) {
        responseEmpty.style.display = 'none';
        responseViewContainer.style.display = 'block';
        try {
            const parsed = JSON.parse(call.resBody);
            responseCodeView.innerHTML = syntaxHighlight(parsed);
        } catch(e) {
            responseCodeView.innerText = call.resBody;
        }
    } else {
        responseViewContainer.style.display = 'none';
        responseEmpty.style.display = 'flex';
        responseEmpty.innerText = 'No response payload recorded.';
    }
}

// Prepopulate the Mock form fields using the details of the selected request
function prepopulateMockForm(call) {
    // extract relative path or domain match
    let pattern = call.url;
    try {
        const urlObj = new URL(call.url);
        pattern = urlObj.pathname; // Default to path substring for easier pattern matching
    } catch(e) {}
    
    if (editingRuleId) return; // don't overwrite a rule that is being edited
    mockUrlPattern.value = pattern;
    mockMatchType.value = 'substring';
    mockHeaders.value = '';
    mockMethod.value = (call.method || 'ANY').toUpperCase();
    if (!mockMethod.value) mockMethod.value = 'ANY';
    mockStatus.value = call.status || 200;
    mockDelay.value = 0;
    
    // Clean response body format for rule creator
    let bodyText = call.resBody || '';
    try {
        const parsed = JSON.parse(bodyText);
        bodyText = JSON.stringify(parsed, null, 2);
    } catch(e) {}
    mockBody.value = bodyText;
}

// --- Mocking Management ---
saveRuleBtn.onclick = () => {
    const pattern = mockUrlPattern.value.trim();
    if (!pattern) {
        alert("Please enter a URL pattern to match.");
        return;
    }

    const matchType = mockMatchType.value;
    if (matchType === 'regex') {
        try {
            new RegExp(pattern);
        } catch (e) {
            alert("Invalid regular expression: " + e.message);
            return;
        }
    }

    let headers = null;
    const headersText = mockHeaders.value.trim();
    if (headersText) {
        try {
            headers = JSON.parse(headersText);
            if (!headers || typeof headers !== 'object' || Array.isArray(headers)) throw new Error('not an object');
        } catch (e) {
            alert('Response headers must be a JSON object, e.g. {"Content-Type": "application/json"}');
            return;
        }
    }

    const statusCode = Number(mockStatus.value) || 200;
    if (statusCode < 200 || statusCode > 599) {
        alert("Status code must be between 200 and 599.");
        return;
    }

    const ruleData = {
        urlPattern: pattern,
        method: mockMethod.value,
        statusCode,
        delay: Math.max(0, Number(mockDelay.value) || 0),
        responseBody: mockBody.value,
        headers,
        matchType
    };

    const existing = editingRuleId ? mockRules.find(r => r.id === editingRuleId) : null;
    if (existing) {
        Object.assign(existing, ruleData);
    } else {
        mockRules.push({ id: Math.random().toString(36).substring(2, 9), enabled: true, ...ruleData });
    }

    chrome.storage.local.set({ mockRules }, () => {
        alert(existing ? "Mock rule updated." : "Mock rule created successfully!");
        resetMockForm();
        renderMockRules();
    });
};

function resetMockForm() {
    editingRuleId = null;
    mockUrlPattern.value = '';
    mockBody.value = '';
    mockHeaders.value = '';
    mockMatchType.value = 'substring';
    mockMethod.value = 'ANY';
    mockStatus.value = 200;
    mockDelay.value = 0;
    saveRuleBtn.textContent = 'Save Mock Rule';
    cancelEditBtn.style.display = 'none';
}

cancelEditBtn.onclick = resetMockForm;

function startEditRule(rule) {
    editingRuleId = rule.id;
    mockUrlPattern.value = rule.urlPattern || '';
    mockMatchType.value = rule.matchType || 'substring';
    mockMethod.value = rule.method || 'ANY';
    mockStatus.value = rule.statusCode || 200;
    mockDelay.value = rule.delay || 0;
    mockHeaders.value = rule.headers ? JSON.stringify(rule.headers, null, 2) : '';
    mockBody.value = rule.responseBody || '';
    saveRuleBtn.textContent = 'Update Mock Rule';
    cancelEditBtn.style.display = 'inline-block';
    mockUrlPattern.focus();
}

// --- Rules export / import ---
exportRulesBtn.onclick = () => {
    downloadText('api_interceptor_rules.json', JSON.stringify({ version: 1, mockRules }, null, 2));
};

importRulesBtn.onclick = () => importRulesFile.click();

importRulesFile.onchange = () => {
    const file = importRulesFile.files && importRulesFile.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
        try {
            const data = JSON.parse(reader.result);
            const incoming = Array.isArray(data) ? data : data.mockRules;
            if (!Array.isArray(incoming)) throw new Error('No mockRules array found');
            const valid = incoming
                .filter(r => r && typeof r.urlPattern === 'string' && r.urlPattern.trim())
                .map(r => ({
                    id: Math.random().toString(36).substring(2, 9),
                    urlPattern: r.urlPattern,
                    method: typeof r.method === 'string' ? r.method.toUpperCase() : 'ANY',
                    statusCode: Number(r.statusCode) || 200,
                    delay: Math.max(0, Number(r.delay) || 0),
                    responseBody: typeof r.responseBody === 'string' ? r.responseBody : JSON.stringify(r.responseBody ?? ''),
                    headers: r.headers && typeof r.headers === 'object' && !Array.isArray(r.headers) ? r.headers : null,
                    matchType: ['substring', 'exact', 'regex'].includes(r.matchType) ? r.matchType : 'substring',
                    enabled: r.enabled !== false
                }));
            mockRules = mockRules.concat(valid);
            chrome.storage.local.set({ mockRules }, () => {
                alert(`Imported ${valid.length} mock rule(s).`);
                renderMockRules();
            });
        } catch (e) {
            alert('Could not import rules: ' + e.message);
        }
        importRulesFile.value = '';
    };
    reader.readAsText(file);
};

function renderMockRules() {
    mockRulesList.innerHTML = '';
    
    if (mockRules.length === 0) {
        mockRulesList.innerHTML = '<div style="color:var(--text-secondary); font-style:italic;">No mock rules defined yet.</div>';
        return;
    }

    mockRules.forEach(rule => {
        const card = document.createElement("div");
        card.className = "rule-card";
        
        card.innerHTML = `
            <div class="rule-details">
                <div class="rule-pattern">${escapeHtml(rule.method)} ${escapeHtml(rule.urlPattern)}</div>
                <div class="rule-meta">
                    <span>${escapeHtml(({ substring: 'Contains', exact: 'Exact', regex: 'Regex' })[rule.matchType] || 'Contains')}</span>
                    <span>Status: ${escapeHtml(rule.statusCode)}</span>
                    <span>Delay: ${escapeHtml(rule.delay)}ms</span>
                </div>
            </div>
            <div class="rule-actions">
                <input type="checkbox" class="rule-enable-toggle" title="Enable / disable" data-id="${escapeHtml(rule.id)}" ${rule.enabled ? 'checked' : ''}>
                <button class="secondary-btn edit-btn" data-id="${escapeHtml(rule.id)}">Edit</button>
                <button class="danger-btn" data-id="${escapeHtml(rule.id)}">Delete</button>
            </div>
        `;

        // Toggle state hook
        card.querySelector(".rule-enable-toggle").onchange = (e) => {
            const ruleId = e.target.dataset.id;
            const targetRule = mockRules.find(r => r.id === ruleId);
            if (targetRule) {
                targetRule.enabled = e.target.checked;
                chrome.storage.local.set({ mockRules });
            }
        };

        card.querySelector(".edit-btn").onclick = () => startEditRule(rule);

        // Delete hook
        card.querySelector(".danger-btn").onclick = (e) => {
            const ruleId = e.target.dataset.id;
            if (editingRuleId === ruleId) resetMockForm();
            mockRules = mockRules.filter(r => r.id !== ruleId);
            chrome.storage.local.set({ mockRules });
        };

        mockRulesList.appendChild(card);
    });
}
