// Detect theme from Chrome DevTools
if (chrome.devtools && chrome.devtools.panels && chrome.devtools.panels.themeName === 'default') {
    document.body.classList.add('theme-light');
}

// Global states
let callsArray = [];
let selectedCallId = null;
let activeTab = 'headers';
let searchQuery = '';
let isPaused = false;
let mockRules = [];
let showWidget = false;
let editingRuleId = null;
let typeFilter = 'all';
const inspectedTabId = chrome.devtools.inspectedWindow.tabId;

// DOM Elements
const tableBody = document.getElementById("table-body");
const searchInput = document.getElementById("search-toolbar-input");
const clearBtn = document.getElementById("clear-toolbar-btn");
const pauseBtn = document.getElementById("pause-toolbar-btn");
const pauseIcon = document.getElementById("pause-icon");
const pauseText = document.getElementById("pause-text");
const harBtn = document.getElementById("har-toolbar-btn");
const widgetToggle = document.getElementById("widget-toggle");

// Detail DOMs
const detailsReqUrl = document.getElementById("details-request-url");
const replayBtn = document.getElementById("replay-btn");
const curlBtn = document.getElementById("curl-btn");
const headersViewContainer = document.getElementById("headers-view-container");
const headersEmpty = document.getElementById("headers-empty");
const generalHeadersList = document.getElementById("general-headers-list");
const responseHeadersList = document.getElementById("response-headers-list");
const requestHeadersList = document.getElementById("request-headers-list");

const payloadViewContainer = document.getElementById("payload-view-container");
const payloadCodeView = document.getElementById("payload-code-view");
const payloadEmpty = document.getElementById("payload-empty");

const responseViewContainer = document.getElementById("response-view-container");
const responseCodeView = document.getElementById("response-code-view");
const responseEmpty = document.getElementById("response-empty");

// Mock Form DOMs
const mockUrlPattern = document.getElementById("mock-url-pattern");
const mockMethod = document.getElementById("mock-method");
const mockStatus = document.getElementById("mock-status");
const mockDelay = document.getElementById("mock-delay");
const mockBody = document.getElementById("mock-body");
const mockMatchType = document.getElementById("mock-match-type");
const mockHeaders = document.getElementById("mock-headers");
const saveRuleBtn = document.getElementById("save-rule-btn");
const cancelEditBtn = document.getElementById("cancel-edit-btn");
const mockRulesList = document.getElementById("mock-rules-list");
const exportRulesBtn = document.getElementById("export-rules-btn");
const importRulesBtn = document.getElementById("import-rules-btn");
const importRulesFile = document.getElementById("import-rules-file");
const importHarBtn = document.getElementById("import-har-btn");
const importHarFile = document.getElementById("import-har-file");
const mockJitter = document.getElementById("mock-jitter");
const mockGql = document.getElementById("mock-gql");
const mockSite = document.getElementById("mock-site");
const mockTemplate = document.getElementById("mock-template");
const mockFormTitle = document.getElementById("mock-form-title");
const mockThisBtn = document.getElementById("mock-this-btn");
const rulesSummary = document.getElementById("rules-summary");
const rowCount = document.getElementById("row-count");
const typeFilterGroup = document.getElementById("type-filter");
const onboardingBanner = document.getElementById("onboarding");
const toastEl = document.getElementById("toast");

// Small non-blocking notification instead of alert()
let toastTimer = null;
function toast(message, isError) {
    toastEl.textContent = message;
    toastEl.classList.toggle('error', !!isError);
    toastEl.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toastEl.classList.remove('show'), isError ? 4000 : 2200);
}

// First-run banner with the basics and keyboard shortcuts
chrome.storage.local.get('panelOnboarded', (res) => {
    onboardingBanner.hidden = !!res.panelOnboarded;
});
document.getElementById("dismiss-onboarding").onclick = () => {
    onboardingBanner.hidden = true;
    chrome.storage.local.set({ panelOnboarded: true });
};

// Connect to background coordinator. The MV3 service worker can be stopped
// at any time, which closes the port, so reconnect automatically.
let port = null;
function connectPort(isReconnect) {
    port = chrome.runtime.connect({ name: 'devtools-page' });
    port.onMessage.addListener(handlePortMessage);
    port.onDisconnect.addListener(() => {
        void chrome.runtime.lastError;
        port = null;
        setTimeout(() => connectPort(true), 500);
    });
    // On reconnect keep the in-memory list (it holds full, untruncated bodies)
    port.postMessage({ action: 'init', tabId: inspectedTabId, keepExisting: !!isReconnect });
}

// Sync storage states
chrome.storage.local.get(['isPaused', 'mockRules', 'showWidget'], (res) => {
    isPaused = !!res.isPaused;
    mockRules = res.mockRules || [];
    showWidget = res.showWidget === true;

    updatePauseUI();
    widgetToggle.checked = showWidget;
    renderMockRules();
});

// Watch for changes in storage
chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === 'local') {
        if (changes.isPaused) {
            isPaused = !!changes.isPaused.newValue;
            updatePauseUI();
        }
        if (changes.mockRules) {
            mockRules = changes.mockRules.newValue || [];
            renderMockRules();
        }
        if (changes.showWidget) {
            showWidget = changes.showWidget.newValue === true;
            widgetToggle.checked = showWidget;
        }
    }
});

// Listen to network logs from background
function handlePortMessage(msg) {
    if (msg.action === 'initCalls') {
        if (msg.keepExisting && callsArray.length > 0) return;
        callsArray = msg.calls || [];
        scheduleRenderTable();
        renderMockRules();
    } else if (msg.action === 'newCall') {
        callsArray.unshift(msg.call);
        // limit list view size
        if (callsArray.length > 150) {
            callsArray.pop();
        }
        scheduleRenderTable();
        if (msg.call && msg.call.isMocked) renderMockRules();
    } else if (msg.action === 'clearCalls') {
        callsArray = [];
        selectedCallId = null;
        scheduleRenderTable();
        updateDetailsUI();
    }
}
connectPort(false);

// --- Tab Navigation ---
function switchTab(name) {
    activeTab = name;
    document.querySelectorAll(".tab").forEach(t => t.classList.toggle("active", t.dataset.tab === name));
    document.querySelectorAll(".tab-content").forEach(content => {
        content.classList.toggle("active", content.id === `tab-${name}`);
    });
}
document.querySelectorAll(".tab").forEach(tab => {
    tab.onclick = () => switchTab(tab.dataset.tab);
});

// --- Type filter chips ---
typeFilterGroup.addEventListener('click', (e) => {
    const chip = e.target.closest('.chip');
    if (!chip) return;
    typeFilter = chip.dataset.filter;
    typeFilterGroup.querySelectorAll('.chip').forEach(c => c.classList.toggle('active', c === chip));
    scheduleRenderTable();
});

function matchesTypeFilter(call) {
    switch (typeFilter) {
        case 'fetch': return (call.type || 'fetch') === 'fetch';
        case 'xhr': return call.type === 'xhr';
        case 'graphql': return !!call.gqlOp;
        case 'mocked': return !!call.isMocked;
        case 'errors': return !!call.error || call.status === 0 || call.status >= 400;
        default: return true;
    }
}

// --- Toolbar Listeners ---
clearBtn.onclick = () => {
    chrome.runtime.sendMessage({ action: 'clearCalls' });
};

pauseBtn.onclick = () => {
    chrome.storage.local.set({ isPaused: !isPaused });
};

function updatePauseUI() {
    if (isPaused) {
        pauseIcon.innerText = "▶️";
        pauseText.innerText = "Resume";
        pauseBtn.classList.add("active");
    } else {
        pauseIcon.innerText = "⏸️";
        pauseText.innerText = "Pause";
        pauseBtn.classList.remove("active");
    }
    if (callsArray.length === 0) scheduleRenderTable();
}

widgetToggle.onchange = (e) => {
    chrome.storage.local.set({ showWidget: e.target.checked });
};

searchInput.oninput = (e) => {
    searchQuery = e.target.value.toLowerCase();
    scheduleRenderTable();
};

harBtn.onclick = () => {
    exportLogs();
};

function downloadText(filename, text, mime) {
    const blob = new Blob([text], { type: mime || 'application/json' });
    const url = URL.createObjectURL(blob);
    const downloadAnchor = document.createElement('a');
    downloadAnchor.href = url;
    downloadAnchor.download = filename;
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function toHarHeaders(obj) {
    return Object.entries(obj || {}).map(([name, value]) => ({ name, value: String(value) }));
}

function headerValue(obj, name) {
    const key = Object.keys(obj || {}).find(k => k.toLowerCase() === name);
    return key ? String(obj[key]) : '';
}

// Build a HAR 1.2 document from the captured calls (oldest first)
function buildHar(calls) {
    const entries = calls.slice().reverse().map(call => {
        let queryString = [];
        try {
            queryString = Array.from(new URL(call.url).searchParams.entries()).map(([name, value]) => ({ name, value }));
        } catch (e) {}
        const resBody = call.resBody == null ? '' : String(call.resBody);
        const latency = Number(call.latency) || 0;
        const started = call.timestamp ? new Date(call.timestamp) : new Date();
        const entry = {
            startedDateTime: started.toISOString(),
            time: latency,
            request: {
                method: call.method || 'GET',
                url: call.url || '',
                httpVersion: 'HTTP/1.1',
                cookies: [],
                headers: toHarHeaders(call.reqHeaders),
                queryString,
                headersSize: -1,
                bodySize: call.reqBody ? String(call.reqBody).length : 0
            },
            response: {
                status: Number(call.status) || 0,
                statusText: call.isMocked ? 'Mocked' : '',
                httpVersion: 'HTTP/1.1',
                cookies: [],
                headers: toHarHeaders(call.resHeaders),
                content: {
                    size: resBody.length,
                    mimeType: headerValue(call.resHeaders, 'content-type') || 'text/plain',
                    text: resBody
                },
                redirectURL: '',
                headersSize: -1,
                bodySize: resBody.length
            },
            cache: {},
            timings: { send: 0, wait: latency, receive: 0 },
            _resourceType: call.type || 'fetch',
            _mocked: !!call.isMocked
        };
        if (call.reqBody) {
            entry.request.postData = {
                mimeType: headerValue(call.reqHeaders, 'content-type') || 'text/plain',
                text: String(call.reqBody)
            };
        }
        return entry;
    });
    return {
        log: {
            version: '1.2',
            creator: { name: 'API Interceptor Pro', version: chrome.runtime.getManifest().version },
            pages: [],
            entries
        }
    };
}

function exportLogs() {
    const stamp = new Date().toISOString().replace(/[:.]/g, '-');
    downloadText(`api_monitor_${stamp}.har`, JSON.stringify(buildHar(callsArray), null, 2));
}

// --- Copy as cURL ---
function shellQuote(value) {
    return "'" + String(value).replace(/'/g, "'\\''") + "'";
}

function buildCurl(call) {
    const parts = ['curl', shellQuote(call.url)];
    if (call.method && call.method.toUpperCase() !== 'GET') {
        parts.push('-X', shellQuote(call.method.toUpperCase()));
    }
    Object.entries(call.reqHeaders || {}).forEach(([k, v]) => {
        parts.push('-H', shellQuote(`${k}: ${v}`));
    });
    if (call.reqBody && !/^\[(FormData|Object \/ Binary Body)\]$/.test(String(call.reqBody))) {
        parts.push('--data-raw', shellQuote(call.reqBody));
    }
    return parts.join(' ');
}

function copyText(text) {
    // navigator.clipboard is often blocked inside DevTools panels; use a textarea fallback
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    let ok = false;
    try {
        ok = document.execCommand('copy');
    } catch (e) {}
    ta.remove();
    return ok;
}

curlBtn.onclick = () => {
    const call = callsArray.find(c => c.id === selectedCallId);
    if (!call) return;
    const ok = copyText(buildCurl(call));
    const original = curlBtn.textContent;
    curlBtn.textContent = ok ? '✅ Copied' : '⚠️ Copy failed';
    setTimeout(() => { curlBtn.textContent = original; }, 1500);
};

// --- Replay Request snippet executor ---
replayBtn.onclick = () => {
    const call = callsArray.find(c => c.id === selectedCallId);
    if (!call) return;

    let headersObj = call.reqHeaders || {};
    let init = {
        method: call.method,
        headers: headersObj
    };
    if (call.reqBody && ['POST', 'PUT', 'PATCH', 'DELETE'].includes(call.method)) {
        init.body = call.reqBody;
    }

    const fetchSnippet = `
        fetch(${JSON.stringify(call.url)}, ${JSON.stringify(init)})
            .then(res => res.text().then(text => ({ status: res.status, text })))
            .then(data => console.log('%c[API Monitor Replayed]', 'color: #51cf66; font-weight: bold;', data))
            .catch(err => console.error('[API Monitor Replay Error]', err));
    `;

    chrome.devtools.inspectedWindow.eval(fetchSnippet, (result, isException) => {
        if (isException) {
            console.error("Replay exception:", isException);
        }
    });
};

function escapeHtml(value) {
    return String(value ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

// --- Table Rendering ---
let renderTableFrameId = null;
function scheduleRenderTable() {
    if (renderTableFrameId) return;
    renderTableFrameId = requestAnimationFrame(() => {
        renderTable();
        renderTableFrameId = null;
    });
}

function renderTable() {
    // Keep reference of current selected row DOM to re-highlight it
    tableBody.innerHTML = '';

    const filtered = callsArray.filter(call => {
        if (!matchesTypeFilter(call)) return false;
        return !searchQuery ||
            (call.url && call.url.toLowerCase().includes(searchQuery)) ||
            (call.method && call.method.toLowerCase().includes(searchQuery)) ||
            (call.gqlOp && call.gqlOp.toLowerCase().includes(searchQuery)) ||
            String(call.status).startsWith(searchQuery);
    });

    rowCount.textContent = callsArray.length
        ? (filtered.length === callsArray.length ? `${callsArray.length} requests` : `${filtered.length} of ${callsArray.length}`)
        : '';

    if (callsArray.length === 0) {
        tableBody.innerHTML = `
            <div class="empty-placeholder">
                <span>⚡</span>
                <div>${isPaused ? 'Capture is paused. Press Resume to record requests.' : 'Waiting for requests... Use the page or reload it (F5) to capture its API calls.'}</div>
            </div>`;
        return;
    }

    if (filtered.length === 0) {
        tableBody.innerHTML = `
            <div class="empty-placeholder">
                <span>🔍</span>
                <div>No requests match this filter.</div>
            </div>`;
        return;
    }

    filtered.forEach(call => {
        const row = document.createElement("div");
        row.className = `table-row ${selectedCallId === call.id ? 'selected' : ''}`;
        row.dataset.id = call.id;

        const isMock = !!call.isMocked;
        let statusClass = 'status-2xx';
        if (call.status === 0 || call.error) statusClass = 'status-error';
        else if (isMock) statusClass = 'status-mock';
        else if (call.status >= 400) statusClass = 'status-4xx';
        else if (call.status >= 300) statusClass = 'status-3xx';

        const statusDisplay = call.status === 0 ? 'FAIL' : call.status;
        const latencyVal = call.latency !== undefined ? `${call.latency}ms` : '';
        const reqType = call.type ? call.type.toUpperCase() : 'FETCH';

        row.innerHTML = `
            <div class="col method-col"><span class="badge badge-${escapeHtml(call.method)}">${escapeHtml(call.method)}</span></div>
            <div class="col status-col ${statusClass}">${escapeHtml(statusDisplay)}${isMock ? '<span class="mock-tag">MOCK</span>' : ''}</div>
            <div class="col url-col" title="${escapeHtml(call.url)}">${escapeHtml(call.url)}${call.gqlOp ? `<span class="gql-chip">${escapeHtml(call.gqlOp)}</span>` : ''}</div>
            <div class="col latency-col">${latencyVal}</div>
            <div class="col type-col">${reqType}</div>
        `;

        row.onclick = () => selectRow(row, call);

        tableBody.appendChild(row);
    });
}

function selectRow(row, call) {
    document.querySelectorAll(".table-row").forEach(r => r.classList.remove("selected"));
    row.classList.add("selected");
    selectedCallId = call.id;
    updateDetailsUI();
    prepopulateMockForm(call);
}

// Move the selection up/down in the visible list
function moveSelection(step) {
    const rows = Array.from(tableBody.querySelectorAll('.table-row'));
    if (!rows.length) return;
    let index = rows.findIndex(r => r.dataset.id === selectedCallId);
    index = index === -1 ? (step > 0 ? 0 : rows.length - 1) : Math.min(rows.length - 1, Math.max(0, index + step));
    const row = rows[index];
    const call = callsArray.find(c => c.id === row.dataset.id);
    if (!call) return;
    selectRow(row, call);
    row.scrollIntoView({ block: 'nearest' });
}

// "Mock this": fill the form from the selected request and open the Mock Rules tab
function mockSelected() {
    const call = callsArray.find(c => c.id === selectedCallId);
    if (!call) {
        toast('Select a request first.', true);
        return;
    }
    resetMockForm();
    prepopulateMockForm(call);
    switchTab('mocking');
    mockBody.focus();
}
mockThisBtn.onclick = mockSelected;

// --- Keyboard shortcuts ---
document.addEventListener('keydown', (e) => {
    const tag = (e.target.tagName || '').toLowerCase();
    const typing = tag === 'input' || tag === 'textarea' || tag === 'select';

    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter' && activeTab === 'mocking') {
        e.preventDefault();
        saveRuleBtn.click();
        return;
    }
    if (e.key === 'Escape') {
        if (e.target === searchInput && searchInput.value) {
            searchInput.value = '';
            searchQuery = '';
            scheduleRenderTable();
        }
        if (typing) e.target.blur();
        return;
    }
    if (typing || e.ctrlKey || e.metaKey || e.altKey) return;

    if (e.key === '/') {
        e.preventDefault();
        searchInput.focus();
        searchInput.select();
    } else if (e.key === 'ArrowDown' || e.key === 'j') {
        e.preventDefault();
        moveSelection(1);
    } else if (e.key === 'ArrowUp' || e.key === 'k') {
        e.preventDefault();
        moveSelection(-1);
    } else if (e.key === 'm' || e.key === 'M') {
        mockSelected();
    }
});

// JSON syntax helper
function syntaxHighlight(json) {
    if (typeof json !== 'string') {
        json = JSON.stringify(json, null, 2);
    }
    try {
        json = json.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
        return json.replace(/("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+-]?\d+)?)/g, function (match) {
            let cls = 'number';
            if (/^"/.test(match)) {
                if (/:$/.test(match)) {
                    cls = 'key';
                } else {
                    cls = 'string';
                }
            } else if (/true|false/.test(match)) {
                cls = 'boolean';
            } else if (/null/.test(match)) {
                cls = 'null';
            }
            return '<span class="' + cls + '">' + match + '</span>';
        });
    } catch (e) {
        return json;
    }
}

// --- Detail View Logic ---
function updateDetailsUI() {
    const call = callsArray.find(c => c.id === selectedCallId);
    if (!call) {
        // Hide details container, show empty placeholder
        headersViewContainer.style.display = 'none';
        headersEmpty.style.display = 'flex';

        payloadViewContainer.style.display = 'none';
        payloadEmpty.style.display = 'flex';

        responseViewContainer.style.display = 'none';
        responseEmpty.style.display = 'flex';
        return;
    }

    // Populate Headers Tab
    headersEmpty.style.display = 'none';
    headersViewContainer.style.display = 'block';

    detailsReqUrl.innerText = `${call.method} ${call.url}`;

    // General headers list
    generalHeadersList.innerHTML = `
        <div class="header-item">
            <div class="header-name">Request URL</div>
            <div class="header-value">${escapeHtml(call.url)}</div>
        </div>
        <div class="header-item">
            <div class="header-name">Request Method</div>
            <div class="header-value">${escapeHtml(call.method)}</div>
        </div>
        <div class="header-item">
            <div class="header-name">Status Code</div>
            <div class="header-value">${call.status || 'Failed'}</div>
        </div>
        <div class="header-item">
            <div class="header-name">Latency</div>
            <div class="header-value">${call.latency !== undefined ? call.latency + ' ms' : 'unknown'}</div>
        </div>
    `;

    // Response Headers
    responseHeadersList.innerHTML = '';
    const resHeaders = call.resHeaders || {};
    if (Object.keys(resHeaders).length === 0) {
        responseHeadersList.innerHTML = '<div style="color:var(--text-secondary); font-style:italic;">No response headers</div>';
    } else {
        Object.entries(resHeaders).forEach(([k, v]) => {
            const el = document.createElement("div");
            el.className = 'header-item';
            el.innerHTML = `<div class="header-name">${escapeHtml(k)}</div><div class="header-value">${escapeHtml(v)}</div>`;
            responseHeadersList.appendChild(el);
        });
    }

    // Request Headers
    requestHeadersList.innerHTML = '';
    const reqHeaders = call.reqHeaders || {};
    if (Object.keys(reqHeaders).length === 0) {
        requestHeadersList.innerHTML = '<div style="color:var(--text-secondary); font-style:italic;">No request headers</div>';
    } else {
        Object.entries(reqHeaders).forEach(([k, v]) => {
            const el = document.createElement("div");
            el.className = 'header-item';
            el.innerHTML = `<div class="header-name">${escapeHtml(k)}</div><div class="header-value">${escapeHtml(v)}</div>`;
            requestHeadersList.appendChild(el);
        });
    }

    // Populate Payload Tab
    if (call.reqBody) {
        payloadEmpty.style.display = 'none';
        payloadViewContainer.style.display = 'block';
        try {
            const parsed = JSON.parse(call.reqBody);
            payloadCodeView.innerHTML = syntaxHighlight(parsed);
        } catch(e) {
            payloadCodeView.innerText = call.reqBody;
        }
    } else {
        payloadViewContainer.style.display = 'none';
        payloadEmpty.style.display = 'flex';
        payloadEmpty.innerText = 'No request payload for this request type.';
    }

    // Populate Response Tab
    if (call.resBody !== undefined && call.resBody !== null) {
        responseEmpty.style.display = 'none';
        responseViewContainer.style.display = 'block';
        try {
            const parsed = JSON.parse(call.resBody);
            responseCodeView.innerHTML = syntaxHighlight(parsed);
        } catch(e) {
            responseCodeView.innerText = call.resBody;
        }
    } else {
        responseViewContainer.style.display = 'none';
        responseEmpty.style.display = 'flex';
        responseEmpty.innerText = 'No response payload recorded.';
    }
}

// Prepopulate the Mock form fields using the details of the selected request
function prepopulateMockForm(call) {
    // extract relative path or domain match
    let pattern = call.url;
    try {
        const urlObj = new URL(call.url);
        pattern = urlObj.pathname; // Default to path substring for easier pattern matching
    } catch(e) {}

    if (editingRuleId) return; // don't overwrite a rule that is being edited
    mockUrlPattern.value = pattern;
    mockMatchType.value = 'substring';
    mockHeaders.value = '';
    mockMethod.value = (call.method || 'ANY').toUpperCase();
    if (!mockMethod.value) mockMethod.value = 'ANY';
    mockStatus.value = call.status || 200;
    mockDelay.value = 0;
    mockJitter.value = 0;
    mockGql.value = call.gqlOp || '';
    mockSite.value = '';

    // Clean response body format for rule creator
    let bodyText = call.resBody || '';
    try {
        const parsed = JSON.parse(bodyText);
        bodyText = JSON.stringify(parsed, null, 2);
    } catch(e) {}
    mockBody.value = bodyText;
}

// --- Mocking Management ---
saveRuleBtn.onclick = () => {
    const pattern = mockUrlPattern.value.trim();
    if (!pattern) {
        toast("Enter a URL pattern to match, e.g. /api/users", true);
        mockUrlPattern.focus();
        return;
    }

    const matchType = mockMatchType.value;
    if (matchType === 'regex') {
        try {
            new RegExp(pattern);
        } catch (e) {
            toast("Invalid regular expression: " + e.message, true);
            return;
        }
    }

    let headers = null;
    const headersText = mockHeaders.value.trim();
    if (headersText) {
        try {
            headers = JSON.parse(headersText);
            if (!headers || typeof headers !== 'object' || Array.isArray(headers)) throw new Error('not an object');
        } catch (e) {
            toast('Response headers must be a JSON object, e.g. {"Content-Type": "application/json"}', true);
            return;
        }
    }

    const statusRaw = String(mockStatus.value).trim();
    const statusCode = statusRaw === '' ? 200 : Number(statusRaw);
    if (statusCode !== 0 && (!(statusCode >= 200) || statusCode > 599)) {
        toast("Status code must be 200-599, or 0 for a network failure.", true);
        return;
    }

    const ruleData = {
        urlPattern: pattern,
        method: mockMethod.value,
        statusCode,
        delay: Math.max(0, Number(mockDelay.value) || 0),
        jitter: Math.max(0, Number(mockJitter.value) || 0),
        graphqlOperation: mockGql.value.trim(),
        site: mockSite.value.trim(),
        responseBody: mockBody.value,
        headers,
        matchType
    };

    const existing = editingRuleId ? mockRules.find(r => r.id === editingRuleId) : null;
    if (existing) {
        Object.assign(existing, ruleData);
    } else {
        mockRules.push({ id: Math.random().toString(36).substring(2, 9), enabled: true, ...ruleData });
    }

    chrome.storage.local.set({ mockRules }, () => {
        toast(existing ? "Mock rule updated." : "Mock rule saved. Matching requests are now mocked.");
        resetMockForm();
        renderMockRules();
    });
};

function resetMockForm() {
    editingRuleId = null;
    mockUrlPattern.value = '';
    mockBody.value = '';
    mockHeaders.value = '';
    mockMatchType.value = 'substring';
    mockMethod.value = 'ANY';
    mockStatus.value = 200;
    mockDelay.value = 0;
    mockJitter.value = 0;
    mockGql.value = '';
    mockSite.value = '';
    mockTemplate.value = '';
    mockFormTitle.textContent = 'Create Mock Rule';
    saveRuleBtn.textContent = 'Save Mock Rule';
    cancelEditBtn.style.display = 'none';
}

cancelEditBtn.onclick = resetMockForm;

// --- Preset mock library ---
const JSON_HEADERS = { "Content-Type": "application/json" };
const MOCK_TEMPLATES = {
    'ok-json': { status: 200, body: { id: 42, name: "Ada Lovelace", email: "ada@example.com", role: "admin" } },
    'empty-list': { status: 200, body: [] },
    'created': { status: 201, body: { id: 1001, status: "created" }, headers: { ...JSON_HEADERS, "Location": "/api/items/1001" } },
    'no-content': { status: 204, body: "" },
    'bad-request': { status: 400, body: { error: "validation_failed", message: "Some fields are invalid.", fields: { email: "Must be a valid email address" } } },
    'unauthorized': { status: 401, body: { error: "unauthorized", message: "Your session has expired. Please sign in again." }, headers: { ...JSON_HEADERS, "WWW-Authenticate": "Bearer error=\"invalid_token\"" } },
    'forbidden': { status: 403, body: { error: "forbidden", message: "You don't have permission to do this." } },
    'not-found': { status: 404, body: { error: "not_found", message: "The requested resource was not found." } },
    'rate-limit': { status: 429, body: { error: "rate_limited", message: "Too many requests. Try again in 30 seconds." }, headers: { ...JSON_HEADERS, "Retry-After": "30" } },
    'server-error': { status: 500, body: { error: "internal_error", message: "Something went wrong on our side." } },
    'unavailable': { status: 503, body: { error: "service_unavailable", message: "Down for maintenance." }, delay: 1500, headers: { ...JSON_HEADERS, "Retry-After": "120" } },
    'slow': { keepBody: true, delay: 2000, jitter: 2000 },
    'network-error': { status: 0, body: "" },
    'graphql-error': { status: 200, body: { data: null, errors: [{ message: "Not authorised to access this field", path: ["viewer"], extensions: { code: "FORBIDDEN" } }] } }
};

mockTemplate.onchange = () => {
    const t = MOCK_TEMPLATES[mockTemplate.value];
    if (!t) return;
    if (!t.keepBody) {
        mockStatus.value = t.status;
        mockBody.value = typeof t.body === 'string' ? t.body : JSON.stringify(t.body, null, 2);
        mockHeaders.value = t.headers ? JSON.stringify(t.headers, null, 2) : '';
    }
    mockDelay.value = t.delay || 0;
    mockJitter.value = t.jitter || 0;
    if (!mockUrlPattern.value) mockUrlPattern.focus();
    toast(`Template applied: ${mockTemplate.options[mockTemplate.selectedIndex].text}`);
};

function startEditRule(rule) {
    editingRuleId = rule.id;
    mockUrlPattern.value = rule.urlPattern || '';
    mockMatchType.value = rule.matchType || 'substring';
    mockMethod.value = rule.method || 'ANY';
    mockStatus.value = rule.statusCode ?? 200;
    mockDelay.value = rule.delay || 0;
    mockJitter.value = rule.jitter || 0;
    mockGql.value = rule.graphqlOperation || '';
    mockSite.value = rule.site || '';
    mockFormTitle.textContent = 'Edit Mock Rule';
    switchTab('mocking');
    mockHeaders.value = rule.headers ? JSON.stringify(rule.headers, null, 2) : '';
    mockBody.value = rule.responseBody || '';
    saveRuleBtn.textContent = 'Update Mock Rule';
    cancelEditBtn.style.display = 'inline-block';
    mockUrlPattern.focus();
}

// --- Rules export / import ---
exportRulesBtn.onclick = () => {
    downloadText('api_interceptor_rules.json', JSON.stringify({ version: 1, mockRules }, null, 2));
};

importRulesBtn.onclick = () => importRulesFile.click();

importRulesFile.onchange = () => {
    const file = importRulesFile.files && importRulesFile.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
        try {
            const data = JSON.parse(reader.result);
            const incoming = Array.isArray(data) ? data : data.mockRules;
            if (!Array.isArray(incoming)) throw new Error('No mockRules array found');
            const valid = incoming
                .filter(r => r && typeof r.urlPattern === 'string' && r.urlPattern.trim())
                .map(r => ({
                    id: Math.random().toString(36).substring(2, 9),
                    urlPattern: r.urlPattern,
                    method: typeof r.method === 'string' ? r.method.toUpperCase() : 'ANY',
                    statusCode: Number(r.statusCode) === 0 && r.statusCode !== '' && r.statusCode != null ? 0 : (Number(r.statusCode) || 200),
                    delay: Math.max(0, Number(r.delay) || 0),
                    jitter: Math.max(0, Number(r.jitter) || 0),
                    graphqlOperation: typeof r.graphqlOperation === 'string' ? r.graphqlOperation : '',
                    site: typeof r.site === 'string' ? r.site : '',
                    responseBody: typeof r.responseBody === 'string' ? r.responseBody : JSON.stringify(r.responseBody ?? ''),
                    headers: r.headers && typeof r.headers === 'object' && !Array.isArray(r.headers) ? r.headers : null,
                    matchType: ['substring', 'exact', 'regex'].includes(r.matchType) ? r.matchType : 'substring',
                    enabled: r.enabled !== false
                }));
            mockRules = mockRules.concat(valid);
            chrome.storage.local.set({ mockRules }, () => {
                toast(`Imported ${valid.length} mock rule(s).`);
                renderMockRules();
            });
        } catch (e) {
            toast('Could not import rules: ' + e.message, true);
        }
        importRulesFile.value = '';
    };
    reader.readAsText(file);
};

// --- Import a HAR file as mock rules (API calls only: fetch/XHR or JSON/text responses) ---
importHarBtn.onclick = () => importHarFile.click();

function harEntriesToRules(har) {
    const entries = har && har.log && Array.isArray(har.log.entries) ? har.log.entries : null;
    if (!entries) throw new Error('This is not a HAR file (no log.entries).');
    const byKey = new Map();
    entries.forEach(entry => {
        const req = entry.request || {};
        const res = entry.response || {};
        const content = res.content || {};
        const mime = String(content.mimeType || '').toLowerCase();
        const kind = entry._resourceType;
        const isApi = kind ? (kind === 'fetch' || kind === 'xhr') : /json|xml|text\/plain/.test(mime);
        if (!isApi || !req.url || !/^https?:/i.test(req.url)) return;
        const status = Number(res.status) || 0;
        if (status < 200 || status > 599) return;
        let body = content.text || '';
        if (content.encoding === 'base64') {
            try { body = decodeURIComponent(escape(atob(body))); } catch (e) { return; }
        }
        const method = String(req.method || 'GET').toUpperCase();
        const headers = {};
        if (content.mimeType) headers['Content-Type'] = content.mimeType;
        // Later entries for the same call win (newest response)
        byKey.set(method + ' ' + req.url, {
            id: Math.random().toString(36).substring(2, 9),
            enabled: true,
            urlPattern: req.url,
            matchType: 'exact',
            method: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'].includes(method) ? method : 'ANY',
            statusCode: status,
            delay: 0,
            jitter: 0,
            graphqlOperation: '',
            site: '',
            headers: Object.keys(headers).length ? headers : null,
            responseBody: body
        });
    });
    return Array.from(byKey.values());
}

importHarFile.onchange = () => {
    const file = importHarFile.files && importHarFile.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
        try {
            const rules = harEntriesToRules(JSON.parse(reader.result));
            if (!rules.length) {
                toast('No fetch/XHR API calls found in this HAR file.', true);
            } else {
                // Replace older rules for the same method + URL so re-importing doesn't duplicate
                const keys = new Set(rules.map(r => r.method + ' ' + r.urlPattern));
                mockRules = mockRules.filter(r => !(r.matchType === 'exact' && keys.has(r.method + ' ' + r.urlPattern))).concat(rules);
                chrome.storage.local.set({ mockRules }, () => {
                    if (chrome.runtime.lastError) {
                        toast('Could not save: ' + chrome.runtime.lastError.message, true);
                        return;
                    }
                    toast(`Imported ${rules.length} mock rule(s) from ${file.name}.`);
                    renderMockRules();
                });
            }
        } catch (e) {
            toast('Could not import HAR: ' + e.message, true);
        }
        importHarFile.value = '';
    };
    reader.readAsText(file);
};

function ruleHits(ruleId) {
    let n = 0;
    for (const c of callsArray) if (c.ruleId === ruleId) n++;
    return n;
}

function renderMockRules() {
    mockRulesList.innerHTML = '';

    const enabledCount = mockRules.filter(r => r.enabled).length;
    rulesSummary.textContent = mockRules.length ? `${enabledCount} of ${mockRules.length} on` : '';

    if (mockRules.length === 0) {
        mockRulesList.innerHTML = '<div style="color:var(--text-secondary); line-height:1.6;">No mock rules yet. Select a request in the list and press <b>Mock this</b>, pick a template above, or import a HAR file.</div>';
        return;
    }

    mockRules.forEach(rule => {
        const card = document.createElement("div");
        card.className = "rule-card" + (rule.enabled ? "" : " disabled");
        const hits = ruleHits(rule.id);
        const status = Number(rule.statusCode) === 0 ? 'Network error' : `Status: ${escapeHtml(rule.statusCode)}`;
        const delay = Number(rule.jitter) ? `Delay: ${escapeHtml(rule.delay || 0)}–${(Number(rule.delay) || 0) + Number(rule.jitter)}ms` : `Delay: ${escapeHtml(rule.delay || 0)}ms`;

        card.innerHTML = `
            <div class="rule-details">
                <div class="rule-pattern">${escapeHtml(rule.method)} ${escapeHtml(rule.urlPattern)}</div>
                <div class="rule-meta">
                    <span>${escapeHtml(({ substring: 'Contains', exact: 'Exact', regex: 'Regex' })[rule.matchType] || 'Contains')}</span>
                    <span>${status}</span>
                    <span>${delay}</span>
                    ${rule.graphqlOperation ? `<span>GraphQL: ${escapeHtml(rule.graphqlOperation)}</span>` : ''}
                    <span>${rule.site ? 'Sites: ' + escapeHtml(rule.site) : 'All sites'}</span>
                    ${hits ? `<span class="rule-hits">${hits} hit${hits === 1 ? '' : 's'}</span>` : ''}
                </div>
            </div>
            <div class="rule-actions">
                <input type="checkbox" class="rule-enable-toggle" title="Enable / disable" data-id="${escapeHtml(rule.id)}" ${rule.enabled ? 'checked' : ''}>
                <button class="secondary-btn edit-btn" data-id="${escapeHtml(rule.id)}">Edit</button>
                <button class="danger-btn" data-id="${escapeHtml(rule.id)}">Delete</button>
            </div>
        `;

        // Toggle state hook
        card.querySelector(".rule-enable-toggle").onchange = (e) => {
            const ruleId = e.target.dataset.id;
            const targetRule = mockRules.find(r => r.id === ruleId);
            if (targetRule) {
                targetRule.enabled = e.target.checked;
                chrome.storage.local.set({ mockRules });
                card.classList.toggle('disabled', !targetRule.enabled);
            }
        };

        card.querySelector(".edit-btn").onclick = () => startEditRule(rule);

        // Delete hook
        card.querySelector(".danger-btn").onclick = (e) => {
            const ruleId = e.target.dataset.id;
            if (editingRuleId === ruleId) resetMockForm();
            mockRules = mockRules.filter(r => r.id !== ruleId);
            chrome.storage.local.set({ mockRules });
        };

        mockRulesList.appendChild(card);
    });
}
