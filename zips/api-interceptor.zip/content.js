// inject.js is registered as a MAIN-world content script in manifest.json,
// so it runs before page scripts. It asks for config once it is ready.
window.addEventListener('API_MONITOR_REQUEST_CONFIG', () => {
    if (configLoaded) updatePageContextConfig();
});

// Local config cache
let extConfig = {
    isPaused: false,
    mockRules: [],
    showWidget: false
};
let configLoaded = false;

// Queue to hold logs before UI initializes
let pendingLogs = [];
let widgetUI = null;

// Initialize configurations and UI
chrome.storage.local.get(['isPaused', 'mockRules', 'showWidget', 'apiCalls'], (res) => {
    extConfig.isPaused = !!res.isPaused;
    extConfig.mockRules = res.mockRules || [];
    extConfig.showWidget = res.showWidget === true; // opt-in overlay
    configLoaded = true;

    // Pass initial configurations to page-context (inject.js)
    updatePageContextConfig();

    if (extConfig.showWidget) {
        initFloatingWidget(res.apiCalls || []);
    }
});

// Update the configuration inside inject.js
function updatePageContextConfig() {
    window.dispatchEvent(new CustomEvent('UPDATE_API_MONITOR_CONFIG', {
        detail: {
            isPaused: extConfig.isPaused,
            mockRules: extConfig.mockRules
        }
    }));
}

// Watch for storage changes in real-time
chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === 'local') {
        let configUpdated = false;

        if (changes.isPaused) {
            extConfig.isPaused = !!changes.isPaused.newValue;
            configUpdated = true;
        }
        if (changes.mockRules) {
            extConfig.mockRules = changes.mockRules.newValue || [];
            configUpdated = true;
        }
        if (changes.showWidget) {
            extConfig.showWidget = changes.showWidget.newValue === true;
            if (extConfig.showWidget) {
                chrome.storage.local.get('apiCalls', (res) => {
                    initFloatingWidget(res.apiCalls || []);
                });
            } else {
                destroyFloatingWidget();
            }
        }
        if (changes.apiCalls && changes.apiCalls.newValue) {
            // If cleared, sync widget UI
            if (changes.apiCalls.newValue.length === 0 && widgetUI) {
                widgetUI.clearLogs();
            }
        }

        if (configUpdated) {
            updatePageContextConfig();
        }
    }
});

// Listen to intercepted network events from inject.js
window.addEventListener('API_DATA_INTERCEPTED', (event) => {
    const detail = event.detail;
    if (!detail || typeof detail !== 'object') return;
    
    // Save request log to background storage (and push to DevTools)
    try {
        chrome.runtime.sendMessage({ action: 'newCall', data: detail }, () => {
            if (chrome.runtime.lastError) {
                // Ignore context invalidation/connection errors
            }
        });
    } catch (e) {
        // Silent catch
    }

    // Render in widget if enabled
    if (extConfig.showWidget) {
        if (widgetUI) {
            widgetUI.addLog(detail);
        } else {
            pendingLogs.push(detail);
        }
    }
});

function escapeHtml(value) {
    return String(value ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

// --- Floating Widget Implementation (using Shadow DOM for isolation) ---
function initFloatingWidget(initialCalls = []) {
    const existing = document.getElementById("api-monitor-widget-root");
    if (existing) {
        existing.remove();
    }

    const host = document.createElement("div");
    host.id = "api-monitor-widget-root";
    Object.assign(host.style, {
        position: "fixed",
        top: "20px",
        right: "20px",
        zIndex: "2147483647",
        resize: "both",
        overflow: "hidden",
        minWidth: "280px",
        minHeight: "320px",
        maxWidth: "90vw",
        maxHeight: "90vh",
        width: "360px",
        height: "540px",
        borderRadius: "16px",
        boxShadow: "0 12px 40px rgba(0, 0, 0, 0.4)"
    });

    if (!document.body) {
        document.addEventListener('DOMContentLoaded', () => {
            if (extConfig.showWidget && !widgetUI) initFloatingWidget(initialCalls);
        }, { once: true });
        return;
    }

    document.body.appendChild(host);
    const shadow = host.attachShadow({ mode: 'open' });

    // Stylesheet rules for Shadow DOM
    const style = document.createElement("style");
    style.textContent = `
        * {
            box-sizing: border-box;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        }
        :host {
            display: block;
        }
        .widget-panel {
            width: 100%;
            height: 100%;
            background: rgba(18, 18, 22, 0.88);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            border: 1px solid rgba(255, 255, 255, 0.12);
            border-radius: 16px;
            display: flex;
            flex-direction: column;
            color: #f1f3f5;
            font-size: 13px;
            overflow: hidden;
        }
        .header {
            background: linear-gradient(135deg, rgba(33, 37, 41, 0.95) 0%, rgba(18, 18, 22, 0.95) 100%);
            padding: 12px 14px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
            cursor: move;
            user-select: none;
            flex-shrink: 0;
        }
        .header-title {
            display: flex;
            align-items: center;
            gap: 8px;
            font-weight: 700;
            font-size: 11px;
            letter-spacing: 0.8px;
            color: #4dabf7;
            text-transform: uppercase;
        }
        .header-dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background-color: #51cf66;
            box-shadow: 0 0 8px #51cf66;
            animation: pulse 2s infinite;
        }
        @keyframes pulse {
            0% { opacity: 0.4; }
            50% { opacity: 1; }
            100% { opacity: 0.4; }
        }
        .header-actions {
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .icon-btn {
            background: none;
            border: none;
            color: #adb5bd;
            cursor: pointer;
            padding: 4px;
            border-radius: 4px;
            font-size: 14px;
            width: 24px;
            height: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s;
        }
        .icon-btn:hover {
            background: rgba(255, 255, 255, 0.1);
            color: #fff;
        }
        .controls {
            padding: 8px 12px;
            background: rgba(0, 0, 0, 0.15);
            border-bottom: 1px solid rgba(255, 255, 255, 0.06);
            display: flex;
            flex-direction: column;
            gap: 8px;
            flex-shrink: 0;
        }
        .search-bar {
            width: 100%;
            background: rgba(255, 255, 255, 0.06);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            padding: 6px 10px;
            color: #fff;
            font-size: 12px;
            outline: none;
            transition: all 0.2s;
        }
        .search-bar:focus {
            border-color: #4dabf7;
            background: rgba(255, 255, 255, 0.1);
        }
        .filters {
            display: flex;
            gap: 6px;
            overflow-x: auto;
            scrollbar-width: none;
        }
        .filters::-webkit-scrollbar {
            display: none;
        }
        .chip {
            padding: 3px 8px;
            border-radius: 20px;
            font-size: 11px;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.05);
            color: #adb5bd;
            cursor: pointer;
            white-space: nowrap;
            transition: all 0.2s;
        }
        .chip:hover {
            background: rgba(255, 255, 255, 0.1);
            color: #fff;
        }
        .chip.active {
            background: rgba(77, 171, 247, 0.15);
            border-color: rgba(77, 171, 247, 0.4);
            color: #4dabf7;
            font-weight: 600;
        }
        .logs-list {
            flex: 1;
            overflow-y: auto;
            padding: 10px;
            display: flex;
            flex-direction: column;
            gap: 8px;
        }
        .logs-list::-webkit-scrollbar {
            width: 6px;
        }
        .logs-list::-webkit-scrollbar-track {
            background: transparent;
        }
        .logs-list::-webkit-scrollbar-thumb {
            background: rgba(255, 255, 255, 0.15);
            border-radius: 4px;
        }
        .empty-msg {
            color: #868e96;
            text-align: center;
            margin-top: 120px;
            font-size: 12px;
        }
        .log-item {
            background: rgba(255, 255, 255, 0.02);
            border: 1px solid rgba(255, 255, 255, 0.05);
            border-radius: 8px;
            overflow: hidden;
            transition: border-color 0.2s, background 0.2s;
            flex-shrink: 0;
        }
        .log-item:hover {
            background: rgba(255, 255, 255, 0.04);
            border-color: rgba(255, 255, 255, 0.1);
        }
        .log-summary {
            padding: 8px 10px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 6px;
            user-select: none;
        }
        .method-badge {
            font-weight: 800;
            font-size: 9px;
            padding: 1.5px 5px;
            border-radius: 3px;
            min-width: 44px;
            text-align: center;
            flex-shrink: 0;
        }
        .method-GET { background: rgba(77, 171, 247, 0.15); color: #4dabf7; }
        .method-POST { background: rgba(81, 207, 102, 0.15); color: #51cf66; }
        .method-PUT { background: rgba(252, 196, 25, 0.15); color: #fcc419; }
        .method-DELETE { background: rgba(255, 107, 107, 0.15); color: #ff6b6b; }
        .method-PATCH { background: rgba(174, 62, 244, 0.15); color: #ae3ef4; }
        .method-OTHER { background: rgba(134, 142, 150, 0.15); color: #868e96; }

        .status-badge {
            font-weight: 700;
            font-size: 9px;
            padding: 1.5px 5px;
            border-radius: 3px;
            flex-shrink: 0;
        }
        .status-2xx { background: rgba(81, 207, 102, 0.15); color: #51cf66; }
        .status-3xx { background: rgba(252, 196, 25, 0.15); color: #fcc419; }
        .status-4xx, .status-5xx { background: rgba(255, 107, 107, 0.15); color: #ff6b6b; }
        .status-error { background: rgba(255, 107, 107, 0.25); color: #ff6b6b; }
        .status-mocked { background: rgba(157, 78, 221, 0.2); color: #b5179e; border: 1px solid rgba(181, 23, 158, 0.3); }

        .url-text {
            flex: 1;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            font-family: monospace;
            font-size: 11px;
            color: #e9ecef;
        }
        .latency-text {
            font-size: 10px;
            color: #868e96;
            flex-shrink: 0;
            text-align: right;
            min-width: 40px;
        }
        .log-details {
            border-top: 1px solid rgba(255, 255, 255, 0.05);
            background: rgba(0, 0, 0, 0.25);
            padding: 10px;
            display: none;
        }
        .log-item.expanded .log-details {
            display: block;
        }
        .detail-row {
            margin-bottom: 8px;
        }
        .detail-title {
            font-weight: bold;
            font-size: 10px;
            color: #adb5bd;
            text-transform: uppercase;
            margin-bottom: 2px;
            letter-spacing: 0.5px;
        }
        .detail-content {
            font-family: monospace;
            font-size: 10px;
            background: rgba(0, 0, 0, 0.4);
            padding: 6px;
            border-radius: 4px;
            white-space: pre-wrap;
            word-break: break-all;
        }
        
        /* Highlight colors */
        .key { color: #f25c54; font-weight: bold; }
        .string { color: #57cc99; }
        .number { color: #3a86ff; }
        .boolean { color: #ffbe0b; }
        .null { color: #8338ec; }

        /* Minimized show widget button */
        .show-trigger {
            display: none;
            position: fixed;
            z-index: 2147483647;
            background: linear-gradient(135deg, #1c7ed6 0%, #1098ad 100%);
            color: #fff;
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 50px;
            padding: 10px 18px;
            font-weight: bold;
            font-size: 11px;
            letter-spacing: 0.5px;
            cursor: pointer;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.3);
            user-select: none;
            align-items: center;
            gap: 6px;
            transition: transform 0.2s;
        }
        .show-trigger:hover {
            transform: scale(1.03);
        }
    `;

    shadow.appendChild(style);

    // Widget UI Structure
    const panel = document.createElement("div");
    panel.className = "widget-panel";
    panel.innerHTML = `
        <div class="header" id="widget-header">
            <div class="header-title">
                <div class="header-dot"></div>
                API Monitor
            </div>
            <div class="header-actions">
                <button class="icon-btn" id="clear-btn" title="Clear Logs">🗑️</button>
                <button class="icon-btn" id="minimize-btn" title="Minimize Panel">➖</button>
            </div>
        </div>
        <div class="controls">
            <input type="text" class="search-bar" id="search-input" placeholder="Filter by URL or body...">
            <div class="filters" id="filter-chips">
                <div class="chip active" data-filter="all">All</div>
                <div class="chip" data-filter="fetch">Fetch</div>
                <div class="chip" data-filter="xhr">XHR</div>
                <div class="chip" data-filter="mocks">Mocks</div>
                <div class="chip" data-filter="errors">Errors</div>
            </div>
        </div>
        <div class="logs-list" id="logs-list">
            <div class="empty-msg" id="empty-message">Waiting for API calls...</div>
        </div>
    `;

    // Show Trigger (when minimized)
    const showBtn = document.createElement("button");
    showBtn.className = "show-trigger";
    showBtn.id = "widget-show-trigger";
    showBtn.innerHTML = `<span>⚡</span> API Monitor`;
    Object.assign(showBtn.style, {
        position: "fixed",
        top: "20px",
        right: "20px"
    });

    shadow.appendChild(panel);
    shadow.appendChild(showBtn);

    // Grab references
    const logsList = shadow.getElementById("logs-list");
    const emptyMsg = shadow.getElementById("empty-message");
    const searchInput = shadow.getElementById("search-input");
    const filterChips = shadow.getElementById("filter-chips");
    const clearBtn = shadow.getElementById("clear-btn");
    const minimizeBtn = shadow.getElementById("minimize-btn");
    const header = shadow.getElementById("widget-header");

    let logsArray = [];
    let activeFilter = 'all';
    let searchQuery = '';
    let expandedLogId = null;

    // Render cached logs for this site only (storage is newest-first, so add oldest first)
    const siteCalls = initialCalls.filter(log => log && log.pageOrigin === location.origin);
    if (siteCalls.length > 0) {
        siteCalls.slice().reverse().forEach(log => {
            addLogToData(log);
        });
        renderLogs();
    }

    // Load any pending logs that arrived during initialization
    if (pendingLogs.length > 0) {
        pendingLogs.forEach(log => {
            addLogToData(log);
        });
        pendingLogs = [];
        renderLogs();
    }

    // --- Dragging Logic ---
    let isDragging = false;
    let dragStartX, dragStartY;
    let hostStartX, hostStartY;

    header.addEventListener('mousedown', (e) => {
        isDragging = true;
        dragStartX = e.clientX;
        dragStartY = e.clientY;
        const rect = host.getBoundingClientRect();
        hostStartX = rect.left;
        hostStartY = rect.top;
        document.addEventListener('mousemove', onMouseMove);
        document.addEventListener('mouseup', onMouseUp);
        e.preventDefault();
    });

    function onMouseMove(e) {
        if (!isDragging) return;
        const dx = e.clientX - dragStartX;
        const dy = e.clientY - dragStartY;
        host.style.left = `${hostStartX + dx}px`;
        host.style.top = `${hostStartY + dy}px`;
        host.style.right = 'auto';
    }

    function onMouseUp() {
        isDragging = false;
        document.removeEventListener('mousemove', onMouseMove);
        document.removeEventListener('mouseup', onMouseUp);
    }

    // Also support dragging the minimized button
    let isBtnDragging = false;
    let btnDragStartX, btnDragStartY;
    let btnStartX, btnStartY;

    showBtn.addEventListener('mousedown', (e) => {
        isBtnDragging = false;
        btnDragStartX = e.clientX;
        btnDragStartY = e.clientY;
        const rect = host.getBoundingClientRect();
        btnStartX = rect.left;
        btnStartY = rect.top;
        document.addEventListener('mousemove', onBtnMouseMove);
        document.addEventListener('mouseup', onBtnMouseUp);
        e.preventDefault();
    });

    function onBtnMouseMove(e) {
        isBtnDragging = true;
        const dx = e.clientX - btnDragStartX;
        const dy = e.clientY - btnDragStartY;
        host.style.left = `${btnStartX + dx}px`;
        host.style.top = `${btnStartY + dy}px`;
        host.style.right = 'auto';
    }

    function onBtnMouseUp(e) {
        document.removeEventListener('mousemove', onBtnMouseMove);
        document.removeEventListener('mouseup', onBtnMouseUp);
        if (!isBtnDragging) {
            // Restore host expanded dimensions and styles
            Object.assign(host.style, {
                width: host.dataset.expandedWidth || "360px",
                height: host.dataset.expandedHeight || "540px",
                minWidth: "280px",
                minHeight: "320px",
                borderRadius: "16px",
                boxShadow: "0 12px 40px rgba(0, 0, 0, 0.4)",
                overflow: "hidden"
            });
            panel.style.display = 'flex';
            showBtn.style.display = 'none';
        }
    }

    // --- Minimizing / Restoring ---
    minimizeBtn.onclick = () => {
        panel.style.display = 'none';
        showBtn.style.display = 'flex';
        
        // Save expanded dimensions
        host.dataset.expandedWidth = host.style.width;
        host.dataset.expandedHeight = host.style.height;

        // Shrink host wrapper to match the minimized showBtn size dynamically
        Object.assign(host.style, {
            width: 'auto',
            height: 'auto',
            minWidth: '0',
            minHeight: '0',
            boxShadow: 'none',
            background: 'transparent',
            borderRadius: '0',
            overflow: 'visible'
        });
    };

    // --- Search & Filters ---
    searchInput.addEventListener('input', (e) => {
        searchQuery = e.target.value.toLowerCase();
        scheduleRender();
    });

    filterChips.addEventListener('click', (e) => {
        if (e.target.classList.contains('chip')) {
            filterChips.querySelectorAll('.chip').forEach(c => c.classList.remove('active'));
            e.target.classList.add('active');
            activeFilter = e.target.dataset.filter;
            scheduleRender();
        }
    });

    // --- Clear Logs ---
    clearBtn.onclick = () => {
        try {
            chrome.runtime.sendMessage({ action: 'clearCalls' }, () => {
                if (chrome.runtime.lastError) {
                    // Ignore context invalidation/connection errors
                }
            });
        } catch (e) {
            // Silent catch
        }
    };

    // JSON format helper with styling
    function syntaxHighlight(json) {
        if (typeof json !== 'string') {
            json = JSON.stringify(json, null, 2);
        }
        try {
            json = json.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
            return json.replace(/("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+-]?\d+)?)/g, function (match) {
                let cls = 'number';
                if (/^"/.test(match)) {
                    if (/:$/.test(match)) {
                        cls = 'key';
                    } else {
                        cls = 'string';
                    }
                } else if (/true|false/.test(match)) {
                    cls = 'boolean';
                } else if (/null/.test(match)) {
                    cls = 'null';
                }
                return '<span class="' + cls + '">' + match + '</span>';
            });
        } catch (e) {
            return json;
        }
    }

    function addLogToData(log) {
        // Enforce max log limit inside widget memory (sync with background)
        logsArray.unshift(log);
        if (logsArray.length > 150) {
            logsArray.pop();
        }
    }

    let renderFrameId = null;
    function scheduleRender() {
        if (renderFrameId) return;
        renderFrameId = requestAnimationFrame(() => {
            renderLogs();
            renderFrameId = null;
        });
    }

    function populateDetails(detailsEl, log) {
        // Clean headers for readability
        const reqHeadersStr = Object.keys(log.reqHeaders || {}).length > 0 
            ? JSON.stringify(log.reqHeaders, null, 2) 
            : 'No headers';
        const resHeadersStr = Object.keys(log.resHeaders || {}).length > 0 
            ? JSON.stringify(log.resHeaders, null, 2) 
            : 'No headers';

        // Clean bodies defensively (ensuring string casting to prevent loop crashes)
        let parsedResBody = String(log.resBody || '');
        try {
            // Try format JSON
            const parsed = JSON.parse(parsedResBody);
            parsedResBody = syntaxHighlight(parsed);
        } catch(e) {
            // Keep raw and escape HTML characters properly
            parsedResBody = parsedResBody.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
        }

        let parsedReqBody = String(log.reqBody || '');
        if (parsedReqBody && log.reqBody) {
            try {
                const parsed = JSON.parse(parsedReqBody);
                parsedReqBody = syntaxHighlight(parsed);
            } catch(e) {
                parsedReqBody = parsedReqBody.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
            }
        } else {
            parsedReqBody = 'No request body';
        }

        detailsEl.innerHTML = `
            <div class="detail-row">
                <div class="detail-title">Request Headers</div>
                <div class="detail-content">${escapeHtml(reqHeadersStr)}</div>
            </div>
            ${log.reqBody ? `
            <div class="detail-row">
                <div class="detail-title">Request Body</div>
                <pre class="detail-content">${parsedReqBody}</pre>
            </div>` : ''}
            <div class="detail-row">
                <div class="detail-title">Response Headers</div>
                <div class="detail-content">${escapeHtml(resHeadersStr)}</div>
            </div>
            <div class="detail-row">
                <div class="detail-title">Response Body</div>
                <pre class="detail-content">${parsedResBody}</pre>
            </div>
        `;
    }

    function renderLogs() {
        // Clear DOM list (except empty message template)
        logsList.innerHTML = '';

        const filtered = logsArray.filter(log => {
            if (!log) return false;
            // Apply Search filter (robust scan on URL, Method, Status, Request body, and Response body)
            const logUrl = String(log.url || '').toLowerCase();
            const logMethod = String(log.method || '').toLowerCase();
            const logStatus = String(log.status || '');
            const logReqBody = String(log.reqBody || '').toLowerCase();
            const logResBody = String(log.resBody || '').toLowerCase();
            
            const matchSearch = !searchQuery || 
                logUrl.includes(searchQuery) || 
                logMethod.includes(searchQuery) ||
                logStatus.includes(searchQuery) ||
                logReqBody.includes(searchQuery) ||
                logResBody.includes(searchQuery);
            
            if (!matchSearch) return false;

            // Apply Tab filter
            if (activeFilter === 'all') return true;
            if (activeFilter === 'fetch') return log.type === 'fetch';
            if (activeFilter === 'xhr') return log.type === 'xhr';
            if (activeFilter === 'mocks') return !!log.isMocked;
            if (activeFilter === 'errors') return !!log.error || log.status >= 400 || log.status === 0;

            return true;
        });

        if (filtered.length === 0) {
            logsList.innerHTML = `<div class="empty-msg">No requests found</div>`;
            return;
        }

        filtered.forEach(log => {
            const item = document.createElement("div");
            item.className = "log-item";
            const isExpanded = log.id === expandedLogId;
            if (isExpanded) {
                item.classList.add("expanded");
            }
            
            const methodClass = `method-${log.method || 'OTHER'}`;
            let statusClass = 'status-2xx';
            if (log.status === 0 || log.error) statusClass = 'status-error';
            else if (log.isMocked) statusClass = 'status-mocked';
            else if (log.status >= 400) statusClass = 'status-4xx';
            else if (log.status >= 300) statusClass = 'status-3xx';

            const statusText = log.isMocked ? 'MOCK' : (log.status === 0 ? 'FAIL' : log.status);
            const latencyVal = log.latency !== undefined ? `${log.latency}ms` : '';

            item.innerHTML = `
                <div class="log-summary">
                    <span class="method-badge ${escapeHtml(methodClass)}">${escapeHtml(log.method)}</span>
                    <span class="status-badge ${statusClass}">${escapeHtml(statusText)}</span>
                    <span class="url-text" title="${escapeHtml(log.url)}">${escapeHtml(log.url)}</span>
                    <span class="latency-text">${latencyVal}</span>
                </div>
                <div class="log-details"></div>
            `;

            const detailsEl = item.querySelector(".log-details");
            if (isExpanded) {
                populateDetails(detailsEl, log);
            }

            // Expand / Collapse details logic
            const summary = item.querySelector(".log-summary");
            summary.onclick = () => {
                const alreadyExpanded = item.classList.contains("expanded");
                // Collapse any other open items first to save screen real estate
                logsList.querySelectorAll(".log-item.expanded").forEach(el => {
                    if (el !== item) {
                        el.classList.remove("expanded");
                        el.querySelector(".log-details").innerHTML = "";
                    }
                });
                
                if (!alreadyExpanded) {
                    item.classList.add("expanded");
                    expandedLogId = log.id;
                    populateDetails(detailsEl, log);
                } else {
                    item.classList.remove("expanded");
                    expandedLogId = null;
                    detailsEl.innerHTML = "";
                }
            };

            logsList.appendChild(item);
        });
    }

    // Exposed widget API
    widgetUI = {
        addLog: (log) => {
            addLogToData(log);
            scheduleRender();
        },
        clearLogs: () => {
            logsArray = [];
            scheduleRender();
        }
    };
}

function destroyFloatingWidget() {
    const host = document.getElementById("api-monitor-widget-root");
    if (host) {
        host.remove();
    }
    widgetUI = null;
}
