// Isolated-world content script. inject.js (MAIN world) wraps fetch/XHR; this script owns
// the mock rules and talks to inject.js through a private MessagePort that is handed over
// with a synchronous event at document_start, before any page script exists. Page scripts
// therefore can't read the rules, fake captured calls or change anything: rules are matched
// here and only the single resolved response for a matching request is sent to the page.
const HANDSHAKE_EVENT = 'api-interceptor-pro:port';
const HELLO_EVENT = 'api-interceptor-pro:hello';
const MAX_CALL_BODY = 200000;

// Local config cache
let extConfig = {
    isPaused: false,
    mockRules: [],
    showWidget: false
};
let configLoaded = false;
let resolveConfigLoaded;
const configLoadedPromise = new Promise(resolve => { resolveConfigLoaded = resolve; });

// Queue to hold logs before UI initializes
let pendingLogs = [];
let widgetUI = null;
let widgetHost = null;

// --- Private channel to inject.js ---
let pagePort = null;

function offerPort() {
    if (pagePort) return true;
    const channel = new MessageChannel();
    const event = new MessageEvent(HANDSHAKE_EVENT, { ports: [channel.port2], cancelable: true });
    const accepted = !window.dispatchEvent(event); // inject.js calls preventDefault() when it takes the port
    if (!accepted) {
        channel.port1.close();
        return false;
    }
    pagePort = channel.port1;
    pagePort.onmessage = onPageMessage;
    if (configLoaded) sendConfigToPage();
    return true;
}

function onHello() {
    window.removeEventListener(HELLO_EVENT, onHello, true);
    offerPort();
}

if (!offerPort()) {
    // inject.js has not run yet: it asks for the port as soon as it starts (still before any
    // page script). Stop listening right after the start-up phase.
    window.addEventListener(HELLO_EVENT, onHello, true);
    setTimeout(() => window.removeEventListener(HELLO_EVENT, onHello, true), 0);
}

function extensionAlive() {
    try {
        return !!(chrome.runtime && chrome.runtime.id);
    } catch (e) {
        return false;
    }
}

// After the extension is reloaded or updated this copy of the script is orphaned:
// stop mocking/capturing on this page instead of using stale rules.
function shutDownChannel() {
    if (!pagePort) return;
    try { pagePort.postMessage({ t: 'config', paused: true, active: false }); } catch (e) {}
    pagePort.close();
    pagePort = null;
}

function sendConfigToPage() {
    if (!pagePort) return;
    pagePort.postMessage({
        t: 'config',
        paused: extConfig.isPaused,
        active: !extConfig.isPaused && extConfig.mockRules.some(ruleApplies)
    });
}

async function onPageMessage(event) {
    const msg = event.data;
    if (!msg || typeof msg !== 'object') return;
    if (!extensionAlive()) {
        if (msg.t === 'match' && pagePort) pagePort.postMessage({ t: 'match', id: msg.id, rule: null });
        shutDownChannel();
        return;
    }
    if (msg.t === 'match') {
        if (!configLoaded) await configLoadedPromise;
        const rule = extConfig.isPaused ? null : findMatchingRule(msg);
        if (pagePort) pagePort.postMessage({ t: 'match', id: msg.id, rule: rule ? resolveRule(rule) : null });
    } else if (msg.t === 'call') {
        const call = sanitizeCall(msg.call);
        if (call) handleCapturedCall(call);
    }
}

// --- Mock rule matching (isolated world only) ---
// Rules can be limited to some sites: "localhost, staging.example.com" (subdomains included)
function siteMatches(rule) {
    const list = String(rule.site || '').split(/[\s,]+/).map(s => s.trim().toLowerCase()).filter(Boolean);
    if (list.length === 0) return true;
    const host = location.hostname.toLowerCase();
    return list.some(s => {
        const site = s.replace(/^[a-z]+:\/\//, '').replace(/\/.*$/, '').replace(/^\*\./, '').replace(/:\d+$/, '');
        return site && (host === site || host.endsWith('.' + site));
    });
}

function ruleApplies(rule) {
    return !!(rule && rule.enabled && typeof rule.urlPattern === 'string' && rule.urlPattern && siteMatches(rule));
}

const regexCache = new Map();
function compileRegex(pattern) {
    if (!regexCache.has(pattern)) {
        let rx = null;
        try { rx = new RegExp(pattern); } catch (e) {}
        if (regexCache.size > 200) regexCache.clear();
        regexCache.set(pattern, rx);
    }
    return regexCache.get(pattern);
}

function findMatchingRule(req) {
    const url = String(req.url || '');
    const absUrl = String(req.absUrl || url);
    const method = String(req.method || 'GET').toUpperCase();
    const gqlOp = String(req.gqlOp || '');
    const body = typeof req.body === 'string' ? req.body : '';
    return extConfig.mockRules.find(rule => {
        if (!ruleApplies(rule)) return false;
        if (rule.method && rule.method !== 'ANY' && String(rule.method).toUpperCase() !== method) return false;
        if (rule.graphqlOperation) {
            const ops = String(rule.graphqlOperation).split(/[\s,]+/).filter(Boolean);
            if (ops.length && !ops.includes(gqlOp)) return false;
        }
        if (rule.bodyContains && !body.includes(String(rule.bodyContains))) return false;
        if (rule.matchType === 'regex') {
            const rx = compileRegex(rule.urlPattern);
            return !!rx && (rx.test(url) || rx.test(absUrl));
        }
        if (rule.matchType === 'exact') {
            return url === rule.urlPattern || absUrl === rule.urlPattern;
        }
        return url.includes(rule.urlPattern) || absUrl.includes(rule.urlPattern);
    }) || null;
}

const STATUS_TEXT = {
    200: 'OK', 201: 'Created', 202: 'Accepted', 204: 'No Content', 206: 'Partial Content',
    301: 'Moved Permanently', 302: 'Found', 304: 'Not Modified',
    400: 'Bad Request', 401: 'Unauthorized', 402: 'Payment Required', 403: 'Forbidden', 404: 'Not Found',
    405: 'Method Not Allowed', 408: 'Request Timeout', 409: 'Conflict', 410: 'Gone', 413: 'Payload Too Large',
    415: 'Unsupported Media Type', 422: 'Unprocessable Entity', 429: 'Too Many Requests',
    500: 'Internal Server Error', 501: 'Not Implemented', 502: 'Bad Gateway', 503: 'Service Unavailable', 504: 'Gateway Timeout'
};

// Mocked calls carry a one-time token; the rule id is looked up here, so hit counters can't be faked
const ruleTokens = new Map();
function issueToken(ruleId) {
    const token = Math.random().toString(36).slice(2) + Date.now().toString(36);
    ruleTokens.set(token, ruleId);
    if (ruleTokens.size > 500) ruleTokens.delete(ruleTokens.keys().next().value);
    return token;
}

function cleanRuleHeaders(headers) {
    if (!headers || typeof headers !== 'object' || Array.isArray(headers)) return null;
    const out = {};
    Object.keys(headers).forEach(key => {
        if (/^[!#$%&'*+.^_`|~0-9A-Za-z-]+$/.test(key)) out[key] = String(headers[key]).replace(/[\r\n]/g, ' ');
    });
    return Object.keys(out).length ? out : null;
}

// Turn a rule into the one response inject.js needs (nothing else of the rule leaves this world)
function resolveRule(rule) {
    const base = Math.max(0, Number(rule.delay) || 0);
    const jitter = Math.max(0, Number(rule.jitter) || 0);
    const delay = Math.min(600000, Math.round(base + (jitter ? Math.random() * jitter : 0)));
    const token = issueToken(rule.id);
    if (rule.mode === 'patch') {
        return { token, mode: 'patch', delay, patch: String(rule.responseBody || '') };
    }
    const rawStatus = rule.statusCode;
    if (rawStatus !== undefined && rawStatus !== null && rawStatus !== '' && Number(rawStatus) === 0) {
        return { token, mode: 'error', delay };
    }
    let status = Number(rawStatus) || 200;
    if (status < 200 || status > 599) status = 200;
    const nullBody = [204, 205, 304].includes(status);
    return {
        token,
        mode: 'mock',
        delay,
        status,
        statusText: STATUS_TEXT[status] || '',
        headers: cleanRuleHeaders(rule.headers) || { 'Content-Type': 'application/json' },
        body: nullBody ? null : String(rule.responseBody || '')
    };
}

// --- Captured calls: everything coming from the page world is untrusted ---
function clip(value, max) {
    if (value === undefined || value === null) return '';
    const s = typeof value === 'string' ? value : String(value);
    return s.length > max ? s.slice(0, max) + '... [Truncated]' : s;
}

function cleanHeaderMap(headers) {
    const out = {};
    if (!headers || typeof headers !== 'object' || Array.isArray(headers)) return out;
    Object.keys(headers).slice(0, 200).forEach(key => {
        out[clip(key, 256)] = clip(headers[key], 8192);
    });
    return out;
}

function sanitizeCall(raw) {
    if (!raw || typeof raw !== 'object') return null;
    const status = Math.round(Number(raw.status));
    const call = {
        id: clip(raw.id, 32).replace(/[^A-Za-z0-9_-]/g, '') || Math.random().toString(36).slice(2, 11),
        type: raw.type === 'xhr' ? 'xhr' : 'fetch',
        url: clip(raw.url, 8192),
        method: clip(raw.method, 24).toUpperCase().replace(/[^A-Z0-9_-]/g, '') || 'GET',
        status: status >= 0 && status <= 999 ? status : 0,
        reqHeaders: cleanHeaderMap(raw.reqHeaders),
        resHeaders: cleanHeaderMap(raw.resHeaders),
        reqBody: raw.reqBody === null || raw.reqBody === undefined ? null : clip(raw.reqBody, MAX_CALL_BODY),
        resBody: clip(raw.resBody, MAX_CALL_BODY),
        latency: Math.max(0, Math.round(Number(raw.latency) || 0)),
        isMocked: raw.isMocked === true,
        error: raw.error === true,
        gqlOp: clip(raw.gqlOp, 128),
        pageOrigin: location.origin,
        timestamp: Date.now(),
        time: new Date().toLocaleTimeString()
    };
    if (raw.patched === true) call.patched = true;
    if (call.isMocked && typeof raw.token === 'string' && ruleTokens.has(raw.token)) {
        call.ruleId = ruleTokens.get(raw.token);
        ruleTokens.delete(raw.token);
    }
    return call;
}

function handleCapturedCall(call) {
    // Save request log to background storage (and push to DevTools)
    try {
        chrome.runtime.sendMessage({ action: 'newCall', data: call }, () => {
            void chrome.runtime.lastError; // service worker restarting / context invalidated
        });
    } catch (e) {
        shutDownChannel();
        return;
    }

    // Render in widget if enabled
    if (extConfig.showWidget) {
        if (widgetUI) {
            widgetUI.addLog(call);
        } else {
            pendingLogs.push(call);
            if (pendingLogs.length > 150) pendingLogs.shift();
        }
    }
}

// Initialize configurations and UI
// Calls captured earlier in this tab (kept by the background in session storage)
function loadTabCallsThenShowWidget() {
    try {
        chrome.runtime.sendMessage({ action: 'getTabCalls' }, (response) => {
            void chrome.runtime.lastError;
            if (extConfig.showWidget && !widgetUI) initFloatingWidget((response && response.calls) || []);
        });
    } catch (e) {
        if (extConfig.showWidget && !widgetUI) initFloatingWidget([]);
    }
}

chrome.storage.local.get(['isPaused', 'mockRules', 'showWidget'], (res) => {
    extConfig.isPaused = !!res.isPaused;
    extConfig.mockRules = Array.isArray(res.mockRules) ? res.mockRules : [];
    extConfig.showWidget = res.showWidget === true; // opt-in overlay
    configLoaded = true;
    resolveConfigLoaded();

    sendConfigToPage();

    if (extConfig.showWidget) {
        loadTabCallsThenShowWidget();
    }
});

// Watch for storage changes in real-time
chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== 'local') return;
    let configUpdated = false;

    if (changes.isPaused) {
        extConfig.isPaused = !!changes.isPaused.newValue;
        configUpdated = true;
    }
    if (changes.mockRules) {
        extConfig.mockRules = Array.isArray(changes.mockRules.newValue) ? changes.mockRules.newValue : [];
        configUpdated = true;
    }
    if (changes.showWidget) {
        extConfig.showWidget = changes.showWidget.newValue === true;
        if (extConfig.showWidget) {
            loadTabCallsThenShowWidget();
        } else {
            destroyFloatingWidget();
        }
    }

    if (configUpdated) sendConfigToPage();
});

// The background tells us when the captured calls of this tab (or all tabs) are cleared
chrome.runtime.onMessage.addListener((message, sender) => {
    if (sender.id !== chrome.runtime.id || !message) return;
    if (message.action === 'callsCleared') {
        pendingLogs = [];
        if (widgetUI) widgetUI.clearLogs();
    }
});

function escapeHtml(value) {
    return String(value ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

// --- Floating Widget Implementation (using Shadow DOM for isolation) ---
function initFloatingWidget(initialCalls = []) {
    destroyFloatingWidget();

    // A custom element, so page CSS written for divs doesn't reach the host
    const host = document.createElement("api-interceptor-widget");
    Object.assign(host.style, {
        display: "block",
        position: "fixed",
        top: "20px",
        right: "20px",
        zIndex: "2147483647",
        resize: "both",
        overflow: "hidden",
        minWidth: "280px",
        minHeight: "320px",
        maxWidth: "90vw",
        maxHeight: "90vh",
        width: "360px",
        height: "540px",
        borderRadius: "16px",
        boxShadow: "0 12px 40px rgba(0, 0, 0, 0.4)"
    });

    if (!document.body) {
        document.addEventListener('DOMContentLoaded', () => {
            if (extConfig.showWidget && !widgetUI) initFloatingWidget(initialCalls);
        }, { once: true });
        return;
    }

    document.body.appendChild(host);
    widgetHost = host;
    // Closed shadow root: captured URLs, headers (tokens) and bodies shown in the widget
    // are not reachable from page scripts (host.shadowRoot is null for them).
    const shadow = host.attachShadow({ mode: 'closed' });
    // Keep keystrokes typed into the widget away from the page's own key handlers / shortcuts
    ['keydown', 'keyup', 'keypress', 'input', 'beforeinput', 'paste', 'copy', 'cut'].forEach(type => {
        shadow.addEventListener(type, (e) => e.stopPropagation());
    });

    // Stylesheet rules for Shadow DOM (a constructed sheet, so a strict page CSP can't block it)
    const css = `
        * {
            box-sizing: border-box;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        }
        :host {
            display: block;
        }
        .widget-panel {
            width: 100%;
            height: 100%;
            background: rgba(18, 18, 22, 0.88);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            border: 1px solid rgba(255, 255, 255, 0.12);
            border-radius: 16px;
            display: flex;
            flex-direction: column;
            color: #f1f3f5;
            font-size: 13px;
            overflow: hidden;
        }
        .header {
            background: linear-gradient(135deg, rgba(33, 37, 41, 0.95) 0%, rgba(18, 18, 22, 0.95) 100%);
            padding: 12px 14px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
            cursor: move;
            user-select: none;
            flex-shrink: 0;
        }
        .header-title {
            display: flex;
            align-items: center;
            gap: 8px;
            font-weight: 700;
            font-size: 11px;
            letter-spacing: 0.8px;
            color: #4dabf7;
            text-transform: uppercase;
        }
        .header-dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background-color: #51cf66;
            box-shadow: 0 0 8px #51cf66;
            animation: pulse 2s infinite;
        }
        @keyframes pulse {
            0% { opacity: 0.4; }
            50% { opacity: 1; }
            100% { opacity: 0.4; }
        }
        .header-actions {
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .icon-btn {
            background: none;
            border: none;
            color: #adb5bd;
            cursor: pointer;
            padding: 4px;
            border-radius: 4px;
            font-size: 14px;
            width: 24px;
            height: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s;
        }
        .icon-btn:hover {
            background: rgba(255, 255, 255, 0.1);
            color: #fff;
        }
        .controls {
            padding: 8px 12px;
            background: rgba(0, 0, 0, 0.15);
            border-bottom: 1px solid rgba(255, 255, 255, 0.06);
            display: flex;
            flex-direction: column;
            gap: 8px;
            flex-shrink: 0;
        }
        .search-bar {
            width: 100%;
            background: rgba(255, 255, 255, 0.06);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            padding: 6px 10px;
            color: #fff;
            font-size: 12px;
            outline: none;
            transition: all 0.2s;
        }
        .search-bar:focus {
            border-color: #4dabf7;
            background: rgba(255, 255, 255, 0.1);
        }
        .filters {
            display: flex;
            gap: 6px;
            overflow-x: auto;
            scrollbar-width: none;
        }
        .filters::-webkit-scrollbar {
            display: none;
        }
        .chip {
            padding: 3px 8px;
            border-radius: 20px;
            font-size: 11px;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.05);
            color: #adb5bd;
            cursor: pointer;
            white-space: nowrap;
            transition: all 0.2s;
        }
        .chip { font: inherit; font-size: 11px; }
        .chip:focus-visible, .icon-btn:focus-visible, .log-summary:focus-visible, .show-trigger:focus-visible {
            outline: 2px solid #4dabf7;
            outline-offset: 1px;
        }
        .chip:hover {
            background: rgba(255, 255, 255, 0.1);
            color: #fff;
        }
        .chip.active {
            background: rgba(77, 171, 247, 0.15);
            border-color: rgba(77, 171, 247, 0.4);
            color: #4dabf7;
            font-weight: 600;
        }
        .logs-list {
            flex: 1;
            overflow-y: auto;
            padding: 10px;
            display: flex;
            flex-direction: column;
            gap: 8px;
        }
        .logs-list::-webkit-scrollbar {
            width: 6px;
        }
        .logs-list::-webkit-scrollbar-track {
            background: transparent;
        }
        .logs-list::-webkit-scrollbar-thumb {
            background: rgba(255, 255, 255, 0.15);
            border-radius: 4px;
        }
        .empty-msg {
            color: #868e96;
            text-align: center;
            margin-top: 120px;
            font-size: 12px;
        }
        .log-item {
            background: rgba(255, 255, 255, 0.02);
            border: 1px solid rgba(255, 255, 255, 0.05);
            border-radius: 8px;
            overflow: hidden;
            transition: border-color 0.2s, background 0.2s;
            flex-shrink: 0;
        }
        .log-item:hover {
            background: rgba(255, 255, 255, 0.04);
            border-color: rgba(255, 255, 255, 0.1);
        }
        .log-summary {
            padding: 8px 10px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 6px;
            user-select: none;
        }
        .method-badge {
            font-weight: 800;
            font-size: 9px;
            padding: 1.5px 5px;
            border-radius: 3px;
            min-width: 44px;
            text-align: center;
            flex-shrink: 0;
        }
        .method-GET { background: rgba(77, 171, 247, 0.15); color: #4dabf7; }
        .method-POST { background: rgba(81, 207, 102, 0.15); color: #51cf66; }
        .method-PUT { background: rgba(252, 196, 25, 0.15); color: #fcc419; }
        .method-DELETE { background: rgba(255, 107, 107, 0.15); color: #ff6b6b; }
        .method-PATCH { background: rgba(174, 62, 244, 0.15); color: #ae3ef4; }
        .method-OTHER { background: rgba(134, 142, 150, 0.15); color: #868e96; }

        .status-badge {
            font-weight: 700;
            font-size: 9px;
            padding: 1.5px 5px;
            border-radius: 3px;
            flex-shrink: 0;
        }
        .status-2xx { background: rgba(81, 207, 102, 0.15); color: #51cf66; }
        .status-3xx { background: rgba(252, 196, 25, 0.15); color: #fcc419; }
        .status-4xx, .status-5xx { background: rgba(255, 107, 107, 0.15); color: #ff6b6b; }
        .status-error { background: rgba(255, 107, 107, 0.25); color: #ff6b6b; }
        .status-mocked { background: rgba(157, 78, 221, 0.2); color: #e599f7; border: 1px solid rgba(218, 119, 242, 0.35); }

        .url-text {
            flex: 1;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            font-family: monospace;
            font-size: 11px;
            color: #e9ecef;
        }
        .latency-text {
            font-size: 10px;
            color: #868e96;
            flex-shrink: 0;
            text-align: right;
            min-width: 40px;
        }
        .log-details {
            border-top: 1px solid rgba(255, 255, 255, 0.05);
            background: rgba(0, 0, 0, 0.25);
            padding: 10px;
            display: none;
        }
        .log-item.expanded .log-details {
            display: block;
        }
        .detail-row {
            margin-bottom: 8px;
        }
        .detail-title {
            font-weight: bold;
            font-size: 10px;
            color: #adb5bd;
            text-transform: uppercase;
            margin-bottom: 2px;
            letter-spacing: 0.5px;
        }
        .detail-content {
            font-family: monospace;
            font-size: 10px;
            background: rgba(0, 0, 0, 0.4);
            padding: 6px;
            border-radius: 4px;
            white-space: pre-wrap;
            word-break: break-all;
        }
        
        /* Highlight colors */
        .key { color: #f25c54; font-weight: bold; }
        .string { color: #57cc99; }
        .number { color: #3a86ff; }
        .boolean { color: #ffbe0b; }
        .null { color: #8338ec; }

        /* Minimized show widget button */
        .show-trigger {
            display: none;
            position: relative;
            white-space: nowrap;
            background: linear-gradient(135deg, #1c7ed6 0%, #1098ad 100%);
            color: #fff;
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 50px;
            padding: 10px 18px;
            font-weight: bold;
            font-size: 11px;
            letter-spacing: 0.5px;
            cursor: pointer;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.3);
            user-select: none;
            align-items: center;
            gap: 6px;
            transition: transform 0.2s;
        }
        .show-trigger:hover {
            transform: scale(1.03);
        }
    `;

    try {
        const sheet = new CSSStyleSheet();
        sheet.replaceSync(css);
        shadow.adoptedStyleSheets = [sheet];
    } catch (e) {
        const style = document.createElement("style");
        style.textContent = css;
        shadow.appendChild(style);
    }

    // Widget UI Structure
    const panel = document.createElement("div");
    panel.className = "widget-panel";
    panel.innerHTML = `
        <div class="header" id="widget-header">
            <div class="header-title">
                <div class="header-dot"></div>
                API Monitor
            </div>
            <div class="header-actions">
                <button class="icon-btn" id="clear-btn" title="Clear this tab's logs" aria-label="Clear this tab's logs">🗑️</button>
                <button class="icon-btn" id="minimize-btn" title="Minimize panel" aria-label="Minimize panel">➖</button>
            </div>
        </div>
        <div class="controls">
            <input type="text" class="search-bar" id="search-input" placeholder="Filter by URL or body..." aria-label="Filter requests">
            <div class="filters" id="filter-chips">
                <button type="button" class="chip active" data-filter="all">All</button>
                <button type="button" class="chip" data-filter="fetch">Fetch</button>
                <button type="button" class="chip" data-filter="xhr">XHR</button>
                <button type="button" class="chip" data-filter="mocks">Mocks</button>
                <button type="button" class="chip" data-filter="errors">Errors</button>
            </div>
        </div>
        <div class="logs-list" id="logs-list">
            <div class="empty-msg" id="empty-message">Waiting for API calls...</div>
        </div>
    `;

    // Show Trigger (when minimized)
    const showBtn = document.createElement("button");
    showBtn.className = "show-trigger";
    showBtn.id = "widget-show-trigger";
    showBtn.setAttribute('aria-label', 'Show API Monitor widget');
    showBtn.innerHTML = `<span>⚡</span> API Monitor`;

    shadow.appendChild(panel);
    shadow.appendChild(showBtn);

    // Grab references
    const logsList = shadow.getElementById("logs-list");
    const emptyMsg = shadow.getElementById("empty-message");
    const searchInput = shadow.getElementById("search-input");
    const filterChips = shadow.getElementById("filter-chips");
    const clearBtn = shadow.getElementById("clear-btn");
    const minimizeBtn = shadow.getElementById("minimize-btn");
    const header = shadow.getElementById("widget-header");

    let logsArray = [];
    let activeFilter = 'all';
    let searchQuery = '';
    let expandedLogId = null;

    // Render cached logs for this site only (storage is newest-first, so add oldest first)
    const siteCalls = initialCalls.filter(log => log && log.pageOrigin === location.origin);
    if (siteCalls.length > 0) {
        siteCalls.slice().reverse().forEach(log => {
            addLogToData(log);
        });
        renderLogs();
    }

    // Load any pending logs that arrived during initialization
    if (pendingLogs.length > 0) {
        pendingLogs.forEach(log => {
            addLogToData(log);
        });
        pendingLogs = [];
        renderLogs();
    }

    // --- Dragging Logic ---
    let isDragging = false;
    let dragStartX, dragStartY;
    let hostStartX, hostStartY;

    header.addEventListener('mousedown', (e) => {
        isDragging = true;
        dragStartX = e.clientX;
        dragStartY = e.clientY;
        const rect = host.getBoundingClientRect();
        hostStartX = rect.left;
        hostStartY = rect.top;
        document.addEventListener('mousemove', onMouseMove);
        document.addEventListener('mouseup', onMouseUp);
        e.preventDefault();
    });

    function onMouseMove(e) {
        if (!isDragging) return;
        const dx = e.clientX - dragStartX;
        const dy = e.clientY - dragStartY;
        host.style.left = `${hostStartX + dx}px`;
        host.style.top = `${hostStartY + dy}px`;
        host.style.right = 'auto';
    }

    function onMouseUp() {
        isDragging = false;
        document.removeEventListener('mousemove', onMouseMove);
        document.removeEventListener('mouseup', onMouseUp);
    }

    // Also support dragging the minimized button
    let isBtnDragging = false;
    let btnDragStartX, btnDragStartY;
    let btnStartX, btnStartY;

    showBtn.addEventListener('mousedown', (e) => {
        isBtnDragging = false;
        btnDragStartX = e.clientX;
        btnDragStartY = e.clientY;
        const rect = host.getBoundingClientRect();
        btnStartX = rect.left;
        btnStartY = rect.top;
        document.addEventListener('mousemove', onBtnMouseMove);
        document.addEventListener('mouseup', onBtnMouseUp);
        e.preventDefault();
    });

    function onBtnMouseMove(e) {
        const dx = e.clientX - btnDragStartX;
        const dy = e.clientY - btnDragStartY;
        if (!isBtnDragging && Math.abs(dx) + Math.abs(dy) < 4) return; // a click, not a drag
        isBtnDragging = true;
        host.style.left = `${btnStartX + dx}px`;
        host.style.top = `${btnStartY + dy}px`;
        host.style.right = 'auto';
    }

    function onBtnMouseUp(e) {
        document.removeEventListener('mousemove', onBtnMouseMove);
        document.removeEventListener('mouseup', onBtnMouseUp);
        if (!isBtnDragging) restoreWidget();
    }

    let expandedWidth = "360px";
    let expandedHeight = "540px";
    function restoreWidget() {
        Object.assign(host.style, {
            width: expandedWidth,
            height: expandedHeight,
            minWidth: "280px",
            minHeight: "320px",
            borderRadius: "16px",
            boxShadow: "0 12px 40px rgba(0, 0, 0, 0.4)",
            overflow: "hidden",
            resize: "both"
        });
        panel.style.display = 'flex';
        showBtn.style.display = 'none';
        minimizeBtn.focus();
    }
    showBtn.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            restoreWidget();
        }
    });

    // --- Minimizing / Restoring ---
    minimizeBtn.onclick = () => {
        panel.style.display = 'none';
        showBtn.style.display = 'flex';
        
        // Save expanded dimensions
        expandedWidth = host.style.width || expandedWidth;
        expandedHeight = host.style.height || expandedHeight;

        // Shrink host wrapper to match the minimized showBtn size dynamically
        Object.assign(host.style, {
            width: 'auto',
            height: 'auto',
            minWidth: '0',
            minHeight: '0',
            boxShadow: 'none',
            background: 'transparent',
            borderRadius: '0',
            overflow: 'visible',
            resize: 'none'
        });
        showBtn.focus();
    };

    // --- Search & Filters ---
    searchInput.addEventListener('input', (e) => {
        searchQuery = e.target.value.toLowerCase();
        scheduleRender();
    });

    filterChips.addEventListener('click', (e) => {
        if (e.target.classList.contains('chip')) {
            filterChips.querySelectorAll('.chip').forEach(c => c.classList.remove('active'));
            e.target.classList.add('active');
            activeFilter = e.target.dataset.filter;
            scheduleRender();
        }
    });

    // --- Clear Logs ---
    clearBtn.onclick = () => {
        logsArray = [];
        scheduleRender();
        try {
            // Clears the calls of this tab only (the background knows which tab asked)
            chrome.runtime.sendMessage({ action: 'clearCalls', scope: 'tab' }, () => {
                if (chrome.runtime.lastError) {
                    // Ignore context invalidation/connection errors
                }
            });
        } catch (e) {
            // Silent catch
        }
    };

    // JSON format helper with styling
    function syntaxHighlight(json) {
        if (typeof json !== 'string') {
            json = JSON.stringify(json, null, 2);
        }
        try {
            json = json.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
            return json.replace(/("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+-]?\d+)?)/g, function (match) {
                let cls = 'number';
                if (/^"/.test(match)) {
                    if (/:$/.test(match)) {
                        cls = 'key';
                    } else {
                        cls = 'string';
                    }
                } else if (/true|false/.test(match)) {
                    cls = 'boolean';
                } else if (/null/.test(match)) {
                    cls = 'null';
                }
                return '<span class="' + cls + '">' + match + '</span>';
            });
        } catch (e) {
            return json;
        }
    }

    function addLogToData(log) {
        // Enforce max log limit inside widget memory (sync with background)
        logsArray.unshift(log);
        if (logsArray.length > 150) {
            logsArray.pop();
        }
    }

    let renderFrameId = null;
    function scheduleRender() {
        if (renderFrameId) return;
        renderFrameId = requestAnimationFrame(() => {
            renderLogs();
            renderFrameId = null;
        });
    }

    function populateDetails(detailsEl, log) {
        // Clean headers for readability
        const reqHeadersStr = Object.keys(log.reqHeaders || {}).length > 0 
            ? JSON.stringify(log.reqHeaders, null, 2) 
            : 'No headers';
        const resHeadersStr = Object.keys(log.resHeaders || {}).length > 0 
            ? JSON.stringify(log.resHeaders, null, 2) 
            : 'No headers';

        // Clean bodies defensively (ensuring string casting to prevent loop crashes)
        let parsedResBody = String(log.resBody || '');
        try {
            // Try format JSON
            const parsed = JSON.parse(parsedResBody);
            parsedResBody = syntaxHighlight(parsed);
        } catch(e) {
            // Keep raw and escape HTML characters properly
            parsedResBody = parsedResBody.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
        }

        let parsedReqBody = String(log.reqBody || '');
        if (parsedReqBody && log.reqBody) {
            try {
                const parsed = JSON.parse(parsedReqBody);
                parsedReqBody = syntaxHighlight(parsed);
            } catch(e) {
                parsedReqBody = parsedReqBody.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
            }
        } else {
            parsedReqBody = 'No request body';
        }

        detailsEl.innerHTML = `
            <div class="detail-row">
                <div class="detail-title">Request Headers</div>
                <div class="detail-content">${escapeHtml(reqHeadersStr)}</div>
            </div>
            ${log.reqBody ? `
            <div class="detail-row">
                <div class="detail-title">Request Body</div>
                <pre class="detail-content">${parsedReqBody}</pre>
            </div>` : ''}
            <div class="detail-row">
                <div class="detail-title">Response Headers</div>
                <div class="detail-content">${escapeHtml(resHeadersStr)}</div>
            </div>
            <div class="detail-row">
                <div class="detail-title">Response Body</div>
                <pre class="detail-content">${parsedResBody}</pre>
            </div>
        `;
    }

    function renderLogs() {
        // Clear DOM list (except empty message template)
        logsList.innerHTML = '';

        const filtered = logsArray.filter(log => {
            if (!log) return false;
            // Apply Search filter (robust scan on URL, Method, Status, Request body, and Response body)
            const logUrl = String(log.url || '').toLowerCase();
            const logMethod = String(log.method || '').toLowerCase();
            const logStatus = String(log.status || '');
            const logReqBody = String(log.reqBody || '').toLowerCase();
            const logResBody = String(log.resBody || '').toLowerCase();
            
            const matchSearch = !searchQuery || 
                logUrl.includes(searchQuery) || 
                logMethod.includes(searchQuery) ||
                logStatus.includes(searchQuery) ||
                logReqBody.includes(searchQuery) ||
                logResBody.includes(searchQuery);
            
            if (!matchSearch) return false;

            // Apply Tab filter
            if (activeFilter === 'all') return true;
            if (activeFilter === 'fetch') return log.type === 'fetch';
            if (activeFilter === 'xhr') return log.type === 'xhr';
            if (activeFilter === 'mocks') return !!log.isMocked;
            if (activeFilter === 'errors') return !!log.error || log.status >= 400 || log.status === 0;

            return true;
        });

        if (filtered.length === 0) {
            logsList.innerHTML = `<div class="empty-msg">No requests found</div>`;
            return;
        }

        filtered.forEach(log => {
            const item = document.createElement("div");
            item.className = "log-item";
            const isExpanded = log.id === expandedLogId;
            if (isExpanded) {
                item.classList.add("expanded");
            }
            
            const methodClass = ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'].includes(log.method) ? `method-${log.method}` : 'method-OTHER';
            let statusClass = 'status-2xx';
            if (log.status === 0 || log.error) statusClass = 'status-error';
            else if (log.isMocked) statusClass = 'status-mocked';
            else if (log.status >= 400) statusClass = 'status-4xx';
            else if (log.status >= 300) statusClass = 'status-3xx';

            const statusText = log.isMocked ? 'MOCK' : (log.status === 0 ? 'FAIL' : log.status);
            const latencyVal = log.latency !== undefined ? `${escapeHtml(log.latency)}ms` : '';

            item.innerHTML = `
                <div class="log-summary" role="button" tabindex="0" aria-expanded="${isExpanded}">
                    <span class="method-badge ${escapeHtml(methodClass)}">${escapeHtml(log.method)}</span>
                    <span class="status-badge ${statusClass}">${escapeHtml(statusText)}</span>
                    <span class="url-text" title="${escapeHtml(log.url)}">${escapeHtml(log.url)}</span>
                    <span class="latency-text">${latencyVal}</span>
                </div>
                <div class="log-details"></div>
            `;

            const detailsEl = item.querySelector(".log-details");
            if (isExpanded) {
                populateDetails(detailsEl, log);
            }

            // Expand / Collapse details logic
            const summary = item.querySelector(".log-summary");
            summary.onkeydown = (e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    summary.click();
                }
            };
            summary.onclick = () => {
                const alreadyExpanded = item.classList.contains("expanded");
                // Collapse any other open items first to save screen real estate
                logsList.querySelectorAll(".log-item.expanded").forEach(el => {
                    if (el !== item) {
                        el.classList.remove("expanded");
                        el.querySelector(".log-details").innerHTML = "";
                    }
                });
                
                logsList.querySelectorAll(".log-summary").forEach(el => el.setAttribute('aria-expanded', 'false'));
                if (!alreadyExpanded) {
                    summary.setAttribute('aria-expanded', 'true');
                    item.classList.add("expanded");
                    expandedLogId = log.id;
                    populateDetails(detailsEl, log);
                } else {
                    item.classList.remove("expanded");
                    expandedLogId = null;
                    detailsEl.innerHTML = "";
                }
            };

            logsList.appendChild(item);
        });
    }

    // Exposed widget API
    widgetUI = {
        addLog: (log) => {
            addLogToData(log);
            scheduleRender();
        },
        clearLogs: () => {
            logsArray = [];
            scheduleRender();
        }
    };
}

function destroyFloatingWidget() {
    if (widgetHost) {
        widgetHost.remove();
        widgetHost = null;
    }
    widgetUI = null;
}
