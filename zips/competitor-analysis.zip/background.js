// Import IndexedDB database logic
importScripts('db.js');

// Allow the sidepanel to be opened when the extension icon is clicked
chrome.runtime.onInstalled.addListener(() => {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true })
    .catch((error) => console.error('Error setting panel behavior:', error));
});

// Listener for content scripts and sidepanel UI messages
// Broadcast-only events (meant for the side panel) that the service worker should ignore
const UI_EVENTS = new Set([
  'SCROLL_STATE_CHANGED', 'SCROLL_PROGRESS', 'AD_SAVED_EVENT', 'AD_DELETED_EVENT',
  'AD_TAGS_UPDATED_EVENT', 'COLLECTIONS_UPDATED_EVENT', 'ADVERTISERS_UPDATED_EVENT'
]);

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || UI_EVENTS.has(message.action)) return false;

  if (message.action === 'PING') {
    sendResponse({ status: 'PONG' });
    return false;
  }

  // Handle operations asynchronously
  handleAsyncMessage(message, sender, sendResponse);
  return true; // Keep message channel open for async sendResponse
});

async function handleAsyncMessage(message, sender, sendResponse) {
  try {
    switch (message.action) {
      case 'SAVE_SEARCH': {
        const saved = await db.saveSearch(message.data);
        sendResponse({ success: true, data: saved });
        break;
      }
      case 'GET_SEARCHES': {
        const searches = await db.getSearches();
        sendResponse({ success: true, data: searches });
        break;
      }
      case 'DELETE_SEARCH': {
        await db.deleteSearch(message.id);
        sendResponse({ success: true });
        break;
      }
      case 'SAVE_AD': {
        const adData = message.data;
        const saved = await db.saveAd(adData);
        sendResponse({ success: true, data: saved });
        
        // Launch enrichment (downloads and traces redirects) asynchronously in background
        enrichAndDownloadAd(adData).catch(err => console.error('Enrichment failed:', err));
        break;
      }
      case 'GET_ADS': {
        const ads = await db.getAds(message.advertiserName);
        sendResponse({ success: true, data: ads });
        break;
      }
      case 'DELETE_AD': {
        await db.deleteAd(message.libraryId);
        // Let side panel know an ad was deleted
        chrome.runtime.sendMessage({ action: 'AD_DELETED_EVENT', libraryId: message.libraryId }).catch(() => {
          // Ignore error
        });
        sendResponse({ success: true });
        break;
      }
      case 'GET_ADVERTISERS': {
        const advertisers = await db.getAdvertisers();
        sendResponse({ success: true, data: advertisers });
        break;
      }
      case 'SAVE_ADVERTISER': {
        const saved = await db.saveAdvertiser(message.data);
        chrome.runtime.sendMessage({ action: 'ADVERTISERS_UPDATED_EVENT' }).catch(() => {});
        sendResponse({ success: true, data: saved });
        break;
      }
      case 'DELETE_ADVERTISER': {
        await db.deleteAdvertiser(message.name);
        sendResponse({ success: true });
        break;
      }
      case 'TOGGLE_WATCH_ADVERTISER': {
        const adv = await db.toggleWatchAdvertiser(message.name, message.isWatching);
        chrome.runtime.sendMessage({ action: 'ADVERTISERS_UPDATED_EVENT' }).catch(() => {});
        sendResponse({ success: true, data: adv });
        break;
      }
      case 'SAVE_ADVERTISER_SNAPSHOT': {
        const adv = await db.saveAdvertiserSnapshot(message.name, message.libraryIds);
        chrome.runtime.sendMessage({ action: 'ADVERTISERS_UPDATED_EVENT' }).catch(() => {});
        sendResponse({ success: true, data: adv });
        break;
      }
      case 'GET_WATCHED_STATE': {
        const store = await db.getStore('advertisers', 'readonly');
        const getRequest = store.get(message.name);
        getRequest.onsuccess = () => {
          const adv = getRequest.result;
          if (adv && adv.isWatched) {
            sendResponse({ success: true, isWatched: true, snapshotIds: adv.snapshotIds || [], lastSnapshotAt: adv.lastSnapshotAt });
          } else {
            sendResponse({ success: true, isWatched: false, snapshotIds: [] });
          }
        };
        getRequest.onerror = (e) => sendResponse({ success: false, error: e.target.error });
        return true; // async handler
      }
      
      // Tag Operations
      case 'ADD_TAG_TO_AD': {
        const ad = await db.addTagToAd(message.libraryId, message.tag);
        chrome.runtime.sendMessage({ action: 'AD_TAGS_UPDATED_EVENT', libraryId: message.libraryId, tags: ad.tags }).catch(() => {});
        sendResponse({ success: true, data: ad });
        break;
      }
      case 'REMOVE_TAG_FROM_AD': {
        const ad = await db.removeTagFromAd(message.libraryId, message.tag);
        chrome.runtime.sendMessage({ action: 'AD_TAGS_UPDATED_EVENT', libraryId: message.libraryId, tags: ad.tags }).catch(() => {});
        sendResponse({ success: true, data: ad });
        break;
      }
      
      // Update Ad Details (from detail modal parsing)
      case 'UPDATE_AD_DETAILS': {
        const store = await db.getStore('ads', 'readwrite');
        const getRequest = store.get(message.libraryId);
        getRequest.onsuccess = () => {
          const ad = getRequest.result;
          if (ad) {
            ad.additionalLinks = message.details.additionalLinks || [];
            ad.additionalTexts = message.details.additionalTexts || [];
            ad.advertiserInfo = message.details.advertiserInfo || '';
            ad.lastDetailedUpdate = message.details.lastDetailedUpdate;
            
            const putRequest = store.put(ad);
            putRequest.onsuccess = () => {
              chrome.runtime.sendMessage({ action: 'AD_SAVED_EVENT', data: ad }).catch(() => {});
              sendResponse({ success: true, data: ad });
            };
            putRequest.onerror = (e) => sendResponse({ success: false, error: e.target.error });
          } else {
            sendResponse({ success: false, error: 'Ad not found' });
          }
        };
        getRequest.onerror = (e) => sendResponse({ success: false, error: e.target.error });
        break;
      }

      // Collection Operations
      case 'SAVE_COLLECTION': {
        const saved = await db.saveCollection(message.data);
        chrome.runtime.sendMessage({ action: 'COLLECTIONS_UPDATED_EVENT' }).catch(() => {});
        sendResponse({ success: true, data: saved });
        break;
      }
      case 'GET_COLLECTIONS': {
        const collections = await db.getCollections();
        sendResponse({ success: true, data: collections });
        break;
      }
      case 'DELETE_COLLECTION': {
        await db.deleteCollection(message.id);
        chrome.runtime.sendMessage({ action: 'COLLECTIONS_UPDATED_EVENT' }).catch(() => {});
        sendResponse({ success: true });
        break;
      }
      case 'ADD_AD_TO_COLLECTION': {
        const coll = await db.addAdToCollection(message.adId, message.collectionId);
        chrome.runtime.sendMessage({ action: 'COLLECTIONS_UPDATED_EVENT' }).catch(() => {});
        sendResponse({ success: true, data: coll });
        break;
      }
      case 'REMOVE_AD_FROM_COLLECTION': {
        const coll = await db.removeAdFromCollection(message.adId, message.collectionId);
        chrome.runtime.sendMessage({ action: 'COLLECTIONS_UPDATED_EVENT' }).catch(() => {});
        sendResponse({ success: true, data: coll });
        break;
      }

      // Local Creative Downloader API
      case 'DOWNLOAD_CREATIVE': {
        let ext = 'jpg';
        if (message.mediaType === 'video') ext = 'mp4';
        
        // Strip query params and try to get extension from path
        const cleanUrl = message.url.split('?')[0];
        const matches = cleanUrl.match(/\.([a-z0-9]+)$/i);
        if (matches && matches[1]) {
          ext = matches[1].toLowerCase();
        }

        const safeBrand = safeFolderName(message.advertiser);
        const filename = `MetaIntelligence/creatives/${safeBrand}/${message.libraryId}.${ext}`;

        chrome.downloads.download({
          url: message.url,
          filename: filename,
          conflictAction: 'overwrite'
        }, (downloadId) => {
          if (chrome.runtime.lastError) {
            console.error('Downloads API Error:', chrome.runtime.lastError.message);
            sendResponse({ success: false, error: chrome.runtime.lastError.message });
          } else {
            sendResponse({ success: true, localPath: filename, downloadId });
          }
        });
        break;
      }

      // Link Redirect & UTM Tracer
      case 'TRACE_REDIRECT': {
        const result = await traceRedirect(message.url);
        sendResponse({ success: true, data: result });
        break;
      }

      default:
        sendResponse({ success: false, error: 'Unknown action: ' + message.action });
    }
  } catch (error) {
    console.error(`Error handling action ${message.action}:`, error);
    sendResponse({ success: false, error: error.message });
  }
}

// Folder-safe advertiser name for download paths
function safeFolderName(name) {
  const cleaned = String(name || 'Unknown').replace(/[^a-zA-Z0-9_\-]/g, '_').replace(/_+/g, '_').slice(0, 80);
  return cleaned || 'Unknown';
}

function extractUtm(urlObj) {
  const utmParams = {};
  for (const [key, val] of urlObj.searchParams.entries()) {
    if (key.startsWith('utm_')) utmParams[key] = val;
  }
  return utmParams;
}

// Redirect resolution trace engine
async function traceRedirect(url) {
  if (!url) return { finalUrl: '', domain: '' };

  // Facebook outbound links (l.facebook.com/l.php?u=...) carry the destination in "u".
  // Decoding it locally is instant and avoids sending a request to the advertiser's site.
  try {
    const u = new URL(url);
    const target = u.searchParams.get('u');
    if (target && /(^|\.)facebook\.com$/i.test(u.hostname)) {
      const targetUrlObj = new URL(target);
      targetUrlObj.searchParams.delete('fbclid');
      return {
        finalUrl: targetUrlObj.href,
        domain: targetUrlObj.hostname,
        utmParams: extractUtm(targetUrlObj)
      };
    }
  } catch (e) {
    // Not a parseable proxy link; fall back to a network trace below
  }

  try {
    const response = await fetch(url, {
      method: 'GET',
      redirect: 'follow',
      referrerPolicy: 'no-referrer'
    });
    
    const finalUrl = response.url;
    const urlObj = new URL(finalUrl);
    const utmParams = {};
    
    for (const [key, val] of urlObj.searchParams.entries()) {
      if (key.startsWith('utm_')) {
        utmParams[key] = val;
      }
    }
    
    return {
      finalUrl,
      domain: urlObj.hostname,
      utmParams
    };
  } catch (err) {
    console.warn('Network tracer failed, using regex parameter extract:', err);
    // Parse target url directly from facebook proxy parameter
    try {
      const u = new URL(url);
      const targetParam = u.searchParams.get('u');
      if (targetParam) {
        const decodedUrl = decodeURIComponent(targetParam);
        const targetUrlObj = new URL(decodedUrl);
        const utmParams = {};
        for (const [key, val] of targetUrlObj.searchParams.entries()) {
          if (key.startsWith('utm_')) {
            utmParams[key] = val;
          }
        }
        return {
          finalUrl: decodedUrl,
          domain: targetUrlObj.hostname,
          utmParams
        };
      }
    } catch (e) {
      console.error('URL parsing fallback error:', e);
    }
    
    // Final fallback
    try {
      const parsedUrl = new URL(url);
      return { finalUrl: url, domain: parsedUrl.hostname, utmParams: {} };
    } catch (e) {
      return { finalUrl: url, domain: '', utmParams: {} };
    }
  }
}

// Background Task: Enriches saved ad records with redirect resolutions and local download paths
async function enrichAndDownloadAd(adData) {
  // Give database transaction a tiny delay if needed to resolve write conflicts
  await new Promise(resolve => setTimeout(resolve, 500));
  
  // Re-read latest record
  const dbAd = await new Promise(async (resolve) => {
    try {
      const adsStore = await db.getStore('ads', 'readonly');
      const req = adsStore.get(adData.libraryId);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => resolve(null);
    } catch (err) {
      resolve(null);
    }
  });

  if (!dbAd) return;

  let updated = false;

  // 1. Trace Link Redirects
  if (dbAd.ctaUrl && !dbAd.resolvedUrl) {
    console.log('Tracing redirect links for Library ID:', dbAd.libraryId);
    const trace = await traceRedirect(dbAd.ctaUrl);
    if (trace && trace.finalUrl) {
      dbAd.resolvedUrl = trace.finalUrl;
      dbAd.resolvedDomain = trace.domain;
      dbAd.utmParams = trace.utmParams;
      updated = true;
    }
  }

  // 2. Persist small thumbnails inside the database. Meta's CDN links are signed and
  // expire after a few days, so without this saved ads lose their images.
  const thumbSource = dbAd.mediaType === 'video'
    ? dbAd.videoThumbnail
    : (dbAd.mediaUrls && dbAd.mediaUrls[0]);
  if (thumbSource && !dbAd.thumbnailData) {
    const data = await makeThumbnailDataUrl(thumbSource, 480);
    if (data) {
      dbAd.thumbnailData = data;
      updated = true;
    }
  }
  if (dbAd.profileImage && !dbAd.profileImageData) {
    const data = await makeThumbnailDataUrl(dbAd.profileImage, 64);
    if (data) {
      dbAd.profileImageData = data;
      updated = true;
    }
  }

  // 3. Download Media Assets locally (can be turned off in Settings)
  const { autoDownloadCreatives } = await chrome.storage.local.get('autoDownloadCreatives');
  const downloadEnabled = autoDownloadCreatives !== false;
  const mediaUrl = dbAd.mediaType === 'video' ? dbAd.videoUrl : (dbAd.mediaUrls && dbAd.mediaUrls[0]);
  if (downloadEnabled && mediaUrl && !mediaUrl.startsWith('blob:') && !dbAd.localPath) {
    console.log('Downloading media asset for Library ID:', dbAd.libraryId);
    
    let ext = 'jpg';
    if (dbAd.mediaType === 'video') ext = 'mp4';
    const cleanUrl = mediaUrl.split('?')[0];
    const matches = cleanUrl.match(/\.([a-z0-9]+)$/i);
    if (matches && matches[1]) {
      ext = matches[1].toLowerCase();
    }

    const safeBrand = safeFolderName(dbAd.advertiser);
    const filename = `MetaIntelligence/creatives/${safeBrand}/${dbAd.libraryId}.${ext}`;

    try {
      await new Promise((resolve, reject) => {
        chrome.downloads.download({
          url: mediaUrl,
          filename: filename,
          conflictAction: 'overwrite'
        }, (downloadId) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
          } else {
            resolve(downloadId);
          }
        });
      });
      dbAd.localPath = filename;
      updated = true;
    } catch (err) {
      console.warn('Background media download failed:', err.message);
    }
  }

  if (updated) {
    await db.saveAd(dbAd);
    console.log('Ad enriched and re-saved:', dbAd.libraryId);
    // Broadcast event to Side Panel to trigger UI updates
    chrome.runtime.sendMessage({ action: 'AD_SAVED_EVENT', data: dbAd }).catch(() => {
      // Ignore if sidepanel is closed
    });
  }
}

// Fetch an image and return a downscaled JPEG data URL (or null on failure)
async function makeThumbnailDataUrl(url, maxSize) {
  if (!url || url.startsWith('blob:')) return null;
  if (url.startsWith('data:')) return url.length < 200000 ? url : null;
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 10000);
    const res = await fetch(url, { signal: controller.signal });
    clearTimeout(timeoutId);
    if (!res.ok) return null;
    const blob = await res.blob();
    if (!blob.type.startsWith('image/')) return null;

    const bitmap = await createImageBitmap(blob);
    const scale = Math.min(1, maxSize / Math.max(bitmap.width, bitmap.height));
    const w = Math.max(1, Math.round(bitmap.width * scale));
    const h = Math.max(1, Math.round(bitmap.height * scale));
    const canvas = new OffscreenCanvas(w, h);
    canvas.getContext('2d').drawImage(bitmap, 0, 0, w, h);
    bitmap.close();
    const out = await canvas.convertToBlob({ type: 'image/jpeg', quality: 0.8 });

    const bytes = new Uint8Array(await out.arrayBuffer());
    let binary = '';
    for (let i = 0; i < bytes.length; i += 0x8000) {
      binary += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
    }
    return `data:image/jpeg;base64,${btoa(binary)}`;
  } catch (err) {
    console.warn('Thumbnail capture failed:', err.message);
    return null;
  }
}
