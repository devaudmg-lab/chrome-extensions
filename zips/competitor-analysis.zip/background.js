// Import IndexedDB database logic
importScripts('db.js');

// Keep settings (including the optional AI API key) out of reach of content scripts.
// Only extension pages (the side panel) and this service worker need them.
try {
  chrome.storage.local.setAccessLevel({ accessLevel: 'TRUSTED_CONTEXTS' }).catch(() => {});
} catch (e) {
  // Older Chrome without setAccessLevel for local storage: nothing else to do
}

// Allow the sidepanel to be opened when the extension icon is clicked
chrome.runtime.onInstalled.addListener(() => {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true })
    .catch((error) => console.error('Error setting panel behavior:', error));
});

// Broadcast-only events (meant for the side panel) that the service worker should ignore
const UI_EVENTS = new Set([
  'SCROLL_STATE_CHANGED', 'SCROLL_PROGRESS', 'AD_SAVED_EVENT', 'AD_DELETED_EVENT',
  'AD_TAGS_UPDATED_EVENT', 'COLLECTIONS_UPDATED_EVENT', 'ADVERTISERS_UPDATED_EVENT'
]);

// Content scripts run on a third-party page, so they may only ask for these actions.
// Everything they send is treated as untrusted input and sanitised below.
const CONTENT_ACTIONS = new Set([
  'SAVE_SEARCH', 'SAVE_AD', 'SAVE_ADVERTISER', 'UPDATE_AD_DETAILS', 'GET_WATCHED_STATE', 'GET_SAVED_IDS'
]);

function isExtensionPage(sender) {
  // Content scripts report the web page's URL here; only our own pages have this origin
  return typeof sender.url === 'string' && sender.url.startsWith(`chrome-extension://${chrome.runtime.id}/`);
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || typeof message.action !== 'string' || UI_EVENTS.has(message.action)) return false;
  if (sender.id !== chrome.runtime.id) return false;

  if (message.action === 'PING') {
    sendResponse({ status: 'PONG' });
    return false;
  }

  if (!isExtensionPage(sender) && !CONTENT_ACTIONS.has(message.action)) {
    sendResponse({ success: false, error: 'Action not allowed from this context' });
    return false;
  }

  // Handle operations asynchronously
  handleAsyncMessage(message, sender, sendResponse);
  return true; // Keep message channel open for async sendResponse
});

function broadcast(message) {
  chrome.runtime.sendMessage(message).catch(() => {
    // No side panel open: nothing to update
  });
}

// ---- Input sanitising for data scraped by the content script ----
const str = (v, max) => (typeof v === 'string' ? v : (v == null ? '' : String(v))).slice(0, max);
const isLibraryId = (v) => typeof v === 'string' && /^\d{1,25}$/.test(v);
const PLATFORMS = new Set(['facebook', 'instagram', 'messenger', 'audience_network', 'threads']);

function sanitizeAd(data) {
  if (!data || typeof data !== 'object' || !isLibraryId(data.libraryId)) return null;
  return {
    libraryId: data.libraryId,
    advertiser: str(data.advertiser, 200).trim() || 'Unknown Advertiser',
    pageUrl: str(data.pageUrl, 2000),
    profileImage: str(data.profileImage, 4000),
    status: data.status === 'inactive' ? 'inactive' : 'active',
    startedDate: str(data.startedDate, 60),
    endedDate: str(data.endedDate, 60),
    platforms: Array.isArray(data.platforms) ? data.platforms.filter(p => PLATFORMS.has(p)) : [],
    primaryText: str(data.primaryText, 10000),
    headline: str(data.headline, 500),
    description: str(data.description, 1000),
    cta: str(data.cta, 100),
    ctaUrl: str(data.ctaUrl, 4000),
    mediaType: data.mediaType === 'video' ? 'video' : 'image',
    mediaUrls: Array.isArray(data.mediaUrls) ? data.mediaUrls.slice(0, 10).map(u => str(u, 4000)) : [],
    videoUrl: str(data.videoUrl, 4000),
    videoThumbnail: str(data.videoThumbnail, 4000),
    collectedAt: Number(data.collectedAt) || Date.now()
  };
}

function sanitizeSearch(data) {
  if (!data || typeof data !== 'object') return null;
  const url = str(data.url, 2000);
  if (!/^https:\/\/www\.facebook\.com\/ads\/library\//.test(url)) return null;
  const id = str(data.id, 300);
  if (!id) return null;
  return {
    id,
    keyword: str(data.keyword, 200),
    country: str(data.country, 10),
    category: str(data.category, 40),
    url,
    timestamp: Date.now(),
    adCount: Math.max(0, Math.min(100000, Number(data.adCount) || 0))
  };
}

function sanitizeAdvertiser(data) {
  if (!data || typeof data !== 'object') return null;
  const name = str(data.name, 200).trim();
  if (!name) return null;
  const t = data.transparency || {};
  return {
    name,
    pageUrl: /^https:\/\/www\.facebook\.com\/ads\/library\//.test(str(data.pageUrl, 2000)) ? str(data.pageUrl, 2000) : '',
    lastUpdated: Date.now(),
    transparency: {
      businessName: str(t.businessName, 200),
      pageCreated: str(t.pageCreated, 60),
      country: str(t.country, 100),
      mergedPages: Array.isArray(t.mergedPages) ? t.mergedPages.slice(0, 20).map(p => str(p, 200)) : []
    }
  };
}

const strList = (list, maxItems, maxLen) => (Array.isArray(list) ? list.slice(0, maxItems).map(v => str(v, maxLen)) : []);

async function handleAsyncMessage(message, sender, sendResponse) {
  try {
    switch (message.action) {
      case 'SAVE_SEARCH': {
        const search = sanitizeSearch(message.data);
        if (!search) throw new Error('Invalid search');
        const saved = await db.saveSearch(search);
        sendResponse({ success: true, data: saved });
        break;
      }
      case 'SAVE_AD': {
        const adData = sanitizeAd(message.data);
        if (!adData) throw new Error('Invalid ad data');
        const saved = await db.saveAd(adData);
        sendResponse({ success: true, data: { libraryId: saved.libraryId } });
        broadcast({ action: 'AD_SAVED_EVENT', libraryId: saved.libraryId });

        // Launch enrichment (thumbnails, landing page, optional download) in the background
        enrichAndDownloadAd(adData.libraryId).catch(err => console.warn('Enrichment failed:', err && err.message));
        break;
      }
      case 'GET_SAVED_IDS': {
        const ids = Array.isArray(message.libraryIds) ? message.libraryIds.filter(isLibraryId) : [];
        const saved = await db.getSavedIds(ids);
        sendResponse({ success: true, data: saved });
        break;
      }
      case 'SAVE_ADVERTISER': {
        const adv = sanitizeAdvertiser(message.data);
        if (!adv) throw new Error('Invalid advertiser');
        const saved = await db.saveAdvertiser(adv);
        broadcast({ action: 'ADVERTISERS_UPDATED_EVENT' });
        sendResponse({ success: true, data: { name: saved.name } });
        break;
      }
      case 'TOGGLE_WATCH_ADVERTISER': {
        const adv = await db.toggleWatchAdvertiser(message.name, !!message.isWatching);
        broadcast({ action: 'ADVERTISERS_UPDATED_EVENT' });
        sendResponse({ success: true, data: adv });
        break;
      }
      case 'SAVE_ADVERTISER_SNAPSHOT': {
        const adv = await db.saveAdvertiserSnapshot(message.name, strList(message.libraryIds, 20000, 25));
        broadcast({ action: 'ADVERTISERS_UPDATED_EVENT' });
        sendResponse({ success: true, data: adv });
        break;
      }
      case 'GET_WATCHED_STATE': {
        const adv = await db.getAdvertiser(str(message.name, 200));
        if (adv && adv.isWatched) {
          sendResponse({ success: true, isWatched: true, snapshotIds: adv.snapshotIds || [], lastSnapshotAt: adv.lastSnapshotAt || null });
        } else {
          sendResponse({ success: true, isWatched: false, snapshotIds: [] });
        }
        break;
      }

      // Extra details from the "See ad details" dialog
      case 'UPDATE_AD_DETAILS': {
        if (!isLibraryId(message.libraryId)) throw new Error('Invalid Library ID');
        const d = message.details || {};
        const ad = await db.updateAd(message.libraryId, {
          additionalLinks: strList(d.additionalLinks, 50, 2000),
          additionalTexts: strList(d.additionalTexts, 50, 2000),
          advertiserInfo: str(d.advertiserInfo, 2000),
          lastDetailedUpdate: Date.now()
        });
        if (!ad) {
          sendResponse({ success: false, error: 'Ad not found' });
          break;
        }
        broadcast({ action: 'AD_SAVED_EVENT', libraryId: ad.libraryId });
        sendResponse({ success: true });
        break;
      }

      default:
        sendResponse({ success: false, error: 'Unknown action: ' + message.action });
    }
  } catch (error) {
    console.warn(`Action ${message.action} failed:`, error && error.message);
    sendResponse({ success: false, error: error && error.message ? error.message : String(error) });
  }
}

// Folder-safe advertiser name for download paths
function safeFolderName(name) {
  const cleaned = String(name || 'Unknown').replace(/[^a-zA-Z0-9_\-]/g, '_').replace(/_+/g, '_').slice(0, 80);
  return cleaned || 'Unknown';
}

function extractUtm(urlObj) {
  const utmParams = {};
  for (const [key, val] of urlObj.searchParams.entries()) {
    if (key.startsWith('utm_')) utmParams[key] = val.slice(0, 300);
  }
  return utmParams;
}

function httpUrl(value) {
  try {
    const u = new URL(value);
    return (u.protocol === 'http:' || u.protocol === 'https:') ? u : null;
  } catch (e) {
    return null;
  }
}

// Landing page resolution. Meta's outbound links (l.facebook.com/l.php?u=...) carry the
// destination in "u", so it is decoded locally: no request is ever sent to the
// advertiser's site (which would show up in their analytics).
function traceRedirect(url) {
  const link = httpUrl(url);
  if (!link) return null;
  let target = link;
  if (/(^|\.)facebook\.com$/i.test(link.hostname) && link.searchParams.get('u')) {
    target = httpUrl(link.searchParams.get('u'));
    if (!target) return null;
  }
  target.searchParams.delete('fbclid');
  return { finalUrl: target.href, domain: target.hostname.replace(/^www\./i, ''), utmParams: extractUtm(target) };
}

const MEDIA_EXTENSIONS = new Set(['jpg', 'jpeg', 'png', 'webp', 'gif', 'mp4', 'mov', 'webm']);

// Only Meta's CDN is downloaded (the host permission covers it, and it keeps the
// extension from fetching arbitrary URLs that a page could plant in an ad card)
function isMetaCdn(url) {
  const u = httpUrl(url);
  return !!u && u.protocol === 'https:' && /(^|\.)fbcdn\.net$/i.test(u.hostname);
}

// Background Task: Enriches saved ad records with redirect resolutions and local download paths
async function enrichAndDownloadAd(libraryId) {
  const dbAd = await db.getAd(libraryId);
  if (!dbAd) return;

  const patch = {};

  // 1. Landing page and UTM parameters
  if (dbAd.ctaUrl && !dbAd.resolvedUrl) {
    const trace = traceRedirect(dbAd.ctaUrl);
    if (trace) {
      patch.resolvedUrl = trace.finalUrl;
      patch.resolvedDomain = trace.domain;
      patch.utmParams = trace.utmParams;
    }
  }

  // 2. Persist small thumbnails inside the database. Meta's CDN links are signed and
  // expire after a few days, so without this saved ads lose their images.
  const thumbSource = dbAd.mediaType === 'video'
    ? dbAd.videoThumbnail
    : (dbAd.mediaUrls && dbAd.mediaUrls[0]);
  if (thumbSource && !dbAd.thumbnailData) {
    const data = await makeThumbnailDataUrl(thumbSource, 480);
    if (data) patch.thumbnailData = data;
  }
  if (dbAd.profileImage && !dbAd.profileImageData) {
    const data = await makeThumbnailDataUrl(dbAd.profileImage, 64);
    if (data) patch.profileImageData = data;
  }

  // 3. Download Media Assets locally (can be turned off in Settings)
  const { autoDownloadCreatives } = await chrome.storage.local.get('autoDownloadCreatives');
  const downloadEnabled = autoDownloadCreatives !== false;
  const mediaUrl = dbAd.mediaType === 'video' ? dbAd.videoUrl : (dbAd.mediaUrls && dbAd.mediaUrls[0]);
  if (downloadEnabled && isMetaCdn(mediaUrl) && !dbAd.localPath) {
    let ext = dbAd.mediaType === 'video' ? 'mp4' : 'jpg';
    const matches = new URL(mediaUrl).pathname.match(/\.([a-z0-9]+)$/i);
    if (matches && MEDIA_EXTENSIONS.has(matches[1].toLowerCase())) ext = matches[1].toLowerCase();

    const filename = `MetaIntelligence/creatives/${safeFolderName(dbAd.advertiser)}/${dbAd.libraryId}.${ext}`;
    try {
      await chrome.downloads.download({ url: mediaUrl, filename, conflictAction: 'overwrite' });
      patch.localPath = filename;
    } catch (err) {
      console.warn('Background media download failed:', err.message);
    }
  }

  if (Object.keys(patch).length) {
    // Merge into the latest record: tags, notes or folders may have changed meanwhile
    await db.updateAd(libraryId, patch);
    broadcast({ action: 'AD_SAVED_EVENT', libraryId });
  }
}

// Fetch an image and return a downscaled JPEG data URL (or null on failure)
async function makeThumbnailDataUrl(url, maxSize) {
  if (!url || url.startsWith('blob:')) return null;
  if (url.startsWith('data:image/')) return url.length < 200000 ? url : null;
  if (!isMetaCdn(url)) return null;
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 10000);
    const res = await fetch(url, { signal: controller.signal, credentials: 'omit' });
    clearTimeout(timeoutId);
    if (!res.ok) return null;
    const blob = await res.blob();
    if (!blob.type.startsWith('image/') || blob.size > 15 * 1024 * 1024) return null;

    const bitmap = await createImageBitmap(blob);
    const scale = Math.min(1, maxSize / Math.max(bitmap.width, bitmap.height));
    const w = Math.max(1, Math.round(bitmap.width * scale));
    const h = Math.max(1, Math.round(bitmap.height * scale));
    const canvas = new OffscreenCanvas(w, h);
    canvas.getContext('2d').drawImage(bitmap, 0, 0, w, h);
    bitmap.close();
    const out = await canvas.convertToBlob({ type: 'image/jpeg', quality: 0.8 });

    const bytes = new Uint8Array(await out.arrayBuffer());
    let binary = '';
    for (let i = 0; i < bytes.length; i += 0x8000) {
      binary += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
    }
    return `data:image/jpeg;base64,${btoa(binary)}`;
  } catch (err) {
    console.warn('Thumbnail capture failed:', err.message);
    return null;
  }
}
