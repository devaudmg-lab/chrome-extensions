// Meta Competitor Intelligence - Side Panel Script

let activeSearchContext = null;
let currentScrollState = { isScrolling: false, count: 0 };

// Escape scraped text before it is placed into HTML. Ad copy, advertiser names and
// lead-form text come from third-party pages and must never be treated as markup
// (this also protects the exported HTML report, which is opened without a CSP).
function esc(value) {
  return String(value == null ? '' : value).replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}

// Only allow http(s) links and inline images in attributes; anything else becomes '#'/''
function safeUrl(value, { allowData = false } = {}) {
  const str = String(value || '').trim();
  if (!str) return '';
  if (allowData && /^data:image\//i.test(str)) return esc(str);
  try {
    const u = new URL(str);
    if (u.protocol === 'http:' || u.protocol === 'https:') return esc(u.href);
  } catch (e) { /* invalid URL */ }
  return '';
}

const PLACEHOLDER_AVATAR = 'data:image/svg+xml;utf8,<svg xmlns=%22http://www.w3.org/2000/svg%22 width=%2210%22 height=%2210%22><rect width=%2210%22 height=%2210%22 fill=%22%23475569%22/></svg>';

// Prefer the thumbnail stored in the database: Meta CDN links expire after a few days
function adImageSrc(ad) {
  if (ad.thumbnailData) return ad.thumbnailData;
  if (ad.mediaType === 'video') return ad.videoThumbnail || '';
  return (ad.mediaUrls && ad.mediaUrls[0]) || '';
}

document.addEventListener('DOMContentLoaded', async () => {

  // Initialize DB
  try {
    await db.init();
    updateDbStatus(true);
  } catch (error) {
    console.error('Database connection failed:', error);
    updateDbStatus(false);
    return;
  }

  // Setup tabs navigation
  initTabs();

  // Load Initial View Data
  loadAllViews();
  loadCollectionsView();

  // Try to bind to active Meta Ad Library tab
  detectActiveTabSearch();

  // Setup event listeners
  setupEventListeners();
  initExtras();

  // Listen for messages from content scripts or background service worker
  chrome.runtime.onMessage.addListener((message, sender) => {
    if (!message || sender.id !== chrome.runtime.id) return;
    if (message.action === 'AD_SAVED_EVENT' || message.action === 'AD_DELETED_EVENT') {
      // Collect All can save hundreds of ads in a row: batch the re-renders
      scheduleViewsRefresh();
    } else if (message.action === 'SCROLL_STATE_CHANGED') {
      if (isFromActiveTab(sender)) handleScrollStateChange(message.data);
    } else if (message.action === 'SCROLL_PROGRESS') {
      if (isFromActiveTab(sender)) handleScrollProgress(message.data);
    } else if (message.action === 'COLLECTIONS_UPDATED_EVENT') {
      loadCollectionsView();
      scheduleViewsRefresh();
    } else if (message.action === 'ADVERTISERS_UPDATED_EVENT') {
      loadBrandsView();
    }
  });

  // Follow the browser: the Search tab always reflects the tab you are looking at
  chrome.tabs.onActivated.addListener(scheduleTabDetect);
  chrome.tabs.onUpdated.addListener((tabId, info, tab) => {
    if (tab.active && (info.url || info.status === 'complete')) scheduleTabDetect();
  });
  if (chrome.windows && chrome.windows.onFocusChanged) chrome.windows.onFocusChanged.addListener(scheduleTabDetect);
});

let activeTabId = null;
function isFromActiveTab(sender) {
  return !sender.tab || activeTabId == null || sender.tab.id === activeTabId;
}

let tabDetectTimer = null;
function scheduleTabDetect() {
  clearTimeout(tabDetectTimer);
  tabDetectTimer = setTimeout(detectActiveTabSearch, 400);
}

// Re-render the data views once things settle (and only the visible heavy ones)
let viewsRefreshTimer = null;
function scheduleViewsRefresh() {
  clearTimeout(viewsRefreshTimer);
  viewsRefreshTimer = setTimeout(() => {
    if (pickerState) return scheduleViewsRefresh();
    loadSavedAdsView();
    loadBrandsView();
    if (document.getElementById('insights-tab').classList.contains('active')) loadInsightsView();
  }, 700);
}

// Tell open Ad Library tabs to re-check which ads are saved (after deletes, imports, resets)
async function notifyAdLibraryTabs() {
  try {
    const tabs = await chrome.tabs.query({ url: 'https://www.facebook.com/ads/library/*' });
    tabs.forEach(t => chrome.tabs.sendMessage(t.id, { action: 'REFRESH_SAVED_STATE' }).catch(() => {}));
  } catch (e) {
    // No Ad Library tabs open
  }
}

// Update database connectivity label in footer
function updateDbStatus(connected) {
  const statusEl = document.getElementById('db-status');
  if (statusEl) {
    statusEl.innerHTML = connected
      ? '<span style="color: #10b981;">●</span> DB Connected'
      : '<span style="color: #ef4444;">●</span> DB Error';
  }
}

// 1. Tab Management UI
function initTabs() {
  const tabs = document.querySelectorAll('.nav-tab');
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      // Toggle nav-tab active classes
      tabs.forEach(t => {
        t.classList.remove('active');
        t.setAttribute('aria-selected', 'false');
      });
      tab.classList.add('active');
      tab.setAttribute('aria-selected', 'true');
      // Each tab starts at the top (the scroll container is shared by all tabs)
      const main = document.querySelector('.app-main');
      if (main) main.scrollTop = 0;

      // Toggle tab-content active classes
      const targetTab = tab.getAttribute('data-tab');
      const contents = document.querySelectorAll('.tab-content');
      contents.forEach(content => {
        content.classList.remove('active');
        if (content.id === targetTab) {
          content.classList.add('active');
        }
      });

      // Reload view when switching to it
      if (targetTab === 'ads-tab') loadSavedAdsView();
      if (targetTab === 'brands-tab') loadBrandsView();
      if (targetTab === 'history-tab') loadHistoryView();
      if (targetTab === 'insights-tab') loadInsightsView();
      if (targetTab === 'settings-tab') loadSettings();
    });
  });
}

// Load database views
function loadAllViews() {
  loadSavedAdsView();
  loadBrandsView();
  loadHistoryView();
}

// 2. Query Active Page Search Context
function isAdLibraryUrl(url) {
  return /^https:\/\/www\.facebook\.com\/ads\/library\//.test(url || '');
}

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  return tab || null;
}

async function detectActiveTabSearch() {
  const tab = await getActiveTab();
  activeTabId = tab ? tab.id : null;
  activeSearchContext = null;
  if (!tab || !isAdLibraryUrl(tab.url)) {
    showSearchEmptyState(true);
    return;
  }

  // Ask content script for search query details
  chrome.tabs.sendMessage(tab.id, { action: 'GET_CURRENT_SEARCH' }, (response) => {
    if (chrome.runtime.lastError) {
      // The page is still loading, or it was open before the extension was installed/updated
      showSearchEmptyState(true, tab.status === 'complete' ? 'disconnected' : 'loading');
      return;
    }

    if (response && response.success && response.data) {
      activeSearchContext = response.data;
      showSearchEmptyState(false);
      populateSearchDetails(response.data);

      // Get current scrolling state from content script
      chrome.tabs.sendMessage(tab.id, { action: 'GET_SCROLL_STATE' }, (stateRes) => {
        if (chrome.runtime.lastError) return;
        if (stateRes) handleScrollStateChange(stateRes, { refresh: false });
      });
    } else {
      showSearchEmptyState(true, 'no-query');
    }
  });
}

function showSearchEmptyState(isEmpty, isDisconnected = false) {
  const emptyMsg = document.getElementById('no-search-msg');
  const details = document.getElementById('search-details');
  const scrollCard = document.getElementById('scroll-card');

  if (isEmpty) {
    emptyMsg.classList.remove('hidden');
    details.classList.add('hidden');
    scrollCard.classList.add('hidden');
    if (currentScrollState.isScrolling) handleScrollStateChange({ isScrolling: false }, { refresh: false });

    const hintEl = emptyMsg.querySelector('.hint');
    if (hintEl) {
      if (isDisconnected === 'disconnected' || isDisconnected === true) {
        hintEl.innerHTML = '⚠️ <strong>Not connected to this tab.</strong> Refresh the Ad Library page (needed once after installing or updating the extension).';
      } else if (isDisconnected === 'loading') {
        hintEl.textContent = 'The Ad Library page is still loading…';
      } else if (isDisconnected === 'no-query') {
        hintEl.textContent = 'Search for a competitor or keyword in the Ad Library to use Collect All. Save buttons already work on every ad card.';
      } else {
        hintEl.textContent = 'Open the Meta Ad Library and search for a competitor or keyword to activate these tools.';
      }
    }
  } else {
    emptyMsg.classList.add('hidden');
    details.classList.remove('hidden');
    scrollCard.classList.remove('hidden');
  }
}

function populateSearchDetails(context) {
  document.getElementById('curr-keyword').innerText = context.keyword || 'None';
  document.getElementById('curr-country').innerText = context.country || 'ALL';
  document.getElementById('curr-category').innerText = context.category || 'all';
  document.getElementById('curr-count').innerText = context.adCount || 0;
}

// 3. Event Listeners Setup
function setupEventListeners() {
  // Collect All trigger
  const btnCollect = document.getElementById('btn-collect-all');
  if (btnCollect) {
    btnCollect.addEventListener('click', toggleCollection);
  }

  // Export Buttons
  document.getElementById('btn-export-excel').addEventListener('click', exportToExcel);
  document.getElementById('btn-export-json').addEventListener('click', exportToJSON);
  document.getElementById('btn-export-csv').addEventListener('click', exportToCSV);
  document.getElementById('btn-import-json').addEventListener('click', () => {
    document.getElementById('import-json-input').click();
  });
  document.getElementById('import-json-input').addEventListener('change', importFromJSON);
  document.getElementById('btn-export-report').addEventListener('click', exportHTMLReport);

  // Filters inside Ads tab
  document.getElementById('ads-search-input').addEventListener('input', filterAds);
  document.getElementById('ads-brand-filter').addEventListener('change', filterAds);
  document.getElementById('ads-collection-filter').addEventListener('change', filterAds);
  document.getElementById('ads-tag-filter').addEventListener('change', filterAds);
  document.getElementById('ads-sort').addEventListener('change', () => {
    chrome.storage.local.set({ adsSort: document.getElementById('ads-sort').value });
    loadSavedAdsView();
  });
  document.getElementById('btn-delete-collection').addEventListener('click', deleteSelectedCollection);
  document.getElementById('btn-check-watched').addEventListener('click', checkWatchedBrands);
  document.getElementById('insights-brand').addEventListener('change', loadInsightsView);

  // Folders Creator
  document.getElementById('btn-create-collection').addEventListener('click', createNewCollection);

  // Reload Button
  const btnReload = document.getElementById('btn-reload-panel');
  if (btnReload) {
    btnReload.addEventListener('click', () => {
      location.reload();
    });
  }

  // Settings Saver
  const btnSaveSettings = document.getElementById('btn-save-settings');
  if (btnSaveSettings) {
    btnSaveSettings.addEventListener('click', saveSettings);
  }

  // Clear DB
  document.getElementById('btn-clear-db').addEventListener('click', resetDatabase);
}

// 4. Scroll Collection Coordination
async function toggleCollection() {
  const tab = await getActiveTab();
  if (!tab || !isAdLibraryUrl(tab.url)) {
    showToast('Switch to an Ad Library search tab first.', 'error');
    detectActiveTabSearch();
    return;
  }

  const onFail = () => {
    showToast('Could not reach the Ad Library tab. Refresh it and try again.', 'error');
  };

  if (currentScrollState.isScrolling) {
    chrome.tabs.sendMessage(tab.id, { action: 'STOP_SCROLL' }, (res) => {
      if (chrome.runtime.lastError) return onFail();
      if (res && res.success) {
        handleScrollStateChange({ isScrolling: false, count: currentScrollState.count });
      }
    });
  } else {
    const limit = parseInt(document.getElementById('scroll-limit').value, 10) || 100;
    chrome.tabs.sendMessage(tab.id, { action: 'START_SCROLL', limit }, (res) => {
      if (chrome.runtime.lastError) return onFail();
      if (res && res.success) {
        handleScrollStateChange({ isScrolling: true, count: 0 });
      }
    });
  }
}

function handleScrollStateChange(state, { refresh = true } = {}) {
  const wasScrolling = currentScrollState.isScrolling;
  currentScrollState.isScrolling = !!state.isScrolling;

  const btnCollect = document.getElementById('btn-collect-all');
  const progressContainer = document.getElementById('scroll-progress-container');
  const limit = parseInt(document.getElementById('scroll-limit').value) || 100;

  if (state.isScrolling) {
    btnCollect.innerHTML = '🛑 Stop Collection';
    btnCollect.className = 'btn btn-secondary';
    progressContainer.classList.remove('hidden');
    updateProgressBar(0, limit);
  } else {
    btnCollect.innerHTML = '📥 Start Collect All';
    btnCollect.className = 'btn btn-primary';
    progressContainer.classList.add('hidden');
    if (refresh && wasScrolling) {
      loadAllViews(); // Refresh view after scroll session
      const n = state.count != null ? state.count : currentScrollState.count;
      showToast(`Collect All finished: ${n} ads loaded on the page and saved.`);
    }
  }
}

function handleScrollProgress(progress) {
  currentScrollState.count = progress.count;
  const limit = parseInt(document.getElementById('scroll-limit').value) || 100;
  updateProgressBar(progress.count, limit);

  const countVal = document.getElementById('curr-count');
  if (countVal) {
    countVal.innerText = progress.count;
  }
}

function updateProgressBar(count, limit) {
  const percentage = Math.min((count / limit) * 100, 100);
  document.getElementById('progress-bar').style.width = `${percentage}%`;
  document.getElementById('progress-text').innerText = `Collected ${count} / ${limit} ads...`;
}

// 5. Render Database Views
let adsRenderSeq = 0;
async function loadSavedAdsView() {
  const seq = ++adsRenderSeq;
  const ads = await db.getAds();
  const adsList = document.getElementById('ads-list');
  const brandFilter = document.getElementById('ads-brand-filter');

  // Populate brand selection filters
  const brands = [...new Set(ads.map(ad => ad.advertiser))];
  const selectedBrand = brandFilter.value;
  brandFilter.innerHTML = '<option value="">All Brands</option>';
  brands.forEach(b => {
    const opt = document.createElement('option');
    opt.value = b;
    opt.textContent = b;
    if (b === selectedBrand) opt.selected = true;
    brandFilter.appendChild(opt);
  });

  // Populate tag filter from every tag in use
  const tagFilter = document.getElementById('ads-tag-filter');
  const selectedTag = tagFilter.value;
  const allTags = [...new Set(ads.flatMap(ad => ad.tags || []))].sort((a, b) => a.localeCompare(b));
  tagFilter.innerHTML = '<option value="">🏷️ All Tags</option>';
  allTags.forEach(t => {
    const opt = document.createElement('option');
    opt.value = t;
    opt.textContent = `🏷️ ${t}`;
    if (t === selectedTag) opt.selected = true;
    tagFilter.appendChild(opt);
  });

  const badge = document.getElementById('ads-count-badge');
  if (badge) badge.textContent = `${ads.length} ad${ads.length === 1 ? '' : 's'}`;

  // Folder names per ad, shown as small badges on each card
  const collections = await db.getCollections();
  folderNamesByAd = {};
  collections.forEach(c => (c.adIds || []).forEach(id => {
    (folderNamesByAd[id] = folderNamesByAd[id] || []).push(c.name);
  }));

  // Cluster variations in-memory
  const groups = await clusterAdsByVariation(ads);
  if (seq !== adsRenderSeq) return; // a newer refresh started meanwhile
  renderAdGroups(sortAdGroups(groups, document.getElementById('ads-sort').value));
  filterAds();
}

function renderAdGroups(groups) {
  const adsList = document.getElementById('ads-list');
  adsList.innerHTML = '';

  if (groups.length === 0) {
    adsList.innerHTML = `
      <div class="empty-state">
        <p>No ads saved yet.</p>
        <p class="hint">Use the "Save Ad" button on Meta Ad Library card elements, or launch a Collector Engine session.</p>
      </div>
    `;
    return;
  }

  groups.forEach(group => {
    const ad = group[0];
    const card = document.createElement('div');
    card.className = 'ad-card';
    card.dataset.id = ad.libraryId;
    card.dataset.brand = ad.advertiser;
    // Everything the search box matches: copy, headline, brand, CTA, landing page, notes
    // (of every variation in the group, so a split-test copy change is findable too)
    card.dataset.search = group.map(a => [a.primaryText, a.headline, a.description, a.advertiser, a.cta,
      a.resolvedDomain, a.note, (a.tags || []).join(' '), a.libraryId].filter(Boolean).join(' \n ')).join(' \n ').toLowerCase();
    card.dataset.tags = [...new Set(group.flatMap(a => a.tags || []))].join('\u0001');

    // Card Header details
    const dateText = ad.startedDate
      ? (ad.endedDate ? `${ad.startedDate} – ${ad.endedDate}` : `Started: ${ad.startedDate}`)
      : 'Started: Unknown';
    const live = daysRunning(ad);
    const liveBadgeHTML = live != null
      ? `<span class="days-live-badge${live >= 30 ? ' long' : ''}" title="${ad.endedDate ? 'Ran for' : 'Running for'} ${live} days">🕒 ${live}d${ad.endedDate ? ' total' : ' live'}</span>`
      : '';
    const activeClass = ad.status === 'active' ? 'active' : 'inactive';
    const statusText = ad.status === 'active' ? 'Active' : 'Inactive';

    // Image / Video display content
    let mediaHTML = '';
    if (ad.mediaType === 'video') {
      const thumb = safeUrl(adImageSrc(ad), { allowData: true });
      mediaHTML = `
        <div class="ad-card-media">
          <span class="ad-video-badge">▶ VIDEO</span>
          <video poster="${thumb}" muted controls preload="none" src="${safeUrl(ad.videoUrl)}"></video>
        </div>
      `;
    } else if (adImageSrc(ad)) {
      mediaHTML = `
        <div class="ad-card-media">
          <img src="${safeUrl(adImageSrc(ad), { allowData: true })}" loading="lazy" alt="">
        </div>
      `;
    }

    // CTA & Resolved Redirect Link
    let ctaHTML = '';
    if (ad.cta) {
      let targetUrl = ad.resolvedUrl || ad.ctaUrl || `https://www.facebook.com/ads/library/?id=${ad.libraryId}`;
      if (ad.cta === 'Open Drop-down') {
        targetUrl = `https://www.facebook.com/ads/library/?id=${ad.libraryId}`;
      }
      ctaHTML = `<a class="ad-card-cta" href="${safeUrl(targetUrl) || '#'}" target="_blank" rel="noopener noreferrer" style="text-decoration: none; cursor: pointer;">${esc(ad.cta)}</a>`;
    }

    // Local download copy badge indicator
    const localBadgeHTML = ad.localPath
      ? `<span class="local-copy-badge" title="Saved: ${esc(ad.localPath)}">📁 Local Copy</span>`
      : '';

    const folderBadgeHTML = (folderNamesByAd[ad.libraryId] || [])
      .map(n => `<span class="folder-badge" title="In folder ${esc(n)}">📁 ${esc(n)}</span>`).join('');

    // Resolved Domain Link
    const domainBadgeHTML = ad.resolvedDomain
      ? `<a class="resolved-domain-badge" href="${safeUrl(ad.resolvedUrl) || '#'}" target="_blank" rel="noopener noreferrer" title="Resolved Destination: ${esc(ad.resolvedUrl)}">🔗 ${esc(ad.resolvedDomain)}</a>`
      : '';

    // Tags Section Builder
    let tagsHTML = '';
    const adTags = ad.tags || [];
    adTags.forEach(tag => {
      const cls = tag.toLowerCase() === 'winner' ? 'tag-winner' : (tag.toLowerCase() === 'hook' ? 'tag-hook' : '');
      tagsHTML += `
        <span class="ad-tag-pill ${cls}">
          ${esc(tag)}
          <button type="button" class="ad-tag-delete" data-tag="${esc(tag)}" data-id="${esc(ad.libraryId)}" title="Remove tag" aria-label="Remove tag ${esc(tag)}">×</button>
        </span>
      `;
    });

    // Details Section Builder (from Ad Details modal parsing)
    let detailsHTML = '';
    if ((ad.additionalTexts && ad.additionalTexts.length > 0) ||
        (ad.additionalLinks && ad.additionalLinks.length > 0) ||
        ad.advertiserInfo) {

      let textsList = '';
      if (ad.additionalTexts && ad.additionalTexts.length > 0) {
        textsList = `
          <div style="font-weight: 600; font-size: 9px; color: #818cf8; margin-top: 6px;">Lead Form / Extracted Text:</div>
          <ul style="margin: 4px 0; padding-left: 12px; font-size: 9px; color: var(--text-secondary); line-height: 1.35; max-height: 120px; overflow-y: auto;">
            ${ad.additionalTexts.map(t => `<li>${esc(t)}</li>`).join('')}
          </ul>
        `;
      }

      let linksList = '';
      if (ad.additionalLinks && ad.additionalLinks.length > 0) {
        linksList = `
          <div style="font-weight: 600; font-size: 9px; color: #3b82f6; margin-top: 6px;">Form Links:</div>
          <div style="display: flex; flex-direction: column; gap: 3px; margin-top: 2px;">
            ${ad.additionalLinks.map(l => `<a href="${safeUrl(l) || '#'}" target="_blank" rel="noopener noreferrer" style="font-size: 9px; color: #93c5fd; text-decoration: none; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">🔗 ${esc(l)}</a>`).join('')}
          </div>
        `;
      }

      let advInfoHTML = '';
      if (ad.advertiserInfo) {
        advInfoHTML = `
          <div style="font-weight: 600; font-size: 9px; color: #10b981; margin-top: 6px;">About Advertiser (More Info):</div>
          <div style="font-size: 9px; color: var(--text-secondary); line-height: 1.3; margin-top: 2px; font-style: italic;">
            "${esc(ad.advertiserInfo)}"
          </div>
        `;
      }

      detailsHTML = `
        <details class="ad-details-dropdown" style="margin-top: 8px; background: rgba(0,0,0,0.15); border-radius: 6px; padding: 6px 8px; border: 1px solid rgba(255,255,255,0.04); width: 100%; box-sizing: border-box;">
          <summary style="font-size: 9px; font-weight: 600; color: var(--text-primary); cursor: pointer; outline: none; user-select: none;">📄 View Ad Details & Lead Form</summary>
          <div style="margin-top: 6px; display: flex; flex-direction: column; gap: 4px;">
            ${advInfoHTML}
            ${textsList}
            ${linksList}
          </div>
        </details>
      `;
    }

    // AI Analysis Section Builder
    let aiHTML = '';
    if (ad.aiAnalysis) {
      const ai = ad.aiAnalysis;
      aiHTML = `
        <div class="ai-analysis-box">
          <div class="ai-analysis-header">
            <span>🔮 AI Copyscript Audit</span>
            <span style="color: #fbbf24; font-weight: 700;">★ Hook: ${esc(ai.hookStrength == null ? '?' : ai.hookStrength)}/10</span>
          </div>
          <div class="ai-analysis-item"><span class="ai-analysis-label">Hook Angle:</span><span class="ai-analysis-val">${esc(ai.hookExplanation || '-')}</span></div>
          <div class="ai-analysis-item"><span class="ai-analysis-label">Offers:</span><span class="ai-analysis-val">${esc((Array.isArray(ai.offers) ? ai.offers.join(', ') : ai.offers) || 'None')}</span></div>
          <div class="ai-analysis-item"><span class="ai-analysis-label">Target Pain Points:</span><span class="ai-analysis-val">${esc((Array.isArray(ai.painPoints) ? ai.painPoints.join(', ') : ai.painPoints) || 'None')}</span></div>
          <div class="ai-analysis-item"><span class="ai-analysis-label">Framework:</span><span class="ai-analysis-val">${esc(ai.framework || '-')}</span></div>
          <div class="ai-analysis-item"><span class="ai-analysis-val">${esc(ai.funnelStage || '-')}</span></div>
        </div>
      `;
    } else {
      aiHTML = `
        <button class="btn-ai-audit" data-id="${esc(ad.libraryId)}" style="margin-top: 8px; width: 100%; border: 1px dashed rgba(99, 102, 241, 0.4); background: rgba(99, 102, 241, 0.05); color: #a5b4fc; font-size: 9px; padding: 6px; border-radius: 6px; cursor: pointer; font-weight: 600;">🔮 Analyze with AI</button>
      `;
    }

    // Split-test variation drawer: what changed in each variation compared with the first ad
    let variationHTML = '';
    if (group.length > 1) {
      const changedFields = new Set();
      const rows = group.slice(1).map((extra, idx) => {
        const changes = describeVariation(ad, extra);
        changes.fields.forEach(f => changedFields.add(f));
        const thumb = adImageSrc(extra);
        return `
          <div class="var-row">
            ${thumb ? `<img class="var-thumb" src="${safeUrl(thumb, { allowData: true })}" alt="">` : '<div class="var-thumb var-thumb-empty"></div>'}
            <div class="var-info">
              <div class="var-head">
                <span>Var #${idx + 2} · ${esc(extra.startedDate || 'Unknown start')}</span>
                <button type="button" class="btn-icon ad-delete-var-btn" data-id="${esc(extra.libraryId)}" title="Delete this variation" aria-label="Delete this variation">🗑️</button>
              </div>
              ${changes.html}
            </div>
          </div>`;
      }).join('');
      const summary = changedFields.size ? `differs in ${[...changedFields].join(', ')}` : 'same copy';
      variationHTML = `
        <details class="ad-details-dropdown variation-drawer">
          <summary>📦 Split test: ${group.length} variations · ${esc(summary)}</summary>
          <div class="var-list">${rows}</div>
        </details>
      `;
    }

    card.innerHTML = `
      <div class="ad-card-header">
        <img class="ad-card-avatar" src="${safeUrl(ad.profileImageData || ad.profileImage, { allowData: true }) || PLACEHOLDER_AVATAR}" alt="${esc(ad.advertiser)}">
        <div class="ad-card-meta">
          <span class="ad-card-brand">${esc(ad.advertiser)}</span>
          <span class="ad-card-dates">${esc(dateText)}</span>
        </div>
        <span class="ad-card-status ${activeClass}">${statusText}</span>
      </div>

      <div class="ad-card-body">${ad.primaryText ? esc(ad.primaryText) : '<i>No ad copy text body.</i>'}</div>

      ${mediaHTML}

      <div style="display: flex; gap: 6px; flex-wrap: wrap;">
        ${liveBadgeHTML}
        ${domainBadgeHTML}
        ${folderBadgeHTML}
        ${localBadgeHTML}
      </div>

      ${ad.note ? `<div class="ad-note" title="Your note">📝 ${esc(ad.note)}</div>` : ''}

      ${detailsHTML}
      ${aiHTML}
      ${variationHTML}

      <div class="ad-card-tags-area">
        ${tagsHTML}
        <button type="button" class="ad-tag-add-trigger" data-id="${esc(ad.libraryId)}">+ Tag</button>
      </div>

      <div class="ad-card-footer">
        ${ctaHTML}
        <div style="display: flex; gap: 4px;">
          <button type="button" class="ad-note-btn ad-delete-btn" title="Add a private note" data-id="${esc(ad.libraryId)}">📝 ${ad.note ? 'Edit note' : 'Note'}</button>
          <button type="button" class="ad-folder-btn ad-delete-btn" title="Assign to Folder" data-id="${esc(ad.libraryId)}">📁 Folder</button>
          <button type="button" class="ad-delete-btn ad-remove-btn" title="Delete saved ad" aria-label="Delete saved ad" data-id="${esc(ad.libraryId)}">🗑️</button>
        </div>
      </div>
    `;

    // Bind AI Audit button click if present
    const btnAi = card.querySelector('.btn-ai-audit');
    if (btnAi) {
      btnAi.addEventListener('click', (e) => {
        const id = e.target.getAttribute('data-id');
        runAICognitiveAnalysis(id, e.target);
      });
    }

    // Bind variation deletes
    card.querySelectorAll('.ad-delete-var-btn').forEach(vBtn => {
      vBtn.addEventListener('click', async (e) => {
        e.stopPropagation();
        e.preventDefault();
        const id = e.currentTarget.getAttribute('data-id');
        if (confirm(`Delete variation ${id}?`)) {
          await db.deleteAd(id);
          afterAdsDeleted();
        }
      });
    });

    // Bind Add Tag trigger
    card.querySelector('.ad-tag-add-trigger').addEventListener('click', (e) => {
      openTagPicker(e.currentTarget, e.currentTarget.getAttribute('data-id'));
    });

    // Bind Note editor
    card.querySelector('.ad-note-btn').addEventListener('click', (e) => {
      openNotePicker(e.currentTarget, e.currentTarget.getAttribute('data-id'));
    });

    // Bind Delete Tag triggers
    card.querySelectorAll('.ad-tag-delete').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();
        const id = e.currentTarget.getAttribute('data-id');
        const tag = e.currentTarget.getAttribute('data-tag');
        await db.removeTagFromAd(id, tag);
        loadSavedAdsView();
      });
    });

    // Bind Folder Assign trigger
    card.querySelector('.ad-folder-btn').addEventListener('click', (e) => {
      openFolderPicker(e.currentTarget, e.currentTarget.getAttribute('data-id'));
    });

    // Bind Delete Button event
    card.querySelector('.ad-remove-btn').addEventListener('click', async (e) => {
      const id = e.currentTarget.getAttribute('data-id');
      if (confirm('Delete this saved ad?')) {
        await db.deleteAd(id);
        card.remove();
        afterAdsDeleted();
      }
    });

    adsList.appendChild(card);
  });
}

// Folders lose deleted ads too, so refresh their counts; open Ad Library tabs un-mark them
function afterAdsDeleted() {
  loadAllViews();
  loadCollectionsView();
  notifyAdLibraryTabs();
}

async function filterAds() {
  const query = document.getElementById('ads-search-input').value.toLowerCase().trim();
  const selectedBrand = document.getElementById('ads-brand-filter').value;
  const selectedCollectionId = document.getElementById('ads-collection-filter').value;

  let allowedAdIds = null;
  if (selectedCollectionId) {
    const collections = await db.getCollections();
    const activeColl = collections.find(c => String(c.id) === selectedCollectionId);
    allowedAdIds = activeColl ? (activeColl.adIds || []) : [];
  }

  const selectedTag = document.getElementById('ads-tag-filter').value;
  const cards = document.querySelectorAll('.ad-card');
  let shown = 0;
  cards.forEach(card => {
    const id = card.dataset.id;
    const brand = card.dataset.brand;

    const matchesBrand = !selectedBrand || brand === selectedBrand;
    const matchesQuery = !query || query.split(/\s+/).every(word => (card.dataset.search || '').includes(word));
    const matchesCollection = !selectedCollectionId || (allowedAdIds && allowedAdIds.includes(id));
    const matchesTag = !selectedTag || (card.dataset.tags || '').split('\u0001').includes(selectedTag);

    if (matchesBrand && matchesQuery && matchesCollection && matchesTag) {
      card.classList.remove('hidden');
      shown++;
    } else {
      card.classList.add('hidden');
    }
  });

  const countEl = document.getElementById('ads-result-count');
  const filtered = query || selectedBrand || selectedCollectionId || selectedTag;
  if (countEl) {
    countEl.textContent = cards.length === 0 ? '' : (filtered ? `Showing ${shown} of ${cards.length} ads` : `${cards.length} ads`);
  }
  let noMatch = document.getElementById('ads-no-match');
  if (cards.length > 0 && shown === 0) {
    if (!noMatch) {
      noMatch = document.createElement('div');
      noMatch.id = 'ads-no-match';
      noMatch.className = 'empty-state';
      noMatch.innerHTML = '<p>No saved ads match these filters.</p><p class="hint">Clear the search box or pick "All" in the filters above.</p>';
      document.getElementById('ads-list').appendChild(noMatch);
    }
  } else if (noMatch) {
    noMatch.remove();
  }
  const delBtn = document.getElementById('btn-delete-collection');
  if (delBtn) delBtn.classList.toggle('hidden', !selectedCollectionId);
}

// Saved Brands View
async function loadBrandsView() {
  const advertisers = await db.getAdvertisers();
  const allAds = await db.getAds();
  const brandsList = document.getElementById('brands-list');
  brandsList.innerHTML = '';

  const watched = advertisers.filter(a => a.isWatched);
  document.getElementById('watch-card').classList.toggle('hidden', watched.length === 0);
  document.getElementById('watch-count').textContent = watched.length;

  if (advertisers.length === 0) {
    brandsList.innerHTML = `
      <div class="empty-state">
        <p>No brands collected yet.</p>
        <p class="hint">Brands are added automatically when you save their ads.</p>
      </div>
    `;
    return;
  }

  // Render SVG campaign scaling timeline chart at the top
  const chartHTML = generateTimelineChartSVG(allAds);
  if (chartHTML) {
    const tempDiv = document.createElement('div');
    tempDiv.innerHTML = chartHTML;
    brandsList.appendChild(tempDiv.firstElementChild);
  }

  advertisers.forEach(adv => {
    const row = document.createElement('div');
    row.className = 'brand-row';

    const countText = adv.totalAdsCollected === 1 ? '1 ad saved' : `${adv.totalAdsCollected} ads saved`;
    const brandAd = allAds.find(a => a.advertiser === adv.name && a.profileImageData);
    const avatarSrc = safeUrl(brandAd && brandAd.profileImageData, { allowData: true }) || safeUrl(adv.profileImage) || PLACEHOLDER_AVATAR;

    let transparencyHTML = '';
    if (adv.transparency) {
      const trans = adv.transparency;
      transparencyHTML = `
        <div class="brand-transparency-box">
          <div class="transparency-title">Transparency Stats</div>
          ${trans.businessName ? `<div class="transparency-item"><span class="transparency-label">Business:</span><span class="transparency-value">${esc(trans.businessName)}</span></div>` : ''}
          ${trans.pageCreated ? `<div class="transparency-item"><span class="transparency-label">Created:</span><span class="transparency-value">${esc(trans.pageCreated)}</span></div>` : ''}
          ${trans.country ? `<div class="transparency-item"><span class="transparency-label">Location:</span><span class="transparency-value">${esc(trans.country)}</span></div>` : ''}
          ${trans.mergedPages && trans.mergedPages.length > 0 ? `<div class="transparency-item"><span class="transparency-label">Merged:</span><span class="transparency-value">${esc(trans.mergedPages.join(', '))}</span></div>` : ''}
        </div>
      `;
    }

    const watchText = adv.isWatched ? '👁️ Unwatch' : '👁️ Watch';
    const watchClass = adv.isWatched ? 'btn-watch active' : 'btn-watch';
    const snapshotBtnHTML = adv.isWatched
      ? `<button class="brand-snapshot-btn" data-name="${esc(adv.name)}" title="Capture current saved ads list as monitored snapshot" style="font-size: 9px; padding: 2px 6px; cursor: pointer;">📸 Snapshot</button>`
      : '';

    row.innerHTML = `
      <img class="brand-row-avatar" src="${avatarSrc}" alt="">
      <div class="brand-row-info">
        <div class="brand-row-name">${esc(adv.name)}</div>
        <div class="brand-row-count">${countText}</div>
        ${adv.isWatched ? snapshotInfoHTML(adv, allAds) : ''}
        ${transparencyHTML}
      </div>
      <div class="brand-actions-col" style="display: flex; flex-direction: column; gap: 4px; align-items: flex-end; justify-content: center;">
        <button type="button" class="btn-icon btn-icon-danger brand-delete-btn" data-name="${esc(adv.name)}" title="Delete brand profile" aria-label="Delete brand profile ${esc(adv.name)}">🗑️</button>
        <button class="${watchClass}" data-name="${esc(adv.name)}" style="font-size: 9px; padding: 2px 6px; cursor: pointer;">${watchText}</button>
        ${snapshotBtnHTML}
      </div>
    `;

    row.querySelector('.brand-delete-btn').addEventListener('click', async (e) => {
      const name = e.currentTarget.getAttribute('data-name');
      if (confirm(`Delete competitor profile for ${name}? This does not remove their saved ads, only the brand metadata.`)) {
        await db.deleteAdvertiser(name);
        row.remove();
        loadAllViews();
      }
    });

    row.querySelector('.btn-watch').addEventListener('click', async (e) => {
      const name = e.currentTarget.getAttribute('data-name');
      const isWatchingNow = !e.currentTarget.classList.contains('active');
      chrome.runtime.sendMessage({
        action: 'TOGGLE_WATCH_ADVERTISER',
        name,
        isWatching: isWatchingNow
      }, (res) => {
        if (chrome.runtime.lastError) return;
        if (res && res.success) {
          notifyAdLibraryTabs();
          showToast(isWatchingNow
            ? `Watching ${name}. Take a 📸 Snapshot, then use "Check now" later to spot new ads.`
            : `Stopped watching ${name}.`
          );
          loadBrandsView();
        }
      });
    });

    if (adv.isWatched) {
      row.querySelector('.brand-snapshot-btn').addEventListener('click', async (e) => {
        const name = e.currentTarget.getAttribute('data-name');
        // Fetch advertiser's ads from IndexedDB
        const adsList = await db.getAds(name);
        const libraryIds = adsList.map(a => a.libraryId);

        chrome.runtime.sendMessage({
          action: 'SAVE_ADVERTISER_SNAPSHOT',
          name,
          libraryIds
        }, (res) => {
          if (chrome.runtime.lastError || !res || !res.success) {
            showToast('Could not save the snapshot. Try again.', 'error');
            return;
          }
          showToast(`Snapshot saved: ${libraryIds.length} ads are now the baseline for ${name}.`);
          loadBrandsView();
          notifyAdLibraryTabs();
        });
      });
    }

    brandsList.appendChild(row);
  });
}

// Folders/Collections View Operations
async function loadCollectionsView() {
  const collections = await db.getCollections();
  const filterSelect = document.getElementById('ads-collection-filter');
  const selectedVal = filterSelect.value;

  filterSelect.innerHTML = '<option value="">📁 All Folders</option>';
  collections.forEach(coll => {
    const opt = document.createElement('option');
    opt.value = String(coll.id);
    opt.textContent = `📁 ${coll.name} (${coll.adIds ? coll.adIds.length : 0})`;
    if (String(coll.id) === selectedVal) opt.selected = true;
    filterSelect.appendChild(opt);
  });
}

function createNewCollection(e) {
  openPicker(e.currentTarget, async () => ({
    title: 'New folder',
    input: {
      placeholder: 'Folder name, e.g. Q4 hooks',
      button: 'Create',
      onSubmit: async (name) => {
        const created = await db.saveCollection({ name, adIds: [], createdAt: Date.now() });
        closePicker();
        await loadCollectionsView();
        document.getElementById('ads-collection-filter').value = String(created.id);
        filterAds();
        showToast(`Folder "${name}" created. Use 📁 Folder on any ad to add it.`);
      }
    }
  }));
}

async function deleteSelectedCollection() {
  const select = document.getElementById('ads-collection-filter');
  const id = select.value;
  if (!id) return;
  const name = select.options[select.selectedIndex].textContent.replace(/^📁\s*/, '');
  if (!confirm(`Delete folder ${name}? The ads inside it stay saved.`)) return;
  await db.deleteCollection(id);
  select.value = '';
  await loadCollectionsView();
  loadSavedAdsView();
  showToast('Folder deleted.');
}

// History View
async function loadHistoryView() {
  const searches = await db.getSearches();
  const historyList = document.getElementById('history-list');
  historyList.innerHTML = '';

  if (searches.length === 0) {
    historyList.innerHTML = `
      <div class="empty-state">
        <p>No search history recorded.</p>
        <p class="hint">The extension logs your search setups automatically when visiting the Meta Ad Library.</p>
      </div>
    `;
    return;
  }

  searches.forEach(search => {
    const item = document.createElement('div');
    item.className = 'history-item';

    const date = new Date(search.timestamp).toLocaleDateString(undefined, {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });

    item.innerHTML = `
      <div class="history-item-left">
        <span class="history-item-keyword">${esc(search.keyword)}</span>
        <span class="history-item-meta">${esc(String(search.country || 'ALL').toUpperCase())} · ${esc(search.category)} · ${esc(date)}</span>
      </div>
      <div class="history-item-actions">
        <button type="button" class="btn-icon history-reopen-btn" title="Reopen this search" aria-label="Reopen search ${esc(search.keyword)}" data-url="${safeUrl(search.url)}">🔗</button>
        <button type="button" class="btn-icon btn-icon-danger history-delete-btn" title="Delete history entry" aria-label="Delete history entry ${esc(search.keyword)}" data-id="${esc(search.id)}">🗑️</button>
      </div>
    `;

    // Bind reopening URL
    item.querySelector('.history-reopen-btn').addEventListener('click', (e) => {
      const url = e.currentTarget.getAttribute('data-url');
      if (url) chrome.tabs.create({ url });
    });

    // Bind Delete History entry
    item.querySelector('.history-delete-btn').addEventListener('click', async (e) => {
      const id = e.currentTarget.getAttribute('data-id');
      await db.deleteSearch(id);
      item.remove();
      loadHistoryView();
    });

    historyList.appendChild(item);
  });
}

// 6. Data Exports
async function exportToExcel() {
  const ads = await db.getAds();
  const advertisers = await db.getAdvertisers();
  const searches = await db.getSearches();

  if (ads.length === 0) {
    showToast('No ads available to export.');
    return;
  }

  // Helper to escape XML special characters
  const escapeXML = (str) => {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&apos;');
  };

  // Build Sheet 1: Competitor Statistics
  let sheet1Rows = '';
  advertisers.forEach(adv => {
    const bizName = adv.transparency?.businessName || 'Unverified';
    const created = adv.transparency?.pageCreated || 'Unknown';
    const loc = adv.transparency?.country || 'Unknown';
    sheet1Rows += `
      <Row>
        <Cell><Data ss:Type="String">${escapeXML(adv.name)}</Data></Cell>
        <Cell><Data ss:Type="Number">${adv.totalAdsCollected || 0}</Data></Cell>
        <Cell><Data ss:Type="String">${escapeXML(bizName)}</Data></Cell>
        <Cell><Data ss:Type="String">${escapeXML(created)}</Data></Cell>
        <Cell><Data ss:Type="String">${escapeXML(loc)}</Data></Cell>
        <Cell><Data ss:Type="String">${escapeXML(adv.pageUrl || '')}</Data></Cell>
      </Row>
    `;
  });

  // Build Sheet 2: Saved Ads Flat List
  let sheet2Rows = '';
  ads.forEach(ad => {
    sheet2Rows += `
      <Row>
        <Cell><Data ss:Type="String">${escapeXML(ad.libraryId)}</Data></Cell>
        <Cell><Data ss:Type="String">${escapeXML(ad.advertiser)}</Data></Cell>
        <Cell><Data ss:Type="String">${escapeXML(ad.status)}</Data></Cell>
        <Cell><Data ss:Type="String">${escapeXML(ad.startedDate)}</Data></Cell>
        <Cell><Data ss:Type="String">${escapeXML((ad.platforms || []).join(', '))}</Data></Cell>
        <Cell><Data ss:Type="String">${escapeXML(ad.headline || '')}</Data></Cell>
        <Cell><Data ss:Type="String">${escapeXML(ad.description || '')}</Data></Cell>
        <Cell><Data ss:Type="String">${escapeXML(ad.cta || '')}</Data></Cell>
        <Cell><Data ss:Type="String">${escapeXML(ad.resolvedUrl || ad.ctaUrl || '')}</Data></Cell>
        <Cell><Data ss:Type="String">${escapeXML(ad.primaryText || '')}</Data></Cell>
        <Cell><Data ss:Type="String">${escapeXML((ad.tags || []).join(', '))}</Data></Cell>
        <Cell><Data ss:Type="String">${escapeXML(ad.note || '')}</Data></Cell>
        ${daysRunning(ad) == null ? '<Cell><Data ss:Type="String"></Data></Cell>' : `<Cell><Data ss:Type="Number">${daysRunning(ad)}</Data></Cell>`}
        <Cell><Data ss:Type="String">${escapeXML(ad.localPath || 'No Local Copy')}</Data></Cell>
      </Row>
    `;
  });

  // Build Sheet 3: Search Logs
  let sheet3Rows = '';
  searches.forEach(search => {
    const d = new Date(search.timestamp).toLocaleString();
    sheet3Rows += `
      <Row>
        <Cell><Data ss:Type="String">${escapeXML(search.keyword)}</Data></Cell>
        <Cell><Data ss:Type="String">${escapeXML(search.country)}</Data></Cell>
        <Cell><Data ss:Type="String">${escapeXML(search.category)}</Data></Cell>
        <Cell><Data ss:Type="String">${escapeXML(d)}</Data></Cell>
        <Cell><Data ss:Type="Number">${search.adCount || 0}</Data></Cell>
        <Cell><Data ss:Type="String">${escapeXML(search.url || '')}</Data></Cell>
      </Row>
    `;
  });

  // Construct XML Workbook template
  const xmlContent = `<?xml version="1.0"?>
<?mso-application progid="Excel.Sheet"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:o="urn:schemas-microsoft-com:office:office"
 xmlns:x="urn:schemas-microsoft-com:office:excel"
 xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:html="http://www.w3.org/TR/REC-html40">
  <DocumentProperties xmlns="urn:schemas-microsoft-com:office:office">
    <Author>Meta Competitor Intelligence</Author>
    <Created>${new Date().toISOString()}</Created>
  </DocumentProperties>

  <!-- Sheet 1 -->
  <Worksheet ss:Name="Competitor statistics">
    <Table>
      <Row>
        <Cell><Data ss:Type="String">Advertiser Name</Data></Cell>
        <Cell><Data ss:Type="String">Total Ads Saved</Data></Cell>
        <Cell><Data ss:Type="String">Verified Business Name</Data></Cell>
        <Cell><Data ss:Type="String">Page Created Date</Data></Cell>
        <Cell><Data ss:Type="String">Manager Location</Data></Cell>
        <Cell><Data ss:Type="String">Profile URL</Data></Cell>
      </Row>
      ${sheet1Rows}
    </Table>
  </Worksheet>

  <!-- Sheet 2 -->
  <Worksheet ss:Name="Active Ads Details">
    <Table>
      <Row>
        <Cell><Data ss:Type="String">Library ID</Data></Cell>
        <Cell><Data ss:Type="String">Advertiser</Data></Cell>
        <Cell><Data ss:Type="String">Status</Data></Cell>
        <Cell><Data ss:Type="String">Started Date</Data></Cell>
        <Cell><Data ss:Type="String">Platforms</Data></Cell>
        <Cell><Data ss:Type="String">Headline</Data></Cell>
        <Cell><Data ss:Type="String">Description</Data></Cell>
        <Cell><Data ss:Type="String">CTA Text</Data></Cell>
        <Cell><Data ss:Type="String">Resolved Destination URL</Data></Cell>
        <Cell><Data ss:Type="String">Ad Copy Text</Data></Cell>
        <Cell><Data ss:Type="String">Tags</Data></Cell>
        <Cell><Data ss:Type="String">Notes</Data></Cell>
        <Cell><Data ss:Type="String">Days Live</Data></Cell>
        <Cell><Data ss:Type="String">Local File Path</Data></Cell>
      </Row>
      ${sheet2Rows}
    </Table>
  </Worksheet>

  <!-- Sheet 3 -->
  <Worksheet ss:Name="Search History Logs">
    <Table>
      <Row>
        <Cell><Data ss:Type="String">Keyword Search</Data></Cell>
        <Cell><Data ss:Type="String">Country Code</Data></Cell>
        <Cell><Data ss:Type="String">Category</Data></Cell>
        <Cell><Data ss:Type="String">Logged Timestamp</Data></Cell>
        <Cell><Data ss:Type="String">Live Ads Count</Data></Cell>
        <Cell><Data ss:Type="String">Search Page URL</Data></Cell>
      </Row>
      ${sheet3Rows}
    </Table>
  </Worksheet>
</Workbook>`;

  triggerDownload(xmlContent, 'meta_competitor_intelligence_report.xls', 'application/vnd.ms-excel;charset=utf-8;');
}

// Full backup: ads (with notes, tags, thumbnails), brands, watch snapshots, folders and history
async function exportToJSON() {
  const [ads, advertisers, collections, searches] = await Promise.all([
    db.getAds(), db.getAdvertisers(), db.getCollections(), db.getSearches()
  ]);
  if (ads.length === 0 && advertisers.length === 0) {
    showToast('No ads available to export.');
    return;
  }
  const backup = {
    app: 'meta-competitor-intelligence',
    format: 2,
    version: chrome.runtime.getManifest().version,
    exportedAt: new Date().toISOString(),
    ads,
    advertisers,
    collections,
    searches
  };
  const day = new Date().toISOString().slice(0, 10);
  triggerDownload(JSON.stringify(backup, null, 2), `meta_intelligence_backup_${day}.json`, 'application/json;charset=utf-8;');
  showToast(`Backup exported: ${ads.length} ads, ${advertisers.length} brands, ${collections.length} folders.`);
}

// CSV export (opens directly in Excel, Google Sheets, Numbers)
async function exportToCSV() {
  const ads = await db.getAds();
  if (ads.length === 0) {
    showToast('No ads available to export.');
    return;
  }

  const cell = (v) => {
    let str = String(v == null ? '' : v);
    // Neutralise spreadsheet formula injection from scraped text
    if (/^[=+\-@\t\r]/.test(str)) str = "'" + str;
    return `"${str.replace(/"/g, '""')}"`;
  };

  const header = ['Library ID', 'Advertiser', 'Status', 'Started Date', 'Platforms', 'Headline', 'Description',
    'CTA', 'Destination URL', 'Destination Domain', 'Ad Copy', 'Tags', 'Notes', 'Ended Date', 'Days Live',
    'Media Type', 'Media URL', 'Ad Library Link', 'Saved At'];
  const rows = ads.map(ad => [
    ad.libraryId,
    ad.advertiser,
    ad.status,
    ad.startedDate,
    (ad.platforms || []).join(', '),
    ad.headline,
    ad.description,
    ad.cta,
    ad.resolvedUrl || ad.ctaUrl,
    ad.resolvedDomain,
    ad.primaryText,
    (ad.tags || []).join(', '),
    ad.note,
    ad.endedDate,
    daysRunning(ad),
    ad.mediaType,
    ad.mediaType === 'video' ? ad.videoUrl : (ad.mediaUrls || [])[0],
    `https://www.facebook.com/ads/library/?id=${ad.libraryId}`,
    ad.collectedAt ? new Date(ad.collectedAt).toISOString() : ''
  ].map(cell).join(','));

  // BOM so Excel detects UTF-8 (emoji / non-latin ad copy)
  const csv = '﻿' + [header.map(cell).join(','), ...rows].join('\r\n');
  triggerDownload(csv, 'meta_competitor_ads.csv', 'text/csv;charset=utf-8;');
}

// Restore ads from a JSON export (merges into the existing database)
async function importFromJSON(event) {
  const input = event.target;
  const file = input.files && input.files[0];
  input.value = '';
  if (!file) return;

  if (file.size > 300 * 1024 * 1024) {
    showToast('Import failed: the file is larger than 300 MB.', 'error');
    return;
  }

  try {
    const parsed = JSON.parse(await file.text());
    const list = Array.isArray(parsed) ? parsed : (parsed && Array.isArray(parsed.ads) ? parsed.ads : null);
    if (!list) throw new Error('Expected a backup made with "Export JSON".');

    let imported = 0;
    for (const item of list) {
      const ad = sanitizeImportedAd(item);
      if (!ad) continue;
      await db.saveAd(ad);
      imported++;
    }

    // Brand profiles (watch state, snapshots, transparency), folders and history from a full backup
    let brands = 0;
    let folders = 0;
    if (!Array.isArray(parsed)) {
      for (const adv of (Array.isArray(parsed.advertisers) ? parsed.advertisers : [])) {
        const clean = sanitizeImportedAdvertiser(adv);
        if (!clean) continue;
        await db.saveAdvertiser(clean);
        brands++;
      }
      const existing = await db.getCollections();
      for (const coll of (Array.isArray(parsed.collections) ? parsed.collections : [])) {
        if (!coll || typeof coll !== 'object') continue;
        const name = cleanStr(coll.name, 60).trim();
        if (!name) continue;
        const ids = cleanList(coll.adIds, 20000, 25).filter(id => /^\d+$/.test(id));
        const match = existing.find(c => c.name === name);
        if (match) {
          match.adIds = [...new Set([...(match.adIds || []), ...ids])];
          await db.saveCollection(match);
        } else {
          existing.push(await db.saveCollection({ name, adIds: ids, createdAt: Number(coll.createdAt) || Date.now() }));
        }
        folders++;
      }
      for (const search of (Array.isArray(parsed.searches) ? parsed.searches : []).slice(0, 300)) {
        if (!search || typeof search !== 'object' || !search.id) continue;
        if (!/^https:\/\/www\.facebook\.com\/ads\/library\//.test(cleanStr(search.url, 2000))) continue;
        await db.saveSearch({
          id: cleanStr(search.id, 300),
          keyword: cleanStr(search.keyword, 200),
          country: cleanStr(search.country, 10),
          category: cleanStr(search.category, 40),
          url: cleanStr(search.url, 2000),
          timestamp: Number(search.timestamp) || Date.now(),
          adCount: Number(search.adCount) || 0
        });
      }
    }

    const extra = brands || folders ? `, ${brands} brand${brands === 1 ? '' : 's'} and ${folders} folder${folders === 1 ? '' : 's'}` : '';
    showToast(`Imported ${imported} ad${imported === 1 ? '' : 's'}${extra}.`);
    loadAllViews();
    loadCollectionsView();
    notifyAdLibraryTabs();
  } catch (err) {
    console.warn('Import failed:', err);
    showToast('Import failed: ' + err.message, 'error');
  }
}

// ---- Sanitising imported backups (a JSON file is untrusted input) ----
function cleanStr(v, max) {
  return (typeof v === 'string' ? v : (typeof v === 'number' ? String(v) : '')).slice(0, max);
}
function cleanList(v, maxItems, maxLen) {
  return Array.isArray(v) ? v.slice(0, maxItems).map(x => cleanStr(x, maxLen)).filter(Boolean) : [];
}
function cleanDataImage(v) {
  return typeof v === 'string' && /^data:image\/(jpeg|png|webp|gif);base64,/i.test(v) && v.length < 2000000 ? v : undefined;
}

function sanitizeImportedAd(item) {
  if (!item || typeof item !== 'object') return null;
  const libraryId = cleanStr(item.libraryId, 25).trim();
  if (!/^\d+$/.test(libraryId)) return null;
  const ad = {
    libraryId,
    advertiser: cleanStr(item.advertiser, 200) || 'Unknown Advertiser',
    pageUrl: cleanStr(item.pageUrl, 2000),
    profileImage: cleanStr(item.profileImage, 4000),
    status: item.status === 'inactive' ? 'inactive' : 'active',
    startedDate: cleanStr(item.startedDate, 60),
    endedDate: cleanStr(item.endedDate, 60),
    platforms: cleanList(item.platforms, 10, 40),
    primaryText: cleanStr(item.primaryText, 10000),
    headline: cleanStr(item.headline, 500),
    description: cleanStr(item.description, 1000),
    cta: cleanStr(item.cta, 100),
    ctaUrl: cleanStr(item.ctaUrl, 4000),
    mediaType: item.mediaType === 'video' ? 'video' : 'image',
    mediaUrls: cleanList(item.mediaUrls, 10, 4000),
    videoUrl: cleanStr(item.videoUrl, 4000),
    videoThumbnail: cleanStr(item.videoThumbnail, 4000),
    resolvedUrl: cleanStr(item.resolvedUrl, 4000),
    resolvedDomain: cleanStr(item.resolvedDomain, 300),
    localPath: cleanStr(item.localPath, 500),
    tags: [...new Set(cleanList(item.tags, 30, 60))],
    note: cleanStr(item.note, 2000),
    additionalLinks: cleanList(item.additionalLinks, 50, 2000),
    additionalTexts: cleanList(item.additionalTexts, 50, 2000),
    advertiserInfo: cleanStr(item.advertiserInfo, 2000),
    collectedAt: Number(item.collectedAt) || Date.now()
  };
  const thumb = cleanDataImage(item.thumbnailData);
  if (thumb) ad.thumbnailData = thumb;
  const avatar = cleanDataImage(item.profileImageData);
  if (avatar) ad.profileImageData = avatar;
  if (typeof item.imageHash === 'string' && /^([01]{64}|[01]{320})$/.test(item.imageHash)) {
    ad.imageHash = item.imageHash;
    ad.imageHashVersion = Number(item.imageHashVersion) || 0;
  }
  if (item.utmParams && typeof item.utmParams === 'object') {
    ad.utmParams = {};
    Object.keys(item.utmParams).slice(0, 20).forEach(k => {
      if (/^utm_[\w-]{1,40}$/.test(k)) ad.utmParams[k] = cleanStr(item.utmParams[k], 300);
    });
  }
  if (item.aiAnalysis && typeof item.aiAnalysis === 'object') {
    try { ad.aiAnalysis = sanitizeAIResult(item.aiAnalysis); } catch (e) { /* drop invalid analysis */ }
  }
  // Empty values must not wipe data that is already saved for the same ad
  Object.keys(ad).forEach(k => {
    const v = ad[k];
    if (v === '' || (Array.isArray(v) && v.length === 0)) delete ad[k];
  });
  return ad;
}

function sanitizeImportedAdvertiser(adv) {
  if (!adv || typeof adv !== 'object') return null;
  const name = cleanStr(adv.name, 200).trim();
  if (!name) return null;
  const clean = { name };
  if (/^https:\/\/www\.facebook\.com\/ads\/library\//.test(cleanStr(adv.pageUrl, 2000))) clean.pageUrl = cleanStr(adv.pageUrl, 2000);
  if (typeof adv.isWatched === 'boolean') clean.isWatched = adv.isWatched;
  if (Array.isArray(adv.snapshotIds)) clean.snapshotIds = cleanList(adv.snapshotIds, 20000, 25).filter(id => /^\d+$/.test(id));
  if (Number(adv.lastSnapshotAt)) clean.lastSnapshotAt = Number(adv.lastSnapshotAt);
  if (Number(adv.firstSeen)) clean.firstSeen = Number(adv.firstSeen);
  if (adv.transparency && typeof adv.transparency === 'object') {
    const t = adv.transparency;
    clean.transparency = {
      businessName: cleanStr(t.businessName, 200),
      pageCreated: cleanStr(t.pageCreated, 60),
      country: cleanStr(t.country, 100),
      mergedPages: cleanList(t.mergedPages, 20, 200)
    };
  }
  return clean;
}

async function urlToBase64(url) {
  if (!url || url.startsWith('data:')) return url;
  try {
    // Timeout-guarded fetch to avoid hanging on slow responses
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 6000);

    const res = await fetch(url, { signal: controller.signal });
    clearTimeout(timeoutId);
    if (!res.ok) return url;

    const blob = await res.blob();
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result);
      reader.onerror = () => resolve(url);
      reader.readAsDataURL(blob);
    });
  } catch (error) {
    console.warn('Failed to fetch image for base64 conversion:', url, error);
    return url; // fallback to original URL if CORS block or offline
  }
}

async function exportHTMLReport() {
  const ads = await db.getAds();
  if (ads.length === 0) {
    showToast('No ads available to generate report.');
    return;
  }

  const btnReport = document.getElementById('btn-export-report');
  const originalText = btnReport.innerText;
  btnReport.innerText = '⏳ Compiling Assets...';
  btnReport.disabled = true;

  try {
    const cardHtmlPromises = ads.map(async (ad) => {
      const isVideo = ad.mediaType === 'video';
      let mediaDisplay = '';

      // Convert advertiser avatar to base64
      let avatarBase64 = PLACEHOLDER_AVATAR;
      if (ad.profileImageData) {
        avatarBase64 = ad.profileImageData;
      } else if (ad.profileImage) {
        avatarBase64 = await urlToBase64(ad.profileImage);
      }
      avatarBase64 = safeUrl(avatarBase64, { allowData: true }) || PLACEHOLDER_AVATAR;

      if (isVideo) {
        // Base64 encode the video poster frame. Video streams remain links due to size limits.
        let posterBase64 = ad.thumbnailData || ad.videoThumbnail || '';
        if (posterBase64 && !ad.thumbnailData) {
          posterBase64 = await urlToBase64(posterBase64);
        }
        posterBase64 = safeUrl(posterBase64, { allowData: true });

        mediaDisplay = `
          <div style="margin: 12px 0; border-radius: 8px; overflow: hidden; background: #000; position: relative;">
            <div style="position: absolute; top: 8px; left: 8px; background: rgba(0,0,0,0.8); color:#fff; font-size: 10px; font-weight:bold; padding: 2px 6px; border-radius:4px;">▶ Video</div>
            <video controls poster="${posterBase64}" style="width:100%; display:block;" src="${safeUrl(ad.videoUrl)}"></video>
          </div>`;
      } else if (ad.thumbnailData || (ad.mediaUrls && ad.mediaUrls.length > 0)) {
        // Base64 encode the creative image (stored thumbnail first: CDN links expire)
        let creativeBase64 = ad.thumbnailData || await urlToBase64(ad.mediaUrls[0]);
        creativeBase64 = safeUrl(creativeBase64, { allowData: true });
        mediaDisplay = `<img src="${creativeBase64}" style="width: 100%; border-radius: 8px; margin: 12px 0; object-fit: cover; max-height: 400px;" />`;
      }

      const ctaBadge = ad.cta ? `<span style="background: #e0e7ff; color: #4f46e5; padding: 4px 8px; border-radius: 4px; font-size: 11px; font-weight: 600;">${esc(ad.cta)}</span>` : '';
      const destUrl = safeUrl(ad.resolvedUrl || ad.ctaUrl);

      return `
        <div style="background: #ffffff; border: 1px solid #e2e8f0; border-radius: 12px; padding: 20px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); display: flex; flex-direction: column; gap: 12px;">
          <div style="display: flex; align-items: center; gap: 12px; border-bottom: 1px solid #f1f5f9; padding-bottom: 12px;">
            <img src="${avatarBase64}" style="width: 40px; height: 40px; border-radius: 50%; object-fit: cover;" />
            <div style="flex: 1;">
              <h3 style="margin: 0; font-size: 14px; font-weight: 700; color: #1e293b;">${esc(ad.advertiser)}</h3>
              <p style="margin: 0; font-size: 11px; color: #64748b;">Library ID: ${esc(ad.libraryId)} · Started: ${esc(ad.startedDate || 'Unknown')}</p>
            </div>
            <span style="font-size: 10px; font-weight: 700; text-transform: uppercase; padding: 2px 8px; border-radius: 20px; ${ad.status === 'active' ? 'background: #d1fae5; color: #065f46;' : 'background: #fee2e2; color: #991b1b;'}">${esc(ad.status)}</span>
          </div>

          <div style="font-size: 13px; color: #334155; line-height: 1.6; white-space: pre-wrap; word-break: break-word;">${ad.primaryText ? esc(ad.primaryText) : '<i>No ad copy.</i>'}</div>

          ${mediaDisplay}

          ${ad.headline ? `<div style="font-size: 14px; font-weight: 700; color: #0f172a;">${esc(ad.headline)}</div>` : ''}
          ${ad.note ? `<div style="font-size: 12px; color: #713f12; background: #fef9c3; border-radius: 6px; padding: 8px 10px;">📝 ${esc(ad.note)}</div>` : ''}
          ${(ad.tags || []).length ? `<div style="font-size: 11px; color: #4338ca;">${(ad.tags || []).map(t => `#${esc(t)}`).join(' ')}</div>` : ''}

          <div style="display: flex; justify-content: space-between; align-items: center; margin-top: auto; border-top: 1px solid #f1f5f9; padding-top: 12px;">
            ${ctaBadge}
            ${destUrl ? `<a href="${destUrl}" target="_blank" rel="noopener noreferrer" style="font-size: 12px; color: #4f46e5; text-decoration: none; font-weight:500;">View Destination Link ↗</a>` : ''}
          </div>
        </div>
      `;
    });

    const cardHtmlList = (await Promise.all(cardHtmlPromises)).join('');

    const reportHtml = `
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="Content-Security-Policy" content="default-src 'none'; img-src data: https:; media-src https:; style-src 'unsafe-inline'">
        <title>Meta Ad Competitor Intelligence Report</title>
        <style>
          body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; background-color: #f8fafc; color: #0f172a; margin: 0; padding: 0; }
          header { background: linear-gradient(135deg, #1e1b4b, #0f172a); color: #fff; padding: 30px 20px; text-align: center; border-bottom: 4px solid #6366f1; }
          header h1 { margin: 0 0 8px 0; font-size: 24px; font-weight: 800; }
          header p { margin: 0; font-size: 14px; color: #94a3b8; }
          .container { max-width: 1200px; margin: 40px auto; padding: 0 20px; }
          .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(360px, 1fr)); gap: 24px; }
          footer { margin-top: 60px; padding: 24px; text-align: center; color: #64748b; font-size: 12px; border-top: 1px solid #e2e8f0; }
        </style>
      </head>
      <body>
        <header>
          <h1>Meta Ad Swipe Report</h1>
          <p>Generated by Meta Competitor Intelligence on ${new Date().toLocaleDateString()} · Stored Count: ${ads.length} Ads</p>
        </header>
        <div class="container">
          <div class="grid">
            ${cardHtmlList}
          </div>
        </div>
        <footer>
          Generated locally. All rights reserved.
        </footer>
      </body>
      </html>
    `;

    triggerDownload(reportHtml, 'meta_intelligence_swipe_file.html', 'text/html;charset=utf-8;');
  } catch (error) {
    console.error('Error generating HTML report:', error);
    showToast('Failed to generate HTML report: ' + error.message);
  } finally {
    btnReport.innerText = originalText;
    btnReport.disabled = false;
  }
}

function triggerDownload(content, filename, contentType) {
  const blob = new Blob([content], { type: contentType });
  const url = URL.createObjectURL(blob);

  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();

  document.body.removeChild(a);
  // Revoking immediately can cancel the download in some Chrome versions
  setTimeout(() => URL.revokeObjectURL(url), 10000);
}

// 7. Reset Database
async function resetDatabase() {
  if (confirm('Are you absolutely sure you want to delete ALL saved searches, brands, and ads from your database? This action is irreversible.')) {
    const database = await db.init();

    // Clear all stores
    const stores = ['searches', 'advertisers', 'ads', 'collections'];
    const transaction = database.transaction(stores, 'readwrite');

    stores.forEach(s => {
      transaction.objectStore(s).clear();
    });

    transaction.oncomplete = () => {
      showToast('Local intelligence database cleared successfully.');
      ['ads-search-input', 'ads-brand-filter', 'ads-collection-filter', 'ads-tag-filter'].forEach(id => {
        document.getElementById(id).value = '';
      });
      loadAllViews();
      loadCollectionsView();
      if (document.getElementById('insights-tab').classList.contains('active')) loadInsightsView();
      notifyAdLibraryTabs();
      detectActiveTabSearch();
    };

    transaction.onerror = (e) => {
      console.error('Clear database error:', e.target.error);
      showToast('Error clearing database.');
    };
  }
}

// 8. Settings Management
function loadSettings() {
  chrome.storage.local.get(['aiProvider', 'aiKey', 'aiModel', 'autoDownloadCreatives'], (res) => {
    if (res.aiProvider) document.getElementById('settings-ai-provider').value = res.aiProvider;
    if (res.aiKey) document.getElementById('settings-ai-key').value = res.aiKey;
    if (res.aiModel) document.getElementById('settings-ai-model').value = res.aiModel;
    document.getElementById('settings-auto-download').checked = res.autoDownloadCreatives !== false;
  });
}

function saveSettings() {
  const provider = document.getElementById('settings-ai-provider').value;
  const key = document.getElementById('settings-ai-key').value;
  const model = document.getElementById('settings-ai-model').value;

  chrome.storage.local.set({
    aiProvider: provider,
    aiKey: key.trim(),
    aiModel: model,
    autoDownloadCreatives: document.getElementById('settings-auto-download').checked
  }, () => {
    const status = document.getElementById('settings-status');
    status.classList.remove('hidden');
    setTimeout(() => status.classList.add('hidden'), 3000);
  });
}

// 9. BYOK AI Integration Client
async function runAICognitiveAnalysis(libraryId, buttonEl) {
  chrome.storage.local.get(['aiProvider', 'aiKey', 'aiModel'], async (res) => {
    const key = (res.aiKey || '').trim();
    const provider = res.aiProvider || 'gemini';
    // Fall back to a model that belongs to the selected provider
    let model = res.aiModel || '';
    if (provider === 'gemini' && !/^gemini/i.test(model)) model = 'gemini-2.5-flash';
    if (provider === 'openai' && /^gemini/i.test(model)) model = 'gpt-4o-mini';
    if (!model) model = provider === 'gemini' ? 'gemini-2.5-flash' : 'gpt-4o-mini';

    if (!key) {
      showToast('Please configure your API Key in the "⚙️ Settings" tab first.');
      return;
    }

    buttonEl.disabled = true;
    buttonEl.textContent = '🔮 Analyzing...';

    // Never leave the button spinning forever on a stalled connection
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 60000);
    // Error bodies are shown in a toast: make sure the key itself never appears there
    const cleanError = (text) => String(text || '').split(key).join('***').replace(/\s+/g, ' ').slice(0, 300);

    try {
      const ad = await db.getAd(libraryId);
      if (!ad) throw new Error('Ad not found');

      const textContent = `Advertiser: ${ad.advertiser}\nAd Copy: ${ad.primaryText || ''}\nHeadline: ${ad.headline || ''}\nDescription: ${ad.description || ''}`;
      const promptText = `
        You are an AI copywriting analyst. Analyze the following Meta ad. Respond STRICTLY in a valid raw JSON object matching this schema (do not wrap in markdown code blocks like \`\`\`json):
        {
          "hookStrength": 8,
          "hookExplanation": "Direct question targeting high energy bills.",
          "offers": ["Free Quote"],
          "painPoints": ["High energy bills", "Poor airflow"],
          "framework": "PAS (Problem-Agitate-Solve)",
          "funnelStage": "TOF (Top of Funnel)"
        }

        Note: The framework should specify which copywriting framework matches best (AIDA, PAS, BAB, or USP). The funnelStage should evaluate TOF (Top of Funnel), MOF (Middle of Funnel), or BOF (Bottom of Funnel) with a short 1-sentence reason.

        AD DETAILS TO ANALYZE:
        ${textContent}
      `;

      let aiResult = null;

      if (provider === 'gemini') {
        // API key goes in a header rather than the URL so it does not end up in logs
        const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'x-goog-api-key': key },
          signal: controller.signal,
          body: JSON.stringify({
            contents: [{ parts: [{ text: promptText }] }],
            generationConfig: { responseMimeType: 'application/json' }
          })
        });

        if (!response.ok) {
          const errText = await response.text();
          throw new Error(`Gemini API Error: ${response.status} - ${cleanError(errText)}`);
        }

        const data = await response.json();
        const rawText = data.candidates?.[0]?.content?.parts?.[0]?.text;
        aiResult = parseAIJson(rawText);
      } else {
        // OpenAI
        const response = await fetch('https://api.openai.com/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${key}`
          },
          signal: controller.signal,
          body: JSON.stringify({
            model: model,
            messages: [{ role: 'user', content: promptText }],
            response_format: { type: 'json_object' }
          })
        });

        if (!response.ok) {
          const errText = await response.text();
          throw new Error(`OpenAI API Error: ${response.status} - ${cleanError(errText)}`);
        }

        const data = await response.json();
        const rawText = data.choices?.[0]?.message?.content;
        aiResult = parseAIJson(rawText);
      }

      if (aiResult) {
        const analysis = Object.assign(sanitizeAIResult(aiResult), { model, analyzedAt: Date.now() });
        // Patch only this field: tags or notes may have changed while the AI was busy
        await db.updateAd(libraryId, { aiAnalysis: analysis });
        showToast('AI Analysis completed successfully!');
        loadSavedAdsView();
      }
    } catch (err) {
      const msg = err && err.name === 'AbortError' ? 'the AI provider did not answer within 60 seconds.' : cleanError(err && err.message);
      console.warn('AI Analysis failed:', msg);
      showToast('AI Analysis failed: ' + msg, 'error');
    } finally {
      clearTimeout(timeoutId);
      buttonEl.disabled = false;
      buttonEl.textContent = '🔮 Analyze with AI';
    }
  });
}

// Keep only the expected fields, with sane types and sizes (model output is untrusted)
function sanitizeAIResult(r) {
  if (!r || typeof r !== 'object' || Array.isArray(r)) throw new Error('The AI response was not a JSON object.');
  const list = (v) => (Array.isArray(v) ? v : (v ? [v] : [])).slice(0, 10).map(x => String(x).slice(0, 200));
  const hook = Number(r.hookStrength);
  const out = {
    hookStrength: Number.isFinite(hook) ? Math.max(0, Math.min(10, Math.round(hook))) : null,
    hookExplanation: String(r.hookExplanation || '').slice(0, 500),
    offers: list(r.offers),
    painPoints: list(r.painPoints),
    framework: String(r.framework || '').slice(0, 120),
    funnelStage: String(r.funnelStage || '').slice(0, 300)
  };
  if (r.model) out.model = String(r.model).slice(0, 60);
  if (Number(r.analyzedAt)) out.analyzedAt = Number(r.analyzedAt);
  return out;
}

// Parse model output that should be JSON (tolerates ```json fences and surrounding text)
function parseAIJson(rawText) {
  if (!rawText) throw new Error('The AI returned an empty response.');
  let text = String(rawText).trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
  const start = text.indexOf('{');
  const end = text.lastIndexOf('}');
  if (start !== -1 && end > start) text = text.slice(start, end + 1);
  return JSON.parse(text);
}

// 10. Canvas Perceptual Hashing & Variation Clustering Engine
// Two hashes per image: a 64-bit average hash (overall light/dark layout) and a 256-bit
// difference hash on a 16x16 grid (edges: text, product, faces). Creatives from one brand
// template (same background, different product or headline) share an average hash, so
// both must match before two ads count as the same creative.
function greyBlocks(img, cols, rows) {
  const canvas = document.createElement('canvas');
  canvas.width = cols * 4;
  canvas.height = rows * 4;
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
  const data = ctx.getImageData(0, 0, canvas.width, canvas.height).data;
  const greys = new Array(cols * rows).fill(0);
  // Average 4x4 pixel blocks: a direct tiny draw only samples a few pixels, so the same
  // creative at two sizes could hash differently.
  for (let y = 0; y < canvas.height; y++) {
    for (let x = 0; x < canvas.width; x++) {
      const i = (y * canvas.width + x) * 4;
      const grey = data[i] * 0.299 + data[i + 1] * 0.587 + data[i + 2] * 0.114;
      greys[(y >> 2) * cols + (x >> 2)] += grey / 16;
    }
  }
  return greys;
}

function calculateImagePHash(src) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      try {
        const a = greyBlocks(img, 8, 8);
        const avg = a.reduce((x, y) => x + y, 0) / 64;
        let hash = '';
        for (let i = 0; i < 64; i++) hash += a[i] >= avg ? '1' : '0';

        const d = greyBlocks(img, 17, 16);
        for (let r = 0; r < 16; r++) {
          for (let c = 0; c < 16; c++) hash += d[r * 17 + c] > d[r * 17 + c + 1] ? '1' : '0';
        }
        resolve(hash);
      } catch (e) {
        reject(e);
      }
    };
    img.onerror = () => reject(new Error('image could not be loaded'));
    img.src = src;
  });
}

const pHashFailed = new Set(); // ads whose image could not be hashed this session
const PHASH_VERSION = 4; // bump to recompute stored hashes after an algorithm change

async function ensureAdImageHash(ad) {
  if (ad.imageHash && ad.imageHashVersion === PHASH_VERSION) return ad.imageHash;
  if (ad.mediaType !== 'image' || pHashFailed.has(ad.libraryId)) return null;
  // Hash the stored thumbnail. A just-saved ad gets it a moment later from the background
  // worker; Meta's CDN does not allow reading the original image from a canvas.
  const src = ad.thumbnailData || (ad.collectedAt < Date.now() - 60000 ? (ad.mediaUrls && ad.mediaUrls[0]) : '');
  if (!src) return null;

  try {
    const hash = await calculateImagePHash(src);
    if (hash) {
      ad.imageHash = hash;
      ad.imageHashVersion = PHASH_VERSION;
      // Patch just the hash: re-saving the whole (older) copy would undo newer edits
      await db.updateAd(ad.libraryId, { imageHash: hash, imageHashVersion: PHASH_VERSION });
      return hash;
    }
  } catch (err) {
    pHashFailed.add(ad.libraryId);
  }
  return null;
}

function getHammingDistance(h1, h2) {
  if (!h1 || !h2 || h1.length !== h2.length) return 99;
  let dist = 0;
  for (let i = 0; i < h1.length; i++) {
    if (h1[i] !== h2[i]) dist++;
  }
  return dist;
}

// Same creative: both the average hash and the difference hash are close
// (thresholds measured on re-encoded/rescaled copies vs. different creatives)
function sameCreative(h1, h2) {
  if (!h1 || !h2 || h1.length !== 320 || h2.length !== 320) return false;
  return getHammingDistance(h1.slice(0, 64), h2.slice(0, 64)) <= 6 &&
         getHammingDistance(h1.slice(64), h2.slice(64)) <= 12;
}

async function clusterAdsByVariation(ads) {
  // Compute any missing hashes first
  for (const ad of ads) {
    if (ad.mediaType === 'image' && (!ad.imageHash || ad.imageHashVersion !== PHASH_VERSION) && !pHashFailed.has(ad.libraryId)) {
      await ensureAdImageHash(ad);
    }
  }

  const groups = [];
  const visited = new Set();

  for (let i = 0; i < ads.length; i++) {
    const adA = ads[i];
    if (visited.has(adA.libraryId)) continue;

    const group = [adA];
    visited.add(adA.libraryId);

    for (let j = i + 1; j < ads.length; j++) {
      const adB = ads[j];
      if (visited.has(adB.libraryId)) continue;

      if (adA.advertiser !== adB.advertiser) continue;

      let isSimilar = false;

      // Group by image similarity (same creative re-used with different copy)
      if (sameCreative(adA.imageHash, adB.imageHash)) isSimilar = true;

      // Group by text content equivalence
      if (!isSimilar && adA.primaryText && adB.primaryText) {
        const cleanA = adA.primaryText.toLowerCase().replace(/[^a-z0-9]/g, '');
        const cleanB = adB.primaryText.toLowerCase().replace(/[^a-z0-9]/g, '');
        if (cleanA === cleanB) isSimilar = true;
      }

      if (isSimilar) {
        group.push(adB);
        visited.add(adB.libraryId);
      }
    }
    groups.push(group);
  }
  // Show the earliest-launched ad as the original; later ones read as its variations
  groups.forEach(g => g.sort((a, b) => {
    const da = parseStartedDate(a.startedDate);
    const dbt = parseStartedDate(b.startedDate);
    return (da ? da.getTime() : Infinity) - (dbt ? dbt.getTime() : Infinity);
  }));
  return groups;
}

// 11. campaign scaling timeline charts (SVG)
let timelineChartSeq = 0;
function generateTimelineChartSVG(ads) {
  if (!ads || ads.length === 0) return '';

  const monthCounts = {};
  const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

  // Works for both "13 Oct 2025" and "Oct 13, 2025" style dates
  ads.forEach(ad => {
    const d = parseStartedDate(ad.startedDate);
    if (!d) return;
    const key = `${monthNames[d.getMonth()]} ${d.getFullYear()}`;
    monthCounts[key] = (monthCounts[key] || 0) + 1;
  });

  const keys = Object.keys(monthCounts);
  if (keys.length === 0) return '';

  // Sort keys chronologically
  keys.sort((a, b) => {
    const parseMonthYear = (str) => {
      const p = str.split(' ');
      const mIdx = monthNames.indexOf(p[0]);
      const y = parseInt(p[1]) || 0;
      return new Date(y, mIdx, 1);
    };
    return parseMonthYear(a) - parseMonthYear(b);
  });

  // Unique gradient id: the chart is rendered in both the Brands and Insights tabs
  const gradId = `barGradient${++timelineChartSeq}`;
  const width = 320;
  const height = 100;
  const padding = 20;
  const graphWidth = width - padding * 2;
  const graphHeight = height - padding * 2;

  const maxVal = Math.max(...keys.map(k => monthCounts[k]));
  const stepX = keys.length > 1 ? graphWidth / (keys.length - 1) : graphWidth;

  let points = '';
  let labels = '';
  let gridLines = '';

  gridLines += `<line x1="${padding}" y1="${padding}" x2="${width - padding}" y2="${padding}" stroke="rgba(255,255,255,0.05)" stroke-width="1" />`;
  gridLines += `<line x1="${padding}" y1="${padding + graphHeight/2}" x2="${width - padding}" y2="${padding + graphHeight/2}" stroke="rgba(255,255,255,0.05)" stroke-width="1" />`;
  gridLines += `<line x1="${padding}" y1="${padding + graphHeight}" x2="${width - padding}" y2="${padding + graphHeight}" stroke="rgba(255,255,255,0.1)" stroke-width="1.5" />`;

  keys.forEach((key, idx) => {
    const val = monthCounts[key];
    const x = padding + (idx * stepX);
    const y = padding + graphHeight - (maxVal > 0 ? (val / maxVal) * graphHeight : 0);

    points += `
      <rect x="${x - 6}" y="${y}" width="12" height="${padding + graphHeight - y}" fill="url(#${gradId})" rx="2" />
      <text x="${x}" y="${y - 4}" fill="#a5b4fc" font-size="7" font-weight="700" text-anchor="middle">${val}</text>
    `;

    labels += `<text x="${x}" y="${height - 4}" fill="var(--text-secondary)" font-size="7" text-anchor="middle">${esc(key)}</text>`;
  });

  return `
    <div class="panel-card timeline-chart-card" style="margin-bottom: 12px; padding: 10px;">
      <h4 style="margin: 0 0 8px 0; font-size: 10px; color: var(--text-primary); text-transform: uppercase; letter-spacing: 0.05em; display: flex; align-items: center; gap: 4px;">📈 New ads launched per month</h4>
      <svg width="100%" height="${height}" viewBox="0 0 ${width} ${height}" preserveAspectRatio="xMidYMid meet" style="display: block;">
        <defs>
          <linearGradient id="${gradId}" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stop-color="#6366f1" stop-opacity="0.8" />
            <stop offset="100%" stop-color="#4f46e5" stop-opacity="0.1" />
          </linearGradient>
        </defs>
        ${gridLines}
        ${points}
        ${labels}
      </svg>
    </div>
  `;
}


// ===================================================================
// 12. v1.2 additions: toasts, pickers, variation diffs, insights,
//     watched-brand checks, onboarding and keyboard shortcuts
// ===================================================================

let folderNamesByAd = {};

// Toasts replace blocking alert() dialogs
let toastTimer = null;
function showToast(message, type) {
  const el = document.getElementById('toast');
  if (!el) return;
  const isError = type === 'error' || (type === undefined && /fail|error|please/i.test(String(message)));
  el.textContent = String(message);
  el.classList.toggle('toast-error', isError);
  el.classList.remove('hidden');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.add('hidden'), isError ? 6000 : 3500);
}

async function getAdById(libraryId) {
  const store = await db.getStore('ads', 'readonly');
  return new Promise((resolve) => {
    const req = store.get(libraryId);
    req.onsuccess = () => resolve(req.result || null);
    req.onerror = () => resolve(null);
  });
}

// ---- Inline picker (replaces prompt() for folders and tags) ----
let pickerState = null;

async function openPicker(anchor, build) {
  pickerState = { anchor, build };
  await renderPicker();
}

function closePicker() {
  const anchor = pickerState && pickerState.anchor;
  pickerState = null;
  const el = document.getElementById('picker');
  el.classList.add('hidden');
  el.innerHTML = '';
  // Return keyboard focus to the button that opened the picker
  if (anchor && anchor.isConnected && el.contains(document.activeElement) === false) anchor.focus({ preventScroll: true });
}

async function renderPicker() {
  if (!pickerState) return;
  const el = document.getElementById('picker');
  const cfg = await pickerState.build();
  const items = cfg.items || [];
  const suggestions = cfg.suggestions || [];

  el.innerHTML = `
    <div class="picker-title">${esc(cfg.title)}</div>
    ${items.length ? `<div class="picker-items">${items.map((it, i) => `
      <button type="button" class="picker-item${it.checked ? ' checked' : ''}" data-i="${i}">
        <span class="picker-check">${it.checked ? '✓' : ''}</span>
        <span class="picker-label">${esc(it.label)}</span>
        ${it.meta != null ? `<span class="picker-meta">${esc(it.meta)}</span>` : ''}
      </button>`).join('')}</div>` : (cfg.emptyText ? `<div class="picker-empty">${esc(cfg.emptyText)}</div>` : '')}
    ${suggestions.length ? `<div class="picker-suggestions">${suggestions.map((sug, i) => `<button type="button" class="picker-chip" data-s="${i}">+ ${esc(sug)}</button>`).join('')}</div>` : ''}
    ${cfg.input ? `<form class="picker-form"><input type="text" maxlength="60" placeholder="${esc(cfg.input.placeholder)}" aria-label="${esc(cfg.input.placeholder)}" autocomplete="off"><button type="submit" class="btn btn-primary btn-inline">${esc(cfg.input.button || 'Add')}</button></form>` : ''}
    ${cfg.textarea ? `<form class="picker-form picker-form-note"><textarea maxlength="2000" rows="5" placeholder="${esc(cfg.textarea.placeholder)}" aria-label="${esc(cfg.title)}">${esc(cfg.textarea.value || '')}</textarea><div class="picker-note-row"><span class="picker-hint">Ctrl+Enter to save</span><button type="submit" class="btn btn-primary btn-inline">${esc(cfg.textarea.button || 'Save')}</button></div></form>` : ''}
  `;
  el.setAttribute('aria-label', cfg.title || 'Picker');

  el.querySelectorAll('.picker-item').forEach(btn => btn.addEventListener('click', async () => {
    const it = items[Number(btn.dataset.i)];
    await it.onToggle(!it.checked);
    await renderPicker();
  }));
  el.querySelectorAll('.picker-chip').forEach(btn => btn.addEventListener('click', async () => {
    await cfg.onSuggestion(suggestions[Number(btn.dataset.s)]);
    await renderPicker();
  }));
  const form = el.querySelector('.picker-form');
  if (form) {
    const field = form.querySelector('input, textarea');
    const target = cfg.textarea || cfg.input;
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const value = field.value.trim();
      if (!value && !cfg.textarea) return;
      await target.onSubmit(value);
      if (pickerState) await renderPicker();
    });
    if (cfg.textarea) {
      field.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
          e.preventDefault();
          form.requestSubmit();
        }
      });
    }
  }

  // Position next to the anchor, kept inside the panel
  el.classList.remove('hidden');
  const anchorEl = pickerState && pickerState.anchor;
  if (anchorEl && anchorEl.isConnected) {
    const r = anchorEl.getBoundingClientRect();
    const w = el.offsetWidth;
    const h = el.offsetHeight;
    let top = r.bottom + 6;
    if (top + h > window.innerHeight - 8) top = Math.max(8, r.top - h - 6);
    const left = Math.min(Math.max(8, r.left), window.innerWidth - w - 8);
    el.style.top = `${top}px`;
    el.style.left = `${left}px`;
  }
  const input = el.querySelector('.picker-form input, .picker-form textarea');
  if (input) {
    input.focus();
    if (input.tagName === 'TEXTAREA') input.setSelectionRange(input.value.length, input.value.length);
  }
}

document.addEventListener('mousedown', (e) => {
  if (!pickerState) return;
  const el = document.getElementById('picker');
  if (el.contains(e.target) || (pickerState.anchor && pickerState.anchor.contains(e.target))) return;
  closePicker();
});

function openFolderPicker(anchor, adId) {
  openPicker(anchor, async () => {
    const cols = await db.getCollections();
    return {
      title: 'Save to folders',
      emptyText: 'No folders yet. Name your first one below.',
      items: cols.map(c => ({
        label: c.name,
        meta: (c.adIds || []).length,
        checked: (c.adIds || []).includes(adId),
        onToggle: async (checked) => {
          if (checked) await db.addAdToCollection(adId, c.id);
          else await db.removeAdFromCollection(adId, c.id);
          refreshAfterFolderChange();
        }
      })),
      input: {
        placeholder: 'New folder name',
        button: 'Create',
        onSubmit: async (name) => {
          await db.saveCollection({ name, adIds: [adId], createdAt: Date.now() });
          refreshAfterFolderChange();
          showToast(`Added to new folder "${name}".`);
        }
      }
    };
  });
}

let folderRefreshTimer = null;
function refreshAfterFolderChange() {
  loadCollectionsView();
  clearTimeout(folderRefreshTimer);
  // Re-render cards (folder badges) once the user is done clicking in the picker
  folderRefreshTimer = setTimeout(() => { if (!pickerState) loadSavedAdsView(); else refreshAfterFolderChange(); }, 600);
}

// Private note per ad (why it works, what to borrow); searchable and exported
function openNotePicker(anchor, adId) {
  openPicker(anchor, async () => {
    const ad = await getAdById(adId);
    return {
      title: 'Note',
      textarea: {
        value: (ad && ad.note) || '',
        placeholder: 'Why does this ad work? What would you borrow?',
        button: 'Save note',
        onSubmit: async (value) => {
          await db.updateAd(adId, { note: value.slice(0, 2000) });
          closePicker();
          showToast(value ? 'Note saved.' : 'Note removed.');
          loadSavedAdsView();
        }
      }
    };
  });
}

const DEFAULT_TAGS = ['Winner', 'Hook', 'UGC', 'Offer', 'Testimonial', 'Swipe'];

function openTagPicker(anchor, adId) {
  openPicker(anchor, async () => {
    const ad = await getAdById(adId);
    const current = (ad && ad.tags) || [];
    const all = await db.getAds();
    const used = [...new Set(all.flatMap(a => a.tags || []))];
    const suggestions = [...new Set([...used, ...DEFAULT_TAGS])].filter(t => !current.includes(t)).slice(0, 10);
    const addTag = async (tag) => {
      await db.addTagToAd(adId, tag);
      scheduleAdsRefresh();
    };
    return {
      title: 'Tags',
      items: current.map(t => ({
        label: t,
        checked: true,
        onToggle: async () => { await db.removeTagFromAd(adId, t); scheduleAdsRefresh(); }
      })),
      emptyText: 'No tags on this ad yet.',
      suggestions,
      onSuggestion: addTag,
      input: { placeholder: 'New tag, e.g. Price anchor', button: 'Add', onSubmit: addTag }
    };
  });
}

let adsRefreshTimer = null;
function scheduleAdsRefresh() {
  clearTimeout(adsRefreshTimer);
  adsRefreshTimer = setTimeout(() => { if (!pickerState) loadSavedAdsView(); else scheduleAdsRefresh(); }, 600);
}

// ---- Variation diffs ----
const normText = (t) => String(t || '').replace(/\s+/g, ' ').trim();

// Word-level diff (LCS). Returns HTML with <del>/<ins>; bounded for very long copy.
function wordDiffHTML(a, b) {
  const A = normText(a).split(' ').filter(Boolean);
  const B = normText(b).split(' ').filter(Boolean);
  if (A.length * B.length > 160000) {
    return `<del>${esc(normText(a))}</del> <ins>${esc(normText(b))}</ins>`;
  }
  const n = A.length;
  const m = B.length;
  const dp = Array.from({ length: n + 1 }, () => new Uint16Array(m + 1));
  for (let i = n - 1; i >= 0; i--) {
    for (let j = m - 1; j >= 0; j--) {
      dp[i][j] = A[i] === B[j] ? dp[i + 1][j + 1] + 1 : Math.max(dp[i + 1][j], dp[i][j + 1]);
    }
  }
  const out = [];
  let i = 0;
  let j = 0;
  while (i < n && j < m) {
    if (A[i] === B[j]) { out.push(esc(A[i])); i++; j++; }
    else if (dp[i + 1][j] >= dp[i][j + 1]) { out.push(`<del>${esc(A[i])}</del>`); i++; }
    else { out.push(`<ins>${esc(B[j])}</ins>`); j++; }
  }
  while (i < n) out.push(`<del>${esc(A[i++])}</del>`);
  while (j < m) out.push(`<ins>${esc(B[j++])}</ins>`);
  // Merge adjacent same-type spans for readability
  return out.join(' ').replace(/<\/del> <del>/g, ' ').replace(/<\/ins> <ins>/g, ' ');
}

function describeVariation(base, v) {
  const fields = [];
  const parts = [];
  const short = (t) => { const x = normText(t); return x.length > 70 ? x.slice(0, 67) + '…' : x; };
  [['headline', 'Headline'], ['cta', 'CTA'], ['description', 'Description']].forEach(([key, label]) => {
    if (normText(base[key]) !== normText(v[key]) && (base[key] || v[key])) {
      fields.push(label.toLowerCase());
      parts.push(`<div class="var-change"><span class="var-field">${label}</span><del>${esc(short(base[key]) || '—')}</del> → <ins>${esc(short(v[key]) || '—')}</ins></div>`);
    }
  });
  if (normText(base.primaryText) !== normText(v.primaryText)) {
    fields.push('copy');
    parts.push(`<div class="var-change"><span class="var-field">Copy</span><span class="var-diff">${wordDiffHTML(base.primaryText, v.primaryText)}</span></div>`);
  }
  const creativeDiffers = base.mediaType !== v.mediaType ||
    (base.imageHash && v.imageHash ? !sameCreative(base.imageHash, v.imageHash) : (adImageSrc(base) !== adImageSrc(v)));
  if (creativeDiffers) {
    fields.push('creative');
    parts.push('<div class="var-change"><span class="var-field">Creative</span>different image or video</div>');
  }
  if (!parts.length) parts.push('<div class="var-change var-same">Identical copy and creative (likely an audience or placement test)</div>');
  return { fields, html: parts.join('') };
}

// ---- Sorting ----
function parseStartedDate(str) {
  if (!str) return null;
  const d = new Date(String(str).replace(/(\d)(st|nd|rd|th)\b/g, '$1'));
  return isNaN(d.getTime()) ? null : d;
}

// Days an ad has been live: until today while it runs, until its end date once it stopped.
// A stopped ad without a known end date has no reliable run length.
function daysRunning(ad) {
  const d = parseStartedDate(ad.startedDate);
  if (!d) return null;
  let end = Date.now();
  if (ad.endedDate) {
    const e = parseStartedDate(ad.endedDate);
    if (e) end = e.getTime();
  } else if (ad.status === 'inactive') {
    return null;
  }
  return Math.max(0, Math.floor((end - d.getTime()) / 86400000));
}

function sortAdGroups(groups, mode) {
  const started = (g) => { const d = parseStartedDate(g[0].startedDate); return d ? d.getTime() : null; };
  const copy = groups.slice();
  if (mode === 'running') {
    copy.sort((a, b) => (started(a) ?? Infinity) - (started(b) ?? Infinity));
  } else if (mode === 'started') {
    copy.sort((a, b) => (started(b) ?? -Infinity) - (started(a) ?? -Infinity));
  } else if (mode === 'brand') {
    copy.sort((a, b) => String(a[0].advertiser).localeCompare(String(b[0].advertiser)));
  }
  return copy; // 'saved' keeps the database order (newest saved first)
}

// ---- Watched brands ----
function snapshotInfoHTML(adv, allAds) {
  if (!adv.lastSnapshotAt) {
    return '<div class="snapshot-info">No snapshot yet: press 📸 Snapshot to set a baseline.</div>';
  }
  const days = Math.floor((Date.now() - adv.lastSnapshotAt) / 86400000);
  const when = days === 0 ? 'today' : days === 1 ? 'yesterday' : `${days} days ago`;
  const ids = new Set(adv.snapshotIds || []);
  const newer = allAds.filter(a => a.advertiser === adv.name && !ids.has(a.libraryId)).length;
  return `<div class="snapshot-info">Snapshot ${when}${newer ? ` · <strong>${newer} new saved ad${newer === 1 ? '' : 's'}</strong>` : ' · no new ads saved since'}</div>`;
}

function adLibraryUrlFor(adv) {
  if (adv.pageUrl && /facebook\.com\/ads\/library/i.test(adv.pageUrl)) return adv.pageUrl;
  return `https://www.facebook.com/ads/library/?active_status=active&ad_type=all&country=ALL&q=${encodeURIComponent(adv.name)}&search_type=keyword_unordered`;
}

async function checkWatchedBrands() {
  const watched = (await db.getAdvertisers()).filter(a => a.isWatched);
  if (!watched.length) {
    showToast('Watch a brand first (👁️ Watch on its row).', 'error');
    return;
  }
  watched.slice(0, 10).forEach((adv, i) => chrome.tabs.create({ url: adLibraryUrlFor(adv), active: i === 0 }));
  showToast(watched.length > 10
    ? `Opened the first 10 of ${watched.length} watched brands. Unwatch a few to check the rest.`
    : `Opened ${watched.length} watched brand${watched.length === 1 ? '' : 's'} in the Ad Library.`);
}

// ---- Insights (analytics) ----
function countBy(list, keyFn) {
  const map = new Map();
  list.forEach(item => {
    const k = keyFn(item);
    if (!k) return;
    map.set(k, (map.get(k) || 0) + 1);
  });
  return [...map.entries()].sort((a, b) => b[1] - a[1]);
}

function barListHTML(entries, total, unit) {
  if (!entries.length) return '<div class="insight-empty">Not enough data yet.</div>';
  const max = entries[0][1];
  return `<div class="bar-list">${entries.map(([label, n]) => {
    const pct = total ? Math.round((n / total) * 100) : 0;
    return `<div class="bar-row" title="${esc(label)}: ${n} ${unit} (${pct}%)">
      <span class="bar-label">${esc(label)}</span>
      <span class="bar-track"><span class="bar-fill" style="width:${Math.max(4, (n / max) * 100)}%"></span></span>
      <span class="bar-value">${n}</span>
    </div>`;
  }).join('')}</div>`;
}

function median(nums) {
  if (!nums.length) return null;
  const s = nums.slice().sort((a, b) => a - b);
  const mid = Math.floor(s.length / 2);
  return s.length % 2 ? s[mid] : Math.round((s[mid - 1] + s[mid]) / 2);
}

async function loadInsightsView() {
  const allAds = await db.getAds();
  const select = document.getElementById('insights-brand');
  const body = document.getElementById('insights-body');
  const chosen = select.value;
  const brands = [...new Set(allAds.map(a => a.advertiser))].sort((a, b) => a.localeCompare(b));
  select.innerHTML = '<option value="">All brands</option>' + brands.map(b => `<option value="${esc(b)}"${b === chosen ? ' selected' : ''}>${esc(b)}</option>`).join('');

  const ads = chosen ? allAds.filter(a => a.advertiser === chosen) : allAds;
  if (!ads.length) {
    body.innerHTML = `<div class="empty-state"><p>No saved ads to analyse yet.</p><p class="hint">Save a few ads from the Ad Library and this tab shows launch patterns, long-running winners, CTAs and landing pages.</p></div>`;
    return;
  }

  const active = ads.filter(a => a.status === 'active').length;
  const videos = ads.filter(a => a.mediaType === 'video').length;
  const runDays = ads.map(daysRunning).filter(d => d != null);
  const med = median(runDays);

  const longest = ads.filter(a => daysRunning(a) != null)
    .sort((a, b) => daysRunning(b) - daysRunning(a)).slice(0, 5);
  const longestHTML = longest.length ? longest.map(ad => {
    const thumb = adImageSrc(ad);
    const text = normText(ad.headline || ad.primaryText || '').slice(0, 80);
    return `<a class="longest-row" href="https://www.facebook.com/ads/library/?id=${esc(ad.libraryId)}" target="_blank" rel="noopener noreferrer" title="Open in the Ad Library">
      ${thumb ? `<img src="${safeUrl(thumb, { allowData: true })}" alt="">` : '<span class="longest-noimg"></span>'}
      <span class="longest-text"><span class="longest-brand">${esc(ad.advertiser)}</span><span class="longest-copy">${esc(text || 'No copy')}</span></span>
      <span class="longest-days">${daysRunning(ad)}<small>days</small></span>
    </a>`;
  }).join('') : '<div class="insight-empty">No start dates recorded yet.</div>';

  const ctas = countBy(ads, a => normText(a.cta)).slice(0, 6);
  const domains = countBy(ads, a => a.resolvedDomain).slice(0, 6);
  const formats = countBy(ads, a => (a.mediaType === 'video' ? 'Video' : 'Image'));
  const platforms = countBy(ads.flatMap(a => (a.platforms || []).map(p => ({ p }))), x => ({
    facebook: 'Facebook', instagram: 'Instagram', messenger: 'Messenger', audience_network: 'Audience Network'
  }[x.p] || x.p));

  let brandTable = '';
  if (!chosen && brands.length > 1) {
    const rows = brands.map(b => {
      const list = allAds.filter(a => a.advertiser === b);
      const vids = list.filter(a => a.mediaType === 'video').length;
      const m = median(list.map(daysRunning).filter(d => d != null));
      return { b, n: list.length, act: list.filter(a => a.status === 'active').length, vid: Math.round((vids / list.length) * 100), m };
    }).sort((x, y) => y.n - x.n);
    brandTable = `<div class="panel-card insight-card">
      <h3>Brand comparison</h3>
      <table class="insight-table">
        <thead><tr><th>Brand</th><th>Ads</th><th>Active</th><th>Video</th><th title="Median days since launch">Median age</th></tr></thead>
        <tbody>${rows.map(r => `<tr><td>${esc(r.b)}</td><td>${r.n}</td><td>${r.act}</td><td>${r.vid}%</td><td>${r.m == null ? '–' : r.m + 'd'}</td></tr>`).join('')}</tbody>
      </table>
    </div>`;
  }

  body.innerHTML = `
    <div class="kpi-grid">
      <div class="kpi"><span class="kpi-value">${ads.length}</span><span class="kpi-label">Saved ads</span></div>
      <div class="kpi"><span class="kpi-value">${active}</span><span class="kpi-label">Still active</span></div>
      <div class="kpi"><span class="kpi-value">${Math.round((videos / ads.length) * 100)}%</span><span class="kpi-label">Video</span></div>
      <div class="kpi"><span class="kpi-value">${med == null ? '–' : med}</span><span class="kpi-label">Median days live</span></div>
    </div>
    <div class="panel-card insight-card">
      <h3>🏆 Longest-running ads</h3>
      <p class="card-desc">Ads that keep running for months are usually profitable. Start your swipe file here.</p>
      <div class="longest-list">${longestHTML}</div>
    </div>
    ${generateTimelineChartSVG(ads)}
    <div class="panel-card insight-card"><h3>Calls to action</h3>${barListHTML(ctas, ads.length, 'ads')}</div>
    <div class="panel-card insight-card"><h3>Landing domains</h3>${barListHTML(domains, ads.length, 'ads')}</div>
    <div class="panel-card insight-card"><h3>${platforms.length ? 'Format and placements' : 'Format'}</h3>${barListHTML(formats, ads.length, 'ads')}${platforms.length ? `<div style="height:10px"></div>${barListHTML(platforms, ads.length, 'ads')}` : ''}</div>
    ${brandTable}
  `;
}

// ---- Onboarding, preferences and keyboard shortcuts ----
function initExtras() {
  chrome.storage.local.get(['onboardingDismissed', 'adsSort'], (res) => {
    if (!res.onboardingDismissed) document.getElementById('onboarding-card').classList.remove('hidden');
    if (res.adsSort) {
      const sortEl = document.getElementById('ads-sort');
      sortEl.value = res.adsSort;
      if (sortEl.value === res.adsSort && res.adsSort !== 'saved') loadSavedAdsView();
    }
  });
  document.getElementById('onboarding-dismiss').addEventListener('click', () => {
    document.getElementById('onboarding-card').classList.add('hidden');
    chrome.storage.local.set({ onboardingDismissed: true });
  });

  document.addEventListener('keydown', (e) => {
    const t = e.target;
    const typing = t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName));
    if (e.key === 'Escape') {
      if (pickerState) { closePicker(); e.preventDefault(); return; }
      if (t && t.id === 'ads-search-input' && t.value) { t.value = ''; filterAds(); return; }
      if (typing) t.blur();
      return;
    }
    if (e.altKey && !e.ctrlKey && !e.metaKey && /^[1-6]$/.test(e.key)) {
      const tabs = document.querySelectorAll('.nav-tab');
      const tab = tabs[Number(e.key) - 1];
      if (tab) { e.preventDefault(); tab.click(); }
      return;
    }
    if (e.key === '/' && !typing) {
      e.preventDefault();
      const adsTab = document.querySelector('.nav-tab[data-tab="ads-tab"]');
      if (adsTab && !adsTab.classList.contains('active')) adsTab.click();
      document.getElementById('ads-search-input').focus();
    }
  });
}
