// Meta Competitor Intelligence - Side Panel Script

let activeSearchContext = null;
let currentScrollState = { isScrolling: false, count: 0 };

// Escape scraped text before it is placed into HTML. Ad copy, advertiser names and
// lead-form text come from third-party pages and must never be treated as markup
// (this also protects the exported HTML report, which is opened without a CSP).
function esc(value) {
  return String(value == null ? '' : value).replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}

// Only allow http(s) links and inline images in attributes; anything else becomes '#'/''
function safeUrl(value, { allowData = false } = {}) {
  const str = String(value || '').trim();
  if (!str) return '';
  if (allowData && /^data:image\//i.test(str)) return esc(str);
  try {
    const u = new URL(str);
    if (u.protocol === 'http:' || u.protocol === 'https:') return esc(u.href);
  } catch (e) { /* invalid URL */ }
  return '';
}

const PLACEHOLDER_AVATAR = 'data:image/svg+xml;utf8,<svg xmlns=%22http://www.w3.org/2000/svg%22 width=%2210%22 height=%2210%22><rect width=%2210%22 height=%2210%22 fill=%22%23475569%22/></svg>';

// Prefer the thumbnail stored in the database: Meta CDN links expire after a few days
function adImageSrc(ad) {
  if (ad.thumbnailData) return ad.thumbnailData;
  if (ad.mediaType === 'video') return ad.videoThumbnail || '';
  return (ad.mediaUrls && ad.mediaUrls[0]) || '';
}

document.addEventListener('DOMContentLoaded', async () => {
  console.log('Side panel script DOM loaded.');

  // Initialize DB
  try {
    await db.init();
    updateDbStatus(true);
  } catch (error) {
    console.error('Database connection failed:', error);
    updateDbStatus(false);
    return;
  }

  // Setup tabs navigation
  initTabs();

  // Load Initial View Data
  loadAllViews();
  loadCollectionsView();

  // Try to bind to active Meta Ad Library tab
  detectActiveTabSearch();

  // Setup event listeners
  setupEventListeners();

  // Listen for messages from content scripts or background service worker
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'AD_SAVED_EVENT' || message.action === 'AD_DELETED_EVENT') {
      loadSavedAdsView();
      loadBrandsView();
    } else if (message.action === 'SCROLL_STATE_CHANGED') {
      handleScrollStateChange(message.data);
    } else if (message.action === 'SCROLL_PROGRESS') {
      handleScrollProgress(message.data);
    } else if (message.action === 'COLLECTIONS_UPDATED_EVENT') {
      loadCollectionsView();
      loadSavedAdsView();
    } else if (message.action === 'ADVERTISERS_UPDATED_EVENT') {
      loadBrandsView();
    }
  });
});

// Update database connectivity label in footer
function updateDbStatus(connected) {
  const statusEl = document.getElementById('db-status');
  if (statusEl) {
    statusEl.innerHTML = connected
      ? '<span style="color: #10b981;">●</span> DB Connected'
      : '<span style="color: #ef4444;">●</span> DB Error';
  }
}

// 1. Tab Management UI
function initTabs() {
  const tabs = document.querySelectorAll('.nav-tab');
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      // Toggle nav-tab active classes
      tabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');

      // Toggle tab-content active classes
      const targetTab = tab.getAttribute('data-tab');
      const contents = document.querySelectorAll('.tab-content');
      contents.forEach(content => {
        content.classList.remove('active');
        if (content.id === targetTab) {
          content.classList.add('active');
        }
      });

      // Reload view when switching to it
      if (targetTab === 'ads-tab') loadSavedAdsView();
      if (targetTab === 'brands-tab') loadBrandsView();
      if (targetTab === 'history-tab') loadHistoryView();
      if (targetTab === 'settings-tab') loadSettings();
    });
  });
}

// Load database views
function loadAllViews() {
  loadSavedAdsView();
  loadBrandsView();
  loadHistoryView();
}

// 2. Query Active Page Search Context
async function detectActiveTabSearch() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.url || !tab.url.includes('facebook.com/ads/library')) {
    showSearchEmptyState(true);
    return;
  }

  // Ask content script for search query details
  chrome.tabs.sendMessage(tab.id, { action: 'GET_CURRENT_SEARCH' }, (response) => {
    if (chrome.runtime.lastError) {
      console.warn('Content script not responsive yet:', chrome.runtime.lastError.message);
      showSearchEmptyState(true, true); // true indicates connection disconnected
      return;
    }

    if (response && response.success && response.data) {
      activeSearchContext = response.data;
      showSearchEmptyState(false);
      populateSearchDetails(response.data);

      // Get current scrolling state from content script
      chrome.tabs.sendMessage(tab.id, { action: 'GET_SCROLL_STATE' }, (stateRes) => {
        if (stateRes) {
          handleScrollStateChange(stateRes);
        }
      });
    } else {
      showSearchEmptyState(true);
    }
  });
}

function showSearchEmptyState(isEmpty, isDisconnected = false) {
  const emptyMsg = document.getElementById('no-search-msg');
  const details = document.getElementById('search-details');
  const scrollCard = document.getElementById('scroll-card');

  if (isEmpty) {
    emptyMsg.classList.remove('hidden');
    details.classList.add('hidden');
    scrollCard.classList.add('hidden');

    const hintEl = emptyMsg.querySelector('.hint');
    if (hintEl) {
      if (isDisconnected) {
        hintEl.innerHTML = '⚠️ <strong>Extension reloaded.</strong> Please refresh your Facebook Ad Library tab to reconnect the side panel.';
      } else {
        hintEl.textContent = 'Please navigate to the Meta Ad Library, search for a competitor, or refresh the page to connect.';
      }
    }
  } else {
    emptyMsg.classList.add('hidden');
    details.classList.remove('hidden');
    scrollCard.classList.remove('hidden');
  }
}

function populateSearchDetails(context) {
  document.getElementById('curr-keyword').innerText = context.keyword || 'None';
  document.getElementById('curr-country').innerText = context.country || 'ALL';
  document.getElementById('curr-category').innerText = context.category || 'all';
  document.getElementById('curr-count').innerText = context.adCount || 0;
}

// 3. Event Listeners Setup
function setupEventListeners() {
  // Collect All trigger
  const btnCollect = document.getElementById('btn-collect-all');
  if (btnCollect) {
    btnCollect.addEventListener('click', toggleCollection);
  }

  // Export Buttons
  document.getElementById('btn-export-excel').addEventListener('click', exportToExcel);
  document.getElementById('btn-export-json').addEventListener('click', exportToJSON);
  document.getElementById('btn-export-csv').addEventListener('click', exportToCSV);
  document.getElementById('btn-import-json').addEventListener('click', () => {
    document.getElementById('import-json-input').click();
  });
  document.getElementById('import-json-input').addEventListener('change', importFromJSON);
  document.getElementById('btn-export-report').addEventListener('click', exportHTMLReport);

  // Filters inside Ads tab
  document.getElementById('ads-search-input').addEventListener('input', filterAds);
  document.getElementById('ads-brand-filter').addEventListener('change', filterAds);
  document.getElementById('ads-collection-filter').addEventListener('change', filterAds);

  // Folders Creator
  document.getElementById('btn-create-collection').addEventListener('click', createNewCollection);

  // Reload Button
  const btnReload = document.getElementById('btn-reload-panel');
  if (btnReload) {
    btnReload.addEventListener('click', () => {
      location.reload();
    });
  }

  // Settings Saver
  const btnSaveSettings = document.getElementById('btn-save-settings');
  if (btnSaveSettings) {
    btnSaveSettings.addEventListener('click', saveSettings);
  }

  // Clear DB
  document.getElementById('btn-clear-db').addEventListener('click', resetDatabase);
}

// 4. Scroll Collection Coordination
async function toggleCollection() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) return;

  const btnCollect = document.getElementById('btn-collect-all');

  if (currentScrollState.isScrolling) {
    // Send Stop Scroll Command
    chrome.tabs.sendMessage(tab.id, { action: 'STOP_SCROLL' }, (res) => {
      if (res && res.success) {
        handleScrollStateChange({ isScrolling: false, lastAdCount: currentScrollState.count });
      }
    });
  } else {
    // Send Start Scroll Command
    const limit = parseInt(document.getElementById('scroll-limit').value) || 100;
    chrome.tabs.sendMessage(tab.id, { action: 'START_SCROLL', limit }, (res) => {
      if (res && res.success) {
        handleScrollStateChange({ isScrolling: true, lastAdCount: 0 });
      }
    });
  }
}

function handleScrollStateChange(state) {
  currentScrollState.isScrolling = state.isScrolling;

  const btnCollect = document.getElementById('btn-collect-all');
  const progressContainer = document.getElementById('scroll-progress-container');
  const limit = parseInt(document.getElementById('scroll-limit').value) || 100;

  if (state.isScrolling) {
    btnCollect.innerHTML = '🛑 Stop Collection';
    btnCollect.className = 'btn btn-secondary';
    progressContainer.classList.remove('hidden');
    updateProgressBar(0, limit);
  } else {
    btnCollect.innerHTML = '📥 Start Collect All';
    btnCollect.className = 'btn btn-primary';
    progressContainer.classList.add('hidden');
    loadAllViews(); // Refresh view after scroll session
  }
}

function handleScrollProgress(progress) {
  currentScrollState.count = progress.count;
  const limit = parseInt(document.getElementById('scroll-limit').value) || 100;
  updateProgressBar(progress.count, limit);

  const countVal = document.getElementById('curr-count');
  if (countVal) {
    countVal.innerText = progress.count;
  }
}

function updateProgressBar(count, limit) {
  const percentage = Math.min((count / limit) * 100, 100);
  document.getElementById('progress-bar').style.width = `${percentage}%`;
  document.getElementById('progress-text').innerText = `Collected ${count} / ${limit} ads...`;
}

// 5. Render Database Views
async function loadSavedAdsView() {
  const ads = await db.getAds();
  const adsList = document.getElementById('ads-list');
  const brandFilter = document.getElementById('ads-brand-filter');

  // Populate brand selection filters
  const brands = [...new Set(ads.map(ad => ad.advertiser))];
  const selectedBrand = brandFilter.value;
  brandFilter.innerHTML = '<option value="">All Brands</option>';
  brands.forEach(b => {
    const opt = document.createElement('option');
    opt.value = b;
    opt.textContent = b;
    if (b === selectedBrand) opt.selected = true;
    brandFilter.appendChild(opt);
  });

  // Cluster variations in-memory
  const groups = await clusterAdsByVariation(ads);
  renderAdGroups(groups);
}

function renderAdGroups(groups) {
  const adsList = document.getElementById('ads-list');
  adsList.innerHTML = '';

  if (groups.length === 0) {
    adsList.innerHTML = `
      <div class="empty-state">
        <p>No ads saved yet.</p>
        <p class="hint">Use the "Save Ad" button on Meta Ad Library card elements, or launch a Collector Engine session.</p>
      </div>
    `;
    return;
  }

  groups.forEach(group => {
    const ad = group[0];
    const card = document.createElement('div');
    card.className = 'ad-card';
    card.dataset.id = ad.libraryId;
    card.dataset.brand = ad.advertiser;
    card.dataset.copy = ad.primaryText || '';
    card.dataset.headline = ad.headline || '';

    // Card Header details
    const dateText = ad.startedDate ? `Started: ${ad.startedDate}` : 'Started: Unknown';
    const activeClass = ad.status === 'active' ? 'active' : 'inactive';
    const statusText = ad.status === 'active' ? 'Active' : 'Inactive';

    // Image / Video display content
    let mediaHTML = '';
    if (ad.mediaType === 'video') {
      const thumb = safeUrl(adImageSrc(ad), { allowData: true });
      mediaHTML = `
        <div class="ad-card-media">
          <span class="ad-video-badge">▶ VIDEO</span>
          <video poster="${thumb}" muted controls preload="none" src="${safeUrl(ad.videoUrl)}"></video>
        </div>
      `;
    } else if (adImageSrc(ad)) {
      mediaHTML = `
        <div class="ad-card-media">
          <img src="${safeUrl(adImageSrc(ad), { allowData: true })}" loading="lazy" alt="">
        </div>
      `;
    }

    // CTA & Resolved Redirect Link
    let ctaHTML = '';
    if (ad.cta) {
      let targetUrl = ad.resolvedUrl || ad.ctaUrl || `https://www.facebook.com/ads/library/?id=${ad.libraryId}`;
      if (ad.cta === 'Open Drop-down') {
        targetUrl = `https://www.facebook.com/ads/library/?id=${ad.libraryId}`;
      }
      ctaHTML = `<a class="ad-card-cta" href="${safeUrl(targetUrl) || '#'}" target="_blank" rel="noopener noreferrer" style="text-decoration: none; cursor: pointer;">${esc(ad.cta)}</a>`;
    }

    // Local download copy badge indicator
    const localBadgeHTML = ad.localPath
      ? `<span class="local-copy-badge" title="Saved: ${esc(ad.localPath)}">📁 Local Copy</span>` 
      : '';

    // Resolved Domain Link
    const domainBadgeHTML = ad.resolvedDomain
      ? `<a class="resolved-domain-badge" href="${safeUrl(ad.resolvedUrl) || '#'}" target="_blank" rel="noopener noreferrer" title="Resolved Destination: ${esc(ad.resolvedUrl)}">🔗 ${esc(ad.resolvedDomain)}</a>` 
      : '';

    // Tags Section Builder
    let tagsHTML = '';
    const adTags = ad.tags || [];
    adTags.forEach(tag => {
      const cls = tag.toLowerCase() === 'winner' ? 'tag-winner' : (tag.toLowerCase() === 'hook' ? 'tag-hook' : '');
      tagsHTML += `
        <span class="ad-tag-pill ${cls}">
          ${esc(tag)}
          <span class="ad-tag-delete" data-tag="${esc(tag)}" data-id="${esc(ad.libraryId)}" title="Delete Tag">×</span>
        </span>
      `;
    });

    // Details Section Builder (from Ad Details modal parsing)
    let detailsHTML = '';
    if ((ad.additionalTexts && ad.additionalTexts.length > 0) ||
        (ad.additionalLinks && ad.additionalLinks.length > 0) ||
        ad.advertiserInfo) {

      let textsList = '';
      if (ad.additionalTexts && ad.additionalTexts.length > 0) {
        textsList = `
          <div style="font-weight: 600; font-size: 9px; color: #818cf8; margin-top: 6px;">Lead Form / Extracted Text:</div>
          <ul style="margin: 4px 0; padding-left: 12px; font-size: 9px; color: var(--text-secondary); line-height: 1.35; max-height: 120px; overflow-y: auto;">
            ${ad.additionalTexts.map(t => `<li>${esc(t)}</li>`).join('')}
          </ul>
        `;
      }

      let linksList = '';
      if (ad.additionalLinks && ad.additionalLinks.length > 0) {
        linksList = `
          <div style="font-weight: 600; font-size: 9px; color: #3b82f6; margin-top: 6px;">Form Links:</div>
          <div style="display: flex; flex-direction: column; gap: 3px; margin-top: 2px;">
            ${ad.additionalLinks.map(l => `<a href="${safeUrl(l) || '#'}" target="_blank" rel="noopener noreferrer" style="font-size: 9px; color: #93c5fd; text-decoration: none; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">🔗 ${esc(l)}</a>`).join('')}
          </div>
        `;
      }

      let advInfoHTML = '';
      if (ad.advertiserInfo) {
        advInfoHTML = `
          <div style="font-weight: 600; font-size: 9px; color: #10b981; margin-top: 6px;">About Advertiser (More Info):</div>
          <div style="font-size: 9px; color: var(--text-secondary); line-height: 1.3; margin-top: 2px; font-style: italic;">
            "${esc(ad.advertiserInfo)}"
          </div>
        `;
      }

      detailsHTML = `
        <details class="ad-details-dropdown" style="margin-top: 8px; background: rgba(0,0,0,0.15); border-radius: 6px; padding: 6px 8px; border: 1px solid rgba(255,255,255,0.04); width: 100%; box-sizing: border-box;">
          <summary style="font-size: 9px; font-weight: 600; color: var(--text-primary); cursor: pointer; outline: none; user-select: none;">📄 View Ad Details & Lead Form</summary>
          <div style="margin-top: 6px; display: flex; flex-direction: column; gap: 4px;">
            ${advInfoHTML}
            ${textsList}
            ${linksList}
          </div>
        </details>
      `;
    }

    // AI Analysis Section Builder
    let aiHTML = '';
    if (ad.aiAnalysis) {
      const ai = ad.aiAnalysis;
      aiHTML = `
        <div class="ai-analysis-box">
          <div class="ai-analysis-header">
            <span>🔮 AI Copyscript Audit</span>
            <span style="color: #fbbf24; font-weight: 700;">★ Hook: ${esc(ai.hookStrength || '?')}/10</span>
          </div>
          <div class="ai-analysis-item"><span class="ai-analysis-label">Hook Angle:</span><span class="ai-analysis-val">${esc(ai.hookExplanation || '-')}</span></div>
          <div class="ai-analysis-item"><span class="ai-analysis-label">Offers:</span><span class="ai-analysis-val">${esc((Array.isArray(ai.offers) ? ai.offers.join(', ') : ai.offers) || 'None')}</span></div>
          <div class="ai-analysis-item"><span class="ai-analysis-label">Target Pain Points:</span><span class="ai-analysis-val">${esc((Array.isArray(ai.painPoints) ? ai.painPoints.join(', ') : ai.painPoints) || 'None')}</span></div>
          <div class="ai-analysis-item"><span class="ai-analysis-label">Framework:</span><span class="ai-analysis-val">${esc(ai.framework || '-')}</span></div>
          <div class="ai-analysis-item"><span class="ai-analysis-val">${esc(ai.funnelStage || '-')}</span></div>
        </div>
      `;
    } else {
      aiHTML = `
        <button class="btn-ai-audit" data-id="${esc(ad.libraryId)}" style="margin-top: 8px; width: 100%; border: 1px dashed rgba(99, 102, 241, 0.4); background: rgba(99, 102, 241, 0.05); color: #a5b4fc; font-size: 9px; padding: 6px; border-radius: 6px; cursor: pointer; font-weight: 600;">🔮 Analyze with AI</button>
      `;
    }

    // Split-test variation drawer HTML
    let variationHTML = '';
    if (group.length > 1) {
      variationHTML = `
        <details class="ad-details-dropdown" style="margin-top: 8px; background: rgba(99, 102, 241, 0.08); border-radius: 6px; padding: 6px 8px; border: 1px solid rgba(99, 102, 241, 0.2); width: 100%; box-sizing: border-box;">
          <summary style="font-size: 9px; font-weight: 700; color: #a5b4fc; cursor: pointer; outline: none; user-select: none;">📦 Split Test: ${group.length} Variations Active</summary>
          <div style="margin-top: 6px; display: flex; flex-direction: column; gap: 4px;">
            ${group.slice(1).map((extra, idx) => `
              <div style="font-size: 8px; color: var(--text-secondary); border-top: 1px solid rgba(255,255,255,0.03); padding-top: 4px; display: flex; justify-content: space-between; align-items: center;">
                <span>Var #${idx + 2} (ID: ${esc(extra.libraryId)})</span>
                <span style="display: flex; gap: 4px; align-items: center;">
                  <span>Started: ${esc(extra.startedDate || 'Unknown')}</span>
                  <button class="btn-icon ad-delete-var-btn" data-id="${esc(extra.libraryId)}" title="Delete Variation" style="font-size: 8px; padding: 2px; color: var(--accent-danger); border: none; background: transparent; cursor: pointer;">🗑️</button>
                </span>
              </div>
            `).join('')}
          </div>
        </details>
      `;
    }

    card.innerHTML = `
      <div class="ad-card-header">
        <img class="ad-card-avatar" src="${safeUrl(ad.profileImageData || ad.profileImage, { allowData: true }) || PLACEHOLDER_AVATAR}" alt="${esc(ad.advertiser)}">
        <div class="ad-card-meta">
          <span class="ad-card-brand">${esc(ad.advertiser)}</span>
          <span class="ad-card-dates">${esc(dateText)}</span>
        </div>
        <span class="ad-card-status ${activeClass}">${statusText}</span>
      </div>

      <div class="ad-card-body">${ad.primaryText ? esc(ad.primaryText) : '<i>No ad copy text body.</i>'}</div>

      ${mediaHTML}

      <div style="display: flex; gap: 6px; flex-wrap: wrap;">
        ${localBadgeHTML}
        ${domainBadgeHTML}
      </div>

      ${detailsHTML}
      ${aiHTML}
      ${variationHTML}

      <div class="ad-card-tags-area">
        ${tagsHTML}
        <span class="ad-tag-add-trigger" data-id="${esc(ad.libraryId)}">+ Tag</span>
      </div>

      <div class="ad-card-footer">
        ${ctaHTML}
        <div style="display: flex; gap: 4px;">
          <button class="ad-folder-btn ad-delete-btn" title="Assign to Folder" data-id="${esc(ad.libraryId)}">📁 Folder</button>
          <button class="ad-delete-btn" title="Delete Saved Ad" data-id="${esc(ad.libraryId)}">🗑️</button>
        </div>
      </div>
    `;

    // Bind AI Audit button click if present
    const btnAi = card.querySelector('.btn-ai-audit');
    if (btnAi) {
      btnAi.addEventListener('click', (e) => {
        const id = e.target.getAttribute('data-id');
        runAICognitiveAnalysis(id, e.target);
      });
    }

    // Bind variation deletes
    card.querySelectorAll('.ad-delete-var-btn').forEach(vBtn => {
      vBtn.addEventListener('click', async (e) => {
        e.stopPropagation();
        e.preventDefault();
        const id = e.target.getAttribute('data-id');
        if (confirm(`Delete variation ${id}?`)) {
          await db.deleteAd(id);
          loadSavedAdsView();
        }
      });
    });

    // Bind Add Tag trigger
    card.querySelector('.ad-tag-add-trigger').addEventListener('click', async (e) => {
      const id = e.target.getAttribute('data-id');
      const tag = prompt('Enter tag name (e.g. Winner, Hook, Copy):');
      if (tag && tag.trim()) {
        await db.addTagToAd(id, tag.trim());
        loadSavedAdsView();
      }
    });

    // Bind Delete Tag triggers
    card.querySelectorAll('.ad-tag-delete').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();
        const id = e.target.getAttribute('data-id');
        const tag = e.target.getAttribute('data-tag');
        await db.removeTagFromAd(id, tag);
        loadSavedAdsView();
      });
    });

    // Bind Folder Assign trigger
    card.querySelector('.ad-folder-btn').addEventListener('click', async (e) => {
      const id = e.target.getAttribute('data-id');
      const collections = await db.getCollections();
      if (collections.length === 0) {
        alert('Please create a folder (Collection) first using the "➕ Folder" button above.');
        return;
      }

      const listStr = collections.map((c, i) => `${i + 1}. ${c.name}`).join('\n');
      const choice = prompt(`Assign this ad to a folder. Enter the folder number:\n\n${listStr}`);
      const index = parseInt(choice) - 1;

      if (choice && index >= 0 && index < collections.length) {
        const targetColl = collections[index];
        await db.addAdToCollection(id, targetColl.id);
        alert(`Ad assigned to folder: ${targetColl.name}`);
        loadSavedAdsView();
      }
    });

    // Bind Delete Button event
    card.querySelector('.ad-delete-btn:not(.ad-folder-btn)').addEventListener('click', async (e) => {
      const id = e.target.getAttribute('data-id');
      if (confirm('Delete this saved ad?')) {
        await db.deleteAd(id);
        card.remove();
        loadAllViews();
      }
    });

    adsList.appendChild(card);
  });
}

async function filterAds() {
  const query = document.getElementById('ads-search-input').value.toLowerCase();
  const selectedBrand = document.getElementById('ads-brand-filter').value;
  const selectedCollectionId = document.getElementById('ads-collection-filter').value;

  let allowedAdIds = null;
  if (selectedCollectionId) {
    const collections = await db.getCollections();
    const activeColl = collections.find(c => String(c.id) === selectedCollectionId);
    allowedAdIds = activeColl ? (activeColl.adIds || []) : [];
  }

  const cards = document.querySelectorAll('.ad-card');
  cards.forEach(card => {
    const id = card.dataset.id;
    const brand = card.dataset.brand;
    const copy = card.dataset.copy.toLowerCase();
    const headline = card.dataset.headline.toLowerCase();

    const matchesBrand = !selectedBrand || brand === selectedBrand;
    const matchesQuery = !query || copy.includes(query) || headline.includes(query);
    const matchesCollection = !selectedCollectionId || (allowedAdIds && allowedAdIds.includes(id));

    if (matchesBrand && matchesQuery && matchesCollection) {
      card.classList.remove('hidden');
    } else {
      card.classList.add('hidden');
    }
  });
}

// Saved Brands View
async function loadBrandsView() {
  const advertisers = await db.getAdvertisers();
  const allAds = await db.getAds();
  const brandsList = document.getElementById('brands-list');
  brandsList.innerHTML = '';

  if (advertisers.length === 0) {
    brandsList.innerHTML = `
      <div class="empty-state">
        <p>No brands collected yet.</p>
        <p class="hint">Brands are added automatically when you save their ads.</p>
      </div>
    `;
    return;
  }

  // Render SVG campaign scaling timeline chart at the top
  const chartHTML = generateTimelineChartSVG(allAds);
  if (chartHTML) {
    const tempDiv = document.createElement('div');
    tempDiv.innerHTML = chartHTML;
    brandsList.appendChild(tempDiv.firstElementChild);
  }

  advertisers.forEach(adv => {
    const row = document.createElement('div');
    row.className = 'brand-row';

    const countText = adv.totalAdsCollected === 1 ? '1 ad saved' : `${adv.totalAdsCollected} ads saved`;
    const brandAd = allAds.find(a => a.advertiser === adv.name && a.profileImageData);
    const avatarSrc = (brandAd && brandAd.profileImageData) || safeUrl(adv.profileImage) || PLACEHOLDER_AVATAR;

    let transparencyHTML = '';
    if (adv.transparency) {
      const trans = adv.transparency;
      transparencyHTML = `
        <div class="brand-transparency-box">
          <div class="transparency-title">Transparency Stats</div>
          ${trans.businessName ? `<div class="transparency-item"><span class="transparency-label">Business:</span><span class="transparency-value">${esc(trans.businessName)}</span></div>` : ''}
          ${trans.pageCreated ? `<div class="transparency-item"><span class="transparency-label">Created:</span><span class="transparency-value">${esc(trans.pageCreated)}</span></div>` : ''}
          ${trans.country ? `<div class="transparency-item"><span class="transparency-label">Location:</span><span class="transparency-value">${esc(trans.country)}</span></div>` : ''}
          ${trans.mergedPages && trans.mergedPages.length > 0 ? `<div class="transparency-item"><span class="transparency-label">Merged:</span><span class="transparency-value">${esc(trans.mergedPages.join(', '))}</span></div>` : ''}
        </div>
      `;
    }

    const watchText = adv.isWatched ? '👁️ Unwatch' : '👁️ Watch';
    const watchClass = adv.isWatched ? 'btn-watch active' : 'btn-watch';
    const snapshotBtnHTML = adv.isWatched
      ? `<button class="brand-snapshot-btn" data-name="${esc(adv.name)}" title="Capture current saved ads list as monitored snapshot" style="font-size: 9px; padding: 2px 6px; cursor: pointer;">📸 Snapshot</button>`
      : '';

    row.innerHTML = `
      <img class="brand-row-avatar" src="${avatarSrc}" alt="">
      <div class="brand-row-info">
        <div class="brand-row-name">${esc(adv.name)}</div>
        <div class="brand-row-count">${countText}</div>
        ${transparencyHTML}
      </div>
      <div class="brand-actions-col" style="display: flex; flex-direction: column; gap: 4px; align-items: flex-end; justify-content: center;">
        <button class="btn-icon btn-icon-danger brand-delete-btn" data-name="${esc(adv.name)}">🗑️</button>
        <button class="${watchClass}" data-name="${esc(adv.name)}" style="font-size: 9px; padding: 2px 6px; cursor: pointer;">${watchText}</button>
        ${snapshotBtnHTML}
      </div>
    `;

    row.querySelector('.brand-delete-btn').addEventListener('click', async (e) => {
      const name = e.target.getAttribute('data-name');
      if (confirm(`Delete competitor profile for ${name}? This does not remove their saved ads, only the brand metadata.`)) {
        await db.deleteAdvertiser(name);
        row.remove();
        loadAllViews();
      }
    });

    row.querySelector('.btn-watch').addEventListener('click', async (e) => {
      const name = e.target.getAttribute('data-name');
      const isWatchingNow = !e.target.classList.contains('active');
      chrome.runtime.sendMessage({
        action: 'TOGGLE_WATCH_ADVERTISER',
        name,
        isWatching: isWatchingNow
      }, (res) => {
        if (res && res.success) {
          alert(isWatchingNow
            ? `Now watching advertiser: ${name}. You will see tags highlighting newly loaded ads on Facebook!`
            : `Stopped watching advertiser: ${name}.`
          );
          loadBrandsView();
        }
      });
    });

    if (adv.isWatched) {
      row.querySelector('.brand-snapshot-btn').addEventListener('click', async (e) => {
        const name = e.target.getAttribute('data-name');
        // Fetch advertiser's ads from IndexedDB
        const adsList = await db.getAds(name);
        const libraryIds = adsList.map(a => a.libraryId);

        chrome.runtime.sendMessage({
          action: 'SAVE_ADVERTISER_SNAPSHOT',
          name,
          libraryIds
        }, (res) => {
          if (res && res.success) {
            alert(`Monitored snapshot saved! Registered ${libraryIds.length} ads as baseline. Any future ads discovered will trigger a 'NEW' visual badge!`);
            loadBrandsView();
          }
        });
      });
    }

    brandsList.appendChild(row);
  });
}

// Folders/Collections View Operations
async function loadCollectionsView() {
  const collections = await db.getCollections();
  const filterSelect = document.getElementById('ads-collection-filter');
  const selectedVal = filterSelect.value;

  filterSelect.innerHTML = '<option value="">📁 All Collections</option>';
  collections.forEach(coll => {
    const opt = document.createElement('option');
    opt.value = String(coll.id);
    opt.textContent = `📁 ${coll.name} (${coll.adIds ? coll.adIds.length : 0})`;
    if (String(coll.id) === selectedVal) opt.selected = true;
    filterSelect.appendChild(opt);
  });
}

async function createNewCollection() {
  const name = prompt('Enter a name for the new folder/collection:');
  if (name && name.trim()) {
    await db.saveCollection({
      name: name.trim(),
      adIds: [],
      createdAt: Date.now()
    });
    loadCollectionsView();
  }
}

// History View
async function loadHistoryView() {
  const searches = await db.getSearches();
  const historyList = document.getElementById('history-list');
  historyList.innerHTML = '';

  if (searches.length === 0) {
    historyList.innerHTML = `
      <div class="empty-state">
        <p>No search history recorded.</p>
        <p class="hint">The extension logs your search setups automatically when visiting the Meta Ad Library.</p>
      </div>
    `;
    return;
  }

  searches.forEach(search => {
    const item = document.createElement('div');
    item.className = 'history-item';

    const date = new Date(search.timestamp).toLocaleDateString(undefined, {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });

    item.innerHTML = `
      <div class="history-item-left">
        <span class="history-item-keyword">${esc(search.keyword)}</span>
        <span class="history-item-meta">${esc(String(search.country || 'ALL').toUpperCase())} · ${esc(search.category)} · ${esc(date)}</span>
      </div>
      <div class="history-item-actions">
        <button class="btn-icon history-reopen-btn" title="Reopen Search URL" data-url="${safeUrl(search.url)}">🔗</button>
        <button class="btn-icon btn-icon-danger history-delete-btn" title="Delete History Entry" data-id="${esc(search.id)}">🗑️</button>
      </div>
    `;

    // Bind reopening URL
    item.querySelector('.history-reopen-btn').addEventListener('click', (e) => {
      const url = e.target.getAttribute('data-url');
      if (url) chrome.tabs.create({ url });
    });

    // Bind Delete History entry
    item.querySelector('.history-delete-btn').addEventListener('click', async (e) => {
      const id = e.target.getAttribute('data-id');
      await db.deleteSearch(id);
      item.remove();
      loadHistoryView();
    });

    historyList.appendChild(item);
  });
}

// 6. Data Exports
async function exportToExcel() {
  const ads = await db.getAds();
  const advertisers = await db.getAdvertisers();
  const searches = await db.getSearches();

  if (ads.length === 0) {
    alert('No ads available to export.');
    return;
  }

  // Helper to escape XML special characters
  const escapeXML = (str) => {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&apos;');
  };

  // Build Sheet 1: Competitor Statistics
  let sheet1Rows = '';
  advertisers.forEach(adv => {
    const bizName = adv.transparency?.businessName || 'Unverified';
    const created = adv.transparency?.pageCreated || 'Unknown';
    const loc = adv.transparency?.country || 'Unknown';
    sheet1Rows += `
      <Row>
        <Cell><Data ss:Type="String">${escapeXML(adv.name)}</Data></Cell>
        <Cell><Data ss:Type="Number">${adv.totalAdsCollected || 0}</Data></Cell>
        <Cell><Data ss:Type="String">${escapeXML(bizName)}</Data></Cell>
        <Cell><Data ss:Type="String">${escapeXML(created)}</Data></Cell>
        <Cell><Data ss:Type="String">${escapeXML(loc)}</Data></Cell>
        <Cell><Data ss:Type="String">${escapeXML(adv.pageUrl || '')}</Data></Cell>
      </Row>
    `;
  });

  // Build Sheet 2: Saved Ads Flat List
  let sheet2Rows = '';
  ads.forEach(ad => {
    sheet2Rows += `
      <Row>
        <Cell><Data ss:Type="String">${escapeXML(ad.libraryId)}</Data></Cell>
        <Cell><Data ss:Type="String">${escapeXML(ad.advertiser)}</Data></Cell>
        <Cell><Data ss:Type="String">${escapeXML(ad.status)}</Data></Cell>
        <Cell><Data ss:Type="String">${escapeXML(ad.startedDate)}</Data></Cell>
        <Cell><Data ss:Type="String">${escapeXML((ad.platforms || []).join(', '))}</Data></Cell>
        <Cell><Data ss:Type="String">${escapeXML(ad.headline || '')}</Data></Cell>
        <Cell><Data ss:Type="String">${escapeXML(ad.description || '')}</Data></Cell>
        <Cell><Data ss:Type="String">${escapeXML(ad.cta || '')}</Data></Cell>
        <Cell><Data ss:Type="String">${escapeXML(ad.resolvedUrl || ad.ctaUrl || '')}</Data></Cell>
        <Cell><Data ss:Type="String">${escapeXML(ad.primaryText || '')}</Data></Cell>
        <Cell><Data ss:Type="String">${escapeXML((ad.tags || []).join(', '))}</Data></Cell>
        <Cell><Data ss:Type="String">${escapeXML(ad.localPath || 'No Local Copy')}</Data></Cell>
      </Row>
    `;
  });

  // Build Sheet 3: Search Logs
  let sheet3Rows = '';
  searches.forEach(search => {
    const d = new Date(search.timestamp).toLocaleString();
    sheet3Rows += `
      <Row>
        <Cell><Data ss:Type="String">${escapeXML(search.keyword)}</Data></Cell>
        <Cell><Data ss:Type="String">${escapeXML(search.country)}</Data></Cell>
        <Cell><Data ss:Type="String">${escapeXML(search.category)}</Data></Cell>
        <Cell><Data ss:Type="String">${escapeXML(d)}</Data></Cell>
        <Cell><Data ss:Type="Number">${search.adCount || 0}</Data></Cell>
        <Cell><Data ss:Type="String">${escapeXML(search.url || '')}</Data></Cell>
      </Row>
    `;
  });

  // Construct XML Workbook template
  const xmlContent = `<?xml version="1.0"?>
<?mso-application progid="Excel.Sheet"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:o="urn:schemas-microsoft-com:office:office"
 xmlns:x="urn:schemas-microsoft-com:office:excel"
 xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:html="http://www.w3.org/TR/REC-html40">
  <DocumentProperties xmlns="urn:schemas-microsoft-com:office:office">
    <Author>Meta Competitor Intelligence</Author>
    <Created>${new Date().toISOString()}</Created>
  </DocumentProperties>

  <!-- Sheet 1 -->
  <Worksheet ss:Name="Competitor statistics">
    <Table>
      <Row>
        <Cell><Data ss:Type="String">Advertiser Name</Data></Cell>
        <Cell><Data ss:Type="String">Total Ads Saved</Data></Cell>
        <Cell><Data ss:Type="String">Verified Business Name</Data></Cell>
        <Cell><Data ss:Type="String">Page Created Date</Data></Cell>
        <Cell><Data ss:Type="String">Manager Location</Data></Cell>
        <Cell><Data ss:Type="String">Profile URL</Data></Cell>
      </Row>
      ${sheet1Rows}
    </Table>
  </Worksheet>

  <!-- Sheet 2 -->
  <Worksheet ss:Name="Active Ads Details">
    <Table>
      <Row>
        <Cell><Data ss:Type="String">Library ID</Data></Cell>
        <Cell><Data ss:Type="String">Advertiser</Data></Cell>
        <Cell><Data ss:Type="String">Status</Data></Cell>
        <Cell><Data ss:Type="String">Started Date</Data></Cell>
        <Cell><Data ss:Type="String">Platforms</Data></Cell>
        <Cell><Data ss:Type="String">Headline</Data></Cell>
        <Cell><Data ss:Type="String">Description</Data></Cell>
        <Cell><Data ss:Type="String">CTA Text</Data></Cell>
        <Cell><Data ss:Type="String">Resolved Destination URL</Data></Cell>
        <Cell><Data ss:Type="String">Ad Copy Text</Data></Cell>
        <Cell><Data ss:Type="String">Tags</Data></Cell>
        <Cell><Data ss:Type="String">Local File Path</Data></Cell>
      </Row>
      ${sheet2Rows}
    </Table>
  </Worksheet>

  <!-- Sheet 3 -->
  <Worksheet ss:Name="Search History Logs">
    <Table>
      <Row>
        <Cell><Data ss:Type="String">Keyword Search</Data></Cell>
        <Cell><Data ss:Type="String">Country Code</Data></Cell>
        <Cell><Data ss:Type="String">Category</Data></Cell>
        <Cell><Data ss:Type="String">Logged Timestamp</Data></Cell>
        <Cell><Data ss:Type="String">Live Ads Count</Data></Cell>
        <Cell><Data ss:Type="String">Search Page URL</Data></Cell>
      </Row>
      ${sheet3Rows}
    </Table>
  </Worksheet>
</Workbook>`;

  triggerDownload(xmlContent, 'meta_competitor_intelligence_report.xls', 'application/vnd.ms-excel;charset=utf-8;');
}

async function exportToJSON() {
  const ads = await db.getAds();
  if (ads.length === 0) {
    alert('No ads available to export.');
    return;
  }
  const jsonContent = JSON.stringify(ads, null, 2);
  triggerDownload(jsonContent, 'meta_competitor_ads.json', 'application/json;charset=utf-8;');
}

// CSV export (opens directly in Excel, Google Sheets, Numbers)
async function exportToCSV() {
  const ads = await db.getAds();
  if (ads.length === 0) {
    alert('No ads available to export.');
    return;
  }

  const cell = (v) => {
    let str = String(v == null ? '' : v);
    // Neutralise spreadsheet formula injection from scraped text
    if (/^[=+\-@\t\r]/.test(str)) str = "'" + str;
    return `"${str.replace(/"/g, '""')}"`;
  };

  const header = ['Library ID', 'Advertiser', 'Status', 'Started Date', 'Platforms', 'Headline', 'Description',
    'CTA', 'Destination URL', 'Destination Domain', 'Ad Copy', 'Tags', 'Media Type', 'Media URL', 'Ad Library Link', 'Saved At'];
  const rows = ads.map(ad => [
    ad.libraryId,
    ad.advertiser,
    ad.status,
    ad.startedDate,
    (ad.platforms || []).join(', '),
    ad.headline,
    ad.description,
    ad.cta,
    ad.resolvedUrl || ad.ctaUrl,
    ad.resolvedDomain,
    ad.primaryText,
    (ad.tags || []).join(', '),
    ad.mediaType,
    ad.mediaType === 'video' ? ad.videoUrl : (ad.mediaUrls || [])[0],
    `https://www.facebook.com/ads/library/?id=${ad.libraryId}`,
    ad.collectedAt ? new Date(ad.collectedAt).toISOString() : ''
  ].map(cell).join(','));

  // BOM so Excel detects UTF-8 (emoji / non-latin ad copy)
  const csv = '﻿' + [header.map(cell).join(','), ...rows].join('\r\n');
  triggerDownload(csv, 'meta_competitor_ads.csv', 'text/csv;charset=utf-8;');
}

// Restore ads from a JSON export (merges into the existing database)
async function importFromJSON(event) {
  const input = event.target;
  const file = input.files && input.files[0];
  input.value = '';
  if (!file) return;

  try {
    const parsed = JSON.parse(await file.text());
    const list = Array.isArray(parsed) ? parsed : (parsed && Array.isArray(parsed.ads) ? parsed.ads : null);
    if (!list) throw new Error('Expected a JSON array of ads (as produced by "Export JSON").');

    let imported = 0;
    for (const item of list) {
      if (!item || typeof item !== 'object') continue;
      const libraryId = String(item.libraryId || '').trim();
      if (!/^\d+$/.test(libraryId)) continue;
      await db.saveAd(Object.assign({}, item, {
        libraryId,
        advertiser: String(item.advertiser || 'Unknown Advertiser'),
        collectedAt: Number(item.collectedAt) || Date.now()
      }));
      imported++;
    }

    alert(`Imported ${imported} ad${imported === 1 ? '' : 's'}.`);
    loadAllViews();
  } catch (err) {
    console.error('Import failed:', err);
    alert('Import failed: ' + err.message);
  }
}

async function urlToBase64(url) {
  if (!url || url.startsWith('data:')) return url;
  try {
    // Timeout-guarded fetch to avoid hanging on slow responses
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 6000);

    const res = await fetch(url, { signal: controller.signal });
    clearTimeout(timeoutId);
    if (!res.ok) return url;

    const blob = await res.blob();
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result);
      reader.onerror = () => resolve(url);
      reader.readAsDataURL(blob);
    });
  } catch (error) {
    console.warn('Failed to fetch image for base64 conversion:', url, error);
    return url; // fallback to original URL if CORS block or offline
  }
}

async function exportHTMLReport() {
  const ads = await db.getAds();
  if (ads.length === 0) {
    alert('No ads available to generate report.');
    return;
  }

  const btnReport = document.getElementById('btn-export-report');
  const originalText = btnReport.innerText;
  btnReport.innerText = '⏳ Compiling Assets...';
  btnReport.disabled = true;

  try {
    const cardHtmlPromises = ads.map(async (ad) => {
      const isVideo = ad.mediaType === 'video';
      let mediaDisplay = '';

      // Convert advertiser avatar to base64
      let avatarBase64 = PLACEHOLDER_AVATAR;
      if (ad.profileImageData) {
        avatarBase64 = ad.profileImageData;
      } else if (ad.profileImage) {
        avatarBase64 = await urlToBase64(ad.profileImage);
      }
      avatarBase64 = safeUrl(avatarBase64, { allowData: true }) || PLACEHOLDER_AVATAR;

      if (isVideo) {
        // Base64 encode the video poster frame. Video streams remain links due to size limits.
        let posterBase64 = ad.thumbnailData || ad.videoThumbnail || '';
        if (posterBase64 && !ad.thumbnailData) {
          posterBase64 = await urlToBase64(posterBase64);
        }
        posterBase64 = safeUrl(posterBase64, { allowData: true });

        mediaDisplay = `
          <div style="margin: 12px 0; border-radius: 8px; overflow: hidden; background: #000; position: relative;">
            <div style="position: absolute; top: 8px; left: 8px; background: rgba(0,0,0,0.8); color:#fff; font-size: 10px; font-weight:bold; padding: 2px 6px; border-radius:4px;">▶ Video</div>
            <video controls poster="${posterBase64}" style="width:100%; display:block;" src="${safeUrl(ad.videoUrl)}"></video>
          </div>`;
      } else if (ad.thumbnailData || (ad.mediaUrls && ad.mediaUrls.length > 0)) {
        // Base64 encode the creative image (stored thumbnail first: CDN links expire)
        let creativeBase64 = ad.thumbnailData || await urlToBase64(ad.mediaUrls[0]);
        creativeBase64 = safeUrl(creativeBase64, { allowData: true });
        mediaDisplay = `<img src="${creativeBase64}" style="width: 100%; border-radius: 8px; margin: 12px 0; object-fit: cover; max-height: 400px;" />`;
      }

      const ctaBadge = ad.cta ? `<span style="background: #e0e7ff; color: #4f46e5; padding: 4px 8px; border-radius: 4px; font-size: 11px; font-weight: 600;">${esc(ad.cta)}</span>` : '';
      const destUrl = safeUrl(ad.resolvedUrl || ad.ctaUrl);

      return `
        <div style="background: #ffffff; border: 1px solid #e2e8f0; border-radius: 12px; padding: 20px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); display: flex; flex-direction: column; gap: 12px;">
          <div style="display: flex; align-items: center; gap: 12px; border-bottom: 1px solid #f1f5f9; padding-bottom: 12px;">
            <img src="${avatarBase64}" style="width: 40px; height: 40px; border-radius: 50%; object-fit: cover;" />
            <div style="flex: 1;">
              <h3 style="margin: 0; font-size: 14px; font-weight: 700; color: #1e293b;">${esc(ad.advertiser)}</h3>
              <p style="margin: 0; font-size: 11px; color: #64748b;">Library ID: ${esc(ad.libraryId)} · Started: ${esc(ad.startedDate || 'Unknown')}</p>
            </div>
            <span style="font-size: 10px; font-weight: 700; text-transform: uppercase; padding: 2px 8px; border-radius: 20px; ${ad.status === 'active' ? 'background: #d1fae5; color: #065f46;' : 'background: #fee2e2; color: #991b1b;'}">${esc(ad.status)}</span>
          </div>

          <div style="font-size: 13px; color: #334155; line-height: 1.6; white-space: pre-wrap; word-break: break-word;">${ad.primaryText ? esc(ad.primaryText) : '<i>No ad copy.</i>'}</div>

          ${mediaDisplay}

          <div style="display: flex; justify-content: space-between; align-items: center; margin-top: auto; border-top: 1px solid #f1f5f9; padding-top: 12px;">
            ${ctaBadge}
            ${destUrl ? `<a href="${destUrl}" target="_blank" rel="noopener noreferrer" style="font-size: 12px; color: #4f46e5; text-decoration: none; font-weight:500;">View Destination Link ↗</a>` : ''}
          </div>
        </div>
      `;
    });

    const cardHtmlList = (await Promise.all(cardHtmlPromises)).join('');

    const reportHtml = `
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="Content-Security-Policy" content="default-src 'none'; img-src data: https:; media-src https:; style-src 'unsafe-inline'">
        <title>Meta Ad Competitor Intelligence Report</title>
        <style>
          body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; background-color: #f8fafc; color: #0f172a; margin: 0; padding: 0; }
          header { background: linear-gradient(135deg, #1e1b4b, #0f172a); color: #fff; padding: 30px 20px; text-align: center; border-bottom: 4px solid #6366f1; }
          header h1 { margin: 0 0 8px 0; font-size: 24px; font-weight: 800; }
          header p { margin: 0; font-size: 14px; color: #94a3b8; }
          .container { max-width: 1200px; margin: 40px auto; padding: 0 20px; }
          .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(360px, 1fr)); gap: 24px; }
          footer { margin-top: 60px; padding: 24px; text-align: center; color: #64748b; font-size: 12px; border-top: 1px solid #e2e8f0; }
        </style>
      </head>
      <body>
        <header>
          <h1>Meta Ad Swipe Report</h1>
          <p>Generated by Meta Competitor Intelligence on ${new Date().toLocaleDateString()} · Stored Count: ${ads.length} Ads</p>
        </header>
        <div class="container">
          <div class="grid">
            ${cardHtmlList}
          </div>
        </div>
        <footer>
          Generated locally. All rights reserved.
        </footer>
      </body>
      </html>
    `;

    triggerDownload(reportHtml, 'meta_intelligence_swipe_file.html', 'text/html;charset=utf-8;');
  } catch (error) {
    console.error('Error generating HTML report:', error);
    alert('Failed to generate HTML report: ' + error.message);
  } finally {
    btnReport.innerText = originalText;
    btnReport.disabled = false;
  }
}

function triggerDownload(content, filename, contentType) {
  const blob = new Blob([content], { type: contentType });
  const url = URL.createObjectURL(blob);

  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();

  document.body.removeChild(a);
  // Revoking immediately can cancel the download in some Chrome versions
  setTimeout(() => URL.revokeObjectURL(url), 10000);
}

// 7. Reset Database
async function resetDatabase() {
  if (confirm('Are you absolutely sure you want to delete ALL saved searches, brands, and ads from your database? This action is irreversible.')) {
    const database = await db.init();

    // Clear all stores
    const stores = ['searches', 'advertisers', 'ads', 'collections'];
    const transaction = database.transaction(stores, 'readwrite');

    stores.forEach(s => {
      transaction.objectStore(s).clear();
    });

    transaction.oncomplete = () => {
      alert('Local intelligence database cleared successfully.');
      loadAllViews();
      loadCollectionsView();
      showSearchEmptyState(true);
    };

    transaction.onerror = (e) => {
      console.error('Clear database error:', e.target.error);
      alert('Error clearing database.');
    };
  }
}

// 8. Settings Management
function loadSettings() {
  chrome.storage.local.get(['aiProvider', 'aiKey', 'aiModel', 'autoDownloadCreatives'], (res) => {
    if (res.aiProvider) document.getElementById('settings-ai-provider').value = res.aiProvider;
    if (res.aiKey) document.getElementById('settings-ai-key').value = res.aiKey;
    if (res.aiModel) document.getElementById('settings-ai-model').value = res.aiModel;
    document.getElementById('settings-auto-download').checked = res.autoDownloadCreatives !== false;
  });
}

function saveSettings() {
  const provider = document.getElementById('settings-ai-provider').value;
  const key = document.getElementById('settings-ai-key').value;
  const model = document.getElementById('settings-ai-model').value;

  chrome.storage.local.set({
    aiProvider: provider,
    aiKey: key.trim(),
    aiModel: model,
    autoDownloadCreatives: document.getElementById('settings-auto-download').checked
  }, () => {
    const status = document.getElementById('settings-status');
    status.classList.remove('hidden');
    setTimeout(() => status.classList.add('hidden'), 3000);
  });
}

// 9. BYOK AI Integration Client
async function runAICognitiveAnalysis(libraryId, buttonEl) {
  chrome.storage.local.get(['aiProvider', 'aiKey', 'aiModel'], async (res) => {
    const key = (res.aiKey || '').trim();
    const provider = res.aiProvider || 'gemini';
    // Fall back to a model that belongs to the selected provider
    let model = res.aiModel || '';
    if (provider === 'gemini' && !/^gemini/i.test(model)) model = 'gemini-2.5-flash';
    if (provider === 'openai' && /^gemini/i.test(model)) model = 'gpt-4o-mini';
    if (!model) model = provider === 'gemini' ? 'gemini-2.5-flash' : 'gpt-4o-mini';

    if (!key) {
      alert('Please configure your API Key in the "⚙️ Settings" tab first.');
      return;
    }

    buttonEl.disabled = true;
    buttonEl.textContent = '🔮 Analyzing...';

    try {
      const adsStore = await db.getStore('ads', 'readonly');
      const ad = await new Promise(resolve => {
        const req = adsStore.get(libraryId);
        req.onsuccess = () => resolve(req.result);
      });

      if (!ad) throw new Error('Ad not found');

      const textContent = `Advertiser: ${ad.advertiser}\nAd Copy: ${ad.primaryText || ''}\nHeadline: ${ad.headline || ''}\nDescription: ${ad.description || ''}`;
      const promptText = `
        You are an AI copywriting analyst. Analyze the following Meta ad. Respond STRICTLY in a valid raw JSON object matching this schema (do not wrap in markdown code blocks like \`\`\`json):
        {
          "hookStrength": 8,
          "hookExplanation": "Direct question targeting high energy bills.",
          "offers": ["Free Quote"],
          "painPoints": ["High energy bills", "Poor airflow"],
          "framework": "PAS (Problem-Agitate-Solve)",
          "funnelStage": "TOF (Top of Funnel)"
        }

        Note: The framework should specify which copywriting framework matches best (AIDA, PAS, BAB, or USP). The funnelStage should evaluate TOF (Top of Funnel), MOF (Middle of Funnel), or BOF (Bottom of Funnel) with a short 1-sentence reason.

        AD DETAILS TO ANALYZE:
        ${textContent}
      `;

      let aiResult = null;

      if (provider === 'gemini') {
        // API key goes in a header rather than the URL so it does not end up in logs
        const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'x-goog-api-key': key },
          body: JSON.stringify({
            contents: [{ parts: [{ text: promptText }] }],
            generationConfig: { responseMimeType: 'application/json' }
          })
        });

        if (!response.ok) {
          const errText = await response.text();
          throw new Error(`Gemini API Error: ${response.status} - ${errText}`);
        }

        const data = await response.json();
        const rawText = data.candidates?.[0]?.content?.parts?.[0]?.text;
        aiResult = parseAIJson(rawText);
      } else {
        // OpenAI
        const response = await fetch('https://api.openai.com/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${key}`
          },
          body: JSON.stringify({
            model: model,
            messages: [{ role: 'user', content: promptText }],
            response_format: { type: 'json_object' }
          })
        });

        if (!response.ok) {
          const errText = await response.text();
          throw new Error(`OpenAI API Error: ${response.status} - ${errText}`);
        }

        const data = await response.json();
        const rawText = data.choices?.[0]?.message?.content;
        aiResult = parseAIJson(rawText);
      }

      if (aiResult) {
        ad.aiAnalysis = aiResult;
        await db.saveAd(ad);
        alert('AI Analysis completed successfully!');
        loadSavedAdsView();
      }
    } catch (err) {
      console.error('AI Analysis failed:', err);
      alert('AI Analysis failed: ' + err.message);
    } finally {
      buttonEl.disabled = false;
      buttonEl.textContent = '🔮 Analyze with AI';
    }
  });
}

// Parse model output that should be JSON (tolerates ```json fences and surrounding text)
function parseAIJson(rawText) {
  if (!rawText) throw new Error('The AI returned an empty response.');
  let text = String(rawText).trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
  const start = text.indexOf('{');
  const end = text.lastIndexOf('}');
  if (start !== -1 && end > start) text = text.slice(start, end + 1);
  return JSON.parse(text);
}

// 10. Canvas Perceptual Hashing & Variation Clustering Engine
function calculateImagePHash(src) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      try {
        const canvas = document.createElement('canvas');
        canvas.width = 8;
        canvas.height = 8;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, 8, 8);

        const imgData = ctx.getImageData(0, 0, 8, 8).data;
        const greys = [];
        let sum = 0;

        for (let i = 0; i < imgData.length; i += 4) {
          const r = imgData[i];
          const g = imgData[i+1];
          const b = imgData[i+2];
          const grey = r * 0.299 + g * 0.587 + b * 0.114;
          greys.push(grey);
          sum += grey;
        }

        const avg = sum / 64;
        let hash = '';
        for (let i = 0; i < 64; i++) {
          hash += greys[i] >= avg ? '1' : '0';
        }
        resolve(hash);
      } catch (e) {
        reject(e);
      }
    };
    img.onerror = (e) => reject(e);
    img.src = src;
  });
}

const pHashFailed = new Set(); // ads whose image could not be hashed this session

async function ensureAdImageHash(ad) {
  if (ad.imageHash) return ad.imageHash;
  if (ad.mediaType !== 'image' || pHashFailed.has(ad.libraryId)) return null;
  const src = ad.thumbnailData || (ad.mediaUrls && ad.mediaUrls[0]);
  if (!src) return null;

  try {
    const hash = await calculateImagePHash(src);
    if (hash) {
      ad.imageHash = hash;
      await db.saveAd(ad);
      return hash;
    }
  } catch (err) {
    pHashFailed.add(ad.libraryId);
    console.warn('pHash calculation failed for ad:', ad.libraryId, err && err.message);
  }
  return null;
}

function getHammingDistance(h1, h2) {
  if (!h1 || !h2 || h1.length !== h2.length) return 99;
  let dist = 0;
  for (let i = 0; i < h1.length; i++) {
    if (h1[i] !== h2[i]) dist++;
  }
  return dist;
}

async function clusterAdsByVariation(ads) {
  // Compute any missing hashes first
  for (const ad of ads) {
    if (ad.mediaType === 'image' && !ad.imageHash && !pHashFailed.has(ad.libraryId)) {
      await ensureAdImageHash(ad);
    }
  }

  const groups = [];
  const visited = new Set();

  for (let i = 0; i < ads.length; i++) {
    const adA = ads[i];
    if (visited.has(adA.libraryId)) continue;

    const group = [adA];
    visited.add(adA.libraryId);

    for (let j = i + 1; j < ads.length; j++) {
      const adB = ads[j];
      if (visited.has(adB.libraryId)) continue;

      if (adA.advertiser !== adB.advertiser) continue;

      let isSimilar = false;

      // Group by image graphic similarity (Hamming distance <= 5)
      if (adA.imageHash && adB.imageHash) {
        const dist = getHammingDistance(adA.imageHash, adB.imageHash);
        if (dist <= 5) isSimilar = true;
      }

      // Group by text content equivalence
      if (!isSimilar && adA.primaryText && adB.primaryText) {
        const cleanA = adA.primaryText.toLowerCase().replace(/[^a-z0-9]/g, '');
        const cleanB = adB.primaryText.toLowerCase().replace(/[^a-z0-9]/g, '');
        if (cleanA === cleanB) isSimilar = true;
      }

      if (isSimilar) {
        group.push(adB);
        visited.add(adB.libraryId);
      }
    }
    groups.push(group);
  }
  return groups;
}

// 11. campaign scaling timeline charts (SVG)
function generateTimelineChartSVG(ads) {
  if (!ads || ads.length === 0) return '';

  const monthCounts = {};
  const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

  ads.forEach(ad => {
    if (!ad.startedDate) return;

    let month = '';
    let year = '';

    const parts = ad.startedDate.split(' ');
    if (parts.length >= 3) {
      month = parts[1];
      year = parts[2];
    } else {
      for (const m of monthNames) {
        if (ad.startedDate.includes(m)) {
          month = m;
          break;
        }
      }
      const yearMatch = ad.startedDate.match(/\d{4}/);
      year = yearMatch ? yearMatch[0] : '';
    }

    if (month && year) {
      const key = `${month} ${year}`;
      monthCounts[key] = (monthCounts[key] || 0) + 1;
    }
  });

  const keys = Object.keys(monthCounts);
  if (keys.length === 0) return '';

  // Sort keys chronologically
  keys.sort((a, b) => {
    const parseMonthYear = (str) => {
      const p = str.split(' ');
      const mIdx = monthNames.indexOf(p[0]);
      const y = parseInt(p[1]) || 0;
      return new Date(y, mIdx, 1);
    };
    return parseMonthYear(a) - parseMonthYear(b);
  });

  const width = 320;
  const height = 100;
  const padding = 20;
  const graphWidth = width - padding * 2;
  const graphHeight = height - padding * 2;

  const maxVal = Math.max(...keys.map(k => monthCounts[k]));
  const stepX = keys.length > 1 ? graphWidth / (keys.length - 1) : graphWidth;

  let points = '';
  let labels = '';
  let gridLines = '';

  gridLines += `<line x1="${padding}" y1="${padding}" x2="${width - padding}" y2="${padding}" stroke="rgba(255,255,255,0.05)" stroke-width="1" />`;
  gridLines += `<line x1="${padding}" y1="${padding + graphHeight/2}" x2="${width - padding}" y2="${padding + graphHeight/2}" stroke="rgba(255,255,255,0.05)" stroke-width="1" />`;
  gridLines += `<line x1="${padding}" y1="${padding + graphHeight}" x2="${width - padding}" y2="${padding + graphHeight}" stroke="rgba(255,255,255,0.1)" stroke-width="1.5" />`;

  keys.forEach((key, idx) => {
    const val = monthCounts[key];
    const x = padding + (idx * stepX);
    const y = padding + graphHeight - (maxVal > 0 ? (val / maxVal) * graphHeight : 0);

    points += `
      <rect x="${x - 6}" y="${y}" width="12" height="${padding + graphHeight - y}" fill="url(#barGradient)" rx="2" />
      <text x="${x}" y="${y - 4}" fill="#a5b4fc" font-size="7" font-weight="700" text-anchor="middle">${val}</text>
    `;

    labels += `<text x="${x}" y="${height - 4}" fill="var(--text-secondary)" font-size="7" text-anchor="middle">${esc(key)}</text>`;
  });

  return `
    <div class="panel-card timeline-chart-card" style="margin-bottom: 12px; padding: 10px;">
      <h4 style="margin: 0 0 8px 0; font-size: 10px; color: var(--text-primary); text-transform: uppercase; letter-spacing: 0.05em; display: flex; align-items: center; gap: 4px;">📈 Campaign Scaling Curve (Active Ads/Mo)</h4>
      <svg width="100%" height="${height}" viewBox="0 0 ${width} ${height}" preserveAspectRatio="xMidYMid meet" style="display: block;">
        <defs>
          <linearGradient id="barGradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stop-color="#6366f1" stop-opacity="0.8" />
            <stop offset="100%" stop-color="#4f46e5" stop-opacity="0.1" />
          </linearGradient>
        </defs>
        ${gridLines}
        ${points}
        ${labels}
      </svg>
    </div>
  `;
}
