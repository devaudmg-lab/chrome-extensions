// Meta Competitor Intelligence - Content Script

let lastUrl = location.href;
let activeSearch = null;
let autoScrollTimer = null;
let isScrolling = false;
let scrollAttempts = 0;
let lastAdCount = 0;
const autoSavedIds = new Set();
let lastAdDetailsSignature = '';
let lastTransparencySignature = '';

let isCurrentAdvertiserWatched = false;
let watchedSnapshotIds = null;
let currentAdvertiserName = '';
let watchCheckedAt = 0;
const WATCH_RECHECK_MS = 15000;

let mainTimer = null;
let domObserver = null;
let domDirty = true;

// Per-card UI lives in a closed shadow root so the page cannot read or restyle it
// (it shows which ads you saved and which brands you watch)
const cardUi = new WeakMap(); // card element -> { host, saveBtn, brandBtn, badge, libraryId }
const savedIds = new Set();   // Library IDs known to be in the database

// After the extension is reloaded or updated, this (orphaned) script can no longer talk
// to the extension. Detect that and shut down quietly instead of throwing every tick.
function isExtensionAlive() {
  try {
    return !!(chrome.runtime && chrome.runtime.id);
  } catch (e) {
    return false;
  }
}

function shutdownOrphanedScript() {
  if (mainTimer) clearInterval(mainTimer);
  mainTimer = null;
  if (autoScrollTimer) clearInterval(autoScrollTimer);
  autoScrollTimer = null;
  isScrolling = false;
  if (domObserver) domObserver.disconnect();
  domObserver = null;
  // Remove buttons that can no longer work; the refreshed page gets fresh ones
  document.querySelectorAll('[data-meta-intel-host]').forEach(el => el.remove());
}

// Safe wrapper around chrome.runtime.sendMessage (never throws, always checks lastError)
function sendToExtension(message, callback) {
  if (!isExtensionAlive()) {
    shutdownOrphanedScript();
    if (callback) callback(null);
    return;
  }
  try {
    chrome.runtime.sendMessage(message, (response) => {
      const err = chrome.runtime.lastError;
      if (callback) callback(err ? null : response, err);
    });
  } catch (e) {
    shutdownOrphanedScript();
    if (callback) callback(null, e);
  }
}

// ---- Shadow DOM styles ----
const UI_CSS = `
:host { all: initial; }
.bar {
  position: absolute; top: 10px; right: 10px; display: flex; gap: 8px; z-index: 9999;
  background: rgba(15, 23, 42, 0.78); backdrop-filter: blur(8px); -webkit-backdrop-filter: blur(8px);
  padding: 6px 8px; border-radius: 20px; border: 1px solid rgba(255, 255, 255, 0.15);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15); opacity: 0.88; transition: opacity 0.2s ease, transform 0.2s ease;
}
.bar:hover, .bar:focus-within { opacity: 1; transform: translateY(-1px); }
button {
  background: rgba(255, 255, 255, 0.12); border: none; border-radius: 12px; color: #fff;
  font: 600 11px/1.2 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
  padding: 5px 9px; cursor: pointer; display: flex; align-items: center; gap: 4px;
  transition: background 0.2s, box-shadow 0.2s, transform 0.2s;
}
button:hover { background: #6366f1; box-shadow: 0 0 8px rgba(99, 102, 241, 0.5); transform: scale(1.03); }
button:active { transform: scale(0.97); }
button:focus-visible { outline: 2px solid #a5b4fc; outline-offset: 2px; }
button.saved { background: #059669; box-shadow: 0 0 8px rgba(16, 185, 129, 0.4); }
button.error { background: #dc2626; }
button[disabled] { cursor: progress; }
.new-badge {
  position: absolute; top: 10px; left: 10px; z-index: 9999; background: #10b981; color: #fff;
  padding: 4px 8px; border-radius: 4px; font: 700 9px/1.2 -apple-system, "Segoe UI", Roboto, Arial, sans-serif;
  letter-spacing: 0.04em; box-shadow: 0 2px 4px rgba(0,0,0,0.2); pointer-events: none;
}
.detect {
  position: fixed; bottom: 20px; left: 20px; z-index: 100000; width: 260px;
  background: linear-gradient(135deg, #1e1b4b, #0f172a); border: 1px solid rgba(99, 102, 241, 0.3);
  border-radius: 12px; padding: 12px 16px; color: #f8fafc; box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
  display: flex; flex-direction: column; gap: 6px; animation: up 0.4s cubic-bezier(0.16, 1, 0.3, 1);
  transition: opacity 0.5s ease;
}
.detect-title { font-size: 12px; font-weight: 700; color: #a5b4fc; text-transform: uppercase; letter-spacing: 0.05em; }
.row { display: flex; justify-content: space-between; font-size: 11px; gap: 8px; }
.label { color: #94a3b8; }
.value { color: #f1f5f9; font-weight: 500; max-width: 150px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
@keyframes up { from { transform: translateY(100px); opacity: 0; } to { transform: none; opacity: 1; } }
`;

let sharedSheet = null;
function attachStyles(root) {
  try {
    if (!sharedSheet) {
      sharedSheet = new CSSStyleSheet();
      sharedSheet.replaceSync(UI_CSS);
    }
    root.adoptedStyleSheets = [sharedSheet];
  } catch (e) {
    const style = document.createElement('style');
    style.textContent = UI_CSS;
    root.appendChild(style);
  }
}

function createShadowHost() {
  const host = document.createElement('div');
  host.setAttribute('data-meta-intel-host', '');
  const root = host.attachShadow({ mode: 'closed' });
  attachStyles(root);
  return { host, root };
}

// Initialize
init();

function init() {
  // Listen for messages from the side panel
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!message || sender.id !== chrome.runtime.id) return false;

    if (message.action === 'START_SCROLL') {
      const limit = Math.max(1, Math.min(1000, parseInt(message.limit, 10) || 200));
      startAutoScroll(limit);
      sendResponse({ success: true, status: 'scrolling_started' });
    } else if (message.action === 'STOP_SCROLL') {
      stopAutoScroll();
      sendResponse({ success: true, status: 'scrolling_stopped' });
    } else if (message.action === 'GET_SCROLL_STATE') {
      sendResponse({ isScrolling, lastAdCount });
    } else if (message.action === 'GET_CURRENT_SEARCH') {
      const current = detectSearchContext();
      sendResponse({ success: true, data: current, isAdLibrary: true });
    } else if (message.action === 'REFRESH_SAVED_STATE') {
      // Ads were deleted, imported or the database was reset in the side panel
      savedIds.clear();
      watchCheckedAt = 0;
      refreshSavedState(findAdCards());
      sendResponse({ success: true });
    }
    return false; // all responses above are synchronous
  });

  // Only re-scan the page when it actually changed (or the URL did)
  domObserver = new MutationObserver(() => { domDirty = true; });
  domObserver.observe(document.documentElement, { childList: true, subtree: true });

  mainTimer = setInterval(tick, 2000);
  setTimeout(() => {
    const searchContext = detectSearchContext();
    if (searchContext) {
      saveSearchContext(searchContext);
      showDetectionBadge(searchContext);
    }
    domDirty = true;
    tick();
  }, 1500);
}

function tick() {
  if (!isExtensionAlive()) {
    shutdownOrphanedScript();
    return;
  }
  const urlChanged = location.href !== lastUrl;
  if (urlChanged) {
    lastUrl = location.href;
    // SPA navigation: the watch state belongs to the previous brand page
    currentAdvertiserName = '';
    isCurrentAdvertiserWatched = false;
    watchedSnapshotIds = null;
    lastTransparencySignature = '';
    const searchContext = detectSearchContext();
    if (searchContext) {
      saveSearchContext(searchContext);
      showDetectionBadge(searchContext);
    }
    domDirty = true;
  }

  const watchStale = isOnBrandPage() && Date.now() - watchCheckedAt > WATCH_RECHECK_MS;
  if (!domDirty && !watchStale) return;
  if (document.hidden && !isScrolling) return; // catch up when the tab is visible again
  domDirty = false;

  injectActionButtons();
  if (urlChanged) markNewSinceSnapshot(); // drop badges that belonged to the previous page
  scrapePageTransparency();
  scrapeAdDetails();
  checkAdvertiserWatchState();
}

function isOnBrandPage() {
  return location.href.includes('view_all_page_id=');
}

// 1. Detect Search Context from URL & DOM
function detectSearchContext() {
  if (!location.href.includes('facebook.com/ads/library')) {
    return null;
  }

  const params = new URL(location.href).searchParams;
  // URLSearchParams already decodes values; decoding again breaks keywords such as "50% off"
  const keyword = (params.get('q') || '').trim();
  const country = params.get('country') || 'ALL';
  const category = params.get('ad_type') || 'all';

  if (!keyword) {
    return null;
  }

  // Generate a unique ID based on keywords, country, category
  const id = `${keyword.toLowerCase()}_${country.toLowerCase()}_${category.toLowerCase()}`;

  activeSearch = {
    id,
    keyword,
    country,
    category,
    url: location.href,
    timestamp: Date.now(),
    adCount: getCardCount()
  };
  return activeSearch;
}

function getCardCount() {
  return findAdCards().length;
}

// Save search to extension IndexedDB via Background Script
function saveSearchContext(context) {
  sendToExtension({ action: 'SAVE_SEARCH', data: context });
}

// Small notice in the corner when a search is detected (closed shadow root)
let detectBadge = null;
function showDetectionBadge(context) {
  if (detectBadge) detectBadge.host.remove();
  const { host, root } = createShadowHost();
  const box = document.createElement('div');
  box.className = 'detect';
  box.setAttribute('role', 'status');
  const title = document.createElement('div');
  title.className = 'detect-title';
  title.textContent = 'Meta Intelligence active';
  box.appendChild(title);
  const valueEls = {};
  [['Keyword', context.keyword], ['Country', context.country], ['Loaded ads', String(context.adCount)]].forEach(([label, value]) => {
    const row = document.createElement('div');
    row.className = 'row';
    const l = document.createElement('span');
    l.className = 'label';
    l.textContent = label;
    const v = document.createElement('span');
    v.className = 'value';
    v.textContent = value;
    row.append(l, v);
    box.appendChild(row);
    valueEls[label] = v;
  });
  root.appendChild(box);
  document.body.appendChild(host);
  const badge = { host, countEl: valueEls['Loaded ads'] };
  detectBadge = badge;

  setTimeout(() => {
    box.style.opacity = '0';
    setTimeout(() => {
      host.remove();
      if (detectBadge === badge) detectBadge = null;
    }, 500);
  }, 6000);
}

// 2. Resilient Ad Card Parsing Heuristics
const LIBRARY_ID_RE = /Library\s*ID:/i;
const countLibraryIds = (text) => (text.match(/Library\s*ID:/gi) || []).length;

// Find all ad card container elements
function findAdCards() {
  const cards = [];
  const seen = new Set();
  if (!document.body) return cards;

  const walk = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  let node;
  while ((node = walk.nextNode())) {
    if (!LIBRARY_ID_RE.test(node.textContent)) continue;

    // Climb parents until the parent holds more than one "Library ID:" label: the
    // element below it is the individual card. textContent is used (not innerText)
    // because it does not force a layout on every step.
    let current = node.parentElement;
    let cardContainer = null;
    for (let i = 0; i < 14 && current; i++) {
      const parent = current.parentElement;
      if (!parent) break;
      if (countLibraryIds(parent.textContent || '') > 1) {
        cardContainer = current;
        break;
      }
      current = parent;
    }

    if (cardContainer && !seen.has(cardContainer) && cardContainer.offsetHeight > 100) {
      seen.add(cardContainer);
      cards.push(cardContainer);
    }
  }
  return cards;
}

function cardLibraryId(card) {
  const m = (card.textContent || '').match(/Library\s*ID:\s*(\d+)/i);
  return m ? m[1] : null;
}

const DATE_PATTERN = '(\\d{1,2}\\s+[A-Za-z]{3,9}\\.?,?\\s+\\d{4}|[A-Za-z]{3,9}\\.?\\s+\\d{1,2},?\\s+\\d{4})';

// Extract fields from a single ad card
function parseAdCard(card) {
  try {
    const cardText = card.innerText || '';
    const lines = cardText.split('\n').map(l => l.trim()).filter(l => l.length > 0);

    // 1. Library ID (ignores potential spacing/newline between "Library" and "ID:")
    const libIdMatch = cardText.match(/Library\s*ID:\s*(\d+)/i);
    const libraryId = libIdMatch ? libIdMatch[1] : null;
    if (!libraryId) return null;

    // 2. Dates. Active ads say "Started running on 13 Oct 2025"; ads that stopped show a
    // range such as "13 Oct 2025 - 20 Nov 2025", which also gives the end date.
    let startedDate = '';
    let endedDate = '';
    const rangeMatch = cardText.match(new RegExp(`${DATE_PATTERN}\\s*[-–]\\s*${DATE_PATTERN}`));
    const startedMatch = cardText.match(new RegExp(`Started running\\s*(?:on)?\\s*${DATE_PATTERN}`, 'i'));
    if (startedMatch) {
      startedDate = startedMatch[1].replace(/\s+/g, ' ').trim();
    } else if (rangeMatch) {
      startedDate = rangeMatch[1].replace(/\s+/g, ' ').trim();
      endedDate = rangeMatch[2].replace(/\s+/g, ' ').trim();
    } else {
      // Unknown date format: keep the old loose capture, limited to one line
      const loose = cardText.match(/Started running\s*(?:on)?\s*([^\n]{6,35})/i);
      if (loose) startedDate = loose[1].split(/\s+(?:Platforms|Library|ID:)/i)[0].trim();
    }

    // 3. Status: the card has a line that reads exactly "Inactive" (ad copy that merely
    // mentions the word must not flip the status)
    const status = lines.some(l => /^inactive$/i.test(l)) ? 'inactive' : 'active';

    // 4. Platforms
    const platforms = [];
    const addPlatform = (p) => { if (!platforms.includes(p)) platforms.push(p); };
    const imagesAndSvgs = card.querySelectorAll('img, svg, [aria-label]');
    for (const el of imagesAndSvgs) {
      const text = el.getAttribute('alt') || el.getAttribute('aria-label') || '';
      if (/facebook/i.test(text)) addPlatform('facebook');
      if (/instagram/i.test(text)) addPlatform('instagram');
      if (/messenger/i.test(text)) addPlatform('messenger');
      if (/audience network/i.test(text)) addPlatform('audience_network');
      if (/threads/i.test(text)) addPlatform('threads');
    }
    // Text fallback (some layouts list the platforms as words)
    if (!platforms.length) {
      if (cardText.includes('Facebook')) addPlatform('facebook');
      if (cardText.includes('Instagram')) addPlatform('instagram');
      if (cardText.includes('Messenger')) addPlatform('messenger');
      if (cardText.includes('Audience Network')) addPlatform('audience_network');
    }

    // 5. Advertiser details. The name is the link to the advertiser's page in the header;
    // never the outbound CTA link (l.facebook.com), which also contains "facebook.com/".
    let advertiser = '';
    let pageUrl = '';
    let profileImage = '';

    // The avatar is usually wrapped in the same link without text: take the first link with a name
    const pageLinks = [
      ...card.querySelectorAll('a[href*="/ads/library/?view_all_page_id="]'),
      ...card.querySelectorAll('a[href*="facebook.com/"]:not([href*="l.facebook.com"]):not([href*="/ads/library/?id="])')
    ];
    const headerAnchor = pageLinks.find(a => a.innerText && a.innerText.trim());
    if (headerAnchor) {
      advertiser = headerAnchor.innerText.trim().split('\n')[0];
      pageUrl = headerAnchor.href;
    } else {
      const heading = card.querySelector('span[style*="font-weight: bold"], div[style*="font-weight: 600"], h4');
      if (heading) advertiser = heading.innerText.trim().split('\n')[0];
    }

    if (!advertiser) {
      advertiser = lines.find(l => !/^(active|inactive)$/i.test(l) && !LIBRARY_ID_RE.test(l)) || 'Unknown Advertiser';
    }

    // Find profile image and creative images with a robust multi-layer heuristic
    const imgElements = Array.from(card.querySelectorAll('img'));
    const creativeImages = [];

    imgElements.forEach((img, index) => {
      const src = img.currentSrc || img.src;
      if (!src || src.startsWith('data:')) return;

      const width = img.offsetWidth || img.naturalWidth || 0;
      const isAvatar = (index === 0) ||
                       src.includes('profile') ||
                       img.closest('a[href*="/ads/library/?view_all_page_id="]') ||
                       img.style.borderRadius === '50%' ||
                       img.classList.contains('profile-image') ||
                       (width > 0 && width < 70);

      if (isAvatar) {
        if (!profileImage) profileImage = src;
      } else if (!creativeImages.includes(src)) {
        creativeImages.push(src);
      }
    });

    // 6. Media Creative
    let mediaType = 'image';
    let mediaUrls = creativeImages;
    let videoUrl = '';
    let videoThumbnail = '';

    const videoElement = card.querySelector('video');
    if (videoElement) {
      mediaType = 'video';
      videoUrl = videoElement.currentSrc || videoElement.src || '';
      videoThumbnail = videoElement.poster || '';
      mediaUrls = videoUrl ? [videoUrl] : [];
    }

    // 7. Text contents. Structure: Header -> Primary Text -> Media -> Footer (Headline + CTA).
    let primaryText = '';
    let headline = '';
    let description = '';
    let cta = '';
    let ctaUrl = '';

    // Separate header components from creative body via <hr> tag to avoid top dropdown triggers
    const hrElement = card.querySelector('hr');
    const creativeContainer = hrElement ? (hrElement.nextElementSibling || card) : card;

    // The footer is the outbound link (l.facebook.com/l.php). On the live Ad Library every
    // line in it (domain, headline, description) is a role="button" element, and the real
    // call to action is the disabled one inside a role="none" wrapper.
    const skipText = /^(See ad details|See summary details|Open Drop-down|Close|Previous items|Next items)$/i;
    const footerLink = creativeContainer.querySelector('a[href*="l.facebook.com/l.php"]') ||
                       card.querySelector('a[href*="l.facebook.com/l.php"]');
    if (footerLink) ctaUrl = footerLink.href;

    const textOf = (el) => (el.innerText || '').trim();
    const scope = footerLink || creativeContainer;
    const buttons = Array.from(scope.querySelectorAll('[role="button"]'))
      .filter(el => textOf(el) && !skipText.test(textOf(el)));

    let ctaElement = buttons.find(el => el.getAttribute('aria-disabled') === 'true' || el.closest('[role="none"]'));
    if (!ctaElement && footerLink) ctaElement = buttons[buttons.length - 1];
    if (!ctaElement && !footerLink) {
      // No outbound link (lead forms, messages): accept a short button label only
      ctaElement = buttons.find(el => textOf(el).length <= 30 && !el.querySelector('[style*="pre-wrap"]'));
    }
    if (ctaElement) cta = textOf(ctaElement).split('\n')[0].slice(0, 100);

    if (footerLink) {
      const isDomain = (t) => !/\s/.test(t) && /^[a-z0-9-]+(\.[a-z0-9-]+)+\/?$/i.test(t);
      let footerTexts = buttons.filter(el => el !== ctaElement && !el.contains(ctaElement) && !(ctaElement && ctaElement.contains(el)))
        .map(textOf);
      if (!footerTexts.length) {
        // Simpler layouts: plain text blocks around the CTA
        footerTexts = Array.from(footerLink.querySelectorAll('div, span'))
          .filter(el => el.children.length === 0)
          .map(textOf);
      }
      footerTexts = footerTexts
        .filter((t, i, all) => t && t !== cta && all.indexOf(t) === i && !isDomain(t) && !/^https?:\/\//i.test(t));
      if (footerTexts.length > 0) headline = footerTexts[0].slice(0, 500);
      if (footerTexts.length > 1) description = footerTexts[1].slice(0, 1000);
    }

    // The primary copy: Meta renders it in a pre-wrap block above the creative. Otherwise
    // fall back to the longest leaf text block on the card.
    const notCopy = (p) => !p || p === headline || p === description || p === cta ||
      LIBRARY_ID_RE.test(p) || /^Started running/i.test(p);
    const preWrap = Array.from(card.querySelectorAll('[style*="pre-wrap"]'))
      .filter(el => !(footerLink && footerLink.contains(el)))
      .map(textOf)
      .filter(t => t.length > 0 && !notCopy(t));
    let rawCopy = preWrap.reduce((a, b) => (a.length >= b.length ? a : b), '');
    if (!rawCopy) {
      const paragraphs = Array.from(card.querySelectorAll('div, span'))
        .filter(d => d.children.length === 0 || Array.from(d.children).every(c => c.tagName === 'BR'))
        .filter(d => !(footerLink && footerLink.contains(d)))
        .map(textOf)
        .filter(t => t.length > 10 && !notCopy(t));
      rawCopy = paragraphs.reduce((a, b) => (a.length >= b.length ? a : b), '');
    }
    // Strip out links (e.g. http://..., https://..., www...) from display ad copy
    primaryText = rawCopy.replace(/(https?:\/\/[^\s]+|www\.[^\s]+|fb\.me\/[^\s]*)/gi, '').trim();

    return {
      libraryId,
      advertiser,
      pageUrl,
      profileImage,
      status,
      startedDate,
      endedDate,
      platforms,
      primaryText,
      headline,
      description,
      cta,
      ctaUrl,
      mediaType,
      mediaUrls,
      videoUrl,
      videoThumbnail,
      collectedAt: Date.now()
    };
  } catch (error) {
    console.warn('Meta Intelligence: could not parse an ad card:', error && error.message);
    return null;
  }
}

// 3. Inject Action Buttons to DOM
function injectActionButtons() {
  const cards = findAdCards();

  if (detectBadge && detectBadge.countEl) detectBadge.countEl.textContent = String(cards.length);

  const fresh = [];
  cards.forEach(card => {
    const existing = cardUi.get(card);
    if (existing && existing.host.isConnected) {
      // Meta re-uses card elements when results change: refresh the state if the ad changed
      const id = cardLibraryId(card);
      if (id && id !== existing.libraryId) {
        existing.libraryId = id;
        setSaveButtonState(existing, savedIds.has(id) ? 'saved' : 'idle');
        if (existing.badge) { existing.badge.remove(); existing.badge = null; }
        fresh.push(card);
      }
      return;
    }

    const { host, root } = createShadowHost();
    if (getComputedStyle(card).position === 'static') card.style.position = 'relative';

    const bar = document.createElement('div');
    bar.className = 'bar';

    const saveBtn = document.createElement('button');
    saveBtn.type = 'button';
    const brandBtn = document.createElement('button');
    brandBtn.type = 'button';
    brandBtn.textContent = '📁 Save Brand';
    brandBtn.title = 'Save every loaded ad from this advertiser';

    const ui = { host, root, saveBtn, brandBtn, badge: null, libraryId: cardLibraryId(card) };
    setSaveButtonState(ui, ui.libraryId && savedIds.has(ui.libraryId) ? 'saved' : 'idle');

    saveBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      e.preventDefault();
      saveSingleCard(card, ui);
    });
    brandBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      e.preventDefault();
      saveBrandAds(card, brandBtn);
    });

    bar.append(saveBtn, brandBtn);
    root.appendChild(bar);
    card.appendChild(host);
    cardUi.set(card, ui);
    fresh.push(card);
  });

  if (fresh.length) {
    refreshSavedState(fresh);
    markNewSinceSnapshot();
  }
}

function setSaveButtonState(ui, state, text) {
  const btn = ui.saveBtn;
  btn.disabled = state === 'busy';
  btn.classList.toggle('saved', state === 'saved');
  btn.classList.toggle('error', state === 'error');
  if (state === 'saved') {
    btn.textContent = text || '✅ Saved';
    btn.title = 'Already in your swipe file. Click to update the saved copy.';
  } else if (state === 'busy') {
    btn.textContent = text || '⏳ Saving...';
  } else if (state === 'error') {
    btn.textContent = text || '❌ Error';
    btn.title = 'Could not save. Refresh the page if you just updated the extension.';
  } else {
    btn.textContent = '💾 Save Ad';
    btn.title = 'Save this ad to your swipe file';
  }
}

// Ask the extension which of these cards are already saved, and mark them
function refreshSavedState(cards) {
  const byId = new Map();
  cards.forEach(card => {
    const ui = cardUi.get(card);
    if (!ui) return;
    ui.libraryId = cardLibraryId(card) || ui.libraryId;
    if (ui.libraryId) byId.set(ui.libraryId, ui);
  });
  if (!byId.size) return;
  sendToExtension({ action: 'GET_SAVED_IDS', libraryIds: [...byId.keys()] }, (res) => {
    if (!res || !res.success) return;
    const found = new Set(res.data || []);
    byId.forEach((ui, id) => {
      if (found.has(id)) savedIds.add(id); else savedIds.delete(id);
      if (!ui.saveBtn.disabled) setSaveButtonState(ui, found.has(id) ? 'saved' : 'idle');
    });
  });
}

// Action: Save single card
function saveSingleCard(card, ui) {
  const adData = parseAdCard(card);
  if (!adData) {
    setSaveButtonState(ui, 'error', '❌ Parse Error');
    return;
  }

  setSaveButtonState(ui, 'busy');
  sendToExtension({ action: 'SAVE_AD', data: adData }, (response) => {
    if (response && response.success) {
      savedIds.add(adData.libraryId);
      setSaveButtonState(ui, 'saved');
    } else {
      setSaveButtonState(ui, 'error');
      console.warn('Meta Intelligence: save failed:', response ? response.error : 'no response');
    }
  });
}

// Action: Save Brand (Collects all currently visible ads from this advertiser)
function saveBrandAds(card, button) {
  const baseData = parseAdCard(card);
  if (!baseData || !baseData.advertiser) {
    button.textContent = '❌ Parse Error';
    return;
  }

  const targetBrand = baseData.advertiser;
  button.textContent = '⏳ Collecting...';
  button.disabled = true;

  const promises = [];
  findAdCards().forEach(c => {
    const data = parseAdCard(c);
    if (data && data.advertiser === targetBrand) {
      promises.push(new Promise((resolve) => {
        sendToExtension({ action: 'SAVE_AD', data }, (res) => {
          const ok = !!(res && res.success);
          if (ok) {
            savedIds.add(data.libraryId);
            const ui = cardUi.get(c);
            if (ui) setSaveButtonState(ui, 'saved');
          }
          resolve(ok);
        });
      }));
    }
  });

  Promise.all(promises).then(results => {
    const savedCount = results.filter(Boolean).length;
    button.textContent = `✅ Saved ${savedCount} ad${savedCount === 1 ? '' : 's'}`;
    button.classList.add('saved');
    setTimeout(() => {
      button.textContent = '📁 Save Brand';
      button.classList.remove('saved');
      button.disabled = false;
    }, 4000);
  });
}

// 4. Auto-scroller engine
function startAutoScroll(limit) {
  if (isScrolling) return;
  isScrolling = true;
  scrollAttempts = 0;
  lastAdCount = getCardCount();
  const startUrl = location.href;

  // Inform the side panel of state change
  sendToExtension({ action: 'SCROLL_STATE_CHANGED', data: { isScrolling, count: lastAdCount } });

  autoScrollTimer = setInterval(() => {
    // The user went to another search or page: stop instead of saving unrelated ads
    if (location.href !== startUrl) {
      stopAutoScroll();
      return;
    }
    const cards = findAdCards();
    const currentCount = cards.length;

    // Trigger action buttons injection on new cards immediately
    injectActionButtons();

    // Save newly loaded ads once each (avoids re-saving and re-downloading every tick)
    cards.forEach(c => {
      const id = cardLibraryId(c);
      if (!id || autoSavedIds.has(id)) return;
      const data = parseAdCard(c);
      if (!data) return;
      autoSavedIds.add(id);
      sendToExtension({ action: 'SAVE_AD', data }, (res) => {
        if (res && res.success) {
          savedIds.add(id);
          const ui = cardUi.get(c);
          if (ui) setSaveButtonState(ui, 'saved');
        } else {
          autoSavedIds.delete(id); // retry on the next tick
        }
      });
    });

    if (currentCount >= limit) {
      stopAutoScroll();
      return;
    }

    window.scrollTo(0, document.body.scrollHeight);

    // Detect bottom of page
    if (currentCount === lastAdCount) {
      scrollAttempts++;
      if (scrollAttempts >= 3) stopAutoScroll();
    } else {
      scrollAttempts = 0;
      lastAdCount = currentCount;
      sendToExtension({ action: 'SCROLL_PROGRESS', data: { count: currentCount } });
    }
  }, 1500);
}

function stopAutoScroll() {
  if (!isScrolling) return;
  isScrolling = false;
  if (autoScrollTimer) {
    clearInterval(autoScrollTimer);
    autoScrollTimer = null;
  }
  sendToExtension({ action: 'SCROLL_STATE_CHANGED', data: { isScrolling, count: getCardCount() } });
}

function getBrandPageName() {
  const pageTitleEl = document.querySelector('h2') || document.querySelector('h1');
  if (!pageTitleEl) return '';
  const pageName = pageTitleEl.innerText.trim().split('\n')[0];
  if (!pageName || pageName.includes('Meta Ad Library') || pageName === 'Facebook') return '';
  return pageName;
}

// Scrape advertiser transparency stats on brand-specific searches
function scrapePageTransparency() {
  if (!isOnBrandPage()) return;
  const pageName = getBrandPageName();
  if (!pageName) return;

  const textWalk = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  let node;
  let pageCreated = '';
  let businessName = '';
  let country = '';
  const mergedPages = [];

  while ((node = textWalk.nextNode())) {
    const text = node.textContent.trim();
    if (!text || text.length > 300) continue;
    if (text.includes('Page created on') || text.includes('Page created:')) {
      pageCreated = text.split(/(?:created on|created:)/i)[1]?.trim() || '';
    } else if (text.includes('Business name') || text.includes('Verified business name')) {
      businessName = text.split(/(?:name)/i)[1]?.replace(/^[:\s]+/, '').trim() || '';
    } else if (text.includes('Primary country/region') || text.includes('Page manager location')) {
      country = text.split(/(?:location|region)/i)[1]?.replace(/^[:\s]+/, '').trim() || '';
    } else if (text.includes('Merged with')) {
      mergedPages.push(text.replace('Merged with', '').trim());
    }
  }

  if (pageCreated || businessName || country || mergedPages.length > 0) {
    const transparency = { businessName, pageCreated, country, mergedPages };

    // Only persist when something changed
    const signature = JSON.stringify([pageName, transparency]);
    if (signature === lastTransparencySignature) return;
    lastTransparencySignature = signature;

    sendToExtension({
      action: 'SAVE_ADVERTISER',
      data: { name: pageName, pageUrl: location.href, lastUpdated: Date.now(), transparency }
    });
  }
}

// Scrapes the ad details dialog or a direct ad page (?id=...) for lead forms and extra assets.
// Only runs when such a view is open, so details are never attached to a random grid card.
function scrapeAdDetails() {
  const urlId = new URL(location.href).searchParams.get('id');
  const dialog = document.querySelector('[role="dialog"]');
  if (!dialog && !urlId) return;
  const detailsRoot = dialog || document.body;

  let libraryId = null;
  const textNodes = document.createTreeWalker(detailsRoot, NodeFilter.SHOW_TEXT);
  let node;
  while ((node = textNodes.nextNode())) {
    const match = node.textContent.match(/Library\s*ID:\s*(\d+)/i);
    if (match) {
      libraryId = match[1];
      break;
    }
  }
  if (!libraryId && !dialog) libraryId = /^\d+$/.test(urlId || '') ? urlId : null;
  if (!libraryId) return;

  const additionalTexts = [];
  const additionalLinks = [];
  let advertiserInfo = '';

  // 1. Lead form texts and links
  const headings = Array.from(detailsRoot.querySelectorAll('div, span, h1, h2, h3, h4'))
    .filter(el => el.children.length === 0 && el.textContent.trim() === 'Additional assets from this ad');

  if (headings.length > 0) {
    // Climb from the heading to the block that holds the asset lists
    let assetsContainer = headings[0].parentElement;
    for (let i = 0; i < 6 && assetsContainer && !assetsContainer.querySelector('li'); i++) {
      assetsContainer = assetsContainer.parentElement;
    }
    if (assetsContainer && assetsContainer.querySelector('li')) {
      const walker = document.createTreeWalker(assetsContainer, NodeFilter.SHOW_ELEMENT);
      let element;
      let captureMode = null; // 'links' or 'text'

      while ((element = walker.nextNode())) {
        const text = element.innerText?.trim();
        if (!text) continue;

        if (text === 'Links') {
          captureMode = 'links';
        } else if (/^Text$/i.test(text) || (text.startsWith('Text') && text.length < 20)) {
          captureMode = 'text';
        } else if (element.tagName === 'LI') {
          if (captureMode === 'links') {
            const anchor = element.querySelector('a');
            const value = anchor && anchor.href ? anchor.href : text;
            if (!additionalLinks.includes(value)) additionalLinks.push(value);
          } else if (captureMode === 'text') {
            if (!additionalTexts.includes(text)) additionalTexts.push(text);
          }
        }
      }
    }
  }

  // 2. Advertiser "More info" description
  const advertiserBlock = Array.from(detailsRoot.querySelectorAll('div, span, h3, h4'))
    .filter(el => el.children.length === 0 && el.textContent.trim() === 'More info');

  if (advertiserBlock.length > 0) {
    const nextSib = advertiserBlock[0].nextElementSibling || advertiserBlock[0].parentElement?.nextElementSibling;
    if (nextSib) advertiserInfo = nextSib.innerText.trim();
  }

  if (additionalLinks.length > 0 || additionalTexts.length > 0 || advertiserInfo) {
    const signature = JSON.stringify([libraryId, additionalLinks, additionalTexts, advertiserInfo]);
    if (signature === lastAdDetailsSignature) return;
    lastAdDetailsSignature = signature;

    sendToExtension({
      action: 'UPDATE_AD_DETAILS',
      libraryId,
      details: { additionalLinks, additionalTexts, advertiserInfo, lastDetailedUpdate: Date.now() }
    });
  }
}

// Queries the background script for the advertiser's watchlist/snapshot status.
// Re-checked every few seconds so a new snapshot taken in the side panel shows up.
function checkAdvertiserWatchState() {
  if (!isOnBrandPage()) return;
  const pageName = getBrandPageName();
  if (!pageName) return;

  if (currentAdvertiserName === pageName && Date.now() - watchCheckedAt < WATCH_RECHECK_MS) return;
  currentAdvertiserName = pageName;
  watchCheckedAt = Date.now();

  sendToExtension({ action: 'GET_WATCHED_STATE', name: pageName }, (res) => {
    if (res && res.success) {
      if (currentAdvertiserName !== pageName) return; // navigated meanwhile
      isCurrentAdvertiserWatched = res.isWatched;
      watchedSnapshotIds = res.isWatched && res.lastSnapshotAt ? new Set(res.snapshotIds || []) : null;
      markNewSinceSnapshot();
    } else {
      watchCheckedAt = 0; // retry on the next tick
    }
  });
}

// Badge ads that appeared after the watched advertiser's last snapshot (and remove
// stale badges when the watch state or snapshot changed)
function markNewSinceSnapshot() {
  const active = isOnBrandPage() && isCurrentAdvertiserWatched && watchedSnapshotIds;
  findAdCards().forEach(card => {
    const ui = cardUi.get(card);
    if (!ui) return;
    const id = cardLibraryId(card);
    const isNew = !!(active && id && !watchedSnapshotIds.has(id));
    if (isNew && !ui.badge) {
      const badge = document.createElement('div');
      badge.className = 'new-badge';
      badge.textContent = '✨ NEW SINCE SNAPSHOT';
      ui.root.appendChild(badge);
      ui.badge = badge;
    } else if (!isNew && ui.badge) {
      ui.badge.remove();
      ui.badge = null;
    }
  });
}
