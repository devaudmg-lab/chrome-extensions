// Meta Competitor Intelligence - Content Script

let lastUrl = location.href;
let activeSearch = null;
let autoScrollTimer = null;
let isScrolling = false;
let scrollAttempts = 0;
let lastAdCount = 0;
const autoSavedIds = new Set();
let lastAdDetailsSignature = '';
let lastTransparencySignature = '';

let isCurrentAdvertiserWatched = false;
let watchedSnapshotIds = null;
let currentAdvertiserName = '';

let mainTimer = null;

// After the extension is reloaded or updated, this (orphaned) script can no longer talk
// to the extension. Detect that and shut down quietly instead of throwing every tick.
function isExtensionAlive() {
  try {
    return !!(chrome.runtime && chrome.runtime.id);
  } catch (e) {
    return false;
  }
}

function shutdownOrphanedScript() {
  if (mainTimer) clearInterval(mainTimer);
  mainTimer = null;
  if (autoScrollTimer) clearInterval(autoScrollTimer);
  autoScrollTimer = null;
  isScrolling = false;
}

// Safe wrapper around chrome.runtime.sendMessage (never throws, always checks lastError)
function sendToExtension(message, callback) {
  if (!isExtensionAlive()) {
    shutdownOrphanedScript();
    if (callback) callback(null);
    return;
  }
  try {
    chrome.runtime.sendMessage(message, (response) => {
      const err = chrome.runtime.lastError;
      if (callback) callback(err ? null : response, err);
    });
  } catch (e) {
    shutdownOrphanedScript();
    if (callback) callback(null, e);
  }
}

// Initialize
init();

function init() {
  // Listen for messages from background/sidepanel
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    
    if (message.action === 'START_SCROLL') {
      startAutoScroll(message.limit || 200);
      sendResponse({ success: true, status: 'scrolling_started' });
    } else if (message.action === 'STOP_SCROLL') {
      stopAutoScroll();
      sendResponse({ success: true, status: 'scrolling_stopped' });
    } else if (message.action === 'GET_SCROLL_STATE') {
      sendResponse({ isScrolling, lastAdCount });
    } else if (message.action === 'GET_CURRENT_SEARCH') {
      const current = detectSearchContext();
      sendResponse({ success: true, data: current });
    }
    return false; // all responses above are synchronous
  });

  // Watch for URL changes (dynamic SPA navigation)
  mainTimer = setInterval(() => {
    if (!isExtensionAlive()) {
      shutdownOrphanedScript();
      return;
    }
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      const searchContext = detectSearchContext();
      if (searchContext) {
        saveSearchContext(searchContext);
      }
    }
    
    // Periodically run card injection, page transparency, ad details, and watch state checkers
    injectActionButtons();
    scrapePageTransparency();
    scrapeAdDetails();
    checkAdvertiserWatchState();
  }, 2000);

  // Initial detection
  setTimeout(() => {
    const searchContext = detectSearchContext();
    if (searchContext) {
      saveSearchContext(searchContext);
    }
    injectActionButtons();
    scrapePageTransparency();
    scrapeAdDetails();
    checkAdvertiserWatchState();
  }, 3000);
}

// 1. Detect Search Context from URL & DOM
function detectSearchContext() {
  if (!location.href.includes('facebook.com/ads/library')) {
    return null;
  }

  const urlObj = new URL(location.href);
  const params = urlObj.searchParams;

  // Extract query parameters
  const keyword = params.get('q') || '';
  const country = params.get('country') || 'ALL';
  const category = params.get('ad_type') || 'all';

  // If there's no active search, try to extract from UI inputs
  if (!keyword) {
    return null;
  }

  // Generate a unique ID based on keywords, country, category
  const id = `${keyword.toLowerCase().trim()}_${country.toLowerCase()}_${category.toLowerCase()}`;
  
  activeSearch = {
    id,
    keyword: decodeURIComponent(keyword),
    country,
    category,
    url: location.href,
    timestamp: Date.now(),
    adCount: getCardCount()
  };

  showDetectionBadge(activeSearch);
  return activeSearch;
}

function getCardCount() {
  return findAdCards().length;
}

// Save search to extension IndexedDB via Background Script
function saveSearchContext(context) {
  sendToExtension({
    action: 'SAVE_SEARCH',
    data: context
  });
}

// Show a sleek notification badge on the page
function showDetectionBadge(context) {
  let badge = document.getElementById('meta-intel-badge');
  if (!badge) {
    badge = document.createElement('div');
    badge.id = 'meta-intel-badge';
    badge.className = 'meta-intel-detection-badge';
    document.body.appendChild(badge);
  }

  badge.innerHTML = `
    <div class="meta-intel-badge-title">
      <span>🛡️ Meta Intelligence Active</span>
    </div>
    <div class="meta-intel-badge-row">
      <span class="meta-intel-badge-label">Keyword:</span>
      <span class="meta-intel-badge-value">${escapeHtml(context.keyword)}</span>
    </div>
    <div class="meta-intel-badge-row">
      <span class="meta-intel-badge-label">Country:</span>
      <span class="meta-intel-badge-value">${escapeHtml(context.country)}</span>
    </div>
    <div class="meta-intel-badge-row">
      <span class="meta-intel-badge-label">Loaded Ads:</span>
      <span class="meta-intel-badge-value" id="meta-intel-badge-count">${context.adCount}</span>
    </div>
  `;

  // Auto-hide after 5 seconds
  setTimeout(() => {
    if (badge) {
      badge.style.transition = 'opacity 0.5s ease';
      badge.style.opacity = '0';
      setTimeout(() => badge.remove(), 500);
    }
  }, 6000);
}

function escapeHtml(str) {
  return String(str).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

// 2. Resilient Ad Card Parsing Heuristics
// Find all ad card container elements
function findAdCards() {
  const cards = [];
  const libraryIdElements = [];

  // Walk DOM to find text matching "Library ID:"
  const walk = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  let node;
  while (node = walk.nextNode()) {
    if (node.textContent.includes('Library ID:')) {
      libraryIdElements.push(node);
    }
  }

  for (const element of libraryIdElements) {
    // Climb parents until we find the individual card container.
    // Heuristic: The container has exactly one "Library ID:" label.
    // If we go one level higher and it has multiple "Library ID:", we've hit the list grid.
    let current = element;
    let cardContainer = null;
    
    for (let i = 0; i < 12; i++) {
      if (!current.parentElement) break;
      const parent = current.parentElement;
      
      const textMatches = parent.innerText ? (parent.innerText.match(/Library ID:/g) || []).length : 0;
      if (textMatches > 1) {
        // Parent contains more than one ad card, so 'current' is our card container!
        cardContainer = current;
        break;
      }
      current = parent;
    }

    if (cardContainer && cardContainer.offsetHeight > 100) {
      if (!cards.includes(cardContainer)) {
        cards.push(cardContainer);
      }
    }
  }
  return cards;
}

// Extract fields from a single ad card
function parseAdCard(card) {
  try {
    const cardText = card.innerText || '';
    
    // 1. Library ID (ignores potential spacing/newline between "Library" and "ID:")
    const libIdMatch = cardText.match(/Library\s*ID:\s*(\d+)/i);
    const libraryId = libIdMatch ? libIdMatch[1] : null;
    if (!libraryId) return null;

    // 2. Started Date (ignores potential spacing/newline between "Started running on" and the date string)
    // The date itself must stay on one line, otherwise the following ad copy gets captured
    const startedMatch = cardText.match(/Started running\s*(?:on)?\s*([\w\d  ,\/.-]{6,35})/i);
    let startedDate = '';
    if (startedMatch) {
      // Normalize all duplicate/newline whitespaces into a single space
      startedDate = startedMatch[1].replace(/\s+/g, ' ').trim();
      // Remove trailing words in case other line details were captured
      startedDate = startedDate.split(/\s+(?:Platforms|Library|ID:)/i)[0].trim();
    }

    // 3. Status
    let status = 'active';
    if (cardText.toLowerCase().includes('inactive')) {
      status = 'inactive';
    }

    // 4. Platforms
    const platforms = [];
    if (cardText.includes('Facebook')) platforms.push('facebook');
    if (cardText.includes('Instagram')) platforms.push('instagram');
    if (cardText.includes('Messenger')) platforms.push('messenger');
    if (cardText.includes('Audience Network')) platforms.push('audience_network');
    
    // Fallback: search SVG titles / image alt tags inside card
    const imagesAndSvgs = card.querySelectorAll('img, svg');
    for (const el of imagesAndSvgs) {
      const alt = el.getAttribute('alt') || '';
      const aria = el.getAttribute('aria-label') || '';
      const text = alt || aria;
      if (/facebook/i.test(text) && !platforms.includes('facebook')) platforms.push('facebook');
      if (/instagram/i.test(text) && !platforms.includes('instagram')) platforms.push('instagram');
      if (/messenger/i.test(text) && !platforms.includes('messenger')) platforms.push('messenger');
      if (/audience/i.test(text) && !platforms.includes('audience_network')) platforms.push('audience_network');
    }

    // 5. Advertiser details
    // The advertiser name is usually the bold link in the top header.
    // Let's find links pointing to page URLs or search queries, or the first bold text.
    let advertiser = '';
    let pageUrl = '';
    let profileImage = '';

    const headerAnchor = card.querySelector('a[href*="/ads/library/?view_all_page_id="]') || 
                         card.querySelector('a[href*="facebook.com/"]');
    if (headerAnchor) {
      advertiser = headerAnchor.innerText.trim();
      pageUrl = headerAnchor.href;
    } else {
      // Fallback: search for bold spans/divs near the top
      const heading = card.querySelector('span[style*="font-weight: bold"], div[style*="font-weight: 600"], h4');
      if (heading) {
        advertiser = heading.innerText.trim();
      }
    }

    if (!advertiser) {
      // Simple parse: grab first line of text
      const lines = cardText.split('\n').map(l => l.trim()).filter(l => l.length > 0);
      advertiser = lines[0] || 'Unknown Advertiser';
    }

    // Find profile image and creative images with a robust multi-layer heuristic
    const imgElements = Array.from(card.querySelectorAll('img'));
    let creativeImages = [];
    
    imgElements.forEach((img, index) => {
      const src = img.src;
      if (!src || src.startsWith('data:')) return;
      
      const width = img.offsetWidth || img.naturalWidth || 0;
      const height = img.offsetHeight || img.naturalHeight || 0;
      
      // Avatar heuristic: 
      // - First image in card DOM order
      // - URL contains "profile"
      // - Inside a link pointing to facebook pages
      // - Explicitly rounded borders (style or class)
      // - Small dimensions if loaded (between 10px and 70px)
      const isAvatar = (index === 0) || 
                       src.includes('profile') || 
                       img.closest('a[href*="/ads/library/?view_all_page_id="]') || 
                       img.style.borderRadius === '50%' ||
                       img.classList.contains('profile-image') ||
                       (width > 0 && width < 70);
                       
      if (isAvatar) {
        if (!profileImage) profileImage = src;
      } else {
        creativeImages.push(src);
      }
    });

    // 6. Media Creative
    let mediaType = 'image';
    let mediaUrls = creativeImages;
    let videoUrl = '';
    let videoThumbnail = '';

    const videoElement = card.querySelector('video');
    if (videoElement) {
      mediaType = 'video';
      videoUrl = videoElement.src || '';
      videoThumbnail = videoElement.poster || '';
      mediaUrls = [videoUrl];
    }

    // 7. Text contents
    // Primary text is generally after the header info and before the creative asset.
    // Let's look for divs that hold text blocks.
    // The structural pattern is: Header -> Primary Text (Ad Copy) -> Media -> Footer (Headline + CTA).
    // Let's extract all texts and categorize them by position.
    let primaryText = '';
    let headline = '';
    let description = '';
    let cta = '';
    let ctaUrl = '';

    // Extract copy: look for elements with primary font size (usually 14px or 15px) or between header and media.
    // Let's grab all text elements and filter out header metadata (Library ID, platforms, advertiser name).
    const allDivs = Array.from(card.querySelectorAll('div, span'))
      .map(el => el.innerText ? el.innerText.trim() : '')
      .filter((text, index, self) => text.length > 0 && self.indexOf(text) === index);

    // Filter text that represents card details
    const cleanTexts = allDivs.filter(txt => {
      return !txt.includes('Library ID:') && 
             !txt.includes('Started running on') && 
             !txt.startsWith('Active') && 
             !txt.startsWith('Inactive') && 
             txt !== advertiser &&
             !platforms.some(p => txt.toLowerCase() === p);
    });

    // Heuristics for copy, headline, CTA
    // Separate header components from creative body via <hr> tag to avoid top dropdown triggers
    const hrElement = card.querySelector('hr');
    const creativeContainer = hrElement ? (hrElement.nextElementSibling || card) : card;

    // Find CTA button inside the creative container
    const ctaButtons = Array.from(creativeContainer.querySelectorAll('div[role="button"], a[role="button"]'));
    const validCta = ctaButtons.filter(el => {
      const text = el.innerText ? el.innerText.trim() : '';
      return text !== '' && 
             !/See ad details/i.test(text) && 
             !/Open Drop-down/i.test(text) && 
             !/Close/i.test(text);
    });

    let ctaElement = null;
    if (validCta.length > 0) {
      ctaElement = validCta[0];
      cta = ctaElement.innerText.trim();
    }
    
    // Find CTA target redirect link
    const footerLink = creativeContainer.querySelector('a[href*="l.facebook.com/l.php"]') || 
                       card.querySelector('a[href*="l.facebook.com/l.php"]');
    if (footerLink) {
      ctaUrl = footerLink.href;
    }

    // If we have a footer section, we can extract headline and description from it
    // The footer container is usually at the bottom next to the CTA button.
    if (ctaElement) {
      const footerParent = ctaElement.closest('div').parentElement;
      if (footerParent) {
        const headings = footerParent.querySelectorAll('span, div');
        const footerTexts = Array.from(headings)
          .map(h => h.innerText ? h.innerText.trim() : '')
          .filter(t => t.length > 0 && t !== cta);

        if (footerTexts.length > 0) headline = footerTexts[0];
        if (footerTexts.length > 1) description = footerTexts[1];
      }
    }

    // Let's find the primary copy
    // It's usually the longest text block located above the media container.
    const paragraphs = Array.from(card.querySelectorAll('div'))
      .filter(d => d.children.length === 0 && d.innerText && d.innerText.trim().length > 10)
      .map(d => d.innerText.trim());

    // Filter out matches that are actually footer elements
    const bodyCopyOptions = paragraphs.filter(p => p !== headline && p !== description && p !== cta && !p.includes('Library ID:'));
    if (bodyCopyOptions.length > 0) {
      // Pick the longest one as the primary ad copy
      const rawCopy = bodyCopyOptions.reduce((a, b) => a.length > b.length ? a : b, '');
      // Strip out links (e.g. http://..., https://..., www...) from display ad copy
      primaryText = rawCopy.replace(/(https?:\/\/[^\s]+|www\.[^\s]+|fb\.me\/[^\s]*)/gi, '').trim();
    }

    return {
      libraryId,
      advertiser,
      pageUrl,
      profileImage,
      status,
      startedDate,
      platforms,
      primaryText,
      headline,
      description,
      cta,
      ctaUrl,
      mediaType,
      mediaUrls,
      videoUrl,
      videoThumbnail,
      collectedAt: Date.now()
    };
  } catch (error) {
    console.error('Error parsing individual ad card:', error);
    return null;
  }
}

// 3. Inject Action Buttons to DOM
function injectActionButtons() {
  const cards = findAdCards();
  
  // Update badge count if displayed
  const badgeCount = document.getElementById('meta-intel-badge-count');
  if (badgeCount) {
    badgeCount.innerText = cards.length;
  }

  cards.forEach(card => {
    // Check if buttons are already injected
    if (card.querySelector('.meta-intel-card-bar') || card.classList.contains('meta-intel-processed')) {
      return;
    }

    card.classList.add('meta-intel-card-wrapper');
    card.classList.add('meta-intel-processed');

    // Create action bar overlay
    const bar = document.createElement('div');
    bar.className = 'meta-intel-card-bar';

    const saveAdBtn = document.createElement('button');
    saveAdBtn.className = 'meta-intel-btn';
    saveAdBtn.innerHTML = '💾 Save Ad';
    saveAdBtn.onclick = (e) => {
      e.stopPropagation();
      e.preventDefault();
      saveSingleCard(card, saveAdBtn);
    };

    const saveBrandBtn = document.createElement('button');
    saveBrandBtn.className = 'meta-intel-btn';
    saveBrandBtn.innerHTML = '📁 Save Brand';
    saveBrandBtn.onclick = (e) => {
      e.stopPropagation();
      e.preventDefault();
      saveBrandAds(card, saveBrandBtn);
    };

    bar.appendChild(saveAdBtn);
    bar.appendChild(saveBrandBtn);
    card.appendChild(bar);

    // Watchlist Snapshot Comparison: Check if this is a new ad launched since last snapshot
    if (isCurrentAdvertiserWatched && watchedSnapshotIds) {
      const cardText = card.innerText || '';
      const libIdMatch = cardText.match(/Library\s*ID:\s*(\d+)/i);
      const libraryId = libIdMatch ? libIdMatch[1] : null;
      
      if (libraryId && !watchedSnapshotIds.includes(libraryId) && !card.querySelector('.meta-intel-snapshot-badge')) {
        const snapshotBadge = document.createElement('div');
        snapshotBadge.className = 'meta-intel-snapshot-badge';
        snapshotBadge.innerText = '✨ NEW SINCE SNAPSHOT';
        snapshotBadge.setAttribute('style', 'background: #10b981; color: white; padding: 4px 8px; border-radius: 4px; font-weight: bold; font-size: 8px; position: absolute; top: 10px; right: 10px; z-index: 10; box-shadow: 0 2px 4px rgba(0,0,0,0.2); pointer-events: none;');
        card.style.position = 'relative';
        card.appendChild(snapshotBadge);
      }
    }
  });
}

// Action: Save single card
function saveSingleCard(card, button) {
  const adData = parseAdCard(card);
  if (!adData) {
    button.innerHTML = '❌ Parse Error';
    return;
  }

  button.innerHTML = '⏳ Saving...';
  sendToExtension({
    action: 'SAVE_AD',
    data: adData
  }, (response) => {
    if (response && response.success) {
      button.innerHTML = '✅ Saved';
      button.className = 'meta-intel-btn meta-intel-btn-saved';
    } else {
      button.innerHTML = '❌ Error';
      console.error('Save failed:', response ? response.error : 'No response');
    }
  });
}

// Action: Save Brand (Collects all currently visible ads from this advertiser)
function saveBrandAds(card, button) {
  const baseData = parseAdCard(card);
  if (!baseData || !baseData.advertiser) {
    button.innerHTML = '❌ Parse Error';
    return;
  }

  const targetBrand = baseData.advertiser;
  button.innerHTML = '⏳ Collecting...';

  const allCards = findAdCards();
  let count = 0;
  let promises = [];

  allCards.forEach(c => {
    const data = parseAdCard(c);
    if (data && data.advertiser === targetBrand) {
      count++;
      const p = new Promise((resolve) => {
        sendToExtension({
          action: 'SAVE_AD',
          data: data
        }, (res) => resolve(res && res.success));
      });
      promises.push(p);
    }
  });

  Promise.all(promises).then(results => {
    const savedCount = results.filter(Boolean).length;
    button.innerHTML = `✅ Saved ${savedCount} Ads`;
    button.className = 'meta-intel-btn meta-intel-btn-saved';
    setTimeout(() => {
      button.innerHTML = '📁 Save Brand';
      button.className = 'meta-intel-btn';
    }, 4000);
  });
}

// 4. Auto-scroller engine
function startAutoScroll(limit) {
  if (isScrolling) return;
  isScrolling = true;
  scrollAttempts = 0;
  lastAdCount = getCardCount();

  console.log(`Starting auto scroll. Current cards: ${lastAdCount}, limit: ${limit}`);
  
  // Inform the side panel of state change
  sendToExtension({ action: 'SCROLL_STATE_CHANGED', data: { isScrolling, count: lastAdCount } });

  autoScrollTimer = setInterval(() => {
    const cards = findAdCards();
    const currentCount = cards.length;
    
    // Trigger action buttons injection on new cards immediately
    injectActionButtons();

    // Auto-save newly scrolled ads in background if they are part of active search
    cards.forEach(c => {
      const data = parseAdCard(c);
      if (data && !autoSavedIds.has(data.libraryId)) {
        // Send silently to DB (once per ad, to avoid re-saving and re-downloading every tick)
        autoSavedIds.add(data.libraryId);
        sendToExtension({ action: 'SAVE_AD', data });
      }
    });

    // Check limits
    if (currentCount >= limit) {
      console.log(`Auto scroll hit limits (${currentCount} >= ${limit}). Stopping.`);
      stopAutoScroll();
      return;
    }

    // Scroll page
    window.scrollTo(0, document.body.scrollHeight);

    // Detect bottom of page
    if (currentCount === lastAdCount) {
      scrollAttempts++;
      if (scrollAttempts >= 3) {
        console.log('No new ads loaded after 3 scrolls. Reached bottom.');
        stopAutoScroll();
      }
    } else {
      scrollAttempts = 0;
      lastAdCount = currentCount;
      // Inform side panel of progress
      sendToExtension({ action: 'SCROLL_PROGRESS', data: { count: currentCount } });
    }
  }, 1500);
}

function stopAutoScroll() {
  if (!isScrolling) return;
  isScrolling = false;
  if (autoScrollTimer) {
    clearInterval(autoScrollTimer);
    autoScrollTimer = null;
  }
  console.log('Auto scroll stopped. Final count:', getCardCount());
  sendToExtension({ action: 'SCROLL_STATE_CHANGED', data: { isScrolling, count: getCardCount() } });
}

// Scrape advertiser transparency stats on brand-specific searches
function scrapePageTransparency() {
  if (!location.href.includes('view_all_page_id=')) return;

  // Locate the page title
  const pageTitleEl = document.querySelector('h2') || document.querySelector('h1') || document.querySelector('span[style*="font-size"]');
  if (!pageTitleEl) return;
  const pageName = pageTitleEl.innerText.trim();
  if (!pageName || pageName.includes('Meta Ad Library') || pageName.includes('Facebook')) return;

  const textWalk = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  let node;
  let pageCreated = '';
  let businessName = '';
  let country = '';
  const mergedPages = [];

  while (node = textWalk.nextNode()) {
    const text = node.textContent.trim();
    if (text.includes('Page created on') || text.includes('Page created:')) {
      pageCreated = text.split(/(?:created on|created:)/i)[1]?.trim() || '';
    } else if (text.includes('Business name') || text.includes('Verified business name')) {
      businessName = text.split(/(?:name)/i)[1]?.trim() || '';
    } else if (text.includes('Primary country/region') || text.includes('Page manager location')) {
      country = text.split(/(?:location|region)/i)[1]?.trim() || '';
    } else if (text.includes('Merged with')) {
      mergedPages.push(text.replace('Merged with', '').trim());
    }
  }

  // If any values were extracted, update advertiser details
  if (pageCreated || businessName || country || mergedPages.length > 0) {
    const transparency = {
      businessName,
      pageCreated,
      country,
      mergedPages
    };

    // Only persist when something changed (this runs every 2 seconds)
    const signature = JSON.stringify([pageName, transparency]);
    if (signature === lastTransparencySignature) return;
    lastTransparencySignature = signature;

    sendToExtension({
      action: 'SAVE_ADVERTISER',
      data: {
        name: pageName,
        pageUrl: location.href,
        lastUpdated: Date.now(),
        transparency: transparency
      }
    });
  }
}

// Scrapes overlay detail modal or direct ad details pages (?id=...) for Lead Forms & extra resources
function scrapeAdDetails() {
  const urlObj = new URL(location.href);
  let libraryId = urlObj.searchParams.get('id');

  // Prefer an open ad-details dialog so details aren't attached to the first card in the grid
  const detailsRoot = document.querySelector('[role="dialog"]') || document.body;

  // Search for the Library ID label in the active DOM if not in URL
  if (!libraryId) {
    const textNodes = document.createTreeWalker(detailsRoot, NodeFilter.SHOW_TEXT);
    let node;
    while (node = textNodes.nextNode()) {
      const match = node.textContent.match(/Library\s*ID:\s*(\d+)/i);
      if (match) {
        libraryId = match[1];
        break;
      }
    }
  }

  if (!libraryId) return;

  let additionalTexts = [];
  let additionalLinks = [];
  let advertiserInfo = '';

  // 1. Scrape Lead Form Texts & Privacy Links
  const headings = Array.from(detailsRoot.querySelectorAll('div, span, h1, h2, h3, h4'))
    .filter(el => el.innerText && el.innerText.trim() === 'Additional assets from this ad');

  if (headings.length > 0) {
    const assetsContainer = headings[0].closest('div')?.parentElement;
    if (assetsContainer) {
      const walker = document.createTreeWalker(assetsContainer, NodeFilter.SHOW_ELEMENT);
      let element;
      let captureMode = null; // 'links' or 'text'

      while (element = walker.nextNode()) {
        const text = element.innerText?.trim();
        if (!text) continue;

        if (text === 'Links') {
          captureMode = 'links';
        } else if (text.startsWith('Text')) {
          captureMode = 'text';
        } else if (element.tagName === 'LI') {
          if (captureMode === 'links') {
            const anchor = element.querySelector('a');
            if (anchor && anchor.href && !additionalLinks.includes(anchor.href)) {
              additionalLinks.push(anchor.href);
            } else if (!additionalLinks.includes(text)) {
              additionalLinks.push(text);
            }
          } else if (captureMode === 'text') {
            if (!additionalTexts.includes(text)) {
              additionalTexts.push(text);
            }
          }
        }
      }
    }
  }

  // 2. Scrape advertiser details descriptions
  const advertiserBlock = Array.from(detailsRoot.querySelectorAll('div, span, h3, h4'))
    .filter(el => el.innerText && el.innerText.trim() === 'More info');

  if (advertiserBlock.length > 0) {
    const nextSib = advertiserBlock[0].nextElementSibling;
    if (nextSib) {
      advertiserInfo = nextSib.innerText.trim();
    }
  }

  // Save parsed data to IndexedDB
  if (additionalLinks.length > 0 || additionalTexts.length > 0 || advertiserInfo) {
    // Skip if nothing changed since the last 2-second tick
    const signature = JSON.stringify([libraryId, additionalLinks, additionalTexts, advertiserInfo]);
    if (signature === lastAdDetailsSignature) return;
    lastAdDetailsSignature = signature;

    sendToExtension({
      action: 'UPDATE_AD_DETAILS',
      libraryId: libraryId,
      details: {
        additionalLinks,
        additionalTexts,
        advertiserInfo,
        lastDetailedUpdate: Date.now()
      }
    });
  }
}

// Queries the background script for active advertiser's watchlist/snapshot status
function checkAdvertiserWatchState() {
  if (!location.href.includes('view_all_page_id=')) return;

  const pageTitleEl = document.querySelector('h2') || document.querySelector('h1') || document.querySelector('span[style*="font-size"]');
  if (!pageTitleEl) return;
  const pageName = pageTitleEl.innerText.trim();
  if (!pageName || pageName.includes('Meta Ad Library') || pageName.includes('Facebook')) return;

  if (currentAdvertiserName === pageName) return; // cache checked page
  currentAdvertiserName = pageName;

  sendToExtension({
    action: 'GET_WATCHED_STATE',
    name: pageName
  }, (res) => {
    if (res && res.success) {
      isCurrentAdvertiserWatched = res.isWatched;
      watchedSnapshotIds = res.snapshotIds || [];
      markNewSinceSnapshot();
    } else {
      currentAdvertiserName = ''; // retry on the next tick
    }
  });
}

// Badge ads that appeared after the watched advertiser's last snapshot. Also runs once the
// watch state arrives, because the action buttons may have been injected before that.
function markNewSinceSnapshot() {
  if (!isCurrentAdvertiserWatched || !watchedSnapshotIds) return;
  findAdCards().forEach(card => {
    if (card.querySelector('.meta-intel-snapshot-badge')) return;
    const libIdMatch = (card.innerText || '').match(/Library\s*ID:\s*(\d+)/i);
    const libraryId = libIdMatch ? libIdMatch[1] : null;
    if (libraryId && !watchedSnapshotIds.includes(libraryId)) {
      const snapshotBadge = document.createElement('div');
      snapshotBadge.className = 'meta-intel-snapshot-badge';
      snapshotBadge.innerText = '✨ NEW SINCE SNAPSHOT';
      snapshotBadge.setAttribute('style', 'background: #10b981; color: white; padding: 4px 8px; border-radius: 4px; font-weight: bold; font-size: 8px; position: absolute; top: 10px; right: 10px; z-index: 10; box-shadow: 0 2px 4px rgba(0,0,0,0.2); pointer-events: none;');
      card.style.position = 'relative';
      card.appendChild(snapshotBadge);
    }
  });
}
