# Meta Competitor Intelligence

Meta Competitor Intelligence turns the public Meta Ad Library (`facebook.com/ads/library`) into your own private, searchable swipe file. Save competitors' ads with one click, organise them with tags and folders, watch advertisers for new launches, and export everything. All data is stored locally in your browser.

## Features

- **One-click saving**: "Save Ad" and "Save Brand" buttons appear on every ad card in the Ad Library. Ads you already saved are marked **✅ Saved** (also after a reload), so you never collect the same ad twice.
- **Collect All**: auto-scrolls a search and saves every ad it loads (50 to 500 ads).
- **Side panel workspace**: one search box that matches ad copy, headlines, brands, CTAs, landing domains, tags and your notes (every word must match); filter by brand, folder or tag, and sort by newest saved, newest launched, longest running or brand. The Search tab follows the browser tab you are looking at.
- **Private notes**: write down why an ad works (📝 Note on any card, Ctrl+Enter to save). Notes are searchable and included in every export.
- **Days live**: every card shows how long the ad has run. For ads that stopped, the real start-to-end range from the Ad Library is used, so "longest running" is not inflated by ads that ended months ago.
- **Split-test diffs**: variations of the same ad are grouped automatically (same copy, or the same creative detected with an image fingerprint that tells apart creatives built from one template), and each variation shows exactly what changed (headline, CTA, word-by-word copy changes, or a different creative).
- **Folders and tags without pop-up dialogs**: an inline picker files an ad into one or more folders, creates new folders, and suggests tags you already use (Winner, Hook, UGC, Offer...). Folders can be deleted without losing their ads.
- **Insights tab**: saved/active counts, video share, median days live, the longest-running ads (usually the profitable ones), launches per month, top calls to action, landing domains, placements and a brand-by-brand comparison.
- **Images that last**: a small thumbnail of every saved creative is stored in the database, so saved ads keep their images after Meta's links expire.
- **Landing page tracing**: shows the real destination domain and UTM parameters behind each CTA.
- **Brand profiles**: page transparency details, a monthly launch timeline, and "Watch" mode that flags ads that are new since your last snapshot. Watched brands show when the snapshot was taken and how many saved ads are newer; **Check now** opens every watched brand in the Ad Library in one click.
- **Optional AI analysis** (bring your own Google Gemini or OpenAI API key): hook strength, offers, pain points, copy framework and funnel stage.
- **Export and full backup**: CSV, Excel and a self-contained HTML swipe report (with notes and tags). **Backup (JSON)** saves everything: ads with thumbnails, notes and tags, brand profiles with watch snapshots, folders and search history. **Restore backup** merges it back (imported files are validated field by field).
- **Optional creative downloads**: saves each ad's image/video to `Downloads/MetaIntelligence/creatives/` (can be turned off in Settings).

- **Friendly basics**: a first-run guide, toast notifications instead of blocking alerts, clear empty states, a saved-ads counter in the header, and remembered sort order.

## Keyboard shortcuts

| Shortcut | Action |
| --- | --- |
| `Alt+Shift+M` | Open the side panel (change it at `chrome://extensions/shortcuts`) |
| `/` | Jump to the Ads tab and search saved ads |
| `Alt+1` ... `Alt+6` | Switch tabs (Search, Ads, Brands, Insights, History, Settings) |
| `Esc` | Close the folder/tag picker, or clear the ad search |
| `Enter` (in the picker) | Create the folder or add the tag you typed |
| `Ctrl+Enter` (in the note editor) | Save the note |

## Install (Load unpacked)

1. Download the ZIP and extract it to a folder.
2. Open `chrome://extensions` in Chrome (or another Chromium browser).
3. Turn on **Developer mode** (top right).
4. Click **Load unpacked** and select the extracted folder (the one that contains `manifest.json`).
5. Open the [Meta Ad Library](https://www.facebook.com/ads/library/), search for a competitor, and click the extension icon to open the side panel.

If you reload or update the extension, refresh any open Ad Library tabs.

## Permissions

| Permission | Why it is needed |
| --- | --- |
| `www.facebook.com/ads/library/*` | Adds the Save buttons to Ad Library pages and reads the ads you choose to save. |
| `l.facebook.com/*` | Resolves Meta's outbound links to find each ad's real landing page. |
| `*.fbcdn.net/*` | Loads ad images and videos from Meta's CDN for thumbnails, downloads and the HTML report. |
| `sidePanel` | Shows the workspace in Chrome's side panel. |
| `storage` | Saves your settings (including an optional AI API key) on this computer. The storage is restricted to the extension's own pages, so scripts running on web pages cannot read the key. |
| `downloads` | Saves exports and (optionally) ad creatives to your Downloads folder. |

Version 1.3.0 adds no new permissions (it no longer injects a stylesheet into the Ad Library: the buttons live in a closed shadow root). The keyboard shortcut uses the manifest `commands` key, which is not a permission. "Check now" opens normal browser tabs and does not need the `tabs` permission.

Landing pages are decoded from Meta's own outbound link (`l.facebook.com/l.php?u=...`), so the extension never sends a request to the advertiser's website. Thumbnails and creative downloads are only fetched from Meta's CDN (`fbcdn.net`).

## Privacy

There is no server. Saved ads, brands, searches and settings stay in your browser. Nothing is sent anywhere unless you use AI analysis, in which case the ad's text is sent to the AI provider you picked (Google or OpenAI) with your own API key.

This extension is not affiliated with or endorsed by Meta.
