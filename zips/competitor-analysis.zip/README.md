# Meta Competitor Intelligence

Meta Competitor Intelligence turns the public Meta Ad Library (`facebook.com/ads/library`) into your own private, searchable swipe file. Save competitors' ads with one click, organise them with tags and folders, watch advertisers for new launches, and export everything. All data is stored locally in your browser.

## Features

- **One-click saving**: "Save Ad" and "Save Brand" buttons appear on every ad card in the Ad Library.
- **Collect All**: auto-scrolls a search and saves every ad it loads (50 to 500 ads).
- **Side panel workspace**: search ad copy, filter by brand or folder, tag ads (Winner, Hook, ...), and group split-test variations automatically.
- **Images that last**: a small thumbnail of every saved creative is stored in the database, so saved ads keep their images after Meta's links expire.
- **Landing page tracing**: shows the real destination domain and UTM parameters behind each CTA.
- **Brand profiles**: page transparency details, a monthly launch timeline, and "Watch" mode that flags ads that are new since your last snapshot.
- **Optional AI analysis** (bring your own Google Gemini or OpenAI API key): hook strength, offers, pain points, copy framework and funnel stage.
- **Export and backup**: CSV, Excel, JSON, a self-contained HTML swipe report, and JSON import to restore a backup.
- **Optional creative downloads**: saves each ad's image/video to `Downloads/MetaIntelligence/creatives/` (can be turned off in Settings).

## Install (Load unpacked)

1. Download the ZIP and extract it to a folder.
2. Open `chrome://extensions` in Chrome (or another Chromium browser).
3. Turn on **Developer mode** (top right).
4. Click **Load unpacked** and select the extracted folder (the one that contains `manifest.json`).
5. Open the [Meta Ad Library](https://www.facebook.com/ads/library/), search for a competitor, and click the extension icon to open the side panel.

If you reload or update the extension, refresh any open Ad Library tabs.

## Permissions

| Permission | Why it is needed |
| --- | --- |
| `www.facebook.com/ads/library/*` | Adds the Save buttons to Ad Library pages and reads the ads you choose to save. |
| `l.facebook.com/*` | Resolves Meta's outbound links to find each ad's real landing page. |
| `*.fbcdn.net/*` | Loads ad images and videos from Meta's CDN for thumbnails, downloads and the HTML report. |
| `sidePanel` | Shows the workspace in Chrome's side panel. |
| `storage` | Saves your settings (including an optional AI API key) on this computer. |
| `downloads` | Saves exports and (optionally) ad creatives to your Downloads folder. |

## Privacy

There is no server. Saved ads, brands, searches and settings stay in your browser. Nothing is sent anywhere unless you use AI analysis, in which case the ad's text is sent to the AI provider you picked (Google or OpenAI) with your own API key.

This extension is not affiliated with or endorsed by Meta.
