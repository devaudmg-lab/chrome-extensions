const DB_NAME = 'MetaIntelligenceDB';
const DB_VERSION = 2;

const db = {
  dbInstance: null,

  init() {
    return new Promise((resolve, reject) => {
      if (this.dbInstance) {
        return resolve(this.dbInstance);
      }

      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onupgradeneeded = (event) => {
        const database = event.target.result;

        // Searches store (history of searches)
        if (!database.objectStoreNames.contains('searches')) {
          database.createObjectStore('searches', { keyPath: 'id' });
        }

        // Advertisers store (competitor profiles)
        if (!database.objectStoreNames.contains('advertisers')) {
          database.createObjectStore('advertisers', { keyPath: 'name' });
        }

        // Ads store (captured ads)
        if (!database.objectStoreNames.contains('ads')) {
          const adStore = database.createObjectStore('ads', { keyPath: 'libraryId' });
          adStore.createIndex('advertiser', 'advertiser', { unique: false });
          adStore.createIndex('collectedAt', 'collectedAt', { unique: false });
        }

        // Collections store (Phase 2 folders)
        if (!database.objectStoreNames.contains('collections')) {
          database.createObjectStore('collections', { keyPath: 'id', autoIncrement: true });
        }
      };

      request.onsuccess = (event) => {
        this.dbInstance = event.target.result;
        resolve(this.dbInstance);
      };

      request.onerror = (event) => {
        console.error('IndexedDB open error:', event.target.error);
        reject(event.target.error);
      };
    });
  },

  async getStore(storeName, mode = 'readonly') {
    const database = await this.init();
    const transaction = database.transaction(storeName, mode);
    return transaction.objectStore(storeName);
  },

  // Search Context Operations
  async saveSearch(searchData) {
    const store = await this.getStore('searches', 'readwrite');
    return new Promise((resolve, reject) => {
      const request = store.put(searchData);
      request.onsuccess = () => resolve(searchData);
      request.onerror = (e) => reject(e.target.error);
    });
  },

  async getSearches() {
    const store = await this.getStore('searches', 'readonly');
    return new Promise((resolve, reject) => {
      const request = store.getAll();
      request.onsuccess = () => {
        // Sort searches by timestamp descending
        const data = request.result || [];
        data.sort((a, b) => b.timestamp - a.timestamp);
        resolve(data);
      };
      request.onerror = (e) => reject(e.target.error);
    });
  },

  async deleteSearch(id) {
    const store = await this.getStore('searches', 'readwrite');
    return new Promise((resolve, reject) => {
      const request = store.delete(id);
      request.onsuccess = () => resolve();
      request.onerror = (e) => reject(e.target.error);
    });
  },

  // Advertiser Operations
  async saveAdvertiser(advertiserData) {
    // Merge with the existing record so periodic transparency scrapes don't wipe
    // watchlist state, snapshots, counters or profile images
    const store = await this.getStore('advertisers', 'readwrite');
    return new Promise((resolve, reject) => {
      const getRequest = store.get(advertiserData.name);
      getRequest.onsuccess = () => {
        const merged = Object.assign({}, getRequest.result || {}, advertiserData);
        const request = store.put(merged);
        request.onsuccess = () => resolve(merged);
        request.onerror = (e) => reject(e.target.error);
      };
      getRequest.onerror = (e) => reject(e.target.error);
    });
  },

  async getAdvertisers() {
    const store = await this.getStore('advertisers', 'readonly');
    return new Promise((resolve, reject) => {
      const request = store.getAll();
      request.onsuccess = () => resolve(request.result || []);
      request.onerror = (e) => reject(e.target.error);
    });
  },

  async deleteAdvertiser(name) {
    const store = await this.getStore('advertisers', 'readwrite');
    return new Promise((resolve, reject) => {
      const request = store.delete(name);
      request.onsuccess = () => resolve();
      request.onerror = (e) => reject(e.target.error);
    });
  },

  // Ad Operations
  async saveAd(adData) {
    // Re-saving an existing ad (auto-scroll, enrichment, AI analysis) merges into the
    // stored record so tags, resolved links, local download paths etc. are preserved
    // and the advertiser counter is only incremented for genuinely new ads.
    const database = await this.init();
    return new Promise((resolve, reject) => {
      const transaction = database.transaction(['ads', 'advertisers'], 'readwrite');
      const adStore = transaction.objectStore('ads');
      const advertiserStore = transaction.objectStore('advertisers');
      let merged = adData;

      const getAdReq = adStore.get(adData.libraryId);
      getAdReq.onsuccess = () => {
        const existing = getAdReq.result;
        merged = existing ? Object.assign({}, existing, adData, { collectedAt: existing.collectedAt || adData.collectedAt }) : adData;
        adStore.put(merged);

        if (adData.advertiser) {
          const checkReq = advertiserStore.get(adData.advertiser);
          checkReq.onsuccess = () => {
            if (!checkReq.result) {
              advertiserStore.put({
                name: adData.advertiser,
                pageUrl: adData.pageUrl || '',
                profileImage: adData.profileImage || '',
                firstSeen: Date.now(),
                lastUpdated: Date.now(),
                totalAdsCollected: 1
              });
            } else if (!existing) {
              const adv = checkReq.result;
              adv.lastUpdated = Date.now();
              adv.totalAdsCollected = (adv.totalAdsCollected || 0) + 1;
              if (!adv.profileImage && adData.profileImage) adv.profileImage = adData.profileImage;
              advertiserStore.put(adv);
            }
          };
        }
      };

      transaction.oncomplete = () => resolve(merged);
      transaction.onerror = (e) => reject(e.target.error);
      transaction.onabort = (e) => reject(e.target.error || new Error('Transaction aborted'));
    });
  },

  async getAds(advertiserName = null) {
    const store = await this.getStore('ads', 'readonly');
    return new Promise((resolve, reject) => {
      if (advertiserName) {
        const index = store.index('advertiser');
        const request = index.getAll(IDBKeyRange.only(advertiserName));
        request.onsuccess = () => {
          const sorted = request.result || [];
          sorted.sort((a, b) => b.collectedAt - a.collectedAt);
          resolve(sorted);
        };
        request.onerror = (e) => reject(e.target.error);
      } else {
        const request = store.getAll();
        request.onsuccess = () => {
          const sorted = request.result || [];
          sorted.sort((a, b) => b.collectedAt - a.collectedAt);
          resolve(sorted);
        };
        request.onerror = (e) => reject(e.target.error);
      }
    });
  },

  async deleteAd(libraryId) {
    // Also keep the advertiser's "ads saved" counter in sync
    const database = await this.init();
    return new Promise((resolve, reject) => {
      const transaction = database.transaction(['ads', 'advertisers'], 'readwrite');
      const adStore = transaction.objectStore('ads');
      const advertiserStore = transaction.objectStore('advertisers');

      const getReq = adStore.get(libraryId);
      getReq.onsuccess = () => {
        const existing = getReq.result;
        adStore.delete(libraryId);
        if (existing && existing.advertiser) {
          const advReq = advertiserStore.get(existing.advertiser);
          advReq.onsuccess = () => {
            const adv = advReq.result;
            if (adv) {
              adv.totalAdsCollected = Math.max(0, (adv.totalAdsCollected || 1) - 1);
              advertiserStore.put(adv);
            }
          };
        }
      };

      transaction.oncomplete = () => resolve();
      transaction.onerror = (e) => reject(e.target.error);
      transaction.onabort = (e) => reject(e.target.error || new Error('Transaction aborted'));
    });
  },

  // Tag Operations
  async addTagToAd(libraryId, tag) {
    const store = await this.getStore('ads', 'readwrite');
    return new Promise((resolve, reject) => {
      const getRequest = store.get(libraryId);
      getRequest.onsuccess = () => {
        const ad = getRequest.result;
        if (!ad) return reject(new Error('Ad not found'));
        ad.tags = ad.tags || [];
        if (!ad.tags.includes(tag)) {
          ad.tags.push(tag);
          const putRequest = store.put(ad);
          putRequest.onsuccess = () => resolve(ad);
          putRequest.onerror = (e) => reject(e.target.error);
        } else {
          resolve(ad);
        }
      };
      getRequest.onerror = (e) => reject(e.target.error);
    });
  },

  async removeTagFromAd(libraryId, tag) {
    const store = await this.getStore('ads', 'readwrite');
    return new Promise((resolve, reject) => {
      const getRequest = store.get(libraryId);
      getRequest.onsuccess = () => {
        const ad = getRequest.result;
        if (!ad) return reject(new Error('Ad not found'));
        ad.tags = ad.tags || [];
        const index = ad.tags.indexOf(tag);
        if (index > -1) {
          ad.tags.splice(index, 1);
          const putRequest = store.put(ad);
          putRequest.onsuccess = () => resolve(ad);
          putRequest.onerror = (e) => reject(e.target.error);
        } else {
          resolve(ad);
        }
      };
      getRequest.onerror = (e) => reject(e.target.error);
    });
  },

  // Collection (Folder) Operations
  async saveCollection(collectionData) {
    const store = await this.getStore('collections', 'readwrite');
    return new Promise((resolve, reject) => {
      const request = store.put(collectionData);
      request.onsuccess = (e) => {
        if (!collectionData.id) {
          collectionData.id = e.target.result; // capture auto-increment key
        }
        resolve(collectionData);
      };
      request.onerror = (e) => reject(e.target.error);
    });
  },

  async getCollections() {
    const store = await this.getStore('collections', 'readonly');
    return new Promise((resolve, reject) => {
      const request = store.getAll();
      request.onsuccess = () => resolve(request.result || []);
      request.onerror = (e) => reject(e.target.error);
    });
  },

  async deleteCollection(id) {
    const store = await this.getStore('collections', 'readwrite');
    return new Promise((resolve, reject) => {
      const request = store.delete(Number(id));
      request.onsuccess = () => resolve();
      request.onerror = (e) => reject(e.target.error);
    });
  },

  async addAdToCollection(adId, collectionId) {
    const store = await this.getStore('collections', 'readwrite');
    return new Promise((resolve, reject) => {
      const getRequest = store.get(Number(collectionId));
      getRequest.onsuccess = () => {
        const coll = getRequest.result;
        if (!coll) return reject(new Error('Collection not found'));
        coll.adIds = coll.adIds || [];
        if (!coll.adIds.includes(adId)) {
          coll.adIds.push(adId);
          const putRequest = store.put(coll);
          putRequest.onsuccess = () => resolve(coll);
          putRequest.onerror = (e) => reject(e.target.error);
        } else {
          resolve(coll);
        }
      };
      getRequest.onerror = (e) => reject(e.target.error);
    });
  },

  async removeAdFromCollection(adId, collectionId) {
    const store = await this.getStore('collections', 'readwrite');
    return new Promise((resolve, reject) => {
      const getRequest = store.get(Number(collectionId));
      getRequest.onsuccess = () => {
        const coll = getRequest.result;
        if (!coll) return reject(new Error('Collection not found'));
        coll.adIds = coll.adIds || [];
        const idx = coll.adIds.indexOf(adId);
        if (idx > -1) {
          coll.adIds.splice(idx, 1);
          const putRequest = store.put(coll);
          putRequest.onsuccess = () => resolve(coll);
          putRequest.onerror = (e) => reject(e.target.error);
        } else {
          resolve(coll);
        }
      };
      getRequest.onerror = (e) => reject(e.target.error);
    });
  },

  // Watch Advertiser Operations
  async toggleWatchAdvertiser(name, isWatching) {
    const store = await this.getStore('advertisers', 'readwrite');
    return new Promise((resolve, reject) => {
      const getRequest = store.get(name);
      getRequest.onsuccess = () => {
        const adv = getRequest.result;
        if (!adv) return reject(new Error('Advertiser not found'));
        adv.isWatched = isWatching;
        if (!isWatching) {
          adv.snapshotIds = []; // clear snapshots if unwatched
          adv.lastSnapshotAt = null;
        }
        const putRequest = store.put(adv);
        putRequest.onsuccess = () => resolve(adv);
        putRequest.onerror = (e) => reject(e.target.error);
      };
      getRequest.onerror = (e) => reject(e.target.error);
    });
  },

  async saveAdvertiserSnapshot(name, libraryIds) {
    const store = await this.getStore('advertisers', 'readwrite');
    return new Promise((resolve, reject) => {
      const getRequest = store.get(name);
      getRequest.onsuccess = () => {
        const adv = getRequest.result;
        if (!adv) return reject(new Error('Advertiser not found'));
        adv.snapshotIds = libraryIds || [];
        adv.lastSnapshotAt = Date.now();
        const putRequest = store.put(adv);
        putRequest.onsuccess = () => resolve(adv);
        putRequest.onerror = (e) => reject(e.target.error);
      };
      getRequest.onerror = (e) => reject(e.target.error);
    });
  }
};

// Make accessible in global scope (Service Worker or Window)
if (typeof self !== 'undefined') {
  self.db = db;
}
