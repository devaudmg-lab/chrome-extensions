# Musicox

Musicox plays music in the background from a YouTube link or a direct audio URL (MP3, AAC, OGG, internet radio streams). Playback keeps going after you close the popup, so you don't need a YouTube tab open.

## Features

- **YouTube and audio URLs**: paste a `youtube.com/watch`, `youtu.be`, `shorts` or `live` link, or any direct audio/stream URL.
- **Background playback**: audio runs in a hidden offscreen document and keeps playing while you browse.
- **Play / pause / stop, volume and loop** controls.
- **Resume**: if you play the same track again later, it picks up where you paused (even after Chrome closed the idle player).
- **Recent tracks**: the last 8 tracks are listed in the popup. Click one to play it again.
- **Use tab**: fills in the URL of the tab you're on (for example a YouTube video page).
- **Clear errors**: shows why a track can't play (invalid URL, unsupported format, video not embeddable, removed video).

Note: some YouTube videos (often music labels and some live streams) don't allow embedding. Those can't be played by Musicox, and the popup will tell you so.

## Install (Load unpacked)

1. Download and unzip the Musicox ZIP.
2. Open `chrome://extensions` in Chrome.
3. Turn on **Developer mode** (top right).
4. Click **Load unpacked** and select the unzipped folder (the one containing `manifest.json`).
5. Pin Musicox from the puzzle-piece menu, then click the icon to open the player.

## Usage

Paste a URL and press **Play** (or Enter). Close the popup and the music keeps playing. Open the popup again to pause, change the volume, toggle loop, or pick a recent track.

## Permissions

| Permission | Why |
| --- | --- |
| `offscreen` | Runs the hidden player page that keeps audio playing after the popup closes. |
| `storage` | Remembers volume, loop, the last track and position, and recent tracks on your device. |
| `activeTab` | Only used when you click **Use tab**, to read the current tab's URL. |
| `declarativeNetRequestWithHostAccess` + access to `www.youtube.com` | YouTube's embedded player refuses to play inside an extension unless the request has a referrer. Musicox adds one to its own embedded-player requests only. It does not read or change YouTube pages you visit. |

Musicox has no server and no analytics. Nothing leaves your browser except the requests to the audio or YouTube URL you choose to play.

## Files

- `manifest.json`: extension configuration
- `background.js`: service worker. It creates the offscreen player, relays commands, and saves state.
- `offscreen.html` / `offscreen.js`: audio engine (HTML5 audio and the YouTube embed, controlled through postMessage, with no remote scripts)
- `popup.html` / `popup.css` / `popup.js`: player UI
- `icons/`: extension icons
