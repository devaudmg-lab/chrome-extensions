# Musicox

Musicox plays music in the background from YouTube videos, whole YouTube playlists or direct audio URLs (MP3, AAC, OGG, internet radio streams). Playback keeps going after you close the popup, so you don't need a YouTube tab open.

## Features

- **YouTube and audio URLs**: paste a `youtube.com/watch`, `youtu.be`, `shorts` or `live` link, or any direct audio/stream URL.
- **YouTube playlists**: paste any link with a `list=` parameter (a `youtube.com/playlist?list=...` page or a video opened inside a playlist) and Musicox plays the whole playlist. The popup shows the video title and its position (for example *Playlist · 4 / 12*). The Queue tab lists every video of the playlist, and you can click one to jump to it. Videos that can't be embedded are skipped.
- **Your own queue**: mix YouTube videos, YouTube playlists and audio URLs. Paste one or several links (separated by spaces or new lines) and press **+ Queue** (or Shift+Enter). Drag items or use the arrows to reorder them, and remove items with ✕. When a track ends, the next one starts. A playlist counts as one queue item and plays to its end first. If you remove the track that is playing, it finishes and the queue carries on with the item that came after it.
- **Play next**: Alt+Enter in the link field (or **↪** next to a recent track) puts the link right after the current track instead of at the end.
- **Saved playlists**: **Save** names the current queue and keeps it. In the Queue tab, click a saved playlist to replace the queue with it and play it, or press **+** to add it to the end of the queue. Saving under an existing name updates that playlist. Up to 50 saved playlists. **Copy links** copies every link of the queue (one per line) so you can share it or paste it back into **+ Queue**.
- **Skips what can't play**: a queue item that can't be played (not embeddable, removed, broken stream) is skipped with a short message, and the queue goes on. If nothing in the queue plays, Musicox stops instead of looping.
- **Next / previous**: moves within a YouTube playlist first, then through your queue. Previous restarts the current track if more than 4 seconds have played.
- **Shuffle and repeat**: shuffle mixes your queue (and the videos of a YouTube playlist). Repeat cycles through *off*, *all* (the queue starts over at the end) and *this track*.
- **Seek bar** with elapsed time and duration (live streams show *LIVE*).
- **Sleep timer**: 15, 30, 45, 60 or 90 minutes, or *end of track*. The music fades out over a few seconds and then pauses. The timer wins over *repeat this track*, survives a pause, and pressing play during the fade-out cancels it.
- **Background playback**: audio runs in a hidden offscreen document and keeps playing while you browse.
- **Volume, mute, play / pause / stop**. The mute button (or M) remembers the volume you had.
- **Resume**: if you play the same track or playlist again later, it picks up where you paused (including the video inside a playlist), even after Chrome closed the idle player. You can turn this off in Settings.
- **Recent tracks**: the last 8 tracks are listed in the popup. Click one to play it, or **+** to add it to the queue.
- **Use tab**: the **Tab** button fills in the URL of the tab you're on (for example a YouTube video or playlist page).
- **YouTube titles**: queue and playlist entries show their real YouTube titles. You can turn this off in Settings.
- **Clear errors**: shows why a track can't play (invalid URL, unsupported format, video not embeddable, removed video).
- **First-run hint** explaining how to start.

Note: some YouTube videos (often music labels and some live streams) don't allow embedding. Those can't be played by Musicox, and the popup tells you so. Inside a playlist they are skipped.

Note: YouTube may play an ad before some videos. Musicox doesn't skip or block ads; the music starts when the ad is over.

## Keyboard shortcuts

These work anywhere in Chrome. You can change them at `chrome://extensions/shortcuts` (or **Settings > Change shortcuts** in the popup).

| Shortcut | Action |
| --- | --- |
| `Alt+Shift+P` | Play / pause |
| `Alt+Shift+N` | Next track |
| `Alt+Shift+B` | Previous track |
| `Alt+Shift+M` | Open the Musicox popup |

Inside the popup: `Space` play/pause, `←` / `→` seek 10 seconds, `↑` / `↓` volume, `M` mute, `N` / `P` next/previous, `S` shuffle, `R` repeat. In the link field: `Enter` play the pasted link, `Shift+Enter` add it to the queue, `Alt+Enter` play it next.

If Chrome or another extension already uses one of these keys, Chrome leaves it unassigned. Set your own key at `chrome://extensions/shortcuts`.

## Install (Load unpacked)

1. Download and unzip the Musicox ZIP.
2. Open `chrome://extensions` in Chrome.
3. Turn on **Developer mode** (top right).
4. Click **Load unpacked** and select the unzipped folder (the one containing `manifest.json`).
5. Pin Musicox from the puzzle-piece menu, then click the icon to open the player.

## Usage

Paste a URL and press **Play** (or Enter). Close the popup and the music keeps playing. Open the popup again to pause, seek, skip, change the volume, or pick a recent track.

To build a queue, paste links and press **+ Queue**, then open the **Queue** tab and click an item to start. Press **Save** in the Queue tab to keep the queue as a named playlist for later. The **Settings** tab has the sleep timer, playback options and the shortcut list.

## Permissions

| Permission | Why |
| --- | --- |
| `offscreen` | Runs the hidden player page that keeps audio playing after the popup closes. |
| `storage` | Remembers volume, repeat/shuffle, your queue, saved playlists, the last track and position, recent tracks, settings and cached YouTube titles on your device. |
| `activeTab` | Only used when you click **Tab**, to read the current tab's URL. |
| `declarativeNetRequestWithHostAccess` + access to `www.youtube.com` | YouTube's embedded player refuses to play inside an extension unless the request has a referrer. Musicox adds one to its own embedded-player requests only. The same site access lets the popup look up video and playlist titles through YouTube's public oEmbed address (plain JSON, no scripts). Musicox does not read or change YouTube pages you visit. |

No new permissions were added in 1.2.0 or 1.3.0 (**Copy links** uses the clipboard from a click in the popup, which needs no permission). Keyboard shortcuts use the manifest's `commands` key, which needs no permission.

Musicox has no server and no analytics. Nothing leaves your browser except requests to the audio or YouTube URLs you choose to play, and the title lookups to `www.youtube.com/oembed` (which you can turn off under **Settings > Show YouTube titles in the queue**).

## Files

- `manifest.json`: extension configuration, including keyboard shortcuts
- `background.js`: service worker. It creates the offscreen player, relays commands, owns the queue (next / previous / shuffle / repeat / auto-advance), handles keyboard shortcuts and saves state.
- `offscreen.html` / `offscreen.js`: audio engine. It uses HTML5 audio and the YouTube embed, controlled with the widget postMessage API (`loadPlaylist`, `nextVideo`, `previousVideo`, `playVideoAt`, `seekTo`, ...) and no remote scripts. It also runs the sleep timer.
- `popup.html` / `popup.css` / `popup.js`: player UI (Player, Queue and Settings tabs)
- `icons/`: extension icons
