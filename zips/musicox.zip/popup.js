const $ = (id) => document.getElementById(id);
const urlInput = $('url-input');
const playPauseBtn = $('play-pause-btn');
const playIcon = $('play-icon');
const pauseIcon = $('pause-icon');
const stopBtn = $('stop-btn');
const loopBtn = $('loop-btn');
const repeatOneBadge = $('repeat-one');
const shuffleBtn = $('shuffle-btn');
const prevBtn = $('prev-btn');
const nextBtn = $('next-btn');
const tabBtn = $('tab-btn');
const addBtn = $('add-btn');
const volumeSlider = $('volume-slider');
const seekSlider = $('seek');
const statusMessage = $('status-message');
const npTitle = $('np-title');
const npSub = $('np-sub');
const eq = $('eq');
const recentSection = $('recent-section');
const recentList = $('recent-list');
const queueList = $('queue-list');
const queueEmpty = $('queue-empty');
const queueCount = $('queue-count');
const clearQueueBtn = $('clear-queue-btn');
const playlistPanel = $('playlist-panel');
const playlistList = $('playlist-list');
const playlistPos = $('playlist-pos');
const sleepStatus = $('sleep-status');

const DEFAULT_SETTINGS = { resume: true, fetchTitles: true };

let state = {}; // last known player state (live or saved)
let queue = [];
let queueState = { currentId: null, shuffle: false, repeat: 'off' };
let settings = { ...DEFAULT_SETTINGS };
let titleCache = {};
let isPlaying = false;
let currentUrl = '';
let busy = false;
let seeking = false;
let statusLock = 0; // keep a user-facing message visible for a moment

function send(message) {
  return chrome.runtime.sendMessage({ target: 'offscreen', ...message })
    .catch(e => ({ success: false, error: e.message }));
}

function sendBg(message) {
  return chrome.runtime.sendMessage({ target: 'background', ...message })
    .catch(e => ({ success: false, error: e.message }));
}

function setStatus(msg, isError = false, hold = 0) {
  statusMessage.textContent = msg;
  statusMessage.className = 'status-message' + (isError ? ' error' : '');
  statusLock = hold ? Date.now() + hold : 0;
}

function formatTime(sec) {
  sec = Math.max(0, Math.floor(sec || 0));
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = String(sec % 60).padStart(2, '0');
  return h ? `${h}:${String(m).padStart(2, '0')}:${s}` : `${m}:${s}`;
}

function setFill(range) {
  const max = Number(range.max) || 0;
  const pct = max > 0 ? (Number(range.value) / max) * 100 : 0;
  range.style.setProperty('--fill', pct + '%');
}

function youTubeVideoId(url) {
  try {
    const u = new URL(url);
    const host = u.hostname.replace(/^(www\.|m\.|music\.)/, '');
    if (host === 'youtu.be') return u.pathname.slice(1, 12) || null;
    if (host === 'youtube.com') return u.searchParams.get('v') || (u.pathname.match(/^\/(?:shorts|live|embed)\/([\w-]{11})/) || [])[1] || null;
  } catch (e) { /* not a URL */ }
  return null;
}

function kindOf(url) {
  try {
    const u = new URL(url);
    const host = u.hostname.replace(/^(www\.|m\.|music\.)/, '');
    if (['youtu.be', 'youtube.com', 'youtube-nocookie.com'].includes(host)) return u.searchParams.get('list') ? 'playlist' : 'youtube';
  } catch (e) { /* not a URL */ }
  return 'audio';
}

const KIND_ICON = { youtube: '▶', playlist: '☰', audio: '♪' };

function fileName(url) {
  try {
    const u = new URL(url);
    return decodeURIComponent(u.pathname.split('/').filter(Boolean).pop() || '') || u.hostname;
  } catch (e) {
    return url;
  }
}

function displayTitle(item) {
  return item.title || titleCache[item.url] || (item.kind === 'audio' || kindOf(item.url) === 'audio' ? fileName(item.url) : item.url);
}

// ---- YouTube titles (oEmbed: plain JSON, no scripts) -------------------------

const titleRequests = new Map();
let cacheSave = null;
function fetchTitle(url) {
  if (!settings.fetchTitles || kindOf(url) === 'audio') return Promise.resolve('');
  if (titleCache[url]) return Promise.resolve(titleCache[url]);
  if (titleRequests.has(url)) return titleRequests.get(url);
  const p = fetch('https://www.youtube.com/oembed?format=json&url=' + encodeURIComponent(url), { credentials: 'omit' })
    .then(r => (r.ok ? r.json() : null))
    .then(data => {
      const t = data && typeof data.title === 'string' ? data.title.slice(0, 200) : '';
      if (t) {
        titleCache[url] = t;
        clearTimeout(cacheSave);
        cacheSave = setTimeout(() => {
          const entries = Object.entries(titleCache).slice(-400);
          chrome.storage.local.set({ titleCache: Object.fromEntries(entries) });
        }, 300);
      }
      return t;
    })
    .catch(() => '');
  titleRequests.set(url, p);
  return p;
}

// ---- Rendering -------------------------------------------------------------

function updateUI(playing) {
  playIcon.classList.toggle('hidden', playing);
  pauseIcon.classList.toggle('hidden', !playing);
  eq.classList.toggle('on', playing);
}

function currentQueueItem() {
  return queue.find(i => i.id === queueState.currentId) || null;
}

function renderNowPlaying() {
  const item = currentQueueItem();
  if (!currentUrl) {
    npTitle.textContent = 'Nothing playing';
    npSub.textContent = queue.length ? `${queue.length} in your queue - press play` : 'Paste a link above to start';
  } else {
    const t = state.title || (item && displayTitle(item)) || titleCache[currentUrl] || fileName(currentUrl);
    npTitle.textContent = t;
    npTitle.title = t;
    const parts = [];
    if (state.isPlaylist) {
      const n = (state.playlist || []).length;
      parts.push(n ? `Playlist · ${state.playlistIndex + 1} / ${n}` : 'YouTube playlist');
    } else {
      parts.push(state.isYouTube ? 'YouTube' : (state.isLive ? 'Live stream' : 'Audio'));
    }
    if (item) {
      const pos = queue.indexOf(item);
      parts.push(`Queue ${pos + 1} / ${queue.length}`);
    }
    npSub.textContent = parts.join('  ·  ');
  }
  // Seek bar
  const dur = state.duration || 0;
  const canSeek = !!currentUrl && dur > 0 && !state.isLive;
  seekSlider.disabled = !canSeek;
  if (!seeking) {
    seekSlider.max = String(Math.max(0, Math.floor(dur)));
    seekSlider.value = String(canSeek ? Math.floor(state.position || 0) : 0);
    $('t-pos').textContent = formatTime(canSeek ? state.position : 0);
  }
  $('t-dur').textContent = state.isLive ? 'LIVE' : formatTime(dur);
  setFill(seekSlider);
}

function renderModes() {
  shuffleBtn.classList.toggle('active', !!queueState.shuffle);
  shuffleBtn.setAttribute('aria-pressed', String(!!queueState.shuffle));
  const repeat = queueState.repeat || 'off';
  loopBtn.classList.toggle('active', repeat !== 'off');
  loopBtn.setAttribute('aria-pressed', String(repeat !== 'off'));
  repeatOneBadge.classList.toggle('hidden', repeat !== 'one');
  loopBtn.title = { off: 'Repeat: off (R)', all: 'Repeat: all (R)', one: 'Repeat: this track (R)' }[repeat];
}

function applyState(next, { fromStorage = false } = {}) {
  if (!next) return;
  state = { ...state, ...next };
  isPlaying = !!state.playing;
  currentUrl = state.url || '';
  updateUI(isPlaying);
  if (typeof state.volume === 'number' && document.activeElement !== volumeSlider) {
    volumeSlider.value = state.volume;
    setFill(volumeSlider);
  }
  renderNowPlaying();
  renderPlaylist();
  renderSleep();
  markCurrentRow();

  if (busy || Date.now() < statusLock) return;
  if (state.error) setStatus(state.error, true);
  else if (isPlaying) setStatus('Now playing');
  else if (currentUrl && state.position > 5 && fromStorage) setStatus('Paused - press play to resume');
  else setStatus(currentUrl ? 'Paused' : 'Ready to play');
}

function rowButton(cls, text, title, onClick) {
  const b = document.createElement('button');
  b.className = 'row-btn ' + cls;
  b.textContent = text;
  b.title = title;
  b.addEventListener('click', (e) => {
    e.stopPropagation();
    onClick();
  });
  return b;
}

function renderRecent(recent) {
  recentList.textContent = '';
  if (!recent || recent.length === 0) {
    recentSection.classList.add('hidden');
    return;
  }
  for (const item of recent) {
    const li = document.createElement('li');
    li.className = 'row';
    const main = document.createElement('button');
    main.className = 'row-main';
    const kind = document.createElement('span');
    kind.className = 'kind';
    kind.textContent = KIND_ICON[item.isPlaylist ? 'playlist' : (item.isYouTube ? 'youtube' : 'audio')];
    const label = document.createElement('span');
    label.className = 'label';
    label.textContent = item.title || titleCache[item.url] || item.url;
    main.append(kind, label);
    main.title = item.url;
    main.addEventListener('click', () => {
      urlInput.value = item.url;
      play(item.url);
    });
    li.append(main, rowButton('add', '+', 'Add to queue', () => addToQueue([item.url])));
    recentList.appendChild(li);
    if (!item.title && !titleCache[item.url]) fetchTitle(item.url).then(t => { if (t) label.textContent = t; });
  }
  recentSection.classList.remove('hidden');
}

let dragId = null;
function renderQueue() {
  queueList.textContent = '';
  queueCount.textContent = String(queue.length);
  queueCount.classList.toggle('hidden', queue.length === 0);
  queueEmpty.classList.toggle('hidden', queue.length > 0);
  clearQueueBtn.classList.toggle('hidden', queue.length === 0);

  queue.forEach((item, index) => {
    const li = document.createElement('li');
    li.className = 'row';
    li.dataset.id = item.id;
    li.draggable = true;
    const main = document.createElement('button');
    main.className = 'row-main';
    main.title = item.url;
    const num = document.createElement('span');
    num.className = 'num';
    num.textContent = String(index + 1);
    const kind = document.createElement('span');
    kind.className = 'kind';
    kind.textContent = KIND_ICON[item.kind] || KIND_ICON.audio;
    const label = document.createElement('span');
    label.className = 'label';
    label.textContent = displayTitle(item);
    main.append(num, kind, label);
    main.addEventListener('click', () => playQueueItem(item.id));
    li.append(
      main,
      rowButton('up', '↑', 'Move up', () => moveItem(item.id, index - 1)),
      rowButton('down', '↓', 'Move down', () => moveItem(item.id, index + 1)),
      rowButton('remove', '✕', 'Remove from queue', () => sendBg({ type: 'QUEUE_REMOVE', id: item.id }))
    );

    li.addEventListener('dragstart', (e) => {
      dragId = item.id;
      li.classList.add('dragging');
      e.dataTransfer.effectAllowed = 'move';
    });
    li.addEventListener('dragend', () => {
      dragId = null;
      li.classList.remove('dragging');
    });
    li.addEventListener('dragover', (e) => {
      if (!dragId || dragId === item.id) return;
      e.preventDefault();
      li.classList.add('drop-before');
    });
    li.addEventListener('dragleave', () => li.classList.remove('drop-before'));
    li.addEventListener('drop', (e) => {
      e.preventDefault();
      li.classList.remove('drop-before');
      if (!dragId || dragId === item.id) return;
      const from = queue.findIndex(i => i.id === dragId);
      moveItem(dragId, from < index ? index - 1 : index);
    });
    queueList.appendChild(li);

    if (!item.title && kindOf(item.url) !== 'audio') {
      fetchTitle(item.url).then(t => {
        if (!t) return;
        label.textContent = t;
        sendBg({ type: 'QUEUE_SET_TITLE', id: item.id, title: t });
      });
    }
  });
  markCurrentRow();
  renderNowPlaying();
}

function markCurrentRow() {
  for (const li of queueList.children) {
    li.classList.toggle('current', li.dataset.id === queueState.currentId && !!currentUrl);
  }
}

let renderedPlaylistKey = '';
function renderPlaylist() {
  const ids = state.isPlaylist ? (state.playlist || []) : [];
  playlistPanel.classList.toggle('hidden', ids.length === 0);
  if (!ids.length) {
    renderedPlaylistKey = '';
    return;
  }
  playlistPos.textContent = `${state.playlistIndex + 1} / ${ids.length}`;
  const key = state.url + '|' + ids.join(',');
  if (key !== renderedPlaylistKey) {
    renderedPlaylistKey = key;
    playlistList.textContent = '';
    ids.forEach((id, index) => {
      const li = document.createElement('li');
      li.className = 'row';
      const main = document.createElement('button');
      main.className = 'row-main';
      const num = document.createElement('span');
      num.className = 'num';
      num.textContent = String(index + 1);
      const label = document.createElement('span');
      label.className = 'label';
      const url = 'https://www.youtube.com/watch?v=' + id;
      label.textContent = titleCache[url] || `Video ${index + 1}`;
      main.append(num, label);
      main.addEventListener('click', async () => {
        const res = await send({ type: 'PLAY_AT', index });
        if (res && res.success === false) setStatus(res.error, true, 3000);
      });
      li.appendChild(main);
      playlistList.appendChild(li);
      // Look up titles for the first part of long playlists only.
      if (!titleCache[url] && index < 60) fetchTitle(url).then(t => { if (t) label.textContent = t; });
    });
  }
  [...playlistList.children].forEach((li, i) => {
    const cur = i === state.playlistIndex;
    if (cur !== li.classList.contains('current')) {
      li.classList.toggle('current', cur);
      if (cur && !playlistPanel.closest('.hidden')) li.scrollIntoView({ block: 'nearest' });
    }
  });
}

function renderSleep() {
  const chips = document.querySelectorAll('#sleep-options .chip');
  const active = state.sleepEndOfTrack ? 'end' : (state.sleepAt > Date.now() ? 'timer' : 'off');
  chips.forEach(c => {
    const on = active === 'end' ? !!c.dataset.end : (active === 'off' ? c.dataset.min === '0' : c.dataset.min === String(state.sleepMinutes));
    c.classList.toggle('active', on);
  });
  if (active === 'end') {
    sleepStatus.textContent = 'Musicox will pause when this track ends.';
  } else if (active === 'timer') {
    sleepStatus.textContent = `Fading out and pausing in ${formatTime((state.sleepAt - Date.now()) / 1000)}.`;
  } else {
    sleepStatus.textContent = 'Music fades out and pauses when the timer ends.';
  }
  sleepStatus.classList.toggle('on', active !== 'off');
}

// ---- Actions ---------------------------------------------------------------

async function play(url) {
  if (!url) {
    // Nothing typed: resume / start the queue
    const res = await sendBg({ type: 'TOGGLE' });
    if (res && res.success === false) setStatus(res.error || 'Please enter a URL first', true, 3000);
    return;
  }
  busy = true;
  setStatus('Loading...');
  playPauseBtn.disabled = true;
  const response = await send({ type: 'PLAY', url });
  busy = false;
  playPauseBtn.disabled = false;
  if (response && response.success) {
    isPlaying = true;
    currentUrl = url;
    updateUI(true);
    setStatus(response.loading ? 'Buffering...' : 'Now playing');
  } else {
    isPlaying = false;
    updateUI(false);
    setStatus('Error: ' + ((response && response.error) || 'Invalid URL'), true, 4000);
  }
}

async function playQueueItem(id) {
  busy = true;
  setStatus('Loading...');
  const res = await sendBg({ type: 'QUEUE_PLAY', id });
  busy = false;
  if (res && res.success === false) setStatus('Error: ' + res.error, true, 4000);
  else setStatus(res && res.loading ? 'Buffering...' : 'Now playing');
  refresh();
}

async function togglePlay() {
  const url = urlInput.value.trim();
  // Pause only if the input still points at the track that is playing
  if (isPlaying && (!url || url === currentUrl)) {
    const response = await send({ type: 'PAUSE' });
    if (response && response.success) {
      isPlaying = false;
      updateUI(false);
      setStatus('Paused');
    }
  } else {
    play(url);
  }
}

async function skip(type) {
  setStatus(type === 'NEXT' ? 'Next...' : 'Previous...');
  const res = await sendBg({ type });
  if (res && res.success === false) setStatus(res.error, true, 3000);
  else setStatus('Now playing');
  refresh();
}

function splitUrls(text) {
  return text.split(/\s+/).map(s => s.trim()).filter(Boolean);
}

async function addToQueue(urls) {
  if (!urls.length) {
    setStatus('Paste a link to add it to the queue', true, 3000);
    return;
  }
  const items = urls.map(url => ({ url, title: titleCache[url] || '' }));
  const res = await sendBg({ type: 'QUEUE_ADD', items });
  if (res && res.success) {
    setStatus(res.added === 1 ? 'Added to queue' : `Added ${res.added} items to queue`, false, 2500);
    if (urls.length === 1 && urlInput.value.trim() === urls[0] && urls[0] !== currentUrl) urlInput.value = '';
  } else {
    setStatus((res && res.error) || 'Could not add to queue', true, 3000);
  }
}

function moveItem(id, to) {
  if (to < 0 || to >= queue.length) return;
  sendBg({ type: 'QUEUE_MOVE', id, to });
}

function showView(name) {
  document.querySelectorAll('.tab').forEach(t => {
    const on = t.dataset.view === name;
    t.classList.toggle('active', on);
    t.setAttribute('aria-selected', String(on));
  });
  document.querySelectorAll('.view').forEach(v => v.classList.toggle('hidden', v.id !== 'view-' + name));
  if (name === 'queue') {
    const cur = playlistList.querySelector('.current');
    if (cur) cur.scrollIntoView({ block: 'nearest' });
  }
}

// ---- Wiring ----------------------------------------------------------------

playPauseBtn.addEventListener('click', togglePlay);
nextBtn.addEventListener('click', () => skip('NEXT'));
prevBtn.addEventListener('click', () => skip('PREVIOUS'));

urlInput.addEventListener('keydown', (e) => {
  if (e.key !== 'Enter') return;
  const urls = splitUrls(urlInput.value);
  if (e.shiftKey || urls.length > 1) addToQueue(urls);
  else play(urls[0] || '');
});

addBtn.addEventListener('click', () => addToQueue(splitUrls(urlInput.value)));

stopBtn.addEventListener('click', async () => {
  await send({ type: 'STOP' });
  isPlaying = false;
  currentUrl = '';
  state = { ...state, url: '', title: '', position: 0, duration: 0, isPlaylist: false, playlist: [] };
  updateUI(false);
  renderNowPlaying();
  renderPlaylist();
  setStatus('Stopped');
});

loopBtn.addEventListener('click', async () => {
  const order = ['off', 'all', 'one'];
  const repeat = order[(order.indexOf(queueState.repeat || 'off') + 1) % order.length];
  queueState = { ...queueState, repeat };
  renderModes();
  setStatus({ off: 'Repeat off', all: 'Repeat all', one: 'Repeat this track' }[repeat], false, 1500);
  await sendBg({ type: 'SET_REPEAT', repeat });
});

shuffleBtn.addEventListener('click', async () => {
  const shuffle = !queueState.shuffle;
  queueState = { ...queueState, shuffle };
  renderModes();
  setStatus(shuffle ? 'Shuffle on' : 'Shuffle off', false, 1500);
  await sendBg({ type: 'SET_SHUFFLE', shuffle });
});

tabBtn.addEventListener('click', async () => {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab && tab.url && /^https?:/.test(tab.url)) {
      urlInput.value = tab.url;
      urlInput.focus();
      setStatus('Tab URL added - press play or + Queue', false, 3000);
    } else {
      setStatus('The current tab has no web URL', true, 3000);
    }
  } catch (e) {
    setStatus('Could not read the current tab', true, 3000);
  }
});

volumeSlider.addEventListener('input', (e) => {
  setFill(volumeSlider);
  send({ type: 'SET_VOLUME', volume: parseFloat(e.target.value) });
});

seekSlider.addEventListener('input', () => {
  seeking = true;
  $('t-pos').textContent = formatTime(Number(seekSlider.value));
  setFill(seekSlider);
});
seekSlider.addEventListener('change', async () => {
  const position = Number(seekSlider.value);
  const res = await send({ type: 'SEEK', position });
  seeking = false;
  if (res && res.success !== false) state.position = position;
  renderNowPlaying();
});

clearQueueBtn.addEventListener('click', () => {
  if (confirm(`Remove all ${queue.length} items from the queue?`)) sendBg({ type: 'QUEUE_CLEAR' });
});

document.querySelectorAll('.tab').forEach(t => t.addEventListener('click', () => showView(t.dataset.view)));

document.querySelectorAll('#sleep-options .chip').forEach(chip => {
  chip.addEventListener('click', async () => {
    const minutes = Number(chip.dataset.min || 0);
    const endOfTrack = !!chip.dataset.end;
    const res = await send({ type: 'SET_SLEEP', minutes, endOfTrack });
    if (res && res.success === false) {
      sleepStatus.textContent = res.error;
      sleepStatus.classList.remove('on');
      return;
    }
    state = { ...state, sleepAt: res.sleepAt || 0, sleepEndOfTrack: !!res.sleepEndOfTrack, sleepMinutes: minutes };
    chrome.storage.local.set({ sleepMinutes: minutes });
    renderSleep();
  });
});

function bindSetting(id, key) {
  const box = $(id);
  box.checked = !!settings[key];
  box.addEventListener('change', () => {
    settings = { ...settings, [key]: box.checked };
    chrome.storage.local.set({ settings });
  });
}

$('shortcuts-btn').addEventListener('click', () => chrome.tabs.create({ url: 'chrome://extensions/shortcuts' }));
$('clear-recent-btn').addEventListener('click', () => {
  chrome.storage.local.set({ recent: [] });
  setStatus('Recent tracks cleared', false, 2000);
});

$('hint-close').addEventListener('click', () => {
  $('hint').classList.add('hidden');
  chrome.storage.local.set({ onboarded: true });
});

// Popup keyboard shortcuts (ignored while typing in the URL field)
document.addEventListener('keydown', (e) => {
  if (e.target === urlInput || e.altKey || e.ctrlKey || e.metaKey) return;
  if (e.target.tagName === 'BUTTON' && (e.key === ' ' || e.key === 'Enter')) return;
  const key = e.key.toLowerCase();
  if (e.key === ' ') { e.preventDefault(); togglePlay(); }
  else if (key === 'n') skip('NEXT');
  else if (key === 'p') skip('PREVIOUS');
  else if (key === 's') shuffleBtn.click();
  else if (key === 'r') loopBtn.click();
  else if ((e.key === 'ArrowLeft' || e.key === 'ArrowRight') && e.target.type !== 'range' && !seekSlider.disabled) {
    e.preventDefault();
    const position = Math.max(0, (state.position || 0) + (e.key === 'ArrowLeft' ? -10 : 10));
    send({ type: 'SEEK', position }).then(() => { state.position = position; renderNowPlaying(); });
  }
});

// Live updates from the player (track ended, YouTube errors, titles, ...)
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  if (changes.playerState && changes.playerState.newValue) applyState(changes.playerState.newValue);
  if (changes.recent) renderRecent(changes.recent.newValue);
  if (changes.queue || changes.queueState) {
    if (changes.queue) queue = changes.queue.newValue || [];
    if (changes.queueState) queueState = { ...queueState, ...(changes.queueState.newValue || {}) };
    renderQueue();
    renderModes();
  }
});

// Poll the live player for position updates while the popup is open.
async function refresh() {
  const response = await send({ type: 'GET_STATE' });
  if (response && response.success !== false && response.live) applyState(response);
  else renderSleep();
}

async function init() {
  const data = await chrome.storage.local.get(['playerState', 'recent', 'queue', 'queueState', 'settings', 'titleCache', 'onboarded', 'sleepMinutes']);
  settings = { ...DEFAULT_SETTINGS, ...(data.settings || {}) };
  titleCache = data.titleCache || {};
  queue = data.queue || [];
  queueState = { ...queueState, ...(data.queueState || {}) };
  state.sleepMinutes = data.sleepMinutes;
  bindSetting('opt-resume', 'resume');
  bindSetting('opt-titles', 'fetchTitles');
  if (!data.onboarded && !queue.length && !(data.playerState && data.playerState.url)) $('hint').classList.remove('hidden');

  renderModes();
  renderQueue();
  if (data.playerState) {
    applyState({ ...data.playerState, playing: false }, { fromStorage: true });
    urlInput.value = data.playerState.url || '';
  } else {
    renderNowPlaying();
  }
  renderRecent(data.recent);
  setFill(volumeSlider);

  // Sync with the live offscreen state (does not create the document if absent)
  const response = await send({ type: 'GET_STATE' });
  if (response && response.success !== false) {
    applyState({ ...(data.playerState || {}), ...response }, { fromStorage: !response.live });
    if (response.url) urlInput.value = response.url;
  }
  if (location.hash.length > 1) showView(location.hash.slice(1));
  setInterval(refresh, 1000);
}

init();
