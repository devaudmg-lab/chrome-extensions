const urlInput = document.getElementById('url-input');
const playPauseBtn = document.getElementById('play-pause-btn');
const playIcon = document.getElementById('play-icon');
const pauseIcon = document.getElementById('pause-icon');
const stopBtn = document.getElementById('stop-btn');
const loopBtn = document.getElementById('loop-btn');
const tabBtn = document.getElementById('tab-btn');
const volumeSlider = document.getElementById('volume-slider');
const statusMessage = document.getElementById('status-message');
const nowPlaying = document.getElementById('now-playing');
const recentSection = document.getElementById('recent-section');
const recentList = document.getElementById('recent-list');

let isPlaying = false;
let currentUrl = '';
let loop = false;
let busy = false;

function send(message) {
  return chrome.runtime.sendMessage({ target: 'offscreen', ...message })
    .catch(e => ({ success: false, error: e.message }));
}

function setStatus(msg, isError = false) {
  statusMessage.textContent = msg;
  statusMessage.className = 'status-message' + (isError ? ' error' : '');
}

function updateUI(playing) {
  playIcon.classList.toggle('hidden', playing);
  pauseIcon.classList.toggle('hidden', !playing);
}

function applyState(state, { fromStorage = false } = {}) {
  if (!state) return;
  isPlaying = !!state.playing;
  currentUrl = state.url || '';
  updateUI(isPlaying);
  if (typeof state.volume === 'number') volumeSlider.value = state.volume;
  loop = !!state.loop;
  loopBtn.classList.toggle('active', loop);
  loopBtn.setAttribute('aria-pressed', String(loop));

  if (state.title && currentUrl) {
    nowPlaying.textContent = state.title;
    nowPlaying.title = state.title;
    nowPlaying.classList.remove('hidden');
  } else {
    nowPlaying.classList.add('hidden');
  }

  if (busy) return;
  if (state.error) setStatus(state.error, true);
  else if (isPlaying) setStatus('Now playing');
  else if (currentUrl && state.position > 5 && fromStorage) setStatus('Paused - press play to resume');
  else setStatus(currentUrl ? 'Paused' : 'Ready to play');
}

function renderRecent(recent) {
  recentList.textContent = '';
  if (!recent || recent.length === 0) {
    recentSection.classList.add('hidden');
    return;
  }
  for (const item of recent) {
    const li = document.createElement('li');
    const btn = document.createElement('button');
    btn.className = 'recent-item';
    btn.textContent = (item.isYouTube ? '▶ ' : '♪ ') + (item.title || item.url);
    btn.title = item.url;
    btn.addEventListener('click', () => {
      urlInput.value = item.url;
      play(item.url);
    });
    li.appendChild(btn);
    recentList.appendChild(li);
  }
  recentSection.classList.remove('hidden');
}

async function init() {
  const { playerState, recent } = await chrome.storage.local.get(['playerState', 'recent']);
  if (playerState) {
    applyState(playerState, { fromStorage: true });
    urlInput.value = playerState.url || '';
  }
  renderRecent(recent);

  // Sync with the live offscreen state (does not create the document if absent)
  const response = await send({ type: 'GET_STATE' });
  if (response && response.success !== false) {
    applyState({ ...(playerState || {}), ...response }, { fromStorage: !response.url });
    if (response.url) urlInput.value = response.url;
  }
}

async function play(url) {
  if (!url) {
    setStatus('Please enter a URL first', true);
    return;
  }
  busy = true;
  setStatus('Loading...');
  playPauseBtn.disabled = true;
  const response = await send({ type: 'PLAY', url });
  busy = false;
  playPauseBtn.disabled = false;
  if (response && response.success) {
    isPlaying = true;
    currentUrl = url;
    updateUI(true);
    setStatus(response.loading ? 'Buffering...' : 'Now playing');
  } else {
    isPlaying = false;
    updateUI(false);
    setStatus('Error: ' + ((response && response.error) || 'Invalid URL'), true);
  }
}

playPauseBtn.addEventListener('click', async () => {
  const url = urlInput.value.trim();
  // Pause only if the input still points at the track that is playing
  if (isPlaying && (!url || url === currentUrl)) {
    const response = await send({ type: 'PAUSE' });
    if (response && response.success) {
      isPlaying = false;
      updateUI(false);
      setStatus('Paused');
    }
  } else {
    play(url);
  }
});

urlInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') play(urlInput.value.trim());
});

stopBtn.addEventListener('click', async () => {
  await send({ type: 'STOP' });
  isPlaying = false;
  currentUrl = '';
  updateUI(false);
  nowPlaying.classList.add('hidden');
  setStatus('Stopped');
});

loopBtn.addEventListener('click', async () => {
  loop = !loop;
  loopBtn.classList.toggle('active', loop);
  loopBtn.setAttribute('aria-pressed', String(loop));
  await send({ type: 'SET_LOOP', loop });
});

tabBtn.addEventListener('click', async () => {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab && tab.url && /^https?:/.test(tab.url)) {
      urlInput.value = tab.url;
      urlInput.focus();
      setStatus('Tab URL added - press play');
    } else {
      setStatus('The current tab has no web URL', true);
    }
  } catch (e) {
    setStatus('Could not read the current tab', true);
  }
});

volumeSlider.addEventListener('input', (e) => {
  send({ type: 'SET_VOLUME', volume: parseFloat(e.target.value) });
});

// Live updates from the player (track ended, YouTube errors, titles, ...)
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  if (changes.playerState && changes.playerState.newValue) applyState(changes.playerState.newValue);
  if (changes.recent) renderRecent(changes.recent.newValue);
});

init();
