// Musicox audio engine. Runs inside the offscreen document.
// NOTE: offscreen documents only get chrome.runtime, so all persistence goes
// through the service worker (STATE_UPDATE / GET_SAVED messages).

const audio = document.getElementById('audio-player');
const playerContainer = document.getElementById('player-container');

let currentUrl = '';
let isYouTube = false;
let ytIframe = null;
let ytReady = false;
let ytListenTimer = null;
let currentVolume = 0.5;
let isPlaying = false;
let loop = false;
let title = '';
let position = 0;
let duration = 0;
let lastError = '';
let isLive = false; // live streams have no meaningful resume position
let pendingPlayResponse = null; // resolves the PLAY request once media starts or fails
let lastPositionSave = 0;

const YT_ORIGIN = 'https://www.youtube.com';
const YT_ERRORS = {
  2: 'Invalid YouTube video ID.',
  5: 'This video cannot be played in the HTML5 player.',
  100: 'Video not found (removed or private).',
  101: 'The owner does not allow this video to be embedded.',
  150: 'The owner does not allow this video to be embedded.',
  153: 'YouTube rejected the embedded player (missing referrer).'
};

function getYouTubeVideoId(url) {
  try {
    const u = new URL(url);
    const host = u.hostname.replace(/^(www\.|m\.|music\.)/, '');
    let id = null;
    if (host === 'youtu.be') id = u.pathname.slice(1).split('/')[0];
    else if (host === 'youtube.com' || host === 'youtube-nocookie.com') {
      if (u.searchParams.get('v')) id = u.searchParams.get('v');
      else {
        const m = u.pathname.match(/^\/(embed|shorts|live|v)\/([^/?#]+)/);
        if (m) id = m[2];
      }
    }
    return id && /^[\w-]{11}$/.test(id) ? id : null;
  } catch (e) {
    return null;
  }
}

function titleFromUrl(url) {
  try {
    const u = new URL(url);
    const name = decodeURIComponent(u.pathname.split('/').filter(Boolean).pop() || '');
    return name || u.hostname;
  } catch (e) {
    return '';
  }
}

function isHttpUrl(url) {
  try {
    const u = new URL(url);
    return u.protocol === 'http:' || u.protocol === 'https:';
  } catch (e) {
    return false;
  }
}

// ---- State reporting -------------------------------------------------------

function snapshot() {
  return {
    playing: isPlaying,
    volume: currentVolume,
    url: currentUrl,
    isYouTube,
    loop,
    title,
    position,
    duration,
    error: lastError
  };
}

function updateState(extra) {
  chrome.runtime.sendMessage({ target: 'background', type: 'STATE_UPDATE', state: { ...snapshot(), ...extra } })
    .catch(() => {});
}

function resolvePlay(result) {
  if (pendingPlayResponse) {
    const respond = pendingPlayResponse;
    pendingPlayResponse = null;
    respond(result);
  }
}

function fail(message) {
  lastError = message;
  isPlaying = false;
  updateState();
  resolvePlay({ success: false, error: message });
}

// ---- YouTube (iframe + widget postMessage protocol, no remote script) ------

function sendYTCommand(func, args = []) {
  if (ytIframe && ytIframe.contentWindow) {
    ytIframe.contentWindow.postMessage(JSON.stringify({
      event: 'command', func, args, id: 1, channel: 'widget'
    }), YT_ORIGIN);
  }
}

function startYTHandshake() {
  clearInterval(ytListenTimer);
  // The embed only reports events after the parent says it is listening.
  ytListenTimer = setInterval(() => {
    if (ytReady || !ytIframe) return clearInterval(ytListenTimer);
    ytIframe.contentWindow.postMessage(JSON.stringify({ event: 'listening', id: 1, channel: 'widget' }), YT_ORIGIN);
  }, 250);
}

function loadYouTube(videoId, startAt) {
  ytReady = false;
  ytIframe = document.createElement('iframe');
  const params = new URLSearchParams({
    enablejsapi: '1',
    autoplay: '1',
    controls: '0',
    playsinline: '1',
    origin: location.origin,
    widget_referrer: location.origin
  });
  if (startAt > 0) params.set('start', String(Math.floor(startAt)));
  if (loop) {
    params.set('loop', '1');
    params.set('playlist', videoId); // required for single-video loop
  }
  ytIframe.src = `${YT_ORIGIN}/embed/${videoId}?${params}`;
  ytIframe.allow = 'autoplay; encrypted-media';
  ytIframe.referrerPolicy = 'strict-origin-when-cross-origin';
  // YouTube refuses playback in players smaller than 200x200; the document is invisible anyway.
  ytIframe.width = '480';
  ytIframe.height = '270';
  ytIframe.style.border = 'none';
  ytIframe.addEventListener('load', startYTHandshake);
  playerContainer.appendChild(ytIframe);
}

function teardownYouTube() {
  clearInterval(ytListenTimer);
  playerContainer.textContent = '';
  ytIframe = null;
  ytReady = false;
}

window.addEventListener('message', (event) => {
  if (event.origin !== YT_ORIGIN || !ytIframe || event.source !== ytIframe.contentWindow) return;
  let data;
  try {
    data = typeof event.data === 'string' ? JSON.parse(event.data) : event.data;
  } catch (e) {
    return;
  }
  if (!data || !data.event) return;

  switch (data.event) {
    case 'onReady':
      ytReady = true;
      clearInterval(ytListenTimer);
      sendYTCommand('addEventListener', ['onStateChange']);
      sendYTCommand('addEventListener', ['onError']);
      sendYTCommand('setVolume', [Math.round(currentVolume * 100)]);
      sendYTCommand('unMute');
      if (isPlaying) sendYTCommand('playVideo');
      break;
    case 'onStateChange':
      handleYTState(data.info);
      break;
    case 'onError':
      fail(YT_ERRORS[data.info] || `YouTube error ${data.info}.`);
      break;
    case 'initialDelivery':
    case 'infoDelivery': {
      const info = data.info || {};
      if (info.videoData && info.videoData.title) title = info.videoData.title;
      if (info.videoData && info.videoData.isLive) isLive = true;
      if (typeof info.duration === 'number' && !isLive) duration = info.duration;
      if (typeof info.currentTime === 'number' && !isLive) {
        position = info.currentTime;
        maybeSavePosition();
      }
      if (typeof info.playerState === 'number') handleYTState(info.playerState);
      break;
    }
  }
});

function handleYTState(state) {
  // -1 unstarted, 0 ended, 1 playing, 2 paused, 3 buffering, 5 cued
  if (state === 1) {
    lastError = '';
    if (!isPlaying) { isPlaying = true; updateState(); }
    resolvePlay({ success: true });
  } else if (state === 0) {
    if (loop) { sendYTCommand('seekTo', [0, true]); sendYTCommand('playVideo'); return; }
    isPlaying = false;
    position = 0;
    updateState({ position: 0 });
  } else if (state === 2) {
    if (isPlaying) { isPlaying = false; updateState(); }
  }
}

// ---- HTML5 audio -----------------------------------------------------------

audio.addEventListener('playing', () => {
  lastError = '';
  isPlaying = true;
  updateState();
  resolvePlay({ success: true });
});
audio.addEventListener('pause', () => {
  if (isYouTube) return;
  isPlaying = false;
  updateState();
});
audio.addEventListener('ended', () => {
  isPlaying = false;
  position = 0;
  updateState({ position: 0 });
});
audio.addEventListener('timeupdate', () => {
  position = audio.currentTime;
  duration = isFinite(audio.duration) ? audio.duration : 0;
  maybeSavePosition();
});
audio.addEventListener('error', () => {
  if (isYouTube || !audio.getAttribute('src')) return;
  const codes = { 1: 'Playback aborted.', 2: 'Network error while loading audio.', 3: 'Audio could not be decoded.', 4: 'Unsupported format or URL is not an audio stream.' };
  fail(codes[audio.error && audio.error.code] || 'Could not load audio.');
});

function maybeSavePosition() {
  const now = Date.now();
  if (now - lastPositionSave > 5000) {
    lastPositionSave = now;
    updateState();
  }
}

// ---- Commands --------------------------------------------------------------

function playMedia(url, startAt, sendResponse) {
  if (url && url !== currentUrl) {
    if (!isHttpUrl(url)) {
      sendResponse({ success: false, error: 'Please enter a valid http(s) URL.' });
      return;
    }
    const videoId = getYouTubeVideoId(url);

    // Stop previous media
    teardownYouTube();
    audio.pause();
    audio.removeAttribute('src');
    audio.load();

    resolvePlay({ success: false, error: 'Replaced by a new track.' });
    currentUrl = url;
    title = '';
    isLive = false;
    position = startAt || 0;
    duration = 0;
    lastError = '';
    isPlaying = true;
    pendingPlayResponse = sendResponse;
    // Don't keep the popup waiting forever on slow streams
    setTimeout(() => resolvePlay({ success: true, loading: true }), 12000);

    if (videoId) {
      isYouTube = true;
      loadYouTube(videoId, startAt);
    } else {
      isYouTube = false;
      title = titleFromUrl(url);
      audio.loop = loop;
      audio.volume = currentVolume;
      audio.src = url;
      if (startAt > 0) {
        audio.addEventListener('loadedmetadata', () => {
          if (startAt < audio.duration) audio.currentTime = startAt;
        }, { once: true });
      }
      audio.play().catch(e => {
        // Load errors are reported (with a better message) by the 'error' event
        if (e.name !== 'AbortError' && e.name !== 'NotSupportedError') fail(e.message);
      });
    }
    updateState();
  } else if (currentUrl) {
    isPlaying = true;
    if (isYouTube) {
      sendYTCommand('playVideo');
      sendResponse({ success: true });
    } else {
      audio.play().then(() => sendResponse({ success: true }))
        .catch(e => sendResponse({ success: false, error: e.message }));
    }
    updateState();
  } else {
    sendResponse({ success: false, error: 'Please enter a URL first.' });
  }
}

function pauseMedia(sendResponse) {
  if (isYouTube) sendYTCommand('pauseVideo');
  else audio.pause();
  isPlaying = false;
  updateState();
  sendResponse({ success: true });
}

function stopMedia(sendResponse) {
  teardownYouTube();
  audio.pause();
  audio.removeAttribute('src');
  audio.load();
  resolvePlay({ success: false, error: 'Stopped.' });
  isPlaying = false;
  position = 0;
  duration = 0;
  currentUrl = '';
  title = '';
  isYouTube = false;
  updateState();
  sendResponse({ success: true });
}

function setVolume(volume, sendResponse) {
  currentVolume = Math.min(1, Math.max(0, Number(volume) || 0));
  if (isYouTube) sendYTCommand('setVolume', [Math.round(currentVolume * 100)]);
  else audio.volume = currentVolume;
  updateState();
  sendResponse({ success: true });
}

function setLoop(value, sendResponse) {
  loop = !!value;
  audio.loop = loop;
  if (isYouTube) sendYTCommand('setLoop', [loop]);
  updateState();
  sendResponse({ success: true });
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // Only handle the copy relayed by the service worker; the popup's original
  // broadcast also reaches this document and would run every command twice.
  if (message.target !== 'offscreen' || !message.relayed) return false;

  switch (message.type) {
    case 'PLAY':
      if (message.prefs) {
        if (typeof message.prefs.volume === 'number') currentVolume = message.prefs.volume;
        loop = !!message.prefs.loop;
      }
      playMedia(message.url, message.startAt || 0, sendResponse);
      return true;
    case 'PAUSE':
      pauseMedia(sendResponse);
      return false;
    case 'STOP':
      stopMedia(sendResponse);
      return false;
    case 'SET_VOLUME':
      setVolume(message.volume, sendResponse);
      return false;
    case 'SET_LOOP':
      setLoop(message.loop, sendResponse);
      return false;
    case 'GET_STATE':
      sendResponse({ success: true, ...snapshot() });
      return false;
    case 'PING':
      sendResponse({ success: true, message: 'pong' });
      return false;
    default:
      sendResponse({ success: false, error: 'Unknown message type: ' + message.type });
      return false;
  }
});

// Restore saved preferences (volume, loop) when the document is (re)created.
chrome.runtime.sendMessage({ target: 'background', type: 'GET_SAVED' }).then((saved) => {
  if (!saved) return;
  if (typeof saved.volume === 'number') {
    currentVolume = saved.volume;
    audio.volume = currentVolume;
  }
  loop = !!saved.loop;
  audio.loop = loop;
}).catch(() => {});
