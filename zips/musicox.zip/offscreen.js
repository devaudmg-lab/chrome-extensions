// Musicox audio engine. Runs inside the offscreen document.
// NOTE: offscreen documents only get chrome.runtime, so all persistence goes
// through the service worker (STATE_UPDATE / GET_SAVED messages). The queue
// itself lives in the service worker; this document only plays one item
// (a single track or a whole YouTube playlist) and reports when it ends.

const audio = document.getElementById('audio-player');
const playerContainer = document.getElementById('player-container');

let currentUrl = '';
let isYouTube = false;
let ytIframe = null;
let ytReady = false;
let ytListenTimer = null;
let currentVolume = 0.5;
let isPlaying = false;
let loop = false; // repeat the current track (or the current video of a playlist)
let shuffle = false;
let title = '';
let position = 0;
let duration = 0;
let lastError = '';
let isLive = false; // live streams have no meaningful resume position
let pendingPlayResponse = null; // resolves the PLAY request once media starts or fails
let playToken = 0; // identifies the latest PLAY request
let failedToken = -1; // the PLAY request whose failure was already reported
let prefsReceived = false; // a PLAY carried the current preferences
let lastPositionSave = 0;

// YouTube playlist state (filled from the embed's infoDelivery messages)
let listId = null;
let playlistIds = [];
let playlistIndex = -1;
let pendingStart = null; // { index, seconds } to apply once the playlist player is ready
let pauseOnNextPlay = false; // sleep timer "end of track" inside a playlist
let expectJump = false; // the next playlist index change was requested by us
let expectJumpTimer = null;

function markJump() {
  expectJump = true;
  clearTimeout(expectJumpTimer);
  // Jumping to the video that is already playing changes nothing, so don't wait forever.
  expectJumpTimer = setTimeout(() => { expectJump = false; }, 6000);
}

// Sleep timer
let sleepAt = 0;
let sleepEndOfTrack = false;
let sleepTimer = null;
let fadeTimer = null;

const YT_ORIGIN = 'https://www.youtube.com';
const YT_ERRORS = {
  2: 'Invalid YouTube video or playlist ID.',
  5: 'This video cannot be played in the HTML5 player.',
  100: 'Video not found (removed or private).',
  101: 'The owner does not allow this video to be embedded.',
  150: 'The owner does not allow this video to be embedded.',
  153: 'YouTube rejected the embedded player (missing referrer).'
};

function getYouTubeVideoId(url) {
  try {
    const u = new URL(url);
    const host = u.hostname.replace(/^(www\.|m\.|music\.)/, '');
    let id = null;
    if (host === 'youtu.be') id = u.pathname.slice(1).split('/')[0];
    else if (host === 'youtube.com' || host === 'youtube-nocookie.com') {
      if (u.searchParams.get('v')) id = u.searchParams.get('v');
      else {
        const m = u.pathname.match(/^\/(embed|shorts|live|v)\/([^/?#]+)/);
        if (m && m[2] !== 'videoseries') id = m[2];
      }
    }
    return id && /^[\w-]{11}$/.test(id) ? id : null;
  } catch (e) {
    return null;
  }
}

function getYouTubeListId(url) {
  try {
    const u = new URL(url);
    const host = u.hostname.replace(/^(www\.|m\.|music\.)/, '');
    if (!['youtu.be', 'youtube.com', 'youtube-nocookie.com'].includes(host)) return null;
    const list = u.searchParams.get('list');
    return list && /^[\w-]{2,64}$/.test(list) ? list : null;
  } catch (e) {
    return null;
  }
}

function titleFromUrl(url) {
  try {
    const u = new URL(url);
    const name = decodeURIComponent(u.pathname.split('/').filter(Boolean).pop() || '');
    return name || u.hostname;
  } catch (e) {
    return '';
  }
}

function isHttpUrl(url) {
  try {
    const u = new URL(url);
    return u.protocol === 'http:' || u.protocol === 'https:';
  } catch (e) {
    return false;
  }
}

// ---- State reporting -------------------------------------------------------

function snapshot() {
  return {
    playing: isPlaying,
    volume: currentVolume,
    url: currentUrl,
    isYouTube,
    loop,
    title,
    position,
    duration,
    isLive,
    isPlaylist: !!listId,
    playlist: listId ? playlistIds : [],
    playlistIndex: listId ? playlistIndex : -1,
    sleepAt,
    sleepEndOfTrack,
    error: lastError
  };
}

function updateState(extra) {
  chrome.runtime.sendMessage({ target: 'background', type: 'STATE_UPDATE', state: { ...snapshot(), ...extra } })
    .catch(() => {});
}

function notifyEnded() {
  chrome.runtime.sendMessage({ target: 'background', type: 'TRACK_ENDED', url: currentUrl }).catch(() => {});
}

function resolvePlay(result) {
  if (pendingPlayResponse) {
    const respond = pendingPlayResponse;
    pendingPlayResponse = null;
    respond(result);
  }
}

function fail(message) {
  lastError = message;
  isPlaying = false;
  updateState();
  resolvePlay({ success: false, error: message });
  if (fadeTimer) {
    // The sleep timer was fading out anyway: stop here instead of skipping on.
    clearSleep();
    applyVolume(currentVolume);
    updateState();
    return;
  }
  // The service worker skips to the next queue item if this one came from the queue.
  if (failedToken === playToken) return; // already reported for this track
  failedToken = playToken;
  chrome.runtime.sendMessage({ target: 'background', type: 'TRACK_FAILED', url: currentUrl, error: message }).catch(() => {});
}

// Called when the current item (track, or the last video of a playlist) finished.
function handleEnded() {
  isPlaying = false;
  position = 0;
  if (sleepEndOfTrack || fadeTimer) {
    // "Sleep at end of track", or the sleep timer was fading out: stop here.
    clearSleep();
    applyVolume(currentVolume);
    updateState({ position: 0, sleptAt: Date.now() });
    return;
  }
  if (listId) playlistIndex = 0;
  updateState({ position: 0 });
  notifyEnded();
}

// ---- YouTube (iframe + widget postMessage protocol, no remote script) ------

function sendYTCommand(func, args = []) {
  if (ytIframe && ytIframe.contentWindow) {
    ytIframe.contentWindow.postMessage(JSON.stringify({
      event: 'command', func, args, id: 1, channel: 'widget'
    }), YT_ORIGIN);
  }
}

function startYTHandshake() {
  clearInterval(ytListenTimer);
  // The embed only reports events after the parent says it is listening.
  ytListenTimer = setInterval(() => {
    if (ytReady || !ytIframe) return clearInterval(ytListenTimer);
    ytIframe.contentWindow.postMessage(JSON.stringify({ event: 'listening', id: 1, channel: 'widget' }), YT_ORIGIN);
  }, 250);
}

function loadYouTube(videoId, startAt, list, startIndex) {
  ytReady = false;
  ytIframe = document.createElement('iframe');
  const params = new URLSearchParams({
    enablejsapi: '1',
    autoplay: '1',
    controls: '0',
    playsinline: '1',
    origin: location.origin,
    widget_referrer: location.origin
  });
  pendingStart = null;
  if (list) {
    params.set('list', list);
    params.set('listType', 'playlist');
    // Resuming inside a playlist: jump to the saved video once the player is ready.
    if (startIndex > 0) {
      pendingStart = { index: startIndex, seconds: Math.floor(startAt || 0) };
      params.set('autoplay', '0');
    } else if (startAt > 0) {
      params.set('start', String(Math.floor(startAt)));
    }
  } else if (startAt > 0) {
    // No `loop=1` embed parameter: repeat is handled on the "ended" state, so it
    // can be switched on and off while the video plays.
    params.set('start', String(Math.floor(startAt)));
  }
  ytIframe.src = `${YT_ORIGIN}/embed/${videoId || 'videoseries'}?${params}`;
  ytIframe.allow = 'autoplay; encrypted-media';
  ytIframe.referrerPolicy = 'strict-origin-when-cross-origin';
  // YouTube refuses playback in players smaller than 200x200; the document is invisible anyway.
  ytIframe.width = '480';
  ytIframe.height = '270';
  ytIframe.style.border = 'none';
  ytIframe.addEventListener('load', startYTHandshake);
  playerContainer.appendChild(ytIframe);
}

function teardownYouTube() {
  clearInterval(ytListenTimer);
  playerContainer.textContent = '';
  ytIframe = null;
  ytReady = false;
  listId = null;
  playlistIds = [];
  playlistIndex = -1;
  pendingStart = null;
  pauseOnNextPlay = false;
  expectJump = false;
}

window.addEventListener('message', (event) => {
  if (event.origin !== YT_ORIGIN || !ytIframe || event.source !== ytIframe.contentWindow) return;
  let data;
  try {
    data = typeof event.data === 'string' ? JSON.parse(event.data) : event.data;
  } catch (e) {
    return;
  }
  if (!data || !data.event) return;

  switch (data.event) {
    case 'onReady':
      ytReady = true;
      clearInterval(ytListenTimer);
      sendYTCommand('addEventListener', ['onStateChange']);
      sendYTCommand('addEventListener', ['onError']);
      sendYTCommand('setVolume', [Math.round(currentVolume * 100)]);
      sendYTCommand('unMute');
      if (listId) {
        if (shuffle) sendYTCommand('setShuffle', [true]);
        if (pendingStart) {
          const { index, seconds } = pendingStart;
          pendingStart = null;
          markJump();
          sendYTCommand('loadPlaylist', [{ list: listId, listType: 'playlist', index, startSeconds: seconds }]);
          break;
        }
      }
      if (isPlaying) sendYTCommand('playVideo');
      break;
    case 'onStateChange':
      handleYTState(data.info);
      break;
    case 'onError':
      // Inside a playlist, skip videos that can't be embedded instead of stopping.
      if (listId && playlistIndex < playlistIds.length - 1 && [100, 101, 150].includes(data.info)) {
        markJump();
        sendYTCommand('nextVideo');
        break;
      }
      fail(YT_ERRORS[data.info] || `YouTube error ${data.info}.`);
      break;
    case 'initialDelivery':
    case 'infoDelivery': {
      const info = data.info || {};
      let changed = false;
      if (info.videoData && info.videoData.title && info.videoData.title !== title) {
        title = info.videoData.title;
        changed = true;
      }
      if (info.videoData && typeof info.videoData.isLive === 'boolean') isLive = info.videoData.isLive;
      if (Array.isArray(info.playlist) && listId) {
        playlistIds = info.playlist.filter(id => typeof id === 'string').slice(0, 500);
        changed = true;
      }
      if (typeof info.playlistIndex === 'number' && listId && info.playlistIndex !== playlistIndex) {
        const previousIndex = playlistIndex;
        playlistIndex = info.playlistIndex;
        changed = true;
        if (expectJump) expectJump = false;
        else onPlaylistAdvance(previousIndex);
      }
      if (typeof info.duration === 'number' && !isLive) duration = info.duration;
      if (typeof info.currentTime === 'number' && !isLive) {
        position = info.currentTime;
        maybeSavePosition();
      }
      if (typeof info.playerState === 'number') handleYTState(info.playerState);
      if (changed) updateState();
      break;
    }
  }
});

// YouTube moved to another video of the playlist by itself (the previous one
// ended). Inside a playlist the embed reports no "ended" state for this.
function onPlaylistAdvance(previousIndex) {
  // The sleep timer wins over "repeat this track".
  if (sleepEndOfTrack) {
    clearSleep();
    pauseOnNextPlay = true;
    sendYTCommand('pauseVideo');
    isPlaying = false;
    position = 0;
    updateState({ sleptAt: Date.now() });
  } else if (loop && previousIndex >= 0) {
    markJump();
    sendYTCommand('playVideoAt', [previousIndex]);
  }
}

function handleYTState(state) {
  // -1 unstarted, 0 ended, 1 playing, 2 paused, 3 buffering, 5 cued
  if (state === 1) {
    if (pauseOnNextPlay) {
      // The sleep timer asked to stop after the previous video.
      pauseOnNextPlay = false;
      sendYTCommand('pauseVideo');
      isPlaying = false;
      updateState();
      return;
    }
    lastError = '';
    if (!isPlaying) { isPlaying = true; updateState(); }
    resolvePlay({ success: true });
  } else if (state === 0) {
    if (!isPlaying && !pendingPlayResponse) return; // duplicate "ended" report
    if (loop && !sleepEndOfTrack && !fadeTimer) {
      if (listId) { markJump(); sendYTCommand('playVideoAt', [playlistIndex]); }
      else { sendYTCommand('seekTo', [0, true]); sendYTCommand('playVideo'); }
      return;
    }
    // YouTube moves on to the next video of the playlist by itself.
    if (listId && playlistIndex < playlistIds.length - 1) return;
    handleEnded();
  } else if (state === 2) {
    if (isPlaying) { isPlaying = false; updateState(); }
  }
}

// ---- HTML5 audio -----------------------------------------------------------

audio.addEventListener('playing', () => {
  lastError = '';
  isPlaying = true;
  updateState();
  resolvePlay({ success: true });
});
audio.addEventListener('pause', () => {
  // Switching tracks pauses the old one; that is not the user pausing.
  if (isYouTube || audio.ended || pendingPlayResponse) return;
  isPlaying = false;
  updateState();
});
audio.addEventListener('ended', () => {
  if (isYouTube) return;
  handleEnded();
});
audio.addEventListener('timeupdate', () => {
  position = audio.currentTime;
  duration = isFinite(audio.duration) ? audio.duration : 0;
  isLive = !isFinite(audio.duration);
  maybeSavePosition();
});
audio.addEventListener('error', () => {
  if (isYouTube || !audio.getAttribute('src')) return;
  const codes = { 1: 'Playback aborted.', 2: 'Network error while loading audio.', 3: 'Audio could not be decoded.', 4: 'Unsupported format or URL is not an audio stream.' };
  fail(codes[audio.error && audio.error.code] || 'Could not load audio.');
});

function maybeSavePosition() {
  const now = Date.now();
  if (now - lastPositionSave > 5000) {
    lastPositionSave = now;
    updateState();
  }
}

// ---- Sleep timer -----------------------------------------------------------

function clearSleep() {
  clearTimeout(sleepTimer);
  clearInterval(fadeTimer);
  sleepTimer = null;
  fadeTimer = null;
  sleepAt = 0;
  sleepEndOfTrack = false;
  syncAudioLoop();
}

// With "sleep at end of track", an audio file must end instead of looping.
function syncAudioLoop() {
  audio.loop = loop && !sleepEndOfTrack;
}

function applyVolume(v) {
  if (isYouTube) sendYTCommand('setVolume', [Math.round(v * 100)]);
  else audio.volume = v;
}

// Fade out over ~8 seconds, pause, then restore the volume for next time.
function fadeOutAndPause() {
  clearInterval(fadeTimer);
  const steps = 40;
  let step = 0;
  fadeTimer = setInterval(() => {
    step++;
    applyVolume(currentVolume * Math.max(0, 1 - step / steps));
    if (step >= steps) {
      clearInterval(fadeTimer);
      fadeTimer = null;
      if (isYouTube) sendYTCommand('pauseVideo');
      else audio.pause();
      isPlaying = false;
      sleepAt = 0;
      setTimeout(() => applyVolume(currentVolume), 300);
      updateState({ sleptAt: Date.now() });
    }
  }, 200);
}

// Arm the sleep timer: at a time (ms since epoch), or at the end of the track.
function armSleep(at, endOfTrack) {
  const wasFading = !!fadeTimer;
  clearSleep();
  if (wasFading) applyVolume(currentVolume);
  if (endOfTrack) {
    sleepEndOfTrack = true;
    syncAudioLoop();
  } else if (at > Date.now()) {
    sleepAt = at;
    sleepTimer = setTimeout(() => {
      sleepTimer = null;
      if (isPlaying) fadeOutAndPause();
      else { sleepAt = 0; updateState(); }
    }, at - Date.now());
  }
}

function setSleep(minutes, endOfTrack, sendResponse) {
  armSleep(minutes > 0 ? Date.now() + minutes * 60000 : 0, endOfTrack);
  updateState();
  sendResponse({ success: true, sleepAt, sleepEndOfTrack });
}

// The user pressed play while the sleep timer was fading out: cancel it.
function cancelFade() {
  if (!fadeTimer) return;
  clearSleep();
  applyVolume(currentVolume);
}

// ---- Commands --------------------------------------------------------------

function playMedia(url, startAt, startIndex, restart, sendResponse) {
  // After an error, pressing play loads the track again instead of resuming a broken player.
  if (url && (url !== currentUrl || restart || lastError)) {
    if (!isHttpUrl(url)) {
      sendResponse({ success: false, error: 'Please enter a valid http(s) URL.' });
      return;
    }
    const videoId = getYouTubeVideoId(url);
    const list = getYouTubeListId(url);

    // Stop previous media
    teardownYouTube();
    cancelFade();
    resolvePlay({ success: false, error: 'Replaced by a new track.' });
    audio.pause();
    audio.removeAttribute('src');
    audio.load();

    currentUrl = url;
    title = '';
    isLive = false;
    position = startAt || 0;
    duration = 0;
    lastError = '';
    isPlaying = true;
    pendingPlayResponse = sendResponse;
    // Don't keep the popup waiting forever on slow streams
    const token = ++playToken;
    setTimeout(() => { if (token === playToken) resolvePlay({ success: true, loading: true }); }, 12000);

    if (videoId || list) {
      isYouTube = true;
      listId = list;
      playlistIndex = list ? Math.max(0, startIndex || 0) : -1;
      loadYouTube(videoId, startAt, list, list ? startIndex : 0);
    } else {
      isYouTube = false;
      title = titleFromUrl(url);
      syncAudioLoop();
      audio.volume = currentVolume;
      audio.src = url;
      if (startAt > 0) {
        audio.addEventListener('loadedmetadata', () => {
          if (startAt < audio.duration) audio.currentTime = startAt;
        }, { once: true });
      }
      audio.play().catch(e => {
        // Load errors are reported (with a better message) by the 'error' event
        if (e.name !== 'AbortError' && e.name !== 'NotSupportedError') fail(e.message);
      });
    }
    updateState();
  } else if (currentUrl) {
    cancelFade();
    isPlaying = true;
    pauseOnNextPlay = false;
    if (isYouTube) {
      sendYTCommand('playVideo');
      sendResponse({ success: true });
    } else {
      audio.play().then(() => sendResponse({ success: true }))
        .catch(e => sendResponse({ success: false, error: e.message }));
    }
    updateState();
  } else {
    sendResponse({ success: false, error: 'Please enter a URL first.' });
  }
}

function pauseMedia(sendResponse) {
  if (isYouTube) sendYTCommand('pauseVideo');
  else audio.pause();
  isPlaying = false;
  updateState();
  sendResponse({ success: true });
}

function stopMedia(sendResponse) {
  teardownYouTube();
  clearSleep();
  audio.pause();
  audio.removeAttribute('src');
  audio.load();
  resolvePlay({ success: false, error: 'Stopped.' });
  isPlaying = false;
  position = 0;
  duration = 0;
  currentUrl = '';
  title = '';
  isYouTube = false;
  isLive = false;
  updateState();
  sendResponse({ success: true });
}

function setVolume(volume, sendResponse) {
  currentVolume = Math.min(1, Math.max(0, Number(volume) || 0));
  if (!fadeTimer) applyVolume(currentVolume);
  updateState();
  sendResponse({ success: true });
}

function setLoop(value, sendResponse) {
  loop = !!value;
  syncAudioLoop();
  updateState();
  sendResponse({ success: true });
}

function seek(seconds, sendResponse) {
  if (!currentUrl || isLive) {
    sendResponse({ success: false, error: 'Nothing to seek.' });
    return;
  }
  const max = duration > 0 ? duration - 0.5 : Infinity;
  const target = Math.max(0, Math.min(Number(seconds) || 0, max));
  if (isYouTube) sendYTCommand('seekTo', [target, true]);
  else audio.currentTime = target;
  position = target;
  updateState();
  sendResponse({ success: true, position: target });
}

function playlistCommand(func, args, sendResponse) {
  if (!listId || !ytIframe) {
    sendResponse({ success: false, error: 'No YouTube playlist is playing.' });
    return;
  }
  isPlaying = true;
  pauseOnNextPlay = false;
  position = 0;
  markJump();
  sendYTCommand(func, args);
  updateState();
  sendResponse({ success: true });
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // Only handle the copy relayed by the service worker; the popup's original
  // broadcast also reaches this document and would run every command twice.
  if (message.target !== 'offscreen' || !message.relayed) return false;

  switch (message.type) {
    case 'PLAY':
      if (message.prefs) {
        const p = message.prefs;
        prefsReceived = true;
        if (typeof p.volume === 'number') currentVolume = p.volume;
        loop = !!p.loop;
        shuffle = !!p.shuffle;
        // A new player document re-arms the sleep timer of the one Chrome closed.
        if (!sleepAt && !sleepEndOfTrack && !fadeTimer && (p.sleepAt > Date.now() || p.sleepEndOfTrack)) {
          armSleep(p.sleepAt, !!p.sleepEndOfTrack);
        }
        syncAudioLoop();
      }
      playMedia(message.url, message.startAt || 0, message.startIndex || 0, !!message.restart, sendResponse);
      return true;
    case 'PAUSE':
      pauseMedia(sendResponse);
      return false;
    case 'STOP':
      stopMedia(sendResponse);
      return false;
    case 'SET_VOLUME':
      setVolume(message.volume, sendResponse);
      return false;
    case 'SET_LOOP':
      setLoop(message.loop, sendResponse);
      return false;
    case 'SET_SHUFFLE':
      shuffle = !!message.shuffle;
      if (listId) sendYTCommand('setShuffle', [shuffle]);
      sendResponse({ success: true });
      return false;
    case 'SEEK':
      seek(message.position, sendResponse);
      return false;
    case 'NEXT_IN_LIST':
      playlistCommand('nextVideo', [], sendResponse);
      return false;
    case 'PREV_IN_LIST':
      playlistCommand('previousVideo', [], sendResponse);
      return false;
    case 'PLAY_AT':
      playlistCommand('playVideoAt', [Math.max(0, Number(message.index) || 0)], sendResponse);
      return false;
    case 'SET_SLEEP':
      setSleep(Number(message.minutes) || 0, !!message.endOfTrack, sendResponse);
      return false;
    case 'GET_STATE':
      sendResponse({ success: true, live: true, ...snapshot() });
      return false;
    case 'PING':
      sendResponse({ success: true, message: 'pong' });
      return false;
    default:
      sendResponse({ success: false, error: 'Unknown message type: ' + message.type });
      return false;
  }
});

// Restore saved preferences (volume, loop) when the document is (re)created.
// A PLAY that arrived first carries fresher preferences, so don't overwrite them.
chrome.runtime.sendMessage({ target: 'background', type: 'GET_SAVED' }).then((saved) => {
  if (!saved || prefsReceived) return;
  if (typeof saved.volume === 'number') {
    currentVolume = saved.volume;
    audio.volume = currentVolume;
  }
  loop = !!saved.loop;
  syncAudioLoop();
}).catch(() => {});
