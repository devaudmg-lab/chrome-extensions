const OFFSCREEN_DOCUMENT_PATH = 'offscreen.html';
const MAX_RECENT = 8;
const MAX_QUEUE = 200;
const DEFAULT_SETTINGS = { resume: true, fetchTitles: true };

let creatingOffscreen; // A promise to track offscreen document creation

async function hasOffscreenDocument() {
  const contexts = await chrome.runtime.getContexts({
    contextTypes: ['OFFSCREEN_DOCUMENT'],
    documentUrls: [chrome.runtime.getURL(OFFSCREEN_DOCUMENT_PATH)]
  });
  return contexts.length > 0;
}

async function setupOffscreenDocument() {
  if (await hasOffscreenDocument()) return;

  if (creatingOffscreen) {
    await creatingOffscreen.catch(() => {});
    return;
  }
  creatingOffscreen = chrome.offscreen.createDocument({
    url: OFFSCREEN_DOCUMENT_PATH,
    reasons: ['AUDIO_PLAYBACK'],
    justification: 'Playback of music in the background.'
  });
  try {
    await creatingOffscreen;
  } catch (e) {
    // A concurrent caller may have created it already; anything else is retried by relay()
    console.warn('Offscreen creation:', e && e.message);
  } finally {
    creatingOffscreen = null;
  }
}

async function getSavedState() {
  const { playerState } = await chrome.storage.local.get('playerState');
  return playerState || {};
}

async function getSettings() {
  const { settings } = await chrome.storage.local.get('settings');
  return { ...DEFAULT_SETTINGS, ...(settings || {}) };
}

// Persist state reported by the offscreen document (it has no chrome.storage access).
let stateWrite = Promise.resolve();
function saveState(state) {
  stateWrite = stateWrite.then(async () => {
    const { playerState = {}, recent = [] } = await chrome.storage.local.get(['playerState', 'recent']);
    const next = { ...playerState, ...state, updatedAt: Date.now() };
    const update = { playerState: next };

    if (state.url && state.playing && !state.error) {
      const existing = recent.find(r => r.url === state.url);
      // A playlist's current video title is not the playlist's name, so keep a known title.
      const newTitle = state.isPlaylist ? ((existing && existing.title) || '') : (state.title || (existing && existing.title) || '');
      const entry = { url: state.url, title: newTitle, isYouTube: !!state.isYouTube, isPlaylist: !!state.isPlaylist };
      const changed = !existing || recent[0].url !== state.url || existing.title !== entry.title;
      if (changed) {
        update.recent = [entry, ...recent.filter(r => r.url !== state.url)].slice(0, MAX_RECENT);
      }
    }
    await chrome.storage.local.set(update);
  }).catch(e => console.warn('Saving state failed:', e && e.message));
  return stateWrite;
}

// ---- Queue -----------------------------------------------------------------
// queue: [{ id, url, title, kind: 'youtube' | 'playlist' | 'audio' }]
// queueState: { currentId, shuffle, repeat: 'off' | 'all' | 'one', order: [ids] }

async function getQueue() {
  const { queue = [], queueState = {} } = await chrome.storage.local.get(['queue', 'queueState']);
  return {
    queue,
    qs: { currentId: null, shuffle: false, repeat: 'off', order: [], ...queueState }
  };
}

function shuffled(ids) {
  const a = ids.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

// The order in which queue items are played (queue order, or the shuffle order).
function playOrder(queue, qs) {
  const ids = queue.map(i => i.id);
  if (!qs.shuffle) return ids;
  const order = (qs.order || []).filter(id => ids.includes(id));
  for (const id of ids) if (!order.includes(id)) order.push(id);
  return order;
}

function newShuffleOrder(queue, currentId) {
  const rest = shuffled(queue.map(i => i.id).filter(id => id !== currentId));
  return currentId && queue.some(i => i.id === currentId) ? [currentId, ...rest] : rest;
}

let queueWrite = Promise.resolve();
// Serialize read-modify-write updates of the queue.
function updateQueue(fn) {
  const run = queueWrite.then(async () => {
    const { queue, qs } = await getQueue();
    const result = await fn(queue, qs);
    await chrome.storage.local.set({ queue: result.queue || queue, queueState: result.qs || qs });
    return result.response || { success: true };
  });
  queueWrite = run.catch(() => {});
  return run;
}

function kindOf(url) {
  try {
    const u = new URL(url);
    const host = u.hostname.replace(/^(www\.|m\.|music\.)/, '');
    if (['youtu.be', 'youtube.com', 'youtube-nocookie.com'].includes(host)) {
      return u.searchParams.get('list') ? 'playlist' : 'youtube';
    }
  } catch (e) { /* invalid URLs are rejected before this */ }
  return 'audio';
}

function isHttpUrl(url) {
  try {
    const u = new URL(url);
    return u.protocol === 'http:' || u.protocol === 'https:';
  } catch (e) {
    return false;
  }
}

async function queueAdd(items, playNext) {
  return updateQueue((queue, qs) => {
    const valid = (items || []).filter(i => i && isHttpUrl(i.url));
    if (!valid.length) return { response: { success: false, error: 'Please enter a valid http(s) URL.' } };
    const room = MAX_QUEUE - queue.length;
    if (room <= 0) return { response: { success: false, error: `The queue is full (${MAX_QUEUE} items).` } };
    const added = valid.slice(0, room).map(i => ({
      id: Date.now().toString(36) + Math.random().toString(36).slice(2, 7),
      url: i.url,
      title: i.title || '',
      kind: kindOf(i.url)
    }));
    let at = queue.length;
    if (playNext) {
      const cur = queue.findIndex(i => i.id === qs.currentId);
      at = cur >= 0 ? cur + 1 : 0;
    }
    const nextQueue = [...queue.slice(0, at), ...added, ...queue.slice(at)];
    const nextQs = { ...qs };
    if (qs.shuffle) {
      // Insert new items at random places after the current one.
      const order = playOrder(queue, qs);
      const curPos = Math.max(0, order.indexOf(qs.currentId));
      for (const item of added) {
        const pos = playNext ? curPos + 1 : curPos + 1 + Math.floor(Math.random() * (order.length - curPos));
        order.splice(Math.min(pos, order.length), 0, item.id);
      }
      nextQs.order = order;
    }
    return { queue: nextQueue, qs: nextQs, response: { success: true, added: added.length, skipped: valid.length - added.length } };
  });
}

async function playUrl(url, { queueId = null, restart = true } = {}) {
  await updateQueue((queue, qs) => ({ qs: { ...qs, currentId: queueId } }));
  return handleOffscreenMessage({ target: 'offscreen', type: 'PLAY', url, restart, noResume: restart, queueId });
}

async function liveState() {
  if (await hasOffscreenDocument()) {
    const live = await relay({ target: 'offscreen', type: 'GET_STATE' });
    if (live && live.success !== false) return live;
  }
  return { ...(await getSavedState()), playing: false, live: false };
}

// Move to the next item. `auto` is true when the current item finished by itself.
async function next({ auto = false } = {}) {
  const live = await liveState();
  if (!auto && live.live && live.isPlaylist && live.playlistIndex < (live.playlist || []).length - 1) {
    return relay({ target: 'offscreen', type: 'NEXT_IN_LIST' });
  }
  const { queue, qs } = await getQueue();
  const order = playOrder(queue, qs);
  const pos = order.indexOf(qs.currentId);
  let targetId = null;
  if (pos === -1) {
    // The current track is not from the queue: continue with the queue, if any.
    if (order.length) targetId = order[0];
    else if (auto && qs.repeat === 'all' && live.url) return playUrl(live.url);
  } else if (pos < order.length - 1) {
    targetId = order[pos + 1];
  } else if (qs.repeat === 'all') {
    if (qs.shuffle) {
      const order2 = newShuffleOrder(queue, null);
      await updateQueue((q, s) => ({ qs: { ...s, order: order2 } }));
      targetId = order2[0];
    } else {
      targetId = order[0];
    }
  }
  if (!targetId) {
    if (auto) return { success: true, ended: true };
    return { success: false, error: order.length ? 'End of the queue.' : (live.isPlaylist ? 'End of the playlist.' : 'The queue is empty.') };
  }
  const item = queue.find(i => i.id === targetId);
  return playUrl(item.url, { queueId: item.id });
}

async function previous() {
  const live = await liveState();
  if (live.live && live.url && !live.isLive && live.position > 4) {
    return relay({ target: 'offscreen', type: 'SEEK', position: 0 });
  }
  if (live.live && live.isPlaylist && live.playlistIndex > 0) {
    return relay({ target: 'offscreen', type: 'PREV_IN_LIST' });
  }
  const { queue, qs } = await getQueue();
  const order = playOrder(queue, qs);
  const pos = order.indexOf(qs.currentId);
  let targetId = null;
  if (pos > 0) targetId = order[pos - 1];
  else if (pos === 0 && qs.repeat === 'all' && order.length > 1) targetId = order[order.length - 1];
  if (!targetId) {
    if (live.live && live.url) return relay({ target: 'offscreen', type: 'SEEK', position: 0 });
    return { success: false, error: 'Nothing before this track.' };
  }
  const item = queue.find(i => i.id === targetId);
  return playUrl(item.url, { queueId: item.id });
}

async function togglePlayback() {
  const live = await liveState();
  if (live.live && live.playing) return relay({ target: 'offscreen', type: 'PAUSE' });
  if (live.url) return handleOffscreenMessage({ target: 'offscreen', type: 'PLAY', url: live.url });
  const { queue, qs } = await getQueue();
  const order = playOrder(queue, qs);
  if (order.length) {
    const item = queue.find(i => i.id === order[0]);
    return playUrl(item.url, { queueId: item.id });
  }
  return { success: false, error: 'Nothing to play yet.' };
}

async function handleBackgroundMessage(message) {
  switch (message.type) {
    case 'NEXT':
      return next();
    case 'PREVIOUS':
      return previous();
    case 'TOGGLE':
      return togglePlayback();
    case 'TRACK_ENDED': {
      const live = await getSavedState();
      if (message.url && live.url && message.url !== live.url) return { success: true };
      return next({ auto: true });
    }
    case 'QUEUE_ADD':
      return queueAdd(message.items, !!message.playNext);
    case 'QUEUE_PLAY': {
      const { queue } = await getQueue();
      const item = queue.find(i => i.id === message.id);
      if (!item) return { success: false, error: 'This item is no longer in the queue.' };
      return playUrl(item.url, { queueId: item.id });
    }
    case 'QUEUE_REMOVE':
      return updateQueue((queue, qs) => ({
        queue: queue.filter(i => i.id !== message.id),
        qs: { ...qs, order: (qs.order || []).filter(id => id !== message.id), currentId: qs.currentId === message.id ? null : qs.currentId }
      }));
    case 'QUEUE_MOVE':
      return updateQueue((queue) => {
        const from = queue.findIndex(i => i.id === message.id);
        if (from === -1) return { response: { success: false, error: 'Item not found.' } };
        const to = Math.max(0, Math.min(queue.length - 1, Number(message.to)));
        const copy = queue.slice();
        const [item] = copy.splice(from, 1);
        copy.splice(to, 0, item);
        return { queue: copy };
      });
    case 'QUEUE_SET_TITLE':
      return updateQueue((queue) => ({
        queue: queue.map(i => (i.id === message.id && !i.title ? { ...i, title: String(message.title || '').slice(0, 200) } : i))
      }));
    case 'QUEUE_CLEAR':
      return updateQueue((queue, qs) => ({ queue: [], qs: { ...qs, order: [], currentId: null } }));
    case 'SET_SHUFFLE': {
      const shuffle = !!message.shuffle;
      const res = await updateQueue((queue, qs) => ({
        qs: { ...qs, shuffle, order: shuffle ? newShuffleOrder(queue, qs.currentId) : [] }
      }));
      if (await hasOffscreenDocument()) await relay({ target: 'offscreen', type: 'SET_SHUFFLE', shuffle });
      return res;
    }
    case 'SET_REPEAT': {
      const repeat = ['off', 'all', 'one'].includes(message.repeat) ? message.repeat : 'off';
      await updateQueue((queue, qs) => ({ qs: { ...qs, repeat } }));
      // "Repeat one" is the player's loop flag.
      return handleOffscreenMessage({ target: 'offscreen', type: 'SET_LOOP', loop: repeat === 'one' });
    }
    default:
      return { success: false, error: 'Unknown message type: ' + message.type };
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.target === 'background') {
    if (message.type === 'STATE_UPDATE') {
      saveState(message.state || {}).then(() => sendResponse({ success: true }));
      return true;
    }
    if (message.type === 'GET_SAVED') {
      getSavedState().then(sendResponse);
      return true;
    }
    handleBackgroundMessage(message)
      .then(sendResponse)
      .catch(e => sendResponse({ success: false, error: (e && e.message) || String(e) }));
    return true;
  }

  if (message.target === 'offscreen' && !message.relayed) {
    handleOffscreenMessage(message)
      .then(sendResponse)
      .catch(e => sendResponse({ success: false, error: (e && e.message) || String(e) }));
    return true; // Keep the message channel open for async response
  }
  return false;
});

async function handleOffscreenMessage(message) {
  // Don't spin up an offscreen document just to read state or pause.
  if (['GET_STATE', 'PAUSE', 'STOP', 'SET_VOLUME', 'SET_LOOP', 'SEEK', 'SET_SLEEP', 'PLAY_AT', 'SET_SHUFFLE'].includes(message.type) && !(await hasOffscreenDocument())) {
    const saved = await getSavedState();
    if (message.type === 'SET_VOLUME') await saveState({ volume: message.volume });
    if (message.type === 'SET_LOOP') await saveState({ loop: !!message.loop });
    if (message.type === 'PAUSE' || message.type === 'STOP') await saveState({ playing: false });
    if (message.type === 'SET_SLEEP' && (message.minutes > 0 || message.endOfTrack)) {
      return { success: false, error: 'Start playing something first.' };
    }
    if (message.type === 'SEEK' && saved.url) await saveState({ position: Math.max(0, Number(message.position) || 0) });
    return { success: true, ...saved, playing: false, live: false };
  }

  if (message.type === 'PLAY') {
    await refererRuleReady;
    const [saved, settings, { queue, qs }] = await Promise.all([getSavedState(), getSettings(), getQueue()]);
    message = {
      ...message,
      prefs: { volume: typeof saved.volume === 'number' ? saved.volume : 0.5, loop: qs.repeat === 'one', shuffle: !!qs.shuffle }
    };
    // A URL typed in the popup that is also in the queue continues the queue from there.
    if (!('queueId' in message)) {
      const inQueue = queue.find(i => i.url === message.url);
      if (inQueue || qs.currentId) {
        await updateQueue((q, s) => ({ qs: { ...s, currentId: inQueue ? inQueue.id : (saved.url === message.url ? s.currentId : null) } }));
      }
    }
    // Resume where the user left off if the same track is played again.
    if (settings.resume && !message.noResume && message.url && message.url === saved.url && !saved.isLive) {
      if (saved.position > 5 && !(saved.duration && saved.position > saved.duration - 5)) message.startAt = saved.position;
      if (saved.isPlaylist && saved.playlistIndex > 0) message.startIndex = saved.playlistIndex;
    }
  }

  await setupOffscreenDocument();
  return relay(message);
}

async function relay(message, attempt = 0) {
  try {
    // Mark as relayed so the offscreen document only acts on the copy sent by
    // the service worker (it would otherwise also receive the popup's original).
    const response = await chrome.runtime.sendMessage({ ...message, relayed: true });
    if (!response) throw new Error('Empty response');
    return response;
  } catch (error) {
    if (attempt >= 15) {
      console.error('Offscreen failure:', error);
      return { success: false, error: 'Offscreen communication failed. Please reload the extension.' };
    }
    await new Promise(r => setTimeout(r, 200));
    await setupOffscreenDocument();
    return relay(message, attempt + 1);
  }
}

// Keyboard shortcuts (chrome://extensions/shortcuts)
chrome.commands.onCommand.addListener((command) => {
  const actions = { 'toggle-playback': togglePlayback, 'next-track': () => next(), 'previous-track': previous };
  const action = actions[command];
  if (action) action().catch(e => console.warn('Command failed:', e && e.message));
});

// The offscreen document is gone after a browser restart, so nothing can be playing.
chrome.runtime.onStartup.addListener(() => saveState({ playing: false, sleepAt: 0, sleepEndOfTrack: false }));

chrome.runtime.onInstalled.addListener(async ({ reason }) => {
  // v1.1 stored "loop" on the player state; it becomes "repeat one".
  if (reason === 'update') {
    const { playerState, queueState } = await chrome.storage.local.get(['playerState', 'queueState']);
    if (!queueState && playerState && playerState.loop) {
      await chrome.storage.local.set({ queueState: { currentId: null, shuffle: false, repeat: 'one', order: [] } });
    }
  }
});

// YouTube's embedded player refuses to play (error 153) when the embedding page
// sends no HTTP Referer, which is the case for chrome-extension:// pages. Add one,
// but only for embed requests made by this extension's offscreen document.
const YT_REFERER_RULE_ID = 1;
// A stable, extension-specific https origin (never resolves to a real site).
const REFERER_VALUE = `https://${chrome.runtime.id}.chromiumapp.org/`;
async function installRefererRule() {
  try {
    await chrome.declarativeNetRequest.updateSessionRules({
      removeRuleIds: [YT_REFERER_RULE_ID],
      addRules: [{
        id: YT_REFERER_RULE_ID,
        priority: 1,
        action: {
          type: 'modifyHeaders',
          requestHeaders: [{ header: 'referer', operation: 'set', value: REFERER_VALUE }]
        },
        condition: {
          urlFilter: '||www.youtube.com/embed/',
          resourceTypes: ['sub_frame'],
          initiatorDomains: [chrome.runtime.id],
          tabIds: [-1] // requests not made from a tab (the offscreen document)
        }
      }]
    });
  } catch (e) {
    console.warn('Could not install YouTube referer rule:', e && e.message);
  }
}
const refererRuleReady = installRefererRule();
