const OFFSCREEN_DOCUMENT_PATH = 'offscreen.html';
const MAX_RECENT = 8;
const MAX_QUEUE = 200;
const DEFAULT_SETTINGS = { resume: true, fetchTitles: true };

let creatingOffscreen; // A promise to track offscreen document creation

async function hasOffscreenDocument() {
  const contexts = await chrome.runtime.getContexts({
    contextTypes: ['OFFSCREEN_DOCUMENT'],
    documentUrls: [chrome.runtime.getURL(OFFSCREEN_DOCUMENT_PATH)]
  });
  return contexts.length > 0;
}

async function setupOffscreenDocument() {
  if (creatingOffscreen) {
    await creatingOffscreen.catch(() => {});
    return;
  }
  if (await hasOffscreenDocument()) return;
  if (creatingOffscreen) {
    // Another caller started creating it while we were checking.
    await creatingOffscreen.catch(() => {});
    return;
  }
  creatingOffscreen = chrome.offscreen.createDocument({
    url: OFFSCREEN_DOCUMENT_PATH,
    reasons: ['AUDIO_PLAYBACK'],
    justification: 'Playback of music in the background.'
  });
  try {
    await creatingOffscreen;
  } catch (e) {
    // A concurrent caller may have created it already; anything else is retried by relay()
    console.warn('Offscreen creation:', e && e.message);
  } finally {
    creatingOffscreen = null;
  }
}

async function getSavedState() {
  const { playerState } = await chrome.storage.local.get('playerState');
  return playerState || {};
}

async function getSettings() {
  const { settings } = await chrome.storage.local.get('settings');
  return { ...DEFAULT_SETTINGS, ...(settings || {}) };
}

// Persist state reported by the offscreen document (it has no chrome.storage access).
let stateWrite = Promise.resolve();
function saveState(state) {
  stateWrite = stateWrite.then(async () => {
    const { playerState = {}, recent = [] } = await chrome.storage.local.get(['playerState', 'recent']);
    const next = { ...playerState, ...state, updatedAt: Date.now() };
    const update = { playerState: next };

    if (state.url && state.playing && !state.error) {
      const existing = recent.find(r => r.url === state.url);
      // A playlist's current video title is not the playlist's name, so keep a known title.
      const newTitle = state.isPlaylist ? ((existing && existing.title) || '') : (state.title || (existing && existing.title) || '');
      const entry = { url: state.url, title: newTitle, isYouTube: !!state.isYouTube, isPlaylist: !!state.isPlaylist };
      const changed = !existing || recent[0].url !== state.url || existing.title !== entry.title;
      if (changed) {
        update.recent = [entry, ...recent.filter(r => r.url !== state.url)].slice(0, MAX_RECENT);
      }
    }
    await chrome.storage.local.set(update);
  }).catch(e => console.warn('Saving state failed:', e && e.message));
  return stateWrite;
}

// A short message for the popup (for example "Skipped ...: not embeddable").
function saveNotice(text) {
  return saveState({ notice: String(text).slice(0, 300), noticeAt: Date.now() });
}

// ---- Queue -----------------------------------------------------------------
// queue: [{ id, url, title, kind: 'youtube' | 'playlist' | 'audio' }]
// queueState: { currentId, shuffle, repeat: 'off' | 'all' | 'one', order: [ids], resumeAt }
// resumeAt: when the current track is not a queue item (it was removed from the
// queue, or a link was played directly), the play-order position "next" continues from.

async function getQueue() {
  const { queue = [], queueState = {} } = await chrome.storage.local.get(['queue', 'queueState']);
  const qs = { currentId: null, shuffle: false, repeat: 'off', order: [], resumeAt: 0, ...queueState };
  if (!Number.isInteger(qs.resumeAt) || qs.resumeAt < 0) qs.resumeAt = 0;
  return { queue, qs };
}

function shuffled(ids) {
  const a = ids.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

// The order in which queue items are played (queue order, or the shuffle order).
function playOrder(queue, qs) {
  const ids = queue.map(i => i.id);
  if (!qs.shuffle) return ids;
  const order = (qs.order || []).filter(id => ids.includes(id));
  for (const id of ids) if (!order.includes(id)) order.push(id);
  return order;
}

function newShuffleOrder(queue, currentId) {
  const rest = shuffled(queue.map(i => i.id).filter(id => id !== currentId));
  return currentId && queue.some(i => i.id === currentId) ? [currentId, ...rest] : rest;
}

// The play-order position that "next" will play.
function nextSlot(order, qs) {
  const pos = order.indexOf(qs.currentId);
  return pos >= 0 ? pos + 1 : Math.min(qs.resumeAt || 0, order.length);
}

function newId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

let queueWrite = Promise.resolve();
// Serialize read-modify-write updates of the queue and saved playlists.
function withLock(fn) {
  const run = queueWrite.then(fn);
  queueWrite = run.catch(() => {});
  return run;
}

function updateQueue(fn) {
  return withLock(async () => {
    const { queue, qs } = await getQueue();
    const result = await fn(queue, qs);
    await chrome.storage.local.set({ queue: result.queue || queue, queueState: result.qs || qs });
    return result.response || { success: true };
  });
}

function kindOf(url) {
  try {
    const u = new URL(url);
    const host = u.hostname.replace(/^(www\.|m\.|music\.)/, '');
    if (['youtu.be', 'youtube.com', 'youtube-nocookie.com'].includes(host)) {
      return u.searchParams.get('list') ? 'playlist' : 'youtube';
    }
  } catch (e) { /* invalid URLs are rejected before this */ }
  return 'audio';
}

function isHttpUrl(url) {
  try {
    const u = new URL(url);
    return u.protocol === 'http:' || u.protocol === 'https:';
  } catch (e) {
    return false;
  }
}

async function queueAdd(items, playNext) {
  return updateQueue((queue, qs) => {
    const valid = (items || []).filter(i => i && isHttpUrl(i.url));
    if (!valid.length) return { response: { success: false, error: 'Please enter a valid http(s) URL.' } };
    const room = MAX_QUEUE - queue.length;
    if (room <= 0) return { response: { success: false, error: `The queue is full (${MAX_QUEUE} items).` } };
    const added = valid.slice(0, room).map(i => ({
      id: newId(),
      url: i.url,
      title: String(i.title || '').slice(0, 200),
      kind: kindOf(i.url)
    }));
    const order = playOrder(queue, qs);
    const slot = nextSlot(order, qs); // where "next" continues
    let at = queue.length;
    if (playNext) {
      // Without shuffle the play order is the queue order, so the slot is a queue index.
      at = qs.shuffle ? Math.min(queue.length, queue.findIndex(i => i.id === qs.currentId) + 1) : slot;
    }
    const nextQueue = [...queue.slice(0, at), ...added, ...queue.slice(at)];
    const nextQs = { ...qs };
    if (qs.shuffle) {
      // "Play next" keeps the pasted order right after the current item;
      // otherwise new items go to random places among the ones not played yet.
      added.forEach((item, k) => {
        const pos = playNext ? slot + k : slot + Math.floor(Math.random() * (order.length - slot + 1));
        order.splice(Math.min(pos, order.length), 0, item.id);
      });
      nextQs.order = order;
    }
    return {
      queue: nextQueue,
      qs: nextQs,
      response: { success: true, added: added.length, skipped: (items || []).length - added.length }
    };
  });
}

async function playUrl(url, { queueId = null, restart = true } = {}) {
  await updateQueue((queue, qs) => ({ qs: { ...qs, currentId: queueId, resumeAt: 0 } }));
  return handleOffscreenMessage({ target: 'offscreen', type: 'PLAY', url, restart, noResume: restart, queueId });
}

function playItem(queue, id) {
  const item = queue.find(i => i.id === id);
  return playUrl(item.url, { queueId: item.id });
}

// A shuffle order for "repeat all" that doesn't start with the track that just played.
function reshuffleAvoiding(queue, lastId) {
  const order = newShuffleOrder(queue, null);
  if (order.length > 1 && order[0] === lastId) {
    const j = 1 + Math.floor(Math.random() * (order.length - 1));
    [order[0], order[j]] = [order[j], order[0]];
  }
  return order;
}

async function liveState() {
  if (await hasOffscreenDocument()) {
    const live = await relay({ target: 'offscreen', type: 'GET_STATE' });
    if (live && live.success !== false) return live;
  }
  return { ...(await getSavedState()), playing: false, live: false };
}

// Move to the next item. `auto` is true when the current item finished by itself.
async function next({ auto = false } = {}) {
  const live = await liveState();
  if (!auto && live.live && live.isPlaylist && live.playlistIndex < (live.playlist || []).length - 1) {
    return relay({ target: 'offscreen', type: 'NEXT_IN_LIST' });
  }
  const { queue, qs } = await getQueue();
  const order = playOrder(queue, qs);
  const slot = nextSlot(order, qs);
  let targetId = null;
  if (slot < order.length) {
    targetId = order[slot];
  } else if (qs.repeat === 'all' && order.length) {
    if (qs.shuffle) {
      const order2 = reshuffleAvoiding(queue, qs.currentId);
      await updateQueue((q, s) => ({ qs: { ...s, order: order2 } }));
      targetId = order2[0];
    } else {
      targetId = order[0];
    }
  } else if (!order.length && auto && qs.repeat === 'all' && live.url) {
    // Repeat all with no queue: play the current track or playlist again.
    return playUrl(live.url);
  }
  if (!targetId) {
    if (auto) return { success: true, ended: true };
    return { success: false, error: order.length ? 'End of the queue.' : (live.isPlaylist ? 'End of the playlist.' : 'The queue is empty.') };
  }
  return playItem(queue, targetId);
}

async function previous() {
  const live = await liveState();
  if (live.live && live.url && !live.isLive && live.position > 4) {
    return relay({ target: 'offscreen', type: 'SEEK', position: 0 });
  }
  if (live.live && live.isPlaylist && live.playlistIndex > 0) {
    return relay({ target: 'offscreen', type: 'PREV_IN_LIST' });
  }
  const { queue, qs } = await getQueue();
  const order = playOrder(queue, qs);
  const pos = order.indexOf(qs.currentId);
  let targetId = null;
  if (pos > 0) targetId = order[pos - 1];
  else if (pos === 0 && qs.repeat === 'all' && order.length > 1) targetId = order[order.length - 1];
  else if (pos === -1 && (qs.resumeAt || 0) > 0 && order.length) {
    // The current track is not a queue item: go back to the item before where the queue continues.
    targetId = order[Math.min(qs.resumeAt, order.length) - 1];
  }
  if (!targetId) {
    if (live.live && live.url) return relay({ target: 'offscreen', type: 'SEEK', position: 0 });
    return { success: false, error: 'Nothing before this track.' };
  }
  return playItem(queue, targetId);
}

async function togglePlayback() {
  const live = await liveState();
  if (live.live && live.playing) return relay({ target: 'offscreen', type: 'PAUSE' });
  if (live.url) return handleOffscreenMessage({ target: 'offscreen', type: 'PLAY', url: live.url });
  // Nothing loaded (stopped, or first run): start the queue where it was.
  const { queue, qs } = await getQueue();
  const order = playOrder(queue, qs);
  if (order.length) {
    const slot = order.includes(qs.currentId) ? order.indexOf(qs.currentId) : nextSlot(order, qs);
    return playItem(queue, order[slot < order.length ? slot : 0]);
  }
  return { success: false, error: 'Nothing to play yet.' };
}

// ---- Saved playlists ---------------------------------------------------------
// savedLists: [{ id, name, items: [{ url, title }], updatedAt }]
const MAX_SAVED = 50;

async function getSavedLists() {
  const { savedLists = [] } = await chrome.storage.local.get('savedLists');
  return Array.isArray(savedLists) ? savedLists : [];
}

function saveQueueAs(rawName) {
  return withLock(async () => {
    const name = String(rawName || '').replace(/\s+/g, ' ').trim().slice(0, 60);
    if (!name) return { success: false, error: 'Give the playlist a name.' };
    const [{ queue }, lists] = await Promise.all([getQueue(), getSavedLists()]);
    if (!queue.length) return { success: false, error: 'The queue is empty, so there is nothing to save.' };
    const items = queue.map(i => ({ url: i.url, title: i.title || '' }));
    const existing = lists.find(l => l.name.toLowerCase() === name.toLowerCase());
    if (!existing && lists.length >= MAX_SAVED) {
      return { success: false, error: `You can keep up to ${MAX_SAVED} saved playlists. Delete one first.` };
    }
    const entry = { id: existing ? existing.id : newId(), name, items, updatedAt: Date.now() };
    await chrome.storage.local.set({ savedLists: [entry, ...lists.filter(l => l !== existing)] });
    return { success: true, replaced: !!existing, count: items.length };
  });
}

async function loadSavedList(id, mode) {
  const list = (await getSavedLists()).find(l => l.id === id);
  if (!list) return { success: false, error: 'This saved playlist no longer exists.' };
  if (mode === 'append') return queueAdd(list.items, false);
  // Replace the queue and start playing it.
  const res = await updateQueue((queue, qs) => {
    const items = list.items.filter(i => i && isHttpUrl(i.url)).slice(0, MAX_QUEUE)
      .map(i => ({ id: newId(), url: i.url, title: String(i.title || '').slice(0, 200), kind: kindOf(i.url) }));
    if (!items.length) return { response: { success: false, error: 'This saved playlist is empty.' } };
    return {
      queue: items,
      qs: { ...qs, currentId: null, resumeAt: 0, order: qs.shuffle ? newShuffleOrder(items, null) : [] },
      response: { success: true, count: items.length }
    };
  });
  if (!res.success) return res;
  const { queue, qs } = await getQueue();
  const played = await playItem(queue, playOrder(queue, qs)[0]);
  return { ...played, count: res.count, name: list.name };
}

function deleteSavedList(id) {
  return withLock(async () => {
    const lists = await getSavedLists();
    await chrome.storage.local.set({ savedLists: lists.filter(l => l.id !== id) });
    return { success: true };
  });
}

// ---- Unplayable queue items ------------------------------------------------
// When a queue item can't be played (not embeddable, removed, bad stream), move
// on to the next one, but never loop forever over a queue where nothing plays.
let failStreak = 0;
async function onTrackFailed(message) {
  const saved = await getSavedState();
  if (message.url && saved.url && message.url !== saved.url) return { success: true };
  const { queue, qs } = await getQueue();
  const current = queue.find(i => i.id === qs.currentId);
  if (!current || current.url !== message.url) return { success: true }; // a link played directly: just show the error
  failStreak++;
  if (failStreak >= queue.length) {
    failStreak = 0;
    return { success: true, stopped: true };
  }
  await saveNotice(`Skipped "${current.title || current.url}": ${message.error || 'it could not be played.'}`);
  return next({ auto: true });
}

async function handleBackgroundMessage(message) {
  switch (message.type) {
    case 'NEXT':
      return next();
    case 'PREVIOUS':
      return previous();
    case 'TOGGLE':
      return togglePlayback();
    case 'TRACK_ENDED': {
      const live = await getSavedState();
      if (message.url && live.url && message.url !== live.url) return { success: true };
      failStreak = 0;
      return next({ auto: true });
    }
    case 'TRACK_FAILED':
      return onTrackFailed(message);
    case 'QUEUE_ADD':
      return queueAdd(message.items, !!message.playNext);
    case 'QUEUE_PLAY': {
      const { queue } = await getQueue();
      if (!queue.some(i => i.id === message.id)) return { success: false, error: 'This item is no longer in the queue.' };
      return playItem(queue, message.id);
    }
    case 'QUEUE_REMOVE':
      return updateQueue((queue, qs) => {
        if (!queue.some(i => i.id === message.id)) return { response: { success: false, error: 'Item not found.' } };
        const order = playOrder(queue, qs);
        const removedPos = order.indexOf(message.id);
        const nextQs = { ...qs, order: (qs.order || []).filter(id => id !== message.id) };
        if (qs.currentId === message.id) {
          // The track keeps playing; "next" continues with the item that followed it.
          nextQs.currentId = null;
          nextQs.resumeAt = removedPos;
        } else if (!order.includes(qs.currentId) && removedPos >= 0 && removedPos < (qs.resumeAt || 0)) {
          nextQs.resumeAt = qs.resumeAt - 1;
        }
        return { queue: queue.filter(i => i.id !== message.id), qs: nextQs };
      });
    case 'QUEUE_MOVE':
      return updateQueue((queue) => {
        const from = queue.findIndex(i => i.id === message.id);
        if (from === -1) return { response: { success: false, error: 'Item not found.' } };
        const to = Math.max(0, Math.min(queue.length - 1, Number(message.to)));
        const copy = queue.slice();
        const [item] = copy.splice(from, 1);
        copy.splice(to, 0, item);
        return { queue: copy };
      });
    case 'QUEUE_SET_TITLE':
      return updateQueue((queue) => ({
        queue: queue.map(i => (i.id === message.id && !i.title ? { ...i, title: String(message.title || '').slice(0, 200) } : i))
      }));
    case 'QUEUE_CLEAR':
      return updateQueue((queue, qs) => ({ queue: [], qs: { ...qs, order: [], currentId: null, resumeAt: 0 } }));
    case 'SAVED_SAVE':
      return saveQueueAs(message.name);
    case 'SAVED_LOAD':
      return loadSavedList(message.id, message.mode === 'append' ? 'append' : 'replace');
    case 'SAVED_DELETE':
      return deleteSavedList(message.id);
    case 'SET_SHUFFLE': {
      const shuffle = !!message.shuffle;
      const res = await updateQueue((queue, qs) => {
        const nextQs = { ...qs, shuffle, order: shuffle ? newShuffleOrder(queue, qs.currentId) : [] };
        // Without a current queue item, the old position means nothing in the new order.
        if (!queue.some(i => i.id === qs.currentId)) nextQs.resumeAt = 0;
        return { qs: nextQs };
      });
      if (await hasOffscreenDocument()) await relay({ target: 'offscreen', type: 'SET_SHUFFLE', shuffle });
      return res;
    }
    case 'SET_REPEAT': {
      const repeat = ['off', 'all', 'one'].includes(message.repeat) ? message.repeat : 'off';
      await updateQueue((queue, qs) => ({ qs: { ...qs, repeat } }));
      // "Repeat one" is the player's loop flag.
      return handleOffscreenMessage({ target: 'offscreen', type: 'SET_LOOP', loop: repeat === 'one' });
    }
    default:
      return { success: false, error: 'Unknown message type: ' + message.type };
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.target === 'background') {
    if (message.type === 'STATE_UPDATE') {
      const s = message.state || {};
      if (s.playing && !s.error && s.position > 2) failStreak = 0; // something really plays
      saveState(s).then(() => sendResponse({ success: true }));
      return true;
    }
    if (message.type === 'GET_SAVED') {
      getSavedState().then(sendResponse);
      return true;
    }
    handleBackgroundMessage(message)
      .then(sendResponse)
      .catch(e => sendResponse({ success: false, error: (e && e.message) || String(e) }));
    return true;
  }

  if (message.target === 'offscreen' && !message.relayed) {
    handleOffscreenMessage(message)
      .then(sendResponse)
      .catch(e => sendResponse({ success: false, error: (e && e.message) || String(e) }));
    return true; // Keep the message channel open for async response
  }
  return false;
});

async function handleOffscreenMessage(message) {
  // Don't spin up an offscreen document just to read state or pause.
  if (['GET_STATE', 'PAUSE', 'STOP', 'SET_VOLUME', 'SET_LOOP', 'SEEK', 'SET_SLEEP', 'PLAY_AT', 'SET_SHUFFLE'].includes(message.type) && !(await hasOffscreenDocument())) {
    const saved = await getSavedState();
    if (message.type === 'SET_VOLUME') await saveState({ volume: Math.min(1, Math.max(0, Number(message.volume) || 0)) });
    if (message.type === 'SET_LOOP') await saveState({ loop: !!message.loop });
    if (message.type === 'PAUSE') await saveState({ playing: false });
    if (message.type === 'STOP') await saveState({ playing: false, sleepAt: 0, sleepEndOfTrack: false });
    if (message.type === 'SET_SLEEP') {
      if (message.minutes > 0 || message.endOfTrack) return { success: false, error: 'Start playing something first.' };
      await saveState({ sleepAt: 0, sleepEndOfTrack: false });
      return { success: true, sleepAt: 0, sleepEndOfTrack: false };
    }
    if (message.type === 'SEEK' && saved.url) await saveState({ position: Math.max(0, Number(message.position) || 0) });
    return { success: true, ...(await getSavedState()), playing: false, live: false };
  }

  if (message.type === 'PLAY') {
    await refererRuleReady;
    const [saved, settings, { queue, qs }] = await Promise.all([getSavedState(), getSettings(), getQueue()]);
    message = {
      ...message,
      prefs: {
        volume: typeof saved.volume === 'number' ? saved.volume : 0.5,
        loop: qs.repeat === 'one',
        shuffle: !!qs.shuffle,
        // Chrome closes the player about 30 s after audio stops (for example while
        // paused), which also drops its sleep timer. A new player picks it up again.
        sleepAt: saved.sleepAt > Date.now() ? saved.sleepAt : 0,
        sleepEndOfTrack: !!saved.sleepEndOfTrack
      }
    };
    // A URL typed in the popup that is also in the queue continues the queue from there.
    if (!('queueId' in message)) {
      await updateQueue((q, s) => {
        const current = q.find(i => i.id === s.currentId);
        if (current && current.url === message.url) return {}; // same item (resume)
        const inQueue = q.find(i => i.url === message.url);
        if (inQueue) return { qs: { ...s, currentId: inQueue.id, resumeAt: 0 } };
        if (!current) return {};
        // A link played directly: the queue continues after the item that was playing.
        const order = playOrder(q, s);
        return { qs: { ...s, currentId: null, resumeAt: order.indexOf(current.id) + 1 } };
      });
    }
    // Resume where the user left off if the same track is played again.
    if (settings.resume && !message.noResume && message.url && message.url === saved.url && !saved.isLive) {
      if (saved.position > 5 && !(saved.duration && saved.position > saved.duration - 5)) message.startAt = saved.position;
      if (saved.isPlaylist && saved.playlistIndex > 0) message.startIndex = saved.playlistIndex;
    }
  }

  await setupOffscreenDocument();
  return relay(message);
}

async function relay(message, attempt = 0) {
  try {
    // Mark as relayed so the offscreen document only acts on the copy sent by
    // the service worker (it would otherwise also receive the popup's original).
    const response = await chrome.runtime.sendMessage({ ...message, relayed: true });
    if (!response) throw new Error('Empty response');
    return response;
  } catch (error) {
    if (attempt >= 15) {
      console.error('Offscreen failure:', error);
      return { success: false, error: 'Offscreen communication failed. Please reload the extension.' };
    }
    await new Promise(r => setTimeout(r, 200));
    await setupOffscreenDocument();
    return relay(message, attempt + 1);
  }
}

// Keyboard shortcuts (chrome://extensions/shortcuts)
chrome.commands.onCommand.addListener((command) => {
  const actions = { 'toggle-playback': togglePlayback, 'next-track': () => next(), 'previous-track': previous };
  const action = actions[command];
  if (action) action().catch(e => console.warn('Command failed:', e && e.message));
});

// The offscreen document is gone after a browser restart, so nothing can be playing.
chrome.runtime.onStartup.addListener(() => saveState({ playing: false, sleepAt: 0, sleepEndOfTrack: false }));

chrome.runtime.onInstalled.addListener(async ({ reason }) => {
  // Installing or updating closes the player too.
  if (reason !== 'install') await saveState({ playing: false, sleepAt: 0, sleepEndOfTrack: false });
  // v1.1 stored "loop" on the player state; it becomes "repeat one".
  if (reason === 'update') {
    const { playerState, queueState } = await chrome.storage.local.get(['playerState', 'queueState']);
    if (!queueState && playerState && playerState.loop) {
      await chrome.storage.local.set({ queueState: { currentId: null, shuffle: false, repeat: 'one', order: [] } });
    }
  }
});

// YouTube's embedded player refuses to play (error 153) when the embedding page
// sends no HTTP Referer, which is the case for chrome-extension:// pages. Add one,
// but only for embed requests made by this extension's offscreen document.
const YT_REFERER_RULE_ID = 1;
// A stable, extension-specific https origin (never resolves to a real site).
const REFERER_VALUE = `https://${chrome.runtime.id}.chromiumapp.org/`;
async function installRefererRule() {
  try {
    await chrome.declarativeNetRequest.updateSessionRules({
      removeRuleIds: [YT_REFERER_RULE_ID],
      addRules: [{
        id: YT_REFERER_RULE_ID,
        priority: 1,
        action: {
          type: 'modifyHeaders',
          requestHeaders: [{ header: 'referer', operation: 'set', value: REFERER_VALUE }]
        },
        condition: {
          urlFilter: '||www.youtube.com/embed/',
          resourceTypes: ['sub_frame'],
          initiatorDomains: [chrome.runtime.id],
          tabIds: [-1] // requests not made from a tab (the offscreen document)
        }
      }]
    });
  } catch (e) {
    console.warn('Could not install YouTube referer rule:', e && e.message);
  }
}
const refererRuleReady = installRefererRule();
