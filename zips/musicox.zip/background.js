const OFFSCREEN_DOCUMENT_PATH = 'offscreen.html';
const MAX_RECENT = 8;

let creatingOffscreen; // A promise to track offscreen document creation

async function hasOffscreenDocument() {
  const contexts = await chrome.runtime.getContexts({
    contextTypes: ['OFFSCREEN_DOCUMENT'],
    documentUrls: [chrome.runtime.getURL(OFFSCREEN_DOCUMENT_PATH)]
  });
  return contexts.length > 0;
}

async function setupOffscreenDocument() {
  if (await hasOffscreenDocument()) return;

  if (creatingOffscreen) {
    await creatingOffscreen.catch(() => {});
    return;
  }
  creatingOffscreen = chrome.offscreen.createDocument({
    url: OFFSCREEN_DOCUMENT_PATH,
    reasons: ['AUDIO_PLAYBACK'],
    justification: 'Playback of music in the background.'
  });
  try {
    await creatingOffscreen;
  } catch (e) {
    // A concurrent caller may have created it already; anything else is retried by relay()
    console.warn('Offscreen creation:', e && e.message);
  } finally {
    creatingOffscreen = null;
  }
}

async function getSavedState() {
  const { playerState } = await chrome.storage.local.get('playerState');
  return playerState || {};
}

// Persist state reported by the offscreen document (it has no chrome.storage access).
let stateWrite = Promise.resolve();
function saveState(state) {
  stateWrite = stateWrite.then(async () => {
    const { playerState = {}, recent = [] } = await chrome.storage.local.get(['playerState', 'recent']);
    const next = { ...playerState, ...state, updatedAt: Date.now() };
    const update = { playerState: next };

    if (state.url && state.playing && !state.error) {
      const existing = recent.find(r => r.url === state.url);
      const entry = { url: state.url, title: state.title || (existing && existing.title) || '', isYouTube: !!state.isYouTube };
      const changed = !existing || recent[0].url !== state.url || existing.title !== entry.title;
      if (changed) {
        update.recent = [entry, ...recent.filter(r => r.url !== state.url)].slice(0, MAX_RECENT);
      }
    }
    await chrome.storage.local.set(update);
  }).catch(e => console.warn('Saving state failed:', e && e.message));
  return stateWrite;
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.target === 'background') {
    if (message.type === 'STATE_UPDATE') {
      saveState(message.state || {}).then(() => sendResponse({ success: true }));
      return true;
    }
    if (message.type === 'GET_SAVED') {
      getSavedState().then(sendResponse);
      return true;
    }
    return false;
  }

  if (message.target === 'offscreen' && !message.relayed) {
    handleOffscreenMessage(message)
      .then(sendResponse)
      .catch(e => sendResponse({ success: false, error: (e && e.message) || String(e) }));
    return true; // Keep the message channel open for async response
  }
  return false;
});

async function handleOffscreenMessage(message) {
  // Don't spin up an offscreen document just to read state or pause.
  if (['GET_STATE', 'PAUSE', 'STOP', 'SET_VOLUME', 'SET_LOOP'].includes(message.type) && !(await hasOffscreenDocument())) {
    const saved = await getSavedState();
    if (message.type === 'SET_VOLUME') await saveState({ volume: message.volume });
    if (message.type === 'SET_LOOP') await saveState({ loop: !!message.loop });
    if (message.type === 'PAUSE' || message.type === 'STOP') await saveState({ playing: false });
    return { success: true, ...saved, playing: false };
  }

  if (message.type === 'PLAY') {
    await refererRuleReady;
    const saved = await getSavedState();
    message = {
      ...message,
      prefs: { volume: typeof saved.volume === 'number' ? saved.volume : 0.5, loop: !!saved.loop }
    };
    // Resume where the user left off if the same track is played again.
    if (message.url && message.url === saved.url && saved.position > 5 &&
        !(saved.duration && saved.position > saved.duration - 5)) {
      message.startAt = saved.position;
    }
  }

  await setupOffscreenDocument();
  return relay(message);
}

async function relay(message, attempt = 0) {
  try {
    // Mark as relayed so the offscreen document only acts on the copy sent by
    // the service worker (it would otherwise also receive the popup's original).
    const response = await chrome.runtime.sendMessage({ ...message, relayed: true });
    if (!response) throw new Error('Empty response');
    return response;
  } catch (error) {
    if (attempt >= 15) {
      console.error('Offscreen failure:', error);
      return { success: false, error: 'Offscreen communication failed. Please reload the extension.' };
    }
    await new Promise(r => setTimeout(r, 200));
    await setupOffscreenDocument();
    return relay(message, attempt + 1);
  }
}

// The offscreen document is gone after a browser restart, so nothing can be playing.
chrome.runtime.onStartup.addListener(() => saveState({ playing: false }));

// YouTube's embedded player refuses to play (error 153) when the embedding page
// sends no HTTP Referer, which is the case for chrome-extension:// pages. Add one,
// but only for embed requests made by this extension's offscreen document.
const YT_REFERER_RULE_ID = 1;
// A stable, extension-specific https origin (never resolves to a real site).
const REFERER_VALUE = `https://${chrome.runtime.id}.chromiumapp.org/`;
async function installRefererRule() {
  try {
    await chrome.declarativeNetRequest.updateSessionRules({
      removeRuleIds: [YT_REFERER_RULE_ID],
      addRules: [{
        id: YT_REFERER_RULE_ID,
        priority: 1,
        action: {
          type: 'modifyHeaders',
          requestHeaders: [{ header: 'referer', operation: 'set', value: REFERER_VALUE }]
        },
        condition: {
          urlFilter: '||www.youtube.com/embed/',
          resourceTypes: ['sub_frame'],
          initiatorDomains: [chrome.runtime.id],
          tabIds: [-1] // requests not made from a tab (the offscreen document)
        }
      }]
    });
  } catch (e) {
    console.warn('Could not install YouTube referer rule:', e && e.message);
  }
}
const refererRuleReady = installRefererRule();
