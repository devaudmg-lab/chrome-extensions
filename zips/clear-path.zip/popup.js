document.getElementById("openBtn").addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  // Content scripts can only run on normal web pages (not chrome://, edge://, the Web Store, PDFs, etc.)
  if (!tab || !tab.url || !/^(https?|file):/.test(tab.url)) {
    alert("ClearPath cannot run on this page.");
    return;
  }

  try {
    // Send message to content.js to show the sidebar
    await chrome.tabs.sendMessage(tab.id, { action: "openSidebar" });
  } catch (err) {
    // content.js isn't present yet (tab was open before the extension was installed/reloaded)
    try {
      await chrome.scripting.insertCSS({
        target: { tabId: tab.id },
        files: ["styles.css"],
      });
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["content.js"],
      });
      await chrome.tabs.sendMessage(tab.id, { action: "openSidebar" });
    } catch (injectErr) {
      alert("ClearPath cannot run on this page. Try reloading the tab.");
      return;
    }
  }

  // Close the popup window only after the sidebar has been opened
  window.close();
});
