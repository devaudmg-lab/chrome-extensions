function showError(text) {
  const el = document.getElementById("error");
  el.textContent = text;
  el.style.display = "block";
}

document.getElementById("openBtn").addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  // Content scripts can only run on normal web pages (not chrome://, edge://, the Web Store, PDFs, etc.)
  if (!tab || !tab.url || !/^(https?|file):/.test(tab.url)) {
    showError("ClearPath cannot run on this page. Open a normal web page and try again.");
    return;
  }

  try {
    // Send message to content.js to show the sidebar
    await chrome.tabs.sendMessage(tab.id, { action: "openSidebar" });
  } catch (err) {
    // content.js isn't present yet (tab was open before the extension was installed/reloaded)
    try {
      await chrome.scripting.insertCSS({
        target: { tabId: tab.id },
        files: ["styles.css"],
      });
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["content.js"],
      });
      await chrome.tabs.sendMessage(tab.id, { action: "openSidebar" });
    } catch (injectErr) {
      showError("ClearPath cannot run on this page. Try reloading the tab.");
      return;
    }
  }

  // Close the popup window only after the sidebar has been opened
  window.close();
});

// Show the shortcuts the user actually has (they can be changed in Chrome)
chrome.commands.getAll((commands) => {
  commands.forEach((c) => {
    const el = document.getElementById("key-" + c.name);
    if (el) el.textContent = c.shortcut || "not set";
  });
});

document.getElementById("shortcuts").addEventListener("click", (e) => {
  e.preventDefault();
  chrome.tabs.create({ url: "chrome://extensions/shortcuts" });
});
