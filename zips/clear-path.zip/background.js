// Keyboard shortcuts (chrome://extensions/shortcuts). Using a shortcut grants activeTab,
// so ClearPath can also be injected into tabs that were open before it was installed.
async function sendToTab(tab, action) {
  if (!tab || !tab.id || !/^(https?|file):/.test(tab.url || "")) return;
  try {
    await chrome.tabs.sendMessage(tab.id, { action });
    return;
  } catch (err) {
    /* content script not there yet */
  }
  try {
    await chrome.scripting.insertCSS({ target: { tabId: tab.id }, files: ["styles.css"] });
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] });
    await chrome.tabs.sendMessage(tab.id, { action });
  } catch (err) {
    /* page cannot be modified (Web Store, PDF viewer, ...) */
  }
}

chrome.commands.onCommand.addListener(async (command, tab) => {
  if (!tab) [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (command === "toggle-sidebar") sendToTab(tab, "toggleSidebar");
  else if (command === "read-aloud") sendToTab(tab, "toggleReadAloud");
});
