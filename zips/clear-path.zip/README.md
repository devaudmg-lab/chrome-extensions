# ClearPath Zen Pro

A calm-reading toolkit for any web page. Hide distracting elements, widen or narrow cramped article columns, and add reading aids such as a reading ruler, colour tints, bionic reading and bigger text.

## Features

- **Target & Hide**: click any ad, banner or sidebar to hide it. ClearPath remembers it for that site, and you can undo it.
- **Target & Resize**: click a container and drag its corner handle to change its width. The text re-flows to fit.
- **Undo Last / Revert All**: bring back the last element you hid, or reset everything ClearPath changed on the current site.
- **Bionic Mode**: makes the first half of each word bold to guide your eyes. Click it again to turn it off.
- **Reading Ruler**: a highlighted bar that follows your mouse.
- **Tints**: sepia, warm amber, soft blue, soft green or a dim overlay to reduce eye strain.
- **Typography**: sliders for paragraph text size and line spacing.
- **Esc** stops hide/resize targeting.

## Install (Load unpacked)

1. Download the ZIP and extract it to a folder.
2. Open `chrome://extensions` and turn on **Developer mode** (top right).
3. Click **Load unpacked** and select the extracted folder (the one that contains `manifest.json`).
4. Pin ClearPath, open any web page and click the icon, then **Open Zen Control**.

Tabs that were already open before installing are handled automatically when you click the button. Browser pages (`chrome://`, the Web Store) cannot be modified.

## Permissions

- **Read and change data on websites** (content script on all sites): needed to show the sidebar and hide, resize or restyle page elements. Nothing is sent anywhere.
- **storage**: remembers which elements you hid on each site, stored locally in your browser.
- **activeTab / scripting**: injects ClearPath into a tab that was open before the extension was installed, only when you click the button.

ClearPath has no server, no analytics and no network requests.
