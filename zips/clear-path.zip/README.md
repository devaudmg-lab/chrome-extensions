# ClearPath Zen Pro

A calm-reading toolkit for any web page. Hide distracting elements, widen or narrow cramped article columns, listen to articles, and add reading aids such as a reading ruler, a focus mask, colour tints, dyslexia-friendly fonts and bionic reading.

## Features

- **Target & Hide**: click any ad, banner or sidebar to hide it. ClearPath remembers it for that site and shows how many elements are hidden. **Undo Last** works even after a reload.
- **Target & Resize**: click a container and drag its corner handle to change its width. The text re-flows to fit.
- **Undo Last / Revert All**: bring back the last element you hid, or reset everything ClearPath changed on the current site (Revert All asks for a second click).
- **Read Aloud**: reads the text you selected, or the article from where you are, using your browser's built-in voices. The paragraph being read is highlighted and scrolled into view, and (new in 1.4) **the word being spoken is highlighted too**. Play, pause, stop, **previous / next paragraph**, progress ("Paragraph 12 of 48"), **voice picker** and speed (0.8x to 2x). Long articles and text without full stops (for example Chinese or Japanese) are split into short pieces so Chrome never stops mid-article. Previous restarts the paragraph; press it again quickly to go one paragraph back.
- **Focus Mask** (new in 1.3): dims the page above and below a clear reading band that follows your mouse. The **Band** slider sets its height (also used by the ruler).
- **Reading Ruler**: a highlighted bar that follows your mouse.
- **Tints**: sepia, warm amber, soft blue, soft green or a dim overlay. Click the active tint again to turn it off.
- **Typography**: font (OpenDyslexic, a readable sans, a book serif or the page's own font), text size, line spacing and letter spacing.
- **Remembered per site** (new in 1.3): tint, font and spacing settings are saved for each site and applied automatically next time. **Clear All Filters** or **Revert All** forgets them.
- **Bionic Mode**: makes the first half of each word bold to guide your eyes. Remembered per site (new in 1.4). It only touches article text, never menus, buttons, code or anything you can type into, and it keeps working on pages that update their text live.
- **Dock left or right** (new in 1.4): the ⇆ button moves the panel to the other side so it never covers what you want to hide.
- First-run welcome tip, and on-page messages instead of pop-up dialogs.

## Keyboard shortcuts

| Shortcut | Action |
| :--- | :--- |
| `Alt+Shift+Q` | Open or close the ClearPath panel |
| `Alt+Shift+S` | Read aloud: start, pause or resume |
| `Esc` | Stop hide/resize targeting, or close the panel when it has focus |

Change them at `chrome://extensions/shortcuts` (the popup has a link).

## Install (Load unpacked)

1. Download the ZIP and extract it to a folder.
2. Open `chrome://extensions` and turn on **Developer mode** (top right).
3. Click **Load unpacked** and select the extracted folder (the one that contains `manifest.json`).
4. Pin ClearPath, open any web page and click the icon, then **Open Zen Control** (or press `Alt+Shift+Q`).

Tabs that were already open before installing are handled automatically when you click the button or use a shortcut. Browser pages (`chrome://`, the Web Store) cannot be modified.

## Permissions

| Permission | Why |
| :--- | :--- |
| Read and change data on websites (content script on all sites) | Shows the panel and hides, resizes or restyles page elements. Nothing is sent anywhere. |
| `storage` | Remembers hidden elements and reading settings for each site, and your read-aloud speed, voice and panel side, locally in your browser. In a private (incognito) window nothing new is saved for the site. |
| `activeTab` / `scripting` | Injects ClearPath into a tab that was open before the extension was installed, only when you click the button or press a shortcut. |

No new permissions were added in 1.3 or 1.4. The bundled OpenDyslexic font files are web-accessible only through Chrome's per-session dynamic URL (`use_dynamic_url`), so sites cannot use them to detect that ClearPath is installed. Read Aloud uses the browser's built-in speech engine (`speechSynthesis`). Depending on the voice you pick in your operating system, Chrome may use an online voice.

ClearPath has no server, no analytics and makes no network requests of its own. Its panel, messages and overlays live in a closed shadow root, so the page's CSS cannot break them and the page's scripts cannot read or click them.

## Credits

The OpenDyslexic font (`fonts/`) is by Abbie Gonzalez and is used under the SIL Open Font License 1.1. See `fonts/OFL.txt`.

## Changelog

- **1.4.0**: word-by-word highlighting, previous/next paragraph, progress and voice picker for Read Aloud; dock the panel left or right; Bionic Mode remembered per site; Undo works after a reload; hidden-element count; Revert All confirmation. Fixes: panel moved into a closed shadow root (page CSS broke it, page scripts could read and click it, and its `.cp-*` classes styled pages' own elements); hidden elements applied with one stylesheet instead of a MutationObserver that read storage on every page change; Bionic Mode no longer breaks React-style pages or editable areas and no longer splits emoji; typography no longer resizes menus, toolbars, code or editors; Read Aloud picks the real article, splits unpunctuated text and starts instantly on long pages; extension updates no longer leave a dead panel behind; clicking the page background no longer hides the whole page; private windows no longer write site names to storage; Clear All Filters no longer wipes the page's own CSS filter; resize restores the original position; better contrast, aria labels and focus rings.

- **1.3.0**: Read Aloud with paragraph highlighting, Focus Mask, adjustable band height, OpenDyslexic / readable fonts and letter spacing, per-site saved reading settings, keyboard shortcuts, first-run tip, dark-mode popup, toasts instead of alerts.
- **1.2.0**: bug fixes, bionic toggle, typography sliders, more tints.
