# ClearPath Zen Pro

A calm-reading toolkit for any web page. Hide distracting elements, widen or narrow cramped article columns, listen to articles, and add reading aids such as a reading ruler, a focus mask, colour tints, dyslexia-friendly fonts and bionic reading.

## Features

- **Target & Hide**: click any ad, banner or sidebar to hide it. ClearPath remembers it for that site, and you can undo it.
- **Target & Resize**: click a container and drag its corner handle to change its width. The text re-flows to fit.
- **Undo Last / Revert All**: bring back the last element you hid, or reset everything ClearPath changed on the current site.
- **Read Aloud** (new in 1.3): reads the text you selected, or the article from where you are, using your browser's built-in voices. The paragraph being read is highlighted and scrolled into view. Play, pause, stop and speed (0.8x to 2x).
- **Focus Mask** (new in 1.3): dims the page above and below a clear reading band that follows your mouse. The **Band** slider sets its height (also used by the ruler).
- **Reading Ruler**: a highlighted bar that follows your mouse.
- **Tints**: sepia, warm amber, soft blue, soft green or a dim overlay. Click the active tint again to turn it off.
- **Typography**: font (OpenDyslexic, a readable sans, a book serif or the page's own font), text size, line spacing and letter spacing.
- **Remembered per site** (new in 1.3): tint, font and spacing settings are saved for each site and applied automatically next time. **Clear All Filters** or **Revert All** forgets them.
- **Bionic Mode**: makes the first half of each word bold to guide your eyes. Click it again to turn it off.
- First-run welcome tip, and on-page messages instead of pop-up dialogs.

## Keyboard shortcuts

| Shortcut | Action |
| :--- | :--- |
| `Alt+Shift+Q` | Open or close the ClearPath panel |
| `Alt+Shift+S` | Read aloud: start, pause or resume |
| `Esc` | Stop hide/resize targeting |

Change them at `chrome://extensions/shortcuts` (the popup has a link).

## Install (Load unpacked)

1. Download the ZIP and extract it to a folder.
2. Open `chrome://extensions` and turn on **Developer mode** (top right).
3. Click **Load unpacked** and select the extracted folder (the one that contains `manifest.json`).
4. Pin ClearPath, open any web page and click the icon, then **Open Zen Control** (or press `Alt+Shift+Q`).

Tabs that were already open before installing are handled automatically when you click the button or use a shortcut. Browser pages (`chrome://`, the Web Store) cannot be modified.

## Permissions

| Permission | Why |
| :--- | :--- |
| Read and change data on websites (content script on all sites) | Shows the panel and hides, resizes or restyles page elements. Nothing is sent anywhere. |
| `storage` | Remembers hidden elements and reading settings for each site, and your read-aloud speed, locally in your browser. |
| `activeTab` / `scripting` | Injects ClearPath into a tab that was open before the extension was installed, only when you click the button or press a shortcut. |

No new permissions were added in 1.3. Read Aloud uses the browser's built-in speech engine (`speechSynthesis`). Depending on the voice you pick in your operating system, Chrome may use an online voice.

ClearPath has no server, no analytics and makes no network requests of its own.

## Credits

The OpenDyslexic font (`fonts/`) is by Abbie Gonzalez and is used under the SIL Open Font License 1.1. See `fonts/OFL.txt`.

## Changelog

- **1.3.0**: Read Aloud with paragraph highlighting, Focus Mask, adjustable band height, OpenDyslexic / readable fonts and letter spacing, per-site saved reading settings, keyboard shortcuts, first-run tip, dark-mode popup, toasts instead of alerts.
- **1.2.0**: bug fixes, bionic toggle, typography sliders, more tints.
