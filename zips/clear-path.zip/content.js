let hiddenElementsStack = [];
let isHideModeActive = false;
let isResizeModeActive = false;
let currentTintOverlay = null;
let ruler = null;
let focusMask = null;
let lastMouseY = window.innerHeight / 2;
let isBionicActive = false;
let resizedElements = [];

// Reading settings remembered per site (tint, typography, font, focus band height)
const PREFS_KEY = "cpPrefs:" + window.location.hostname;
const DEFAULT_PREFS = {
  tint: "none",
  fontSize: 0,
  lineHeight: 0,
  letterSpacing: 0,
  font: "page",
  band: 34,
};
let prefs = { ...DEFAULT_PREFS };
let prefsSaveTimer = null;

const FONT_STACKS = {
  dyslexic: "'OpenDyslexic', Verdana, sans-serif",
  sans: "Verdana, 'Segoe UI', Tahoma, Arial, sans-serif",
  serif: "Georgia, 'Iowan Old Style', 'Times New Roman', serif",
};

const cpStyleTag = document.createElement("style");
cpStyleTag.id = "cp-dynamic-styles";
(document.head || document.documentElement).appendChild(cpStyleTag);

function updateGlobalStyles(css) {
  cpStyleTag.textContent = css;
}

function updateButtonUI() {
  const hideBtn = document.getElementById("cp-hide-toggle");
  const resizeBtn = document.getElementById("cp-resize-toggle");
  if (hideBtn) {
    hideBtn.textContent = isHideModeActive
      ? "HIDING: ON (Esc)"
      : "Target & Hide";
    hideBtn.style.background = isHideModeActive ? "#ef4444" : "";
  }
  if (resizeBtn) {
    resizeBtn.textContent = isResizeModeActive
      ? "RESIZE: ON (Esc)"
      : "Target & Resize";
    resizeBtn.style.background = isResizeModeActive ? "#ef4444" : "";
  }
}

// Mark the ruler / focus mask / tint buttons that are currently on
function updateSensoryUI() {
  const rulerBtn = document.getElementById("cp-ruler-btn");
  const maskBtn = document.getElementById("cp-mask-btn");
  if (rulerBtn) {
    rulerBtn.classList.toggle("cp-on", !!ruler);
  }
  if (maskBtn) {
    maskBtn.classList.toggle("cp-on", !!focusMask);
  }
  document.querySelectorAll("#clearpath-sidebar .cp-tint").forEach((b) => {
    b.classList.toggle("cp-tint-active", b.dataset.tint === prefs.tint);
  });
}

// Small message at the bottom of the page (replaces blocking alert() dialogs)
let toastTimer = null;
function showToast(text) {
  let toast = document.getElementById("cp-toast");
  if (!toast) {
    toast = document.createElement("div");
    toast.id = "cp-toast";
    document.documentElement.appendChild(toast);
  }
  toast.textContent = text;
  toast.classList.add("cp-toast-show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("cp-toast-show"), 2600);
}

// --- Per-site reading settings ---
function savePrefs() {
  clearTimeout(prefsSaveTimer);
  prefsSaveTimer = setTimeout(() => {
    const isDefault = Object.keys(DEFAULT_PREFS).every((k) => prefs[k] === DEFAULT_PREFS[k]);
    try {
      if (isDefault) chrome.storage.local.remove(PREFS_KEY);
      else chrome.storage.local.set({ [PREFS_KEY]: prefs });
    } catch (err) {
      /* extension reloaded: ignore */
    }
  }, 250);
}

async function loadPrefs() {
  try {
    const data = await chrome.storage.local.get(PREFS_KEY);
    if (data[PREFS_KEY]) prefs = { ...DEFAULT_PREFS, ...data[PREFS_KEY] };
  } catch (err) {
    return;
  }
  applyReadingStyles();
  if (prefs.tint !== "none") applyTint(prefs.tint, false);
  syncTypographyControls();
}

// Builds the page-wide reading CSS from `prefs` (0 / "page" = leave the page's own value)
function applyReadingStyles() {
  const css = [];
  const text = [];
  if (prefs.fontSize > 0) text.push(`font-size: ${prefs.fontSize}px !important;`);
  if (prefs.lineHeight > 0) text.push(`line-height: ${prefs.lineHeight} !important;`);
  if (prefs.letterSpacing > 0) text.push(`letter-spacing: ${prefs.letterSpacing}em !important;`);
  if (text.length) css.push(`p, li, dd, blockquote { ${text.join(" ")} }`);
  if (prefs.font !== "page" && FONT_STACKS[prefs.font]) {
    if (prefs.font === "dyslexic") {
      const reg = chrome.runtime.getURL("fonts/OpenDyslexic-Regular.woff2");
      const bold = chrome.runtime.getURL("fonts/OpenDyslexic-Bold.woff2");
      css.push(`@font-face { font-family: 'OpenDyslexic'; src: url('${reg}') format('woff2'); font-weight: 400; font-display: swap; }`);
      css.push(`@font-face { font-family: 'OpenDyslexic'; src: url('${bold}') format('woff2'); font-weight: 700; font-display: swap; }`);
    }
    // Text blocks and their inline children; icon tags (<i>) are left alone so icon fonts keep working
    const blocks = ":is(p, li, dd, dt, blockquote, td, th, h1, h2, h3, h4, h5, h6, figcaption, caption)";
    css.push(
      `${blocks}:not(#clearpath-sidebar *), ${blocks}:not(#clearpath-sidebar *) :is(a, span, em, strong, b, cite, q, small, abbr, mark) { font-family: ${FONT_STACKS[prefs.font]} !important; }`,
    );
  }
  updateGlobalStyles(css.join("\n"));
}

// --- NEW FUNCTION: REVERT ALL CHANGES ---
async function revertAllChanges() {
  const domain = window.location.hostname;

  // 1. Clear Storage for this domain (remember which selectors we had hidden)
  const data = await chrome.storage.local.get(domain);
  const storedSelectors = data[domain] || [];
  await chrome.storage.local.remove([domain, PREFS_KEY]);

  // 2. Show all hidden elements in the current session
  hiddenElementsStack.forEach((item) => {
    if (item.el) item.el.style.setProperty("display", "", "");
  });

  // 3. Show elements hidden by persistence (only ours, not the page's own hidden elements)
  storedSelectors.forEach((s) => {
    try {
      document.querySelectorAll(s).forEach((el) => {
        if (el.style.getPropertyPriority("display") === "important")
          el.style.removeProperty("display");
      });
    } catch (err) {
      /* invalid selector */
    }
  });

  // 4. Reset Stack
  hiddenElementsStack = [];

  // 5. Turn off all modes
  isHideModeActive = false;
  isResizeModeActive = false;
  if (currentTintOverlay) {
    currentTintOverlay.remove();
    currentTintOverlay = null;
  }
  if (ruler) {
    ruler.remove();
    ruler = null;
  }
  if (focusMask) toggleFocusMask();
  stopReading();
  document.documentElement.style.filter = "";
  clearTimeout(prefsSaveTimer);
  prefs = { ...DEFAULT_PREFS };
  updateGlobalStyles("");
  removeBionic();
  resizedElements.forEach(({ el, width, maxWidth }) => {
    el.style.width = width;
    el.style.maxWidth = maxWidth;
    delete el.dataset.cpResizing;
    el.querySelectorAll(":scope > .cp-resizer-handle").forEach((h) => h.remove());
  });
  resizedElements = [];
  syncTypographyControls();
  updateButtonUI();
  updateSensoryUI();

  showToast("All ClearPath changes on this site have been reverted.");
}

document.addEventListener("mouseover", (e) => {
  if (e.target.closest && e.target.closest("#clearpath-sidebar")) return;
  if (isHideModeActive || isResizeModeActive)
    e.target.classList.add("clearpath-hover-target");
});
document.addEventListener("mouseout", (e) => {
  e.target.classList.remove("clearpath-hover-target");
});

document.addEventListener(
  "click",
  (e) => {
    if (e.target.closest("#clearpath-sidebar")) return;
    if (isHideModeActive) {
      e.preventDefault();
      e.stopPropagation();
      hideElement(e.target);
    } else if (isResizeModeActive) {
      e.preventDefault();
      e.stopPropagation();
      makeElementResizable(e.target);
    }
  },
  true,
);

function getUniqueSelector(el) {
  if (el.id) return `#${CSS.escape(el.id)}`;
  let path = [];
  while (el.parentElement && el.tagName !== "HTML") {
    let index = Array.from(el.parentElement.children).indexOf(el) + 1;
    path.unshift(`${el.tagName.toLowerCase()}:nth-child(${index})`);
    el = el.parentElement;
  }
  return path.join(" > ");
}

async function hideElement(el) {
  const selector = getUniqueSelector(el);
  const domain = window.location.hostname;
  el.classList.remove("clearpath-hover-target");
  el.style.setProperty("display", "none", "important");
  hiddenElementsStack.push({ el, selector });
  const data = await chrome.storage.local.get(domain);
  const hiddenSelectors = data[domain] || [];
  if (!hiddenSelectors.includes(selector)) {
    hiddenSelectors.push(selector);
    await chrome.storage.local.set({ [domain]: hiddenSelectors });
  }
}

function undoLastHide() {
  const last = hiddenElementsStack.pop();
  if (!last) {
    showToast("Nothing to undo yet.");
    return;
  }
  if (last.el) {
    last.el.style.setProperty("display", "", "");
    const domain = window.location.hostname;
    chrome.storage.local.get(domain).then((data) => {
      const list = data[domain] || [];
      const filtered = list.filter((s) => s !== last.selector);
      chrome.storage.local.set({ [domain]: filtered });
    });
  }
}

function escapeHtml(str) {
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function applyBionic() {
  const walker = document.createTreeWalker(
    document.body,
    NodeFilter.SHOW_TEXT,
    null,
    false,
  );
  // Collect first: replacing nodes while walking detaches the walker after the first replacement
  const nodes = [];
  let node;
  while ((node = walker.nextNode())) {
    const parent = node.parentElement;
    if (!parent || !node.textContent.trim()) continue;
    if (
      ["SCRIPT", "STYLE", "NOSCRIPT", "TEXTAREA", "SELECT", "OPTION", "CODE", "PRE"].includes(
        parent.tagName,
      )
    )
      continue;
    if (parent.isContentEditable) continue;
    if (parent.closest("#clearpath-sidebar, #cp-toast, .cp-bionic")) continue;
    nodes.push(node);
  }
  nodes.forEach((node) => {
    const span = document.createElement("span");
    span.className = "cp-bionic";
    // Escape page text so it is never parsed as HTML
    span.innerHTML = node.textContent
      .split(/(\s+)/)
      .map((word) => {
        if (!word || /^\s+$/.test(word)) return word;
        if (word.length <= 3) return `<b>${escapeHtml(word)}</b>`;
        let mid = Math.ceil(word.length / 2);
        return `<b>${escapeHtml(word.slice(0, mid))}</b>${escapeHtml(word.slice(mid))}`;
      })
      .join("");
    node.parentElement.replaceChild(span, node);
  });
}

// Restore the original text nodes so Bionic Mode can be switched off again
function removeBionic() {
  document.querySelectorAll("span.cp-bionic").forEach((span) => {
    if (span.parentNode)
      span.parentNode.replaceChild(document.createTextNode(span.textContent), span);
  });
  if (document.body) document.body.normalize();
  isBionicActive = false;
  const btn = document.getElementById("cp-bionic-btn");
  if (btn) {
    btn.textContent = "Bionic Mode";
    btn.classList.remove("cp-on");
  }
}

function toggleBionic() {
  if (isBionicActive) {
    removeBionic();
    return;
  }
  applyBionic();
  isBionicActive = true;
  const btn = document.getElementById("cp-bionic-btn");
  if (btn) {
    btn.textContent = "Bionic Mode: ON";
    btn.classList.add("cp-on");
  }
}

// Put the sidebar controls in line with `prefs`
function syncTypographyControls() {
  const set = (id, value) => {
    const el = document.getElementById(id);
    if (el) el.value = value;
  };
  const label = (id, text) => {
    const el = document.getElementById(id);
    if (el) el.textContent = text;
  };
  set("cp-font-size", prefs.fontSize);
  set("cp-line-height", prefs.lineHeight);
  set("cp-letter-spacing", prefs.letterSpacing);
  set("cp-font-family", prefs.font);
  set("cp-band", prefs.band);
  label("cp-font-size-val", prefs.fontSize ? prefs.fontSize + "px" : "page");
  label("cp-line-height-val", prefs.lineHeight ? Number(prefs.lineHeight).toFixed(1) : "page");
  label("cp-letter-spacing-val", prefs.letterSpacing ? Number(prefs.letterSpacing).toFixed(2) : "page");
  label("cp-band-val", prefs.band + "px");
  updateSensoryUI();
}

function toggleRuler() {
  if (ruler) {
    ruler.remove();
    ruler = null;
    updateSensoryUI();
    return;
  }
  ruler = document.createElement("div");
  ruler.id = "cp-ruler";
  Object.assign(ruler.style, {
    position: "fixed",
    left: 0,
    width: "100%",
    height: prefs.band + "px",
    background: "rgba(79, 70, 229, 0.2)",
    borderTop: "2px solid #4f46e5",
    borderBottom: "2px solid #4f46e5",
    pointerEvents: "none",
    zIndex: "2147483646", // below the sidebar
    boxSizing: "border-box",
  });
  document.body.appendChild(ruler);
  positionReadingAids();
  updateSensoryUI();
}

// Focus mask: dims the page above and below a clear reading band that follows the mouse
function toggleFocusMask() {
  if (focusMask) {
    focusMask.top.remove();
    focusMask.bottom.remove();
    focusMask = null;
    updateSensoryUI();
    return;
  }
  const make = () => {
    const d = document.createElement("div");
    d.className = "cp-focus-mask";
    document.documentElement.appendChild(d);
    return d;
  };
  focusMask = { top: make(), bottom: make() };
  positionReadingAids();
  updateSensoryUI();
}

function positionReadingAids() {
  const half = prefs.band / 2;
  if (ruler) {
    ruler.style.height = prefs.band + "px";
    ruler.style.top = lastMouseY - half + "px";
  }
  if (focusMask) {
    focusMask.top.style.top = "0px";
    focusMask.top.style.height = Math.max(0, lastMouseY - half) + "px";
    focusMask.bottom.style.top = lastMouseY + half + "px";
    focusMask.bottom.style.bottom = "0px";
  }
}

// Single listener for the reading ruler and focus mask (adding one per toggle leaked listeners)
document.addEventListener("mousemove", (e) => {
  lastMouseY = e.clientY;
  if (ruler || focusMask) positionReadingAids();
});

function applyTint(color, remember = true) {
  if (currentTintOverlay) currentTintOverlay.remove();
  currentTintOverlay = null;
  if (remember) {
    prefs.tint = color;
    savePrefs();
  }
  updateSensoryUI();
  if (color === "none" || !document.body) return;
  currentTintOverlay = document.createElement("div");
  currentTintOverlay.id = "cp-tint-overlay";
  Object.assign(currentTintOverlay.style, {
    position: "fixed",
    top: 0,
    left: 0,
    width: "100vw",
    height: "100vh",
    pointerEvents: "none",
    zIndex: "2147483646",
    backgroundColor: color,
  });
  document.body.appendChild(currentTintOverlay);
}

// --- Read aloud (speechSynthesis, runs locally in the browser) ---
const tts = { active: false, paused: false, queue: [], idx: 0, run: 0, el: null };
let ttsRate = 1;
try {
  chrome.storage.local.get({ cpTtsRate: 1 }, (s) => {
    if (!chrome.runtime.lastError) ttsRate = Number(s.cpTtsRate) || 1;
  });
} catch (err) {
  /* keep default */
}

function cleanSpeechText(text) {
  return text
    .replace(/\[(\d+|[a-z]|edit|citation needed|note \d+)\]/gi, "") // [1], [edit] etc.
    .replace(/\s+/g, " ")
    .trim();
}

// Split long text into sentence-sized chunks (Chrome stops very long utterances)
function chunkText(text) {
  const sentences = text.match(/[^.!?]+[.!?]+["')\]]*\s*|[^.!?]+$/g) || [text];
  const chunks = [];
  let cur = "";
  sentences.forEach((s) => {
    if ((cur + s).length > 220 && cur) {
      chunks.push(cur.trim());
      cur = "";
    }
    cur += s;
  });
  if (cur.trim()) chunks.push(cur.trim());
  return chunks;
}

function collectReadableBlocks() {
  const selection = window.getSelection && window.getSelection().toString().trim();
  if (selection) return [{ el: null, text: cleanSpeechText(selection) }];
  const root = document.querySelector("article, main, [role='main']") || document.body;
  const blocks = [];
  root.querySelectorAll("h1, h2, h3, h4, p, li, blockquote, dd").forEach((el) => {
    if (el.closest("#clearpath-sidebar, nav, footer, aside, [aria-hidden='true'], figure, table, .thumb, .navbox, .reflist, .references"))
      return;
    if (el.querySelector("p, li")) return; // the inner blocks are read instead
    if (!el.offsetParent && getComputedStyle(el).position !== "fixed") return; // hidden
    const text = cleanSpeechText(el.innerText || "");
    if (text.length > 1) blocks.push({ el, text });
  });
  // Start at the first block that is on screen
  const start = blocks.findIndex((b) => b.el.getBoundingClientRect().bottom > 60);
  return start > 0 ? blocks.slice(start) : blocks;
}

function setReadingHighlight(el) {
  if (tts.el) tts.el.classList.remove("cp-tts-current");
  tts.el = el;
  if (!el) return;
  el.classList.add("cp-tts-current");
  const r = el.getBoundingClientRect();
  if (r.top < 0 || r.bottom > window.innerHeight)
    el.scrollIntoView({ block: "center", behavior: "smooth" });
}

function speakNext(run) {
  if (run !== tts.run || !tts.active) return;
  if (tts.idx >= tts.queue.length) {
    stopReading();
    showToast("Finished reading.");
    return;
  }
  const item = tts.queue[tts.idx];
  setReadingHighlight(item.el);
  const u = new SpeechSynthesisUtterance(item.text);
  u.rate = ttsRate;
  if (document.documentElement.lang) u.lang = document.documentElement.lang;
  u.onend = () => {
    if (run !== tts.run) return;
    tts.idx++;
    speakNext(run);
  };
  u.onerror = (e) => {
    if (run !== tts.run || e.error === "interrupted" || e.error === "canceled") return;
    stopReading();
    showToast("Read aloud stopped: " + e.error);
  };
  speechSynthesis.speak(u);
}

function startReading() {
  if (!("speechSynthesis" in window)) {
    showToast("Read aloud is not available in this browser.");
    return;
  }
  const blocks = collectReadableBlocks();
  if (!blocks.length) {
    showToast("No readable text found. Select some text and try again.");
    return;
  }
  speechSynthesis.cancel();
  tts.queue = [];
  blocks.forEach((b) => chunkText(b.text).forEach((text) => tts.queue.push({ el: b.el, text })));
  tts.idx = 0;
  tts.active = true;
  tts.paused = false;
  tts.run++;
  updateReadUI();
  speakNext(tts.run);
}

function stopReading() {
  tts.run++;
  tts.active = false;
  tts.paused = false;
  if ("speechSynthesis" in window) speechSynthesis.cancel();
  setReadingHighlight(null);
  updateReadUI();
}

// Play / pause / resume: the same action for the button and the keyboard shortcut
function toggleReading() {
  if (!tts.active) startReading();
  else if (tts.paused) {
    speechSynthesis.resume();
    tts.paused = false;
  } else {
    speechSynthesis.pause();
    tts.paused = true;
  }
  updateReadUI();
}

function updateReadUI() {
  const btn = document.getElementById("cp-read-btn");
  const stop = document.getElementById("cp-read-stop");
  if (btn) {
    btn.textContent = !tts.active ? "▶ Read Aloud" : tts.paused ? "▶ Resume" : "❚❚ Pause";
    btn.classList.toggle("cp-on", tts.active);
  }
  if (stop) stop.disabled = !tts.active;
}

function makeElementResizable(el) {
  if (el.dataset.cpResizing) return;
  el.dataset.cpResizing = "true";
  el.classList.remove("clearpath-hover-target");
  resizedElements.push({ el, width: el.style.width, maxWidth: el.style.maxWidth });
  if (getComputedStyle(el).position === "static") el.style.position = "relative";
  const handle = document.createElement("div");
  handle.className = "cp-resizer-handle";
  el.appendChild(handle);
  handle.addEventListener("mousedown", (e) => {
    e.preventDefault();
    let startX = e.clientX,
      startWidth = el.offsetWidth;
    const doResize = (m) => {
      // Change the real width so text re-flows (a scale transform only magnified it)
      const newWidth = Math.max(150, startWidth + (m.clientX - startX));
      el.style.setProperty("width", newWidth + "px", "important");
      el.style.setProperty("max-width", "none", "important");
    };
    const stop = () => {
      document.removeEventListener("mousemove", doResize);
      document.removeEventListener("mouseup", stop);
    };
    document.addEventListener("mousemove", doResize);
    document.addEventListener("mouseup", stop);
  });
}

function createSidebar() {
  if (document.getElementById("clearpath-sidebar")) return;
  const sidebar = document.createElement("div");
  sidebar.id = "clearpath-sidebar";
  sidebar.innerHTML = `
    <div class="cp-header"><h3>Zen Pro</h3><button id="cp-close-sidebar" title="Close (Alt+Shift+Q)">×</button></div>
    <div class="cp-tip" id="cp-tip" hidden>
        <b>Welcome to ClearPath</b>
        Click <b>Target &amp; Hide</b>, then click any ad or banner to remove it. Reading settings below are remembered for this site.
        <span class="cp-tip-keys"><kbd>Alt</kbd>+<kbd>Shift</kbd>+<kbd>Q</kbd> opens this panel, <kbd>Alt</kbd>+<kbd>Shift</kbd>+<kbd>S</kbd> reads aloud.</span>
        <button class="cp-btn cp-tip-ok" id="cp-tip-ok">Got it</button>
    </div>
    <div class="cp-section">
        <small>LAYOUT TOOLS</small>
        <button class="cp-btn cp-btn-primary" id="cp-hide-toggle">Target & Hide</button>
        <button class="cp-btn cp-btn-secondary" id="cp-resize-toggle">Target & Resize</button>
        <div class="cp-row">
          <button class="cp-btn" id="cp-undo">Undo Last</button>
          <button class="cp-btn cp-btn-danger" id="cp-revert-all" title="Reset everything ClearPath changed on this site">Revert All</button>
        </div>
    </div>
    <div class="cp-section">
        <small>READ ALOUD</small>
        <div class="cp-row">
          <button class="cp-btn" id="cp-read-btn" title="Reads the selection, or the article from where you are (Alt+Shift+S)">▶ Read Aloud</button>
          <button class="cp-btn cp-btn-narrow" id="cp-read-stop" title="Stop" disabled>■</button>
        </div>
        <label class="cp-flex">Speed
          <select id="cp-read-rate">
            <option value="0.8">0.8×</option><option value="1">1×</option><option value="1.2">1.2×</option>
            <option value="1.4">1.4×</option><option value="1.7">1.7×</option><option value="2">2×</option>
          </select>
        </label>
    </div>
    <div class="cp-section">
        <small>FOCUS &amp; COLOUR</small>
        <div class="cp-row">
          <button class="cp-btn" id="cp-ruler-btn">Reading Ruler</button>
          <button class="cp-btn" id="cp-mask-btn">Focus Mask</button>
        </div>
        <label class="cp-flex">Band <input type="range" id="cp-band" min="20" max="200" step="2" value="34"><span id="cp-band-val">34px</span></label>
        <button class="cp-btn" id="cp-bionic-btn">Bionic Mode</button>
        <div class="cp-tints">
          <button class="cp-tint" data-tint="rgba(255, 230, 0, 0.1)" title="Sepia" style="background:#e9dca4"></button>
          <button class="cp-tint" data-tint="rgba(255, 150, 0, 0.12)" title="Warm amber" style="background:#f2b866"></button>
          <button class="cp-tint" data-tint="rgba(80, 150, 255, 0.1)" title="Soft blue" style="background:#9cc2f5"></button>
          <button class="cp-tint" data-tint="rgba(120, 220, 140, 0.1)" title="Soft green" style="background:#a7dfb2"></button>
          <button class="cp-tint" data-tint="rgba(0, 0, 0, 0.25)" title="Dim" style="background:#555"></button>
        </div>
    </div>
    <div class="cp-section">
        <small>TYPOGRAPHY</small>
        <label class="cp-flex">Font
          <select id="cp-font-family">
            <option value="page">Page font</option>
            <option value="dyslexic">OpenDyslexic</option>
            <option value="sans">Readable sans</option>
            <option value="serif">Book serif</option>
          </select>
        </label>
        <label class="cp-flex">Size <input type="range" id="cp-font-size" min="0" max="32" step="1" value="0"><span id="cp-font-size-val">page</span></label>
        <label class="cp-flex">Spacing <input type="range" id="cp-line-height" min="0" max="2.6" step="0.1" value="0"><span id="cp-line-height-val">page</span></label>
        <label class="cp-flex">Letters <input type="range" id="cp-letter-spacing" min="0" max="0.2" step="0.01" value="0"><span id="cp-letter-spacing-val">page</span></label>
        <button class="cp-btn" id="cp-clear-btn">Clear All Filters</button>
        <div class="cp-note">Saved for <span id="cp-site"></span></div>
    </div>`;
  document.body.appendChild(sidebar);
  document.getElementById("cp-site").textContent = window.location.hostname || "this page";

  document.getElementById("cp-hide-toggle").onclick = () => {
    isResizeModeActive = false;
    isHideModeActive = !isHideModeActive;
    updateButtonUI();
  };
  document.getElementById("cp-resize-toggle").onclick = () => {
    isHideModeActive = false;
    isResizeModeActive = !isResizeModeActive;
    updateButtonUI();
  };
  document.getElementById("cp-revert-all").onclick = revertAllChanges;
  document.getElementById("cp-close-sidebar").onclick = closeSidebar;
  document.getElementById("cp-undo").onclick = undoLastHide;
  document.getElementById("cp-bionic-btn").onclick = toggleBionic;
  document.getElementById("cp-ruler-btn").onclick = toggleRuler;
  document.getElementById("cp-mask-btn").onclick = toggleFocusMask;
  document.getElementById("cp-read-btn").onclick = toggleReading;
  document.getElementById("cp-read-stop").onclick = stopReading;
  const rateSel = document.getElementById("cp-read-rate");
  rateSel.value = String(ttsRate);
  rateSel.onchange = () => {
    ttsRate = Number(rateSel.value) || 1;
    chrome.storage.local.set({ cpTtsRate: ttsRate });
    // Apply the new speed from the current sentence on
    if (tts.active && !tts.paused) {
      tts.run++;
      speechSynthesis.cancel();
      speakNext(tts.run);
    }
  };
  sidebar.querySelectorAll(".cp-tint").forEach((btn) => {
    // Clicking the active tint again turns it off
    btn.onclick = () => applyTint(prefs.tint === btn.dataset.tint ? "none" : btn.dataset.tint);
  });

  const onTypography = () => {
    const fs = Number(document.getElementById("cp-font-size").value);
    const lh = Number(document.getElementById("cp-line-height").value);
    prefs.fontSize = fs < 10 ? 0 : fs;
    prefs.lineHeight = lh < 1 ? 0 : lh;
    prefs.letterSpacing = Number(document.getElementById("cp-letter-spacing").value) || 0;
    prefs.font = document.getElementById("cp-font-family").value;
    prefs.band = Number(document.getElementById("cp-band").value) || 34;
    syncTypographyControls();
    applyReadingStyles();
    positionReadingAids();
    savePrefs();
  };
  ["cp-font-size", "cp-line-height", "cp-letter-spacing", "cp-band"].forEach((id) => {
    document.getElementById(id).oninput = onTypography;
  });
  document.getElementById("cp-font-family").onchange = onTypography;

  document.getElementById("cp-clear-btn").onclick = () => {
    document.documentElement.style.filter = "";
    prefs = { ...DEFAULT_PREFS };
    applyTint("none");
    applyReadingStyles();
    syncTypographyControls();
    savePrefs();
    if (isBionicActive) removeBionic();
    if (ruler) toggleRuler();
    if (focusMask) toggleFocusMask();
  };

  syncTypographyControls();
  updateReadUI();

  // First-run hint
  try {
    chrome.storage.local.get({ cpOnboarded: false }, (s) => {
      if (chrome.runtime.lastError || s.cpOnboarded) return;
      const tip = document.getElementById("cp-tip");
      tip.hidden = false;
      document.getElementById("cp-tip-ok").onclick = () => {
        tip.hidden = true;
        chrome.storage.local.set({ cpOnboarded: true });
      };
    });
  } catch (err) {
    /* ignore */
  }
}

function openSidebar() {
  createSidebar();
  document.getElementById("clearpath-sidebar").style.setProperty("display", "flex", "important");
}

function closeSidebar() {
  const sidebar = document.getElementById("clearpath-sidebar");
  if (sidebar) sidebar.style.setProperty("display", "none", "important");
  isHideModeActive = false;
  isResizeModeActive = false;
  updateButtonUI();
}

function isSidebarOpen() {
  const sidebar = document.getElementById("clearpath-sidebar");
  return !!sidebar && sidebar.style.display !== "none";
}

document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") {
    isHideModeActive = false;
    isResizeModeActive = false;
    updateButtonUI();
  }
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === "openSidebar") openSidebar();
  else if (msg.action === "toggleSidebar") isSidebarOpen() ? closeSidebar() : openSidebar();
  else if (msg.action === "toggleReadAloud") toggleReading();
  else return;
  // Reply so the sender knows the content script is present (no reply = "port closed" error)
  sendResponse({ ok: true });
});

async function applyPersistentHides() {
  const domain = window.location.hostname;
  const data = await chrome.storage.local.get(domain);
  const hiddenSelectors = data[domain] || [];
  hiddenSelectors.forEach((s) => {
    try {
      const el = document.querySelector(s);
      if (el) el.style.setProperty("display", "none", "important");
    } catch (err) {
      /* invalid selector */
    }
  });
}

applyPersistentHides();
loadPrefs();
// Debounced: reading storage on every single DOM mutation is very expensive on dynamic pages
let cpPersistTimer = null;
const observer = new MutationObserver(() => {
  if (cpPersistTimer) return;
  cpPersistTimer = setTimeout(() => {
    cpPersistTimer = null;
    applyPersistentHides();
  }, 300);
});
if (document.body)
  observer.observe(document.body, { childList: true, subtree: true });
// Stop speaking when the page is left
window.addEventListener("pagehide", () => {
  if (tts.active) speechSynthesis.cancel();
});
