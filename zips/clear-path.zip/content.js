// ClearPath Zen Pro content script.
// Wrapped in a function so it can be injected again (popup / shortcut) without
// "Identifier has already been declared" errors, and so an orphaned copy left
// behind by an extension update can hand over to the new one.
(() => {
  const isAlive = () => {
    try {
      return !!(chrome.runtime && chrome.runtime.id);
    } catch (err) {
      return false;
    }
  };

  const previous = window.__clearPathZen;
  if (previous && previous.alive()) return; // already running in this tab
  if (previous) previous.teardown(); // orphan from before an extension update
  // Orphans living in another isolated world tear themselves down on this event
  document.dispatchEvent(new CustomEvent("clearpath:init"));
  // Leftovers from 1.3.x, which kept its UI in the page's light DOM
  document
    .querySelectorAll("#clearpath-sidebar, #cp-toast, #cp-tint-overlay, #cp-ruler, .cp-focus-mask, style#cp-dynamic-styles, clearpath-ui")
    .forEach((el) => el.remove());

  // ---------------------------------------------------------------------------
  // State
  // ---------------------------------------------------------------------------
  let isHideModeActive = false;
  let isResizeModeActive = false;
  let hoverTarget = null;
  let lastMouseY = window.innerHeight / 2;
  let resizedElements = [];
  let hiddenSelectors = []; // persisted per site, newest last
  let tornDown = false;
  const cleanups = [];

  // Hidden elements and reading settings are stored per site. Local files share one key.
  const SITE = location.hostname || (location.protocol === "file:" ? "file://" : location.origin);
  const PREFS_KEY = "cpPrefs:" + SITE;
  const MAX_HIDDEN = 300;
  const DEFAULT_PREFS = {
    tint: "none",
    fontSize: 0,
    lineHeight: 0,
    letterSpacing: 0,
    font: "page",
    band: 34,
    bionic: false,
  };
  let prefs = { ...DEFAULT_PREFS };
  let prefsSaveTimer = null;

  const FONT_STACKS = {
    dyslexic: "'OpenDyslexic', Verdana, sans-serif",
    sans: "Verdana, 'Segoe UI', Tahoma, Arial, sans-serif",
    serif: "Georgia, 'Iowan Old Style', 'Times New Roman', serif",
  };

  // Text blocks that reading styles and Bionic Mode apply to
  const TEXT_BLOCKS = "p, li, dd, dt, blockquote, td, th, h1, h2, h3, h4, h5, h6, figcaption, caption";
  // Never restyle or rewrite these: menus and toolbars (fixed-size layouts), editable areas, code
  const NO_TOUCH =
    "nav, [role=navigation], [role=menu], [role=menubar], [role=toolbar], [role=tablist], [contenteditable]:not([contenteditable=false]), textarea, pre, code, kbd, samp, svg, math";

  // ---------------------------------------------------------------------------
  // Small helpers
  // ---------------------------------------------------------------------------
  function on(target, type, fn, opts) {
    const handler = (e) => {
      if (!isAlive()) return teardown();
      fn(e);
    };
    target.addEventListener(type, handler, opts);
    cleanups.push(() => target.removeEventListener(type, handler, opts));
  }

  // Storage calls that never throw (the extension may have been reloaded under us)
  const store = {
    async get(keys) {
      try {
        return (await chrome.storage.local.get(keys)) || {};
      } catch (err) {
        return {};
      }
    },
    async set(obj) {
      try {
        await chrome.storage.local.set(obj);
      } catch (err) {
        /* extension reloaded */
      }
    },
    async remove(keys) {
      try {
        await chrome.storage.local.remove(keys);
      } catch (err) {
        /* extension reloaded */
      }
    },
  };

  // In a private window, per-site data is not written (the site names would end up in
  // normal-profile storage). Saved settings from normal windows still apply.
  let incognitoPromise = null;
  function isIncognito() {
    if (!incognitoPromise) {
      incognitoPromise = chrome.runtime
        .sendMessage({ action: "cpContext" })
        .then((r) => !!(r && r.incognito))
        .catch(() => false);
    }
    return incognitoPromise;
  }
  let incognitoNoticeShown = false;
  async function canSaveSiteData() {
    if (!(await isIncognito())) return true;
    if (!incognitoNoticeShown) {
      incognitoNoticeShown = true;
      showToast("Private window: changes on this site are not saved.");
    }
    return false;
  }

  // ---------------------------------------------------------------------------
  // Page stylesheet: hidden elements + reading typography
  // ---------------------------------------------------------------------------
  const cpStyleTag = document.createElement("style");
  cpStyleTag.id = "cp-dynamic-styles";
  let readingCss = "";

  function renderPageStyles() {
    const valid = hiddenSelectors.filter((s) => {
      if (typeof s !== "string" || /[{}]/.test(s)) return false;
      try {
        document.createDocumentFragment().querySelector(s);
        return true;
      } catch (err) {
        return false;
      }
    });
    const hideCss = valid.map((s) => `${s} { display: none !important; }`).join("\n");
    cpStyleTag.textContent = hideCss + "\n" + readingCss;
    if (!cpStyleTag.isConnected) (document.head || document.documentElement).appendChild(cpStyleTag);
  }

  // Builds the page-wide reading CSS from `prefs` (0 / "page" = leave the page's own value)
  function applyReadingStyles() {
    const css = [];
    const text = [];
    if (prefs.fontSize > 0) text.push(`font-size: ${prefs.fontSize}px !important;`);
    if (prefs.lineHeight > 0) text.push(`line-height: ${prefs.lineHeight} !important;`);
    if (prefs.letterSpacing > 0) text.push(`letter-spacing: ${prefs.letterSpacing}em !important;`);
    const keep = `:not(${NO_TOUCH.split(", ").map((s) => s + ", " + s + " *").join(", ")})`;
    if (text.length) css.push(`:is(p, li, dd, blockquote)${keep} { ${text.join(" ")} }`);
    if (prefs.font !== "page" && FONT_STACKS[prefs.font]) {
      if (prefs.font === "dyslexic") {
        const reg = chrome.runtime.getURL("fonts/OpenDyslexic-Regular.woff2");
        const bold = chrome.runtime.getURL("fonts/OpenDyslexic-Bold.woff2");
        css.push(`@font-face { font-family: 'OpenDyslexic'; src: url('${reg}') format('woff2'); font-weight: 400; font-display: swap; }`);
        css.push(`@font-face { font-family: 'OpenDyslexic'; src: url('${bold}') format('woff2'); font-weight: 700; font-display: swap; }`);
      }
      // Text blocks and their inline children; icon tags (<i>) are left alone so icon fonts keep working
      const blocks = `:is(${TEXT_BLOCKS})${keep}`;
      css.push(
        `${blocks}, ${blocks} :is(a, span, em, strong, b, cite, q, small, abbr, mark)${keep} { font-family: ${FONT_STACKS[prefs.font]} !important; }`,
      );
    }
    readingCss = css.join("\n");
    renderPageStyles();
  }

  // ---------------------------------------------------------------------------
  // UI: everything ClearPath draws lives in one closed shadow root, so page CSS cannot
  // restyle it and page scripts cannot read or click it.
  // ---------------------------------------------------------------------------
  const PANEL_CSS = `
:host { all: initial !important; }
* { box-sizing: border-box; }
[hidden] { display: none !important; }
.layer > div { position: fixed; left: 0; right: 0; pointer-events: none; }
.tint { top: 0; bottom: 0; }
.mask { background: rgba(15, 23, 42, 0.62); }
.ruler { background: rgba(79, 70, 229, 0.2); border-top: 2px solid #4f46e5; border-bottom: 2px solid #4f46e5; }
.panel {
  position: fixed; top: 0; right: 0; width: 280px; height: 100vh; overflow-y: auto; overscroll-behavior: contain;
  background: #1a1a1a; color: #fff; padding: 16px 20px 20px; pointer-events: auto;
  font: 13px/1.4 system-ui, "Segoe UI", Roboto, sans-serif; text-align: left;
  box-shadow: -8px 0 24px rgba(0, 0, 0, 0.25); color-scheme: dark;
}
.header { display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #333; margin-bottom: 15px; padding-bottom: 6px; }
h2 { margin: 0; font-size: 16px; color: #a5b4fc; font-weight: 700; }
h2:focus { outline: none; }
.panel.left { right: auto; left: 0; box-shadow: 8px 0 24px rgba(0, 0, 0, 0.25); }
.head-btns { display: flex; gap: 2px; }
.dock { background: none; border: none; color: #aaa; font-size: 15px; line-height: 1; cursor: pointer; padding: 4px 6px; border-radius: 4px; }
.dock:hover { color: #fff; }
.close { background: none; border: none; color: #aaa; font-size: 22px; line-height: 1; cursor: pointer; padding: 2px 6px; border-radius: 4px; }
.close:hover { color: #fff; }
.section { margin-bottom: 18px; }
.section > h3 { color: #9a9a9a; font-weight: 700; margin: 0 0 8px; font-size: 10px; letter-spacing: 1px; }
.btn {
  display: block; width: 100%; background: #2d2d2d; border: 1px solid #444; color: #fff; padding: 8px; margin: 0 0 6px;
  border-radius: 4px; cursor: pointer; font: inherit; text-align: left; transition: background 0.2s, border-color 0.2s;
}
.btn:hover { background: #3d3d3d; border-color: #6366f1; }
.btn:disabled { opacity: 0.45; cursor: default; }
.btn-primary { background: #4f46e5; border-color: #4f46e5; font-weight: 700; text-align: center; }
.btn-primary:hover { background: #4338ca; }
.btn-secondary { background: #047857; border-color: #047857; font-weight: 600; text-align: center; }
.btn-secondary:hover { background: #065f46; }
.btn.armed { background: #b91c1c; border-color: #ef4444; }
.btn-danger { background: #3a1f22; border-color: #7f1d1d; color: #fecaca; text-align: center; }
.btn-danger:hover, .btn-danger.confirm { background: #7f1d1d; border-color: #ef4444; color: #fff; }
.btn.on { background: #312e81; border-color: #818cf8; }
.row { display: flex; gap: 6px; }
.row .btn { flex: 1; width: auto; }
.row .narrow { flex: 0 0 36px; text-align: center; padding: 8px 0; }
.row .read { text-align: center; white-space: nowrap; }
.flex { display: flex; align-items: center; gap: 10px; margin-bottom: 10px; color: #ddd; font-size: 12px; }
.flex > span:first-child { min-width: 48px; }
.flex output { min-width: 40px; text-align: right; color: #bbb; }
input[type="range"] { flex: 1; min-width: 0; accent-color: #6366f1; margin: 0; }
select { flex: 1; min-width: 0; background: #2d2d2d; color: #fff; border: 1px solid #444; border-radius: 4px; padding: 4px 6px; font: 12px system-ui, sans-serif; }
.tints { display: flex; gap: 6px; margin: 4px 0 8px; }
.tint-btn { width: 32px; height: 24px; border: 1px solid #555; border-radius: 4px; cursor: pointer; padding: 0; }
.tint-btn:hover { border-color: #818cf8; }
.tint-btn[aria-pressed="true"] { outline: 2px solid #a5b4fc; outline-offset: 2px; }
.note { font-size: 11px; color: #9a9a9a; margin-top: 2px; }
.note b { color: #ccc; font-weight: 600; }
.progress { font-size: 11px; color: #9a9a9a; margin: -2px 0 8px; }
.progress:empty { display: none; }
.tip { background: #1e1b4b; border: 1px solid #4f46e5; border-radius: 8px; padding: 10px 12px; margin-bottom: 16px; font-size: 12px; line-height: 1.5; color: #e0e7ff; }
.tip > b:first-child { display: block; margin-bottom: 4px; font-size: 13px; }
.tip-keys { display: block; margin-top: 6px; color: #c7d2fe; }
kbd { background: #312e81; border: 1px solid #4f46e5; border-radius: 3px; padding: 0 4px; font: 11px ui-monospace, monospace; color: #fff; }
.tip .btn { margin: 8px 0 0; text-align: center; background: #4f46e5; border: none; }
button:focus-visible, select:focus-visible, input:focus-visible { outline: 2px solid #a5b4fc; outline-offset: 2px; }
.toast {
  position: fixed; left: 50%; bottom: 24px; transform: translate(-50%, 20px); max-width: min(480px, calc(100vw - 32px));
  background: #1a1a1a; color: #fff; font: 13px/1.4 system-ui, "Segoe UI", sans-serif; padding: 10px 16px; border-radius: 8px;
  border-left: 3px solid #6366f1; box-shadow: 0 8px 24px rgba(0, 0, 0, 0.35); opacity: 0; pointer-events: none;
  transition: opacity 0.2s, transform 0.2s;
}
.toast.show { opacity: 1; transform: translate(-50%, 0); }
@media (prefers-reduced-motion: reduce) { .toast, .btn { transition: none; } }
`;

  const PANEL_HTML = `
<div class="header"><h2 id="cp-title" tabindex="-1">Zen Pro</h2><div class="head-btns"><button class="dock" id="cp-dock" aria-label="Move panel to the other side" title="Move panel to the other side">⇆</button><button class="close" id="cp-close" aria-label="Close panel" title="Close (Alt+Shift+Q)">×</button></div></div>
<div class="tip" id="cp-tip" hidden>
  <b>Welcome to ClearPath</b>
  Click <b>Target &amp; Hide</b>, then click any ad or banner to remove it. Reading settings below are remembered for this site.
  <span class="tip-keys"><kbd>Alt</kbd>+<kbd>Shift</kbd>+<kbd>Q</kbd> opens this panel, <kbd>Alt</kbd>+<kbd>Shift</kbd>+<kbd>S</kbd> reads aloud.</span>
  <button class="btn" id="cp-tip-ok">Got it</button>
</div>
<section class="section" aria-labelledby="cp-h-layout">
  <h3 id="cp-h-layout">LAYOUT TOOLS</h3>
  <button class="btn btn-primary" id="cp-hide-toggle" aria-pressed="false">Target &amp; Hide</button>
  <button class="btn btn-secondary" id="cp-resize-toggle" aria-pressed="false">Target &amp; Resize</button>
  <div class="row">
    <button class="btn" id="cp-undo" title="Bring back the last element you hid on this site">Undo Last</button>
    <button class="btn btn-danger" id="cp-revert-all" title="Reset everything ClearPath changed on this site">Revert All</button>
  </div>
  <div class="note" id="cp-hidden-count" aria-live="polite"></div>
</section>
<section class="section" aria-labelledby="cp-h-read">
  <h3 id="cp-h-read">READ ALOUD</h3>
  <div class="row">
    <button class="btn narrow" id="cp-read-prev" aria-label="Previous paragraph" title="Previous paragraph" disabled>⏮</button>
    <button class="btn read" id="cp-read-btn" title="Reads the selection, or the article from where you are (Alt+Shift+S)">▶ Read</button>
    <button class="btn narrow" id="cp-read-next" aria-label="Next paragraph" title="Next paragraph" disabled>⏭</button>
    <button class="btn narrow" id="cp-read-stop" aria-label="Stop reading" title="Stop" disabled>■</button>
  </div>
  <div class="progress" id="cp-read-progress" aria-live="polite"></div>
  <label class="flex"><span>Voice</span><select id="cp-read-voice"><option value="">Browser default</option></select></label>
  <label class="flex"><span>Speed</span>
    <select id="cp-read-rate">
      <option value="0.8">0.8×</option><option value="1">1×</option><option value="1.2">1.2×</option>
      <option value="1.4">1.4×</option><option value="1.7">1.7×</option><option value="2">2×</option>
    </select>
  </label>
</section>
<section class="section" aria-labelledby="cp-h-focus">
  <h3 id="cp-h-focus">FOCUS &amp; COLOUR</h3>
  <div class="row">
    <button class="btn" id="cp-ruler-btn" aria-pressed="false">Reading Ruler</button>
    <button class="btn" id="cp-mask-btn" aria-pressed="false">Focus Mask</button>
  </div>
  <label class="flex"><span>Band</span><input type="range" id="cp-band" min="20" max="200" step="2" value="34"><output id="cp-band-val">34px</output></label>
  <button class="btn" id="cp-bionic-btn" aria-pressed="false">Bionic Mode</button>
  <div class="tints" role="group" aria-label="Colour tint">
    <button class="tint-btn" data-tint="rgba(255, 230, 0, 0.1)" aria-label="Sepia tint" title="Sepia" style="background:#e9dca4"></button>
    <button class="tint-btn" data-tint="rgba(255, 150, 0, 0.12)" aria-label="Warm amber tint" title="Warm amber" style="background:#f2b866"></button>
    <button class="tint-btn" data-tint="rgba(80, 150, 255, 0.1)" aria-label="Soft blue tint" title="Soft blue" style="background:#9cc2f5"></button>
    <button class="tint-btn" data-tint="rgba(120, 220, 140, 0.1)" aria-label="Soft green tint" title="Soft green" style="background:#a7dfb2"></button>
    <button class="tint-btn" data-tint="rgba(0, 0, 0, 0.25)" aria-label="Dim" title="Dim" style="background:#555"></button>
  </div>
</section>
<section class="section" aria-labelledby="cp-h-type">
  <h3 id="cp-h-type">TYPOGRAPHY</h3>
  <label class="flex"><span>Font</span>
    <select id="cp-font-family">
      <option value="page">Page font</option>
      <option value="dyslexic">OpenDyslexic</option>
      <option value="sans">Readable sans</option>
      <option value="serif">Book serif</option>
    </select>
  </label>
  <label class="flex"><span>Size</span><input type="range" id="cp-font-size" min="0" max="32" step="1" value="0"><output id="cp-font-size-val">page</output></label>
  <label class="flex"><span>Spacing</span><input type="range" id="cp-line-height" min="0" max="2.6" step="0.1" value="0"><output id="cp-line-height-val">page</output></label>
  <label class="flex"><span>Letters</span><input type="range" id="cp-letter-spacing" min="0" max="0.2" step="0.01" value="0"><output id="cp-letter-spacing-val">page</output></label>
  <button class="btn" id="cp-clear-btn">Clear All Filters</button>
  <div class="note">Saved for <b id="cp-site"></b></div>
</section>`;

  let host = null;
  let shadow = null;
  let panel = null;
  const ui = {}; // overlay elements inside the shadow root
  const $ = (id) => (shadow ? shadow.getElementById(id) : null);

  function ensureUI() {
    if (!host) {
      host = document.createElement("clearpath-ui");
      host.style.cssText =
        "all: initial !important; position: fixed !important; inset: 0 !important; width: 0 !important; height: 0 !important; z-index: 2147483647 !important; pointer-events: none !important; display: block !important;";
      shadow = host.attachShadow({ mode: "closed" });
      const sheet = new CSSStyleSheet();
      sheet.replaceSync(PANEL_CSS);
      shadow.adoptedStyleSheets = [sheet];
      const layer = document.createElement("div");
      layer.className = "layer";
      ["tint", "maskTop", "maskBottom", "ruler"].forEach((name) => {
        const d = document.createElement("div");
        d.className = name === "maskTop" || name === "maskBottom" ? "mask" : name;
        d.hidden = true;
        layer.appendChild(d);
        ui[name] = d;
      });
      ui.toast = document.createElement("div");
      ui.toast.className = "toast";
      ui.toast.setAttribute("role", "status");
      shadow.append(layer, ui.toast);
    }
    if (!host.isConnected) document.documentElement.appendChild(host);
  }

  // Small message at the bottom of the page (replaces blocking alert() dialogs)
  let toastTimer = null;
  function showToast(text) {
    ensureUI();
    ui.toast.textContent = text;
    ui.toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => ui.toast.classList.remove("show"), 2800);
  }

  function setPressed(id, onState) {
    const el = $(id);
    if (!el) return;
    el.classList.toggle("on", onState);
    el.setAttribute("aria-pressed", String(onState));
  }

  function updateButtonUI() {
    const hideBtn = $("cp-hide-toggle");
    const resizeBtn = $("cp-resize-toggle");
    if (hideBtn) {
      hideBtn.textContent = isHideModeActive ? "HIDING: click an element (Esc)" : "Target & Hide";
      hideBtn.classList.toggle("armed", isHideModeActive);
      hideBtn.setAttribute("aria-pressed", String(isHideModeActive));
    }
    if (resizeBtn) {
      resizeBtn.textContent = isResizeModeActive ? "RESIZE: click a container (Esc)" : "Target & Resize";
      resizeBtn.classList.toggle("armed", isResizeModeActive);
      resizeBtn.setAttribute("aria-pressed", String(isResizeModeActive));
    }
    if (!isHideModeActive && !isResizeModeActive) clearHoverTarget();
    const count = $("cp-hidden-count");
    if (count) {
      count.textContent = hiddenSelectors.length
        ? `${hiddenSelectors.length} element${hiddenSelectors.length === 1 ? "" : "s"} hidden on this site`
        : "";
    }
  }

  // Mark the ruler / focus mask / tint / bionic buttons that are currently on
  function updateSensoryUI() {
    setPressed("cp-ruler-btn", !!rulerOn);
    setPressed("cp-mask-btn", !!maskOn);
    setPressed("cp-bionic-btn", bionic.active);
    const bionicBtn = $("cp-bionic-btn");
    if (bionicBtn) bionicBtn.textContent = bionic.active ? "Bionic Mode: ON" : "Bionic Mode";
    if (shadow) {
      shadow.querySelectorAll(".tint-btn").forEach((b) => {
        b.setAttribute("aria-pressed", String(b.dataset.tint === prefs.tint));
      });
    }
  }

  // ---------------------------------------------------------------------------
  // Per-site reading settings
  // ---------------------------------------------------------------------------
  function savePrefs() {
    clearTimeout(prefsSaveTimer);
    prefsSaveTimer = setTimeout(async () => {
      if (!(await canSaveSiteData())) return;
      const isDefault = Object.keys(DEFAULT_PREFS).every((k) => prefs[k] === DEFAULT_PREFS[k]);
      if (isDefault) store.remove(PREFS_KEY);
      else store.set({ [PREFS_KEY]: prefs });
    }, 250);
  }

  async function saveHidden() {
    if (!(await canSaveSiteData())) return;
    if (hiddenSelectors.length) await store.set({ [SITE]: hiddenSelectors });
    else await store.remove(SITE);
  }

  async function loadSiteData() {
    const data = await store.get([SITE, PREFS_KEY]);
    if (tornDown) return;
    if (Array.isArray(data[SITE])) hiddenSelectors = data[SITE].filter((s) => typeof s === "string");
    if (data[PREFS_KEY] && typeof data[PREFS_KEY] === "object") prefs = { ...DEFAULT_PREFS, ...data[PREFS_KEY] };
    applyReadingStyles(); // also renders the hidden-element rules
    if (prefs.tint !== "none") applyTint(prefs.tint, false);
    if (prefs.bionic) bionic.apply();
    syncTypographyControls();
    updateButtonUI();
  }

  // ---------------------------------------------------------------------------
  // Target & Hide / Resize
  // ---------------------------------------------------------------------------
  const isOwnUI = (e) => !!host && e.composedPath().includes(host);
  const isPageRoot = (el) => !el || el === document.documentElement || el === document.body || el === document.head;

  function clearHoverTarget() {
    if (hoverTarget) hoverTarget.classList.remove("clearpath-hover-target");
    hoverTarget = null;
  }

  function onMouseOver(e) {
    if (!(isHideModeActive || isResizeModeActive) || isOwnUI(e)) return;
    const el = e.target;
    if (!(el instanceof Element) || isPageRoot(el)) return;
    clearHoverTarget();
    hoverTarget = el;
    el.classList.add("clearpath-hover-target");
  }

  // While targeting, swallow the whole press so the page does not react (menus, links, drag)
  function onTargetPointer(e) {
    if (!(isHideModeActive || isResizeModeActive) || isOwnUI(e)) return;
    if (e.target && e.target.classList && e.target.classList.contains("cp-resizer-handle")) return;
    e.preventDefault();
    e.stopPropagation();
  }

  function onTargetClick(e) {
    if (!(isHideModeActive || isResizeModeActive) || isOwnUI(e)) return;
    if (e.target && e.target.classList && e.target.classList.contains("cp-resizer-handle")) return;
    e.preventDefault();
    e.stopPropagation();
    const el = e.target instanceof Element ? e.target : null;
    if (isPageRoot(el)) {
      showToast("That is the whole page. Point at a smaller element.");
      return;
    }
    if (isHideModeActive) hideElement(el);
    else makeElementResizable(el);
  }

  // Generated ids (React ":r1:", "ember123", hashes) change between visits, so they make bad anchors
  function isStableId(id) {
    return !!id && id.length < 64 && !/\d{3,}|^[:_\d]|[0-9a-f]{8,}/i.test(id);
  }

  // Path from the nearest element with a stable, unique id (or from <html>)
  function getUniqueSelector(el) {
    const parts = [];
    while (el && el.parentElement && el !== document.documentElement) {
      if (isStableId(el.id)) {
        const idSel = "#" + CSS.escape(el.id);
        if (document.querySelectorAll(idSel).length === 1) {
          parts.unshift(idSel);
          return parts.join(" > ");
        }
      }
      const index = Array.prototype.indexOf.call(el.parentElement.children, el) + 1;
      parts.unshift(`${CSS.escape(el.localName)}:nth-child(${index})`);
      el = el.parentElement;
    }
    return parts.join(" > ");
  }

  function hideElement(el) {
    const selector = getUniqueSelector(el);
    clearHoverTarget();
    if (!selector) return;
    if (!hiddenSelectors.includes(selector)) {
      hiddenSelectors.push(selector);
      if (hiddenSelectors.length > MAX_HIDDEN) hiddenSelectors.shift();
    }
    renderPageStyles();
    saveHidden();
    updateButtonUI();
  }

  // Works across reloads: the hidden list is the undo stack
  function undoLastHide() {
    if (!hiddenSelectors.length) {
      showToast("Nothing to undo yet.");
      return;
    }
    hiddenSelectors.pop();
    renderPageStyles();
    saveHidden();
    updateButtonUI();
    showToast("Restored the last hidden element.");
  }

  function makeElementResizable(el) {
    if (el.dataset.cpResizing) return;
    el.dataset.cpResizing = "true";
    clearHoverTarget();
    resizedElements.push({
      el,
      width: el.style.getPropertyValue("width"),
      widthPriority: el.style.getPropertyPriority("width"),
      maxWidth: el.style.getPropertyValue("max-width"),
      maxWidthPriority: el.style.getPropertyPriority("max-width"),
      position: el.style.position,
    });
    if (getComputedStyle(el).position === "static") el.style.position = "relative";
    const handle = document.createElement("div");
    handle.className = "cp-resizer-handle";
    handle.title = "Drag to resize";
    el.appendChild(handle);
    handle.addEventListener("mousedown", (e) => {
      e.preventDefault();
      e.stopPropagation();
      const startX = e.clientX;
      const startWidth = el.offsetWidth;
      const doResize = (m) => {
        // Change the real width so text re-flows (a scale transform only magnified it)
        const newWidth = Math.max(150, startWidth + (m.clientX - startX));
        el.style.setProperty("width", newWidth + "px", "important");
        el.style.setProperty("max-width", "none", "important");
      };
      const stop = () => {
        document.removeEventListener("mousemove", doResize);
        document.removeEventListener("mouseup", stop);
      };
      document.addEventListener("mousemove", doResize);
      document.addEventListener("mouseup", stop);
    });
    showToast("Drag the round handle in the bottom-right corner to resize.");
  }

  function restoreResized() {
    resizedElements.forEach(({ el, width, widthPriority, maxWidth, maxWidthPriority, position }) => {
      el.style.setProperty("width", width, widthPriority);
      el.style.setProperty("max-width", maxWidth, maxWidthPriority);
      el.style.position = position;
      delete el.dataset.cpResizing;
      el.querySelectorAll(":scope > .cp-resizer-handle").forEach((h) => h.remove());
    });
    resizedElements = [];
  }

  // ---------------------------------------------------------------------------
  // Bionic Mode
  // Each text node stays in the page (emptied) with the bold version right after it.
  // Frameworks such as React keep working on "their" text node: if they change it,
  // the bold copy is rebuilt; if they remove it, the copy goes too.
  // ---------------------------------------------------------------------------
  const bionic = {
    active: false,
    copies: new Map(), // original text node -> { span, text }
    observer: null,
    pending: new Set(),
    timer: null,
    busy: false,

    accept(node) {
      const parent = node.parentElement;
      if (!parent || !node.data.trim()) return false;
      if (parent.closest(".cp-bionic") || parent.isContentEditable) return false;
      if (!parent.closest(TEXT_BLOCKS)) return false;
      if (parent.closest(NO_TOUCH + ", script, style, noscript, select, option, button, [aria-hidden=true]")) return false;
      return true;
    },

    build(text) {
      const span = document.createElement("span");
      span.className = "cp-bionic";
      text.split(/(\s+)/).forEach((word) => {
        if (!word) return;
        if (/^\s+$/.test(word)) {
          span.append(word);
          return;
        }
        const chars = Array.from(word); // keeps emoji and other surrogate pairs whole
        const mid = chars.length <= 3 ? chars.length : Math.ceil(chars.length / 2);
        const b = document.createElement("b");
        b.textContent = chars.slice(0, mid).join("");
        span.append(b);
        if (mid < chars.length) span.append(chars.slice(mid).join(""));
      });
      return span;
    },

    convert(node) {
      if (this.copies.has(node) || !this.accept(node)) return;
      const text = node.data;
      const span = this.build(text);
      node.after(span);
      node.data = "";
      this.copies.set(node, { span, text });
    },

    convertWithin(root) {
      if (root.nodeType === Node.TEXT_NODE) {
        this.convert(root);
        return;
      }
      if (root.nodeType !== Node.ELEMENT_NODE) return;
      const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
      const nodes = [];
      let n;
      while ((n = walker.nextNode())) nodes.push(n); // collect first, then change the DOM
      nodes.forEach((t) => this.convert(t));
    },

    apply() {
      if (this.active || !document.body) return;
      this.active = true;
      this.busy = true;
      this.convertWithin(document.body);
      this.busy = false;
      this.observer = new MutationObserver((records) => this.onMutations(records));
      this.observer.observe(document.body, { childList: true, subtree: true, characterData: true });
      updateSensoryUI();
    },

    onMutations(records) {
      if (this.busy) return;
      for (const r of records) {
        if (r.type === "characterData") {
          const copy = this.copies.get(r.target);
          if (copy && r.target.data !== "") this.pending.add(r.target);
        } else {
          r.removedNodes.forEach((n) => {
            if (n.nodeType === Node.TEXT_NODE && this.copies.has(n) && !n.isConnected) {
              this.copies.get(n).span.remove();
              this.copies.delete(n);
            }
          });
          r.addedNodes.forEach((n) => {
            if (!(n instanceof Element && n.classList.contains("cp-bionic"))) this.pending.add(n);
          });
        }
      }
      if (this.pending.size && !this.timer) this.timer = setTimeout(() => this.flush(), 200);
    },

    flush() {
      this.timer = null;
      if (!this.active) return;
      this.busy = true;
      this.pending.forEach((n) => {
        if (!n.isConnected) return;
        const copy = this.copies.get(n);
        if (copy) {
          if (n.data === "") return; // only moved; the sweep below re-places its copy
          // The page changed the text of a node we converted: rebuild its bold copy
          const span = this.build(n.data);
          copy.span.replaceWith(span);
          this.copies.set(n, { span, text: n.data });
          n.data = "";
        } else {
          this.convertWithin(n);
        }
      });
      this.pending.clear();
      // Forget nodes the page removed; put copies back next to nodes the page moved
      this.copies.forEach((copy, node) => {
        if (!node.isConnected) {
          copy.span.remove();
          this.copies.delete(node);
        } else if (node.nextSibling !== copy.span) {
          node.after(copy.span);
        }
      });
      this.observer.takeRecords();
      this.busy = false;
    },

    remove() {
      if (this.observer) this.observer.disconnect();
      this.observer = null;
      clearTimeout(this.timer);
      this.timer = null;
      this.pending.clear();
      this.copies.forEach(({ span, text }, node) => {
        if (node.data === "") node.data = text;
        span.remove();
      });
      this.copies.clear();
      this.active = false;
      updateSensoryUI();
    },
  };

  function toggleBionic() {
    if (bionic.active) bionic.remove();
    else bionic.apply();
    prefs.bionic = bionic.active;
    savePrefs();
  }

  // ---------------------------------------------------------------------------
  // Typography controls
  // ---------------------------------------------------------------------------
  function syncTypographyControls() {
    const set = (id, value) => {
      const el = $(id);
      if (el) el.value = value;
    };
    const label = (id, text) => {
      const el = $(id);
      if (el) el.textContent = text;
    };
    set("cp-font-size", prefs.fontSize);
    set("cp-line-height", prefs.lineHeight);
    set("cp-letter-spacing", prefs.letterSpacing);
    set("cp-font-family", prefs.font);
    set("cp-band", prefs.band);
    label("cp-font-size-val", prefs.fontSize ? prefs.fontSize + "px" : "page");
    label("cp-line-height-val", prefs.lineHeight ? Number(prefs.lineHeight).toFixed(1) : "page");
    label("cp-letter-spacing-val", prefs.letterSpacing ? Number(prefs.letterSpacing).toFixed(2) : "page");
    label("cp-band-val", prefs.band + "px");
    updateSensoryUI();
  }

  // ---------------------------------------------------------------------------
  // Reading ruler, focus mask and tint (drawn inside the shadow root)
  // ---------------------------------------------------------------------------
  let rulerOn = false;
  let maskOn = false;

  function toggleRuler() {
    ensureUI();
    rulerOn = !rulerOn;
    ui.ruler.hidden = !rulerOn;
    positionReadingAids();
    updateSensoryUI();
  }

  // Focus mask: dims the page above and below a clear reading band that follows the mouse
  function toggleFocusMask() {
    ensureUI();
    maskOn = !maskOn;
    ui.maskTop.hidden = ui.maskBottom.hidden = !maskOn;
    positionReadingAids();
    updateSensoryUI();
  }

  function positionReadingAids() {
    if (!host) return;
    const half = prefs.band / 2;
    if (rulerOn) {
      ui.ruler.style.height = prefs.band + "px";
      ui.ruler.style.top = lastMouseY - half + "px";
    }
    if (maskOn) {
      ui.maskTop.style.top = "0px";
      ui.maskTop.style.height = Math.max(0, lastMouseY - half) + "px";
      ui.maskBottom.style.top = lastMouseY + half + "px";
      ui.maskBottom.style.bottom = "0px";
    }
  }

  function onMouseMove(e) {
    lastMouseY = e.clientY;
    if (rulerOn || maskOn) positionReadingAids();
  }

  function applyTint(color, remember = true) {
    if (remember) {
      prefs.tint = color;
      savePrefs();
    }
    if (color !== "none" || host) {
      ensureUI();
      ui.tint.hidden = color === "none";
      ui.tint.style.backgroundColor = color === "none" ? "" : color;
    }
    updateSensoryUI();
  }

  // ---------------------------------------------------------------------------
  // Read aloud (speechSynthesis, runs in the browser)
  // Blocks are collected up front (cheap); their text is extracted only when reached,
  // with a map back to the page's text nodes so the spoken word can be highlighted.
  // ---------------------------------------------------------------------------
  const tts = { active: false, paused: false, blocks: [], bi: 0, chunks: [], ci: 0, cur: null, run: 0, el: null, utter: null, blockStartedAt: 0 };
  let ttsRate = 1;
  let ttsVoiceURI = "";
  const canHighlightWords = typeof Highlight === "function" && !!(window.CSS && CSS.highlights);
  const READ_SKIP = "nav, footer, aside, [aria-hidden='true'], figure, table, .thumb, .navbox, .reflist, .references, [role=navigation], [role=complementary]";
  const BLOCK_BREAK = "p, li, dd, dt, blockquote, div, h1, h2, h3, h4, h5, h6, td, th, section, article, br, tr";

  // Citation markers such as [1], [edit], [citation needed]
  const CITATION_RE = /\[(\d+|[a-z]|edit|citation needed|note \d+)\]/gi;

  function visible(el) {
    if (el.checkVisibility) return el.checkVisibility({ visibilityProperty: true });
    return el.getClientRects().length > 0;
  }

  // Text of `root` (optionally clipped to `range`) plus, for every character, its position in the page
  function extractText(root, range) {
    const segs = []; // { node, base, off } : raw[base..] comes from node.data[off..]
    let raw = "";
    let lastBlock = null;
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode(n) {
        if (range && !range.intersectsNode(n)) return NodeFilter.FILTER_REJECT;
        const p = n.parentElement;
        if (!p || p.closest("script, style, noscript, sup.reference, .mw-editsection")) return NodeFilter.FILTER_REJECT;
        if (!n.data || !visible(p)) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      },
    });
    let n;
    while ((n = walker.nextNode())) {
      let start = 0;
      let end = n.data.length;
      if (range) {
        if (n === range.startContainer) start = range.startOffset;
        if (n === range.endContainer) end = range.endOffset;
      }
      if (end <= start) continue;
      const block = n.parentElement.closest(BLOCK_BREAK);
      if (lastBlock && block !== lastBlock) raw += " "; // keep words from separate blocks apart
      lastBlock = block;
      segs.push({ node: n, base: raw.length, off: start });
      raw += n.data.slice(start, end);
    }
    // Blank out citations with spaces of the same length so positions stay valid
    raw = raw.replace(CITATION_RE, (m) => " ".repeat(m.length));
    // Collapse whitespace; map[i] = index in raw of text[i]
    let text = "";
    const map = [];
    let pendingSpace = -1;
    for (let i = 0; i < raw.length; i++) {
      if (/\s/.test(raw[i])) {
        if (pendingSpace < 0 && text) pendingSpace = i;
        continue;
      }
      if (pendingSpace >= 0) {
        text += " ";
        map.push(pendingSpace);
        pendingSpace = -1;
      }
      text += raw[i];
      map.push(i);
    }
    return { text, map, segs };
  }

  // Sentence-sized pieces as [start, end) offsets (Chrome cuts off very long utterances)
  function chunkRanges(text, max = 220) {
    const out = [];
    const re = /[^.!?。！？]+(?:[.!?。！？]+["'”’)\]]*\s*|$)/g;
    let m;
    let curStart = 0;
    let curEnd = 0;
    while ((m = re.exec(text)) && m[0]) {
      const s = m.index;
      const e = s + m[0].length;
      if (e - curStart > max && curEnd > curStart) {
        out.push([curStart, curEnd]);
        curStart = curEnd;
      }
      curEnd = e;
    }
    if (curEnd < text.length) curEnd = text.length;
    if (curEnd > curStart) out.push([curStart, curEnd]);
    // Hard-split anything still too long (no sentence punctuation) at a comma or space
    const result = [];
    out.forEach(([s, e]) => {
      while (e - s > max) {
        const slice = text.slice(s, s + max);
        let cut = Math.max(slice.lastIndexOf(", "), slice.lastIndexOf("; "));
        if (cut < max / 2) cut = slice.lastIndexOf(" ");
        if (cut < max / 4) cut = max;
        else cut += 1;
        result.push([s, s + cut]);
        s += cut;
      }
      result.push([s, e]);
    });
    // Trim whitespace at the edges; drop empty pieces
    return result
      .map(([s, e]) => {
        while (s < e && /\s/.test(text[s])) s++;
        while (e > s && /\s/.test(text[e - 1])) e--;
        return [s, e];
      })
      .filter(([s, e]) => e > s);
  }

  // The part of the page that holds the article: the candidate with the most text
  function findReadingRoot() {
    const candidates = Array.from(document.querySelectorAll("article, main, [role='main'], [itemprop='articleBody']"));
    let best = null;
    let bestLen = 0;
    candidates.forEach((el) => {
      const len = (el.textContent || "").length;
      if (len > bestLen) {
        best = el;
        bestLen = len;
      }
    });
    const bodyLen = (document.body.textContent || "").length;
    return best && bestLen > bodyLen * 0.25 ? best : document.body;
  }

  function collectReadableBlocks() {
    const sel = window.getSelection && window.getSelection();
    if (sel && sel.rangeCount && sel.toString().trim()) {
      return { blocks: [{ el: null, range: sel.getRangeAt(0).cloneRange() }], start: 0 };
    }
    const root = findReadingRoot();
    const blocks = [];
    root.querySelectorAll("h1, h2, h3, h4, p, li, blockquote, dd").forEach((el) => {
      if (el.closest(READ_SKIP)) return;
      if (el.querySelector("p, li")) return; // the inner blocks are read instead
      if ((el.textContent || "").trim().length < 2) return;
      if (!visible(el)) return;
      blocks.push({ el });
    });
    // Start at the first block that is on screen (the earlier ones stay reachable with Previous)
    const start = blocks.findIndex((b) => b.el.getBoundingClientRect().bottom > 60);
    return { blocks, start: Math.max(0, start) };
  }

  function setReadingHighlight(el) {
    if (tts.el && tts.el !== el) tts.el.classList.remove("cp-tts-current");
    tts.el = el;
    if (!el) return;
    el.classList.add("cp-tts-current");
    const r = el.getBoundingClientRect();
    if (r.top < 0 || r.bottom > window.innerHeight) {
      const smooth = !window.matchMedia("(prefers-reduced-motion: reduce)").matches;
      el.scrollIntoView({ block: "center", behavior: smooth ? "smooth" : "auto" });
    }
  }

  function clearWordHighlight() {
    if (canHighlightWords) CSS.highlights.delete("cp-tts-word");
  }

  function highlightWord(cur, from, to) {
    if (!canHighlightWords || !cur) return;
    try {
      const toPoint = (rawIdx) => {
        let lo = 0;
        let hi = cur.segs.length - 1;
        while (lo < hi) {
          const mid = (lo + hi + 1) >> 1;
          if (cur.segs[mid].base <= rawIdx) lo = mid;
          else hi = mid - 1;
        }
        const seg = cur.segs[lo];
        return [seg.node, Math.min(seg.node.data.length, seg.off + (rawIdx - seg.base))];
      };
      const [sn, so] = toPoint(cur.map[from]);
      const [en, eo] = toPoint(cur.map[to - 1]); // last character of the word
      if (!sn.isConnected || !en.isConnected) return clearWordHighlight();
      const range = document.createRange();
      range.setStart(sn, so);
      range.setEnd(en, Math.min(en.data.length, eo + 1));
      CSS.highlights.set("cp-tts-word", new Highlight(range));
    } catch (err) {
      clearWordHighlight();
    }
  }

  function pickVoice() {
    if (!ttsVoiceURI || !("speechSynthesis" in window)) return null;
    return speechSynthesis.getVoices().find((v) => v.voiceURI === ttsVoiceURI) || null;
  }

  // Load the next block's text when the current one is used up; false = end of article
  function prepareBlock() {
    while (tts.bi < tts.blocks.length) {
      const block = tts.blocks[tts.bi];
      let cur = null;
      try {
        if (block.range) {
          const common = block.range.commonAncestorContainer;
          cur = extractText(common.nodeType === Node.TEXT_NODE ? common.parentNode : common, block.range);
        } else if (block.el.isConnected) {
          cur = extractText(block.el);
        }
      } catch (err) {
        cur = null;
      }
      if (cur && cur.text.length > 1) {
        tts.cur = cur;
        tts.chunks = chunkRanges(cur.text);
        if (tts.ci >= tts.chunks.length) tts.ci = 0;
        if (tts.chunks.length) return true;
      }
      tts.bi++;
      tts.ci = 0;
    }
    return false;
  }

  function speakNext(run) {
    if (run !== tts.run || !tts.active) return;
    if (!tts.cur || tts.ci >= tts.chunks.length) {
      if (tts.cur) {
        tts.bi++;
        tts.ci = 0;
        tts.cur = null;
      }
      if (!prepareBlock()) {
        stopReading();
        showToast("Finished reading.");
        return;
      }
    }
    const cur = tts.cur;
    const [start, end] = tts.chunks[tts.ci];
    const block = tts.blocks[tts.bi];
    if (tts.ci === 0) tts.blockStartedAt = Date.now();
    setReadingHighlight(block.el);
    clearWordHighlight();
    updateReadUI();
    const u = new SpeechSynthesisUtterance(cur.text.slice(start, end));
    tts.utter = u; // keep a reference: Chrome can drop events of collected utterances
    u.rate = ttsRate;
    const voice = pickVoice();
    if (voice) {
      u.voice = voice;
      u.lang = voice.lang;
    } else if (document.documentElement.lang) {
      u.lang = document.documentElement.lang;
    }
    u.onboundary = (e) => {
      if (run !== tts.run || e.name !== "word") return;
      const from = start + e.charIndex;
      if (from >= end) return;
      let len = e.charLength;
      if (!len) {
        const rest = cur.text.slice(from, end).match(/^\S+/);
        len = rest ? rest[0].length : 1;
      }
      highlightWord(cur, from, Math.min(end, from + len));
    };
    u.onend = () => {
      if (run !== tts.run) return;
      tts.ci++;
      speakNext(run);
    };
    u.onerror = (e) => {
      if (run !== tts.run || e.error === "interrupted" || e.error === "canceled") return;
      stopReading();
      showToast("Read aloud stopped: " + e.error);
    };
    speechSynthesis.speak(u);
  }

  function startReading() {
    if (!("speechSynthesis" in window)) {
      showToast("Read aloud is not available in this browser.");
      return;
    }
    const { blocks, start } = collectReadableBlocks();
    if (!blocks.length) {
      showToast("No readable text found. Select some text and try again.");
      return;
    }
    speechSynthesis.cancel();
    tts.blocks = blocks;
    tts.bi = start;
    tts.ci = 0;
    tts.cur = null;
    tts.active = true;
    tts.paused = false;
    tts.run++;
    if (!prepareBlock()) {
      tts.active = false;
      showToast("No readable text found. Select some text and try again.");
      updateReadUI();
      return;
    }
    speakNext(tts.run);
  }

  function stopReading() {
    tts.run++;
    const wasActive = tts.active;
    tts.active = false;
    tts.paused = false;
    tts.utter = null;
    tts.cur = null;
    tts.blocks = [];
    if (wasActive && "speechSynthesis" in window) speechSynthesis.cancel();
    setReadingHighlight(null);
    clearWordHighlight();
    updateReadUI();
  }

  // Play / pause / resume: the same action for the button and the keyboard shortcut
  function toggleReading() {
    if (!tts.active) startReading();
    else if (tts.paused) {
      speechSynthesis.resume();
      tts.paused = false;
    } else {
      speechSynthesis.pause();
      tts.paused = true;
    }
    updateReadUI();
  }

  // Previous: like a music player, restart this paragraph, or go to the one before
  // when pressed within the first moments of it
  function previousParagraph() {
    if (!tts.active) return;
    if (tts.bi === 0 || Date.now() - tts.blockStartedAt > 1200) {
      tts.ci = 0;
      restartSpeech();
    } else {
      restartSpeech(-1);
    }
  }

  // Restart speech at the current position (new speed / voice) or jump by whole paragraphs
  function restartSpeech(blockDelta = 0) {
    if (!tts.active) return;
    if (blockDelta) {
      const target = Math.max(0, Math.min(tts.blocks.length - 1, tts.bi + blockDelta));
      if (target === tts.bi && blockDelta > 0) return;
      tts.bi = target;
      tts.ci = 0;
      tts.cur = null;
      if (!prepareBlock()) {
        stopReading();
        return;
      }
    }
    tts.run++;
    if (tts.paused) speechSynthesis.resume(); // speak() does nothing while paused
    tts.paused = false;
    speechSynthesis.cancel();
    speakNext(tts.run);
  }

  function updateReadUI() {
    const btn = $("cp-read-btn");
    if (!btn) return;
    btn.textContent = !tts.active ? "▶ Read" : tts.paused ? "▶ Resume" : "❚❚ Pause";
    btn.classList.toggle("on", tts.active);
    $("cp-read-stop").disabled = !tts.active;
    $("cp-read-prev").disabled = !tts.active;
    $("cp-read-next").disabled = !tts.active || tts.bi >= tts.blocks.length - 1;
    const progress = $("cp-read-progress");
    if (!tts.active) progress.textContent = "";
    else if (tts.blocks.length === 1 && !tts.blocks[0].el) progress.textContent = "Reading your selection";
    else progress.textContent = `Paragraph ${tts.bi + 1} of ${tts.blocks.length}${tts.paused ? " (paused)" : ""}`;
  }

  function fillVoices() {
    const select = $("cp-read-voice");
    if (!select || !("speechSynthesis" in window)) return;
    const voices = speechSynthesis.getVoices();
    const pageLang = (document.documentElement.lang || navigator.language || "").slice(0, 2).toLowerCase();
    const sorted = voices.slice().sort((a, b) => {
      const am = a.lang.toLowerCase().startsWith(pageLang) ? 0 : 1;
      const bm = b.lang.toLowerCase().startsWith(pageLang) ? 0 : 1;
      return am - bm || a.lang.localeCompare(b.lang) || a.name.localeCompare(b.name);
    });
    select.replaceChildren(new Option("Browser default", ""));
    sorted.forEach((v) => {
      select.add(new Option(`${v.name} (${v.lang})${v.localService ? "" : " · online"}`, v.voiceURI));
    });
    select.value = sorted.some((v) => v.voiceURI === ttsVoiceURI) ? ttsVoiceURI : "";
  }

  // ---------------------------------------------------------------------------
  // Revert / clear
  // ---------------------------------------------------------------------------
  async function revertAllChanges() {
    hiddenSelectors = [];
    clearTimeout(prefsSaveTimer);
    prefs = { ...DEFAULT_PREFS };
    await store.remove([SITE, PREFS_KEY]); // removing is fine even in a private window
    isHideModeActive = false;
    isResizeModeActive = false;
    applyTint("none", false);
    if (rulerOn) toggleRuler();
    if (maskOn) toggleFocusMask();
    stopReading();
    if (bionic.active) bionic.remove();
    restoreResized();
    applyReadingStyles();
    syncTypographyControls();
    updateButtonUI();
    showToast("All ClearPath changes on this site have been reverted.");
  }

  function clearAllFilters() {
    prefs = { ...DEFAULT_PREFS };
    applyTint("none", false);
    if (bionic.active) bionic.remove();
    if (rulerOn) toggleRuler();
    if (maskOn) toggleFocusMask();
    applyReadingStyles();
    syncTypographyControls();
    savePrefs();
  }

  // ---------------------------------------------------------------------------
  // Panel
  // ---------------------------------------------------------------------------
  function createSidebar() {
    ensureUI();
    if (panel) return;
    panel = document.createElement("aside");
    panel.className = "panel";
    panel.setAttribute("aria-label", "ClearPath Zen Pro");
    panel.hidden = true;
    panel.innerHTML = PANEL_HTML; // static template, no page data
    shadow.insertBefore(panel, ui.toast);
    $("cp-site").textContent = SITE;

    $("cp-hide-toggle").onclick = () => {
      isResizeModeActive = false;
      isHideModeActive = !isHideModeActive;
      updateButtonUI();
    };
    $("cp-resize-toggle").onclick = () => {
      isHideModeActive = false;
      isResizeModeActive = !isResizeModeActive;
      updateButtonUI();
    };
    // Revert All asks for a second click instead of acting at once
    let revertTimer = null;
    const revertBtn = $("cp-revert-all");
    revertBtn.onclick = () => {
      if (!revertBtn.classList.contains("confirm")) {
        revertBtn.classList.add("confirm");
        revertBtn.textContent = "Sure? Click again";
        revertTimer = setTimeout(() => {
          revertBtn.classList.remove("confirm");
          revertBtn.textContent = "Revert All";
        }, 3000);
        return;
      }
      clearTimeout(revertTimer);
      revertBtn.classList.remove("confirm");
      revertBtn.textContent = "Revert All";
      revertAllChanges();
    };
    $("cp-close").onclick = closeSidebar;
    // Dock left or right, so the panel never covers what you want to hide (remembered for all sites)
    $("cp-dock").onclick = () => {
      const left = !panel.classList.contains("left");
      panel.classList.toggle("left", left);
      store.set({ cpPanelSide: left ? "left" : "right" });
    };
    store.get({ cpPanelSide: "right" }).then((s) => panel.classList.toggle("left", s.cpPanelSide === "left"));
    $("cp-undo").onclick = undoLastHide;
    $("cp-bionic-btn").onclick = toggleBionic;
    $("cp-ruler-btn").onclick = toggleRuler;
    $("cp-mask-btn").onclick = toggleFocusMask;
    $("cp-read-btn").onclick = toggleReading;
    $("cp-read-stop").onclick = stopReading;
    $("cp-read-prev").onclick = previousParagraph;
    $("cp-read-next").onclick = () => restartSpeech(1);
    const rateSel = $("cp-read-rate");
    rateSel.value = String(ttsRate);
    rateSel.onchange = () => {
      ttsRate = Number(rateSel.value) || 1;
      store.set({ cpTtsRate: ttsRate });
      if (tts.active && !tts.paused) restartSpeech(); // apply from the current sentence on
    };
    const voiceSel = $("cp-read-voice");
    fillVoices();
    if ("speechSynthesis" in window) {
      speechSynthesis.addEventListener("voiceschanged", fillVoices);
      cleanups.push(() => speechSynthesis.removeEventListener("voiceschanged", fillVoices));
    }
    voiceSel.onchange = () => {
      ttsVoiceURI = voiceSel.value;
      store.set({ cpTtsVoice: ttsVoiceURI });
      if (tts.active && !tts.paused) restartSpeech();
    };
    shadow.querySelectorAll(".tint-btn").forEach((btn) => {
      // Clicking the active tint again turns it off
      btn.onclick = () => applyTint(prefs.tint === btn.dataset.tint ? "none" : btn.dataset.tint);
    });

    const onTypography = () => {
      const fs = Number($("cp-font-size").value);
      const lh = Number($("cp-line-height").value);
      prefs.fontSize = fs < 10 ? 0 : fs;
      prefs.lineHeight = lh < 1 ? 0 : lh;
      prefs.letterSpacing = Number($("cp-letter-spacing").value) || 0;
      prefs.font = $("cp-font-family").value;
      prefs.band = Number($("cp-band").value) || 34;
      syncTypographyControls();
      applyReadingStyles();
      positionReadingAids();
      savePrefs();
    };
    ["cp-font-size", "cp-line-height", "cp-letter-spacing", "cp-band"].forEach((id) => {
      $(id).oninput = onTypography;
    });
    $("cp-font-family").onchange = onTypography;
    $("cp-clear-btn").onclick = clearAllFilters;

    syncTypographyControls();
    updateButtonUI();
    updateReadUI();

    // First-run hint
    store.get({ cpOnboarded: false }).then((s) => {
      if (s.cpOnboarded) return;
      const tip = $("cp-tip");
      tip.hidden = false;
      $("cp-tip-ok").onclick = () => {
        tip.hidden = true;
        store.set({ cpOnboarded: true });
        $("cp-title").focus();
      };
    });
  }

  function openSidebar() {
    createSidebar();
    if (!host.isConnected) document.documentElement.appendChild(host);
    panel.hidden = false;
    $("cp-title").focus({ preventScroll: true });
  }

  function closeSidebar() {
    if (panel) panel.hidden = true;
    isHideModeActive = false;
    isResizeModeActive = false;
    updateButtonUI();
  }

  const isSidebarOpen = () => !!panel && !panel.hidden && !!host && host.isConnected;

  function onKeyDown(e) {
    if (e.key !== "Escape") return;
    if (isHideModeActive || isResizeModeActive) {
      isHideModeActive = false;
      isResizeModeActive = false;
      updateButtonUI();
    } else if (isSidebarOpen() && isOwnUI(e)) {
      closeSidebar();
    }
  }

  function onMessage(msg, sender, sendResponse) {
    if (!msg || typeof msg.action !== "string") return;
    if (msg.action === "openSidebar") openSidebar();
    else if (msg.action === "toggleSidebar") isSidebarOpen() ? closeSidebar() : openSidebar();
    else if (msg.action === "toggleReadAloud") toggleReading();
    else return;
    // Reply so the sender knows the content script is present (no reply = "port closed" error)
    sendResponse({ ok: true });
  }

  // ---------------------------------------------------------------------------
  // Teardown (extension updated or reloaded while this page stayed open)
  // ---------------------------------------------------------------------------
  function teardown() {
    if (tornDown) return;
    tornDown = true;
    cleanups.forEach((fn) => {
      try {
        fn();
      } catch (err) {
        /* ignore */
      }
    });
    if (tts.active && "speechSynthesis" in window) speechSynthesis.cancel();
    tts.active = false;
    if (tts.el) tts.el.classList.remove("cp-tts-current");
    clearWordHighlight();
    clearHoverTarget();
    if (bionic.active) bionic.remove();
    restoreResized();
    cpStyleTag.remove();
    if (host) host.remove();
    if (window.__clearPathZen && window.__clearPathZen.teardown === teardown) delete window.__clearPathZen;
  }

  window.__clearPathZen = { alive: isAlive, teardown };

  // ---------------------------------------------------------------------------
  // Start
  // ---------------------------------------------------------------------------
  on(document, "mouseover", onMouseOver, true);
  on(document, "mousemove", onMouseMove, { passive: true });
  on(document, "pointerdown", onTargetPointer, true);
  on(document, "mousedown", onTargetPointer, true);
  on(document, "click", onTargetClick, true);
  on(document, "keydown", onKeyDown, true);
  on(window, "pagehide", () => {
    if (tts.active) stopReading();
  });
  // A newer copy of ClearPath started in this tab: step aside if this copy is orphaned
  const onNewInstance = () => {
    if (!isAlive()) teardown();
  };
  document.addEventListener("clearpath:init", onNewInstance);
  cleanups.push(() => document.removeEventListener("clearpath:init", onNewInstance));
  chrome.runtime.onMessage.addListener(onMessage);
  cleanups.push(() => {
    try {
      chrome.runtime.onMessage.removeListener(onMessage);
    } catch (err) {
      /* ignore */
    }
  });

  renderPageStyles();
  loadSiteData();
  store.get({ cpTtsRate: 1, cpTtsVoice: "" }).then((s) => {
    ttsRate = Number(s.cpTtsRate) || 1;
    ttsVoiceURI = typeof s.cpTtsVoice === "string" ? s.cpTtsVoice : "";
    const rateSel = $("cp-read-rate");
    if (rateSel) rateSel.value = String(ttsRate);
    fillVoices();
  });
})();
