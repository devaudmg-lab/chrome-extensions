let hiddenElementsStack = [];
let isHideModeActive = false;
let isResizeModeActive = false;
let currentTintOverlay = null;
let ruler = null;
let isBionicActive = false;
let resizedElements = [];

const cpStyleTag = document.createElement("style");
cpStyleTag.id = "cp-dynamic-styles";
(document.head || document.documentElement).appendChild(cpStyleTag);

function updateGlobalStyles(css) {
  cpStyleTag.textContent = css;
}

function updateButtonUI() {
  const hideBtn = document.getElementById("cp-hide-toggle");
  const resizeBtn = document.getElementById("cp-resize-toggle");
  if (hideBtn) {
    hideBtn.textContent = isHideModeActive
      ? "HIDING: ON (Esc)"
      : "Target & Hide";
    hideBtn.style.background = isHideModeActive ? "#ef4444" : "";
  }
  if (resizeBtn) {
    resizeBtn.textContent = isResizeModeActive
      ? "RESIZE: ON (Esc)"
      : "Target & Resize";
    resizeBtn.style.background = isResizeModeActive ? "#ef4444" : "";
  }
}

// --- NEW FUNCTION: REVERT ALL CHANGES ---
async function revertAllChanges() {
  const domain = window.location.hostname;

  // 1. Clear Storage for this domain (remember which selectors we had hidden)
  const data = await chrome.storage.local.get(domain);
  const storedSelectors = data[domain] || [];
  await chrome.storage.local.remove(domain);

  // 2. Show all hidden elements in the current session
  hiddenElementsStack.forEach((item) => {
    if (item.el) item.el.style.setProperty("display", "", "");
  });

  // 3. Show elements hidden by persistence (only ours, not the page's own hidden elements)
  storedSelectors.forEach((s) => {
    try {
      document.querySelectorAll(s).forEach((el) => {
        if (el.style.getPropertyPriority("display") === "important")
          el.style.removeProperty("display");
      });
    } catch (err) {
      /* invalid selector */
    }
  });

  // 4. Reset Stack
  hiddenElementsStack = [];

  // 5. Turn off all modes
  isHideModeActive = false;
  isResizeModeActive = false;
  if (currentTintOverlay) {
    currentTintOverlay.remove();
    currentTintOverlay = null;
  }
  if (ruler) {
    ruler.remove();
    ruler = null;
  }
  document.documentElement.style.filter = "";
  updateGlobalStyles("");
  removeBionic();
  resizedElements.forEach(({ el, width, maxWidth }) => {
    el.style.width = width;
    el.style.maxWidth = maxWidth;
    delete el.dataset.cpResizing;
    el.querySelectorAll(":scope > .cp-resizer-handle").forEach((h) => h.remove());
  });
  resizedElements = [];
  resetTypographyControls();
  updateButtonUI();

  alert("All ClearPath changes on this site have been reverted.");
}

document.addEventListener("mouseover", (e) => {
  if (e.target.closest && e.target.closest("#clearpath-sidebar")) return;
  if (isHideModeActive || isResizeModeActive)
    e.target.classList.add("clearpath-hover-target");
});
document.addEventListener("mouseout", (e) => {
  e.target.classList.remove("clearpath-hover-target");
});

document.addEventListener(
  "click",
  (e) => {
    if (e.target.closest("#clearpath-sidebar")) return;
    if (isHideModeActive) {
      e.preventDefault();
      e.stopPropagation();
      hideElement(e.target);
    } else if (isResizeModeActive) {
      e.preventDefault();
      e.stopPropagation();
      makeElementResizable(e.target);
    }
  },
  true,
);

function getUniqueSelector(el) {
  if (el.id) return `#${CSS.escape(el.id)}`;
  let path = [];
  while (el.parentElement && el.tagName !== "HTML") {
    let index = Array.from(el.parentElement.children).indexOf(el) + 1;
    path.unshift(`${el.tagName.toLowerCase()}:nth-child(${index})`);
    el = el.parentElement;
  }
  return path.join(" > ");
}

async function hideElement(el) {
  const selector = getUniqueSelector(el);
  const domain = window.location.hostname;
  el.classList.remove("clearpath-hover-target");
  el.style.setProperty("display", "none", "important");
  hiddenElementsStack.push({ el, selector });
  const data = await chrome.storage.local.get(domain);
  const hiddenSelectors = data[domain] || [];
  if (!hiddenSelectors.includes(selector)) {
    hiddenSelectors.push(selector);
    await chrome.storage.local.set({ [domain]: hiddenSelectors });
  }
}

function undoLastHide() {
  const last = hiddenElementsStack.pop();
  if (last && last.el) {
    last.el.style.setProperty("display", "", "");
    const domain = window.location.hostname;
    chrome.storage.local.get(domain).then((data) => {
      const list = data[domain] || [];
      const filtered = list.filter((s) => s !== last.selector);
      chrome.storage.local.set({ [domain]: filtered });
    });
  }
}

function escapeHtml(str) {
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function applyBionic() {
  const walker = document.createTreeWalker(
    document.body,
    NodeFilter.SHOW_TEXT,
    null,
    false,
  );
  // Collect first: replacing nodes while walking detaches the walker after the first replacement
  const nodes = [];
  let node;
  while ((node = walker.nextNode())) {
    const parent = node.parentElement;
    if (!parent || !node.textContent.trim()) continue;
    if (
      ["SCRIPT", "STYLE", "NOSCRIPT", "TEXTAREA", "SELECT", "OPTION", "CODE", "PRE"].includes(
        parent.tagName,
      )
    )
      continue;
    if (parent.isContentEditable) continue;
    if (parent.closest("#clearpath-sidebar, .cp-bionic")) continue;
    nodes.push(node);
  }
  nodes.forEach((node) => {
    const span = document.createElement("span");
    span.className = "cp-bionic";
    // Escape page text so it is never parsed as HTML
    span.innerHTML = node.textContent
      .split(/(\s+)/)
      .map((word) => {
        if (!word || /^\s+$/.test(word)) return word;
        if (word.length <= 3) return `<b>${escapeHtml(word)}</b>`;
        let mid = Math.ceil(word.length / 2);
        return `<b>${escapeHtml(word.slice(0, mid))}</b>${escapeHtml(word.slice(mid))}`;
      })
      .join("");
    node.parentElement.replaceChild(span, node);
  });
}

// Restore the original text nodes so Bionic Mode can be switched off again
function removeBionic() {
  document.querySelectorAll("span.cp-bionic").forEach((span) => {
    if (span.parentNode)
      span.parentNode.replaceChild(document.createTextNode(span.textContent), span);
  });
  if (document.body) document.body.normalize();
  isBionicActive = false;
  const btn = document.getElementById("cp-bionic-btn");
  if (btn) btn.textContent = "Bionic Mode";
}

function toggleBionic() {
  if (isBionicActive) {
    removeBionic();
    return;
  }
  applyBionic();
  isBionicActive = true;
  const btn = document.getElementById("cp-bionic-btn");
  if (btn) btn.textContent = "Bionic Mode: ON";
}

function updateTypography(fontSize, lineHeight) {
  // 0 = leave the page's own value untouched
  const rules = [];
  if (fontSize > 0) rules.push(`font-size: ${fontSize}px !important;`);
  if (lineHeight > 0) rules.push(`line-height: ${lineHeight} !important;`);
  updateGlobalStyles(
    rules.length ? `p, li, dd, blockquote { ${rules.join(" ")} }` : "",
  );
}

function resetTypographyControls() {
  const fs = document.getElementById("cp-font-size");
  const lh = document.getElementById("cp-line-height");
  if (fs) fs.value = 0;
  if (lh) lh.value = 0;
  const fsv = document.getElementById("cp-font-size-val");
  const lhv = document.getElementById("cp-line-height-val");
  if (fsv) fsv.textContent = "page";
  if (lhv) lhv.textContent = "page";
}

function toggleRuler() {
  if (ruler) {
    ruler.remove();
    ruler = null;
    return;
  }
  ruler = document.createElement("div");
  Object.assign(ruler.style, {
    position: "fixed",
    left: 0,
    width: "100%",
    height: "30px",
    background: "rgba(79, 70, 229, 0.2)",
    borderTop: "2px solid #4f46e5",
    borderBottom: "2px solid #4f46e5",
    pointerEvents: "none",
    zIndex: "2147483647",
    top: "50%",
  });
  document.body.appendChild(ruler);
}

// Single listener for the reading ruler (adding one per toggle leaked listeners)
document.addEventListener("mousemove", (e) => {
  if (ruler) ruler.style.top = e.clientY - 15 + "px";
});

function applyTint(color) {
  if (currentTintOverlay) currentTintOverlay.remove();
  currentTintOverlay = null;
  if (color === "none") return;
  currentTintOverlay = document.createElement("div");
  Object.assign(currentTintOverlay.style, {
    position: "fixed",
    top: 0,
    left: 0,
    width: "100vw",
    height: "100vh",
    pointerEvents: "none",
    zIndex: "2147483646",
    backgroundColor: color,
  });
  document.body.appendChild(currentTintOverlay);
}

function makeElementResizable(el) {
  if (el.dataset.cpResizing) return;
  el.dataset.cpResizing = "true";
  el.classList.remove("clearpath-hover-target");
  resizedElements.push({ el, width: el.style.width, maxWidth: el.style.maxWidth });
  if (getComputedStyle(el).position === "static") el.style.position = "relative";
  const handle = document.createElement("div");
  handle.className = "cp-resizer-handle";
  el.appendChild(handle);
  handle.addEventListener("mousedown", (e) => {
    e.preventDefault();
    let startX = e.clientX,
      startWidth = el.offsetWidth;
    const doResize = (m) => {
      // Change the real width so text re-flows (a scale transform only magnified it)
      const newWidth = Math.max(150, startWidth + (m.clientX - startX));
      el.style.setProperty("width", newWidth + "px", "important");
      el.style.setProperty("max-width", "none", "important");
    };
    const stop = () => {
      document.removeEventListener("mousemove", doResize);
      document.removeEventListener("mouseup", stop);
    };
    document.addEventListener("mousemove", doResize);
    document.addEventListener("mouseup", stop);
  });
}

function createSidebar() {
  if (document.getElementById("clearpath-sidebar")) return;
  const sidebar = document.createElement("div");
  sidebar.id = "clearpath-sidebar";
  sidebar.innerHTML = `
    <div class="cp-header"><h3>Zen Pro</h3><button id="cp-close-sidebar">×</button></div>
    <div class="cp-section">
        <small>LAYOUT TOOLS</small>
        <button class="cp-btn cp-btn-primary" id="cp-hide-toggle">Target & Hide</button>
        <button class="cp-btn cp-btn-secondary" id="cp-resize-toggle">Target & Resize</button>
        <button class="cp-btn" id="cp-undo">Undo Last</button>
        <button class="cp-btn cp-btn-danger" id="cp-revert-all">REVERT ALL CHANGES</button>
    </div>
    <div class="cp-section">
        <small>SENSORY</small>
        <button class="cp-btn" id="cp-bionic-btn">Bionic Mode</button>
        <button class="cp-btn" id="cp-ruler-btn">Reading Ruler</button>
        <div class="cp-tints">
          <button class="cp-tint" data-tint="rgba(255, 230, 0, 0.1)" title="Sepia" style="background:#e9dca4"></button>
          <button class="cp-tint" data-tint="rgba(255, 150, 0, 0.12)" title="Warm amber" style="background:#f2b866"></button>
          <button class="cp-tint" data-tint="rgba(80, 150, 255, 0.1)" title="Soft blue" style="background:#9cc2f5"></button>
          <button class="cp-tint" data-tint="rgba(120, 220, 140, 0.1)" title="Soft green" style="background:#a7dfb2"></button>
          <button class="cp-tint" data-tint="rgba(0, 0, 0, 0.25)" title="Dim" style="background:#555"></button>
        </div>
        <button class="cp-btn" id="cp-clear-btn">Clear All Filters</button>
    </div>
    <div class="cp-section">
        <small>TYPOGRAPHY</small>
        <label class="cp-flex">Size <input type="range" id="cp-font-size" min="0" max="32" step="1" value="0"><span id="cp-font-size-val">page</span></label>
        <label class="cp-flex">Spacing <input type="range" id="cp-line-height" min="0" max="2.6" step="0.1" value="0"><span id="cp-line-height-val">page</span></label>
    </div>`;
  document.body.appendChild(sidebar);

  document.getElementById("cp-hide-toggle").onclick = () => {
    isResizeModeActive = false;
    isHideModeActive = !isHideModeActive;
    updateButtonUI();
  };
  document.getElementById("cp-resize-toggle").onclick = () => {
    isHideModeActive = false;
    isResizeModeActive = !isResizeModeActive;
    updateButtonUI();
  };
  document.getElementById("cp-revert-all").onclick = revertAllChanges;
  document.getElementById("cp-close-sidebar").onclick = () => {
    sidebar.style.setProperty("display", "none", "important");
    isHideModeActive = false;
    isResizeModeActive = false;
    updateButtonUI();
  };
  document.getElementById("cp-undo").onclick = undoLastHide;
  document.getElementById("cp-bionic-btn").onclick = toggleBionic;
  document.getElementById("cp-ruler-btn").onclick = toggleRuler;
  sidebar.querySelectorAll(".cp-tint").forEach((btn) => {
    btn.onclick = () => applyTint(btn.dataset.tint);
  });
  const fontSlider = document.getElementById("cp-font-size");
  const lineSlider = document.getElementById("cp-line-height");
  const onTypography = () => {
    const fs = Number(fontSlider.value) < 10 ? 0 : Number(fontSlider.value);
    const lh = Number(lineSlider.value) < 1 ? 0 : Number(lineSlider.value);
    document.getElementById("cp-font-size-val").textContent = fs ? fs + "px" : "page";
    document.getElementById("cp-line-height-val").textContent = lh ? lh.toFixed(1) : "page";
    updateTypography(fs, lh);
  };
  fontSlider.oninput = onTypography;
  lineSlider.oninput = onTypography;
  document.getElementById("cp-clear-btn").onclick = () => {
    applyTint("none");
    document.documentElement.style.filter = "";
    updateGlobalStyles("");
    resetTypographyControls();
    if (isBionicActive) removeBionic();
    if (ruler) toggleRuler();
  };
}

document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") {
    isHideModeActive = false;
    isResizeModeActive = false;
    updateButtonUI();
  }
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === "openSidebar") {
    createSidebar();
    document.getElementById("clearpath-sidebar").style.setProperty("display", "flex", "important");
    // Reply so the popup knows the content script is present (no reply = "port closed" error)
    sendResponse({ ok: true });
  }
});

async function applyPersistentHides() {
  const domain = window.location.hostname;
  const data = await chrome.storage.local.get(domain);
  const hiddenSelectors = data[domain] || [];
  hiddenSelectors.forEach((s) => {
    try {
      const el = document.querySelector(s);
      if (el) el.style.setProperty("display", "none", "important");
    } catch (err) {
      /* invalid selector */
    }
  });
}

applyPersistentHides();
// Debounced: reading storage on every single DOM mutation is very expensive on dynamic pages
let cpPersistTimer = null;
const observer = new MutationObserver(() => {
  if (cpPersistTimer) return;
  cpPersistTimer = setTimeout(() => {
    cpPersistTimer = null;
    applyPersistentHides();
  }, 300);
});
if (document.body)
  observer.observe(document.body, { childList: true, subtree: true });
