# CookieClean

A privacy-first cookie manager for Chrome. It removes tracking cookies automatically and keeps you logged in to the sites you trust.

## Features

- **One-click purge** of all cookies for the current site, or delete single cookies from the Active Site list.
- **Restore (Recently Cleaned)**: every cleanup, manual or automatic (tab close, leaving a site, prompt, shortcut, startup, schedule), can be undone from *Settings › Recently Cleaned* until the browser closes. If the site you are on was just cleaned, the Active Site tab offers a *Restore* button. Cookies come back with their flags, expiry and partition. The copies are kept in memory only (`chrome.storage.session`) and *Forget* drops them at once.
- **Wait before cleaning** (default 15 seconds; off, 15 s, 1 min or 5 min): after you close or leave a site, CookieClean waits before cleaning it. Reopen it in time (for example with <kbd>Ctrl</kbd>+<kbd>Shift</kbd>+<kbd>T</kbd>, or when a sign-in sends you through another site and back) and nothing is deleted.
- **Trusted sites, Always or Until restart**: *Always* sites are never cleaned automatically. *Until restart* sites (a greylist) keep their cookies while you browse and are cleaned when the browser starts.
- **Third-party cookies view**: the Active Site tab has a *This site / Third-party* switch. Third-party lists the other domains loaded by the page (ads, analytics, embeds) that store cookies sent to them, marks known trackers and partitioned cookies, and lets you delete them per domain or all at once.
- **Deep clean site data** (optional): when a site is cleaned (manually, on tab close or with the shortcut) also remove its localStorage, IndexedDB, Cache Storage and service workers.
- **Scheduled cleaning** (optional): every hour, every 6 hours or once a day, delete all cookies that aren't trusted. Sites open in a tab are skipped. The Settings tab shows when it last ran.
- **Auto-clean on tab close**: when you close the last tab of a site, its cookies are deleted.
- **Clean when leaving a site** (optional): also cleans when a tab navigates to a different site.
- **Prompt mode** (optional): shows a desktop notification with *Clear Cookies* / *Trust Site* buttons instead of deleting.
- **Clean on browser startup**: removes cookies of sites that aren't trusted. Sites restored in open tabs are kept; CookieClean waits for session restore to finish first.
- **Whitelist import and export** (JSON with both lists, or plain text with one domain per line).
- **Cookie Explorer**: lists every site storing cookies, with a high-risk filter (known trackers, long-lived cookies, too many cookies, insecure session cookies).
- **Privacy score** (A+ to F) for the active site.
- **Cookie Age Limiter**: shortens the lifetime of long-lived cookies to 24 hours, 7 days or 30 days.
- **Keyboard shortcut** <kbd>Alt</kbd>+<kbd>Shift</kbd>+<kbd>K</kbd>: purges the current site's cookies without opening the popup (trusted sites are left alone; the icon shows "!"). You can change it at `chrome://extensions/shortcuts`.
- **Stats**: cookies cleared today, in the last 7 days and in total, a 14-day bar chart, and today's count on the icon badge.
- **Pause switch** (*Auto-clean* in the header): stops all automatic cleaning; manual tools keep working.

## What is never deleted automatically

Every automatic path (tab close, leaving a site, prompt, startup, schedule, age limiter) uses the same rules:

- **Trusted sites and their subdomains.** `github.com` also covers `www.github.com` and `gist.github.com`; trusting `www.github.com` covers `github.com`.
- **Parent-domain cookies a trusted site uses.** If `mail.example.com` is trusted, cookies set on `.example.com` are kept even when you close `news.example.com`, because the browser sends them to the trusted site too.
- **Cookies of sites open in any tab or window**, including parent-domain cookies they use and the partitioned cookies stored under them.
- **Partitioned (CHIPS) cookies** are cleaned with the top-level site they belong to, and kept when that site is trusted or open.
- Incognito tabs only clean the incognito cookie store (if you allow the extension in incognito).

Manual actions ask first when they would touch a trusted site, and every manual action can be undone.

## Keyboard shortcuts

| Keys | Where | Action |
| --- | --- | --- |
| <kbd>Alt</kbd>+<kbd>Shift</kbd>+<kbd>K</kbd> | Anywhere | Purge the current site's cookies (and site data when Deep clean is on) |
| <kbd>1</kbd> <kbd>2</kbd> <kbd>3</kbd> <kbd>4</kbd> | Panel | Active Site / Explorer / Whitelist / Settings |
| <kbd>/</kbd> | Panel | Search domains in the Explorer |
| <kbd>Ctrl</kbd>+<kbd>Z</kbd> | Panel | Undo the last manual purge or shortcut purge |

## Install (Load unpacked)

1. Download and unzip the extension.
2. Open `chrome://extensions` and switch on **Developer mode** (top right).
3. Click **Load unpacked** and select the unzipped folder (the one that contains `manifest.json`).
4. Pin CookieClean from the puzzle-piece menu and click its icon to open the panel.

## Permissions

| Permission | Why |
| --- | --- |
| `cookies` + access to all sites | Reads and deletes cookies for any site you visit. Chrome only allows cookie access for sites the extension has host access to. |
| `storage` | Saves your settings, trusted sites and stats locally. Copies of recently cleaned cookies (for Restore) are kept in session memory only and disappear when the browser closes. |
| `notifications` | Shows the optional "Clear cookies?" prompt when you leave a site. |
| `alarms` | Runs the Cookie Age Limiter every 15 minutes, the optional scheduled cleaning, and pending cleanups after the *Wait before cleaning* delay. |
| `browsingData` | Only used when **Deep clean site data** is on: removes a cleaned site's localStorage, IndexedDB, cache and service workers. It is always limited to that site's own origins. |
| `scripting` | Only used when you open the panel: reads which domains the current page loaded (`performance` resource list) to build the Third-party view. Nothing is changed on the page and nothing is sent anywhere. The page cannot trigger any deletion: the extension has no content scripts and no message listeners. |

CookieClean works completely offline. It does not collect, send or sell any data.

## Notes

- Deleting a site's cookies will log you out of that site. Trust the sites where you want to stay signed in.
- Site data other than cookies (localStorage, IndexedDB, cache) is removed only when **Deep clean site data** is on, and only for the site being cleaned. Startup and scheduled cleaning remove cookies only. Restore brings back cookies, not site data.
- The Third-party view can't scan browser pages (`chrome://`) or the Chrome Web Store. It shows partitioned (CHIPS) cookies on Chrome 119 and later. *Delete all third-party* keeps cookies that a site open in another tab uses.
- Recently Cleaned keeps the last 12 cleanups (up to 4,000 cookies each) until the browser closes.
