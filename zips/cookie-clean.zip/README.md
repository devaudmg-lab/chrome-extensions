# CookieClean

A privacy-first cookie manager for Chrome. It removes tracking cookies automatically and keeps you logged in to the sites you trust.

## Features

- **One-click purge** of all cookies for the current site, or delete single cookies from the Active Site list.
- **Undo**: every manual purge shows an *Undo* button (or press <kbd>Ctrl</kbd>+<kbd>Z</kbd>) that puts the deleted cookies back, with their flags and expiry, while the panel is open.
- **Third-party cookies view**: the Active Site tab has a *This site / Third-party* switch. Third-party lists the other domains loaded by the page (ads, analytics, embeds) that store cookies, marks known trackers and partitioned cookies, and lets you delete them per domain or all at once.
- **Deep clean site data** (optional): when a site is cleaned (manually, on tab close or with the shortcut) also remove its localStorage, IndexedDB, Cache Storage, service workers and other site storage.
- **Scheduled cleaning** (optional): every hour, every 6 hours or once a day, delete all non-whitelisted cookies. Sites open in a tab are skipped. The Settings tab shows when it last ran.
- **Auto-clean on tab close**: when you close the last tab of a site, its cookies are deleted (whitelisted sites are skipped).
- **Clean when leaving a site** (optional): also cleans when a tab navigates to a different site.
- **Prompt mode** (optional): shows a desktop notification with *Clear Cookies* / *Whitelist Site* buttons instead of deleting right away.
- **Clean on browser startup**: removes all non-whitelisted cookies when Chrome starts (sites restored in open tabs are kept).
- **Whitelist ("Safe Havens")**: protects a domain and all its subdomains. Supports import and export (JSON or plain text, one domain per line).
- **Cookie Explorer**: lists every site storing cookies, with a high-risk filter (known trackers, long-lived cookies, too many cookies, insecure session cookies).
- **Privacy score** (A+ to F) for the active site.
- **Cookie Age Limiter**: shortens the lifetime of long-lived cookies to 24 hours, 7 days or 30 days.
- **Keyboard shortcut** <kbd>Alt</kbd>+<kbd>Shift</kbd>+<kbd>K</kbd>: purges the current site's cookies without opening the popup. You can change it at `chrome://extensions/shortcuts`.
- **Stats**: cookies cleared today, in the last 7 days and in total, a 14-day bar chart (hover a bar for the exact count), and today's count on the icon badge.
- **First-run tips** in the panel, and keyboard navigation: <kbd>1</kbd>-<kbd>4</kbd> switch tabs, <kbd>/</kbd> searches the Explorer, <kbd>Esc</kbd> leaves a text field.

## Keyboard shortcuts

| Keys | Where | Action |
| --- | --- | --- |
| <kbd>Alt</kbd>+<kbd>Shift</kbd>+<kbd>K</kbd> | Anywhere | Purge the current site's cookies (and site data when Deep clean is on) |
| <kbd>1</kbd> <kbd>2</kbd> <kbd>3</kbd> <kbd>4</kbd> | Panel | Active Site / Explorer / Whitelist / Settings |
| <kbd>/</kbd> | Panel | Search domains in the Explorer |
| <kbd>Ctrl</kbd>+<kbd>Z</kbd> | Panel | Undo the last purge |

## Install (Load unpacked)

1. Download and unzip the extension.
2. Open `chrome://extensions` and switch on **Developer mode** (top right).
3. Click **Load unpacked** and select the unzipped folder (the one that contains `manifest.json`).
4. Pin CookieClean from the puzzle-piece menu and click its icon to open the panel.

## Permissions

| Permission | Why |
| --- | --- |
| `cookies` + access to all sites | Reads and deletes cookies for any site you visit. Chrome only allows cookie access for sites the extension has host access to. |
| `storage` | Saves your settings, whitelist and stats locally. |
| `notifications` | Shows the optional "Clear cookies?" prompt when you leave a site. |
| `alarms` | Runs the Cookie Age Limiter every 15 minutes and the optional scheduled cleaning. |
| `browsingData` | Only used when **Deep clean site data** is on: removes a cleaned site's localStorage, IndexedDB, cache and service workers. It is always limited to that site's own origins. |
| `scripting` | Only used when you open the panel: reads which domains the current page loaded (`performance` resource list) to build the Third-party view. Nothing is changed on the page and nothing is sent anywhere. |

CookieClean works completely offline. It does not collect, send or sell any data.

## Notes

- Deleting a site's cookies will log you out of that site. Whitelist the sites where you want to stay signed in.
- Site data other than cookies (localStorage, IndexedDB, cache) is removed only when **Deep clean site data** is on, and only for the site being cleaned. Startup and scheduled cleaning remove cookies only.
- The Third-party view can't scan browser pages (`chrome://`) or the Chrome Web Store. It shows partitioned (CHIPS) cookies on Chrome 119 and later.
- Undo works while the panel stays open. Expired cookies are not restored.
