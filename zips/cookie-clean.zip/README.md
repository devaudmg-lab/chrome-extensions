# CookieClean

A privacy-first cookie manager for Chrome. It removes tracking cookies automatically and keeps you logged in to the sites you trust.

## Features

- **One-click purge** of all cookies for the current site, or delete single cookies from the Active Site list.
- **Auto-clean on tab close**: when you close the last tab of a site, its cookies are deleted (whitelisted sites are skipped).
- **Clean when leaving a site** (optional): also cleans when a tab navigates to a different site.
- **Prompt mode** (optional): shows a desktop notification with *Clear Cookies* / *Whitelist Site* buttons instead of deleting right away.
- **Clean on browser startup**: removes all non-whitelisted cookies when Chrome starts (sites restored in open tabs are kept).
- **Whitelist ("Safe Havens")**: protects a domain and all its subdomains. Supports import and export (JSON or plain text, one domain per line).
- **Cookie Explorer**: lists every site storing cookies, with a high-risk filter (known trackers, long-lived cookies, too many cookies, insecure session cookies).
- **Privacy score** (A+ to F) for the active site.
- **Cookie Age Limiter**: shortens the lifetime of long-lived cookies to 24 hours, 7 days or 30 days.
- **Keyboard shortcut** <kbd>Alt</kbd>+<kbd>Shift</kbd>+<kbd>K</kbd>: purges the current site's cookies without opening the popup. You can change it at `chrome://extensions/shortcuts`.
- **Stats**: shows how many cookies were cleared today and in total, with today's count on the icon badge.

## Install (Load unpacked)

1. Download and unzip the extension.
2. Open `chrome://extensions` and switch on **Developer mode** (top right).
3. Click **Load unpacked** and select the unzipped folder (the one that contains `manifest.json`).
4. Pin CookieClean from the puzzle-piece menu and click its icon to open the panel.

## Permissions

| Permission | Why |
| --- | --- |
| `cookies` + access to all sites | Reads and deletes cookies for any site you visit. Chrome only allows cookie access for sites the extension has host access to. |
| `storage` | Saves your settings, whitelist and stats locally. |
| `notifications` | Shows the optional "Clear cookies?" prompt when you leave a site. |
| `alarms` | Runs the Cookie Age Limiter every 15 minutes. |

CookieClean works completely offline. It does not collect, send or sell any data.

## Notes

- Deleting a site's cookies will log you out of that site. Whitelist the sites where you want to stay signed in.
- Partitioned third-party cookies (CHIPS) and other site data (localStorage, IndexedDB) are not removed.
