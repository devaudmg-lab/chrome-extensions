// CookieClean - shared cleaning rules, used by the service worker (importScripts)
// and the popup (<script>). Every path that deletes data goes through these rules so
// whitelisted sites, sites open in a tab and partitioned cookies are handled the same way.

const CC = (() => {
  const DEFAULT_SETTINGS = {
    extensionEnabled: true,
    autoDeleteOnTabClose: true,
    cleanOnDomainChange: false, // also clean when a tab navigates away to another site
    promptOnTabClose: false,
    cleanOnBrowserStart: true,
    cookieAgeLimit: "none", // "none", "1_day", "7_days", "30_days"
    clearSiteData: false, // also remove localStorage, IndexedDB, cache and service workers of a cleaned site
    scheduledClean: "off", // "off", "1h", "6h", "24h"
    cleanupDelay: 15, // seconds to wait after a site is left before cleaning it (0 = right away)
    whitelist: [], // always kept, e.g. ["github.com"]
    greylist: [] // kept while browsing, cleaned on browser startup
  };

  function mergeSettings(stored) {
    const s = { ...DEFAULT_SETTINGS, ...(stored || {}) };
    s.whitelist = cleanList(s.whitelist);
    s.greylist = cleanList(s.greylist).filter(d => !s.whitelist.includes(d));
    if (![0, 15, 60, 300].includes(Number(s.cleanupDelay))) s.cleanupDelay = DEFAULT_SETTINGS.cleanupDelay;
    s.cleanupDelay = Number(s.cleanupDelay);
    return s;
  }

  function cleanList(list) {
    if (!Array.isArray(list)) return [];
    const out = [];
    list.forEach(item => {
      const d = normalizeDomain(item);
      if (d && !out.includes(d)) out.push(d);
    });
    return out;
  }

  // Turn user input (URL, "*.example.com", ".example.com", "Example.com/path") into a bare hostname
  function normalizeDomain(input) {
    let value = String(input == null ? "" : input).trim().toLowerCase();
    if (!value) return "";
    try {
      if (/^[a-z][a-z0-9+.-]*:\/\//.test(value)) value = new URL(value).hostname;
    } catch (e) {
      return "";
    }
    value = value.split(/[\/?#:]/)[0].replace(/^\*\./, "").replace(/^\.+/, "").replace(/\.+$/, "");
    if (!/^[a-z0-9_-]+(\.[a-z0-9_-]+)*$/.test(value) || value.length > 253) return "";
    return value;
  }

  function stripDot(domain) {
    return domain && domain.startsWith(".") ? domain.substring(1) : (domain || "");
  }

  function baseHost(hostname) {
    return String(hostname || "").toLowerCase().replace(/^www\./, "");
  }

  // host equals domain or is one of its subdomains
  function hostMatches(host, domain) {
    return !!host && !!domain && (host === domain || host.endsWith("." + domain));
  }

  // Two hostnames belong to the same site if one is a subdomain of the other
  // or they share the same www-less host
  function sameSite(a, b) {
    if (!a || !b) return false;
    const ba = baseHost(a), bb = baseHost(b);
    return ba === bb || ba.endsWith("." + bb) || bb.endsWith("." + ba);
  }

  // Only http(s) pages carry cookies we manage
  function hostFromUrl(url) {
    if (!url) return null;
    try {
      const parsed = new URL(url);
      if (parsed.protocol !== "http:" && parsed.protocol !== "https:") return null;
      return parsed.hostname.toLowerCase();
    } catch (e) {
      return null;
    }
  }

  function partitionHost(cookie) {
    const site = cookie && cookie.partitionKey && cookie.partitionKey.topLevelSite;
    return site ? hostFromUrl(site) : null;
  }

  // A host (a site being cleaned, or an origin of its storage) is kept when a list entry
  // covers it: the entry itself, its subdomains, or the www/bare twin of the entry.
  function isHostListed(host, list) {
    if (!host || !Array.isArray(list)) return false;
    const h = stripDot(host).toLowerCase();
    return list.some(entry => {
      const e = String(entry).toLowerCase();
      return hostMatches(h, e) || baseHost(h) === baseHost(e);
    });
  }

  // A cookie is kept when it belongs to a listed site, or is a parent-domain cookie that
  // the browser sends to a listed site (".example.com" is sent to a whitelisted
  // "mail.example.com"), or lives in the partition of a listed top-level site.
  function isCookieListed(cookie, list) {
    if (!cookie || !Array.isArray(list) || !list.length) return false;
    const d = stripDot(cookie.domain).toLowerCase();
    const top = partitionHost(cookie);
    return list.some(entry => {
      const e = String(entry).toLowerCase();
      if (hostMatches(d, e) || baseHost(d) === baseHost(e)) return true;
      if (!cookie.hostOnly && hostMatches(e, d)) return true;
      if (top && (hostMatches(top, e) || hostMatches(e, top))) return true;
      return false;
    });
  }

  // Lists that protect a cookie right now. On browser startup only the whitelist counts;
  // the greylist ("until restart") is cleaned then.
  function protectedLists(settings, { startup = false } = {}) {
    return startup ? [settings.whitelist] : [settings.whitelist, settings.greylist || []];
  }

  function isHostProtected(host, settings, opts) {
    return protectedLists(settings, opts).some(list => isHostListed(host, list));
  }

  function isCookieProtected(cookie, settings, opts) {
    return protectedLists(settings, opts).some(list => isCookieListed(cookie, list));
  }

  // Hostnames of every http(s) tab, including tabs that are still loading
  async function openHosts(excludeTabId) {
    try {
      const tabs = await chrome.tabs.query({});
      const hosts = new Set();
      tabs.forEach(t => {
        if (t.id === excludeTabId) return;
        [t.url, t.pendingUrl].forEach(u => {
          const h = hostFromUrl(u);
          if (h) hosts.add(h);
        });
      });
      return Array.from(hosts);
    } catch (e) {
      return [];
    }
  }

  // The cookie is used by a site that is open in a tab (any window): it belongs to the
  // same site, is a parent-domain cookie sent to it, or lives in that site's partition.
  function isCookieInUse(cookie, hosts) {
    const d = stripDot(cookie.domain).toLowerCase();
    const top = partitionHost(cookie);
    return hosts.some(h => sameSite(h, d) || (top && sameSite(h, top)));
  }

  function cookieUrl(cookie) {
    return (cookie.secure ? "https://" : "http://") + stripDot(cookie.domain) + (cookie.path || "/");
  }

  function cookieKey(c) {
    return `${c.storeId}|${c.domain}|${c.path}|${c.name}|${c.partitionKey ? (c.partitionKey.topLevelSite || "") + (c.partitionKey.hasCrossSiteAncestor ? "+x" : "") : ""}`;
  }

  function dedupe(cookies) {
    const seen = new Set();
    return cookies.filter(c => {
      const key = cookieKey(c);
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }

  // getAll that also returns partitioned (CHIPS) cookies. Without a partitionKey Chrome
  // only returns unpartitioned cookies; partitionKey {} (Chrome 119+) returns both.
  async function getAllCookies(filter = {}) {
    try {
      return await chrome.cookies.getAll({ ...filter, partitionKey: {} });
    } catch (e) {
      try {
        return await chrome.cookies.getAll(filter);
      } catch (e2) {
        return [];
      }
    }
  }

  // Cookie store of a tab ("0" regular, "1" incognito); undefined = default store
  async function storeIdForTab(tabId) {
    if (tabId == null) return undefined;
    try {
      const stores = await chrome.cookies.getAllCookieStores();
      const store = stores.find(s => (s.tabIds || []).includes(tabId));
      return store ? store.id : undefined;
    } catch (e) {
      return undefined;
    }
  }

  // Every cookie of a site: cookies on the host and its subdomains, on the www-less base
  // host, parent-domain cookies sent to it, and partitioned cookies the site set.
  // withEmbedded also returns cookies other domains stored in this site's partition.
  async function getCookiesForSite(hostname, storeId, { withEmbedded = false } = {}) {
    const host = String(hostname).toLowerCase();
    const base = baseHost(host);
    const store = storeId ? { storeId } : {};
    const queries = [
      chrome.cookies.getAll({ ...store, domain: base }),
      chrome.cookies.getAll({ ...store, url: "https://" + host + "/" }),
      chrome.cookies.getAll({ ...store, url: "http://" + host + "/" })
    ];
    const results = await Promise.all(queries.map(q => q.catch(() => [])));
    const partitioned = (await getAllCookies(store)).filter(c => {
      if (!c.partitionKey) return false;
      const d = stripDot(c.domain);
      const top = partitionHost(c);
      if (sameSite(host, d) && (hostMatches(host, d) || hostMatches(d, base))) return true;
      return withEmbedded && top && sameSite(host, top);
    });
    return dedupe(results.flat().concat(partitioned));
  }

  async function removeCookie(cookie) {
    const details = { url: cookieUrl(cookie), name: cookie.name };
    if (cookie.storeId) details.storeId = cookie.storeId;
    if (cookie.partitionKey) details.partitionKey = cookie.partitionKey;
    const result = await chrome.cookies.remove(details);
    return !!result;
  }

  // Remove cookies; returns the cookies that were removed (kept for Restore)
  async function removeCookies(cookies) {
    const removed = [];
    for (const cookie of cookies) {
      try {
        if (await removeCookie(cookie)) removed.push(cookie);
      } catch (e) {
        console.warn(`CookieClean: could not remove cookie "${cookie.name}"`, e);
      }
    }
    return removed;
  }

  // Put cookies back with their flags, expiry and partition. Expired ones are skipped.
  async function restoreCookies(cookies) {
    const now = Date.now() / 1000;
    let restored = 0;
    for (const c of cookies) {
      if (c.expirationDate && c.expirationDate < now) continue;
      const details = {
        url: cookieUrl(c),
        name: c.name,
        value: c.value,
        path: c.path,
        secure: c.secure,
        httpOnly: c.httpOnly,
        sameSite: c.sameSite
      };
      if (c.storeId) details.storeId = c.storeId;
      // Host-only cookies must be set without a domain, or they become domain cookies
      if (!c.hostOnly) details.domain = c.domain;
      if (c.expirationDate) details.expirationDate = c.expirationDate;
      if (c.partitionKey) details.partitionKey = c.partitionKey;
      try {
        if (await chrome.cookies.set(details)) restored++;
      } catch (e) {
        console.warn(`CookieClean: could not restore cookie "${c.name}"`, e);
      }
    }
    return restored;
  }

  // Origins a site's storage can live under, minus origins that are protected or open
  function siteOrigins(hostname, settings, hosts = []) {
    const host = String(hostname).toLowerCase();
    const base = baseHost(host);
    const origins = [];
    new Set([host, base, "www." + base]).forEach(h => {
      if (isHostProtected(h, settings)) return;
      if (hosts.some(o => o === h || baseHost(o) === baseHost(h))) return;
      origins.push("https://" + h, "http://" + h);
    });
    return origins;
  }

  // Remove localStorage, IndexedDB, Cache Storage, service workers, etc. for one site
  async function clearSiteStorage(hostname, settings, hosts = []) {
    if (!chrome.browsingData) return false;
    const origins = siteOrigins(hostname, settings, hosts);
    if (!origins.length) return false;
    try {
      await chrome.browsingData.remove({ origins }, {
        cacheStorage: true,
        fileSystems: true,
        indexedDB: true,
        localStorage: true,
        serviceWorkers: true
      });
      return true;
    } catch (e) {
      console.warn(`CookieClean: could not clear site data for ${hostname}`, e);
      return false;
    }
  }

  // --- Recently cleaned (kept in memory only, chrome.storage.session) ---
  const RECENT_PREFIX = "recent:";
  const RECENT_MAX_ENTRIES = 12;
  const RECENT_MAX_COOKIES = 4000;
  const RECENT_MAX_BYTES = 4 * 1024 * 1024;

  function slimCookie(c) {
    const o = {
      name: c.name, value: c.value, domain: c.domain, path: c.path, secure: c.secure,
      httpOnly: c.httpOnly, sameSite: c.sameSite, hostOnly: c.hostOnly, storeId: c.storeId
    };
    if (c.expirationDate) o.expirationDate = c.expirationDate;
    if (c.partitionKey) o.partitionKey = c.partitionKey;
    return o;
  }

  // Keep what a cleanup removed so it can be restored until the browser closes
  async function recordCleanup({ label, source, cookies, dataCleared = false }) {
    if (!chrome.storage.session || !cookies || !cookies.length) return null;
    const at = Date.now();
    const id = at.toString(36) + Math.random().toString(36).slice(2, 7);
    const entry = {
      id, at, label, source, dataCleared,
      count: cookies.length,
      cookies: cookies.slice(0, RECENT_MAX_COOKIES).map(slimCookie)
    };
    try {
      await chrome.storage.session.set({ [RECENT_PREFIX + id]: entry });
      await pruneRecent();
      return id;
    } catch (e) {
      console.warn("CookieClean: could not keep the cleanup for Restore", e);
      return null;
    }
  }

  async function listRecent() {
    if (!chrome.storage.session) return [];
    const all = await chrome.storage.session.get(null);
    return Object.keys(all)
      .filter(k => k.startsWith(RECENT_PREFIX))
      .map(k => all[k])
      .filter(e => e && Array.isArray(e.cookies))
      .sort((a, b) => b.at - a.at);
  }

  async function pruneRecent() {
    const entries = await listRecent();
    let bytes = 0;
    const drop = [];
    entries.forEach((e, i) => {
      bytes += JSON.stringify(e).length;
      if (i >= RECENT_MAX_ENTRIES || bytes > RECENT_MAX_BYTES) drop.push(RECENT_PREFIX + e.id);
    });
    if (drop.length) await chrome.storage.session.remove(drop);
  }

  async function takeRecent(id) {
    const key = RECENT_PREFIX + id;
    const data = await chrome.storage.session.get(key);
    if (!data[key]) return null;
    await chrome.storage.session.remove(key);
    return data[key];
  }

  // --- Stats (read-modify-write so popup and worker don't overwrite each other) ---
  function dayKey(date = new Date()) {
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, "0");
    const d = String(date.getDate()).padStart(2, "0");
    return `${y}-${m}-${d}`;
  }

  async function addToStats(delta, at = Date.now()) {
    const data = await chrome.storage.local.get("stats");
    const stats = data.stats || { clearedTotal: 0, clearedToday: 0, lastResetDate: new Date().toDateString() };
    const todayStr = new Date().toDateString();
    if (stats.lastResetDate !== todayStr) {
      stats.clearedToday = 0;
      stats.lastResetDate = todayStr;
    }
    const history = stats.history && typeof stats.history === "object" ? stats.history : {};
    const key = dayKey(new Date(at));
    stats.clearedTotal = Math.max(0, (stats.clearedTotal || 0) + delta);
    if (key === dayKey()) stats.clearedToday = Math.max(0, (stats.clearedToday || 0) + delta);
    history[key] = Math.max(0, (history[key] || 0) + delta);
    const cutoff = dayKey(new Date(Date.now() - 30 * 24 * 60 * 60 * 1000));
    Object.keys(history).forEach(k => { if (k < cutoff) delete history[k]; });
    stats.history = history;
    await chrome.storage.local.set({ stats });
    return stats;
  }

  function badgeText(count) {
    return count > 0 ? (count > 9999 ? "9k+" : String(count)) : "";
  }

  return {
    DEFAULT_SETTINGS, mergeSettings, normalizeDomain, stripDot, baseHost, hostMatches, sameSite,
    hostFromUrl, partitionHost, isHostListed, isCookieListed, isHostProtected, isCookieProtected,
    openHosts, isCookieInUse, cookieUrl, cookieKey, dedupe, getAllCookies, storeIdForTab,
    getCookiesForSite, removeCookie, removeCookies, restoreCookies, siteOrigins, clearSiteStorage,
    recordCleanup, listRecent, takeRecent, dayKey, addToStats, badgeText
  };
})();

if (typeof module !== "undefined") module.exports = CC;
