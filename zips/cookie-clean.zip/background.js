// CookieClean - Background Service Worker (Manifest V3)

// In-memory tab-to-domain mapping to persist state during worker lifetime.
// We also use chrome.storage.session to ensure persistence if the service worker suspends.
let activeTabs = {};

// Default Settings
const DEFAULT_SETTINGS = {
  extensionEnabled: true,
  autoDeleteOnTabClose: true,
  cleanOnDomainChange: false, // also clean when a tab navigates away to another site
  promptOnTabClose: false,
  cleanOnBrowserStart: true,
  cookieAgeLimit: "none", // options: "none", "1_day", "7_days", "30_days"
  clearSiteData: false, // also remove localStorage, IndexedDB, cache and service workers of a cleaned site
  scheduledClean: "off", // options: "off", "1h", "6h", "24h"
  whitelist: [] // array of domains (e.g., ["github.com", "google.com"])
};

const SCHEDULE_MINUTES = { "1h": 60, "6h": 360, "24h": 1440 };
const SCHEDULE_ALARM = "scheduledCleanAlarm";

const NOTIFICATION_PREFIX = "cookieclean-prompt|";

// Helper: Load settings merged with defaults (handles keys added in newer versions)
async function getSettings() {
  const data = await chrome.storage.local.get("settings");
  const settings = { ...DEFAULT_SETTINGS, ...(data.settings || {}) };
  if (!Array.isArray(settings.whitelist)) settings.whitelist = [];
  return settings;
}

// Helper: Initialize session storage and settings
chrome.runtime.onInstalled.addListener(async () => {
  const data = await chrome.storage.local.get(["settings", "stats"]);
  // Merge defaults so new settings keys exist after an update
  await chrome.storage.local.set({ settings: { ...DEFAULT_SETTINGS, ...(data.settings || {}) } });
  if (!data.stats) {
    await chrome.storage.local.set({
      stats: { clearedTotal: 0, clearedToday: 0, lastResetDate: new Date().toDateString() }
    });
  }

  // Set up periodic alarm for Age Limiter (every 15 minutes)
  chrome.alarms.create("cookieAgeLimiterAlarm", { periodInMinutes: 15 });
  await syncScheduleAlarm();

  await seedOpenTabs();
  await refreshBadge();
});

// Helper: Get domain from a full URL (only http/https pages carry cookies we manage)
function getDomainFromUrl(url) {
  if (!url) return null;
  try {
    const parsed = new URL(url);
    if (parsed.protocol !== "http:" && parsed.protocol !== "https:") return null;
    return parsed.hostname;
  } catch (e) {
    return null;
  }
}

function stripDot(domain) {
  return domain && domain.startsWith('.') ? domain.substring(1) : domain;
}

// Helper: Check if domain or its parent domain is whitelisted
function isWhitelisted(domain, whitelist) {
  if (!domain || !whitelist) return false;

  // Normalize domain
  const cleanDomain = stripDot(domain).toLowerCase();

  for (const item of whitelist) {
    const cleanItem = String(item).toLowerCase();
    // Match exact domain or subdomains (e.g., if "example.com" is whitelisted, "sub.example.com" is also protected)
    if (cleanDomain === cleanItem || cleanDomain.endsWith("." + cleanItem)) {
      return true;
    }
  }
  return false;
}

// Record which site a tab is showing
async function rememberTab(tabId, domain) {
  activeTabs[tabId] = domain;
  if (chrome.storage.session) {
    await chrome.storage.session.set({ [tabId.toString()]: domain });
  }
}

async function recallTab(tabId) {
  let domain = activeTabs[tabId];
  if (!domain && chrome.storage.session) {
    const res = await chrome.storage.session.get(tabId.toString());
    domain = res[tabId.toString()];
  }
  return domain || null;
}

// Tabs that were open before install/startup are not seen by onUpdated; record them now
async function seedOpenTabs() {
  try {
    const tabs = await chrome.tabs.query({});
    for (const tab of tabs) {
      const domain = getDomainFromUrl(tab.url);
      if (domain) await rememberTab(tab.id, domain);
    }
  } catch (e) {
    console.error("CookieClean: Could not seed open tabs", e);
  }
}

// Track Tabs: Save domain when a tab updates its URL
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  const url = changeInfo.url || (changeInfo.status === "complete" ? tab.url : null);
  if (!url) return;
  const domain = getDomainFromUrl(url);
  if (!domain) return;

  const previous = await recallTab(tabId);
  await rememberTab(tabId, domain);

  // Optional: treat navigating away from a site like closing its tab
  if (previous && previous !== domain && !sameSite(previous, domain)) {
    const settings = await getSettings();
    if (settings.extensionEnabled && settings.autoDeleteOnTabClose && settings.cleanOnDomainChange) {
      await handleSiteLeft(previous, settings);
    }
  }
});

// Track Tabs: Handle Tab Removal and trigger cleanup
chrome.tabs.onRemoved.addListener(async (tabId) => {
  const domain = await recallTab(tabId);

  // Clean up maps
  delete activeTabs[tabId];
  if (chrome.storage.session) {
    await chrome.storage.session.remove(tabId.toString());
  }

  if (!domain) return;

  const settings = await getSettings();
  if (!settings.extensionEnabled || !settings.autoDeleteOnTabClose) return;

  await handleSiteLeft(domain, settings);
});

// Helper: two hostnames belong to the same site if one is a subdomain of the other
// or they share the same base (www-stripped) host
function sameSite(a, b) {
  if (!a || !b) return false;
  const ba = baseHost(a), bb = baseHost(b);
  return ba === bb || ba.endsWith("." + bb) || bb.endsWith("." + ba);
}

function baseHost(hostname) {
  return hostname.toLowerCase().replace(/^www\./, "");
}

// The user has left a site (closed its last tab or navigated away): clean or prompt
async function handleSiteLeft(domain, settings) {
  // Check if the domain is whitelisted
  if (isWhitelisted(domain, settings.whitelist)) return;

  // CRITICAL PROTECTION: don't clear cookies while another tab of this site is still open.
  const allTabs = await chrome.tabs.query({});
  const hasRemainingTab = allTabs.some(t => sameSite(getDomainFromUrl(t.url), domain));
  if (hasRemainingTab) return;

  if (settings.promptOnTabClose) {
    // The domain is encoded in the notification ID so the prompt still works
    // after the service worker has been suspended and restarted.
    const notificationId = NOTIFICATION_PREFIX + domain + "|" + Date.now();
    chrome.notifications.create(notificationId, {
      type: "basic",
      iconUrl: "icons/icon128.png",
      title: "CookieClean Protection",
      message: `You left "${domain}". Clear its cookies?`,
      buttons: [
        { title: "Clear Cookies" },
        { title: "Whitelist Site" }
      ],
      requireInteraction: true
    });
  } else {
    const clearedCount = await clearCookiesForDomain(domain, settings.whitelist);
    if (settings.clearSiteData) await clearSiteStorage(domain);
    if (clearedCount > 0) {
      await updateStats(clearedCount);
    }
  }
}

// Origins a site's storage can live under (host, www-less base host and www. variant)
function siteOrigins(hostname) {
  const base = baseHost(hostname);
  const hosts = new Set([hostname.toLowerCase(), base, "www." + base]);
  const origins = [];
  hosts.forEach(h => { origins.push("https://" + h, "http://" + h); });
  return origins;
}

// Remove localStorage, IndexedDB, Cache Storage, service workers, etc. for one site
async function clearSiteStorage(hostname) {
  if (!chrome.browsingData) return false;
  try {
    await chrome.browsingData.remove({ origins: siteOrigins(hostname) }, {
      cacheStorage: true,
      fileSystems: true,
      indexedDB: true,
      localStorage: true,
      serviceWorkers: true,
      webSQL: true
    });
    return true;
  } catch (e) {
    console.warn(`CookieClean: Could not clear site data for ${hostname}`, e);
    return false;
  }
}

function domainFromNotificationId(notificationId) {
  if (!notificationId.startsWith(NOTIFICATION_PREFIX)) return null;
  const parts = notificationId.substring(NOTIFICATION_PREFIX.length).split("|");
  return parts[0] || null;
}

// Handle Notification button clicks
chrome.notifications.onButtonClicked.addListener(async (notificationId, buttonIndex) => {
  const domain = domainFromNotificationId(notificationId);
  if (!domain) return;

  const settings = await getSettings();
  if (buttonIndex === 0) {
    // Button: Clear Cookies
    const clearedCount = await clearCookiesForDomain(domain, settings.whitelist);
    if (settings.clearSiteData) await clearSiteStorage(domain);
    if (clearedCount > 0) {
      await updateStats(clearedCount);
    }
  } else if (buttonIndex === 1) {
    // Button: Whitelist Site
    const entry = baseHost(domain);
    if (!settings.whitelist.includes(entry)) {
      settings.whitelist.push(entry);
      await chrome.storage.local.set({ settings });
    }
  }

  chrome.notifications.clear(notificationId);
});

// Helper: build the URL chrome.cookies.remove/set needs for a cookie
function cookieUrl(cookie) {
  const protocol = cookie.secure ? "https://" : "http://";
  return protocol + stripDot(cookie.domain) + cookie.path;
}

async function removeCookie(cookie) {
  const details = { url: cookieUrl(cookie), name: cookie.name, storeId: cookie.storeId };
  if (cookie.partitionKey) details.partitionKey = cookie.partitionKey;
  await chrome.cookies.remove(details);
}

// Helper: collect every cookie belonging to a site: cookies on the host and its
// subdomains, cookies on the www-less base host, and parent-domain cookies sent to it.
async function getCookiesForSite(hostname) {
  const base = baseHost(hostname);
  const queries = [
    chrome.cookies.getAll({ domain: base }),
    chrome.cookies.getAll({ url: "https://" + hostname + "/" }),
    chrome.cookies.getAll({ url: "http://" + hostname + "/" })
  ];
  const results = await Promise.all(queries.map(q => q.catch(() => [])));
  const seen = new Set();
  return results.flat().filter(c => {
    const key = `${c.storeId}|${c.domain}|${c.path}|${c.name}|${c.partitionKey ? JSON.stringify(c.partitionKey) : ""}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

// Helper: Clear all cookies for a site, skipping cookies of whitelisted (sub)domains
async function clearCookiesForDomain(domain, whitelist = []) {
  try {
    const cookies = await getCookiesForSite(domain);
    let clearedCount = 0;
    for (const cookie of cookies) {
      if (isWhitelisted(cookie.domain, whitelist)) continue;
      try {
        await removeCookie(cookie);
        clearedCount++;
      } catch (e) {
        console.error(`CookieClean: Error removing cookie "${cookie.name}"`, e);
      }
    }
    return clearedCount;
  } catch (error) {
    console.error(`CookieClean: Error clearing cookies for ${domain}`, error);
    return 0;
  }
}

// Helper: Update historical stats
async function updateStats(count) {
  const data = await chrome.storage.local.get("stats");
  const stats = data.stats || { clearedTotal: 0, clearedToday: 0, lastResetDate: new Date().toDateString() };

  const todayStr = new Date().toDateString();
  if (stats.lastResetDate !== todayStr) {
    stats.clearedToday = 0;
    stats.lastResetDate = todayStr;
  }

  stats.clearedTotal += count;
  stats.clearedToday += count;
  addToHistory(stats, count);

  await chrome.storage.local.set({ stats });

  // Update badge text on the icon dynamically to show today's cleared count
  updateBadgeText(stats.clearedToday);
}

// Daily history for the stats chart: { "2026-10-26": 42, ... }, last 30 days kept
function dayKey(date = new Date()) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

function addToHistory(stats, count) {
  const history = stats.history && typeof stats.history === "object" ? stats.history : {};
  const key = dayKey();
  history[key] = (history[key] || 0) + count;
  const cutoff = dayKey(new Date(Date.now() - 30 * 24 * 60 * 60 * 1000));
  Object.keys(history).forEach(k => { if (k < cutoff) delete history[k]; });
  stats.history = history;
}

// Helper: Update Badge text on icon
function updateBadgeText(count) {
  if (count > 0) {
    chrome.action.setBadgeText({ text: count > 9999 ? "9k+" : count.toString() });
    chrome.action.setBadgeBackgroundColor({ color: "#ff5e7e" }); // Coral accent
  } else {
    chrome.action.setBadgeText({ text: "" });
  }
}

// Badge shows today's count; reset it when the day has changed
async function refreshBadge() {
  const data = await chrome.storage.local.get("stats");
  const stats = data.stats;
  if (!stats) return updateBadgeText(0);
  updateBadgeText(stats.lastResetDate === new Date().toDateString() ? stats.clearedToday : 0);
}

// Browser Startup Cleanup
chrome.runtime.onStartup.addListener(async () => {
  await seedOpenTabs();
  await refreshBadge();

  await syncScheduleAlarm();

  const settings = await getSettings();
  if (!settings.extensionEnabled || !settings.cleanOnBrowserStart) return;

  await purgeAllExceptOpenAndWhitelisted(settings);
});

// Delete every non-whitelisted cookie, skipping sites open in a tab so nobody is
// logged out mid-page. Used by "Clean on browser startup" and scheduled cleaning.
async function purgeAllExceptOpenAndWhitelisted(settings) {
  const allCookies = await chrome.cookies.getAll({});
  if (!allCookies || allCookies.length === 0) return 0;

  const openTabs = await chrome.tabs.query({});
  const openDomains = openTabs.map(t => getDomainFromUrl(t.url)).filter(Boolean);

  let totalCleared = 0;
  for (const cookie of allCookies) {
    const domain = stripDot(cookie.domain);
    if (isWhitelisted(domain, settings.whitelist)) continue;
    if (openDomains.some(d => sameSite(d, domain))) continue;
    try {
      await removeCookie(cookie);
      totalCleared++;
    } catch (e) {
      console.error(`CookieClean: Error removing cookie "${cookie.name}"`, e);
    }
  }

  if (totalCleared > 0) {
    await updateStats(totalCleared);
  }
  return totalCleared;
}

// Scheduled cleaning: (re)create or remove the alarm to match the setting
async function syncScheduleAlarm() {
  const settings = await getSettings();
  const minutes = SCHEDULE_MINUTES[settings.scheduledClean];
  const existing = await chrome.alarms.get(SCHEDULE_ALARM);
  if (!minutes) {
    if (existing) await chrome.alarms.clear(SCHEDULE_ALARM);
    return;
  }
  if (existing && existing.periodInMinutes === minutes) return;
  await chrome.alarms.create(SCHEDULE_ALARM, { delayInMinutes: minutes, periodInMinutes: minutes });
}

async function runScheduledClean() {
  const settings = await getSettings();
  if (!settings.extensionEnabled || !SCHEDULE_MINUTES[settings.scheduledClean]) return;
  const cleared = await purgeAllExceptOpenAndWhitelisted(settings);
  await chrome.storage.local.set({ lastScheduledClean: { at: Date.now(), cleared } });
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local" || !changes.settings) return;
  const before = (changes.settings.oldValue || {}).scheduledClean;
  const after = (changes.settings.newValue || {}).scheduledClean;
  if (before !== after) syncScheduleAlarm();
});

// Keyboard shortcut: purge cookies for the active tab's site
chrome.commands.onCommand.addListener(async (command) => {
  if (command !== "purge-current-site") return;
  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  const domain = tab && getDomainFromUrl(tab.url);
  if (!domain) return;

  // Manual purge: same scope as the popup's "Purge Site Cookies" button
  const cleared = await clearCookiesForDomain(domain, []);
  const settings = await getSettings();
  if (settings.clearSiteData) await clearSiteStorage(domain);
  if (cleared > 0) {
    await updateStats(cleared);
  }

  // Brief per-tab confirmation on the icon
  try {
    await chrome.action.setBadgeText({ tabId: tab.id, text: cleared > 0 ? "✓" : "0" });
    await chrome.action.setBadgeBackgroundColor({ tabId: tab.id, color: cleared > 0 ? "#22c55e" : "#64748b" });
    setTimeout(() => {
      chrome.action.setBadgeText({ tabId: tab.id, text: "" }).catch(() => {});
      refreshBadge();
    }, 2500);
  } catch (e) {
    // Tab may have closed
  }
});

// Periodic Alarms: Handles Cookie Age Limiter
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === "cookieAgeLimiterAlarm") {
    await runCookieAgeLimiter();
  } else if (alarm.name === SCHEDULE_ALARM) {
    await runScheduledClean();
  }
});

// Listen to Cookie Changes (for real-time age limiting)
chrome.cookies.onChanged.addListener(async (changeInfo) => {
  // Only handle newly set or updated cookies (not removed ones)
  if (changeInfo.removed) return;

  const settings = await getSettings();
  if (!settings.extensionEnabled || settings.cookieAgeLimit === "none") return;

  const cookie = changeInfo.cookie;

  // Skip whitelisted domains
  if (isWhitelisted(cookie.domain, settings.whitelist)) return;

  // Limit age
  await enforceCookieAgeLimit(cookie, settings.cookieAgeLimit);
});

// Helper: Enforce cookie age limit on a single cookie
async function enforceCookieAgeLimit(cookie, ageLimitOption) {
  if (!cookie.expirationDate) return; // Session cookie, already safe

  let maxAgeSeconds = 0;
  switch (ageLimitOption) {
    case "1_day":
      maxAgeSeconds = 24 * 60 * 60;
      break;
    case "7_days":
      maxAgeSeconds = 7 * 24 * 60 * 60;
      break;
    case "30_days":
      maxAgeSeconds = 30 * 24 * 60 * 60;
      break;
    default:
      return;
  }

  const nowSeconds = Math.floor(Date.now() / 1000);
  const targetExpiration = nowSeconds + maxAgeSeconds;

  // If the cookie's expiration date is further out than target, trim it!
  // To avoid infinite loops, check if it exceeds the target by more than 10 seconds.
  if (cookie.expirationDate > targetExpiration + 10) {
    try {
      const details = {
        url: cookieUrl(cookie),
        name: cookie.name,
        value: cookie.value,
        // Host-only cookies must be set without a domain, or a duplicate domain cookie is created
        domain: cookie.hostOnly ? undefined : cookie.domain,
        path: cookie.path,
        secure: cookie.secure,
        httpOnly: cookie.httpOnly,
        sameSite: cookie.sameSite,
        expirationDate: targetExpiration,
        storeId: cookie.storeId
      };
      // Keep partitioned (CHIPS) cookies in their partition instead of creating an unpartitioned copy
      if (cookie.partitionKey) details.partitionKey = cookie.partitionKey;
      await chrome.cookies.set(details);
    } catch (e) {
      console.error(`CookieClean: Error enforcing age limit on cookie "${cookie.name}"`, e);
    }
  }
}

// Helper: Run age limiting across ALL current cookies
async function runCookieAgeLimiter() {
  const settings = await getSettings();
  if (!settings.extensionEnabled || settings.cookieAgeLimit === "none") return;

  const cookies = await chrome.cookies.getAll({});
  for (const cookie of cookies) {
    if (isWhitelisted(cookie.domain, settings.whitelist)) continue;
    await enforceCookieAgeLimit(cookie, settings.cookieAgeLimit);
  }
}
