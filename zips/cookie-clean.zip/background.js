// CookieClean - Background Service Worker (Manifest V3)
importScripts("cleaner-core.js");

// tabId -> { host, storeId }. Mirrored in chrome.storage.session ("tab:<id>") because the
// worker can be suspended at any time and loses this object.
const activeTabs = {};

const SCHEDULE_MINUTES = { "1h": 60, "6h": 360, "24h": 1440 };
const SCHEDULE_ALARM = "scheduledCleanAlarm";
const AGE_ALARM = "cookieAgeLimiterAlarm";
const PENDING_ALARM = "pendingCleanupAlarm";
const PENDING_PREFIX = "pending:";
const TAB_PREFIX = "tab:";
const NOTIFICATION_PREFIX = "cookieclean-prompt|";

async function getSettings() {
  const data = await chrome.storage.local.get("settings");
  return CC.mergeSettings(data.settings);
}

chrome.runtime.onInstalled.addListener(async () => {
  const data = await chrome.storage.local.get(["settings", "stats"]);
  // Merge defaults so new settings keys exist after an update
  await chrome.storage.local.set({ settings: CC.mergeSettings(data.settings) });
  if (!data.stats) {
    await chrome.storage.local.set({
      stats: { clearedTotal: 0, clearedToday: 0, lastResetDate: new Date().toDateString(), history: {} }
    });
  }
  // Tab keys of older versions were bare tab ids
  if (chrome.storage.session) {
    const session = await chrome.storage.session.get(null);
    const legacy = Object.keys(session).filter(k => /^\d+$/.test(k));
    if (legacy.length) await chrome.storage.session.remove(legacy);
  }
  await ensureAlarms();
  await seedOpenTabs();
  await refreshBadge();
});

// Browser startup: wait for restored tabs, then clean
chrome.runtime.onStartup.addListener(async () => {
  await ensureAlarms();
  await refreshBadge();
  await waitForTabsToSettle();
  await seedOpenTabs();

  const settings = await getSettings();
  if (!settings.extensionEnabled || !settings.cleanOnBrowserStart) return;
  await purgeAllExceptOpenAndProtected(settings, "startup");
});

async function ensureAlarms() {
  if (!(await chrome.alarms.get(AGE_ALARM))) {
    await chrome.alarms.create(AGE_ALARM, { periodInMinutes: 15 });
  }
  await syncScheduleAlarm();
}

// Session restore can add tabs after onStartup fires. Poll until the tab list stops
// changing (max ~10 s) so restored sites count as open and keep their cookies.
async function waitForTabsToSettle() {
  let last = -1, stable = 0;
  for (let i = 0; i < 14 && stable < 2; i++) {
    await new Promise(r => setTimeout(r, 700));
    const tabs = await chrome.tabs.query({});
    const loading = tabs.some(t => !t.url && !t.pendingUrl);
    if (tabs.length === last && !loading) stable++; else stable = 0;
    last = tabs.length;
  }
}

// --- Tab tracking ---
async function rememberTab(tabId, host, storeId) {
  const value = { host: host || null, storeId: storeId || null };
  activeTabs[tabId] = value;
  if (chrome.storage.session) await chrome.storage.session.set({ [TAB_PREFIX + tabId]: value });
}

async function recallTab(tabId) {
  let value = activeTabs[tabId];
  if (!value && chrome.storage.session) {
    const res = await chrome.storage.session.get(TAB_PREFIX + tabId);
    value = res[TAB_PREFIX + tabId];
  }
  return value && value.host ? value : null;
}

async function forgetTab(tabId) {
  delete activeTabs[tabId];
  if (chrome.storage.session) await chrome.storage.session.remove(TAB_PREFIX + tabId);
}

// Tabs that were open before install/startup are not seen by onUpdated; record them now
async function seedOpenTabs() {
  try {
    const [tabs, stores] = await Promise.all([chrome.tabs.query({}), chrome.cookies.getAllCookieStores()]);
    for (const tab of tabs) {
      const host = CC.hostFromUrl(tab.url || tab.pendingUrl);
      if (!host) continue;
      const store = stores.find(s => (s.tabIds || []).includes(tab.id));
      await rememberTab(tab.id, host, store && store.id);
    }
  } catch (e) {
    console.warn("CookieClean: could not read open tabs", e);
  }
}

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  const url = changeInfo.url || (changeInfo.status === "complete" ? tab.url : null);
  if (!url) return;
  const host = CC.hostFromUrl(url);
  const previous = await recallTab(tabId);
  if (previous && host === previous.host) return;

  // Navigating to a browser page (new tab page, settings) also leaves the site
  await rememberTab(tabId, host, host ? await CC.storeIdForTab(tabId) : null);

  if (previous && !(host && CC.sameSite(previous.host, host))) {
    const settings = await getSettings();
    if (settings.extensionEnabled && settings.autoDeleteOnTabClose && settings.cleanOnDomainChange) {
      await siteLeft(previous.host, previous.storeId, "leave", settings);
    }
  }
});

// Tab discarding and prerendering swap a tab for a new one with another id
chrome.tabs.onReplaced.addListener(async (addedTabId, removedTabId) => {
  const previous = await recallTab(removedTabId);
  await forgetTab(removedTabId);
  if (previous) await rememberTab(addedTabId, previous.host, previous.storeId);
});

chrome.tabs.onRemoved.addListener(async (tabId) => {
  const previous = await recallTab(tabId);
  await forgetTab(tabId);
  if (!previous) return;

  const settings = await getSettings();
  if (!settings.extensionEnabled || !settings.autoDeleteOnTabClose) return;
  await siteLeft(previous.host, previous.storeId, "tab-close", settings);
});

// --- Leaving a site: prompt, or queue a cleanup after the grace period ---
async function siteLeft(host, storeId, reason, settings) {
  if (CC.isHostProtected(host, settings)) return;

  if (settings.promptOnTabClose) {
    const hosts = await CC.openHosts();
    if (hosts.some(h => CC.sameSite(h, host))) return; // another tab still shows this site
    // Host and store are encoded in the notification ID so the prompt still works
    // after the service worker has been suspended and restarted.
    const notificationId = NOTIFICATION_PREFIX + host + "|" + (storeId || "") + "|" + Date.now();
    chrome.notifications.create(notificationId, {
      type: "basic",
      iconUrl: "icons/icon128.png",
      title: "CookieClean",
      message: `You left ${host}. Clear its cookies?`,
      buttons: [{ title: "Clear Cookies" }, { title: "Trust Site" }],
      requireInteraction: true
    });
    return;
  }
  // Open tabs are checked when the cleanup runs: while a window is closing, its other
  // tabs are still listed for a moment
  await queueCleanup(host, storeId, reason, settings.cleanupDelay);
}

// Pending cleanups live in session storage (one key each, so concurrent tab closes
// can't overwrite each other) and run from a timer, with an alarm as backup in case
// the worker is suspended first. Everything is checked again when the cleanup runs.
async function queueCleanup(host, storeId, reason, delaySeconds) {
  // Even with no delay, wait a moment so a closing window's other tabs are gone
  const delayMs = Math.max(1000, delaySeconds * 1000);
  const entry = { host, storeId: storeId || null, reason, due: Date.now() + delayMs };
  await chrome.storage.session.set({ [PENDING_PREFIX + (storeId || "") + "|" + host]: entry });
  setTimeout(processPending, delayMs + 50);
  await armPendingAlarm();
}

async function armPendingAlarm() {
  const pending = await listPending();
  if (!pending.length) {
    await chrome.alarms.clear(PENDING_ALARM);
    return;
  }
  const next = Math.min(...pending.map(p => p.due));
  // Chrome runs alarms no sooner than 30 s after creation
  await chrome.alarms.create(PENDING_ALARM, { when: Math.max(next, Date.now() + 30000) });
}

async function listPending() {
  if (!chrome.storage.session) return [];
  const all = await chrome.storage.session.get(null);
  return Object.keys(all).filter(k => k.startsWith(PENDING_PREFIX)).map(k => ({ key: k, ...all[k] }));
}

let processing = Promise.resolve();
function processPending() {
  processing = processing.then(runPending).catch(e => console.warn("CookieClean: cleanup failed", e));
  return processing;
}

async function runPending() {
  const due = (await listPending()).filter(p => p.due <= Date.now() + 250);
  if (due.length) {
    await chrome.storage.session.remove(due.map(p => p.key));
    const settings = await getSettings();
    for (const p of due) {
      if (!settings.extensionEnabled || !settings.autoDeleteOnTabClose) continue;
      await cleanSite(p.host, p.storeId, p.reason, settings);
    }
  }
  await armPendingAlarm();
}

// Clean a site the user has left. Re-checks the whitelist and open tabs at run time,
// and never touches a cookie that is protected or used by a site open in any tab.
async function cleanSite(host, storeId, source, settings) {
  if (CC.isHostProtected(host, settings)) return 0;
  const hosts = await CC.openHosts();
  if (hosts.some(h => CC.sameSite(h, host))) return 0; // the site was opened again

  const cookies = await CC.getCookiesForSite(host, storeId || undefined, { withEmbedded: true });
  const targets = cookies.filter(c => !CC.isCookieProtected(c, settings) && !CC.isCookieInUse(c, hosts));
  const removed = await CC.removeCookies(targets);
  const dataCleared = settings.clearSiteData ? await CC.clearSiteStorage(host, settings, hosts) : false;
  if (removed.length) {
    await CC.recordCleanup({ label: host, source, cookies: removed, dataCleared });
    await updateStats(removed.length);
  }
  return removed.length;
}

function parseNotificationId(notificationId) {
  if (!notificationId.startsWith(NOTIFICATION_PREFIX)) return null;
  const [host, storeId] = notificationId.substring(NOTIFICATION_PREFIX.length).split("|");
  return host ? { host, storeId: storeId || null } : null;
}

chrome.notifications.onButtonClicked.addListener(async (notificationId, buttonIndex) => {
  const info = parseNotificationId(notificationId);
  if (!info) return;
  chrome.notifications.clear(notificationId);

  const settings = await getSettings();
  if (buttonIndex === 0) {
    await cleanSite(info.host, info.storeId, "prompt", settings);
  } else if (buttonIndex === 1) {
    const entry = CC.baseHost(info.host);
    if (!settings.whitelist.includes(entry)) {
      settings.whitelist.push(entry);
      settings.greylist = settings.greylist.filter(d => d !== entry);
      await chrome.storage.local.set({ settings });
    }
  }
});

// --- Startup and scheduled cleaning ---
// Delete every cookie that is not protected and not used by a site open in a tab.
// On startup the greylist ("keep until restart") is cleaned too.
async function purgeAllExceptOpenAndProtected(settings, source) {
  const startup = source === "startup";
  const allCookies = await CC.getAllCookies();
  if (!allCookies.length) return 0;
  const hosts = await CC.openHosts();
  const targets = allCookies.filter(c =>
    !CC.isCookieProtected(c, settings, { startup }) && !CC.isCookieInUse(c, hosts));
  const removed = await CC.removeCookies(targets);
  if (removed.length) {
    await CC.recordCleanup({ label: startup ? "Browser startup" : "Scheduled cleaning", source, cookies: removed });
    await updateStats(removed.length);
  }
  return removed.length;
}

async function syncScheduleAlarm() {
  const settings = await getSettings();
  const minutes = SCHEDULE_MINUTES[settings.scheduledClean];
  const existing = await chrome.alarms.get(SCHEDULE_ALARM);
  if (!minutes) {
    if (existing) await chrome.alarms.clear(SCHEDULE_ALARM);
    return;
  }
  if (existing && existing.periodInMinutes === minutes) return;
  await chrome.alarms.create(SCHEDULE_ALARM, { delayInMinutes: minutes, periodInMinutes: minutes });
}

async function runScheduledClean() {
  const settings = await getSettings();
  if (!settings.extensionEnabled || !SCHEDULE_MINUTES[settings.scheduledClean]) return;
  const cleared = await purgeAllExceptOpenAndProtected(settings, "scheduled");
  await chrome.storage.local.set({ lastScheduledClean: { at: Date.now(), cleared } });
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local" || !changes.settings) return;
  const before = (changes.settings.oldValue || {}).scheduledClean;
  const after = (changes.settings.newValue || {}).scheduledClean;
  if (before !== after) syncScheduleAlarm();
});

// --- Stats and badge ---
async function updateStats(count) {
  const stats = await CC.addToStats(count);
  updateBadgeText(stats.clearedToday);
}

function updateBadgeText(count) {
  chrome.action.setBadgeText({ text: CC.badgeText(count) });
  if (count > 0) chrome.action.setBadgeBackgroundColor({ color: "#ff5e7e" });
}

async function refreshBadge() {
  const { stats } = await chrome.storage.local.get("stats");
  if (!stats) return updateBadgeText(0);
  updateBadgeText(stats.lastResetDate === new Date().toDateString() ? stats.clearedToday : 0);
}

// --- Keyboard shortcut: purge the active tab's site ---
chrome.commands.onCommand.addListener((command) => {
  if (command === "purge-current-site") purgeActiveSite();
});

async function purgeActiveSite() {
  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  const host = tab && CC.hostFromUrl(tab.url);
  if (!host) return;

  const settings = await getSettings();
  let cleared = 0;
  let blocked = false;
  if (CC.isHostProtected(host, settings)) {
    // A stray key press must not log you out of a trusted site
    blocked = true;
  } else {
    const storeId = await CC.storeIdForTab(tab.id);
    const cookies = await CC.getCookiesForSite(host, storeId);
    const removed = await CC.removeCookies(cookies.filter(c => !CC.isCookieProtected(c, settings)));
    const dataCleared = settings.clearSiteData ? await CC.clearSiteStorage(host, settings) : false;
    cleared = removed.length;
    if (cleared) {
      await CC.recordCleanup({ label: host, source: "shortcut", cookies: removed, dataCleared });
      await updateStats(cleared);
    }
  }

  // Brief per-tab confirmation on the icon
  try {
    const text = blocked ? "!" : cleared > 0 ? "✓" : "0";
    const color = blocked ? "#f59e0b" : cleared > 0 ? "#22c55e" : "#64748b";
    await chrome.action.setBadgeText({ tabId: tab.id, text });
    await chrome.action.setBadgeBackgroundColor({ tabId: tab.id, color });
    await chrome.action.setTitle({ tabId: tab.id, title: blocked
      ? `CookieClean: ${host} is trusted, nothing was deleted`
      : `CookieClean: deleted ${cleared} cookie${cleared === 1 ? "" : "s"} of ${host}. Open the panel to restore.` });
    setTimeout(() => {
      chrome.action.setBadgeText({ tabId: tab.id, text: "" }).catch(() => {});
      chrome.action.setTitle({ tabId: tab.id, title: chrome.runtime.getManifest().name }).catch(() => {});
      refreshBadge();
    }, 2500);
  } catch (e) {
    // Tab may have closed
  }
}

// --- Alarms ---
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === AGE_ALARM) {
    await runCookieAgeLimiter();
  } else if (alarm.name === SCHEDULE_ALARM) {
    await runScheduledClean();
  } else if (alarm.name === PENDING_ALARM) {
    await processPending();
  }
});

// --- Cookie Age Limiter ---
chrome.cookies.onChanged.addListener(async (changeInfo) => {
  if (changeInfo.removed) return;
  const settings = await getSettings();
  if (!settings.extensionEnabled || settings.cookieAgeLimit === "none") return;
  const cookie = changeInfo.cookie;
  if (CC.isCookieProtected(cookie, settings)) return;
  await enforceCookieAgeLimit(cookie, settings.cookieAgeLimit);
});

const AGE_LIMIT_SECONDS = { "1_day": 86400, "7_days": 7 * 86400, "30_days": 30 * 86400 };

async function enforceCookieAgeLimit(cookie, ageLimitOption) {
  if (!cookie.expirationDate) return; // Session cookie, already safe
  const maxAgeSeconds = AGE_LIMIT_SECONDS[ageLimitOption];
  if (!maxAgeSeconds) return;

  const targetExpiration = Math.floor(Date.now() / 1000) + maxAgeSeconds;
  // The 10 s margin stops the onChanged event of our own update from looping
  if (cookie.expirationDate <= targetExpiration + 10) return;
  const details = {
    url: CC.cookieUrl(cookie),
    name: cookie.name,
    value: cookie.value,
    path: cookie.path,
    secure: cookie.secure,
    httpOnly: cookie.httpOnly,
    sameSite: cookie.sameSite,
    expirationDate: targetExpiration,
    storeId: cookie.storeId
  };
  // Host-only cookies must be set without a domain, or a duplicate domain cookie is created
  if (!cookie.hostOnly) details.domain = cookie.domain;
  // Keep partitioned (CHIPS) cookies in their partition instead of creating an unpartitioned copy
  if (cookie.partitionKey) details.partitionKey = cookie.partitionKey;
  try {
    await chrome.cookies.set(details);
  } catch (e) {
    console.warn(`CookieClean: could not shorten cookie "${cookie.name}"`, e);
  }
}

async function runCookieAgeLimiter() {
  const settings = await getSettings();
  if (!settings.extensionEnabled || settings.cookieAgeLimit === "none") return;
  const cookies = await CC.getAllCookies();
  for (const cookie of cookies) {
    if (CC.isCookieProtected(cookie, settings)) continue;
    await enforceCookieAgeLimit(cookie, settings.cookieAgeLimit);
  }
}
