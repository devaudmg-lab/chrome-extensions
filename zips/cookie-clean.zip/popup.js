// CookieClean - Popup Control Panel Script

// State
let currentDomain = "";
let currentUrl = "";
let settings = {};
let stats = {};
let explorerFilter = "all"; // "all" or "suspicious"
let cookieView = "first"; // "first" (this site) or "third" (third-party cookies on this page)
let currentTabId = null;
let lastPurge = null; // { cookies: [...], label } kept while the panel is open, for Undo

// Default settings fallback
const DEFAULT_SETTINGS = {
  extensionEnabled: true,
  autoDeleteOnTabClose: true,
  cleanOnDomainChange: false,
  promptOnTabClose: false,
  cleanOnBrowserStart: true,
  cookieAgeLimit: "none",
  clearSiteData: false,
  scheduledClean: "off",
  whitelist: []
};

const TRACKER_PATTERNS = [
  'doubleclick', 'google-analytics', 'googleadservices', 'googlesyndication', 'googletagmanager', 'adnxs', 'rubiconproject',
  'pubmatic', 'quantserve', 'scorecardresearch', 'taboola', 'outbrain', 'criteo', 'facebook.net', 'facebook.com',
  'hotjar', 'crazyegg', 'adroll', 'amazon-adsystem', 'bluekai', 'optimizely', 'amplitude', 'bing.com', 'clarity.ms',
  'linkedin', 'tiktok', 'yandex', 'mixpanel', 'segment', 'hubspot', 'demdex', 'casalemedia', 'openx', 'teads'
];

// DOM Elements
const elements = {
  // Navigation Tabs
  tabButtons: document.querySelectorAll(".tab-btn"),
  tabPanels: document.querySelectorAll(".tab-panel"),

  // Global Toggle
  globalToggle: document.getElementById("global-toggle"),

  // Active Site Tab
  currentDomainText: document.getElementById("current-domain"),
  currentSiteStatus: document.getElementById("current-site-status"),
  currentCookieCount: document.getElementById("current-cookie-count"),
  privacyScore: document.getElementById("privacy-score"),
  siteFavicon: document.getElementById("site-favicon"),
  btnPurgeCurrent: document.getElementById("btn-purge-current"),
  btnWhitelistCurrent: document.getElementById("btn-whitelist-current"),
  whitelistCurrentText: document.getElementById("whitelist-current-text"),
  currentCookiesList: document.getElementById("current-cookies-list"),
  activeSiteCard: document.querySelector(".active-site-card"),

  // Explorer Tab
  explorerSearch: document.getElementById("explorer-search"),
  btnPurgeAll: document.getElementById("btn-purge-all"),
  explorerSitesList: document.getElementById("explorer-sites-list"),
  btnFilterAll: document.getElementById("btn-filter-all"),
  btnFilterSuspicious: document.getElementById("btn-filter-suspicious"),

  // Whitelist Tab
  whitelistInput: document.getElementById("whitelist-input"),
  btnAddWhitelist: document.getElementById("btn-add-whitelist"),
  whitelistSitesList: document.getElementById("whitelist-sites-list"),

  // Settings & Stats
  statsTotal: document.getElementById("stats-total"),
  statsToday: document.getElementById("stats-today"),
  btnResetStats: document.getElementById("btn-reset-stats"),
  statsWeek: document.getElementById("stats-week"),
  historyChart: document.getElementById("history-chart"),
  chartMax: document.getElementById("chart-max"),
  chartStart: document.getElementById("chart-start"),
  settingSiteData: document.getElementById("setting-site-data"),
  settingSchedule: document.getElementById("setting-schedule"),
  scheduleStatus: document.getElementById("schedule-status"),
  purgeCurrentText: document.getElementById("purge-current-text"),
  onboardingCard: document.getElementById("onboarding-card"),
  btnDismissOnboarding: document.getElementById("btn-dismiss-onboarding"),
  segFirst: document.getElementById("seg-first"),
  segThird: document.getElementById("seg-third"),
  segFirstCount: document.getElementById("seg-first-count"),
  segThirdCount: document.getElementById("seg-third-count"),
  thirdPartyList: document.getElementById("third-party-list"),

  settingAutoDelete: document.getElementById("setting-auto-delete"),
  settingDomainChange: document.getElementById("setting-domain-change"),
  btnExportWhitelist: document.getElementById("btn-export-whitelist"),
  btnImportWhitelist: document.getElementById("btn-import-whitelist"),
  whitelistImportFile: document.getElementById("whitelist-import-file"),
  appVersion: document.getElementById("app-version"),
  settingPrompt: document.getElementById("setting-prompt"),
  settingStartupClean: document.getElementById("setting-startup-clean"),
  settingAgeLimit: document.getElementById("setting-age-limit"),

  toastContainer: document.getElementById("toast-container")
};

// Initialize Popup
document.addEventListener("DOMContentLoaded", async () => {
  await loadSettingsAndStats();
  setupTabNavigation();
  await detectActiveTab();
  setupEventListeners();
  setupKeyboardShortcuts();
  updateDashboardCharts();
});

// Load Settings and Stats from Chrome Storage
async function loadSettingsAndStats() {
  const localData = await chrome.storage.local.get(["settings", "stats", "onboardingDone", "lastScheduledClean"]);
  elements.onboardingCard.hidden = !!localData.onboardingDone;
  settings = { ...DEFAULT_SETTINGS, ...(localData.settings || {}) };
  if (!Array.isArray(settings.whitelist)) settings.whitelist = [];
  elements.appVersion.innerText = "v" + chrome.runtime.getManifest().version;
  stats = localData.stats || { clearedTotal: 0, clearedToday: 0, lastResetDate: new Date().toDateString() };
  if (stats.lastResetDate !== new Date().toDateString()) {
    stats.clearedToday = 0;
  }

  // Bind UI Controls
  elements.globalToggle.checked = settings.extensionEnabled;
  elements.settingAutoDelete.checked = settings.autoDeleteOnTabClose;
  elements.settingDomainChange.checked = settings.cleanOnDomainChange;
  elements.settingPrompt.checked = settings.promptOnTabClose;
  elements.settingStartupClean.checked = settings.cleanOnBrowserStart;
  elements.settingAgeLimit.value = settings.cookieAgeLimit;
  elements.settingSiteData.checked = settings.clearSiteData;
  elements.settingSchedule.value = settings.scheduledClean;
  updatePurgeLabel();
  updateScheduleStatus(localData.lastScheduledClean);

  // Stats
  elements.statsTotal.innerText = stats.clearedTotal;
  elements.statsToday.innerText = stats.clearedToday;

  // Toggle display mode based on extension status
  toggleExtensionUIState(settings.extensionEnabled);
}

// Enable/Disable UI styling based on global switch
function updatePurgeLabel() {
  elements.purgeCurrentText.innerText = settings.clearSiteData ? "Purge Cookies & Data" : "Purge Site Cookies";
  elements.btnPurgeCurrent.title = settings.clearSiteData
    ? "Delete this site's cookies, localStorage, IndexedDB, cache and service workers"
    : "Delete all cookies of this site";
}

function updateScheduleStatus(last) {
  if (settings.scheduledClean === "off") {
    elements.scheduleStatus.innerText = "";
    return;
  }
  elements.scheduleStatus.innerText = last && last.at
    ? `Last run ${new Date(last.at).toLocaleString([], { dateStyle: "medium", timeStyle: "short" })}: ${last.cleared} cookie${last.cleared === 1 ? "" : "s"} removed.`
    : "First run is one interval from now.";
}

function toggleExtensionUIState(isEnabled) {
  const wrapper = document.querySelector(".tab-content-wrapper");
  if (isEnabled) {
    wrapper.style.opacity = "1";
    wrapper.style.pointerEvents = "auto";
  } else {
    wrapper.style.opacity = "0.4";
    wrapper.style.pointerEvents = "none";
    showToast("CookieClean is currently disabled.", "error");
  }
}

function switchToTab(tabId) {
  const btn = Array.from(elements.tabButtons).find(b => b.getAttribute("data-tab") === tabId);
  if (btn) btn.click();
}

// Keyboard shortcuts inside the panel
function setupKeyboardShortcuts() {
  const order = ["tab-active-site", "tab-explorer", "tab-whitelist", "tab-settings"];
  document.addEventListener("keydown", (e) => {
    const tag = (e.target.tagName || "").toLowerCase();
    const typing = tag === "input" || tag === "textarea" || tag === "select";
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "z" && !typing) {
      if (lastPurge) {
        e.preventDefault();
        undoLastPurge();
      }
      return;
    }
    if (e.key === "Escape" && typing) {
      e.target.blur();
      return;
    }
    if (typing || e.ctrlKey || e.metaKey || e.altKey) return;
    if (/^[1-4]$/.test(e.key)) {
      switchToTab(order[Number(e.key) - 1]);
    } else if (e.key === "/") {
      e.preventDefault();
      switchToTab("tab-explorer");
      elements.explorerSearch.focus();
    }
  });
}

// Setup Tab Navigation
function setupTabNavigation() {
  elements.tabButtons.forEach(btn => {
    btn.addEventListener("click", () => {
      // Remove active from buttons
      elements.tabButtons.forEach(b => b.classList.remove("active"));
      btn.classList.add("active");

      // Toggle panels
      const targetTab = btn.getAttribute("data-tab");
      elements.tabPanels.forEach(panel => {
        if (panel.id === targetTab) {
          panel.classList.add("active");
          // Action triggers on opening tabs
          if (targetTab === "tab-explorer") {
            loadExplorerData();
          } else if (targetTab === "tab-whitelist") {
            renderWhitelist();
          }
        } else {
          panel.classList.remove("active");
        }
      });
    });
  });
}

// Helper: Extract apex domain (e.g. google.com from accounts.google.com)
function getApexDomain(domain) {
  if (!domain) return "";
  const parts = domain.split(".");
  if (parts.length > 2) {
    // Basic logic for generic domains. Handles co.uk, com.au, etc. simply
    const secondLast = parts[parts.length - 2];
    if (["com", "co", "org", "net", "gov", "edu"].includes(secondLast) && parts.length > 2) {
      return parts.slice(-3).join(".");
    }
    return parts.slice(-2).join(".");
  }
  return domain;
}

// Detect the current active tab
async function detectActiveTab() {
  try {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tabs.length === 0) return;

    const tab = tabs[0];
    currentUrl = tab.url;
    currentTabId = tab.id;

    if (!currentUrl || currentUrl.startsWith("chrome://") || currentUrl.startsWith("chrome-extension://") || currentUrl.startsWith("edge://") || currentUrl.startsWith("about:")) {
      // System or Extension page
      elements.currentDomainText.innerText = "System Page";
      elements.currentDomainText.title = "System Page";
      elements.currentSiteStatus.className = "status-indicator safe";
      elements.currentSiteStatus.innerText = "Secure Zone";
      elements.currentCookieCount.innerText = "0";
      elements.privacyScore.innerText = "N/A";
      elements.btnPurgeCurrent.disabled = true;
      elements.btnWhitelistCurrent.disabled = true;
      elements.currentCookiesList.innerHTML = `<p class="empty-message">No cookies can be read on browser system pages.</p>`;
      elements.segFirstCount.innerText = "0";
      elements.segThirdCount.innerText = "0";
      elements.thirdPartyList.innerHTML = `<p class="empty-message">Open a website to see its third-party cookies.</p>`;
      return;
    }

    const urlObj = new URL(currentUrl);
    currentDomain = urlObj.hostname;

    elements.currentDomainText.innerText = currentDomain;
    elements.currentDomainText.title = currentDomain;

    // Favicon loading
    if (tab.favIconUrl) {
      elements.siteFavicon.innerHTML = `<img src="${escapeHtml(tab.favIconUrl)}" width="20" height="20" style="object-fit: contain;">`;
    } else {
      elements.siteFavicon.innerText = "🌐";
    }

    await loadActiveSiteCookies();
    // Count third-party cookies up front so the switch shows the number
    loadThirdPartyCookies();
  } catch (error) {
    console.error("CookieClean: Active tab detection failed", error);
    elements.currentDomainText.innerText = "Access Blocked";
    elements.currentCookiesList.innerHTML = `<p class="empty-message">Unable to query cookies. Check site permissions.</p>`;
  }
}

// Load cookies for the active domain
async function loadActiveSiteCookies() {
  if (!currentDomain) return;

  // Check if whitelisted
  const whitelisted = isWhitelisted(currentDomain, settings.whitelist);
  updateActiveSiteCardStyle(whitelisted);

  try {
    const cookies = await getSiteCookies();
    const count = cookies.length;

    // Display count
    elements.currentCookieCount.innerText = count;
    elements.segFirstCount.innerText = count;

    // Calculate score
    const scoreInfo = calculatePrivacyScore(cookies);
    elements.privacyScore.innerText = scoreInfo.grade;
    elements.privacyScore.className = `stat-num ${scoreInfo.class}`;

    // Render list
    renderActiveSiteCookiesList(cookies);

  } catch (error) {
    console.error("Error reading cookies", error);
    elements.currentCookieCount.innerText = "Error";
    elements.privacyScore.innerText = "F";
  }
}

// Cookies for the active site: those sent to the page URL (incl. parent-domain cookies)
// plus cookies set on the host and its subdomains
async function getSiteCookies() {
  const [byUrl, byDomain] = await Promise.all([
    chrome.cookies.getAll({ url: currentUrl }),
    chrome.cookies.getAll({ domain: currentDomain })
  ]);
  const seen = new Set();
  return [...byUrl, ...byDomain].filter(c => {
    const key = `${c.storeId}|${c.domain}|${c.path}|${c.name}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

// Helper: Check if domain matches whitelist (subdomains included)
function isWhitelisted(domain, whitelist) {
  if (!domain || !whitelist) return false;
  const cleanDomain = domain.toLowerCase();
  for (const item of whitelist) {
    const cleanItem = item.toLowerCase();
    if (cleanDomain === cleanItem || cleanDomain.endsWith("." + cleanItem)) {
      return true;
    }
  }
  return false;
}

// Helper: Check if a domain has suspicious characteristics or tracking cookies
function checkDomainSuspicion(domain, cookies) {
  const reasons = [];

  // 1. Tracker patterns check
  const isTrackerName = isTrackerDomain(domain);
  if (isTrackerName) {
    reasons.push("Known tracker/analytics domain");
  }

  // 2. High Cookie Count
  if (cookies.length > 15) {
    reasons.push(`Excessive cookies stored (${cookies.length})`);
  }

  // 3. Persistent Beacons (long expiration)
  const twoYearsSeconds = 2 * 365 * 24 * 60 * 60;
  const nowSeconds = Math.floor(Date.now() / 1000);
  const hasLongLived = cookies.some(c => c.expirationDate && (c.expirationDate - nowSeconds) > twoYearsSeconds);
  if (hasLongLived) {
    reasons.push("Contains persistent tracking cookies (> 2 years)");
  }

  // 4. Sensitive but Insecure
  const sensitiveNames = ['session', 'sid', 'token', 'auth', 'login', 'jwt', 'user'];
  const hasInsecureSensitive = cookies.some(c => {
    const nameLower = c.name.toLowerCase();
    const isSensitive = sensitiveNames.some(s => nameLower.includes(s));
    return isSensitive && (!c.secure || !c.httpOnly);
  });
  if (hasInsecureSensitive) {
    reasons.push("Sensitive login/session cookies lack Secure or HttpOnly protection");
  }

  return {
    isSuspicious: reasons.length > 0,
    reasons: reasons
  };
}

// Update Active Site Card Styling
function updateActiveSiteCardStyle(isWhitelisted) {
  elements.activeSiteCard.className = "card active-site-card";
  if (isWhitelisted) {
    elements.activeSiteCard.classList.add("whitelisted-site");
    elements.currentSiteStatus.className = "status-indicator warn";
    elements.currentSiteStatus.innerText = "Trusted (Safe)";
    elements.whitelistCurrentText.innerText = "Remove Trust (Delete)";
    elements.btnWhitelistCurrent.querySelector(".icon-shield").style.stroke = "var(--color-yellow)";
  } else {
    elements.activeSiteCard.classList.add("unsafe-site");
    elements.currentSiteStatus.className = "status-indicator danger";
    elements.currentSiteStatus.innerText = "Monitored";
    elements.whitelistCurrentText.innerText = "Trust Site (Whitelist)";
    elements.btnWhitelistCurrent.querySelector(".icon-shield").style.stroke = "currentColor";
  }
}

// Calculate Privacy Score (A+ to F)
function calculatePrivacyScore(cookies) {
  if (!cookies || cookies.length === 0) {
    return { grade: "A+", class: "safe" };
  }

  let points = 100;

  // Deduct based on cookie count
  if (cookies.length > 50) points -= 35;
  else if (cookies.length > 30) points -= 25;
  else if (cookies.length > 15) points -= 15;
  else if (cookies.length > 5) points -= 8;

  // Secure and HttpOnly flags check
  let insecureCount = 0;
  let missingHttpOnlyCount = 0;

  cookies.forEach(c => {
    if (!c.secure) insecureCount++;
    if (!c.httpOnly) missingHttpOnlyCount++;
  });

  const percentInsecure = (insecureCount / cookies.length) * 100;
  const percentMissingHttpOnly = (missingHttpOnlyCount / cookies.length) * 100;

  if (percentInsecure > 50) points -= 15;
  else if (percentInsecure > 20) points -= 8;

  if (percentMissingHttpOnly > 50) points -= 15;
  else if (percentMissingHttpOnly > 20) points -= 8;

  let grade = "A";
  let gradeClass = "safe";

  if (points >= 95) { grade = "A+"; gradeClass = "safe"; }
  else if (points >= 88) { grade = "A"; gradeClass = "safe"; }
  else if (points >= 80) { grade = "B"; gradeClass = "warn"; }
  else if (points >= 70) { grade = "C"; gradeClass = "warn"; }
  else if (points >= 55) { grade = "D"; gradeClass = "danger"; }
  else { grade = "F"; gradeClass = "danger"; }

  return { grade, class: gradeClass };
}

let cachedSiteCookies = [];

// Render active site cookies in detail panel
function renderActiveSiteCookiesList(cookies) {
  const savedScrollTop = elements.currentCookiesList.scrollTop;

  cachedSiteCookies = cookies || [];
  if (!cookies || cookies.length === 0) {
    elements.currentCookiesList.innerHTML = `<p class="empty-message">No cookies stored by this site.</p>`;
    return;
  }

  let html = "";
  cookies.forEach(cookie => {
    const isSecure = cookie.secure;
    const isHttpOnly = cookie.httpOnly;
    const expiryStr = cookie.expirationDate
      ? new Date(cookie.expirationDate * 1000).toLocaleDateString()
      : "Session";

    html += `
      <div class="cookie-item">
        <div class="cookie-meta">
          <div class="cookie-name" title="${escapeHtml(cookie.name)}">${escapeHtml(cookie.name)}</div>
          <div class="cookie-submeta">
            <span>Exp: ${expiryStr}</span>
            ${isSecure ? '<span class="badge-tag secure">Secure</span>' : ''}
            ${isHttpOnly ? '<span class="badge-tag">HttpOnly</span>' : ''}
          </div>
        </div>
        <button class="btn-icon btn-delete-single" data-name="${encodeURIComponent(cookie.name)}" data-secure="${cookie.secure}" data-domain="${encodeURIComponent(cookie.domain)}" data-store="${encodeURIComponent(cookie.storeId)}" data-path="${encodeURIComponent(cookie.path)}">
          <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="3 6 5 6 21 6"></polyline>
            <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
          </svg>
        </button>
      </div>
    `;
  });

  elements.currentCookiesList.innerHTML = html;
  elements.currentCookiesList.scrollTop = savedScrollTop;

  // Bind single delete actions
  elements.currentCookiesList.querySelectorAll(".btn-delete-single").forEach(btn => {
    btn.addEventListener("click", async (e) => {
      const name = decodeURIComponent(btn.getAttribute("data-name"));
      const path = decodeURIComponent(btn.getAttribute("data-path"));
      const isSecure = btn.getAttribute("data-secure") === "true";

      const protocol = isSecure ? "https://" : "http://";
      const cookieDomain = decodeURIComponent(btn.getAttribute("data-domain"));
      const storeId = decodeURIComponent(btn.getAttribute("data-store"));
      const cleanDomain = cookieDomain.startsWith('.') ? cookieDomain.substring(1) : cookieDomain;
      const url = protocol + cleanDomain + path;

      try {
        const cookie = cachedSiteCookies.find(c => c.name === name && c.domain === cookieDomain && c.path === path && c.storeId === storeId);
        if (cookie) {
          await removeCookies([cookie], `cookie "${name}"`);
        } else {
          await chrome.cookies.remove({ url, name, storeId });
        }
        showUndoToast(`Cleared cookie: ${name}`);
        await loadActiveSiteCookies();
        await updateClearedCount(1);
      } catch (err) {
        showToast("Error clearing cookie.", "error");
      }
    });
  });
}

// TAB 2: Load Explorer Data (All Cookies)
async function loadExplorerData(preserveScroll = false) {
  const savedScrollTop = preserveScroll ? elements.explorerSitesList.scrollTop : 0;
  if (!preserveScroll) {
    elements.explorerSitesList.innerHTML = `<p class="loading-message">Reading cookies...</p>`;
  }

  try {
    const cookies = await chrome.cookies.getAll({});

    // Group by site domain
    const sites = {};
    cookies.forEach(cookie => {
      // Strip leading dot
      const domain = cookie.domain.startsWith('.') ? cookie.domain.substring(1) : cookie.domain;
      if (!sites[domain]) {
        sites[domain] = [];
      }
      sites[domain].push(cookie);
    });

    const searchQuery = elements.explorerSearch.value.trim().toLowerCase();

    // Process and analyze domains
    let processedDomains = Object.keys(sites).map(domain => {
      const suspicion = checkDomainSuspicion(domain, sites[domain]);
      return {
        domain,
        cookies: sites[domain],
        suspicion
      };
    });

    // Filter by search query
    processedDomains = processedDomains.filter(item => item.domain.includes(searchQuery));

    // Filter by high risk if toggle is on
    if (explorerFilter === "suspicious") {
      processedDomains = processedDomains.filter(item => item.suspicion.isSuspicious);
    }

    // Sort by cookie count descending
    processedDomains.sort((a, b) => b.cookies.length - a.cookies.length);

    if (processedDomains.length === 0) {
      elements.explorerSitesList.innerHTML = `<p class="empty-message">No matching cookies found.</p>`;
      return;
    }

    let html = "";
    processedDomains.forEach(item => {
      const domain = item.domain;
      const count = item.cookies.length;
      const whitelisted = isWhitelisted(domain, settings.whitelist);
      const suspicion = item.suspicion;

      let badgeHtml = "";
      if (whitelisted) {
        badgeHtml = '• <span style="color:var(--color-yellow)">Protected</span>';
      } else if (suspicion.isSuspicious) {
        badgeHtml = '• <span style="color:var(--color-coral); font-weight:600;">⚠️ High Risk</span>';
      }

      let reasonsHtml = "";
      if (suspicion.isSuspicious) {
        reasonsHtml = `<span class="suspicious-reasons">Risk: ${suspicion.reasons.join('; ')}</span>`;
      }

      html += `
        <div class="site-row">
          <div class="site-domain-info">
            <span class="site-name" title="${escapeHtml(domain)}">${escapeHtml(domain)}</span>
            <span class="site-cookies-tag">${count} cookie${count > 1 ? 's' : ''} ${badgeHtml}</span>
            ${reasonsHtml}
          </div>
          <div class="site-actions">
            <button class="btn-icon btn-purge-site" data-domain="${escapeHtml(domain)}" title="Clear cookies for ${escapeHtml(domain)}">
              <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2">
                <polyline points="3 6 5 6 21 6"></polyline>
                <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
              </svg>
            </button>
          </div>
        </div>
      `;
    });

    elements.explorerSitesList.innerHTML = html;
    if (preserveScroll) {
      elements.explorerSitesList.scrollTop = savedScrollTop;
    }

    // Bind clean actions
    elements.explorerSitesList.querySelectorAll(".btn-purge-site").forEach(btn => {
      btn.addEventListener("click", async () => {
        const domain = btn.getAttribute("data-domain");
        btn.disabled = true;

        const count = await clearCookiesForDomain(domain);
        if (count > 0) {
          showUndoToast(`Cleared ${count} cookies for ${domain}`);
          await updateClearedCount(count);
          if (domain === currentDomain) {
            await loadActiveSiteCookies();
          }
          await loadExplorerData(true);
        } else {
          showToast("No cookies cleared.");
          btn.disabled = false;
        }
      });
    });

  } catch (err) {
    console.error("Explorer load error", err);
    elements.explorerSitesList.innerHTML = `<p class="empty-message">Error querying cookie store.</p>`;
  }
}

// TAB 3: Render Whitelist
function renderWhitelist() {
  const list = settings.whitelist || [];

  if (list.length === 0) {
    elements.whitelistSitesList.innerHTML = `<p class="empty-message">No safe domains configured yet.</p>`;
    return;
  }

  let html = "";
  list.forEach(domain => {
    html += `
      <div class="whitelist-item">
        <span>${escapeHtml(domain)}</span>
        <button class="btn-icon btn-remove-whitelist" data-domain="${escapeHtml(domain)}">
          <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2">
            <line x1="18" y1="6" x2="6" y2="18"></line>
            <line x1="6" y1="6" x2="18" y2="18"></line>
          </svg>
        </button>
      </div>
    `;
  });

  elements.whitelistSitesList.innerHTML = html;

  // Bind removal actions
  elements.whitelistSitesList.querySelectorAll(".btn-remove-whitelist").forEach(btn => {
    btn.addEventListener("click", async () => {
      const domain = btn.getAttribute("data-domain");
      settings.whitelist = settings.whitelist.filter(d => d !== domain);
      await saveSettings();
      renderWhitelist();
      showToast(`Removed "${domain}" from whitelist.`);

      // Update active card styling if active domain matches
      if (domain === currentDomain) {
        updateActiveSiteCardStyle(false);
      }
    });
  });
}

// Add event listeners
function setupEventListeners() {
  // First-run card
  elements.btnDismissOnboarding.addEventListener("click", () => {
    elements.onboardingCard.hidden = true;
    chrome.storage.local.set({ onboardingDone: true });
  });

  // This site / Third-party switch
  [elements.segFirst, elements.segThird].forEach(btn => {
    btn.addEventListener("click", () => setCookieView(btn.dataset.view));
  });

  // Global switch
  elements.globalToggle.addEventListener("change", async (e) => {
    settings.extensionEnabled = e.target.checked;
    await saveSettings();
    toggleExtensionUIState(settings.extensionEnabled);
    if (settings.extensionEnabled) {
      showToast("CookieClean protection is ON.");
    } else {
      showToast("CookieClean protection is OFF.", "error");
    }
  });

  // Active Tab Purge Button
  elements.btnPurgeCurrent.addEventListener("click", async () => {
    if (!currentDomain) return;
    elements.btnPurgeCurrent.disabled = true;

    // Quick rolling numbers animation helper
    let counter = parseInt(elements.currentCookieCount.innerText) || 0;
    const interval = setInterval(() => {
      if (counter <= 0) {
        clearInterval(interval);
      } else {
        counter = Math.max(0, counter - Math.ceil(counter / 5));
        elements.currentCookieCount.innerText = counter;
      }
    }, 40);

    let cleared = 0;
    let dataCleared = false;
    try {
      const siteCookies = await getSiteCookies();
      cleared = await removeCookies(siteCookies, currentDomain);
      if (settings.clearSiteData) dataCleared = await clearSiteStorage(currentDomain);
    } catch (error) {
      console.error(`Error deleting cookies for ${currentDomain}`, error);
    }
    clearInterval(interval);

    elements.currentCookieCount.innerText = "0";
    elements.privacyScore.innerText = "A+";
    elements.privacyScore.className = "stat-num safe";
    elements.currentCookiesList.innerHTML = `<p class="empty-message">No cookies stored by this site.</p>`;
    elements.segFirstCount.innerText = "0";
    cachedSiteCookies = [];

    const message = `Purged ${cleared} cookie${cleared === 1 ? "" : "s"}${dataCleared ? " and site data" : ""}.`;
    if (cleared > 0) showUndoToast(message); else showToast(message);
    await updateClearedCount(cleared);

    setTimeout(() => {
      elements.btnPurgeCurrent.disabled = false;
    }, 1000);
  });

  // Active Tab Whitelist Button
  elements.btnWhitelistCurrent.addEventListener("click", async () => {
    if (!currentDomain) return;

    if (isWhitelisted(currentDomain, settings.whitelist)) {
      // Remove every entry that protects this site (exact or parent domain)
      const removed = settings.whitelist.filter(item => isWhitelisted(currentDomain, [item]));
      settings.whitelist = settings.whitelist.filter(item => !removed.includes(item));
      showToast(`Removed "${removed.join(", ")}" from whitelist.`);
    } else {
      // Add to Whitelist
      settings.whitelist.push(currentDomain);
      showToast(`Added "${currentDomain}" to whitelist.`);
    }

    await saveSettings();
    updateActiveSiteCardStyle(isWhitelisted(currentDomain, settings.whitelist));
  });

  // Explorer search filtering
  let searchTimeout;
  elements.explorerSearch.addEventListener("input", () => {
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(loadExplorerData, 200);
  });

  // Explorer filter buttons (All Sites vs High Risk Sites)
  elements.btnFilterAll.addEventListener("click", () => {
    explorerFilter = "all";
    elements.btnFilterAll.classList.add("active");
    elements.btnFilterSuspicious.classList.remove("active");
    loadExplorerData();
  });

  elements.btnFilterSuspicious.addEventListener("click", () => {
    explorerFilter = "suspicious";
    elements.btnFilterSuspicious.classList.add("active");
    elements.btnFilterAll.classList.remove("active");
    loadExplorerData();
  });

  // Purge ALL cookies button
  elements.btnPurgeAll.addEventListener("click", async () => {
    const doubleConfirm = confirm("Are you sure you want to delete ALL cookies stored in Chrome (excluding whitelisted sites)? This will log you out of most sites.");
    if (!doubleConfirm) return;

    elements.btnPurgeAll.disabled = true;
    elements.btnPurgeAll.innerText = "Purging...";

    try {
      const cookies = await chrome.cookies.getAll({});
      const targets = cookies.filter(cookie => !isWhitelisted(stripDot(cookie.domain), settings.whitelist));
      const cleared = await removeCookies(targets, "all sites");

      showUndoToast(`Bulk purged ${cleared} cookies.`);
      await updateClearedCount(cleared);
      await loadActiveSiteCookies();
      await loadExplorerData();
    } catch (e) {
      showToast("Purge failed.", "error");
    } finally {
      elements.btnPurgeAll.disabled = false;
      elements.btnPurgeAll.innerText = "Clear All Cookies";
    }
  });

  // Add domain to whitelist manually
  elements.btnAddWhitelist.addEventListener("click", async () => {
    let rawInput = normalizeDomain(elements.whitelistInput.value);
    if (!rawInput) {
      showToast("Please enter a valid domain, e.g. github.com", "error");
      return;
    }

    if (settings.whitelist.includes(rawInput)) {
      showToast("Domain is already in the whitelist.", "error");
      return;
    }

    settings.whitelist.push(rawInput);
    await saveSettings();

    elements.whitelistInput.value = "";
    renderWhitelist();
    showToast(`Added "${rawInput}" to whitelist.`);

    // Update active site details if the new entry protects it
    if (currentDomain && isWhitelisted(currentDomain, [rawInput])) {
      updateActiveSiteCardStyle(true);
    }
  });

  // Whitelist export / import
  elements.btnExportWhitelist.addEventListener("click", () => {
    const blob = new Blob([JSON.stringify({ whitelist: settings.whitelist }, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "cookieclean-whitelist.json";
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  });

  elements.btnImportWhitelist.addEventListener("click", () => elements.whitelistImportFile.click());

  elements.whitelistImportFile.addEventListener("change", async () => {
    const file = elements.whitelistImportFile.files && elements.whitelistImportFile.files[0];
    if (!file) return;
    try {
      const text = await file.text();
      let entries;
      try {
        const data = JSON.parse(text);
        entries = Array.isArray(data) ? data : data.whitelist;
      } catch (e) {
        entries = text.split(/[\s,]+/); // plain text: one domain per line
      }
      if (!Array.isArray(entries)) throw new Error("no whitelist found");
      let added = 0;
      for (const entry of entries) {
        const domain = normalizeDomain(String(entry));
        if (domain && !settings.whitelist.includes(domain)) {
          settings.whitelist.push(domain);
          added++;
        }
      }
      await saveSettings();
      renderWhitelist();
      if (currentDomain) updateActiveSiteCardStyle(isWhitelisted(currentDomain, settings.whitelist));
      showToast(`Imported ${added} new domain${added === 1 ? "" : "s"}.`);
    } catch (e) {
      showToast("Could not import whitelist file.", "error");
    }
    elements.whitelistImportFile.value = "";
  });

  // Enter key support for whitelist input
  elements.whitelistInput.addEventListener("keypress", (e) => {
    if (e.key === "Enter") {
      elements.btnAddWhitelist.click();
    }
  });

  // Settings Toggles Change Events
  elements.settingAutoDelete.addEventListener("change", (e) => {
    settings.autoDeleteOnTabClose = e.target.checked;
    saveSettings();
  });

  elements.settingDomainChange.addEventListener("change", (e) => {
    settings.cleanOnDomainChange = e.target.checked;
    saveSettings();
  });

  elements.settingPrompt.addEventListener("change", (e) => {
    settings.promptOnTabClose = e.target.checked;
    saveSettings();
  });

  elements.settingStartupClean.addEventListener("change", (e) => {
    settings.cleanOnBrowserStart = e.target.checked;
    saveSettings();
  });

  elements.settingSiteData.addEventListener("change", async (e) => {
    settings.clearSiteData = e.target.checked;
    await saveSettings();
    updatePurgeLabel();
    showToast(settings.clearSiteData ? "Deep clean on: site storage is removed too." : "Deep clean off: only cookies are removed.");
  });

  elements.settingSchedule.addEventListener("change", async (e) => {
    settings.scheduledClean = e.target.value;
    await saveSettings();
    updateScheduleStatus(null);
    showToast(settings.scheduledClean === "off" ? "Scheduled cleaning turned off." : `Scheduled cleaning: ${e.target.options[e.target.selectedIndex].text.toLowerCase()}.`);
  });

  elements.settingAgeLimit.addEventListener("change", (e) => {
    settings.cookieAgeLimit = e.target.value;
    saveSettings();
    showToast(`Cookie age limit updated.`);
  });

  // Reset Stats Button
  elements.btnResetStats.addEventListener("click", async () => {
    if (confirm("Reset privacy stats?")) {
      stats.clearedTotal = 0;
      stats.clearedToday = 0;
      stats.history = {};
      stats.lastResetDate = new Date().toDateString();
      await chrome.storage.local.set({ stats });

      elements.statsTotal.innerText = "0";
      elements.statsToday.innerText = "0";
      elements.statsWeek.innerText = "0";
      chrome.action.setBadgeText({ text: "" });

      updateDashboardCharts();
      showToast("Privacy stats reset successfully.");
    }
  });
}

// Clear all cookies for a domain directly (similar to background helper)
async function clearCookiesForDomain(domain) {
  try {
    const cookies = await chrome.cookies.getAll({ domain: domain });
    if (!cookies || cookies.length === 0) return 0;
    return await removeCookies(cookies, domain);
  } catch (error) {
    console.error(`Error deleting cookies for domain ${domain}`, error);
    return 0;
  }
}

// Turn user input (URL, "*.example.com", ".example.com", "Example.com/path") into a bare hostname
function normalizeDomain(input) {
  let value = String(input || "").trim().toLowerCase();
  if (!value) return "";
  try {
    if (/^[a-z][a-z0-9+.-]*:\/\//.test(value)) value = new URL(value).hostname;
  } catch (e) {
    return "";
  }
  value = value.split(/[\/?#:]/)[0].replace(/^\*\./, "").replace(/^\.+/, "").replace(/\.+$/, "");
  if (!/^[a-z0-9-]+(\.[a-z0-9-]+)*$/.test(value) || value.length > 253) return "";
  return value;
}

// Save Settings utility
async function saveSettings() {
  await chrome.storage.local.set({ settings });
}

// Update Stats utility
async function updateClearedCount(count) {
  if (count <= 0) return;

  const todayStr = new Date().toDateString();
  if (stats.lastResetDate !== todayStr) {
    stats.clearedToday = 0;
    stats.lastResetDate = todayStr;
  }

  stats.clearedTotal += count;
  stats.clearedToday += count;
  const history = stats.history && typeof stats.history === "object" ? stats.history : {};
  history[dayKey()] = (history[dayKey()] || 0) + count;
  stats.history = history;

  await chrome.storage.local.set({ stats });

  elements.statsTotal.innerText = stats.clearedTotal;
  elements.statsToday.innerText = stats.clearedToday;

  // Set background action badge
  chrome.action.setBadgeText({ text: stats.clearedToday.toString() });
  chrome.action.setBadgeBackgroundColor({ color: "#ff5e7e" });

  updateDashboardCharts();
}

// Local-date key used for the daily history, e.g. "2026-10-26"
function dayKey(date = new Date()) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

// Bar chart of cookies cleared per day over the last 14 days
function updateDashboardCharts() {
  const history = stats.history || {};
  const days = [];
  for (let i = 13; i >= 0; i--) {
    const date = new Date();
    date.setHours(12, 0, 0, 0);
    date.setDate(date.getDate() - i);
    days.push({ date, count: history[dayKey(date)] || 0 });
  }
  const max = Math.max(...days.map(d => d.count));
  const week = days.slice(-7).reduce((sum, d) => sum + d.count, 0);
  elements.statsWeek.innerText = week;
  elements.chartMax.innerText = max > 0 ? `peak ${max}/day` : "";
  elements.chartStart.innerText = days[0].date.toLocaleDateString([], { month: "short", day: "numeric" });

  elements.historyChart.innerHTML = days.map((d, i) => {
    const height = max > 0 ? Math.max(4, Math.round((d.count / max) * 100)) : 4;
    const label = `${d.date.toLocaleDateString([], { weekday: "short", month: "short", day: "numeric" })}: ${d.count} cookie${d.count === 1 ? "" : "s"}`;
    return `<div class="history-bar ${d.count === 0 ? "zero" : ""} ${i === 13 ? "today" : ""}" style="height:${d.count === 0 ? 2 : height}%" title="${escapeHtml(label)}"></div>`;
  }).join("");
}

function stripDot(domain) {
  return domain && domain.startsWith(".") ? domain.substring(1) : domain;
}

function isTrackerDomain(domain) {
  const d = String(domain || "").toLowerCase();
  return TRACKER_PATTERNS.some(pattern => d.includes(pattern));
}

// Remove cookies and remember them so the user can undo while the panel is open
async function removeCookies(cookies, label) {
  const removed = [];
  for (const cookie of cookies) {
    const details = {
      url: (cookie.secure ? "https://" : "http://") + stripDot(cookie.domain) + cookie.path,
      name: cookie.name,
      storeId: cookie.storeId
    };
    if (cookie.partitionKey) details.partitionKey = cookie.partitionKey;
    try {
      await chrome.cookies.remove(details);
      removed.push(cookie);
    } catch (e) {
      console.error(`CookieClean: Error removing cookie "${cookie.name}"`, e);
    }
  }
  if (removed.length) lastPurge = { cookies: removed, label };
  return removed.length;
}

// Put the cookies of the last purge back
async function undoLastPurge() {
  if (!lastPurge) return;
  const { cookies } = lastPurge;
  lastPurge = null;
  const now = Date.now() / 1000;
  let restored = 0;
  for (const c of cookies) {
    if (c.expirationDate && c.expirationDate < now) continue;
    const details = {
      url: (c.secure ? "https://" : "http://") + stripDot(c.domain) + c.path,
      name: c.name,
      value: c.value,
      path: c.path,
      secure: c.secure,
      httpOnly: c.httpOnly,
      sameSite: c.sameSite,
      storeId: c.storeId
    };
    // Host-only cookies must be set without a domain, or they become domain cookies
    if (!c.hostOnly) details.domain = c.domain;
    if (c.expirationDate) details.expirationDate = c.expirationDate;
    if (c.partitionKey) details.partitionKey = c.partitionKey;
    try {
      if (await chrome.cookies.set(details)) restored++;
    } catch (e) {
      console.warn(`CookieClean: Could not restore cookie "${c.name}"`, e);
    }
  }
  // Undo also takes the restored cookies off the stats
  if (restored > 0) {
    stats.clearedTotal = Math.max(0, stats.clearedTotal - restored);
    stats.clearedToday = Math.max(0, stats.clearedToday - restored);
    if (stats.history && stats.history[dayKey()]) stats.history[dayKey()] = Math.max(0, stats.history[dayKey()] - restored);
    await chrome.storage.local.set({ stats });
    elements.statsTotal.innerText = stats.clearedTotal;
    elements.statsToday.innerText = stats.clearedToday;
    chrome.action.setBadgeText({ text: stats.clearedToday > 0 ? String(stats.clearedToday) : "" });
    updateDashboardCharts();
  }
  showToast(`Restored ${restored} cookie${restored === 1 ? "" : "s"}.`);
  await loadActiveSiteCookies();
  if (cookieView === "third") await loadThirdPartyCookies();
  if (document.getElementById("tab-explorer").classList.contains("active")) await loadExplorerData(true);
}

function showUndoToast(message) {
  showToast(message, "success", lastPurge ? { label: "Undo", onClick: undoLastPurge } : null);
}

// Site storage (localStorage, IndexedDB, cache, service workers) for a host
async function clearSiteStorage(hostname) {
  if (!chrome.browsingData) return false;
  const base = hostname.toLowerCase().replace(/^www\./, "");
  const hosts = new Set([hostname.toLowerCase(), base, "www." + base]);
  const origins = [];
  hosts.forEach(h => origins.push("https://" + h, "http://" + h));
  try {
    await chrome.browsingData.remove({ origins }, {
      cacheStorage: true, fileSystems: true, indexedDB: true, localStorage: true, serviceWorkers: true, webSQL: true
    });
    return true;
  } catch (e) {
    console.warn("CookieClean: could not clear site data", e);
    return false;
  }
}

// --- Third-party cookies on the current page ---
function setCookieView(view) {
  cookieView = view;
  elements.segFirst.classList.toggle("active", view === "first");
  elements.segThird.classList.toggle("active", view === "third");
  elements.currentCookiesList.hidden = view !== "first";
  elements.thirdPartyList.hidden = view !== "third";
  if (view === "third") loadThirdPartyCookies();
}

// Runs inside the page: hostnames of every resource the page loaded
function collectPageHosts() {
  const hosts = new Set();
  const add = (u) => {
    try {
      const url = new URL(u, location.href);
      if (url.protocol === "http:" || url.protocol === "https:") hosts.add(url.hostname);
    } catch (e) {}
  };
  performance.getEntriesByType("resource").forEach(e => add(e.name));
  document.querySelectorAll("script[src], iframe[src], img[src], link[href]").forEach(el => add(el.src || el.href));
  return Array.from(hosts);
}

async function loadThirdPartyCookies() {
  const list = elements.thirdPartyList;
  if (!currentDomain || !currentTabId) {
    list.innerHTML = `<p class="empty-message">Open a website to see its third-party cookies.</p>`;
    return;
  }
  list.innerHTML = `<p class="loading-message">Looking for third-party cookies...</p>`;

  let hosts = [];
  try {
    const [result] = await chrome.scripting.executeScript({ target: { tabId: currentTabId }, func: collectPageHosts });
    hosts = (result && result.result) || [];
  } catch (e) {
    list.innerHTML = `<p class="empty-message">This page can't be scanned (browser or store pages are protected).</p>`;
    elements.segThirdCount.innerText = "0";
    return;
  }

  const siteApex = getApexDomain(currentDomain);
  const thirdApexes = Array.from(new Set(hosts.map(h => getApexDomain(h)).filter(a => a && a !== siteApex)));
  const groups = {};
  await Promise.all(thirdApexes.map(async apex => {
    const cookies = await chrome.cookies.getAll({ domain: apex }).catch(() => []);
    if (cookies.length) groups[apex] = { apex, cookies, partitioned: 0 };
  }));

  // Partitioned (CHIPS) cookies that other domains set while embedded in this site
  try {
    const partitioned = await chrome.cookies.getAll({ partitionKey: { topLevelSite: "https://" + siteApex } });
    partitioned.forEach(c => {
      const apex = getApexDomain(stripDot(c.domain));
      if (!apex || apex === siteApex) return;
      const group = groups[apex] || (groups[apex] = { apex, cookies: [], partitioned: 0 });
      if (!group.cookies.some(x => x.name === c.name && x.domain === c.domain && x.path === c.path && !!x.partitionKey)) {
        group.cookies.push(c);
        group.partitioned++;
      }
    });
  } catch (e) {
    // partitionKey filtering needs Chrome 119+
  }

  const items = Object.values(groups).sort((a, b) => {
    const ta = isTrackerDomain(a.apex), tb = isTrackerDomain(b.apex);
    return ta !== tb ? (ta ? -1 : 1) : b.cookies.length - a.cookies.length;
  });
  const total = items.reduce((n, g) => n + g.cookies.length, 0);
  elements.segThirdCount.innerText = total;

  if (!items.length) {
    list.innerHTML = `<p class="empty-message">No third-party cookies here.${thirdApexes.length ? ` This page loads ${thirdApexes.length} other domain${thirdApexes.length === 1 ? "" : "s"}, but none of them stores cookies.` : ""}</p>`;
    return;
  }

  list.innerHTML = items.map(g => {
    const tracker = isTrackerDomain(g.apex);
    const trusted = isWhitelisted(g.apex, settings.whitelist);
    return `
      <div class="tp-row">
        <div class="cookie-meta">
          <div class="tp-domain">${escapeHtml(g.apex)}</div>
          <div class="tp-meta">
            <span>${g.cookies.length} cookie${g.cookies.length === 1 ? "" : "s"}</span>
            ${tracker ? '<span class="badge-tag tracker">Tracker</span>' : ""}
            ${g.partitioned ? `<span class="badge-tag partitioned" title="Partitioned cookies only readable on this site">${g.partitioned} partitioned</span>` : ""}
            ${trusted ? '<span class="badge-tag secure">Trusted</span>' : ""}
          </div>
        </div>
        <button class="btn-icon btn-purge-third" data-apex="${escapeHtml(g.apex)}" title="Delete cookies of ${escapeHtml(g.apex)}">
          <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="3 6 5 6 21 6"></polyline>
            <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
          </svg>
        </button>
      </div>`;
  }).join("") + `
    <div class="tp-footer">
      <span class="tp-note">${items.length} of ${thirdApexes.length} loaded domain${thirdApexes.length === 1 ? "" : "s"} store cookies</span>
      <button class="btn-text" id="btn-purge-all-third">Delete all third-party</button>
    </div>`;

  list.querySelectorAll(".btn-purge-third").forEach(btn => {
    btn.addEventListener("click", async () => {
      const group = groups[btn.getAttribute("data-apex")];
      if (!group) return;
      btn.disabled = true;
      const count = await removeCookies(group.cookies, group.apex);
      await updateClearedCount(count);
      showUndoToast(`Deleted ${count} cookie${count === 1 ? "" : "s"} of ${group.apex}.`);
      await loadThirdPartyCookies();
    });
  });
  document.getElementById("btn-purge-all-third").addEventListener("click", async () => {
    const all = items.filter(g => !isWhitelisted(g.apex, settings.whitelist)).flatMap(g => g.cookies);
    const count = await removeCookies(all, "third-party");
    await updateClearedCount(count);
    showUndoToast(`Deleted ${count} third-party cookie${count === 1 ? "" : "s"}.`);
    await loadThirdPartyCookies();
  });
}

// Toast notification helper
function showToast(message, type = "success", action = null) {
  // Only one toast at a time so the panel stays readable
  elements.toastContainer.innerHTML = "";
  const toast = document.createElement("div");
  toast.className = `toast ${type === "error" ? "toast-error" : ""}`;

  toast.innerHTML = `
    <span>${escapeHtml(message)}</span>
    ${action ? `<button class="toast-action">${escapeHtml(action.label)}</button>` : ""}
    <button class="toast-close">&times;</button>
  `;

  elements.toastContainer.appendChild(toast);

  // Auto remove (undo toasts stay longer)
  const autoClose = setTimeout(() => {
    toast.style.opacity = "0";
    toast.style.transform = "translateY(10px)";
    setTimeout(() => toast.remove(), 300);
  }, action ? 7000 : 3000);

  if (action) {
    toast.querySelector(".toast-action").addEventListener("click", () => {
      clearTimeout(autoClose);
      toast.remove();
      action.onClick();
    });
  }

  // Manual close
  toast.querySelector(".toast-close").addEventListener("click", () => {
    clearTimeout(autoClose);
    toast.remove();
  });
}

// HTML escape helper
function escapeHtml(str) {
  if (str === null || str === undefined) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}
