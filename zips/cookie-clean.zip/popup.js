// CookieClean - Popup Control Panel Script
// Cleaning rules (whitelist, open tabs, partitioned cookies) live in cleaner-core.js (CC).

// State
let currentDomain = "";
let currentUrl = "";
let currentStoreId; // cookie store of the active tab (incognito has its own)
let settings = CC.mergeSettings();
let stats = {};
let explorerFilter = "all"; // "all" or "suspicious"
let cookieView = "first"; // "first" (this site) or "third" (third-party cookies on this page)
let currentTabId = null;
let cachedSiteCookies = [];

const TRACKER_PATTERNS = [
  'doubleclick', 'google-analytics', 'googleadservices', 'googlesyndication', 'googletagmanager', 'adnxs', 'rubiconproject',
  'pubmatic', 'quantserve', 'scorecardresearch', 'taboola', 'outbrain', 'criteo', 'facebook.net', 'facebook.com',
  'hotjar', 'crazyegg', 'adroll', 'amazon-adsystem', 'bluekai', 'optimizely', 'amplitude', 'bing.com', 'clarity.ms',
  'linkedin', 'tiktok', 'yandex', 'mixpanel', 'segment', 'hubspot', 'demdex', 'casalemedia', 'openx', 'teads'
];

const SOURCE_LABELS = {
  manual: "Deleted in the panel",
  shortcut: "Keyboard shortcut",
  "tab-close": "Tab closed",
  leave: "Left the site",
  prompt: "Cleared from prompt",
  startup: "Browser startup",
  scheduled: "Scheduled cleaning"
};

const TRASH_SVG = `<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
  <polyline points="3 6 5 6 21 6"></polyline>
  <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
</svg>`;

// DOM Elements
const elements = {
  tabButtons: document.querySelectorAll(".tab-btn"),
  tabPanels: document.querySelectorAll(".tab-panel"),
  globalToggle: document.getElementById("global-toggle"),
  pausedBanner: document.getElementById("paused-banner"),

  // Active Site Tab
  currentDomainText: document.getElementById("current-domain"),
  currentSiteStatus: document.getElementById("current-site-status"),
  currentCookieCount: document.getElementById("current-cookie-count"),
  privacyScore: document.getElementById("privacy-score"),
  siteFavicon: document.getElementById("site-favicon"),
  btnPurgeCurrent: document.getElementById("btn-purge-current"),
  btnWhitelistCurrent: document.getElementById("btn-whitelist-current"),
  whitelistCurrentText: document.getElementById("whitelist-current-text"),
  currentCookiesList: document.getElementById("current-cookies-list"),
  activeSiteCard: document.querySelector(".active-site-card"),
  siteRestore: document.getElementById("site-restore"),

  // Explorer Tab
  explorerSearch: document.getElementById("explorer-search"),
  btnPurgeAll: document.getElementById("btn-purge-all"),
  explorerSitesList: document.getElementById("explorer-sites-list"),
  btnFilterAll: document.getElementById("btn-filter-all"),
  btnFilterSuspicious: document.getElementById("btn-filter-suspicious"),

  // Whitelist Tab
  whitelistInput: document.getElementById("whitelist-input"),
  whitelistMode: document.getElementById("whitelist-mode"),
  btnAddWhitelist: document.getElementById("btn-add-whitelist"),
  whitelistSitesList: document.getElementById("whitelist-sites-list"),
  btnExportWhitelist: document.getElementById("btn-export-whitelist"),
  btnImportWhitelist: document.getElementById("btn-import-whitelist"),
  whitelistImportFile: document.getElementById("whitelist-import-file"),

  // Settings & Stats
  statsTotal: document.getElementById("stats-total"),
  statsToday: document.getElementById("stats-today"),
  btnResetStats: document.getElementById("btn-reset-stats"),
  statsWeek: document.getElementById("stats-week"),
  historyChart: document.getElementById("history-chart"),
  chartMax: document.getElementById("chart-max"),
  chartStart: document.getElementById("chart-start"),
  recentList: document.getElementById("recent-list"),
  btnForgetRecent: document.getElementById("btn-forget-recent"),
  settingSiteData: document.getElementById("setting-site-data"),
  settingSchedule: document.getElementById("setting-schedule"),
  settingDelay: document.getElementById("setting-delay"),
  scheduleStatus: document.getElementById("schedule-status"),
  purgeCurrentText: document.getElementById("purge-current-text"),
  onboardingCard: document.getElementById("onboarding-card"),
  btnDismissOnboarding: document.getElementById("btn-dismiss-onboarding"),
  segFirst: document.getElementById("seg-first"),
  segThird: document.getElementById("seg-third"),
  segFirstCount: document.getElementById("seg-first-count"),
  segThirdCount: document.getElementById("seg-third-count"),
  thirdPartyList: document.getElementById("third-party-list"),
  settingAutoDelete: document.getElementById("setting-auto-delete"),
  settingDomainChange: document.getElementById("setting-domain-change"),
  appVersion: document.getElementById("app-version"),
  settingPrompt: document.getElementById("setting-prompt"),
  settingStartupClean: document.getElementById("setting-startup-clean"),
  settingAgeLimit: document.getElementById("setting-age-limit"),

  toastContainer: document.getElementById("toast-container")
};

// Initialize Popup
document.addEventListener("DOMContentLoaded", async () => {
  await loadSettingsAndStats();
  setupTabNavigation();
  await detectActiveTab();
  setupEventListeners();
  setupKeyboardShortcuts();
  updateDashboardCharts();
  await renderRecent();
});

// Keep the panel in sync when the worker changes settings (e.g. "Trust Site" from a
// prompt) so a later save from here can't drop that change.
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes.settings && changes.settings.newValue) {
    settings = CC.mergeSettings(changes.settings.newValue);
    if (document.getElementById("tab-whitelist").classList.contains("active")) renderWhitelist();
    if (currentDomain) updateActiveSiteCardStyle(CC.isHostProtected(currentDomain, settings));
  } else if (area === "local" && changes.stats && changes.stats.newValue) {
    stats = changes.stats.newValue;
    renderStatsNumbers();
    updateDashboardCharts();
  } else if (area === "session" && Object.keys(changes).some(k => k.startsWith("recent:"))) {
    renderRecent();
  }
});

async function loadSettingsAndStats() {
  const localData = await chrome.storage.local.get(["settings", "stats", "onboardingDone", "lastScheduledClean"]);
  elements.onboardingCard.hidden = !!localData.onboardingDone;
  settings = CC.mergeSettings(localData.settings);
  elements.appVersion.innerText = "v" + chrome.runtime.getManifest().version;
  stats = localData.stats || { clearedTotal: 0, clearedToday: 0, lastResetDate: new Date().toDateString() };

  elements.globalToggle.checked = settings.extensionEnabled;
  elements.settingAutoDelete.checked = settings.autoDeleteOnTabClose;
  elements.settingDomainChange.checked = settings.cleanOnDomainChange;
  elements.settingPrompt.checked = settings.promptOnTabClose;
  elements.settingStartupClean.checked = settings.cleanOnBrowserStart;
  elements.settingAgeLimit.value = settings.cookieAgeLimit;
  elements.settingSiteData.checked = settings.clearSiteData;
  elements.settingSchedule.value = settings.scheduledClean;
  elements.settingDelay.value = String(settings.cleanupDelay);
  updatePurgeLabel();
  updateScheduleStatus(localData.lastScheduledClean);
  renderStatsNumbers();
  updatePausedState();
}

function renderStatsNumbers() {
  const today = stats.lastResetDate === new Date().toDateString() ? stats.clearedToday : 0;
  elements.statsTotal.innerText = stats.clearedTotal || 0;
  elements.statsToday.innerText = today || 0;
}

function updatePurgeLabel() {
  elements.purgeCurrentText.innerText = settings.clearSiteData ? "Purge Cookies & Data" : "Purge Site Cookies";
  elements.btnPurgeCurrent.title = settings.clearSiteData
    ? "Delete this site's cookies, localStorage, IndexedDB, cache and service workers"
    : "Delete all cookies of this site";
}

function updateScheduleStatus(last) {
  if (settings.scheduledClean === "off") {
    elements.scheduleStatus.innerText = "";
    return;
  }
  elements.scheduleStatus.innerText = last && last.at
    ? `Last run ${new Date(last.at).toLocaleString([], { dateStyle: "medium", timeStyle: "short" })}: ${last.cleared} cookie${last.cleared === 1 ? "" : "s"} removed.`
    : "First run is one interval from now.";
}

// Automatic cleaning off: say so, but keep the manual tools and settings usable
function updatePausedState() {
  elements.pausedBanner.hidden = settings.extensionEnabled;
}

function switchToTab(tabId) {
  const btn = Array.from(elements.tabButtons).find(b => b.getAttribute("data-tab") === tabId);
  if (btn) btn.click();
}

function setupKeyboardShortcuts() {
  const order = ["tab-active-site", "tab-explorer", "tab-whitelist", "tab-settings"];
  document.addEventListener("keydown", async (e) => {
    const tag = (e.target.tagName || "").toLowerCase();
    const typing = tag === "input" || tag === "textarea" || tag === "select";
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "z" && !typing) {
      e.preventDefault();
      const recent = await CC.listRecent();
      const last = recent.find(r => r.source === "manual" || r.source === "shortcut");
      if (last) await restoreEntry(last.id); else showToast("Nothing to undo.");
      return;
    }
    if (e.key === "Escape" && typing) {
      e.target.blur();
      return;
    }
    if (typing || e.ctrlKey || e.metaKey || e.altKey) return;
    if (/^[1-4]$/.test(e.key)) {
      switchToTab(order[Number(e.key) - 1]);
    } else if (e.key === "/") {
      e.preventDefault();
      switchToTab("tab-explorer");
      elements.explorerSearch.focus();
    }
  });
}

function setupTabNavigation() {
  elements.tabButtons.forEach(btn => {
    btn.addEventListener("click", () => {
      elements.tabButtons.forEach(b => {
        b.classList.toggle("active", b === btn);
        b.setAttribute("aria-selected", b === btn ? "true" : "false");
      });
      const targetTab = btn.getAttribute("data-tab");
      elements.tabPanels.forEach(panel => {
        const active = panel.id === targetTab;
        panel.classList.toggle("active", active);
        if (!active) return;
        if (targetTab === "tab-explorer") loadExplorerData();
        else if (targetTab === "tab-whitelist") renderWhitelist();
        else if (targetTab === "tab-settings") renderRecent();
      });
    });
  });
}

// Helper: Extract apex domain (e.g. google.com from accounts.google.com)
function getApexDomain(domain) {
  if (!domain) return "";
  const parts = domain.split(".");
  if (parts.length > 2) {
    // Basic logic for generic domains. Handles co.uk, com.au, etc. simply
    const secondLast = parts[parts.length - 2];
    if (["com", "co", "org", "net", "gov", "edu", "ac"].includes(secondLast)) {
      return parts.slice(-3).join(".");
    }
    return parts.slice(-2).join(".");
  }
  return domain;
}

async function detectActiveTab() {
  try {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tabs.length === 0) return;

    const tab = tabs[0];
    currentUrl = tab.url || "";
    currentTabId = tab.id;
    const host = CC.hostFromUrl(currentUrl);

    if (!host) {
      // Browser page, extension page, file:// or another page without web cookies
      elements.currentDomainText.innerText = "Browser page";
      elements.currentDomainText.title = "This page has no website cookies";
      elements.currentSiteStatus.className = "status-indicator safe";
      elements.currentSiteStatus.innerText = "No cookies";
      elements.currentCookieCount.innerText = "0";
      elements.privacyScore.innerText = "N/A";
      elements.btnPurgeCurrent.disabled = true;
      elements.btnWhitelistCurrent.disabled = true;
      elements.currentCookiesList.innerHTML = `<p class="empty-message">Open a website to see and clean its cookies.</p>`;
      elements.segFirstCount.innerText = "0";
      elements.segThirdCount.innerText = "0";
      elements.thirdPartyList.innerHTML = `<p class="empty-message">Open a website to see its third-party cookies.</p>`;
      return;
    }

    currentDomain = host;
    currentStoreId = await CC.storeIdForTab(tab.id);
    elements.currentDomainText.innerText = currentDomain;
    elements.currentDomainText.title = currentDomain;

    if (tab.favIconUrl && /^(https?:|data:image\/)/.test(tab.favIconUrl)) {
      elements.siteFavicon.innerHTML = `<img src="${escapeHtml(tab.favIconUrl)}" width="20" height="20" alt="" style="object-fit: contain;">`;
    } else {
      elements.siteFavicon.innerText = "🌐";
    }

    await loadActiveSiteCookies();
    // Count third-party cookies up front so the switch shows the number
    loadThirdPartyCookies();
  } catch (error) {
    console.error("CookieClean: Active tab detection failed", error);
    elements.currentDomainText.innerText = "Access Blocked";
    elements.currentCookiesList.innerHTML = `<p class="empty-message">Unable to query cookies. Check site permissions.</p>`;
  }
}

async function loadActiveSiteCookies() {
  if (!currentDomain) return;
  updateActiveSiteCardStyle(CC.isHostProtected(currentDomain, settings));

  try {
    const cookies = await getSiteCookies();
    elements.currentCookieCount.innerText = cookies.length;
    elements.segFirstCount.innerText = cookies.length;
    const scoreInfo = calculatePrivacyScore(cookies);
    elements.privacyScore.innerText = scoreInfo.grade;
    elements.privacyScore.className = `stat-num ${scoreInfo.class}`;
    renderActiveSiteCookiesList(cookies);
  } catch (error) {
    console.error("CookieClean: Error reading cookies", error);
    elements.currentCookieCount.innerText = "Error";
    elements.privacyScore.innerText = "F";
  }
}

// The same set tab-close cleaning removes: cookies on the host and its subdomains,
// parent-domain cookies sent to it, and the site's own partitioned cookies
function getSiteCookies() {
  return CC.getCookiesForSite(currentDomain, currentStoreId);
}

function isWhitelistedAlways(domain) {
  return CC.isHostListed(domain, settings.whitelist);
}

function checkDomainSuspicion(domain, cookies) {
  const reasons = [];
  if (isTrackerDomain(domain)) reasons.push("Known tracker/analytics domain");
  if (cookies.length > 15) reasons.push(`Excessive cookies stored (${cookies.length})`);

  const twoYearsSeconds = 2 * 365 * 24 * 60 * 60;
  const nowSeconds = Math.floor(Date.now() / 1000);
  if (cookies.some(c => c.expirationDate && (c.expirationDate - nowSeconds) > twoYearsSeconds)) {
    reasons.push("Contains persistent tracking cookies (> 2 years)");
  }

  const sensitiveNames = ['session', 'sid', 'token', 'auth', 'login', 'jwt', 'user'];
  const hasInsecureSensitive = cookies.some(c => {
    const nameLower = c.name.toLowerCase();
    return sensitiveNames.some(s => nameLower.includes(s)) && (!c.secure || !c.httpOnly);
  });
  if (hasInsecureSensitive) reasons.push("Sensitive login/session cookies lack Secure or HttpOnly protection");

  return { isSuspicious: reasons.length > 0, reasons };
}

function updateActiveSiteCardStyle(isProtected) {
  elements.activeSiteCard.className = "card active-site-card";
  const always = isProtected && isWhitelistedAlways(currentDomain);
  if (isProtected) {
    elements.activeSiteCard.classList.add("whitelisted-site");
    elements.currentSiteStatus.className = "status-indicator warn";
    elements.currentSiteStatus.innerText = always ? "Trusted" : "Kept until restart";
    elements.whitelistCurrentText.innerText = "Remove Trust";
    elements.btnWhitelistCurrent.querySelector(".icon-shield").style.stroke = "var(--color-yellow)";
  } else {
    elements.activeSiteCard.classList.add("unsafe-site");
    elements.currentSiteStatus.className = "status-indicator danger";
    elements.currentSiteStatus.innerText = "Cleaned when closed";
    elements.whitelistCurrentText.innerText = "Trust Site";
    elements.btnWhitelistCurrent.querySelector(".icon-shield").style.stroke = "currentColor";
  }
}

// Privacy Score (A+ to F)
function calculatePrivacyScore(cookies) {
  if (!cookies || cookies.length === 0) return { grade: "A+", class: "safe" };

  let points = 100;
  if (cookies.length > 50) points -= 35;
  else if (cookies.length > 30) points -= 25;
  else if (cookies.length > 15) points -= 15;
  else if (cookies.length > 5) points -= 8;

  const insecure = cookies.filter(c => !c.secure).length / cookies.length * 100;
  const noHttpOnly = cookies.filter(c => !c.httpOnly).length / cookies.length * 100;
  if (insecure > 50) points -= 15; else if (insecure > 20) points -= 8;
  if (noHttpOnly > 50) points -= 15; else if (noHttpOnly > 20) points -= 8;

  if (points >= 95) return { grade: "A+", class: "safe" };
  if (points >= 88) return { grade: "A", class: "safe" };
  if (points >= 80) return { grade: "B", class: "warn" };
  if (points >= 70) return { grade: "C", class: "warn" };
  if (points >= 55) return { grade: "D", class: "danger" };
  return { grade: "F", class: "danger" };
}

function renderActiveSiteCookiesList(cookies) {
  const savedScrollTop = elements.currentCookiesList.scrollTop;
  cachedSiteCookies = cookies || [];
  if (!cachedSiteCookies.length) {
    elements.currentCookiesList.innerHTML = `<p class="empty-message">No cookies stored by this site.</p>`;
    return;
  }

  elements.currentCookiesList.innerHTML = cachedSiteCookies.map((cookie, i) => {
    const expiryStr = cookie.expirationDate ? new Date(cookie.expirationDate * 1000).toLocaleDateString() : "Session";
    const shared = !CC.isCookieProtected(cookie, settings) ? "" :
      (CC.isHostProtected(currentDomain, settings) ? "" : '<span class="badge-tag secure" title="Also sent to a trusted site, so it is kept">Kept</span>');
    return `
      <div class="cookie-item">
        <div class="cookie-meta">
          <div class="cookie-name" title="${escapeHtml(cookie.name)} (${escapeHtml(cookie.domain)})">${escapeHtml(cookie.name)}</div>
          <div class="cookie-submeta">
            <span>Exp: ${escapeHtml(expiryStr)}</span>
            ${cookie.secure ? '<span class="badge-tag secure">Secure</span>' : ''}
            ${cookie.httpOnly ? '<span class="badge-tag">HttpOnly</span>' : ''}
            ${cookie.partitionKey ? '<span class="badge-tag partitioned">Partitioned</span>' : ''}
            ${shared}
          </div>
        </div>
        <button class="btn-icon btn-delete-single" data-index="${i}" aria-label="Delete cookie ${escapeHtml(cookie.name)}" title="Delete this cookie">${TRASH_SVG}</button>
      </div>`;
  }).join("");
  elements.currentCookiesList.scrollTop = savedScrollTop;

  elements.currentCookiesList.querySelectorAll(".btn-delete-single").forEach(btn => {
    btn.addEventListener("click", async () => {
      const cookie = cachedSiteCookies[Number(btn.getAttribute("data-index"))];
      if (!cookie) return;
      btn.disabled = true;
      const count = await purge([cookie], `cookie "${cookie.name}"`);
      if (count) showUndoToast(`Cleared cookie: ${cookie.name}`);
      else showToast("Error clearing cookie.", "error");
      await loadActiveSiteCookies();
    });
  });
}

// Remove cookies, keep them for Restore and count them in the stats
async function purge(cookies, label, dataCleared = false) {
  const removed = await CC.removeCookies(cookies);
  if (removed.length) {
    await CC.recordCleanup({ label, source: "manual", cookies: removed, dataCleared });
    stats = await CC.addToStats(removed.length);
    renderStatsNumbers();
    updateDashboardCharts();
    chrome.action.setBadgeText({ text: CC.badgeText(stats.clearedToday) });
    chrome.action.setBadgeBackgroundColor({ color: "#ff5e7e" });
  }
  return removed.length;
}

// TAB 2: Explorer (all cookies of this cookie store, grouped by domain)
async function loadExplorerData(preserveScroll = false) {
  const savedScrollTop = preserveScroll ? elements.explorerSitesList.scrollTop : 0;
  if (!preserveScroll) elements.explorerSitesList.innerHTML = `<p class="loading-message">Reading cookies...</p>`;

  try {
    const cookies = await CC.getAllCookies(currentStoreId ? { storeId: currentStoreId } : {});
    const sites = {};
    cookies.forEach(cookie => {
      const domain = CC.stripDot(cookie.domain);
      (sites[domain] = sites[domain] || []).push(cookie);
    });

    const searchQuery = elements.explorerSearch.value.trim().toLowerCase();
    let processed = Object.keys(sites)
      .filter(domain => domain.includes(searchQuery))
      .map(domain => ({ domain, cookies: sites[domain], suspicion: checkDomainSuspicion(domain, sites[domain]) }));
    if (explorerFilter === "suspicious") processed = processed.filter(item => item.suspicion.isSuspicious);
    processed.sort((a, b) => b.cookies.length - a.cookies.length);

    if (!processed.length) {
      elements.explorerSitesList.innerHTML = `<p class="empty-message">No matching cookies found.</p>`;
      return;
    }

    elements.explorerSitesList.innerHTML = processed.map(item => {
      const { domain, suspicion } = item;
      const count = item.cookies.length;
      const kept = item.cookies.filter(c => CC.isCookieProtected(c, settings)).length;
      let badgeHtml = "";
      if (kept) badgeHtml = `• <span class="tag-protected">${kept === count ? "Protected" : `${kept} protected`}</span>`;
      else if (suspicion.isSuspicious) badgeHtml = '• <span class="tag-risk">⚠️ High Risk</span>';
      const reasonsHtml = suspicion.isSuspicious ? `<span class="suspicious-reasons">Risk: ${escapeHtml(suspicion.reasons.join('; '))}</span>` : "";
      return `
        <div class="site-row">
          <div class="site-domain-info">
            <span class="site-name" title="${escapeHtml(domain)}">${escapeHtml(domain)}</span>
            <span class="site-cookies-tag">${count} cookie${count === 1 ? '' : 's'} ${badgeHtml}</span>
            ${reasonsHtml}
          </div>
          <div class="site-actions">
            <button class="btn-icon btn-purge-site" data-domain="${escapeHtml(domain)}" aria-label="Clear cookies for ${escapeHtml(domain)}" title="Clear cookies for ${escapeHtml(domain)}">${TRASH_SVG}</button>
          </div>
        </div>`;
    }).join("");
    if (preserveScroll) elements.explorerSitesList.scrollTop = savedScrollTop;

    elements.explorerSitesList.querySelectorAll(".btn-purge-site").forEach(btn => {
      btn.addEventListener("click", async () => {
        const domain = btn.getAttribute("data-domain");
        // Only this row's cookies: never the cookies of its subdomains, which have rows of their own
        const rowCookies = sites[domain] || [];
        const kept = rowCookies.filter(c => CC.isCookieProtected(c, settings));
        if (kept.length && !confirm(`${kept.length} of these cookies are protected by your whitelist (${domain} or a trusted site uses them). Delete them anyway?`)) return;
        btn.disabled = true;
        const count = await purge(rowCookies, domain);
        if (count > 0) {
          showUndoToast(`Cleared ${count} cookie${count === 1 ? "" : "s"} for ${domain}`);
          if (currentDomain && CC.sameSite(domain, currentDomain)) await loadActiveSiteCookies();
          await loadExplorerData(true);
        } else {
          showToast("No cookies cleared.");
          btn.disabled = false;
        }
      });
    });
  } catch (err) {
    console.error("CookieClean: Explorer load error", err);
    elements.explorerSitesList.innerHTML = `<p class="empty-message">Error querying cookie store.</p>`;
  }
}

// TAB 3: Whitelist and greylist
function renderWhitelist() {
  const rows = settings.whitelist.map(d => ({ domain: d, mode: "always" }))
    .concat(settings.greylist.map(d => ({ domain: d, mode: "restart" })))
    .sort((a, b) => a.domain.localeCompare(b.domain));

  if (!rows.length) {
    elements.whitelistSitesList.innerHTML = `<p class="empty-message">No trusted sites yet. Add the sites where you want to stay signed in.</p>`;
    return;
  }

  elements.whitelistSitesList.innerHTML = rows.map(({ domain, mode }) => `
    <div class="whitelist-item">
      <span class="wl-domain">${escapeHtml(domain)}</span>
      <button class="wl-mode ${mode}" data-domain="${escapeHtml(domain)}" title="Click to switch between Always and Until restart">${mode === "always" ? "Always" : "Until restart"}</button>
      <button class="btn-icon btn-remove-whitelist" data-domain="${escapeHtml(domain)}" aria-label="Remove ${escapeHtml(domain)}" title="Remove">
        <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
          <line x1="18" y1="6" x2="6" y2="18"></line>
          <line x1="6" y1="6" x2="18" y2="18"></line>
        </svg>
      </button>
    </div>`).join("");

  elements.whitelistSitesList.querySelectorAll(".btn-remove-whitelist").forEach(btn => {
    btn.addEventListener("click", async () => {
      const domain = btn.getAttribute("data-domain");
      settings.whitelist = settings.whitelist.filter(d => d !== domain);
      settings.greylist = settings.greylist.filter(d => d !== domain);
      await saveSettings();
      renderWhitelist();
      showToast(`Removed "${domain}".`);
      if (currentDomain) updateActiveSiteCardStyle(CC.isHostProtected(currentDomain, settings));
    });
  });
  elements.whitelistSitesList.querySelectorAll(".wl-mode").forEach(btn => {
    btn.addEventListener("click", async () => {
      const domain = btn.getAttribute("data-domain");
      if (settings.whitelist.includes(domain)) {
        settings.whitelist = settings.whitelist.filter(d => d !== domain);
        settings.greylist.push(domain);
        showToast(`${domain}: kept until the browser restarts.`);
      } else {
        settings.greylist = settings.greylist.filter(d => d !== domain);
        settings.whitelist.push(domain);
        showToast(`${domain}: always kept.`);
      }
      await saveSettings();
      renderWhitelist();
      if (currentDomain) updateActiveSiteCardStyle(CC.isHostProtected(currentDomain, settings));
    });
  });
}

function addTrusted(domain, mode) {
  settings.whitelist = settings.whitelist.filter(d => d !== domain);
  settings.greylist = settings.greylist.filter(d => d !== domain);
  (mode === "restart" ? settings.greylist : settings.whitelist).push(domain);
}

function setupEventListeners() {
  elements.btnDismissOnboarding.addEventListener("click", () => {
    elements.onboardingCard.hidden = true;
    chrome.storage.local.set({ onboardingDone: true });
  });

  [elements.segFirst, elements.segThird].forEach(btn => {
    btn.addEventListener("click", () => setCookieView(btn.dataset.view));
  });

  elements.globalToggle.addEventListener("change", async (e) => {
    settings.extensionEnabled = e.target.checked;
    await saveSettings();
    updatePausedState();
    showToast(settings.extensionEnabled ? "Automatic cleaning is on." : "Automatic cleaning is paused.", settings.extensionEnabled ? "success" : "error");
  });

  // Purge the active site
  elements.btnPurgeCurrent.addEventListener("click", async () => {
    if (!currentDomain) return;
    const trusted = CC.isHostProtected(currentDomain, settings);
    if (trusted && !confirm(`${currentDomain} is trusted. Delete its cookies anyway? You will be signed out.`)) return;
    elements.btnPurgeCurrent.disabled = true;

    let cleared = 0, kept = 0;
    let dataCleared = false;
    try {
      const siteCookies = await getSiteCookies();
      // Cookies a trusted site also uses (e.g. ".example.com" for a trusted mail.example.com) stay,
      // unless the user confirmed purging this trusted site itself
      const targets = trusted ? siteCookies : siteCookies.filter(c => !CC.isCookieProtected(c, settings));
      kept = siteCookies.length - targets.length;
      if (settings.clearSiteData) {
        dataCleared = trusted
          ? await CC.clearSiteStorage(currentDomain, { whitelist: [], greylist: [] })
          : await CC.clearSiteStorage(currentDomain, settings);
      }
      cleared = await purge(targets, currentDomain, dataCleared);
    } catch (error) {
      console.error(`CookieClean: Error deleting cookies for ${currentDomain}`, error);
    }

    await loadActiveSiteCookies();
    let message = `Purged ${cleared} cookie${cleared === 1 ? "" : "s"}${dataCleared ? " and site data" : ""}.`;
    if (kept) message += ` Kept ${kept} shared with a trusted site.`;
    if (cleared > 0) showUndoToast(message + (dataCleared ? " Undo restores cookies only." : "")); else showToast(message);
    setTimeout(() => { elements.btnPurgeCurrent.disabled = false; }, 600);
  });

  // Trust / untrust the active site
  elements.btnWhitelistCurrent.addEventListener("click", async () => {
    if (!currentDomain) return;
    if (CC.isHostProtected(currentDomain, settings)) {
      // Remove every entry that protects this site (exact, www twin or parent domain)
      const covers = item => CC.isHostListed(currentDomain, [item]);
      const removed = settings.whitelist.filter(covers).concat(settings.greylist.filter(covers));
      settings.whitelist = settings.whitelist.filter(d => !covers(d));
      settings.greylist = settings.greylist.filter(d => !covers(d));
      showToast(`Removed "${removed.join(", ")}" from trusted sites.`);
    } else {
      // "www.github.com" -> "github.com", so the sign-in cookies on .github.com are kept too
      const entry = CC.baseHost(currentDomain);
      addTrusted(entry, "always");
      showToast(`Trusted "${entry}" and its subdomains.`);
    }
    await saveSettings();
    await loadActiveSiteCookies();
  });

  let searchTimeout;
  elements.explorerSearch.addEventListener("input", () => {
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(() => loadExplorerData(), 200);
  });

  elements.btnFilterAll.addEventListener("click", () => {
    explorerFilter = "all";
    elements.btnFilterAll.classList.add("active");
    elements.btnFilterSuspicious.classList.remove("active");
    loadExplorerData();
  });

  elements.btnFilterSuspicious.addEventListener("click", () => {
    explorerFilter = "suspicious";
    elements.btnFilterSuspicious.classList.add("active");
    elements.btnFilterAll.classList.remove("active");
    loadExplorerData();
  });

  // Purge every cookie that isn't protected
  elements.btnPurgeAll.addEventListener("click", async () => {
    if (!confirm("Delete ALL cookies in this browser profile except those of trusted sites? This signs you out of most sites, including sites open in other tabs.")) return;
    elements.btnPurgeAll.disabled = true;
    elements.btnPurgeAll.innerText = "Purging...";
    try {
      const cookies = await CC.getAllCookies(currentStoreId ? { storeId: currentStoreId } : {});
      const cleared = await purge(cookies.filter(c => !CC.isCookieProtected(c, settings)), "All sites");
      showUndoToast(`Purged ${cleared} cookie${cleared === 1 ? "" : "s"}.`);
      await loadActiveSiteCookies();
      await loadExplorerData();
    } catch (e) {
      showToast("Purge failed.", "error");
    } finally {
      elements.btnPurgeAll.disabled = false;
      elements.btnPurgeAll.innerText = "Clear All Cookies";
    }
  });

  elements.btnAddWhitelist.addEventListener("click", async () => {
    const domain = CC.normalizeDomain(elements.whitelistInput.value);
    if (!domain) {
      showToast("Please enter a valid domain, e.g. github.com", "error");
      return;
    }
    const mode = elements.whitelistMode.value;
    const list = mode === "restart" ? settings.greylist : settings.whitelist;
    if (list.includes(domain)) {
      showToast("Domain is already in the list.", "error");
      return;
    }
    addTrusted(domain, mode);
    await saveSettings();
    elements.whitelistInput.value = "";
    renderWhitelist();
    showToast(mode === "restart" ? `"${domain}" is kept until the browser restarts.` : `Added "${domain}" to trusted sites.`);
    if (currentDomain) updateActiveSiteCardStyle(CC.isHostProtected(currentDomain, settings));
  });

  elements.whitelistInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") elements.btnAddWhitelist.click();
  });

  elements.btnExportWhitelist.addEventListener("click", () => {
    const blob = new Blob([JSON.stringify({ whitelist: settings.whitelist, greylist: settings.greylist }, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "cookieclean-whitelist.json";
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  });

  elements.btnImportWhitelist.addEventListener("click", () => elements.whitelistImportFile.click());

  elements.whitelistImportFile.addEventListener("change", async () => {
    const file = elements.whitelistImportFile.files && elements.whitelistImportFile.files[0];
    if (!file) return;
    try {
      if (file.size > 1024 * 1024) throw new Error("file too large");
      const text = await file.text();
      let always, restart = [];
      try {
        const data = JSON.parse(text);
        always = Array.isArray(data) ? data : data.whitelist;
        if (data && Array.isArray(data.greylist)) restart = data.greylist;
      } catch (e) {
        always = text.split(/[\s,]+/); // plain text: one domain per line
      }
      if (!Array.isArray(always)) throw new Error("no whitelist found");
      let added = 0;
      const add = (entries, mode) => entries.forEach(entry => {
        const domain = CC.normalizeDomain(entry);
        if (!domain || settings.whitelist.includes(domain) || settings.greylist.includes(domain)) return;
        addTrusted(domain, mode);
        added++;
      });
      add(always, "always");
      add(restart, "restart");
      await saveSettings();
      renderWhitelist();
      if (currentDomain) updateActiveSiteCardStyle(CC.isHostProtected(currentDomain, settings));
      showToast(`Imported ${added} new domain${added === 1 ? "" : "s"}.`);
    } catch (e) {
      showToast("Could not import whitelist file.", "error");
    }
    elements.whitelistImportFile.value = "";
  });

  // Settings
  const bindToggle = (el, key) => el.addEventListener("change", (e) => {
    settings[key] = e.target.checked;
    saveSettings();
  });
  bindToggle(elements.settingAutoDelete, "autoDeleteOnTabClose");
  bindToggle(elements.settingDomainChange, "cleanOnDomainChange");
  bindToggle(elements.settingPrompt, "promptOnTabClose");
  bindToggle(elements.settingStartupClean, "cleanOnBrowserStart");

  elements.settingSiteData.addEventListener("change", async (e) => {
    settings.clearSiteData = e.target.checked;
    await saveSettings();
    updatePurgeLabel();
    showToast(settings.clearSiteData ? "Deep clean on: site storage is removed too." : "Deep clean off: only cookies are removed.");
  });

  elements.settingSchedule.addEventListener("change", async (e) => {
    settings.scheduledClean = e.target.value;
    await saveSettings();
    updateScheduleStatus(null);
    showToast(settings.scheduledClean === "off" ? "Scheduled cleaning turned off." : `Scheduled cleaning: ${e.target.options[e.target.selectedIndex].text.toLowerCase()}.`);
  });

  elements.settingDelay.addEventListener("change", async (e) => {
    settings.cleanupDelay = Number(e.target.value);
    await saveSettings();
    showToast(settings.cleanupDelay ? `Sites are cleaned ${e.target.options[e.target.selectedIndex].text.toLowerCase()} after you leave.` : "Sites are cleaned right after you leave.");
  });

  elements.settingAgeLimit.addEventListener("change", (e) => {
    settings.cookieAgeLimit = e.target.value;
    saveSettings();
    showToast("Cookie age limit updated.");
  });

  elements.btnForgetRecent.addEventListener("click", async () => {
    const recent = await CC.listRecent();
    await chrome.storage.session.remove(recent.map(r => "recent:" + r.id));
    await renderRecent();
    showToast("Forgot the recently cleaned cookies.");
  });

  elements.btnResetStats.addEventListener("click", async () => {
    if (!confirm("Reset privacy stats?")) return;
    stats = { clearedTotal: 0, clearedToday: 0, history: {}, lastResetDate: new Date().toDateString() };
    await chrome.storage.local.set({ stats });
    renderStatsNumbers();
    chrome.action.setBadgeText({ text: "" });
    updateDashboardCharts();
    showToast("Privacy stats reset successfully.");
  });
}

async function saveSettings() {
  await chrome.storage.local.set({ settings });
}

// Bar chart of cookies cleared per day over the last 14 days
function updateDashboardCharts() {
  const history = stats.history || {};
  const days = [];
  for (let i = 13; i >= 0; i--) {
    const date = new Date();
    date.setHours(12, 0, 0, 0);
    date.setDate(date.getDate() - i);
    days.push({ date, count: history[CC.dayKey(date)] || 0 });
  }
  const max = Math.max(...days.map(d => d.count));
  elements.statsWeek.innerText = days.slice(-7).reduce((sum, d) => sum + d.count, 0);
  elements.chartMax.innerText = max > 0 ? `peak ${max}/day` : "";
  elements.chartStart.innerText = days[0].date.toLocaleDateString([], { month: "short", day: "numeric" });

  elements.historyChart.innerHTML = days.map((d, i) => {
    const height = max > 0 ? Math.max(4, Math.round((d.count / max) * 100)) : 4;
    const label = `${d.date.toLocaleDateString([], { weekday: "short", month: "short", day: "numeric" })}: ${d.count} cookie${d.count === 1 ? "" : "s"}`;
    return `<div class="history-bar ${d.count === 0 ? "zero" : ""} ${i === 13 ? "today" : ""}" style="height:${d.count === 0 ? 2 : height}%" title="${escapeHtml(label)}"></div>`;
  }).join("");
}

function isTrackerDomain(domain) {
  const d = String(domain || "").toLowerCase();
  return TRACKER_PATTERNS.some(pattern => d.includes(pattern));
}

// --- Restore (undo for manual and automatic cleanups, kept until the browser closes) ---
function timeAgo(at) {
  const s = Math.max(0, Math.round((Date.now() - at) / 1000));
  if (s < 60) return "just now";
  if (s < 3600) return `${Math.floor(s / 60)} min ago`;
  if (s < 86400) return `${Math.floor(s / 3600)} h ago`;
  return new Date(at).toLocaleDateString();
}

async function restoreEntry(id) {
  const entry = await CC.takeRecent(id);
  if (!entry) {
    showToast("Already restored.");
    return;
  }
  const restored = await CC.restoreCookies(entry.cookies);
  if (restored > 0) {
    stats = await CC.addToStats(-restored, entry.at);
    renderStatsNumbers();
    updateDashboardCharts();
    chrome.action.setBadgeText({ text: CC.badgeText(stats.lastResetDate === new Date().toDateString() ? stats.clearedToday : 0) });
  }
  showToast(`Restored ${restored} cookie${restored === 1 ? "" : "s"}${entry.label ? ` (${entry.label})` : ""}.`);
  await loadActiveSiteCookies();
  if (cookieView === "third") await loadThirdPartyCookies();
  if (document.getElementById("tab-explorer").classList.contains("active")) await loadExplorerData(true);
  await renderRecent();
}

async function renderRecent() {
  let recent = [];
  try {
    recent = await CC.listRecent();
  } catch (e) {
    recent = [];
  }

  // Active Site tab: offer to restore this site's last cleanup
  const mine = currentDomain && recent.find(r => r.source !== "startup" && r.source !== "scheduled" && CC.sameSite(r.label, currentDomain));
  if (mine) {
    elements.siteRestore.hidden = false;
    elements.siteRestore.innerHTML = `
      <span>${escapeHtml(SOURCE_LABELS[mine.source] || "Cleaned")} ${escapeHtml(timeAgo(mine.at))}: ${mine.count} cookie${mine.count === 1 ? "" : "s"} removed.</span>
      <button class="btn-restore" data-id="${escapeHtml(mine.id)}">Restore</button>`;
    elements.siteRestore.querySelector(".btn-restore").addEventListener("click", () => restoreEntry(mine.id));
  } else {
    elements.siteRestore.hidden = true;
    elements.siteRestore.innerHTML = "";
  }

  // Settings tab: the full list
  elements.btnForgetRecent.hidden = !recent.length;
  if (!recent.length) {
    elements.recentList.innerHTML = `<p class="recent-empty">Nothing cleaned since the browser started.</p>`;
    return;
  }
  elements.recentList.innerHTML = recent.map(r => `
    <div class="recent-row">
      <div class="cookie-meta">
        <div class="recent-label" title="${escapeHtml(r.label)}">${escapeHtml(r.label)}</div>
        <div class="recent-meta">${escapeHtml(SOURCE_LABELS[r.source] || r.source)} · ${escapeHtml(timeAgo(r.at))} · ${r.count} cookie${r.count === 1 ? "" : "s"}${r.dataCleared ? " + site data" : ""}</div>
      </div>
      <button class="btn-restore" data-id="${escapeHtml(r.id)}" aria-label="Restore cookies of ${escapeHtml(r.label)}">Restore</button>
    </div>`).join("");
  elements.recentList.querySelectorAll(".btn-restore").forEach(btn => {
    btn.addEventListener("click", () => {
      btn.disabled = true;
      restoreEntry(btn.getAttribute("data-id"));
    });
  });
}

function showUndoToast(message) {
  showToast(message, "success", {
    label: "Undo",
    onClick: async () => {
      const recent = await CC.listRecent();
      const last = recent.find(r => r.source === "manual");
      if (last) await restoreEntry(last.id);
    }
  });
}

// --- Third-party cookies on the current page ---
function setCookieView(view) {
  cookieView = view;
  elements.segFirst.classList.toggle("active", view === "first");
  elements.segThird.classList.toggle("active", view === "third");
  elements.segFirst.setAttribute("aria-selected", view === "first" ? "true" : "false");
  elements.segThird.setAttribute("aria-selected", view === "third" ? "true" : "false");
  elements.currentCookiesList.hidden = view !== "first";
  elements.thirdPartyList.hidden = view !== "third";
  if (view === "third") loadThirdPartyCookies();
}

// Runs inside the page (isolated world): hostnames of every resource the page loaded
function collectPageHosts() {
  const hosts = new Set();
  const add = (u) => {
    try {
      const url = new URL(u, location.href);
      if (url.protocol === "http:" || url.protocol === "https:") hosts.add(url.hostname);
    } catch (e) {}
  };
  performance.getEntriesByType("resource").forEach(e => add(e.name));
  document.querySelectorAll("script[src], iframe[src], img[src], link[href]").forEach(el => add(el.src || el.href));
  return Array.from(hosts).slice(0, 500);
}

let thirdPartyRun = 0;
async function loadThirdPartyCookies() {
  const run = ++thirdPartyRun; // only the latest scan renders
  const list = elements.thirdPartyList;
  if (!currentDomain || !currentTabId) {
    list.innerHTML = `<p class="empty-message">Open a website to see its third-party cookies.</p>`;
    return;
  }
  list.innerHTML = `<p class="loading-message">Looking for third-party cookies...</p>`;

  let hosts = [];
  try {
    const [result] = await chrome.scripting.executeScript({ target: { tabId: currentTabId }, func: collectPageHosts });
    // The page controls this list, so treat it as untrusted: hostnames only
    hosts = ((result && result.result) || []).map(h => CC.normalizeDomain(h)).filter(Boolean);
  } catch (e) {
    list.innerHTML = `<p class="empty-message">This page can't be scanned (browser or store pages are protected).</p>`;
    elements.segThirdCount.innerText = "0";
    return;
  }

  const store = currentStoreId ? { storeId: currentStoreId } : {};
  const siteApex = getApexDomain(currentDomain);
  const thirdHosts = hosts.filter(h => getApexDomain(h) !== siteApex);
  const thirdApexes = Array.from(new Set(thirdHosts.map(getApexDomain)));
  const groups = {};
  await Promise.all(thirdApexes.map(async apex => {
    const cookies = await chrome.cookies.getAll({ ...store, domain: apex }).catch(() => []);
    // Only cookies the browser sends to a host this page actually loaded, so a shared
    // suffix such as github.io doesn't pull in unrelated sites
    const used = cookies.filter(c => {
      const d = CC.stripDot(c.domain);
      return thirdHosts.some(h => c.hostOnly ? h === d : CC.hostMatches(h, d));
    });
    if (used.length) groups[apex] = { apex, cookies: used, partitioned: 0 };
  }));

  // Partitioned (CHIPS) cookies that other domains set while embedded in this site
  const partitioned = (await CC.getAllCookies(store)).filter(c => {
    const top = CC.partitionHost(c);
    return c.partitionKey && top && getApexDomain(top) === siteApex;
  });
  partitioned.forEach(c => {
    const apex = getApexDomain(CC.stripDot(c.domain));
    if (!apex || apex === siteApex) return;
    const group = groups[apex] || (groups[apex] = { apex, cookies: [], partitioned: 0 });
    if (!group.cookies.some(x => CC.cookieKey(x) === CC.cookieKey(c))) {
      group.cookies.push(c);
      group.partitioned++;
    }
  });

  // Cookies used by sites open in other tabs (e.g. a signed-in mail tab) are kept by
  // "Delete all", so a page can't get you signed out elsewhere just by embedding a domain
  const otherHosts = await CC.openHosts(currentTabId);
  if (run !== thirdPartyRun) return;
  const items = Object.values(groups).map(g => {
    g.protectedCount = g.cookies.filter(c => CC.isCookieProtected(c, settings)).length;
    g.inUse = g.cookies.filter(c => !c.partitionKey && CC.isCookieInUse(c, otherHosts)).length;
    return g;
  }).sort((a, b) => {
    const ta = isTrackerDomain(a.apex), tb = isTrackerDomain(b.apex);
    return ta !== tb ? (ta ? -1 : 1) : b.cookies.length - a.cookies.length;
  });
  const total = items.reduce((n, g) => n + g.cookies.length, 0);
  elements.segThirdCount.innerText = total;

  if (!items.length) {
    list.innerHTML = `<p class="empty-message">No third-party cookies here.${thirdApexes.length ? ` This page loads ${thirdApexes.length} other domain${thirdApexes.length === 1 ? "" : "s"}, but none of them stores cookies.` : ""}</p>`;
    return;
  }

  list.innerHTML = items.map(g => {
    const allProtected = g.protectedCount === g.cookies.length;
    return `
      <div class="tp-row">
        <div class="cookie-meta">
          <div class="tp-domain">${escapeHtml(g.apex)}</div>
          <div class="tp-meta">
            <span>${g.cookies.length} cookie${g.cookies.length === 1 ? "" : "s"}</span>
            ${isTrackerDomain(g.apex) ? '<span class="badge-tag tracker">Tracker</span>' : ""}
            ${g.partitioned ? `<span class="badge-tag partitioned" title="Partitioned cookies only readable on this site">${g.partitioned} partitioned</span>` : ""}
            ${g.protectedCount ? `<span class="badge-tag secure" title="Kept: protected by your trusted sites">${allProtected ? "Trusted" : `${g.protectedCount} trusted`}</span>` : ""}
            ${g.inUse ? `<span class="badge-tag inuse" title="Also used by a site open in another tab">open in a tab</span>` : ""}
          </div>
        </div>
        <button class="btn-icon btn-purge-third" data-apex="${escapeHtml(g.apex)}" ${allProtected ? "disabled" : ""}
          aria-label="Delete cookies of ${escapeHtml(g.apex)}" title="${allProtected ? "Trusted: kept" : `Delete cookies of ${escapeHtml(g.apex)}`}">${TRASH_SVG}</button>
      </div>`;
  }).join("") + `
    <div class="tp-footer">
      <span class="tp-note">${items.length} of ${thirdApexes.length} loaded domain${thirdApexes.length === 1 ? "" : "s"} store cookies</span>
      <button class="btn-text" id="btn-purge-all-third">Delete all third-party</button>
    </div>`;

  list.querySelectorAll(".btn-purge-third").forEach(btn => {
    btn.addEventListener("click", async () => {
      const group = groups[btn.getAttribute("data-apex")];
      if (!group) return;
      const targets = group.cookies.filter(c => !CC.isCookieProtected(c, settings));
      if (group.inUse && !confirm(`Some cookies of ${group.apex} are used by a site open in another tab. Deleting them may sign you out there. Continue?`)) return;
      btn.disabled = true;
      const count = await purge(targets, group.apex);
      showUndoToast(`Deleted ${count} cookie${count === 1 ? "" : "s"} of ${group.apex}.`);
      await loadThirdPartyCookies();
    });
  });
  document.getElementById("btn-purge-all-third").addEventListener("click", async () => {
    const all = items.flatMap(g => g.cookies);
    const targets = all.filter(c => !CC.isCookieProtected(c, settings) && (c.partitionKey || !CC.isCookieInUse(c, otherHosts)));
    const kept = all.length - targets.length;
    const count = await purge(targets, "Third-party cookies");
    showUndoToast(`Deleted ${count} third-party cookie${count === 1 ? "" : "s"}.${kept ? ` Kept ${kept} (trusted or open in a tab).` : ""}`);
    await loadThirdPartyCookies();
  });
}

// Toast notification helper (one at a time)
function showToast(message, type = "success", action = null) {
  elements.toastContainer.innerHTML = "";
  const toast = document.createElement("div");
  toast.className = `toast ${type === "error" ? "toast-error" : ""}`;
  toast.setAttribute("role", "status");
  toast.innerHTML = `
    <span>${escapeHtml(message)}</span>
    ${action ? `<button class="toast-action">${escapeHtml(action.label)}</button>` : ""}
    <button class="toast-close" aria-label="Close">&times;</button>
  `;
  elements.toastContainer.appendChild(toast);

  const autoClose = setTimeout(() => {
    toast.style.opacity = "0";
    toast.style.transform = "translateY(10px)";
    setTimeout(() => toast.remove(), 300);
  }, action ? 7000 : 3000);

  if (action) {
    toast.querySelector(".toast-action").addEventListener("click", () => {
      clearTimeout(autoClose);
      toast.remove();
      action.onClick();
    });
  }
  toast.querySelector(".toast-close").addEventListener("click", () => {
    clearTimeout(autoClose);
    toast.remove();
  });
}

function escapeHtml(str) {
  if (str === null || str === undefined) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}
