// CookieClean - Popup Control Panel Script

// State
let currentDomain = "";
let currentUrl = "";
let settings = {};
let stats = {};
let explorerFilter = "all"; // "all" or "suspicious"

// Default settings fallback
const DEFAULT_SETTINGS = {
  extensionEnabled: true,
  autoDeleteOnTabClose: true,
  cleanOnDomainChange: false,
  promptOnTabClose: false,
  cleanOnBrowserStart: true,
  cookieAgeLimit: "none",
  whitelist: []
};

// DOM Elements
const elements = {
  // Navigation Tabs
  tabButtons: document.querySelectorAll(".tab-btn"),
  tabPanels: document.querySelectorAll(".tab-panel"),
  
  // Global Toggle
  globalToggle: document.getElementById("global-toggle"),
  
  // Active Site Tab
  currentDomainText: document.getElementById("current-domain"),
  currentSiteStatus: document.getElementById("current-site-status"),
  currentCookieCount: document.getElementById("current-cookie-count"),
  privacyScore: document.getElementById("privacy-score"),
  siteFavicon: document.getElementById("site-favicon"),
  btnPurgeCurrent: document.getElementById("btn-purge-current"),
  btnWhitelistCurrent: document.getElementById("btn-whitelist-current"),
  whitelistCurrentText: document.getElementById("whitelist-current-text"),
  currentCookiesList: document.getElementById("current-cookies-list"),
  activeSiteCard: document.querySelector(".active-site-card"),
  
  // Explorer Tab
  explorerSearch: document.getElementById("explorer-search"),
  btnPurgeAll: document.getElementById("btn-purge-all"),
  explorerSitesList: document.getElementById("explorer-sites-list"),
  btnFilterAll: document.getElementById("btn-filter-all"),
  btnFilterSuspicious: document.getElementById("btn-filter-suspicious"),
  
  // Whitelist Tab
  whitelistInput: document.getElementById("whitelist-input"),
  btnAddWhitelist: document.getElementById("btn-add-whitelist"),
  whitelistSitesList: document.getElementById("whitelist-sites-list"),
  
  // Settings & Stats
  statsTotal: document.getElementById("stats-total"),
  statsToday: document.getElementById("stats-today"),
  btnResetStats: document.getElementById("btn-reset-stats"),
  sparklinePath: document.getElementById("sparkline-path"),
  sparklineFill: document.getElementById("sparkline-fill"),
  
  settingAutoDelete: document.getElementById("setting-auto-delete"),
  settingDomainChange: document.getElementById("setting-domain-change"),
  btnExportWhitelist: document.getElementById("btn-export-whitelist"),
  btnImportWhitelist: document.getElementById("btn-import-whitelist"),
  whitelistImportFile: document.getElementById("whitelist-import-file"),
  appVersion: document.getElementById("app-version"),
  settingPrompt: document.getElementById("setting-prompt"),
  settingStartupClean: document.getElementById("setting-startup-clean"),
  settingAgeLimit: document.getElementById("setting-age-limit"),
  
  toastContainer: document.getElementById("toast-container")
};

// Initialize Popup
document.addEventListener("DOMContentLoaded", async () => {
  await loadSettingsAndStats();
  setupTabNavigation();
  await detectActiveTab();
  setupEventListeners();
  updateDashboardCharts();
});

// Load Settings and Stats from Chrome Storage
async function loadSettingsAndStats() {
  const localData = await chrome.storage.local.get(["settings", "stats"]);
  settings = { ...DEFAULT_SETTINGS, ...(localData.settings || {}) };
  if (!Array.isArray(settings.whitelist)) settings.whitelist = [];
  elements.appVersion.innerText = "v" + chrome.runtime.getManifest().version;
  stats = localData.stats || { clearedTotal: 0, clearedToday: 0, lastResetDate: new Date().toDateString() };
  if (stats.lastResetDate !== new Date().toDateString()) {
    stats.clearedToday = 0;
  }

  // Bind UI Controls
  elements.globalToggle.checked = settings.extensionEnabled;
  elements.settingAutoDelete.checked = settings.autoDeleteOnTabClose;
  elements.settingDomainChange.checked = settings.cleanOnDomainChange;
  elements.settingPrompt.checked = settings.promptOnTabClose;
  elements.settingStartupClean.checked = settings.cleanOnBrowserStart;
  elements.settingAgeLimit.value = settings.cookieAgeLimit;
  
  // Stats
  elements.statsTotal.innerText = stats.clearedTotal;
  elements.statsToday.innerText = stats.clearedToday;

  // Toggle display mode based on extension status
  toggleExtensionUIState(settings.extensionEnabled);
}

// Enable/Disable UI styling based on global switch
function toggleExtensionUIState(isEnabled) {
  const wrapper = document.querySelector(".tab-content-wrapper");
  if (isEnabled) {
    wrapper.style.opacity = "1";
    wrapper.style.pointerEvents = "auto";
  } else {
    wrapper.style.opacity = "0.4";
    wrapper.style.pointerEvents = "none";
    showToast("CookieClean is currently disabled.", "error");
  }
}

// Setup Tab Navigation
function setupTabNavigation() {
  elements.tabButtons.forEach(btn => {
    btn.addEventListener("click", () => {
      // Remove active from buttons
      elements.tabButtons.forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      
      // Toggle panels
      const targetTab = btn.getAttribute("data-tab");
      elements.tabPanels.forEach(panel => {
        if (panel.id === targetTab) {
          panel.classList.add("active");
          // Action triggers on opening tabs
          if (targetTab === "tab-explorer") {
            loadExplorerData();
          } else if (targetTab === "tab-whitelist") {
            renderWhitelist();
          }
        } else {
          panel.classList.remove("active");
        }
      });
    });
  });
}

// Helper: Extract apex domain (e.g. google.com from accounts.google.com)
function getApexDomain(domain) {
  if (!domain) return "";
  const parts = domain.split(".");
  if (parts.length > 2) {
    // Basic logic for generic domains. Handles co.uk, com.au, etc. simply
    const secondLast = parts[parts.length - 2];
    if (["com", "co", "org", "net", "gov", "edu"].includes(secondLast) && parts.length > 2) {
      return parts.slice(-3).join(".");
    }
    return parts.slice(-2).join(".");
  }
  return domain;
}

// Detect the current active tab
async function detectActiveTab() {
  try {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tabs.length === 0) return;
    
    const tab = tabs[0];
    currentUrl = tab.url;
    
    if (!currentUrl || currentUrl.startsWith("chrome://") || currentUrl.startsWith("chrome-extension://") || currentUrl.startsWith("edge://") || currentUrl.startsWith("about:")) {
      // System or Extension page
      elements.currentDomainText.innerText = "System Page";
      elements.currentDomainText.title = "System Page";
      elements.currentSiteStatus.className = "status-indicator safe";
      elements.currentSiteStatus.innerText = "Secure Zone";
      elements.currentCookieCount.innerText = "0";
      elements.privacyScore.innerText = "N/A";
      elements.btnPurgeCurrent.disabled = true;
      elements.btnWhitelistCurrent.disabled = true;
      elements.currentCookiesList.innerHTML = `<p class="empty-message">No cookies can be read on browser system pages.</p>`;
      return;
    }

    const urlObj = new URL(currentUrl);
    currentDomain = urlObj.hostname;
    
    elements.currentDomainText.innerText = currentDomain;
    elements.currentDomainText.title = currentDomain;
    
    // Favicon loading
    if (tab.favIconUrl) {
      elements.siteFavicon.innerHTML = `<img src="${escapeHtml(tab.favIconUrl)}" width="20" height="20" style="object-fit: contain;">`;
    } else {
      elements.siteFavicon.innerText = "🌐";
    }

    await loadActiveSiteCookies();
  } catch (error) {
    console.error("CookieClean: Active tab detection failed", error);
    elements.currentDomainText.innerText = "Access Blocked";
    elements.currentCookiesList.innerHTML = `<p class="empty-message">Unable to query cookies. Check site permissions.</p>`;
  }
}

// Load cookies for the active domain
async function loadActiveSiteCookies() {
  if (!currentDomain) return;

  // Check if whitelisted
  const whitelisted = isWhitelisted(currentDomain, settings.whitelist);
  updateActiveSiteCardStyle(whitelisted);

  try {
    const cookies = await getSiteCookies();
    const count = cookies.length;

    // Display count
    elements.currentCookieCount.innerText = count;

    // Calculate score
    const scoreInfo = calculatePrivacyScore(cookies);
    elements.privacyScore.innerText = scoreInfo.grade;
    elements.privacyScore.className = `stat-num ${scoreInfo.class}`;

    // Render list
    renderActiveSiteCookiesList(cookies);

  } catch (error) {
    console.error("Error reading cookies", error);
    elements.currentCookieCount.innerText = "Error";
    elements.privacyScore.innerText = "F";
  }
}

// Cookies for the active site: those sent to the page URL (incl. parent-domain cookies)
// plus cookies set on the host and its subdomains
async function getSiteCookies() {
  const [byUrl, byDomain] = await Promise.all([
    chrome.cookies.getAll({ url: currentUrl }),
    chrome.cookies.getAll({ domain: currentDomain })
  ]);
  const seen = new Set();
  return [...byUrl, ...byDomain].filter(c => {
    const key = `${c.storeId}|${c.domain}|${c.path}|${c.name}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

// Helper: Check if domain matches whitelist (subdomains included)
function isWhitelisted(domain, whitelist) {
  if (!domain || !whitelist) return false;
  const cleanDomain = domain.toLowerCase();
  for (const item of whitelist) {
    const cleanItem = item.toLowerCase();
    if (cleanDomain === cleanItem || cleanDomain.endsWith("." + cleanItem)) {
      return true;
    }
  }
  return false;
}

// Helper: Check if a domain has suspicious characteristics or tracking cookies
function checkDomainSuspicion(domain, cookies) {
  const reasons = [];
  
  // 1. Tracker patterns check
  const trackerPatterns = [
    'doubleclick', 'google-analytics', 'googleadservices', 'adnxs', 'rubiconproject',
    'pubmatic', 'quantserve', 'scorecardresearch', 'taboola', 'outbrain', 'criteo',
    'hotjar', 'crazyegg', 'adroll', 'amazon-adsystem', 'bluekai', 'optimizely', 'amplitude'
  ];
  const isTrackerName = trackerPatterns.some(pattern => domain.toLowerCase().includes(pattern));
  if (isTrackerName) {
    reasons.push("Known tracker/analytics domain");
  }

  // 2. High Cookie Count
  if (cookies.length > 15) {
    reasons.push(`Excessive cookies stored (${cookies.length})`);
  }

  // 3. Persistent Beacons (long expiration)
  const twoYearsSeconds = 2 * 365 * 24 * 60 * 60;
  const nowSeconds = Math.floor(Date.now() / 1000);
  const hasLongLived = cookies.some(c => c.expirationDate && (c.expirationDate - nowSeconds) > twoYearsSeconds);
  if (hasLongLived) {
    reasons.push("Contains persistent tracking cookies (> 2 years)");
  }

  // 4. Sensitive but Insecure
  const sensitiveNames = ['session', 'sid', 'token', 'auth', 'login', 'jwt', 'user'];
  const hasInsecureSensitive = cookies.some(c => {
    const nameLower = c.name.toLowerCase();
    const isSensitive = sensitiveNames.some(s => nameLower.includes(s));
    return isSensitive && (!c.secure || !c.httpOnly);
  });
  if (hasInsecureSensitive) {
    reasons.push("Sensitive login/session cookies lack Secure or HttpOnly protection");
  }

  return {
    isSuspicious: reasons.length > 0,
    reasons: reasons
  };
}

// Update Active Site Card Styling
function updateActiveSiteCardStyle(isWhitelisted) {
  elements.activeSiteCard.className = "card active-site-card";
  if (isWhitelisted) {
    elements.activeSiteCard.classList.add("whitelisted-site");
    elements.currentSiteStatus.className = "status-indicator warn";
    elements.currentSiteStatus.innerText = "Trusted (Safe)";
    elements.whitelistCurrentText.innerText = "Remove Trust (Delete)";
    elements.btnWhitelistCurrent.querySelector(".icon-shield").style.stroke = "var(--color-yellow)";
  } else {
    elements.activeSiteCard.classList.add("unsafe-site");
    elements.currentSiteStatus.className = "status-indicator danger";
    elements.currentSiteStatus.innerText = "Monitored";
    elements.whitelistCurrentText.innerText = "Trust Site (Whitelist)";
    elements.btnWhitelistCurrent.querySelector(".icon-shield").style.stroke = "currentColor";
  }
}

// Calculate Privacy Score (A+ to F)
function calculatePrivacyScore(cookies) {
  if (!cookies || cookies.length === 0) {
    return { grade: "A+", class: "safe" };
  }

  let points = 100;
  
  // Deduct based on cookie count
  if (cookies.length > 50) points -= 35;
  else if (cookies.length > 30) points -= 25;
  else if (cookies.length > 15) points -= 15;
  else if (cookies.length > 5) points -= 8;

  // Secure and HttpOnly flags check
  let insecureCount = 0;
  let missingHttpOnlyCount = 0;

  cookies.forEach(c => {
    if (!c.secure) insecureCount++;
    if (!c.httpOnly) missingHttpOnlyCount++;
  });

  const percentInsecure = (insecureCount / cookies.length) * 100;
  const percentMissingHttpOnly = (missingHttpOnlyCount / cookies.length) * 100;

  if (percentInsecure > 50) points -= 15;
  else if (percentInsecure > 20) points -= 8;

  if (percentMissingHttpOnly > 50) points -= 15;
  else if (percentMissingHttpOnly > 20) points -= 8;

  let grade = "A";
  let gradeClass = "safe";

  if (points >= 95) { grade = "A+"; gradeClass = "safe"; }
  else if (points >= 88) { grade = "A"; gradeClass = "safe"; }
  else if (points >= 80) { grade = "B"; gradeClass = "warn"; }
  else if (points >= 70) { grade = "C"; gradeClass = "warn"; }
  else if (points >= 55) { grade = "D"; gradeClass = "danger"; }
  else { grade = "F"; gradeClass = "danger"; }

  return { grade, class: gradeClass };
}

// Render active site cookies in detail panel
function renderActiveSiteCookiesList(cookies) {
  const savedScrollTop = elements.currentCookiesList.scrollTop;

  if (!cookies || cookies.length === 0) {
    elements.currentCookiesList.innerHTML = `<p class="empty-message">No cookies stored by this site.</p>`;
    return;
  }

  let html = "";
  cookies.forEach(cookie => {
    const isSecure = cookie.secure;
    const isHttpOnly = cookie.httpOnly;
    const expiryStr = cookie.expirationDate 
      ? new Date(cookie.expirationDate * 1000).toLocaleDateString()
      : "Session";

    html += `
      <div class="cookie-item">
        <div class="cookie-meta">
          <div class="cookie-name" title="${escapeHtml(cookie.name)}">${escapeHtml(cookie.name)}</div>
          <div class="cookie-submeta">
            <span>Exp: ${expiryStr}</span>
            ${isSecure ? '<span class="badge-tag secure">Secure</span>' : ''}
            ${isHttpOnly ? '<span class="badge-tag">HttpOnly</span>' : ''}
          </div>
        </div>
        <button class="btn-icon btn-delete-single" data-name="${encodeURIComponent(cookie.name)}" data-secure="${cookie.secure}" data-domain="${encodeURIComponent(cookie.domain)}" data-store="${encodeURIComponent(cookie.storeId)}" data-path="${encodeURIComponent(cookie.path)}">
          <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="3 6 5 6 21 6"></polyline>
            <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
          </svg>
        </button>
      </div>
    `;
  });

  elements.currentCookiesList.innerHTML = html;
  elements.currentCookiesList.scrollTop = savedScrollTop;

  // Bind single delete actions
  elements.currentCookiesList.querySelectorAll(".btn-delete-single").forEach(btn => {
    btn.addEventListener("click", async (e) => {
      const name = decodeURIComponent(btn.getAttribute("data-name"));
      const path = decodeURIComponent(btn.getAttribute("data-path"));
      const isSecure = btn.getAttribute("data-secure") === "true";
      
      const protocol = isSecure ? "https://" : "http://";
      const cookieDomain = decodeURIComponent(btn.getAttribute("data-domain"));
      const storeId = decodeURIComponent(btn.getAttribute("data-store"));
      const cleanDomain = cookieDomain.startsWith('.') ? cookieDomain.substring(1) : cookieDomain;
      const url = protocol + cleanDomain + path;

      try {
        await chrome.cookies.remove({ url, name, storeId });
        showToast(`Cleared cookie: ${name}`);
        await loadActiveSiteCookies();
        await updateClearedCount(1);
      } catch (err) {
        showToast("Error clearing cookie.", "error");
      }
    });
  });
}

// TAB 2: Load Explorer Data (All Cookies)
async function loadExplorerData(preserveScroll = false) {
  const savedScrollTop = preserveScroll ? elements.explorerSitesList.scrollTop : 0;
  if (!preserveScroll) {
    elements.explorerSitesList.innerHTML = `<p class="loading-message">Reading cookies...</p>`;
  }
  
  try {
    const cookies = await chrome.cookies.getAll({});
    
    // Group by site domain
    const sites = {};
    cookies.forEach(cookie => {
      // Strip leading dot
      const domain = cookie.domain.startsWith('.') ? cookie.domain.substring(1) : cookie.domain;
      if (!sites[domain]) {
        sites[domain] = [];
      }
      sites[domain].push(cookie);
    });

    const searchQuery = elements.explorerSearch.value.trim().toLowerCase();
    
    // Process and analyze domains
    let processedDomains = Object.keys(sites).map(domain => {
      const suspicion = checkDomainSuspicion(domain, sites[domain]);
      return {
        domain,
        cookies: sites[domain],
        suspicion
      };
    });

    // Filter by search query
    processedDomains = processedDomains.filter(item => item.domain.includes(searchQuery));

    // Filter by high risk if toggle is on
    if (explorerFilter === "suspicious") {
      processedDomains = processedDomains.filter(item => item.suspicion.isSuspicious);
    }

    // Sort by cookie count descending
    processedDomains.sort((a, b) => b.cookies.length - a.cookies.length);

    if (processedDomains.length === 0) {
      elements.explorerSitesList.innerHTML = `<p class="empty-message">No matching cookies found.</p>`;
      return;
    }

    let html = "";
    processedDomains.forEach(item => {
      const domain = item.domain;
      const count = item.cookies.length;
      const whitelisted = isWhitelisted(domain, settings.whitelist);
      const suspicion = item.suspicion;
      
      let badgeHtml = "";
      if (whitelisted) {
        badgeHtml = '• <span style="color:var(--color-yellow)">Protected</span>';
      } else if (suspicion.isSuspicious) {
        badgeHtml = '• <span style="color:var(--color-coral); font-weight:600;">⚠️ High Risk</span>';
      }
      
      let reasonsHtml = "";
      if (suspicion.isSuspicious) {
        reasonsHtml = `<span class="suspicious-reasons">Risk: ${suspicion.reasons.join('; ')}</span>`;
      }
      
      html += `
        <div class="site-row">
          <div class="site-domain-info">
            <span class="site-name" title="${escapeHtml(domain)}">${escapeHtml(domain)}</span>
            <span class="site-cookies-tag">${count} cookie${count > 1 ? 's' : ''} ${badgeHtml}</span>
            ${reasonsHtml}
          </div>
          <div class="site-actions">
            <button class="btn-icon btn-purge-site" data-domain="${escapeHtml(domain)}" title="Clear cookies for ${escapeHtml(domain)}">
              <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2">
                <polyline points="3 6 5 6 21 6"></polyline>
                <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
              </svg>
            </button>
          </div>
        </div>
      `;
    });

    elements.explorerSitesList.innerHTML = html;
    if (preserveScroll) {
      elements.explorerSitesList.scrollTop = savedScrollTop;
    }

    // Bind clean actions
    elements.explorerSitesList.querySelectorAll(".btn-purge-site").forEach(btn => {
      btn.addEventListener("click", async () => {
        const domain = btn.getAttribute("data-domain");
        btn.disabled = true;
        
        const count = await clearCookiesForDomain(domain);
        if (count > 0) {
          showToast(`Cleared ${count} cookies for ${domain}`);
          await updateClearedCount(count);
          if (domain === currentDomain) {
            await loadActiveSiteCookies();
          }
          await loadExplorerData(true);
        } else {
          showToast("No cookies cleared.");
          btn.disabled = false;
        }
      });
    });

  } catch (err) {
    console.error("Explorer load error", err);
    elements.explorerSitesList.innerHTML = `<p class="empty-message">Error querying cookie store.</p>`;
  }
}

// TAB 3: Render Whitelist
function renderWhitelist() {
  const list = settings.whitelist || [];
  
  if (list.length === 0) {
    elements.whitelistSitesList.innerHTML = `<p class="empty-message">No safe domains configured yet.</p>`;
    return;
  }

  let html = "";
  list.forEach(domain => {
    html += `
      <div class="whitelist-item">
        <span>${escapeHtml(domain)}</span>
        <button class="btn-icon btn-remove-whitelist" data-domain="${escapeHtml(domain)}">
          <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2">
            <line x1="18" y1="6" x2="6" y2="18"></line>
            <line x1="6" y1="6" x2="18" y2="18"></line>
          </svg>
        </button>
      </div>
    `;
  });

  elements.whitelistSitesList.innerHTML = html;

  // Bind removal actions
  elements.whitelistSitesList.querySelectorAll(".btn-remove-whitelist").forEach(btn => {
    btn.addEventListener("click", async () => {
      const domain = btn.getAttribute("data-domain");
      settings.whitelist = settings.whitelist.filter(d => d !== domain);
      await saveSettings();
      renderWhitelist();
      showToast(`Removed "${domain}" from whitelist.`);
      
      // Update active card styling if active domain matches
      if (domain === currentDomain) {
        updateActiveSiteCardStyle(false);
      }
    });
  });
}

// Add event listeners
function setupEventListeners() {
  // Global switch
  elements.globalToggle.addEventListener("change", async (e) => {
    settings.extensionEnabled = e.target.checked;
    await saveSettings();
    toggleExtensionUIState(settings.extensionEnabled);
    if (settings.extensionEnabled) {
      showToast("CookieClean protection is ON.");
    } else {
      showToast("CookieClean protection is OFF.", "error");
    }
  });

  // Active Tab Purge Button
  elements.btnPurgeCurrent.addEventListener("click", async () => {
    if (!currentDomain) return;
    elements.btnPurgeCurrent.disabled = true;
    
    // Quick rolling numbers animation helper
    let counter = parseInt(elements.currentCookieCount.innerText) || 0;
    const interval = setInterval(() => {
      if (counter <= 0) {
        clearInterval(interval);
      } else {
        counter = Math.max(0, counter - Math.ceil(counter / 5));
        elements.currentCookieCount.innerText = counter;
      }
    }, 40);

    let cleared = 0;
    try {
      const siteCookies = await getSiteCookies();
      for (const cookie of siteCookies) {
        const protocol = cookie.secure ? "https://" : "http://";
        const cleanDomain = cookie.domain.startsWith('.') ? cookie.domain.substring(1) : cookie.domain;
        await chrome.cookies.remove({ url: protocol + cleanDomain + cookie.path, name: cookie.name, storeId: cookie.storeId });
        cleared++;
      }
    } catch (error) {
      console.error(`Error deleting cookies for ${currentDomain}`, error);
    }
    clearInterval(interval);
    
    elements.currentCookieCount.innerText = "0";
    elements.privacyScore.innerText = "A+";
    elements.privacyScore.className = "stat-num safe";
    elements.currentCookiesList.innerHTML = `<p class="empty-message">No cookies stored by this site.</p>`;
    
    showToast(`Purged ${cleared} cookies successfully.`);
    await updateClearedCount(cleared);
    
    setTimeout(() => {
      elements.btnPurgeCurrent.disabled = false;
    }, 1000);
  });

  // Active Tab Whitelist Button
  elements.btnWhitelistCurrent.addEventListener("click", async () => {
    if (!currentDomain) return;
    
    if (isWhitelisted(currentDomain, settings.whitelist)) {
      // Remove every entry that protects this site (exact or parent domain)
      const removed = settings.whitelist.filter(item => isWhitelisted(currentDomain, [item]));
      settings.whitelist = settings.whitelist.filter(item => !removed.includes(item));
      showToast(`Removed "${removed.join(", ")}" from whitelist.`);
    } else {
      // Add to Whitelist
      settings.whitelist.push(currentDomain);
      showToast(`Added "${currentDomain}" to whitelist.`);
    }
    
    await saveSettings();
    updateActiveSiteCardStyle(isWhitelisted(currentDomain, settings.whitelist));
  });

  // Explorer search filtering
  let searchTimeout;
  elements.explorerSearch.addEventListener("input", () => {
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(loadExplorerData, 200);
  });

  // Explorer filter buttons (All Sites vs High Risk Sites)
  elements.btnFilterAll.addEventListener("click", () => {
    explorerFilter = "all";
    elements.btnFilterAll.classList.add("active");
    elements.btnFilterSuspicious.classList.remove("active");
    loadExplorerData();
  });

  elements.btnFilterSuspicious.addEventListener("click", () => {
    explorerFilter = "suspicious";
    elements.btnFilterSuspicious.classList.add("active");
    elements.btnFilterAll.classList.remove("active");
    loadExplorerData();
  });

  // Purge ALL cookies button
  elements.btnPurgeAll.addEventListener("click", async () => {
    const doubleConfirm = confirm("Are you sure you want to delete ALL cookies stored in Chrome (excluding whitelisted sites)? This will log you out of most sites.");
    if (!doubleConfirm) return;

    elements.btnPurgeAll.disabled = true;
    elements.btnPurgeAll.innerText = "Purging...";

    try {
      const cookies = await chrome.cookies.getAll({});
      let cleared = 0;
      
      for (const cookie of cookies) {
        const domain = cookie.domain.startsWith('.') ? cookie.domain.substring(1) : cookie.domain;
        if (!isWhitelisted(domain, settings.whitelist)) {
          const protocol = cookie.secure ? "https://" : "http://";
          const url = protocol + domain + cookie.path;
          
          await chrome.cookies.remove({
            url: url,
            name: cookie.name,
            storeId: cookie.storeId
          });
          cleared++;
        }
      }

      showToast(`Bulk purged ${cleared} cookies.`);
      await updateClearedCount(cleared);
      await loadActiveSiteCookies();
      await loadExplorerData();
    } catch (e) {
      showToast("Purge failed.", "error");
    } finally {
      elements.btnPurgeAll.disabled = false;
      elements.btnPurgeAll.innerText = "Clear All Cookies";
    }
  });

  // Add domain to whitelist manually
  elements.btnAddWhitelist.addEventListener("click", async () => {
    let rawInput = normalizeDomain(elements.whitelistInput.value);
    if (!rawInput) {
      showToast("Please enter a valid domain, e.g. github.com", "error");
      return;
    }

    if (settings.whitelist.includes(rawInput)) {
      showToast("Domain is already in the whitelist.", "error");
      return;
    }

    settings.whitelist.push(rawInput);
    await saveSettings();
    
    elements.whitelistInput.value = "";
    renderWhitelist();
    showToast(`Added "${rawInput}" to whitelist.`);
    
    // Update active site details if the new entry protects it
    if (currentDomain && isWhitelisted(currentDomain, [rawInput])) {
      updateActiveSiteCardStyle(true);
    }
  });

  // Whitelist export / import
  elements.btnExportWhitelist.addEventListener("click", () => {
    const blob = new Blob([JSON.stringify({ whitelist: settings.whitelist }, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "cookieclean-whitelist.json";
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  });

  elements.btnImportWhitelist.addEventListener("click", () => elements.whitelistImportFile.click());

  elements.whitelistImportFile.addEventListener("change", async () => {
    const file = elements.whitelistImportFile.files && elements.whitelistImportFile.files[0];
    if (!file) return;
    try {
      const text = await file.text();
      let entries;
      try {
        const data = JSON.parse(text);
        entries = Array.isArray(data) ? data : data.whitelist;
      } catch (e) {
        entries = text.split(/[\s,]+/); // plain text: one domain per line
      }
      if (!Array.isArray(entries)) throw new Error("no whitelist found");
      let added = 0;
      for (const entry of entries) {
        const domain = normalizeDomain(String(entry));
        if (domain && !settings.whitelist.includes(domain)) {
          settings.whitelist.push(domain);
          added++;
        }
      }
      await saveSettings();
      renderWhitelist();
      if (currentDomain) updateActiveSiteCardStyle(isWhitelisted(currentDomain, settings.whitelist));
      showToast(`Imported ${added} new domain${added === 1 ? "" : "s"}.`);
    } catch (e) {
      showToast("Could not import whitelist file.", "error");
    }
    elements.whitelistImportFile.value = "";
  });

  // Enter key support for whitelist input
  elements.whitelistInput.addEventListener("keypress", (e) => {
    if (e.key === "Enter") {
      elements.btnAddWhitelist.click();
    }
  });

  // Settings Toggles Change Events
  elements.settingAutoDelete.addEventListener("change", (e) => {
    settings.autoDeleteOnTabClose = e.target.checked;
    saveSettings();
  });

  elements.settingDomainChange.addEventListener("change", (e) => {
    settings.cleanOnDomainChange = e.target.checked;
    saveSettings();
  });

  elements.settingPrompt.addEventListener("change", (e) => {
    settings.promptOnTabClose = e.target.checked;
    saveSettings();
  });

  elements.settingStartupClean.addEventListener("change", (e) => {
    settings.cleanOnBrowserStart = e.target.checked;
    saveSettings();
  });

  elements.settingAgeLimit.addEventListener("change", (e) => {
    settings.cookieAgeLimit = e.target.value;
    saveSettings();
    showToast(`Cookie age limit updated.`);
  });

  // Reset Stats Button
  elements.btnResetStats.addEventListener("click", async () => {
    if (confirm("Reset privacy stats?")) {
      stats.clearedTotal = 0;
      stats.clearedToday = 0;
      stats.lastResetDate = new Date().toDateString();
      await chrome.storage.local.set({ stats });
      
      elements.statsTotal.innerText = "0";
      elements.statsToday.innerText = "0";
      chrome.action.setBadgeText({ text: "" });
      
      updateDashboardCharts();
      showToast("Privacy stats reset successfully.");
    }
  });
}

// Clear all cookies for a domain directly (similar to background helper)
async function clearCookiesForDomain(domain) {
  try {
    const cookies = await chrome.cookies.getAll({ domain: domain });
    if (!cookies || cookies.length === 0) return 0;

    let cleared = 0;
    for (const cookie of cookies) {
      const protocol = cookie.secure ? "https://" : "http://";
      const cleanDomain = cookie.domain.startsWith('.') ? cookie.domain.substring(1) : cookie.domain;
      const url = protocol + cleanDomain + cookie.path;

      await chrome.cookies.remove({
        url: url,
        name: cookie.name,
        storeId: cookie.storeId
      });
      cleared++;
    }
    return cleared;
  } catch (error) {
    console.error(`Error deleting cookies for domain ${domain}`, error);
    return 0;
  }
}

// Turn user input (URL, "*.example.com", ".example.com", "Example.com/path") into a bare hostname
function normalizeDomain(input) {
  let value = String(input || "").trim().toLowerCase();
  if (!value) return "";
  try {
    if (/^[a-z][a-z0-9+.-]*:\/\//.test(value)) value = new URL(value).hostname;
  } catch (e) {
    return "";
  }
  value = value.split(/[\/?#:]/)[0].replace(/^\*\./, "").replace(/^\.+/, "").replace(/\.+$/, "");
  if (!/^[a-z0-9-]+(\.[a-z0-9-]+)*$/.test(value) || value.length > 253) return "";
  return value;
}

// Save Settings utility
async function saveSettings() {
  await chrome.storage.local.set({ settings });
}

// Update Stats utility
async function updateClearedCount(count) {
  if (count <= 0) return;
  
  const todayStr = new Date().toDateString();
  if (stats.lastResetDate !== todayStr) {
    stats.clearedToday = 0;
    stats.lastResetDate = todayStr;
  }

  stats.clearedTotal += count;
  stats.clearedToday += count;
  
  await chrome.storage.local.set({ stats });
  
  elements.statsTotal.innerText = stats.clearedTotal;
  elements.statsToday.innerText = stats.clearedToday;

  // Set background action badge
  chrome.action.setBadgeText({ text: stats.clearedToday.toString() });
  chrome.action.setBadgeBackgroundColor({ color: "#ff5e7e" });
  
  updateDashboardCharts();
}

// Drawing sparkline path based on stats
function updateDashboardCharts() {
  const cleared = stats.clearedTotal || 0;
  
  // Calculate relative curve values based on totals (mocking dynamic charts)
  const val1 = Math.min(60, 60 - (cleared * 0.05));
  const val2 = Math.min(60, 50 - (cleared * 0.1));
  const val3 = Math.min(60, 30 - (stats.clearedToday * 0.2));
  const val4 = Math.min(60, 15 - (stats.clearedToday * 0.5));
  
  const pathD = `M 0 60 Q 50 ${val1} 100 ${val2} T 200 ${val3} T 300 ${val4}`;
  const fillD = `${pathD} L 300 80 L 0 80 Z`;
  
  elements.sparklinePath.setAttribute("d", pathD);
  elements.sparklineFill.setAttribute("d", fillD);
}

// Toast notification helper
function showToast(message, type = "success") {
  const toast = document.createElement("div");
  toast.className = `toast ${type === "error" ? "toast-error" : ""}`;
  
  toast.innerHTML = `
    <span>${escapeHtml(message)}</span>
    <button class="toast-close">&times;</button>
  `;
  
  elements.toastContainer.appendChild(toast);
  
  // Auto remove
  const autoClose = setTimeout(() => {
    toast.style.opacity = "0";
    toast.style.transform = "translateY(10px)";
    setTimeout(() => toast.remove(), 300);
  }, 3000);

  // Manual close
  toast.querySelector(".toast-close").addEventListener("click", () => {
    clearTimeout(autoClose);
    toast.remove();
  });
}

// HTML escape helper
function escapeHtml(str) {
  if (str === null || str === undefined) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}
