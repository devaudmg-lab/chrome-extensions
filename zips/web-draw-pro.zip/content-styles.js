// Styles for the WebDrawPro overlay. They are injected into a CLOSED shadow root by
// content.js, so the page's CSS cannot restyle the toolbar and page scripts cannot
// reach the canvas, the text box or the screenshot. Loaded right before content.js.
globalThis.__webDrawProCSS = `
.wd {
  position: fixed;
  top: 0;
  left: 0;
  pointer-events: none;
  font: 13px/1.3 Arial, sans-serif;
  color: #2c3e50;
  color-scheme: light;
}
.wd *, .wd *::before, .wd *::after { box-sizing: border-box; }
.canvas {
  position: absolute;
  top: 0;
  left: 0;
  cursor: crosshair;
  pointer-events: auto;
  touch-action: none;
}
.wd.minimized .canvas { pointer-events: none; }
.wd.drawings-off .canvas, .wd.drawings-off .blur-layer { visibility: hidden; }
.blur-layer {
  position: absolute;
  inset: 0;
  overflow: hidden;
  pointer-events: none;
}
.blur {
  position: absolute;
  -webkit-backdrop-filter: blur(var(--r, 10px)) saturate(0.8);
  backdrop-filter: blur(var(--r, 10px)) saturate(0.8);
  background: rgba(128, 128, 128, 0.22);
  border-radius: 3px;
}

/* Toolbar */
.toolbar {
  position: fixed;
  top: 20px;
  right: 20px;
  width: 112px;
  max-height: calc(100vh - 40px);
  overflow-y: auto;
  background: #2c3e50;
  border-radius: 12px;
  padding: 10px;
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 6px;
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.4);
  pointer-events: auto;
  user-select: none;
  scrollbar-width: none;
}
.toolbar::-webkit-scrollbar { display: none; }
.wd.minimized .toolbar { display: none; }
.wide { grid-column: 1 / -1; }
.drag-handle {
  background: #34495e;
  height: 15px;
  cursor: move;
  border-radius: 4px;
  color: #fff;
  text-align: center;
  font-size: 10px;
  line-height: 15px;
  touch-action: none;
}
.tool-btn {
  background: #ecf0f1;
  border: none;
  border-radius: 8px;
  padding: 7px 0;
  margin: 0;
  cursor: pointer;
  font: 16px/1.2 Arial, sans-serif;
  color: #2c3e50;
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 32px;
}
.tool-btn:hover { background: #fff; }
.tool-btn:focus-visible, .color-picker:focus-visible, .width-picker:focus-visible, .drag-handle:focus-visible,
.side-tab button:focus-visible, .panel button:focus-visible {
  outline: 2px solid #f1c40f;
  outline-offset: 2px;
}
.tool-btn[aria-pressed="true"], .tool-btn.on {
  background: #3498db;
  color: #fff;
}
.tool-btn.wide { font-size: 13px; }
.tool-btn.hide-btn { background: #f39c12; color: #fff; }
.step-icon {
  display: inline-flex;
  width: 20px;
  height: 20px;
  border-radius: 50%;
  background: #e74c3c;
  color: #fff;
  font: bold 12px/20px Arial, sans-serif;
  justify-content: center;
}
.hl-icon {
  display: inline-block;
  width: 20px;
  height: 10px;
  border-radius: 2px;
  background: rgba(241, 196, 15, 0.85);
}
.color-picker {
  width: 100%;
  height: 35px;
  border-radius: 5px;
  cursor: pointer;
  border: none;
  padding: 0;
  background: none;
}
.width-picker {
  width: 100%;
  padding: 4px;
  border-radius: 5px;
  border: none;
  font: 12px Arial, sans-serif;
  background: #ecf0f1;
  color: #2c3e50;
  cursor: pointer;
}
hr {
  border: 0;
  border-top: 1px solid #555;
  margin: 5px 0;
}

/* Text box while typing */
.text-input {
  position: absolute;
  background: rgba(255, 255, 255, 0.6);
  border: 1px dashed #3498db;
  outline: none;
  font-family: Arial, sans-serif;
  min-width: 60px;
  padding: 0 2px;
  margin: 0;
  pointer-events: auto;
}

/* Minimized side tab */
.side-tab {
  position: fixed;
  right: 0;
  top: 50%;
  transform: translateY(-50%);
  display: none;
  flex-direction: column;
  background: #2c3e50;
  border-radius: 12px 0 0 12px;
  box-shadow: -4px 0 15px rgba(0, 0, 0, 0.3);
  border: 1px solid #34495e;
  border-right: none;
  pointer-events: auto;
  overflow: hidden;
}
.wd.minimized .side-tab { display: flex; }
.side-tab button {
  background: none;
  border: none;
  color: #5dade2;
  font: bold 13px Arial, sans-serif;
  cursor: pointer;
  padding: 12px 8px;
  margin: 0;
}
.side-tab button:hover { background: #34495e; color: #ecf0f1; }
.side-tab .open { writing-mode: vertical-rl; }
.side-tab .eye { border-top: 1px solid #34495e; font-size: 14px; padding: 8px; }

/* Help / welcome panel */
.panel {
  position: fixed;
  top: 20px;
  right: 148px;
  width: 270px;
  max-height: calc(100vh - 40px);
  overflow-y: auto;
  background: #2c3e50;
  color: #ecf0f1;
  border-left: 3px solid #3498db;
  border-radius: 10px;
  padding: 12px 14px;
  font: 12px/1.6 Arial, sans-serif;
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.4);
  pointer-events: auto;
}
.panel[hidden], .wd.minimized .panel { display: none; }
.panel b.title { display: block; font-size: 13px; margin-bottom: 4px; }
.panel kbd {
  background: #34495e;
  border-radius: 3px;
  padding: 0 4px;
  font: 11px monospace;
  color: #ecf0f1;
}
.panel table { border-collapse: collapse; width: 100%; margin: 4px 0; }
.panel td { padding: 1px 4px 1px 0; vertical-align: top; }
.panel .saved { margin-top: 8px; color: #bdc3c7; }
.panel .row { display: flex; gap: 6px; margin-top: 8px; flex-wrap: wrap; }
.panel button {
  background: #3498db;
  color: #fff;
  border: none;
  border-radius: 6px;
  padding: 4px 12px;
  font: bold 12px Arial, sans-serif;
  cursor: pointer;
}
.panel button.secondary { background: #34495e; }
.panel button:disabled { opacity: 0.5; cursor: default; }

/* Toast */
.toast {
  position: fixed;
  left: 50%;
  bottom: 24px;
  max-width: calc(100vw - 32px);
  transform: translate(-50%, 16px);
  background: #2c3e50;
  color: #ecf0f1;
  border-left: 3px solid #3498db;
  border-radius: 8px;
  padding: 9px 16px;
  font: 13px Arial, sans-serif;
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.35);
  opacity: 0;
  pointer-events: none;
  transition: opacity 0.2s, transform 0.2s;
}
.toast.show {
  opacity: 1;
  transform: translate(-50%, 0);
}
.capturing .toolbar, .capturing .panel, .capturing .toast, .capturing .side-tab, .capturing .text-input {
  visibility: hidden !important;
}
@media (prefers-reduced-motion: reduce) {
  .toast { transition: none; }
}
`;
