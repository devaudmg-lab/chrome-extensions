// Pages where extensions are not allowed to inject scripts
const RESTRICTED = /^(chrome|edge|about|chrome-extension|chrome-search|chrome-untrusted|devtools|view-source):|^https:\/\/(chrome\.google\.com\/webstore|chromewebstore\.google\.com)/;

// Short visible hint on the icon when the page cannot be drawn on (instead of silently
// doing nothing).
async function flagUnsupported(tabId) {
  try {
    await chrome.action.setBadgeBackgroundColor({ tabId, color: "#c0392b" });
    await chrome.action.setBadgeText({ tabId, text: "✕" });
    await chrome.action.setTitle({ tabId, title: "WebDrawPro can't draw on this page (browser pages, the Web Store and some built-in viewers are protected)" });
    setTimeout(() => {
      chrome.action.setBadgeText({ tabId, text: "" }).catch(() => {});
      chrome.action.setTitle({ tabId, title: chrome.runtime.getManifest().action.default_title }).catch(() => {});
    }, 4000);
  } catch (err) {
    /* tab closed */
  }
}

// Toolbar icon / Alt+Shift+D: show, minimize or restore the overlay in this tab.
async function toggleOnTab(tab) {
  if (!tab || !tab.id) return;
  if (tab.url && RESTRICTED.test(tab.url)) return flagUnsupported(tab.id);
  const msg = { action: "toggle", incognito: !!tab.incognito };

  // Already injected and alive? Just toggle.
  try {
    await chrome.tabs.sendMessage(tab.id, msg, { frameId: 0 });
    return;
  } catch (err) {
    /* not injected yet, or an orphaned copy from before an extension update */
  }

  try {
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content-styles.js", "content.js"] });
    await chrome.tabs.sendMessage(tab.id, msg, { frameId: 0 });
  } catch (err) {
    flagUnsupported(tab.id);
  }
}
chrome.action.onClicked.addListener(toggleOnTab);

// Save / Copy: screenshot of the visible tab (drawings included). The activeTab grant
// from clicking the icon allows captureVisibleTab for this tab only. The image is sent
// back to the isolated content script, never to the page.
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.action !== "capture") return;
  const tab = sender.tab;
  // Only our own top-frame content script, and only while its tab is the one on screen
  // (otherwise captureVisibleTab would photograph whatever tab is visible instead).
  if (sender.id !== chrome.runtime.id || !tab || sender.frameId !== 0 || !tab.active) {
    sendResponse({ error: "not-visible" });
    return;
  }
  chrome.tabs
    .captureVisibleTab(tab.windowId, { format: "png" })
    .then((dataUrl) => sendResponse({ dataUrl }))
    .catch((err) => sendResponse({ error: String(err && err.message) }));
  return true; // async response
});
