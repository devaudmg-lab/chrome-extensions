// Pages where extensions are not allowed to inject scripts
const RESTRICTED = /^(chrome|edge|about|chrome-extension|devtools|view-source):|^https:\/\/(chrome\.google\.com\/webstore|chromewebstore\.google\.com)/;

chrome.action.onClicked.addListener(async (tab) => {
  if (!tab.id || (tab.url && RESTRICTED.test(tab.url))) return;

  // Already injected? Just toggle (avoids stacking a new copy of the CSS on every click)
  try {
    await chrome.tabs.sendMessage(tab.id, { action: "toggle" });
    return;
  } catch (err) {
    /* not injected yet */
  }

  try {
    await chrome.scripting.insertCSS({ target: { tabId: tab.id }, files: ["content.css"] });
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] });
    await chrome.tabs.sendMessage(tab.id, { action: "toggle" });
  } catch (err) {
    console.warn("WebDrawPro: cannot draw on this page:", err && err.message);
  }
});

// "Save" button: screenshot of the visible tab (drawings included). The activeTab grant
// from clicking the toolbar icon allows captureVisibleTab for this tab.
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action !== "capture" || !sender.tab) return;
  chrome.tabs
    .captureVisibleTab(sender.tab.windowId, { format: "png" })
    .then((dataUrl) => sendResponse({ dataUrl }))
    .catch((err) => sendResponse({ error: String(err && err.message) }));
  return true; // async response
});
