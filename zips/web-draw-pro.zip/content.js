// WebDrawPro content script. Injected on demand (activeTab) by background.js together
// with content-styles.js.
//
// Security: the whole overlay (toolbar, drawing canvas, text box, blur boxes) lives in a
// CLOSED shadow root. Page scripts cannot query it, read the canvas, read what you type,
// or click the Save / Copy buttons. The page screenshot only ever exists in this isolated
// content-script world: it is never put in the DOM.
(() => {
// background.js only injects this file when no live copy answered its "toggle" message,
// so any copy still registered here is orphaned (for example after an extension update).
// Remove it instead of keeping a dead toolbar on the page.
if (window.__webDrawPro) {
  try {
    window.__webDrawPro.destroy();
  } catch (err) {
    /* already gone */
  }
}

let abort = null; // aborted by destroy(): removes every page listener we added
const on = (target, type, fn, opts) =>
  target.addEventListener(type, fn, Object.assign({ signal: abort.signal }, opts || {}));

// All shapes are stored in PAGE coordinates (clientX + scrollX), so drawings stay
// attached to the content and scroll with the page.
let host, root, wrap, canvas, ctx, blurLayer, toolbarEl, panelEl;
let drawings = [];
let history = []; // snapshots of `drawings` for Undo
let future = []; // snapshots for Redo
let isDrawing = false;
let isActive = true; // false = minimized (page usable, drawings still shown)
let drawingsVisible = true;
let currentTool = "pen";
let currentColor = "#ff0000";
let strokeWidth = 3;
let fillShapes = false;
let selectedObj = null;
let resizeHandle = null;
let historyPendingForDrag = false;
let erasedThisStroke = false;
let startX, startY;
let lastX, lastY; // last pointer position in page coordinates (for the live preview)
let shiftHeld = false;
let activePointer = null;
let currentPath = [];
let blurEls = [];
let textBox = null; // { input, x, y } while typing
let incognito = false;
const HANDLE_SIZE = 8;
const MAX_HISTORY = 100;
const WIDTHS = [2, 3, 6, 10];
const COLOR_RE = /^#[0-9a-f]{6}$/i;

// Single-key tool shortcuts (only while the toolbar is open and you're not typing)
const TOOL_KEYS = {
  v: "select", p: "pen", h: "highlight", e: "eraser", r: "rect", o: "circle",
  a: "arrow", m: "ruler", t: "text", b: "blur", n: "step",
};
const TOOLS = ["select", "pen", "highlight", "rect", "circle", "arrow", "text", "step", "blur", "ruler", "eraser"];
const SHAPE_TYPES = new Set(["pen", "highlight", "rect", "circle", "arrow", "ruler", "text", "step", "blur"]);

const HOST_STYLE = [
  "all:initial", "position:fixed", "top:0", "left:0", "width:0", "height:0", "margin:0", "padding:0",
  "border:0", "display:block", "visibility:visible", "opacity:1", "filter:none", "transform:none",
  "clip-path:none", "mask:none", "contain:none", "overflow:visible", "pointer-events:none",
  "z-index:2147483647",
].map((d) => d + "!important").join(";");

const TEMPLATE = `
  <div class="wd">
    <div class="blur-layer"></div>
    <canvas class="canvas" aria-hidden="true"></canvas>
    <div class="side-tab">
      <button class="open" id="open" title="Open the drawing toolbar (Alt+Shift+D)" aria-label="Open the drawing toolbar">Draw ✏️</button>
      <button class="eye" id="eye" title="Hide drawings" aria-label="Hide drawings" aria-pressed="false">👁</button>
    </div>
    <div class="toolbar" role="toolbar" aria-label="WebDrawPro drawing tools" aria-orientation="vertical">
      <div class="drag-handle wide" id="drag-handle" title="Drag to move the toolbar">⠿</div>
      <button class="tool-btn" id="btn-select" title="Select / move (V). Double-click text to edit, Delete removes" aria-label="Select and move">👆</button>
      <button class="tool-btn" id="btn-pen" title="Pen (P)" aria-label="Pen">✏️</button>
      <button class="tool-btn" id="btn-highlight" title="Highlighter (H)" aria-label="Highlighter"><span class="hl-icon"></span></button>
      <button class="tool-btn" id="btn-rect" title="Rectangle (R). Hold Shift for a square" aria-label="Rectangle">🟦</button>
      <button class="tool-btn" id="btn-circle" title="Circle (O)" aria-label="Circle">⭕</button>
      <button class="tool-btn" id="btn-arrow" title="Arrow (A). Hold Shift for 45° steps" aria-label="Arrow">➚</button>
      <button class="tool-btn" id="btn-text" title="Text (T)" aria-label="Text"><b>T</b></button>
      <button class="tool-btn" id="btn-step" title="Numbered step (N)" aria-label="Numbered step"><span class="step-icon">1</span></button>
      <button class="tool-btn" id="btn-blur" title="Blur an area (B). With Fill on: solid black-out" aria-label="Blur or black out an area">▦</button>
      <button class="tool-btn" id="btn-ruler" title="Ruler (M). Snaps level; Shift for 45° steps" aria-label="Ruler">📏</button>
      <button class="tool-btn" id="btn-eraser" title="Eraser (E). Click or drag over shapes" aria-label="Eraser">🧽</button>
      <button class="tool-btn" id="btn-help" title="Shortcuts and saved drawings (?)" aria-label="Help, shortcuts and saved drawings" aria-expanded="false"><b>?</b></button>
      <input type="color" id="color-picker" class="color-picker wide" value="#ff0000" title="Colour (also recolours the selected shape)" aria-label="Colour">
      <select id="width-picker" class="width-picker wide" title="Stroke width (also applies to the selected shape)" aria-label="Stroke width">
        <option value="2">Thin</option>
        <option value="3" selected>Normal</option>
        <option value="6">Thick</option>
        <option value="10">Marker</option>
      </select>
      <button class="tool-btn wide" id="btn-fill" title="Fill rectangles and circles; solid black-out for the blur tool" aria-label="Fill shapes" aria-pressed="false">🎨 Fill</button>
      <hr class="wide">
      <button class="tool-btn" id="btn-undo" title="Undo (Ctrl+Z)" aria-label="Undo">↩️</button>
      <button class="tool-btn" id="btn-redo" title="Redo (Ctrl+Y)" aria-label="Redo">↪️</button>
      <button class="tool-btn" id="btn-copy" title="Copy screenshot to clipboard" aria-label="Copy screenshot to clipboard">📋</button>
      <button class="tool-btn" id="btn-save" title="Save screenshot with drawings (PNG)" aria-label="Save screenshot as PNG">💾</button>
      <button class="tool-btn" id="btn-clear" title="Clear all drawings on this page (and its saved copy)" aria-label="Clear all drawings on this page">🗑️</button>
      <button class="tool-btn hide-btn" id="btn-minimize" title="Minimize: use the page, keep drawings visible (Alt+Shift+D)" aria-label="Minimize toolbar">➡️</button>
    </div>
    <div class="panel" id="panel" role="dialog" aria-label="WebDrawPro help" hidden>
      <b class="title">WebDrawPro</b>
      Drawings stick to the page as you scroll<span id="persist-note"> and are kept for this page address, so they come back the next time you open WebDrawPro here</span>.
      <table>
        <tr><td><kbd>V</kbd> select</td><td><kbd>P</kbd> pen</td></tr>
        <tr><td><kbd>H</kbd> highlighter</td><td><kbd>R</kbd> box</td></tr>
        <tr><td><kbd>O</kbd> circle</td><td><kbd>A</kbd> arrow</td></tr>
        <tr><td><kbd>T</kbd> text</td><td><kbd>N</kbd> step</td></tr>
        <tr><td><kbd>B</kbd> blur</td><td><kbd>M</kbd> ruler</td></tr>
        <tr><td><kbd>E</kbd> eraser</td><td><kbd>Esc</kbd> deselect</td></tr>
      </table>
      <kbd>Ctrl</kbd>+<kbd>Z</kbd> / <kbd>Ctrl</kbd>+<kbd>Y</kbd> undo / redo, <kbd>Del</kbd> delete,
      <kbd>Shift</kbd> square / 45°. Keys are ignored while you type in the page.
      <div class="saved" id="saved-info"></div>
      <div class="row">
        <button id="panel-ok">Got it</button>
        <button class="secondary" id="forget-all" title="Delete the saved drawings of every page">Forget all pages</button>
      </div>
    </div>
    <div class="toast" id="toast" role="status" aria-live="polite"></div>
  </div>`;

const $ = (id) => root.getElementById(id);

// ---------- Settings ----------
function loadSettings() {
  try {
    chrome.storage.local.get({ color: "#ff0000", strokeWidth: 3, fill: false, onboarded: false }, (s) => {
      if (chrome.runtime.lastError || !root) return;
      currentColor = COLOR_RE.test(s.color) ? s.color : "#ff0000";
      strokeWidth = WIDTHS.includes(Number(s.strokeWidth)) ? Number(s.strokeWidth) : 3;
      fillShapes = !!s.fill;
      $("color-picker").value = currentColor;
      $("width-picker").value = String(strokeWidth);
      updateFillButton();
      if (!s.onboarded) showPanel(true);
    });
  } catch (err) {
    /* storage unavailable: keep defaults */
  }
}
function saveSettings() {
  try {
    chrome.storage.local.set({ color: currentColor, strokeWidth, fill: fillShapes });
  } catch (err) {
    /* extension reloaded: ignore */
  }
}

// ---------- Per-page persistence ----------
// Drawings are saved locally (chrome.storage.local) under the page address, never in
// incognito. Capped by number of pages and by size.
const PAGE_PREFIX = "page:";
const INDEX_KEY = "savedPages"; // { [storageKey]: lastSavedTime }
const MAX_PAGES = 200;
const MAX_PAGE_BYTES = 500 * 1024;
let pageKeyNow = null;
let saveTimer = null;
let savedTooBigWarned = false;

function keyFor(href) {
  try {
    const u = new URL(href);
    if (!/^(https?|file):$/.test(u.protocol)) return null;
    // Keep hash routes (#/inbox, #!/x) but not plain in-page anchors (#section)
    const hash = /^#[!/]/.test(u.hash) ? u.hash : "";
    return PAGE_PREFIX + u.origin + u.pathname + u.search + hash;
  } catch (err) {
    return null;
  }
}
const canPersist = () => !incognito && !!pageKeyNow;

function scheduleSave() {
  if (!canPersist()) return;
  clearTimeout(saveTimer);
  const key = pageKeyNow;
  saveTimer = setTimeout(() => {
    saveTimer = null;
    persist(key, drawings);
  }, 400);
}
function flushSave() {
  if (!saveTimer) return;
  clearTimeout(saveTimer);
  saveTimer = null;
  persist(pageKeyNow, drawings);
}

function persist(key, list) {
  if (incognito || !key) return;
  try {
    chrome.storage.local.get({ [INDEX_KEY]: {} }, (res) => {
      if (chrome.runtime.lastError) return;
      const index = res[INDEX_KEY] && typeof res[INDEX_KEY] === "object" ? res[INDEX_KEY] : {};
      if (!list.length) {
        delete index[key];
        chrome.storage.local.remove(key);
        chrome.storage.local.set({ [INDEX_KEY]: index });
        return;
      }
      // Round coordinates to 0.1 px to keep the stored JSON small
      const json = JSON.stringify(list, (k, v) => (typeof v === "number" ? Math.round(v * 10) / 10 : v));
      if (json.length > MAX_PAGE_BYTES) {
        if (!savedTooBigWarned) toast("Too many drawings to remember for this page. Save a PNG to keep them.");
        savedTooBigWarned = true;
        return;
      }
      index[key] = Date.now();
      const evict = Object.keys(index)
        .sort((a, b) => index[b] - index[a])
        .slice(MAX_PAGES);
      evict.forEach((k) => delete index[k]);
      if (evict.length) chrome.storage.local.remove(evict);
      chrome.storage.local.set({ [key]: json, [INDEX_KEY]: index });
    });
  } catch (err) {
    /* extension reloaded: nothing we can do */
  }
}

function num(v) {
  return typeof v === "number" && Number.isFinite(v);
}
// Stored data is treated as untrusted input: keep only known fields of known shapes
function sanitize(list) {
  if (!Array.isArray(list)) return [];
  return list
    .filter((o) => o && SHAPE_TYPES.has(o.type) && num(o.x) && num(o.y))
    .map((o) => {
      const s = {
        type: o.type,
        x: o.x,
        y: o.y,
        w: num(o.w) ? o.w : 0,
        h: num(o.h) ? o.h : 0,
        color: COLOR_RE.test(o.color) ? o.color : "#ff0000",
        width: num(o.width) ? Math.min(Math.max(o.width, 1), 60) : 3,
        fill: !!o.fill,
        points: Array.isArray(o.points)
          ? o.points.filter((p) => p && num(p.x) && num(p.y)).map((p) => ({ x: p.x, y: p.y }))
          : [],
        text: typeof o.text === "string" ? o.text.slice(0, 2000) : "",
      };
      if (o.solid) s.solid = true;
      if (num(o.size)) s.size = Math.min(Math.max(o.size, 6), 200);
      if (num(o.n)) s.n = Math.round(o.n);
      return s;
    })
    .filter((o) => (o.type !== "pen" && o.type !== "highlight") || o.points.length);
}

function loadPage(announce) {
  drawings = [];
  history = [];
  future = [];
  selectedObj = null;
  savedTooBigWarned = false;
  pageKeyNow = keyFor(location.href);
  redraw();
  if (!canPersist()) return;
  const key = pageKeyNow;
  try {
    chrome.storage.local.get(key, (res) => {
      if (chrome.runtime.lastError || key !== pageKeyNow || !res[key]) return;
      let list = [];
      try {
        list = sanitize(JSON.parse(res[key]));
      } catch (err) {
        list = [];
      }
      if (!list.length) return;
      // Anything drawn in the meantime is kept on top
      drawings = list.concat(drawings);
      redraw();
      if (announce) toast(`Restored ${list.length} drawing${list.length === 1 ? "" : "s"} saved for this page`);
    });
  } catch (err) {
    /* ignore */
  }
}

// SPAs change the address without reloading: switch to that page's drawings
let lastHref = location.href;
function checkUrlChange() {
  if (location.href === lastHref) return;
  lastHref = location.href;
  if (keyFor(location.href) === pageKeyNow) return;
  commitText();
  flushSave();
  loadPage(true);
}

function updateSavedInfo() {
  const info = $("saved-info");
  const forget = $("forget-all");
  $("persist-note").hidden = incognito;
  if (incognito) {
    info.textContent = "Incognito: drawings are not saved.";
    forget.hidden = true;
    return;
  }
  try {
    chrome.storage.local.get({ [INDEX_KEY]: {} }, (res) => {
      if (chrome.runtime.lastError) return;
      const n = Object.keys(res[INDEX_KEY] || {}).length;
      info.textContent = n
        ? `Saved drawings: ${n} page${n === 1 ? "" : "s"} (stored only on this computer).`
        : "No saved drawings yet.";
      forget.disabled = !n;
    });
  } catch (err) {
    /* ignore */
  }
}
function forgetAllPages() {
  try {
    chrome.storage.local.get(null, (all) => {
      if (chrome.runtime.lastError) return;
      const keys = Object.keys(all).filter((k) => k.startsWith(PAGE_PREFIX)).concat(INDEX_KEY);
      chrome.storage.local.remove(keys, () => {
        // Keep what is on screen now: it is saved again only if you keep drawing
        toast("Saved drawings forgotten for all pages");
        updateSavedInfo();
      });
    });
  } catch (err) {
    /* ignore */
  }
}

// ---------- History ----------
function pushHistory() {
  history.push(JSON.stringify(drawings));
  if (history.length > MAX_HISTORY) history.shift();
  future = []; // a new change makes the redo steps invalid
  scheduleSave();
}
function undo() {
  if (!history.length) return toast("Nothing to undo");
  future.push(JSON.stringify(drawings));
  drawings = JSON.parse(history.pop());
  selectedObj = null;
  redraw();
  scheduleSave();
}
function redo() {
  if (!future.length) return toast("Nothing to redo");
  history.push(JSON.stringify(drawings));
  drawings = JSON.parse(future.pop());
  selectedObj = null;
  redraw();
  scheduleSave();
}

// Page <-> screen helpers
const pageX = (clientX) => clientX + window.scrollX;
const pageY = (clientY) => clientY + window.scrollY;

// Visible viewport size WITHOUT scrollbars, so the canvas never covers (and blocks) them
function viewport() {
  const el = document.compatMode === "CSS1Compat" || !document.body ? document.documentElement : document.body;
  const w = Math.min(el.clientWidth || window.innerWidth, window.innerWidth);
  const h = Math.min(el.clientHeight || window.innerHeight, window.innerHeight);
  return { w: w || window.innerWidth, h: h || window.innerHeight };
}

let toastTimer = null;
function toast(text) {
  const el = root && $("toast");
  if (!el) return;
  el.textContent = text;
  el.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove("show"), 2600);
}

function showPanel(show) {
  panelEl.hidden = !show;
  $("btn-help").setAttribute("aria-expanded", String(show));
  $("btn-help").classList.toggle("on", show);
  if (show) updateSavedInfo();
}

// ---------- Setup / teardown ----------
function init(opts) {
  incognito = !!(opts && opts.incognito) || !!(chrome.extension && chrome.extension.inIncognitoContext);
  abort = new AbortController();
  isActive = true;
  drawingsVisible = true;
  blurEls = [];
  lastHref = location.href;

  host = document.createElement("web-draw-pro");
  host.setAttribute("style", HOST_STYLE);
  try {
    root = host.attachShadow({ mode: "closed" });
  } catch (err) {
    // The page defined its own <web-draw-pro> element: fall back to a plain element
    host = document.createElement("span");
    host.setAttribute("style", HOST_STYLE);
    root = host.attachShadow({ mode: "closed" });
  }
  // Static markup only; no page or user data goes through innerHTML
  root.innerHTML = `<style>${globalThis.__webDrawProCSS || ""}</style>${TEMPLATE}`;
  document.documentElement.appendChild(host);

  wrap = root.querySelector(".wd");
  canvas = root.querySelector(".canvas");
  ctx = canvas.getContext("2d");
  blurLayer = root.querySelector(".blur-layer");
  toolbarEl = root.querySelector(".toolbar");
  panelEl = $("panel");

  selectTool("pen");
  resizeCanvas();
  setupListeners();
  setupToolbarDrag();
  loadSettings();
  loadPage(true);
  watchDpr();
}

// Remove the overlay and every listener it added to the page
function destroy() {
  if (!host) return;
  commitText(true);
  flushSave();
  if (abort) abort.abort();
  clearInterval(urlTimer);
  host.remove();
  host = root = wrap = canvas = ctx = blurLayer = toolbarEl = panelEl = null;
  blurEls = [];
  isDrawing = false;
  activePointer = null;
}

function setActive(active) {
  isActive = active;
  wrap.classList.toggle("minimized", !active);
  if (!active) {
    commitText();
    isDrawing = false;
    activePointer = null;
    selectedObj = null;
  } else if (!drawingsVisible) {
    setDrawingsVisible(true);
  }
  redraw();
}
const toggleUI = () => setActive(!isActive);

function setDrawingsVisible(v) {
  drawingsVisible = v;
  wrap.classList.toggle("drawings-off", !v);
  const eye = $("eye");
  eye.setAttribute("aria-pressed", String(!v));
  eye.title = v ? "Hide drawings" : "Show drawings";
  eye.setAttribute("aria-label", eye.title);
  eye.textContent = v ? "👁" : "🚫";
}

function updateFillButton() {
  const fillBtn = $("btn-fill");
  fillBtn.setAttribute("aria-pressed", String(fillShapes));
}

function selectTool(t) {
  const btn = $(`btn-${t}`);
  if (!btn) return;
  commitText();
  currentTool = t;
  TOOLS.forEach((name) => $(`btn-${name}`).setAttribute("aria-pressed", String(name === t)));
  canvas.style.cursor = t === "select" ? "default" : t === "text" ? "text" : "crosshair";
  selectedObj = null;
  redraw();
}

// ---------- Screenshot (Save / Copy) ----------
// Screenshot of the visible page with the drawings on top (toolbar, panels and selection
// handles hidden). Returns { dataUrl, withPage }. withPage is false when the browser
// refused the capture and only the drawing layer could be exported.
async function captureScreenshot() {
  commitText();
  const sel = selectedObj;
  selectedObj = null;
  wrap.classList.add("capturing");
  redraw();
  await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
  let dataUrl = null;
  try {
    const res = await chrome.runtime.sendMessage({ action: "capture" });
    if (res && res.dataUrl) dataUrl = res.dataUrl;
  } catch (err) {
    /* fall back below */
  }
  wrap.classList.remove("capturing");
  selectedObj = sel;
  redraw();
  return dataUrl ? { dataUrl, withPage: true } : { dataUrl: canvas.toDataURL("image/png"), withPage: false };
}

const NO_PAGE_MSG = "Chrome blocked the page capture, so only your drawings were exported. Click the WebDrawPro icon again and retry.";

async function saveImage() {
  const shot = await captureScreenshot();
  // Detached link in this isolated world: the image never touches the page DOM
  const link = document.createElement("a");
  const d = new Date();
  const pad = (n) => String(n).padStart(2, "0");
  const stamp = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}_${pad(d.getHours())}-${pad(d.getMinutes())}-${pad(d.getSeconds())}`;
  link.download = `web-drawing-${stamp}.png`;
  link.href = shot.dataUrl;
  link.click();
  toast(shot.withPage ? "Screenshot saved" : NO_PAGE_MSG);
}

async function copyImage() {
  let withPage = true;
  try {
    // Hand the clipboard a promise so the click's user activation is still valid
    const blob = captureScreenshot().then((shot) => {
      withPage = shot.withPage;
      return fetch(shot.dataUrl).then((r) => r.blob());
    });
    await navigator.clipboard.write([new ClipboardItem({ "image/png": blob })]);
    toast(withPage ? "Screenshot copied to the clipboard" : NO_PAGE_MSG);
  } catch (err) {
    toast("This page blocks copying. Use Save 💾 instead.");
  }
}

// ---------- Keyboard: never steal keys while the user types ----------
function isEditable(el) {
  if (!el || el.nodeType !== 1) return false;
  if (el.isContentEditable) return true;
  if (/^(INPUT|TEXTAREA|SELECT)$/.test(el.tagName)) return true;
  const role = el.getAttribute("role");
  return role === "textbox" || role === "combobox" || role === "searchbox" || role === "spinbutton";
}
function isTyping(e) {
  if (e.isComposing || e.keyCode === 229) return true; // IME composition
  if (document.designMode === "on") return true;
  if (textBox) return true;
  // composedPath() sees inside open shadow roots (web components such as search boxes)
  const path = e.composedPath ? e.composedPath() : [e.target];
  for (const n of path) {
    if (n === document || n === window) break;
    if (n !== host && isEditable(n)) return true;
  }
  // Focus inside nested shadow roots
  let a = document.activeElement;
  while (a && a.shadowRoot && a.shadowRoot.activeElement) a = a.shadowRoot.activeElement;
  return a !== host && isEditable(a);
}

// ---------- Shape geometry ----------
// Ruler snaps to level/plumb within 10°, Shift snaps lines to 45° steps and boxes to squares
function constrain(tool, sx, sy, ex, ey, shift) {
  let dx = ex - sx,
    dy = ey - sy;
  if ((tool === "rect" || tool === "blur") && shift) {
    const s = Math.max(Math.abs(dx), Math.abs(dy));
    dx = (dx < 0 ? -1 : 1) * s;
    dy = (dy < 0 ? -1 : 1) * s;
  } else if (tool === "arrow" || tool === "ruler") {
    const step = shift ? 45 : tool === "ruler" ? 90 : 0;
    if (step) {
      const ang = Math.atan2(dy, dx) * (180 / Math.PI);
      const snapped = Math.round(ang / step) * step;
      if (shift || Math.abs(ang - snapped) < 10) {
        const len = Math.hypot(dx, dy);
        dx = Math.round(len * Math.cos((snapped * Math.PI) / 180) * 100) / 100;
        dy = Math.round(len * Math.sin((snapped * Math.PI) / 180) * 100) / 100;
      }
    }
  }
  return { dx, dy };
}

function calculateAngle(x1, y1, x2, y2) {
  let angle = Math.atan2(y2 - y1, x2 - x1) * (180 / Math.PI);
  return angle < 0 ? angle + 360 : angle;
}

// ---------- Listeners ----------
function setupListeners() {
  TOOLS.forEach((t) => ($(`btn-${t}`).onclick = () => selectTool(t)));
  $("open").onclick = () => setActive(true);
  $("eye").onclick = () => setDrawingsVisible(!drawingsVisible);
  $("btn-minimize").onclick = () => setActive(false);
  $("btn-help").onclick = () => showPanel(panelEl.hidden);
  $("panel-ok").onclick = () => {
    showPanel(false);
    try {
      chrome.storage.local.set({ onboarded: true });
    } catch (err) {
      /* ignore */
    }
  };
  $("forget-all").onclick = forgetAllPages;

  $("btn-fill").onclick = () => {
    fillShapes = !fillShapes;
    updateFillButton();
    saveSettings();
    if (selectedObj && (selectedObj.type === "rect" || selectedObj.type === "circle")) {
      pushHistory();
      selectedObj.fill = fillShapes;
      redraw();
    }
  };

  $("btn-save").onclick = saveImage;
  $("btn-copy").onclick = copyImage;

  // Colour: live preview while the picker is open, ONE undo step and ONE storage write
  // per pick (the old version wrote storage and history on every input event)
  const picker = $("color-picker");
  let recolourSnapshotTaken = false;
  picker.oninput = (e) => {
    currentColor = e.target.value;
    if (selectedObj && selectedObj.type !== "blur") {
      if (!recolourSnapshotTaken) {
        pushHistory();
        recolourSnapshotTaken = true;
      }
      selectedObj.color = currentColor;
      redraw();
      scheduleSave();
    }
  };
  picker.onchange = (e) => {
    currentColor = e.target.value;
    recolourSnapshotTaken = false;
    saveSettings();
  };
  $("width-picker").onchange = (e) => {
    strokeWidth = Number(e.target.value) || 3;
    saveSettings();
    if (selectedObj && /^(pen|rect|circle|arrow|ruler|highlight)$/.test(selectedObj.type)) {
      pushHistory();
      selectedObj.width = selectedObj.type === "highlight" ? highlightWidth() : strokeWidth;
      redraw();
    }
  };
  $("btn-clear").onclick = () => {
    if (!drawings.length) return toast("Nothing to clear yet");
    pushHistory(); // Clear can be undone (and undo saves the drawings again)
    drawings = [];
    selectedObj = null;
    redraw();
    toast(canPersist() ? "Cleared, also from saved drawings. Press Ctrl+Z to undo." : "Cleared. Press Ctrl+Z to undo.");
  };
  $("btn-undo").onclick = undo;
  $("btn-redo").onclick = redo;

  // Pointer events: mouse, pen/stylus and touch. Pointer capture keeps the stroke going
  // even when the pointer leaves the canvas (e.g. over the toolbar).
  on(canvas, "pointerdown", onPointerDown);
  on(canvas, "pointermove", onPointerMove);
  on(canvas, "pointerup", onPointerUp);
  on(canvas, "pointercancel", onPointerUp);
  on(canvas, "lostpointercapture", (e) => {
    if (e.pointerId === activePointer) onPointerUp(e);
  });
  on(canvas, "dblclick", onDoubleClick);
  // No focus change on canvas clicks: keeps the new text box focused and the page's
  // selection untouched
  on(canvas, "mousedown", (e) => e.preventDefault());

  // Keyboard shortcuts (only while the toolbar is open and you're not typing)
  on(
    window,
    "keydown",
    (e) => {
      if (e.key === "Shift") updateShift(true);
      if (!isActive || !canvas || isTyping(e)) return;
      const key = (e.key || "").toLowerCase();
      const mod = e.ctrlKey || e.metaKey;
      let handled = true;
      if (mod && !e.shiftKey && !e.altKey && key === "z") undo();
      else if (mod && !e.altKey && (key === "y" || (e.shiftKey && key === "z"))) redo();
      else if ((e.key === "Delete" || e.key === "Backspace") && selectedObj && !mod) {
        pushHistory();
        drawings = drawings.filter((o) => o !== selectedObj);
        selectedObj = null;
        redraw();
      } else if (e.key === "Escape" && (selectedObj || !panelEl.hidden)) {
        selectedObj = null;
        showPanel(false);
        redraw();
      } else if (!mod && !e.altKey && !e.shiftKey && TOOL_KEYS[key]) selectTool(TOOL_KEYS[key]);
      else if (!mod && !e.altKey && e.key === "?") showPanel(panelEl.hidden);
      else handled = false;
      if (handled) {
        e.preventDefault();
        e.stopPropagation();
      }
    },
    { capture: true },
  );
  on(window, "keyup", (e) => {
    if (e.key === "Shift") updateShift(false);
  }, { capture: true });
  on(window, "blur", () => updateShift(false));

  // Drawings live in page coordinates: repaint when the page scrolls
  let scrollFrame = null;
  on(
    window,
    "scroll",
    () => {
      if (scrollFrame) return;
      scrollFrame = requestAnimationFrame(() => {
        scrollFrame = null;
        if (canvas) redraw();
      });
    },
    { passive: true },
  );
  on(window, "resize", () => {
    if (canvas) resizeCanvas();
  });

  // Save before the page goes away; follow SPA address changes
  on(window, "pagehide", flushSave);
  on(document, "visibilitychange", () => {
    if (document.visibilityState === "hidden") flushSave();
  });
  on(window, "popstate", checkUrlChange);
  on(window, "hashchange", checkUrlChange);
  urlTimer = setInterval(checkUrlChange, 1000);
}
let urlTimer = null;

function updateShift(v) {
  if (shiftHeld === v) return;
  shiftHeld = v;
  if (isDrawing) redraw();
}

const highlightWidth = () => Math.max(14, strokeWidth * 4);

function onPointerDown(e) {
  if (!isActive || activePointer !== null) return;
  if (e.pointerType === "mouse" && e.button !== 0) return;
  const x = pageX(e.clientX),
    y = pageY(e.clientY);
  lastX = x;
  lastY = y;
  shiftHeld = e.shiftKey;
  // Drawing takes the focus off the last toolbar button, so Space/Enter can't re-press it
  if (root.activeElement && root.activeElement !== (textBox && textBox.input)) root.activeElement.blur();

  if (currentTool === "text") {
    addTextInput(x, y); // also finishes a text box that is still open
    return;
  }
  commitText();

  if (currentTool === "step") {
    pushHistory();
    const n = drawings.reduce((max, o) => (o.type === "step" ? Math.max(max, o.n || 0) : max), 0) + 1;
    drawings.push({ type: "step", x, y, n, color: currentColor, size: 12 + strokeWidth * 1.5 });
    redraw();
    return;
  }

  activePointer = e.pointerId;
  try {
    canvas.setPointerCapture(e.pointerId);
  } catch (err) {
    /* ignore */
  }
  isDrawing = true;

  if (currentTool === "eraser") {
    erasedThisStroke = false;
    eraseAt(x, y);
    return;
  }

  if (currentTool === "select") {
    historyPendingForDrag = false;
    resizeHandle = null;
    if (selectedObj) {
      resizeHandle = getResizeHandle(x, y, selectedObj);
      if (resizeHandle) {
        historyPendingForDrag = true;
        return;
      }
    }
    selectedObj = [...drawings].reverse().find((obj) => isPointInShape(x, y, obj)) || null;
    if (selectedObj) {
      historyPendingForDrag = true;
      startX = x;
      startY = y;
    }
    redraw();
    return;
  }

  startX = x;
  startY = y;
  if (currentTool === "pen" || currentTool === "highlight") currentPath = [{ x, y }];
  redraw();
}

function eraseAt(x, y) {
  const remaining = drawings.filter((obj) => !isPointInShape(x, y, obj));
  if (remaining.length === drawings.length) return;
  if (!erasedThisStroke) {
    pushHistory(); // one undo step per eraser stroke
    erasedThisStroke = true;
  }
  drawings = remaining;
  if (selectedObj && !drawings.includes(selectedObj)) selectedObj = null;
  redraw();
  scheduleSave();
}

function onPointerMove(e) {
  if (!isDrawing || e.pointerId !== activePointer) return;
  const x = pageX(e.clientX),
    y = pageY(e.clientY);
  lastX = x;
  lastY = y;
  shiftHeld = e.shiftKey;

  if (currentTool === "eraser") return eraseAt(x, y);

  if (currentTool === "select") {
    if (!selectedObj) return;
    // Snapshot once, on the first actual movement, so a plain click doesn't fill Undo
    if (historyPendingForDrag) {
      pushHistory();
      historyPendingForDrag = false;
    }
    if (resizeHandle) resizeShape(selectedObj, resizeHandle, x, y);
    else {
      moveShape(selectedObj, x - startX, y - startY);
      startX = x;
      startY = y;
    }
    redraw();
    return;
  }

  if (currentTool === "pen" || currentTool === "highlight") {
    // Coalesced events give smooth lines with pens and fast mice
    const events = e.getCoalescedEvents ? e.getCoalescedEvents() : [];
    (events.length ? events : [e]).forEach((ev) => currentPath.push({ x: pageX(ev.clientX), y: pageY(ev.clientY) }));
  }
  redraw();
}

function onPointerUp(e) {
  if (e.pointerId !== activePointer) return;
  activePointer = null;
  if (!isDrawing) return;
  isDrawing = false;
  const tool = currentTool;
  if (tool !== "select" && tool !== "eraser") {
    const endX = e.type === "pointercancel" || e.type === "lostpointercapture" ? lastX : pageX(e.clientX);
    const endY = e.type === "pointercancel" || e.type === "lostpointercapture" ? lastY : pageY(e.clientY);
    let { dx, dy } = constrain(tool, startX, startY, endX, endY, shiftHeld);
    if (tool === "circle") {
      dx = Math.hypot(dx, dy);
      dy = 0;
    }
    const freehand = tool === "pen" || tool === "highlight";
    // A plain click with a shape tool would create an invisible zero-size shape
    const isDot = !freehand && Math.abs(dx) < 2 && Math.abs(dy) < 2;
    const tooSmallBlur = tool === "blur" && (Math.abs(dx) < 4 || Math.abs(dy) < 4);
    if (!isDot && !tooSmallBlur) {
      pushHistory();
      const shape = {
        type: tool,
        color: currentColor,
        width: tool === "highlight" ? highlightWidth() : strokeWidth,
        fill: fillShapes,
        x: startX,
        y: startY,
        w: freehand ? 0 : dx,
        h: freehand ? 0 : dy,
        points: freehand ? currentPath.slice() : [],
        text: "",
      };
      if (tool === "blur" && fillShapes) shape.solid = true;
      drawings.push(shape);
    }
    currentPath = [];
  }
  resizeHandle = null;
  historyPendingForDrag = false;
  redraw();
  scheduleSave();
}

function onDoubleClick(e) {
  if (!isActive || currentTool !== "select") return;
  const x = pageX(e.clientX),
    y = pageY(e.clientY);
  const obj = [...drawings].reverse().find((o) => o.type === "text" && isPointInShape(x, y, o));
  if (!obj) return;
  e.preventDefault();
  addTextInput(obj.x, obj.y, obj);
}

function moveShape(obj, dx, dy) {
  obj.x += dx;
  obj.y += dy;
  if (obj.points && obj.points.length) obj.points = obj.points.map((p) => ({ x: p.x + dx, y: p.y + dy }));
}

function resizeShape(obj, handle, x, y) {
  if (obj.type === "circle") {
    obj.w = Math.max(3, Math.max(Math.abs(x - obj.x), Math.abs(y - obj.y)));
    return;
  }
  if (obj.type === "arrow" || obj.type === "ruler") {
    // Lines have two handles: the start point and the end point
    const ex = obj.x + obj.w,
      ey = obj.y + obj.h;
    if (handle === "start") {
      obj.x = x;
      obj.y = y;
      obj.w = ex - x;
      obj.h = ey - y;
    } else {
      obj.w = x - obj.x;
      obj.h = y - obj.y;
    }
    return;
  }
  if (handle === "br") {
    obj.w = x - obj.x;
    obj.h = y - obj.y;
  } else if (handle === "bl") {
    obj.w += obj.x - x;
    obj.x = x;
    obj.h = y - obj.y;
  } else if (handle === "tr") {
    obj.h += obj.y - y;
    obj.y = y;
    obj.w = x - obj.x;
  } else if (handle === "tl") {
    obj.w += obj.x - x;
    obj.h += obj.y - y;
    obj.x = x;
    obj.y = y;
  }
}

// ---------- Rendering ----------
// Readable measurement badge centred on the ruler line (dark pill, white text)
function drawRulerLabel(text, cx, cy) {
  ctx.save();
  ctx.setLineDash([]);
  ctx.globalAlpha = 1;
  ctx.font = "bold 12px Arial";
  const w = ctx.measureText(text).width + 14;
  const h = 20;
  ctx.fillStyle = "rgba(44, 62, 80, 0.92)";
  ctx.beginPath();
  if (ctx.roundRect) ctx.roundRect(cx - w / 2, cy - h / 2, w, h, 10);
  else ctx.rect(cx - w / 2, cy - h / 2, w, h);
  ctx.fill();
  ctx.fillStyle = "#fff";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(text, cx, cy + 1);
  ctx.restore();
}

function drawArrowHead(x1, y1, x2, y2, width) {
  const head = Math.max(10, width * 4);
  const a = Math.atan2(y2 - y1, x2 - x1);
  ctx.beginPath();
  ctx.moveTo(x2, y2);
  ctx.lineTo(x2 - head * Math.cos(a - Math.PI / 7), y2 - head * Math.sin(a - Math.PI / 7));
  ctx.lineTo(x2 - head * Math.cos(a + Math.PI / 7), y2 - head * Math.sin(a + Math.PI / 7));
  ctx.closePath();
  ctx.fill();
}

// Blur strength grows with the box, so large text is not left readable
const blurRadius = (o) => Math.round(Math.min(28, Math.max(10, Math.min(Math.abs(o.w), Math.abs(o.h)) * 0.4)));

// Blur areas are real DOM boxes with backdrop-filter (a canvas cannot read the page pixels).
// They sit under the drawing canvas inside the closed shadow root and are included in
// Save / Copy screenshots. Solid black-outs are painted on the canvas instead.
function syncBlurLayer() {
  if (!blurLayer) return;
  const blurs = drawings.filter((o) => o.type === "blur" && !o.solid);
  while (blurEls.length < blurs.length) {
    const el = document.createElement("div");
    el.className = "blur";
    blurLayer.appendChild(el);
    blurEls.push(el);
  }
  while (blurEls.length > blurs.length) blurEls.pop().remove();
  blurs.forEach((o, i) => {
    const s = blurEls[i].style;
    s.left = Math.min(o.x, o.x + o.w) - window.scrollX + "px";
    s.top = Math.min(o.y, o.y + o.h) - window.scrollY + "px";
    s.width = Math.abs(o.w) + "px";
    s.height = Math.abs(o.h) + "px";
    s.setProperty("--r", blurRadius(o) + "px");
  });
}

function redraw() {
  if (!ctx) return;
  const dpr = window.devicePixelRatio || 1;
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  // Page coordinates -> screen: shift by the scroll position
  ctx.setTransform(dpr, 0, 0, dpr, -window.scrollX * dpr, -window.scrollY * dpr);
  syncBlurLayer();
  drawings.forEach((obj) => drawShape(obj, obj === selectedObj));
  if (textBox) positionTextBox();

  if (isDrawing && currentTool !== "select" && currentTool !== "eraser" && lastX !== undefined) {
    drawPreview(lastX, lastY);
  }
}

function drawPreview(curX, curY) {
  const tool = currentTool;
  const { dx, dy } = constrain(tool, startX, startY, curX, curY, shiftHeld);
  ctx.save();
  ctx.strokeStyle = currentColor;
  ctx.fillStyle = currentColor;
  ctx.lineWidth = strokeWidth;
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  ctx.setLineDash([5, 5]);
  if (tool === "rect") ctx.strokeRect(startX, startY, dx, dy);
  else if (tool === "blur") {
    ctx.lineWidth = 1.5;
    ctx.strokeStyle = "#3498db";
    ctx.fillStyle = fillShapes ? "rgba(17, 17, 17, 0.6)" : "rgba(52, 152, 219, 0.12)";
    ctx.fillRect(startX, startY, dx, dy);
    ctx.strokeRect(startX, startY, dx, dy);
  } else if (tool === "circle") {
    ctx.beginPath();
    ctx.arc(startX, startY, Math.hypot(dx, dy), 0, Math.PI * 2);
    ctx.stroke();
  } else if (tool === "arrow") {
    ctx.beginPath();
    ctx.moveTo(startX, startY);
    ctx.lineTo(startX + dx, startY + dy);
    ctx.stroke();
    ctx.setLineDash([]);
    drawArrowHead(startX, startY, startX + dx, startY + dy, strokeWidth);
  } else if (tool === "ruler") {
    ctx.beginPath();
    ctx.moveTo(startX, startY);
    ctx.lineTo(startX + dx, startY + dy);
    ctx.stroke();
    const angle = calculateAngle(startX, startY, startX + dx, startY + dy);
    drawRulerLabel(`${Math.round(Math.hypot(dx, dy))}px / ${Math.round(angle) % 360}°`, startX + dx / 2, startY + dy / 2);
  } else if (tool === "pen" || tool === "highlight") {
    ctx.setLineDash([]);
    drawFreehand({ type: tool, points: currentPath, color: currentColor, width: tool === "highlight" ? highlightWidth() : strokeWidth });
  }
  ctx.restore();
}

function drawFreehand(obj) {
  ctx.save();
  ctx.strokeStyle = obj.color;
  ctx.lineWidth = obj.width || 3;
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  if (obj.type === "highlight") ctx.globalAlpha = 0.35;
  ctx.beginPath();
  obj.points.forEach((p, i) => (i === 0 ? ctx.moveTo(p.x, p.y) : ctx.lineTo(p.x, p.y)));
  if (obj.points.length === 1) ctx.lineTo(obj.points[0].x + 0.1, obj.points[0].y);
  ctx.stroke();
  ctx.restore();
}

function drawShape(obj, isSelected) {
  if (obj.hidden) return; // text being edited
  const width = obj.width || 3;
  ctx.strokeStyle = obj.color;
  ctx.fillStyle = obj.color;
  ctx.lineWidth = width;
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  ctx.beginPath();

  if (obj.type === "pen" || obj.type === "highlight") {
    drawFreehand(obj);
  } else if (obj.type === "rect") {
    if (obj.fill) ctx.fillRect(obj.x, obj.y, obj.w, obj.h);
    ctx.strokeRect(obj.x, obj.y, obj.w, obj.h);
  } else if (obj.type === "circle") {
    ctx.arc(obj.x, obj.y, Math.abs(obj.w), 0, Math.PI * 2);
    if (obj.fill) ctx.fill();
    ctx.stroke();
  } else if (obj.type === "arrow") {
    ctx.moveTo(obj.x, obj.y);
    ctx.lineTo(obj.x + obj.w, obj.y + obj.h);
    ctx.stroke();
    drawArrowHead(obj.x, obj.y, obj.x + obj.w, obj.y + obj.h, width);
  } else if (obj.type === "ruler") {
    ctx.moveTo(obj.x, obj.y);
    ctx.lineTo(obj.x + obj.w, obj.y + obj.h);
    ctx.stroke();
    const d = Math.round(Math.hypot(obj.w, obj.h));
    const angle = calculateAngle(obj.x, obj.y, obj.x + obj.w, obj.y + obj.h);
    drawRulerLabel(`${d}px / ${Math.round(angle) % 360}°`, obj.x + obj.w / 2, obj.y + obj.h / 2);
  } else if (obj.type === "text") {
    ctx.font = `${obj.size || 20}px Arial`;
    ctx.fillText(obj.text, obj.x, obj.y);
  } else if (obj.type === "step") {
    // Numbered callout: filled circle with a white number and a soft white ring
    const r = obj.size || 16;
    ctx.arc(obj.x, obj.y, r, 0, Math.PI * 2);
    ctx.fill();
    ctx.lineWidth = 2;
    ctx.strokeStyle = "rgba(255, 255, 255, 0.9)";
    ctx.stroke();
    ctx.fillStyle = "#fff";
    ctx.font = `bold ${Math.round(r * 1.1)}px Arial`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(String(obj.n), obj.x, obj.y + 1);
    ctx.textAlign = "start";
    ctx.textBaseline = "alphabetic";
  } else if (obj.type === "blur" && obj.solid) {
    // Solid black-out: fully opaque, nothing of the page shows through
    ctx.fillStyle = "#111";
    ctx.fillRect(obj.x, obj.y, obj.w, obj.h);
  }
  // Soft "blur" boxes are drawn by syncBlurLayer(); only their handles are painted here

  if (isSelected) drawSelection(obj);
}

function handlesFor(obj) {
  if (obj.type === "arrow" || obj.type === "ruler")
    return { start: { x: obj.x, y: obj.y }, end: { x: obj.x + obj.w, y: obj.y + obj.h } };
  if (obj.type === "circle") {
    const r = Math.abs(obj.w);
    return {
      tl: { x: obj.x - r, y: obj.y - r }, tr: { x: obj.x + r, y: obj.y - r },
      bl: { x: obj.x - r, y: obj.y + r }, br: { x: obj.x + r, y: obj.y + r },
    };
  }
  if (obj.type === "rect" || obj.type === "blur")
    return {
      tl: { x: obj.x, y: obj.y }, tr: { x: obj.x + obj.w, y: obj.y },
      bl: { x: obj.x, y: obj.y + obj.h }, br: { x: obj.x + obj.w, y: obj.y + obj.h },
    };
  return null; // pen, highlight, text, step: move only
}

function drawSelection(obj) {
  ctx.save();
  ctx.globalAlpha = 1;
  ctx.strokeStyle = "#3498db";
  ctx.fillStyle = "#3498db";
  ctx.lineWidth = 1;
  ctx.setLineDash([4, 4]);
  const b = getBounds(obj);
  ctx.strokeRect(b.x - 4, b.y - 4, b.w + 8, b.h + 8);
  ctx.setLineDash([]);
  const handles = handlesFor(obj);
  if (handles) {
    Object.values(handles).forEach((c) => {
      ctx.fillStyle = "#fff";
      ctx.fillRect(c.x - HANDLE_SIZE / 2 - 1, c.y - HANDLE_SIZE / 2 - 1, HANDLE_SIZE + 2, HANDLE_SIZE + 2);
      ctx.fillStyle = "#3498db";
      ctx.fillRect(c.x - HANDLE_SIZE / 2, c.y - HANDLE_SIZE / 2, HANDLE_SIZE, HANDLE_SIZE);
    });
  }
  ctx.restore();
}

function getBounds(obj) {
  if (obj.type === "pen" || obj.type === "highlight") {
    const xs = obj.points.map((p) => p.x),
      ys = obj.points.map((p) => p.y);
    const x = Math.min(...xs),
      y = Math.min(...ys);
    return { x, y, w: Math.max(...xs) - x, h: Math.max(...ys) - y };
  }
  if (obj.type === "text") {
    ctx.save();
    ctx.font = `${obj.size || 20}px Arial`;
    const size = obj.size || 20;
    const w = ctx.measureText(obj.text).width;
    ctx.restore();
    return { x: obj.x, y: obj.y - size, w, h: size * 1.2 };
  }
  if (obj.type === "step" || obj.type === "circle") {
    const r = obj.type === "step" ? obj.size || 16 : Math.abs(obj.w);
    return { x: obj.x - r, y: obj.y - r, w: r * 2, h: r * 2 };
  }
  return { x: Math.min(obj.x, obj.x + obj.w), y: Math.min(obj.y, obj.y + obj.h), w: Math.abs(obj.w), h: Math.abs(obj.h) };
}

function getResizeHandle(x, y, obj) {
  const handles = handlesFor(obj);
  if (!handles) return null;
  for (const [name, c] of Object.entries(handles)) {
    if (Math.abs(x - c.x) < 10 && Math.abs(y - c.y) < 10) return name;
  }
  return null;
}

function distToSegment(px, py, x1, y1, x2, y2) {
  const dx = x2 - x1,
    dy = y2 - y1;
  const len2 = dx * dx + dy * dy;
  const t = len2 ? Math.max(0, Math.min(1, ((px - x1) * dx + (py - y1) * dy) / len2)) : 0;
  return Math.hypot(px - (x1 + t * dx), py - (y1 + t * dy));
}

function isPointInShape(x, y, obj) {
  if (obj.type === "rect" || obj.type === "blur")
    return (
      x >= Math.min(obj.x, obj.x + obj.w) &&
      x <= Math.max(obj.x, obj.x + obj.w) &&
      y >= Math.min(obj.y, obj.y + obj.h) &&
      y <= Math.max(obj.y, obj.y + obj.h)
    );
  if (obj.type === "circle") return Math.hypot(x - obj.x, y - obj.y) <= Math.abs(obj.w);
  if (obj.type === "step") return Math.hypot(x - obj.x, y - obj.y) <= (obj.size || 16) + 2;
  if (obj.type === "pen" || obj.type === "highlight") {
    const tol = Math.max(10, (obj.width || 3) / 2 + 4);
    const pts = obj.points;
    if (pts.length === 1) return Math.hypot(x - pts[0].x, y - pts[0].y) < tol;
    for (let i = 1; i < pts.length; i++) {
      if (distToSegment(x, y, pts[i - 1].x, pts[i - 1].y, pts[i].x, pts[i].y) < tol) return true;
    }
    return false;
  }
  if (obj.type === "ruler" || obj.type === "arrow")
    return distToSegment(x, y, obj.x, obj.y, obj.x + obj.w, obj.y + obj.h) < 12;
  if (obj.type === "text") {
    const b = getBounds(obj);
    return x >= b.x && x <= b.x + Math.max(b.w, 20) && y >= b.y && y <= b.y + b.h + 4;
  }
  return false;
}

// ---------- Text ----------
// x / y are page coordinates; the box itself is positioned on screen and follows scrolling
function addTextInput(x, y, editing) {
  commitText();
  const size = editing ? editing.size || 20 : Math.round(14 + strokeWidth * 2);
  const color = editing ? editing.color : currentColor;
  const input = document.createElement("input");
  input.className = "text-input";
  input.style.color = color;
  input.style.fontSize = size + "px";
  input.placeholder = "Type, then Enter";
  input.setAttribute("aria-label", "Text annotation");
  if (editing) input.value = editing.text;
  // Keystrokes stay inside the overlay: the page's bubbling key handlers never see them
  ["keydown", "keyup", "keypress", "input", "beforeinput", "paste", "copy", "cut"].forEach((t) =>
    input.addEventListener(t, (e) => e.stopPropagation()),
  );
  wrap.appendChild(input);
  textBox = { input, x, y, size, color, editing };
  positionTextBox();
  if (editing) {
    selectedObj = null;
    editing.hidden = true; // hide the canvas copy while editing
    redraw();
  }
  input.focus({ preventScroll: true });
  input.select();
  input.addEventListener("blur", () => commitText());
  input.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      commitText();
    } else if (e.key === "Escape") {
      e.preventDefault();
      commitText(true);
    }
  });
}

function positionTextBox() {
  if (!textBox) return;
  textBox.input.style.left = textBox.x - window.scrollX + "px";
  textBox.input.style.top = textBox.y - window.scrollY - textBox.size + "px";
}

// Finish the open text box. cancel = drop the typed text (Escape)
function commitText(cancel) {
  if (!textBox) return;
  const tb = textBox;
  textBox = null;
  const value = cancel ? "" : tb.input.value.trim();
  if (tb.editing) {
    delete tb.editing.hidden;
    if (!cancel && value !== tb.editing.text) {
      pushHistory();
      if (value) tb.editing.text = value;
      else drawings = drawings.filter((o) => o !== tb.editing);
    }
  } else if (value) {
    pushHistory();
    drawings.push({ type: "text", x: tb.x, y: tb.y, text: value, color: tb.color, size: tb.size });
  }
  tb.input.remove();
  redraw();
}

// ---------- Toolbar drag ----------
function setupToolbarDrag() {
  const h = $("drag-handle");
  let offsetX, offsetY;

  const onMove = (ev) => {
    placeToolbar(ev.clientX - offsetX, ev.clientY - offsetY);
  };
  const onUp = (ev) => {
    h.removeEventListener("pointermove", onMove);
    h.removeEventListener("pointerup", onUp);
    h.removeEventListener("pointercancel", onUp);
    try {
      h.releasePointerCapture(ev.pointerId);
    } catch (err) {
      /* ignore */
    }
  };
  h.addEventListener("pointerdown", (e) => {
    const rect = toolbarEl.getBoundingClientRect();
    offsetX = e.clientX - rect.left;
    offsetY = e.clientY - rect.top;
    h.setPointerCapture(e.pointerId);
    h.addEventListener("pointermove", onMove);
    h.addEventListener("pointerup", onUp);
    h.addEventListener("pointercancel", onUp);
    e.preventDefault(); // no text selection while dragging
  });
}

// Keep the toolbar inside the window (also after the window gets smaller)
function placeToolbar(x, y) {
  const vp = viewport();
  const cx = Math.min(Math.max(0, x), Math.max(0, vp.w - toolbarEl.offsetWidth));
  const cy = Math.min(Math.max(0, y), Math.max(0, vp.h - 30));
  toolbarEl.style.left = cx + "px";
  toolbarEl.style.top = cy + "px";
  toolbarEl.style.right = "auto";
}

// ---------- Size / HiDPI ----------
function resizeCanvas() {
  // Render at device resolution so lines stay sharp on HiDPI screens and after zooming
  const dpr = window.devicePixelRatio || 1;
  const vp = viewport();
  canvas.width = Math.round(vp.w * dpr);
  canvas.height = Math.round(vp.h * dpr);
  canvas.style.width = vp.w + "px";
  canvas.style.height = vp.h + "px";
  blurLayer.style.width = vp.w + "px";
  blurLayer.style.height = vp.h + "px";
  if (toolbarEl.style.left) placeToolbar(parseFloat(toolbarEl.style.left), parseFloat(toolbarEl.style.top));
  redraw();
}

// Moving the window to a screen with a different pixel density does not always fire
// "resize": watch devicePixelRatio directly.
function watchDpr() {
  if (!window.matchMedia || abort.signal.aborted) return;
  const mq = window.matchMedia(`(resolution: ${window.devicePixelRatio || 1}dppx)`);
  mq.addEventListener(
    "change",
    () => {
      if (!canvas) return;
      resizeCanvas();
      watchDpr();
    },
    { once: true, signal: abort.signal },
  );
}

// ---------- Messages from background.js ----------
const onMessage = (msg, sender, sendResponse) => {
  if (!msg || msg.action !== "toggle" || sender.id !== chrome.runtime.id) return;
  if (host && host.isConnected) toggleUI();
  else {
    destroy(); // the page removed our element: start fresh
    init(msg);
  }
  sendResponse({ ok: true });
};
chrome.runtime.onMessage.addListener(onMessage);
window.__webDrawPro = {
  destroy() {
    try {
      chrome.runtime.onMessage.removeListener(onMessage);
    } catch (err) {
      /* context invalidated */
    }
    destroy();
  },
};
})();
