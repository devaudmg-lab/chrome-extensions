// Guard: background re-runs this file on every toolbar click; top-level
// `let` redeclaration would throw, so wrap everything and run only once.
(() => {
if (window.__webDrawProInjected) return;
window.__webDrawProInjected = true;

// All shapes are stored in PAGE coordinates (clientX + scrollX), so drawings stay
// attached to the content and scroll with the page.
let canvas, ctx;
let drawings = [];
let history = []; // snapshots of `drawings` for Undo
let future = []; // snapshots for Redo
let isDrawing = false;
let isActive = true;
let currentTool = "pen";
let currentColor = "#ff0000";
let strokeWidth = 3;
let fillShapes = false;
let selectedObj = null;
let resizeHandle = null;
let historyPendingForDrag = false;
let startX, startY;
let currentPath = [];
let blurLayer = null;
let blurEls = [];
const HANDLE_SIZE = 8;
const MAX_HISTORY = 100;

// Single-key tool shortcuts (only while the toolbar is open and you're not typing)
const TOOL_KEYS = { v: "select", p: "pen", e: "eraser", r: "rect", o: "circle", a: "arrow", m: "ruler", t: "text", b: "blur", n: "step" };

// Remember the last colour / width / fill between sessions
function loadSettings() {
  try {
    chrome.storage.local.get(
      { color: "#ff0000", strokeWidth: 3, fill: false, onboarded: false },
      (s) => {
        if (chrome.runtime.lastError) return;
        currentColor = s.color;
        strokeWidth = Number(s.strokeWidth) || 3;
        fillShapes = !!s.fill;
        const picker = document.getElementById("color-picker");
        const width = document.getElementById("width-picker");
        if (picker) picker.value = currentColor;
        if (width) width.value = String(strokeWidth);
        updateFillButton();
        if (!s.onboarded) showTip();
      },
    );
  } catch (err) {
    /* storage unavailable: keep defaults */
  }
}
function saveSettings() {
  try {
    chrome.storage.local.set({ color: currentColor, strokeWidth, fill: fillShapes });
  } catch (err) {
    /* ignore */
  }
}

function pushHistory() {
  history.push(JSON.stringify(drawings));
  if (history.length > MAX_HISTORY) history.shift();
  future = []; // a new change makes the redo steps invalid
}
function undo() {
  if (!history.length) return toast("Nothing to undo");
  future.push(JSON.stringify(drawings));
  drawings = JSON.parse(history.pop());
  selectedObj = null;
  redraw();
}
function redo() {
  if (!future.length) return toast("Nothing to redo");
  history.push(JSON.stringify(drawings));
  drawings = JSON.parse(future.pop());
  selectedObj = null;
  redraw();
}

// Page <-> screen helpers
const pageX = (clientX) => clientX + window.scrollX;
const pageY = (clientY) => clientY + window.scrollY;

let toastTimer = null;
function toast(text) {
  const el = document.getElementById("webdraw-toast");
  if (!el) return;
  el.textContent = text;
  el.classList.add("webdraw-toast-show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove("webdraw-toast-show"), 2200);
}

function showTip() {
  const tip = document.getElementById("webdraw-tip");
  if (!tip) return;
  tip.hidden = false;
  document.getElementById("webdraw-tip-ok").onclick = () => {
    tip.hidden = true;
    try {
      chrome.storage.local.set({ onboarded: true });
    } catch (err) {
      /* ignore */
    }
  };
}

function init() {
  if (document.getElementById("webdraw-container")) return;

  const container = document.createElement("div");
  container.id = "webdraw-container";
  container.innerHTML = `
        <div id="webdraw-blur-layer"></div>
        <canvas id="webdraw-canvas"></canvas>
        <div id="webdraw-side-tab">Draw ✏️</div>
        <div id="webdraw-toolbar">
            <div class="drag-handle wide" id="drag-handle" title="Drag to move">⠿</div>
            <button class="tool-btn" id="btn-select" title="Select / move (V) · Delete removes">👆</button>
            <button class="tool-btn tool-active" id="btn-pen" title="Pen (P)">✏️</button>
            <button class="tool-btn" id="btn-rect" title="Rectangle (R)">🟦</button>
            <button class="tool-btn" id="btn-circle" title="Circle (O)">⭕</button>
            <button class="tool-btn" id="btn-arrow" title="Arrow (A)">➚</button>
            <button class="tool-btn" id="btn-text" title="Text (T)"><b>T</b></button>
            <button class="tool-btn" id="btn-step" title="Numbered step (N)"><span class="step-icon">1</span></button>
            <button class="tool-btn" id="btn-blur" title="Blur / redact an area (B)">▦</button>
            <button class="tool-btn" id="btn-ruler" title="Ruler (M)">📏</button>
            <button class="tool-btn" id="btn-eraser" title="Eraser (E)">🧽</button>
            <input type="color" id="color-picker" class="color-picker wide" value="#ff0000" title="Colour">
            <select id="width-picker" class="width-picker wide" title="Stroke width">
                <option value="2">Thin</option>
                <option value="3" selected>Normal</option>
                <option value="6">Thick</option>
                <option value="10">Marker</option>
            </select>
            <button class="tool-btn wide" id="btn-fill" title="Fill rectangles and circles">🎨 Fill</button>
            <hr class="wide">
            <button class="tool-btn" id="btn-undo" title="Undo (Ctrl+Z)">↩️</button>
            <button class="tool-btn" id="btn-redo" title="Redo (Ctrl+Y)">↪️</button>
            <button class="tool-btn" id="btn-copy" title="Copy screenshot to clipboard">📋</button>
            <button class="tool-btn" id="btn-save" title="Save screenshot with drawings">💾</button>
            <button class="tool-btn" id="btn-clear" title="Clear all">🗑️</button>
            <button class="tool-btn" id="btn-minimize" style="background:#f39c12; color:white" title="Minimize to side (Alt+Shift+D hides the toolbar)">➡️</button>
        </div>
        <div id="webdraw-tip" hidden>
            <b>Welcome to WebDrawPro</b>
            Drawings stick to the page as you scroll.<br>
            Keys: <kbd>P</kbd> pen, <kbd>R</kbd> box, <kbd>A</kbd> arrow, <kbd>T</kbd> text, <kbd>N</kbd> step, <kbd>B</kbd> blur, <kbd>V</kbd> select.<br>
            <kbd>Ctrl</kbd>+<kbd>Z</kbd> / <kbd>Ctrl</kbd>+<kbd>Y</kbd> undo and redo.
            <button id="webdraw-tip-ok">Got it</button>
        </div>
        <div id="webdraw-toast"></div>
    `;
  document.body.appendChild(container);

  canvas = document.getElementById("webdraw-canvas");
  ctx = canvas.getContext("2d");
  blurLayer = document.getElementById("webdraw-blur-layer");

  document.getElementById("webdraw-side-tab").onclick = toggleUI;
  document.getElementById("btn-minimize").onclick = toggleUI;

  resizeCanvas();
  setupListeners();
  setupToolbarDrag();
  loadSettings();
}

function toggleUI() {
  isActive = !isActive;
  const canvasEl = document.getElementById("webdraw-canvas");
  const toolbar = document.getElementById("webdraw-toolbar");
  const sideTab = document.getElementById("webdraw-side-tab");

  if (isActive) {
    canvasEl.style.display = "block";
    blurLayer.style.display = "block";
    toolbar.style.display = "grid";
    sideTab.style.display = "none";
    canvasEl.style.pointerEvents = "auto";
    redraw();
  } else {
    canvasEl.style.display = "none";
    blurLayer.style.display = "none";
    toolbar.style.display = "none";
    sideTab.style.display = "block";
    canvasEl.style.pointerEvents = "none";
    document.getElementById("webdraw-tip").hidden = true;
    isDrawing = false; // Reset drawing state
  }
}

function updateFillButton() {
  const fillBtn = document.getElementById("btn-fill");
  if (!fillBtn) return;
  fillBtn.style.background = fillShapes ? "#3498db" : "#ecf0f1";
  fillBtn.style.color = fillShapes ? "white" : "black";
}

function selectTool(t) {
  const btn = document.getElementById(`btn-${t}`);
  if (!btn) return;
  currentTool = t;
  document
    .querySelectorAll("#webdraw-toolbar .tool-btn")
    .forEach((b) => b.classList.remove("tool-active"));
  btn.classList.add("tool-active");
  canvas.style.cursor = t === "select" ? "default" : t === "text" ? "text" : "crosshair";
  selectedObj = null;
  redraw();
}

// Screenshot of the visible page with the drawings on top (toolbar, tips and selection
// handles hidden). Falls back to exporting only the drawing layer.
async function captureScreenshot() {
  const hide = ["webdraw-toolbar", "webdraw-tip", "webdraw-toast"].map((id) => document.getElementById(id));
  const prev = hide.map((el) => el.style.visibility);
  hide.forEach((el) => (el.style.visibility = "hidden"));
  const sel = selectedObj;
  selectedObj = null;
  redraw();
  await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
  let dataUrl = null;
  try {
    const res = await chrome.runtime.sendMessage({ action: "capture" });
    if (res && res.dataUrl) dataUrl = res.dataUrl;
  } catch (err) {
    /* fall back below */
  }
  hide.forEach((el, i) => (el.style.visibility = prev[i]));
  selectedObj = sel;
  redraw();
  return dataUrl || canvas.toDataURL("image/png");
}

async function saveImage() {
  const dataUrl = await captureScreenshot();
  const link = document.createElement("a");
  const stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-");
  link.download = `web-drawing-${stamp}.png`;
  link.href = dataUrl;
  link.click();
}

async function copyImage() {
  try {
    // Hand the clipboard a promise so the click's user activation is still valid
    const blob = captureScreenshot().then((url) => fetch(url).then((r) => r.blob()));
    await navigator.clipboard.write([new ClipboardItem({ "image/png": blob })]);
    toast("Screenshot copied to the clipboard");
  } catch (err) {
    toast("This page blocks copying. Use Save 💾 instead.");
  }
}

function setupListeners() {
  ["select", "pen", "rect", "circle", "arrow", "ruler", "text", "eraser", "blur", "step"].forEach((t) => {
    const btn = document.getElementById(`btn-${t}`);
    if (btn) btn.onclick = () => selectTool(t);
  });

  // Toggle Fill Logic
  const fillBtn = document.getElementById("btn-fill");
  fillBtn.onclick = () => {
    fillShapes = !fillShapes;
    updateFillButton();
    saveSettings();
  };

  document.getElementById("btn-save").onclick = saveImage;
  document.getElementById("btn-copy").onclick = copyImage;

  document.getElementById("color-picker").oninput = (e) => {
    currentColor = e.target.value;
    // Recolour the selected shape too
    if (selectedObj && selectedObj.type !== "blur") {
      pushHistory();
      selectedObj.color = currentColor;
      redraw();
    }
    saveSettings();
  };
  document.getElementById("width-picker").onchange = (e) => {
    strokeWidth = Number(e.target.value) || 3;
    saveSettings();
  };
  document.getElementById("btn-clear").onclick = () => {
    if (!drawings.length) return toast("Nothing to clear yet");
    pushHistory(); // Clear can be undone
    drawings = [];
    selectedObj = null;
    redraw();
    toast("Cleared. Press Ctrl+Z to undo.");
  };
  document.getElementById("btn-undo").onclick = undo;
  document.getElementById("btn-redo").onclick = redo;

  canvas.onmousedown = (e) => {
    if (!isActive || e.button !== 0) return;
    const x = pageX(e.clientX),
      y = pageY(e.clientY);
    isDrawing = true;

    if (currentTool === "eraser") {
      const remaining = drawings.filter((obj) => !isPointInShape(x, y, obj));
      if (remaining.length !== drawings.length) {
        pushHistory();
        drawings = remaining;
      }
      isDrawing = false;
      redraw();
      return;
    }

    if (currentTool === "step") {
      pushHistory();
      const n = drawings.reduce((max, o) => (o.type === "step" ? Math.max(max, o.n) : max), 0) + 1;
      drawings.push({ type: "step", x, y, n, color: currentColor, size: 12 + strokeWidth * 1.5 });
      isDrawing = false;
      redraw();
      return;
    }

    if (currentTool === "select") {
      historyPendingForDrag = false;
      if (selectedObj) {
        resizeHandle = getResizeHandle(x, y, selectedObj);
        if (resizeHandle) {
          historyPendingForDrag = true;
          return;
        }
      }
      selectedObj = [...drawings]
        .reverse()
        .find((obj) => isPointInShape(x, y, obj));
      if (selectedObj) {
        historyPendingForDrag = true;
        startX = x - selectedObj.x;
        startY = y - selectedObj.y;
      }
      redraw();
    } else {
      startX = x;
      startY = y;
      if (currentTool === "pen") {
        currentPath = [{ x, y }];
      }
      if (currentTool === "text") {
        e.preventDefault(); // keep the focus in the new text box
        addTextInput(x, y);
        isDrawing = false;
      }
    }
  };

  canvas.onmousemove = (e) => {
    if (!isDrawing) return;
    const x = pageX(e.clientX),
      y = pageY(e.clientY);

    if (currentTool === "select" && selectedObj) {
      // Snapshot once, on the first actual movement, so a plain click doesn't fill Undo
      if (historyPendingForDrag) {
        pushHistory(); // serialised copy; we keep editing the live object
        historyPendingForDrag = false;
      }
      if (resizeHandle) {
        // Resize Logic
        if (resizeHandle === "br") {
          selectedObj.w = x - selectedObj.x;
          selectedObj.h = y - selectedObj.y;
        } else if (resizeHandle === "bl") {
          let oldX = selectedObj.x;
          selectedObj.x = x;
          selectedObj.w += oldX - x;
          selectedObj.h = y - selectedObj.y;
        } else if (resizeHandle === "tr") {
          let oldY = selectedObj.y;
          selectedObj.y = y;
          selectedObj.h += oldY - y;
          selectedObj.w = x - selectedObj.x;
        } else if (resizeHandle === "tl") {
          let oldX = selectedObj.x,
            oldY = selectedObj.y;
          selectedObj.x = x;
          selectedObj.y = y;
          selectedObj.w += oldX - x;
          selectedObj.h += oldY - y;
        }
      } else {
        // Move Logic
        if (selectedObj.type === "pen") {
          const dx = x - (startX + selectedObj.x),
            dy = y - (startY + selectedObj.y);
          selectedObj.points = selectedObj.points.map((p) => ({
            x: p.x + dx,
            y: p.y + dy,
          }));
          selectedObj.x += dx;
          selectedObj.y += dy;
        } else {
          selectedObj.x = x - startX;
          selectedObj.y = y - startY;
        }
      }
    } else if (currentTool === "pen") {
      currentPath.push({ x, y });
    }
    redraw(x, y);
  };

  // Listen on window so releasing the mouse outside the canvas (e.g. over the
  // toolbar) still finishes the shape instead of leaving the tool stuck.
  window.addEventListener("mouseup", (e) => {
    if (!isDrawing) return;
    if (currentTool !== "select" && currentTool !== "text") {
      const endX = pageX(e.clientX),
        endY = pageY(e.clientY);
      let dx = endX - startX,
        dy = endY - startY;
      let angle = calculateAngle(startX, startY, endX, endY);

      // Snapping
      if (currentTool === "ruler" && Math.abs(angle % 90) < 10) {
        angle = Math.round(angle / 90) * 90;
        let d = Math.sqrt(dx * dx + dy * dy);
        dx = d * Math.cos((angle * Math.PI) / 180);
        dy = d * Math.sin((angle * Math.PI) / 180);
      }

      if (currentTool === "circle") dx = Math.sqrt(dx * dx + dy * dy);

      // A plain click with a shape tool would create an invisible zero-size shape
      const isDot = currentTool !== "pen" && dx === 0 && dy === 0;
      const tooSmallBlur = currentTool === "blur" && (Math.abs(dx) < 4 || Math.abs(dy) < 4);
      if (!isDot && !tooSmallBlur) {
        pushHistory();
        drawings.push({
          type: currentTool,
          color: currentColor,
          width: strokeWidth,
          fill: fillShapes,
          x: startX,
          y: startY,
          w: dx,
          h: dy,
          points: currentTool === "pen" ? [...currentPath] : [],
          angle: angle,
          text: "",
        });
      }
    }
    isDrawing = false;
    resizeHandle = null;
    historyPendingForDrag = false;
    redraw();
  });

  // Keyboard shortcuts (only while the overlay is active and you're not typing)
  document.addEventListener(
    "keydown",
    (e) => {
      if (!isActive || !canvas) return;
      const t = e.target;
      if (t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName))) return;
      const key = e.key.toLowerCase();
      const mod = e.ctrlKey || e.metaKey;
      let handled = true;
      if (mod && !e.shiftKey && key === "z") undo();
      else if (mod && (key === "y" || (e.shiftKey && key === "z"))) redo();
      else if ((e.key === "Delete" || e.key === "Backspace") && selectedObj) {
        pushHistory();
        drawings = drawings.filter((o) => o !== selectedObj);
        selectedObj = null;
        redraw();
      } else if (e.key === "Escape" && selectedObj) {
        selectedObj = null;
        redraw();
      } else if (!mod && !e.altKey && !e.shiftKey && TOOL_KEYS[key]) selectTool(TOOL_KEYS[key]);
      else handled = false;
      if (handled) {
        e.preventDefault();
        e.stopPropagation();
      }
    },
    true,
  );

  // Drawings live in page coordinates: repaint when the page scrolls
  let scrollFrame = null;
  window.addEventListener(
    "scroll",
    () => {
      if (scrollFrame) return;
      scrollFrame = requestAnimationFrame(() => {
        scrollFrame = null;
        redraw();
      });
    },
    { passive: true },
  );
}

function calculateAngle(x1, y1, x2, y2) {
  let angle = Math.atan2(y2 - y1, x2 - x1) * (180 / Math.PI);
  return angle < 0 ? angle + 360 : angle;
}

// Readable measurement badge centred on the ruler line (dark pill, white text)
function drawRulerLabel(text, cx, cy) {
  ctx.save();
  ctx.setLineDash([]);
  ctx.font = "bold 12px Arial";
  const w = ctx.measureText(text).width + 14;
  const h = 20;
  ctx.fillStyle = "rgba(44, 62, 80, 0.92)";
  ctx.beginPath();
  if (ctx.roundRect) ctx.roundRect(cx - w / 2, cy - h / 2, w, h, 10);
  else ctx.rect(cx - w / 2, cy - h / 2, w, h);
  ctx.fill();
  ctx.fillStyle = "#fff";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(text, cx, cy + 1);
  ctx.restore();
}

function drawArrowHead(x1, y1, x2, y2, width) {
  const head = Math.max(10, width * 4);
  const a = Math.atan2(y2 - y1, x2 - x1);
  ctx.beginPath();
  ctx.moveTo(x2, y2);
  ctx.lineTo(x2 - head * Math.cos(a - Math.PI / 7), y2 - head * Math.sin(a - Math.PI / 7));
  ctx.lineTo(x2 - head * Math.cos(a + Math.PI / 7), y2 - head * Math.sin(a + Math.PI / 7));
  ctx.closePath();
  ctx.fill();
}

// Blur areas are real DOM boxes with backdrop-filter (a canvas cannot read the page pixels).
// They sit under the drawing canvas and are included in Save / Copy screenshots.
function syncBlurLayer() {
  if (!blurLayer) return;
  const blurs = drawings.filter((o) => o.type === "blur");
  while (blurEls.length < blurs.length) {
    const el = document.createElement("div");
    el.className = "webdraw-blur";
    blurLayer.appendChild(el);
    blurEls.push(el);
  }
  while (blurEls.length > blurs.length) blurEls.pop().remove();
  blurs.forEach((o, i) => {
    const el = blurEls[i];
    el.style.left = Math.min(o.x, o.x + o.w) - window.scrollX + "px";
    el.style.top = Math.min(o.y, o.y + o.h) - window.scrollY + "px";
    el.style.width = Math.abs(o.w) + "px";
    el.style.height = Math.abs(o.h) + "px";
  });
}

function redraw(curX, curY) {
  if (!ctx) return;
  const dpr = window.devicePixelRatio || 1;
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  // Page coordinates -> screen: shift by the scroll position
  ctx.setTransform(dpr, 0, 0, dpr, -window.scrollX * dpr, -window.scrollY * dpr);
  syncBlurLayer();
  drawings.forEach((obj) => drawShape(obj, obj === selectedObj));

  if (isDrawing && currentTool !== "select" && curX !== undefined) {
    ctx.strokeStyle = currentColor;
    ctx.fillStyle = currentColor;
    ctx.lineWidth = strokeWidth;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.setLineDash([5, 5]);
    if (currentTool === "rect")
      ctx.strokeRect(startX, startY, curX - startX, curY - startY);
    else if (currentTool === "blur") {
      ctx.save();
      ctx.lineWidth = 1.5;
      ctx.strokeStyle = "#3498db";
      ctx.fillStyle = "rgba(52, 152, 219, 0.12)";
      ctx.fillRect(startX, startY, curX - startX, curY - startY);
      ctx.strokeRect(startX, startY, curX - startX, curY - startY);
      ctx.restore();
    } else if (currentTool === "circle") {
      let r = Math.sqrt((curX - startX) ** 2 + (curY - startY) ** 2);
      ctx.beginPath();
      ctx.arc(startX, startY, r, 0, Math.PI * 2);
      ctx.stroke();
    } else if (currentTool === "arrow") {
      ctx.beginPath();
      ctx.moveTo(startX, startY);
      ctx.lineTo(curX, curY);
      ctx.stroke();
      ctx.setLineDash([]);
      drawArrowHead(startX, startY, curX, curY, strokeWidth);
    } else if (currentTool === "ruler") {
      let angle = calculateAngle(startX, startY, curX, curY);
      let d = Math.round(Math.hypot(curX - startX, curY - startY));
      ctx.beginPath();
      ctx.moveTo(startX, startY);
      ctx.lineTo(curX, curY);
      ctx.stroke();
      ctx.setLineDash([]);
      drawRulerLabel(`${d}px / ${Math.round(angle)}°`, (startX + curX) / 2, (startY + curY) / 2);
    } else if (currentTool === "pen") {
      ctx.setLineDash([]);
      ctx.beginPath();
      currentPath.forEach((p, i) =>
        i === 0 ? ctx.moveTo(p.x, p.y) : ctx.lineTo(p.x, p.y),
      );
      ctx.stroke();
    }
    ctx.setLineDash([]);
  }
}

function drawShape(obj, isSelected) {
  const width = obj.width || 3;
  ctx.strokeStyle = obj.color;
  ctx.fillStyle = obj.color;
  ctx.lineWidth = width;
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  ctx.beginPath();

  if (obj.type === "pen") {
    obj.points.forEach((p, i) =>
      i === 0 ? ctx.moveTo(p.x, p.y) : ctx.lineTo(p.x, p.y),
    );
    if (obj.points.length === 1) ctx.lineTo(obj.points[0].x + 0.1, obj.points[0].y);
    ctx.stroke();
  } else if (obj.type === "rect") {
    if (obj.fill) ctx.fillRect(obj.x, obj.y, obj.w, obj.h);
    ctx.strokeRect(obj.x, obj.y, obj.w, obj.h);
  } else if (obj.type === "circle") {
    ctx.arc(obj.x, obj.y, Math.abs(obj.w), 0, Math.PI * 2);
    if (obj.fill) ctx.fill();
    ctx.stroke();
  } else if (obj.type === "arrow") {
    ctx.moveTo(obj.x, obj.y);
    ctx.lineTo(obj.x + obj.w, obj.y + obj.h);
    ctx.stroke();
    drawArrowHead(obj.x, obj.y, obj.x + obj.w, obj.y + obj.h, width);
  } else if (obj.type === "ruler") {
    ctx.moveTo(obj.x, obj.y);
    ctx.lineTo(obj.x + obj.w, obj.y + obj.h);
    ctx.stroke();
    let d = Math.round(Math.sqrt(obj.w ** 2 + obj.h ** 2));
    let angle = calculateAngle(obj.x, obj.y, obj.x + obj.w, obj.y + obj.h);
    drawRulerLabel(`${d}px / ${Math.round(angle)}°`, obj.x + obj.w / 2, obj.y + obj.h / 2);
  } else if (obj.type === "text") {
    ctx.font = `${obj.size || 20}px Arial`;
    ctx.fillText(obj.text, obj.x, obj.y);
  } else if (obj.type === "step") {
    // Numbered callout: filled circle with a white number and a soft white ring
    const r = obj.size || 16;
    ctx.arc(obj.x, obj.y, r, 0, Math.PI * 2);
    ctx.fill();
    ctx.lineWidth = 2;
    ctx.strokeStyle = "rgba(255, 255, 255, 0.9)";
    ctx.stroke();
    ctx.fillStyle = "#fff";
    ctx.font = `bold ${Math.round(r * 1.1)}px Arial`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(String(obj.n), obj.x, obj.y + 1);
    ctx.textAlign = "start";
    ctx.textBaseline = "alphabetic";
  }
  // "blur" is drawn by syncBlurLayer(); only its selection handles are painted here

  if (isSelected) {
    ctx.fillStyle = "#3498db";
    if (obj.type === "pen" || obj.type === "text" || obj.type === "step") {
      // No resize handles: just show a dashed box around the selection
      const b = getBounds(obj);
      ctx.save();
      ctx.strokeStyle = "#3498db";
      ctx.lineWidth = 1;
      ctx.setLineDash([4, 4]);
      ctx.strokeRect(b.x - 4, b.y - 4, b.w + 8, b.h + 8);
      ctx.restore();
      return;
    }
    if (obj.type === "blur") {
      ctx.save();
      ctx.strokeStyle = "#3498db";
      ctx.lineWidth = 1;
      ctx.setLineDash([4, 4]);
      ctx.strokeRect(obj.x, obj.y, obj.w, obj.h);
      ctx.restore();
    }
    const corners = [
      { x: obj.x, y: obj.y },
      { x: obj.x + obj.w, y: obj.y },
      { x: obj.x, y: obj.y + obj.h },
      { x: obj.x + obj.w, y: obj.y + obj.h },
    ];
    corners.forEach((c) =>
      ctx.fillRect(c.x - 4, c.y - 4, HANDLE_SIZE, HANDLE_SIZE),
    );
  }
}

function getBounds(obj) {
  if (obj.type === "pen") {
    const xs = obj.points.map((p) => p.x),
      ys = obj.points.map((p) => p.y);
    const x = Math.min(...xs),
      y = Math.min(...ys);
    return { x, y, w: Math.max(...xs) - x, h: Math.max(...ys) - y };
  }
  if (obj.type === "text") {
    ctx.font = `${obj.size || 20}px Arial`;
    const size = obj.size || 20;
    return { x: obj.x, y: obj.y - size, w: ctx.measureText(obj.text).width, h: size };
  }
  if (obj.type === "step") {
    const r = obj.size || 16;
    return { x: obj.x - r, y: obj.y - r, w: r * 2, h: r * 2 };
  }
  return { x: obj.x, y: obj.y, w: obj.w, h: obj.h };
}

function getResizeHandle(x, y, obj) {
  if (obj.type === "pen" || obj.type === "text" || obj.type === "step") return null;
  if (Math.abs(x - obj.x) < 10 && Math.abs(y - obj.y) < 10) return "tl";
  if (Math.abs(x - (obj.x + obj.w)) < 10 && Math.abs(y - obj.y) < 10)
    return "tr";
  if (Math.abs(x - obj.x) < 10 && Math.abs(y - (obj.y + obj.h)) < 10)
    return "bl";
  if (Math.abs(x - (obj.x + obj.w)) < 10 && Math.abs(y - (obj.y + obj.h)) < 10)
    return "br";
  return null;
}

function distToSegment(px, py, x1, y1, x2, y2) {
  const dx = x2 - x1,
    dy = y2 - y1;
  const len2 = dx * dx + dy * dy;
  const t = len2 ? Math.max(0, Math.min(1, ((px - x1) * dx + (py - y1) * dy) / len2)) : 0;
  return Math.hypot(px - (x1 + t * dx), py - (y1 + t * dy));
}

function isPointInShape(x, y, obj) {
  if (obj.type === "rect" || obj.type === "blur")
    return (
      x >= Math.min(obj.x, obj.x + obj.w) &&
      x <= Math.max(obj.x, obj.x + obj.w) &&
      y >= Math.min(obj.y, obj.y + obj.h) &&
      y <= Math.max(obj.y, obj.y + obj.h)
    );
  if (obj.type === "circle")
    return Math.sqrt((x - obj.x) ** 2 + (y - obj.y) ** 2) <= Math.abs(obj.w);
  if (obj.type === "step") return Math.hypot(x - obj.x, y - obj.y) <= (obj.size || 16) + 2;
  if (obj.type === "pen")
    return obj.points.some(
      (p) => Math.sqrt((x - p.x) ** 2 + (y - p.y) ** 2) < 15,
    );
  // Distance to the segment (the old slope formula divided by zero on vertical lines)
  if (obj.type === "ruler" || obj.type === "arrow")
    return distToSegment(x, y, obj.x, obj.y, obj.x + obj.w, obj.y + obj.h) < 12;
  if (obj.type === "text") {
    const b = getBounds(obj);
    return x >= b.x && x <= b.x + Math.max(b.w, 20) && y >= b.y && y <= b.y + b.h + 4;
  }
  return false;
}

// x / y are page coordinates; the input box itself is positioned on screen
function addTextInput(x, y) {
  const size = Math.round(14 + strokeWidth * 2);
  const input = document.createElement("input");
  input.className = "webdraw-text-input";
  input.style.left = x - window.scrollX + "px";
  input.style.top = y - window.scrollY - size + "px";
  input.style.color = currentColor;
  input.style.fontSize = size + "px";
  input.placeholder = "Type, then Enter";
  document.getElementById("webdraw-container").appendChild(input);
  input.focus(); // focus right away so the first keys typed are not lost
  input.onblur = () => {
    if (input.value) {
      pushHistory();
      drawings.push({
        type: "text",
        x,
        y,
        text: input.value,
        color: currentColor,
        size,
      });
    }
    input.remove();
    redraw();
  };
  input.onkeydown = (e) => {
    if (e.key === "Enter") input.blur();
    if (e.key === "Escape") {
      input.value = "";
      input.blur();
    }
  };
}

function setupToolbarDrag() {
  const tb = document.getElementById("webdraw-toolbar");
  const h = document.getElementById("drag-handle");

  let offsetX, offsetY;

  const onMove = (ev) => {
    // Keep the toolbar inside the window
    const x = Math.min(Math.max(0, ev.clientX - offsetX), window.innerWidth - tb.offsetWidth);
    const y = Math.min(Math.max(0, ev.clientY - offsetY), window.innerHeight - 30);
    tb.style.left = x + "px";
    tb.style.top = y + "px";
    tb.style.right = "auto"; // Override the CSS 'right: 20px'
  };
  const onUp = () => {
    document.removeEventListener("mousemove", onMove, true);
    document.removeEventListener("mouseup", onUp, true);
    document.documentElement.style.cursor = "";
  };

  // addEventListener (not document.onmousemove) so the page's own handlers are left alone
  h.addEventListener("mousedown", (e) => {
    const rect = tb.getBoundingClientRect();
    offsetX = e.clientX - rect.left;
    offsetY = e.clientY - rect.top;
    document.documentElement.style.cursor = "move";
    document.addEventListener("mousemove", onMove, true);
    document.addEventListener("mouseup", onUp, true);
    // Prevent text selection while dragging
    e.preventDefault();
  });
}

function resizeCanvas() {
  // Render at device resolution so lines stay sharp on HiDPI screens
  const dpr = window.devicePixelRatio || 1;
  canvas.width = Math.round(window.innerWidth * dpr);
  canvas.height = Math.round(window.innerHeight * dpr);
  canvas.style.width = window.innerWidth + "px";
  canvas.style.height = window.innerHeight + "px";
  redraw();
}
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action !== "toggle") return;
  if (document.getElementById("webdraw-container")) toggleUI();
  else init();
  sendResponse({ ok: true });
});
window.addEventListener("resize", () => {
  if (canvas) resizeCanvas();
});
})();
