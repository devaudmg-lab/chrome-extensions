# WebDrawPro

Draw, annotate and measure directly on top of any web page. This is useful for screen shares, teaching, design reviews and bug reports.

## Features

- **Tools**: freehand pen, highlighter (new in 1.4), rectangle, circle, arrow, ruler (pixel distance and angle in a readable badge, snaps level/plumb), text, numbered steps, blur / black-out and eraser.
- **Works with a mouse, a pen tablet or touch** (new in 1.4). The eraser now erases everything you drag over.
- **Hold Shift** (new in 1.4) for perfect squares and for arrows and rulers in 45° steps.
- **Numbered steps**: click to drop markers 1, 2, 3... for how-to guides and bug reports.
- **Blur or black out**: drag over an email address, a key or a face. Blur gets stronger on larger areas; turn on **Fill** first for a solid black box. Both are in Save and Copy.
- **Drawings are saved per page** (new in 1.4): they are kept for the page address on your computer and come back the next time you open WebDrawPro on that page (also in single-page apps that change the address). **Clear all** removes them, and **Forget all pages** in the help panel (?) deletes every saved page. Nothing is saved in incognito windows.
- **Drawings stay attached to the page**: they scroll with the content they point at.
- **Select tool**: move any shape, resize boxes, circles, blur areas and lines (start and end handles). Picking a colour, width or Fill changes the selected shape. **Double-click a text** to edit it (new in 1.4). **Delete** removes the selected shape.
- **Minimize** keeps your drawings on screen while you use the page normally (new in 1.4); the eye button on the side tab hides them.
- **Undo and Redo** for everything, including Clear All and erasing.
- **Copy** a screenshot of the visible page with your drawings to the clipboard, or **Save** it as a PNG. The toolbar is not included.
- **Help panel** (? button or the `?` key) with every shortcut.

## Keyboard shortcuts

| Key | Action |
| :--- | :--- |
| `Alt+Shift+D` | Open / minimize the toolbar (same as clicking the icon; change at `chrome://extensions/shortcuts`) |
| `V` | Select / move (double-click text to edit) |
| `P` | Pen |
| `H` | Highlighter |
| `R` | Rectangle |
| `O` | Circle |
| `A` | Arrow |
| `T` | Text |
| `N` | Numbered step |
| `B` | Blur area (Fill on: black-out) |
| `M` | Ruler (measure) |
| `E` | Eraser |
| `Shift` while drawing | Square / 45° lines |
| `Ctrl/Cmd + Z` | Undo |
| `Ctrl/Cmd + Y` or `Ctrl/Cmd + Shift + Z` | Redo |
| `Delete` / `Backspace` | Delete the selected shape |
| `Esc` | Deselect / close the help panel |
| `?` | Help panel |

Single-key shortcuts only work while the toolbar is open, and never while you type in the page (inputs, text areas, rich-text editors and inputs inside web components).

## Install (Load unpacked)

1. Download the ZIP and extract it to a folder.
2. Open `chrome://extensions` and turn on **Developer mode** (top right).
3. Click **Load unpacked** and select the extracted folder (the one that contains `manifest.json`).
4. Pin WebDrawPro, open a web page and click the icon (or press `Alt+Shift+D`) to show the toolbar. Click the icon again to hide or show it.

Browser pages (`chrome://`, the Chrome Web Store) cannot be drawn on; the icon shows a short red ✕ there.

Limits: drawings follow the page's main scroll. Content that scrolls inside a box (for example a chat pane) moves under the drawings. If a responsive page re-flows after you resize the window, drawings keep their page position.

## Permissions

| Permission | Why |
| :--- | :--- |
| `activeTab` | Gives access only to the tab where you click the icon or press the shortcut. It is used to add the drawing layer and to take the screenshot for Save and Copy. |
| `scripting` | Injects the drawing toolbar into that tab. |
| `storage` | Remembers your colour, stroke width and Fill setting, and saves your drawings per page address, locally on your computer (max. 200 pages, oldest dropped first). Nothing is saved in incognito. |

No new permissions in 1.4.

## Privacy and security

- The toolbar, the drawing canvas, the text box and the blur boxes live in a **closed shadow root**. Scripts on the page cannot read your drawings or what you type in a text note, and cannot press Save or Copy.
- The page screenshot is taken by the extension and only handled inside the extension's isolated content script; it is never added to the page. Capture is refused unless the request comes from WebDrawPro in the tab that is currently on screen.
- The keys you type into a text note are not passed on to the page's own key handlers. (A page that listens in the capture phase on `window` could still see key presses, as for any typing on that page.)
- Copy uses the standard web clipboard API after you click the button. A few sites block clipboard access, and WebDrawPro then tells you to use Save instead.

There is no "read all your data on all websites" permission, no server and no network requests.

## Changelog

- **1.4.0**: overlay moved into a closed shadow root (page scripts can no longer read the canvas, notes or buttons); drawings saved per page address with Clear and Forget all; highlighter; pen/touch support and drag-to-erase; Shift constraint; double-click to edit text; minimize keeps drawings visible; help panel. Fixes: tool keys fired while typing in web-component inputs; colour picker flooded undo and storage; circle and line resize handles; ruler snapping only worked on one side of 0/90°; canvas covered the page scrollbar; text box did not follow scrolling; drawing preview vanished while scrolling; HiDPI not updated when moving between screens; toolbar could end up off-screen after resizing; dead toolbar left behind after an extension update; Save/Copy silently exported drawings only when capture failed; capture could photograph another tab.

- **1.3.0**: drawings anchored to the page, redo, blur/redact tool, numbered steps, copy to clipboard, single-key tool shortcuts and Alt+Shift+D, readable ruler labels, recolour selected shape, two-column toolbar, welcome tip and toasts.
- **1.2.0**: select/move/resize, undo, save with page screenshot, stroke width and fill, bug fixes.
