# WebDrawPro

Draw, annotate and measure directly on top of any web page. This is useful for screen shares, teaching, design reviews and bug reports.

## Features

- **Tools**: freehand pen, rectangle, circle, arrow, ruler (shows pixel distance and angle in a readable badge, and snaps to horizontal/vertical), text and eraser.
- **Numbered steps** (new in 1.3): click to drop numbered markers 1, 2, 3... for how-to guides and bug reports. They use the current colour.
- **Blur / redact** (new in 1.3): drag over an email address, a key or a face to blur it before you share a screenshot. The blur is included in Save and Copy.
- **Drawings stay attached to the page** (new in 1.3): they scroll with the content they point at, instead of floating over the screen.
- **Select tool**: move any shape and resize rectangles, circles, arrows, rulers and blur areas with the corner handles. Picking a colour recolours the selected shape. Press **Delete** to remove it.
- **Styling**: colour picker, stroke width (Thin, Normal, Thick, Marker) and solid fill for rectangles and circles. Your choices are remembered.
- **Undo and Redo** (redo is new in 1.3): works for drawing, moving, erasing and Clear All.
- **Copy** (new in 1.3): copies a screenshot of the visible page with your drawings to the clipboard, ready to paste into chat, email or an issue tracker.
- **Save**: downloads a PNG screenshot of the visible page with your drawings on it. The toolbar is not included.
- **Compact two-column toolbar**: drag it by the top handle. Minimize it to the side tab to use the page normally, and click the tab to start drawing again.
- First-run tip with the keyboard shortcuts, and short on-page messages (for example "Nothing to undo").

## Keyboard shortcuts

| Key | Action |
| :--- | :--- |
| `Alt+Shift+D` | Show / hide the toolbar (same as clicking the icon; change at `chrome://extensions/shortcuts`) |
| `V` | Select / move |
| `P` | Pen |
| `R` | Rectangle |
| `O` | Circle |
| `A` | Arrow |
| `T` | Text |
| `N` | Numbered step |
| `B` | Blur area |
| `M` | Ruler (measure) |
| `E` | Eraser |
| `Ctrl/Cmd + Z` | Undo |
| `Ctrl/Cmd + Y` or `Ctrl/Cmd + Shift + Z` | Redo |
| `Delete` / `Backspace` | Delete the selected shape |
| `Esc` | Deselect |

Single-key shortcuts only work while the toolbar is open and you are not typing in a text field.

## Install (Load unpacked)

1. Download the ZIP and extract it to a folder.
2. Open `chrome://extensions` and turn on **Developer mode** (top right).
3. Click **Load unpacked** and select the extracted folder (the one that contains `manifest.json`).
4. Pin WebDrawPro, open a web page and click the icon (or press `Alt+Shift+D`) to show the toolbar. Click the icon again to hide or show it.

Browser pages (`chrome://`, the Chrome Web Store) cannot be drawn on. Drawings are kept in the page until you reload it.

## Permissions

| Permission | Why |
| :--- | :--- |
| `activeTab` | Gives access only to the tab where you click the icon or press the shortcut. It is used to add the drawing layer and to take the screenshot for Save and Copy. |
| `scripting` | Injects the drawing toolbar into that tab. |
| `storage` | Remembers your colour, stroke width, fill setting and whether you have seen the welcome tip, locally. |

No new permissions were added in 1.3. Copy uses the standard web clipboard API after you click the button. A few sites block clipboard access, and WebDrawPro then tells you to use Save instead.

There is no "read all your data on all websites" permission, no server and no network requests.

## Changelog

- **1.3.0**: drawings anchored to the page, redo, blur/redact tool, numbered steps, copy to clipboard, single-key tool shortcuts and Alt+Shift+D, readable ruler labels, recolour selected shape, two-column toolbar, welcome tip and toasts.
- **1.2.0**: select/move/resize, undo, save with page screenshot, stroke width and fill, bug fixes.
