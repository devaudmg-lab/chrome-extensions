# WebDrawPro

Draw, annotate and measure directly on top of any web page. This is useful for screen shares, teaching, design reviews and bug reports.

## Features

- **Tools**: freehand pen, rectangle, circle, arrow, ruler (shows pixel distance and angle, and snaps to horizontal/vertical), text and eraser.
- **Select tool**: move any shape and resize rectangles, circles, arrows and rulers with the corner handles. Press **Delete** to remove the selected shape.
- **Styling**: colour picker, stroke width (Thin, Normal, Thick, Marker) and solid fill for rectangles and circles. Your choices are remembered.
- **Undo** (button or **Ctrl/Cmd + Z**): works for drawing, moving, erasing and Clear All.
- **Save**: downloads a PNG screenshot of the visible page with your drawings on it. The toolbar is not included.
- **Draggable toolbar**: drag it by the top handle. Minimize it to the side tab to use the page normally, and click the tab to start drawing again.

## Install (Load unpacked)

1. Download the ZIP and extract it to a folder.
2. Open `chrome://extensions` and turn on **Developer mode** (top right).
3. Click **Load unpacked** and select the extracted folder (the one that contains `manifest.json`).
4. Pin WebDrawPro, open a web page and click the icon to show the toolbar. Click the icon again to hide or show it.

Browser pages (`chrome://`, the Chrome Web Store) cannot be drawn on. Drawings are kept in the page until you reload it. They do not scroll with the page.

## Permissions

- **activeTab**: gives access only to the tab where you click the icon. It is used to add the drawing layer and to take the screenshot for Save.
- **scripting**: injects the drawing toolbar into that tab.
- **storage**: remembers your colour, stroke width and fill setting, locally.

There is no "read all your data on all websites" permission, no server and no network requests.
