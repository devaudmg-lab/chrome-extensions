// ScrollShot Pro - Popup Script

document.addEventListener('DOMContentLoaded', () => {
  const startBtn = document.getElementById('start-capture-btn');
  const delaySelect = document.getElementById('delay-select');
  const errorMsg = document.getElementById('error-msg');
  const versionEl = document.getElementById('version');

  if (versionEl) versionEl.textContent = 'v' + chrome.runtime.getManifest().version;

  chrome.storage.local.get({ captureDelay: '0' }, (prefs) => {
    if (!chrome.runtime.lastError && prefs.captureDelay) {
      delaySelect.value = String(prefs.captureDelay);
    }
  });

  delaySelect.addEventListener('change', () => {
    chrome.storage.local.set({ captureDelay: delaySelect.value });
  });

  startBtn.addEventListener('click', () => {
    errorMsg.style.display = 'none';
    startBtn.disabled = true;
    chrome.runtime.sendMessage(
      { action: 'START_SELECTION_MODE', delay: parseInt(delaySelect.value, 10) || 0 },
      (response) => {
        startBtn.disabled = false;
        if (chrome.runtime.lastError || !response || !response.success) {
          errorMsg.textContent = (response && response.error) ||
            (chrome.runtime.lastError && chrome.runtime.lastError.message) ||
            'Could not start capture on this page.';
          errorMsg.style.display = 'block';
          return;
        }
        window.close(); // Close popup window
      }
    );
  });
});
