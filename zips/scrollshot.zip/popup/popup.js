// ScrollShot Pro - Popup Script

document.addEventListener('DOMContentLoaded', () => {
  const startBtn = document.getElementById('start-capture-btn');
  const fullBtn = document.getElementById('full-page-btn');
  const visibleBtn = document.getElementById('visible-btn');
  const saveAsCheck = document.getElementById('saveas-check');
  const delaySelect = document.getElementById('delay-select');
  const errorMsg = document.getElementById('error-msg');
  const versionEl = document.getElementById('version');
  const onboard = document.getElementById('onboard');
  const recentGrid = document.getElementById('recent-grid');
  const recentEmpty = document.getElementById('recent-empty');

  if (versionEl) versionEl.textContent = 'v' + chrome.runtime.getManifest().version;

  chrome.storage.local.get({ captureDelay: '0', onboarded: false, askSaveAs: true }, (prefs) => {
    if (chrome.runtime.lastError) return;
    if (prefs.captureDelay) delaySelect.value = String(prefs.captureDelay);
    if (!prefs.onboarded) onboard.style.display = 'block';
    saveAsCheck.checked = prefs.askSaveAs !== false;
  });

  saveAsCheck.addEventListener('change', () => {
    chrome.storage.local.set({ askSaveAs: saveAsCheck.checked });
  });

  const finishOnboarding = () => {
    onboard.style.display = 'none';
    chrome.storage.local.set({ onboarded: true });
  };
  document.getElementById('onboard-close').addEventListener('click', finishOnboarding);

  delaySelect.addEventListener('change', () => {
    chrome.storage.local.set({ captureDelay: delaySelect.value });
  });

  const openHistory = () => chrome.tabs.create({ url: chrome.runtime.getURL('history/history.html') });
  document.getElementById('history-btn').addEventListener('click', openHistory);

  // Last three captures as thumbnails (click opens the full history page)
  (async () => {
    try {
      const items = await window.ScrollShotHistory.list({ limit: 3 });
      recentEmpty.hidden = items.length > 0;
      items.forEach((item) => {
        const b = document.createElement('button');
        b.className = 'recent-item';
        b.title = `${item.title || item.host || 'Capture'} (${item.width} × ${item.height})`;
        b.setAttribute('aria-label', `Open capture history: ${b.title}`);
        if (item.thumb) {
          const img = document.createElement('img');
          img.src = item.thumb;
          img.alt = '';
          if (item.width && item.height / item.width < 0.55) img.className = 'wide'; // don't blow up short captures
          b.appendChild(img);
        }
        b.addEventListener('click', openHistory);
        recentGrid.appendChild(b);
      });
    } catch (e) {
      recentEmpty.textContent = 'Capture history is unavailable in this profile.';
      recentEmpty.hidden = false;
    }
  })();

  const buttons = [startBtn, fullBtn, visibleBtn];
  const start = (mode) => {
    errorMsg.style.display = 'none';
    buttons.forEach((b) => { b.disabled = true; });
    chrome.runtime.sendMessage(
      { action: 'START_SELECTION_MODE', delay: parseInt(delaySelect.value, 10) || 0, mode },
      (response) => {
        buttons.forEach((b) => { b.disabled = false; });
        if (chrome.runtime.lastError || !response || !response.success) {
          errorMsg.textContent = (response && response.error) ||
            (chrome.runtime.lastError && chrome.runtime.lastError.message) ||
            'Could not start capture on this page.';
          errorMsg.style.display = 'block';
          return;
        }
        finishOnboarding();
        window.close(); // Close popup window
      }
    );
  };

  startBtn.addEventListener('click', () => start('region'));
  fullBtn.addEventListener('click', () => start('full'));
  visibleBtn.addEventListener('click', () => start('visible'));
});
