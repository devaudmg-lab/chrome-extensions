// ScrollShot Pro - Capture history page

(function () {
  const History = window.ScrollShotHistory;
  const grid = document.getElementById('grid');
  const emptyEl = document.getElementById('empty');
  const errorEl = document.getElementById('error');
  const countEl = document.getElementById('count');
  const clearBtn = document.getElementById('clear-btn');
  const viewer = document.getElementById('viewer');
  const viewerImg = document.getElementById('viewer-img');
  const viewerTitle = document.getElementById('viewer-title');

  document.getElementById('max-items').textContent = History.MAX_ITEMS;

  let viewerUrl = null;

  function toast(text) {
    const t = document.createElement('div');
    t.className = 'toast';
    t.textContent = text;
    document.body.appendChild(t);
    setTimeout(() => t.remove(), 1800);
  }

  function formatDate(ts) {
    const d = new Date(ts);
    return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' }) + ', ' +
      d.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' });
  }

  function fileName(item) {
    const pad = (n) => String(n).padStart(2, '0');
    const d = new Date(item.createdAt);
    const host = (item.host || 'page').replace(/^www\./, '').replace(/[^a-z0-9.-]/gi, '_');
    return `scrollshot_${host}_${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}_${pad(d.getHours())}-${pad(d.getMinutes())}-${pad(d.getSeconds())}.png`;
  }

  async function download(item) {
    const full = await History.get(item.id);
    if (!full || !full.blob) return toast('This capture is no longer available');
    const url = URL.createObjectURL(full.blob);
    chrome.downloads.download({ url, filename: fileName(item), saveAs: true }, () => {
      void chrome.runtime.lastError;
      setTimeout(() => URL.revokeObjectURL(url), 60000);
    });
  }

  async function copy(item) {
    try {
      const full = await History.get(item.id);
      await navigator.clipboard.write([new ClipboardItem({ [full.blob.type || 'image/png']: full.blob })]);
      toast('Copied to clipboard');
    } catch (e) {
      toast('Copy was blocked - use Download instead');
    }
  }

  async function view(item) {
    const full = await History.get(item.id);
    if (!full || !full.blob) return;
    if (viewerUrl) URL.revokeObjectURL(viewerUrl);
    viewerUrl = URL.createObjectURL(full.blob);
    viewerImg.src = viewerUrl;
    viewerTitle.textContent = `${item.title || item.host || 'Capture'} · ${item.width} × ${item.height} px`;
    viewer.hidden = false;
  }

  function closeViewer() {
    viewer.hidden = true;
    viewerImg.removeAttribute('src');
    if (viewerUrl) URL.revokeObjectURL(viewerUrl);
    viewerUrl = null;
  }

  function button(label, cls, title, onClick) {
    const b = document.createElement('button');
    b.className = `btn ${cls}`;
    b.textContent = label;
    if (title) b.title = title;
    b.onclick = onClick;
    return b;
  }

  function renderCard(item) {
    const card = document.createElement('article');
    card.className = 'card';

    const thumb = document.createElement('button');
    thumb.className = 'thumb';
    thumb.title = 'View full size';
    if (item.thumb) {
      const img = document.createElement('img');
      img.src = item.thumb;
      img.alt = '';
      // Short, wide captures (a toolbar, one code line) would be blown up by "cover"
      if (item.width && item.height / item.width < 0.55) img.className = 'wide';
      thumb.appendChild(img);
    }
    if (item.edited) {
      const badge = document.createElement('span');
      badge.className = 'badge';
      badge.textContent = 'Edited';
      thumb.appendChild(badge);
    }
    thumb.onclick = () => view(item);

    const meta = document.createElement('div');
    meta.className = 'meta';
    const title = document.createElement('div');
    title.className = 'title';
    title.textContent = item.title || item.host || 'Untitled page';
    title.title = item.url || '';
    const details = document.createElement('div');
    details.className = 'details';
    details.textContent = [item.host, formatDate(item.createdAt), `${item.width} × ${item.height}`].filter(Boolean).join(' · ');
    meta.append(title, details);

    const row = document.createElement('div');
    row.className = 'row';
    row.append(
      button('⬇️ Download', 'btn-primary', 'Download PNG', () => download(item)),
      button('📋 Copy', '', 'Copy to clipboard', () => copy(item)),
      button('🗑️', 'btn-icon', 'Delete', async () => {
        await History.remove(item.id);
        load();
      })
    );

    card.append(thumb, meta, row);
    return card;
  }

  async function load() {
    try {
      const items = await History.list();
      grid.replaceChildren(...items.map(renderCard));
      emptyEl.hidden = items.length > 0;
      clearBtn.hidden = items.length === 0;
      countEl.textContent = items.length ? `${items.length} capture${items.length === 1 ? '' : 's'}` : '';
      errorEl.hidden = true;
    } catch (err) {
      grid.replaceChildren();
      emptyEl.hidden = true;
      errorEl.hidden = false;
      document.getElementById('error-text').textContent = `Chrome couldn't open the history database (${err && err.message ? err.message : 'unknown error'}).`;
    }
  }

  clearBtn.onclick = async () => {
    if (!confirm('Delete all saved captures? Files you already downloaded are not affected.')) return;
    await History.clear();
    load();
  };

  document.getElementById('viewer-close').onclick = closeViewer;
  viewer.addEventListener('click', (e) => {
    if (e.target === viewer || e.target.classList.contains('viewer-body')) closeViewer();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && !viewer.hidden) closeViewer();
  });

  // Refresh when a new capture is finished while this page is open
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) load();
  });

  load();
})();
