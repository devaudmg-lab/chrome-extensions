// ScrollShot Pro - Offscreen Canvas Stitcher Engine
//
// Every frame is a screenshot of the viewport taken at a known scroll offset from where
// the capture started. The frame's rows are placed at that absolute offset, so rounding
// never accumulates (fractional devicePixelRatio, fractional scroll positions) and a
// skipped or partial frame cannot shift everything below it.

let canvas = null;
let ctx = null;
let currentRegion = null;
let pageInfo = null;
let devScale = 1;      // device pixels per CSS pixel, measured from the first screenshot
let outScale = 1;      // < 1 when the capture is too big for one Chrome canvas
let targetRows = 0;    // full capture height in device pixels
let stitchedRows = 0;  // device rows already on the canvas
let cropW = 0;
let isInitialized = false;

// Chrome refuses to encode canvases taller than 32767px or larger than ~268M pixels,
// so very long captures are scaled down to fit instead of being cut off.
const MAX_CANVAS_HEIGHT = 32000;
const MAX_CANVAS_AREA = 250000000;

// Finished captures, kept briefly in memory in case the history database is unavailable
const recent = new Map();
function remember(id, entry) {
  recent.set(id, entry);
  while (recent.size > 3) recent.delete(recent.keys().next().value);
}

// Frames decode asynchronously; process messages strictly in arrival order so
// slices are appended in sequence and export waits for the last frame.
let taskQueue = Promise.resolve();
function enqueue(task) {
  const run = taskQueue.then(task);
  taskQueue = run.catch((err) => console.error('Stitcher error:', err));
  return run;
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'OFFSCREEN_INIT_CANVAS') {
    enqueue(() => initCanvas(msg.region, msg.page));
  }
  else if (msg.action === 'OFFSCREEN_ADD_FRAME') {
    enqueue(() => addFrame(msg));
  }
  else if (msg.action === 'OFFSCREEN_EXPORT') {
    enqueue(() => exportStitchedCanvas());
  }
  else if (msg.action === 'OFFSCREEN_GET_CHUNK') {
    const entry = recent.get(msg.id);
    if (!entry) return false; // let the service worker answer from the history database
    ScrollShotTransfer.blobChunk(entry.blob, msg.index).then(
      (data) => sendResponse({ success: true, data }),
      (err) => sendResponse({ success: false, error: err.message })
    );
    return true;
  }
  return false;
});

function initCanvas(region, page) {
  canvas = document.getElementById('offscreen-canvas');
  ctx = canvas.getContext('2d');
  currentRegion = region;
  pageInfo = page || null;
  stitchedRows = 0;
  targetRows = 0;
  outScale = 1;
  isInitialized = true;
}

function decode(dataUrl) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('Could not decode a captured frame'));
    img.src = dataUrl;
  });
}

async function addFrame(msg) {
  const region = msg.region;
  if (!isInitialized || !canvas) initCanvas(region, pageInfo);
  const img = await decode(msg.dataUrl);

  // captureVisibleTab is not always viewport * devicePixelRatio (zoom, display
  // scaling, headless windows), so derive the real scale from the image itself.
  // innerWidth is a rounded integer, so prefer the exact devicePixelRatio when the two agree.
  const measured = (region.viewportWidth > 0 && img.width > 0) ? img.width / region.viewportWidth : 0;
  const dpr = msg.dpr || region.dpr || 1;
  const dev = !measured || Math.abs(measured - dpr) <= dpr * 0.01 ? dpr : measured;

  const cropX = Math.max(0, Math.min(img.width - 1, Math.round(region.x * dev)));
  const cropY = Math.max(0, Math.min(img.height - 1, Math.round(region.y * dev)));
  const frameW = Math.max(1, Math.min(img.width - cropX, Math.round(region.width * dev)));
  const cropH = Math.max(1, Math.min(img.height - cropY, Math.round(region.height * dev)));

  if (msg.isFirstFrame || targetRows === 0) {
    devScale = dev;
    cropW = frameW;
    targetRows = Math.max(cropH, Math.round((region.targetHeight || region.height) * dev));
    outScale = Math.min(1, MAX_CANVAS_HEIGHT / targetRows, Math.sqrt(MAX_CANVAS_AREA / (cropW * targetRows)));
    canvas.width = Math.max(1, Math.round(cropW * outScale));
    canvas.height = Math.max(1, Math.round(targetRows * outScale));
    ctx = canvas.getContext('2d');
    ctx.imageSmoothingQuality = 'high';
    stitchedRows = 0;
  }

  // Rows of the full capture this frame covers, from its absolute scroll offset
  const frameTop = msg.isFirstFrame ? 0 : Math.max(0, Math.round((msg.scrollOffset || 0) * devScale));
  const start = Math.max(stitchedRows, frameTop);
  const end = Math.min(frameTop + cropH, targetRows);

  if (end > start) {
    const dTop = Math.round(start * outScale);
    const dBottom = Math.round(end * outScale);
    if (dBottom > dTop) {
      ctx.drawImage(img, cropX, cropY + (start - frameTop), Math.min(frameW, cropW), end - start,
        0, dTop, Math.round(Math.min(frameW, cropW) * outScale), dBottom - dTop);
    }
    stitchedRows = end;
  }

  if (stitchedRows >= targetRows) {
    chrome.runtime.sendMessage({ action: 'TARGET_HEIGHT_REACHED' }).catch(() => {});
  }
}

function toBlob(source, type, quality) {
  return new Promise((resolve, reject) => {
    source.toBlob((b) => (b ? resolve(b) : reject(new Error('Chrome could not encode the image'))), type, quality);
  });
}

async function exportStitchedCanvas() {
  if (!canvas || stitchedRows === 0) {
    chrome.runtime.sendMessage({ action: 'STITCH_FAILED', error: 'Nothing was captured.' }).catch(() => {});
    return;
  }

  // The capture can end early (bottom of the page reached, Finish pressed): trim the unused rows
  let out = canvas;
  const usedHeight = Math.max(1, Math.min(canvas.height, Math.round(stitchedRows * outScale)));
  if (usedHeight < canvas.height) {
    out = document.createElement('canvas');
    out.width = canvas.width;
    out.height = usedHeight;
    out.getContext('2d').drawImage(canvas, 0, 0, canvas.width, usedHeight, 0, 0, canvas.width, usedHeight);
  }

  const blob = await toBlob(out, 'image/png');
  const id = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  const thumb = makeThumbnail(out);
  remember(id, { blob });

  // Release the big canvas memory right away
  const width = out.width;
  const height = out.height;
  canvas.width = 1;
  canvas.height = 1;
  if (out !== canvas) {
    out.width = 0;
    out.height = 0;
  }
  isInitialized = false;

  const page = pageInfo || {};
  try {
    await self.ScrollShotHistory.add({
      id, title: page.title, url: page.url, host: page.host, width, height, thumb, blob
    });
  } catch (err) {
    // History is a convenience: a full disk must never break the capture
    console.warn('Could not save capture to history:', err && err.message);
  }

  chrome.runtime.sendMessage({
    action: 'STITCH_COMPLETE',
    id,
    width,
    height,
    size: blob.size,
    scale: outScale < 0.999 ? outScale : 1
  }).catch(() => {});
}

// Small JPEG of the top of the capture for the history list (max 360 x 270)
function makeThumbnail(source) {
  try {
    const tw = 360;
    const th = 270;
    const scale = tw / source.width;
    const srcH = Math.min(source.height, Math.round(th / scale));
    const t = document.createElement('canvas');
    t.width = tw;
    t.height = Math.max(1, Math.round(srcH * scale));
    const tctx = t.getContext('2d');
    tctx.fillStyle = '#FFFFFF';
    tctx.fillRect(0, 0, t.width, t.height);
    tctx.imageSmoothingQuality = 'high';
    tctx.drawImage(source, 0, 0, source.width, srcH, 0, 0, t.width, t.height);
    return t.toDataURL('image/jpeg', 0.8);
  } catch (e) {
    return '';
  }
}
