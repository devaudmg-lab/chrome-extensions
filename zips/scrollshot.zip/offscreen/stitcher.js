// ScrollShot Pro - Offscreen Canvas Stitcher Engine

let canvas = null;
let ctx = null;
let currentRegion = null;
let currentDPR = 1;
let totalCanvasHeight = 0;
let isInitialized = false;

// Chrome refuses to encode canvases taller than 32767px or larger than ~268M pixels
// (toDataURL returns "data:,"), so stop appending before we hit that limit.
const MAX_CANVAS_HEIGHT = 32000;
const MAX_CANVAS_AREA = 250000000;

// Frames decode asynchronously; process messages strictly in arrival order so
// slices are appended in sequence and export waits for the last frame.
let taskQueue = Promise.resolve();
function enqueue(task) {
  taskQueue = taskQueue.then(task).catch((err) => console.error('Stitcher error:', err));
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'OFFSCREEN_INIT_CANVAS') {
    enqueue(() => initCanvas(msg.region, msg.dpr));
  }
  else if (msg.action === 'OFFSCREEN_ADD_FRAME') {
    enqueue(() => addFrame(msg.dataUrl, msg.region, msg.scrollDelta, msg.dpr, msg.isFirstFrame));
  }
  else if (msg.action === 'OFFSCREEN_EXPORT') {
    enqueue(() => exportStitchedCanvas());
  }
});

function initCanvas(region, dpr) {
  canvas = document.getElementById('offscreen-canvas');
  ctx = canvas.getContext('2d', { willReadFrequently: true });

  currentRegion = region;
  currentDPR = dpr || 1;

  const targetWidth = Math.round(region.width * currentDPR);
  const targetHeight = Math.round(region.height * currentDPR);

  canvas.width = Math.max(10, targetWidth);
  canvas.height = Math.max(10, targetHeight);
  totalCanvasHeight = 0;
  isInitialized = true;
}

function addFrame(dataUrl, region, scrollDelta, dpr, isFirstFrame) {
  if (!isInitialized || !canvas) {
    initCanvas(region, dpr);
  }

  return new Promise((resolve) => {
  const img = new Image();
  img.onerror = () => resolve();
  img.onload = () => {
    try {
    // captureVisibleTab is not always viewport * devicePixelRatio (zoom, display
    // scaling, headless windows), so derive the real scale from the image itself.
    const dprVal = (region.viewportWidth > 0 && img.width > 0)
      ? img.width / region.viewportWidth
      : (dpr || currentDPR || 1);

    // Clamp crop bounds strictly within viewport image dimensions
    const cropX = Math.max(0, Math.min(img.width - 10, Math.round(region.x * dprVal)));
    const cropY = Math.max(0, Math.min(img.height - 10, Math.round(region.y * dprVal)));
    const cropW = Math.max(10, Math.min(img.width - cropX, Math.round(region.width * dprVal)));
    const cropH = Math.max(10, Math.min(img.height - cropY, Math.round(region.height * dprVal)));

    // Create temp canvas for current frame crop
    const frameCanvas = document.createElement('canvas');
    frameCanvas.width = cropW;
    frameCanvas.height = cropH;
    const frameCtx = frameCanvas.getContext('2d', { willReadFrequently: true });
    frameCtx.drawImage(img, cropX, cropY, cropW, cropH, 0, 0, cropW, cropH);

    if (isFirstFrame || totalCanvasHeight === 0) {
      // Draw first frame
      canvas.width = cropW;
      canvas.height = cropH;
      ctx.drawImage(frameCanvas, 0, 0);
      totalCanvasHeight = cropH;
      return;
    }

    // Calculate slice height from scroll delta
    const deltaPx = Math.round(Math.abs(scrollDelta) * dprVal);
    let sliceHeight = Math.min(cropH, Math.max(5, deltaPx));

    // Cap total canvas height strictly to user's selected targetHeight (e.g. 2085px native)
    const browserMaxHeight = Math.min(MAX_CANVAS_HEIGHT, Math.floor(MAX_CANVAS_AREA / Math.max(1, cropW)));
    const targetMaxHeight = Math.min(browserMaxHeight, Math.round((region.targetHeight || region.height) * dprVal));
    let isTargetReached = false;

    if (totalCanvasHeight + sliceHeight >= targetMaxHeight) {
      sliceHeight = Math.max(0, targetMaxHeight - totalCanvasHeight);
      isTargetReached = true;
    }

    const sliceSourceY = cropH - sliceHeight;

    if (sliceHeight <= 0) {
      chrome.runtime.sendMessage({ action: 'TARGET_HEIGHT_REACHED' });
      return;
    }

    // Backup existing canvas
    const tempCanvas = document.createElement('canvas');
    tempCanvas.width = canvas.width;
    tempCanvas.height = canvas.height;
    const tempCtx = tempCanvas.getContext('2d');
    tempCtx.drawImage(canvas, 0, 0);

    // Expand main canvas height to append new slice
    const newTotalHeight = totalCanvasHeight + sliceHeight;
    canvas.height = newTotalHeight;

    // Restore previous canvas content
    ctx.drawImage(tempCanvas, 0, 0);

    // Append new slice from bottom of new frame
    ctx.drawImage(
      frameCanvas,
      0, sliceSourceY, cropW, sliceHeight,
      0, totalCanvasHeight, cropW, sliceHeight
    );

    totalCanvasHeight = newTotalHeight;

    if (isTargetReached || totalCanvasHeight >= targetMaxHeight) {
      chrome.runtime.sendMessage({ action: 'TARGET_HEIGHT_REACHED' });
    }
    } finally {
      resolve();
    }
  };
  img.src = dataUrl;
  });
}

function exportStitchedCanvas() {
  if (!canvas || totalCanvasHeight === 0) return;

  const dataUrl = canvas.toDataURL('image/png');
  chrome.runtime.sendMessage({
    action: 'STITCH_COMPLETE',
    dataUrl: dataUrl,
    width: canvas.width,
    height: canvas.height,
    thumb: makeThumbnail(canvas)
  });
}

// Small JPEG of the top of the capture for the history list (max 360 x 270)
function makeThumbnail(source) {
  try {
    const tw = 360;
    const th = 270;
    const scale = tw / source.width;
    const srcH = Math.min(source.height, Math.round(th / scale));
    const t = document.createElement('canvas');
    t.width = tw;
    t.height = Math.max(1, Math.round(srcH * scale));
    const tctx = t.getContext('2d');
    tctx.fillStyle = '#FFFFFF';
    tctx.fillRect(0, 0, t.width, t.height);
    tctx.imageSmoothingQuality = 'high';
    tctx.drawImage(source, 0, 0, source.width, srcH, 0, 0, t.width, t.height);
    return t.toDataURL('image/jpeg', 0.8);
  } catch (e) {
    return '';
  }
}
