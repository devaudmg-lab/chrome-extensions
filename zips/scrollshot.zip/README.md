# ScrollShot Pro

Region-locked scrolling screenshots for Chrome. Draw a box around just the part of a page you want, such as a chat thread, a code block or a table, and ScrollShot scrolls and stitches it into one tall image. The navbars, ads and sidebars around it stay out.

## Features
- **Region + scroll capture**: select a region and ScrollShot auto-scrolls and stitches it into one image.
- **Click a scroll area**: in selection mode, scrollable panels (chat threads, code viewers, sidebars) light up green when you hover them. Click one and ScrollShot captures its whole content, top to bottom.
- **Full page in one click**: the **Full Page** button (or `Alt+Shift+F`) captures the entire page. Fixed and sticky headers, sidebars and chat bubbles appear once, at the top, instead of repeating down the image. On web apps whose window doesn't scroll, it captures the main scroll area instead.
- **Edit before sharing**: the preview has **Crop**, **Blur** (pixelate private details), **Box** (red outline) and **Highlight** (yellow marker) tools, plus **Undo**. Copy and Download use the edited image.
- **Capture history**: your last 25 captures are kept on your computer (IndexedDB). The popup shows the latest three; **View all** opens a history page where you can view, download, copy or delete them.
- **Tall selections**: while drawing or resizing, hold the pointer at the bottom edge of the window and the page scrolls so the box can grow past the screen.
- **Nested scroll areas**: it scrolls the inner container (chat panels, code viewers) when that is what sits under your selection.
- **Sticky header masking**: fixed and sticky headers are hidden during capture so they don't repeat in the image.
- **Delayed start**: wait 3, 5 or 10 seconds before capturing, so you can open a menu or hover state first.
- **Export**: copy to the clipboard (PNG), or download as PNG, JPG or WebP. Files are named automatically, for example `scrollshot_github.com_2026-10-26_14-05-09.png`.
- **First-run guide**: the popup explains the two capture modes the first time, and selection mode shows a short hint at the top of the page.

## Install (Load unpacked)
1. Download and unzip the ZIP.
2. Open `chrome://extensions` and turn on **Developer mode** (top right).
3. Click **Load unpacked** and select the unzipped folder (the one that contains `manifest.json`).
4. Pin ScrollShot Pro from the puzzle-piece menu.

## How to use
1. Click the toolbar icon and press **Region Scroll Capture** (`Ctrl+Shift+S`), or **Full Page** (`Alt+Shift+F`).
2. Region capture: drag a box, or click a highlighted scroll area. Adjust the box with the handles if needed, and hold at the bottom edge to make it taller than the screen. Press **Enter** (or **Start Capture**).
3. ScrollShot scrolls and captures, then shows a preview.
4. Optionally crop, blur, box or highlight parts of the image.
5. Copy or download the result. It's also saved in your capture history.

## Keyboard shortcuts
| Keys | Where | Action |
|---|---|---|
| `Ctrl+Shift+S` (`Cmd+Shift+S` on Mac) | Anywhere | Start region capture |
| `Alt+Shift+F` | Anywhere | Capture the full page |
| `Enter` | Selection | Start capturing the selected box |
| `Esc` | Selection / capture | Cancel |
| `C` / `B` / `R` / `H` | Preview | Crop / Blur / Box / Highlight tool |
| `Ctrl+Z` (`Cmd+Z`) | Preview | Undo the last edit |
| `Esc` | Preview | Drop the current tool, press again to close |

You can change the two global shortcuts at `chrome://extensions/shortcuts`.

Chrome does not allow extensions on `chrome://` pages, the Chrome Web Store or the built-in PDF viewer.

## Permissions
| Permission | Why |
|---|---|
| `activeTab` | Capture and inject the selection overlay into the tab you're on, and only after you click the icon or use the shortcut. No access to all sites. |
| `scripting` | Inject the selection overlay and capture toolbar into that tab. |
| `offscreen` | Stitch the frames on a hidden canvas. |
| `downloads` | Save the finished image. |
| `storage` | Remember your preferred export format, start delay and whether you've seen the welcome tips. |

All processing happens locally in your browser. Nothing is uploaded. Capture history lives in the extension's own IndexedDB on your computer (last 25 captures); clear it any time from the history page. No new permissions were needed for it.
