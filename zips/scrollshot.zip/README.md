# ScrollShot Pro

Region-locked scrolling screenshots for Chrome. Draw a box around just the part of a page you want, such as a chat thread, a code block or a table, and ScrollShot scrolls and stitches it into one tall image. The navbars, ads and sidebars around it stay out.

## Features
- **Region + scroll capture**: select a region and ScrollShot auto-scrolls and stitches it into one image.
- **Click a scroll area**: in selection mode, scrollable panels (chat threads, code viewers, sidebars) light up green when you hover them. Click one and ScrollShot captures its whole content, top to bottom.
- **Full page in one click**: the **Full Page** button (or `Alt+Shift+F`) captures the entire page. Fixed headers and chat bubbles appear once instead of repeating down the image, and sticky headings (table headers, section titles) stay at their own place in the content. On web apps whose window doesn't scroll, it captures the main scroll area instead.
- **Visible area**: the **Visible Area** button (or `Alt+Shift+V`) grabs exactly what is on screen, in one frame.
- **Very long pages**: pages taller than Chrome's largest image (32,000 px) are scaled down to fit, so nothing is cut off; the preview tells you when that happened.
- **Lazy-loaded images**: before each frame ScrollShot waits (briefly) for images that just scrolled into view, so they aren't blank in the result.
- **Edit before sharing**: the preview has **Crop**, **Blur** (pixelate private details), **Box** (red outline), **Arrow**, **Highlight** (yellow marker) and **Text** (red label) tools, plus **Undo**. Copy and Download use the edited image.
- **Capture history**: your last 25 captures are kept on your computer (IndexedDB). The popup shows the latest three; **View all** opens a history page where you can view, download, copy or delete them.
- **Tall selections**: while drawing or resizing, hold the pointer at the bottom edge of the window and the page scrolls so the box can grow past the screen.
- **Nested scroll areas**: it scrolls the inner container (chat panels, code viewers) when that is what sits under your selection.
- **Sticky header masking**: fixed and sticky headers are hidden during capture so they don't repeat in the image.
- **Delayed start**: wait 3, 5 or 10 seconds before capturing, so you can open a menu or hover state first.
- **Export**: copy to the clipboard (PNG), or download as PNG, JPG, WebP or a multi-page A4 **PDF**. Files are named automatically, for example `scrollshot_github.com_2026-10-26_14-05-09.png`. Untick **Ask where to save each download** in the popup to save straight to your Downloads folder.
- **Safe when you switch tabs**: if you switch to another tab during a capture, ScrollShot pauses and continues when you come back. It never stitches another tab into your image.
- **First-run guide**: the popup explains the two capture modes the first time, and selection mode shows a short hint at the top of the page.

## Install (Load unpacked)
1. Download and unzip the ZIP.
2. Open `chrome://extensions` and turn on **Developer mode** (top right).
3. Click **Load unpacked** and select the unzipped folder (the one that contains `manifest.json`).
4. Pin ScrollShot Pro from the puzzle-piece menu.

## How to use
1. Click the toolbar icon and press **Region Scroll Capture** (`Ctrl+Shift+S`), **Full Page** (`Alt+Shift+F`) or **Visible Area** (`Alt+Shift+V`).
2. Region capture: drag a box, or click a highlighted scroll area. Adjust the box with the handles if needed, and hold at the bottom edge to make it taller than the screen. Press **Enter** (or **Start Capture**).
3. ScrollShot scrolls and captures, then shows a preview.
4. Optionally crop, blur, box, highlight, add arrows or text labels.
5. Copy or download the result. It's also saved in your capture history.

## Keyboard shortcuts
| Keys | Where | Action |
|---|---|---|
| `Ctrl+Shift+S` (`Cmd+Shift+S` on Mac) | Anywhere | Start region capture |
| `Alt+Shift+F` | Anywhere | Capture the full page |
| `Alt+Shift+V` | Anywhere | Capture the visible area |
| `Enter` | Selection | Start capturing the selected box |
| `Esc` | Countdown / selection / capture | Cancel |
| `C` / `B` / `R` / `A` / `H` / `T` | Preview | Crop / Blur / Box / Arrow / Highlight / Text tool |
| `Enter` / `Esc` | Text label | Add the label / discard it |
| `Ctrl+Z` (`Cmd+Z`) | Preview | Undo the last edit |
| `Esc` | Preview | Drop the current tool, press again to close |

You can change the global shortcuts at `chrome://extensions/shortcuts`. If a shortcut can't run on the current page, the toolbar icon shows a red `!` for a few seconds (hover it for the reason).

Chrome does not allow extensions on `chrome://` pages, the Chrome Web Store or the built-in PDF viewer. For local `file://` pages, turn on **Allow access to file URLs** for ScrollShot in `chrome://extensions`.

## Permissions
| Permission | Why |
|---|---|
| `activeTab` | Capture and inject the selection overlay into the tab you're on, and only after you click the icon or use the shortcut. No access to all sites. |
| `scripting` | Inject the selection overlay and capture toolbar into that tab. |
| `offscreen` | Stitch the frames on a hidden canvas. |
| `downloads` | Save the finished image or PDF. |
| `storage` | Remember your preferred export format, start delay, the "ask where to save" choice and whether you've seen the welcome tips. Session storage remembers which tab is being captured if Chrome pauses the background worker. |

No host permissions and no new permissions in 1.3.0. All processing happens locally in your browser. Nothing is uploaded. Capture history lives in the extension's own IndexedDB on your computer (last 25 captures, at most about 400 MB); clear it any time from the history page.

## Privacy on the page you capture
The captured image can include things the page itself can't read (for example cross-origin iframes), so it never enters the page's reach: the preview and editor live in a closed shadow root, the image is only held in the extension's isolated script context (never as a `data:` or `blob:` URL in the page's DOM), and the capture toolbar is closed to page scripts too.
