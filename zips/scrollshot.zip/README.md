# ScrollShot Pro

Region-locked scrolling screenshots for Chrome. Draw a box around just the part of a page you want, such as a chat thread, a code block or a table, and ScrollShot scrolls and stitches it into one tall image. The navbars, ads and sidebars around it stay out.

## Features
- **Region + scroll capture**: select a region and ScrollShot auto-scrolls and stitches it into one image.
- **Tall selections**: while drawing or resizing, hold the pointer at the bottom edge of the window and the page scrolls so the box can grow past the screen.
- **Nested scroll areas**: it scrolls the inner container (chat panels, code viewers) when that is what sits under your selection.
- **Sticky header masking**: fixed and sticky headers are hidden during capture so they don't repeat in the image.
- **Delayed start**: wait 3, 5 or 10 seconds before selecting, so you can open a menu or hover state first.
- **Export**: copy to the clipboard (PNG), or download as PNG, JPG or WebP. Files are named automatically, for example `scrollshot_github.com_2026-10-26_14-05-09.png`.
- **Shortcut**: `Ctrl+Shift+S` (`Cmd+Shift+S` on Mac). Press `Esc` to cancel at any time.

## Install (Load unpacked)
1. Download and unzip the ZIP.
2. Open `chrome://extensions` and turn on **Developer mode** (top right).
3. Click **Load unpacked** and select the unzipped folder (the one that contains `manifest.json`).
4. Pin ScrollShot Pro from the puzzle-piece menu.

## How to use
1. Click the toolbar icon and press **Start Region Scroll Capture**, or press `Ctrl+Shift+S`.
2. Drag a box. Adjust it with the handles if needed. Hold at the bottom edge to make it taller than the screen.
3. Press **Enter** (or **Start Capture**). ScrollShot scrolls and captures, then shows a preview.
4. Copy or download the result.

Chrome does not allow extensions on `chrome://` pages, the Chrome Web Store or the built-in PDF viewer.

## Permissions
| Permission | Why |
|---|---|
| `activeTab` | Capture and inject the selection overlay into the tab you're on, and only after you click the icon or use the shortcut. No access to all sites. |
| `scripting` | Inject the selection overlay and capture toolbar into that tab. |
| `offscreen` | Stitch the frames on a hidden canvas. |
| `downloads` | Save the finished image. |
| `storage` | Remember your preferred export format and start delay. |

All processing happens locally in your browser. Nothing is uploaded.
