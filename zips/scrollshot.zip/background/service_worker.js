// ScrollShot Pro - Service Worker (Background Script)

let isOffscreenCreating = null; // Promise while an offscreen document is being created
let lastCaptureTime = 0;
const MIN_CAPTURE_INTERVAL_MS = 250; // Allows up to 4 captures/sec while safely managing quota
let activeCaptureTabId = null;
let activeCaptureWindowId = null;

async function captureVisibleTabSafe(windowId = null, retryCount = 0) {
  const now = Date.now();
  const timeSinceLast = now - lastCaptureTime;

  if (timeSinceLast < MIN_CAPTURE_INTERVAL_MS) {
    const delay = MIN_CAPTURE_INTERVAL_MS - timeSinceLast;
    await new Promise(resolve => setTimeout(resolve, delay));
  }

  try {
    lastCaptureTime = Date.now();
    return await chrome.tabs.captureVisibleTab(windowId, { format: 'png' });
  } catch (err) {
    if (err.message && err.message.includes('MAX_CAPTURE_VISIBLE_TAB_CALLS_PER_SECOND') && retryCount < 3) {
      console.warn(`Quota hit, retrying in 650ms (attempt ${retryCount + 1})...`);
      await new Promise(resolve => setTimeout(resolve, 650));
      return await captureVisibleTabSafe(windowId, retryCount + 1);
    }
    throw err;
  }
}

async function setupOffscreenDocument() {
  const offscreenUrl = chrome.runtime.getURL('offscreen/stitcher.html');
  const existingContexts = await chrome.runtime.getContexts({
    contextTypes: ['OFFSCREEN_DOCUMENT'],
    documentUrls: [offscreenUrl]
  });

  if (existingContexts.length > 0) {
    return;
  }

  // Concurrent callers must wait for the in-flight creation, otherwise their
  // messages are sent before the stitcher exists and get dropped.
  if (isOffscreenCreating) {
    await isOffscreenCreating;
    return;
  }
  isOffscreenCreating = chrome.offscreen.createDocument({
    url: offscreenUrl,
    reasons: ['BLOBS'],
    justification: 'Stitching screenshot frames incrementally on HTML5 Canvas'
  });

  try {
    await isOffscreenCreating;
  } catch (err) {
    console.error('Error creating offscreen document:', err);
  } finally {
    isOffscreenCreating = null;
  }
}

async function closeOffscreenDocument() {
  const offscreenUrl = chrome.runtime.getURL('offscreen/stitcher.html');
  const existingContexts = await chrome.runtime.getContexts({
    contextTypes: ['OFFSCREEN_DOCUMENT'],
    documentUrls: [offscreenUrl]
  });

  if (existingContexts.length > 0) {
    await chrome.offscreen.closeDocument();
  }
}

// Trigger selection mode on active tab (optionally after a countdown delay in seconds)
async function activateSelectionMode(tabId, delay = 0) {
  try {
    activeCaptureTabId = tabId;
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ['content/overlay.js', 'content/scroll_inspector.js', 'content/toolbar.js']
    });

    await chrome.scripting.insertCSS({
      target: { tabId },
      files: ['content/overlay.css']
    });

    await chrome.tabs.sendMessage(tabId, { action: 'INIT_OVERLAY', delay: delay || 0 });
    return { success: true };
  } catch (err) {
    console.warn('Failed to inject selection scripts:', err);
    return {
      success: false,
      error: 'ScrollShot cannot run on this page (browser pages, the Chrome Web Store and PDF viewers are blocked by Chrome).'
    };
  }
}

// Shortcut command listener
chrome.commands.onCommand.addListener(async (command) => {
  if (command === 'toggle-capture') {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab && tab.id) {
      await activateSelectionMode(tab.id);
    }
  }
});

// Message hub
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    try {
      if (message.action === 'START_SELECTION_MODE') {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tab || !tab.id) {
          sendResponse({ success: false, error: 'No active tab found.' });
          return;
        }
        sendResponse(await activateSelectionMode(tab.id, message.delay));
      }

      else if (message.action === 'INIT_STITCHER') {
        if (sender.tab) {
          activeCaptureTabId = sender.tab.id;
          activeCaptureWindowId = sender.tab.windowId;
        }
        await setupOffscreenDocument();
        chrome.runtime.sendMessage({
          action: 'OFFSCREEN_INIT_CANVAS',
          region: message.region,
          dpr: message.dpr
        });
        sendResponse({ success: true });
      }

      else if (message.action === 'CAPTURE_FRAME_REQUEST') {
        if (sender.tab) {
          activeCaptureTabId = sender.tab.id;
          activeCaptureWindowId = sender.tab.windowId;
        }
        const winId = activeCaptureWindowId || (sender.tab ? sender.tab.windowId : null);

        const dataUrl = await captureVisibleTabSafe(winId);

        await setupOffscreenDocument();

        // Forward captured viewport screenshot to Offscreen Stitcher
        chrome.runtime.sendMessage({
          action: 'OFFSCREEN_ADD_FRAME',
          dataUrl,
          region: message.region,
          scrollDelta: message.scrollDelta,
          dpr: message.dpr,
          isFirstFrame: message.isFirstFrame
        });
        sendResponse({ success: true });
      }

      else if (message.action === 'FINISH_CAPTURE') {
        await setupOffscreenDocument();
        chrome.runtime.sendMessage({ action: 'OFFSCREEN_EXPORT' });
        sendResponse({ success: true });
      }

      else if (message.action === 'STITCH_COMPLETE') {
        const targetTabId = (sender.tab && sender.tab.id) || activeCaptureTabId;
        if (targetTabId) {
          chrome.tabs.sendMessage(targetTabId, {
            action: 'SHOW_PREVIEW',
            dataUrl: message.dataUrl,
            width: message.width,
            height: message.height
          }).catch(async () => {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            if (tab && tab.id) {
              chrome.tabs.sendMessage(tab.id, {
                action: 'SHOW_PREVIEW',
                dataUrl: message.dataUrl,
                width: message.width,
                height: message.height
              }).catch((e) => console.warn('Could not deliver preview:', e));
            }
          });
        } else {
          const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
          if (tab && tab.id) {
            chrome.tabs.sendMessage(tab.id, {
              action: 'SHOW_PREVIEW',
              dataUrl: message.dataUrl,
              width: message.width,
              height: message.height
            }).catch((e) => console.warn('Could not deliver preview:', e));
          }
        }
        sendResponse({ success: true });
      }

      else if (message.action === 'TARGET_HEIGHT_REACHED') {
        const targetTabId = (sender.tab && sender.tab.id) || activeCaptureTabId;
        if (targetTabId) {
          chrome.tabs.sendMessage(targetTabId, { action: 'STOP_AUTO_SCROLL' }).catch(() => {});
        } else {
          const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
          if (tab && tab.id) {
            chrome.tabs.sendMessage(tab.id, { action: 'STOP_AUTO_SCROLL' }).catch(() => {});
          }
        }
        sendResponse({ success: true });
      }

      else if (message.action === 'CANCEL_CAPTURE') {
        await closeOffscreenDocument();
        sendResponse({ success: true });
      }

      else if (message.action === 'DOWNLOAD_IMAGE') {
        const downloadId = await chrome.downloads.download({
          url: message.dataUrl,
          filename: message.filename || `scrollshot_${Date.now()}.png`,
          saveAs: true
        });
        sendResponse({ success: true, downloadId });
      }
    } catch (err) {
      console.error('Service worker message error:', err);
      sendResponse({ success: false, error: err.message });
    }
  })();
  return true; // async sendResponse
});
