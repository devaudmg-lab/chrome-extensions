// ScrollShot Pro - Service Worker (Background Script)

importScripts('../lib/history_db.js', '../lib/transfer.js');

let isOffscreenCreating = null; // Promise while an offscreen document is being created
let lastCaptureTime = 0;
const MIN_CAPTURE_INTERVAL_MS = 510; // Chrome allows 2 captureVisibleTab calls per second
let wasInactive = false; // the capture tab was in the background at the last frame request
const OFFSCREEN_URL = chrome.runtime.getURL('offscreen/stitcher.html');

// The tab being captured. Kept in session storage as well, because the service worker
// can be stopped between two frames when the user scrolls by hand.
let session = null; // { tabId, windowId, page: { title, url, host } }
async function getSession() {
  if (session) return session;
  try {
    const stored = await chrome.storage.session.get('capture');
    session = stored.capture || null;
  } catch (e) { /* storage.session unavailable */ }
  return session;
}
function setSession(next) {
  session = next;
  chrome.storage.session.set({ capture: next }).catch(() => {});
}

// Capture ids each tab may read back (the preview loads its image in chunks)
let grants = null;
async function getGrants() {
  if (grants) return grants;
  try {
    grants = (await chrome.storage.session.get('grants')).grants || {};
  } catch (e) {
    grants = {};
  }
  return grants;
}
async function grant(id, tabId) {
  const g = await getGrants();
  g[id] = tabId;
  const ids = Object.keys(g);
  if (ids.length > 20) delete g[ids[0]];
  chrome.storage.session.set({ grants: g }).catch(() => {});
}
async function isGranted(id, sender) {
  const g = await getGrants();
  return !!(sender.tab && g[id] === sender.tab.id);
}

async function captureVisibleTabSafe(windowId = null, retryCount = 0) {
  const now = Date.now();
  const timeSinceLast = now - lastCaptureTime;

  if (timeSinceLast < MIN_CAPTURE_INTERVAL_MS) {
    const delay = MIN_CAPTURE_INTERVAL_MS - timeSinceLast;
    await new Promise(resolve => setTimeout(resolve, delay));
  }

  try {
    lastCaptureTime = Date.now();
    return await chrome.tabs.captureVisibleTab(windowId, { format: 'png' });
  } catch (err) {
    if (err.message && err.message.includes('MAX_CAPTURE_VISIBLE_TAB_CALLS_PER_SECOND') && retryCount < 3) {
      await new Promise(resolve => setTimeout(resolve, 650));
      return await captureVisibleTabSafe(windowId, retryCount + 1);
    }
    throw err;
  }
}

async function hasOffscreenDocument() {
  const existingContexts = await chrome.runtime.getContexts({
    contextTypes: ['OFFSCREEN_DOCUMENT'],
    documentUrls: [OFFSCREEN_URL]
  });
  return existingContexts.length > 0;
}

async function setupOffscreenDocument() {
  if (await hasOffscreenDocument()) return;

  // Concurrent callers must wait for the in-flight creation, otherwise their
  // messages are sent before the stitcher exists and get dropped.
  if (isOffscreenCreating) {
    await isOffscreenCreating;
    return;
  }
  isOffscreenCreating = chrome.offscreen.createDocument({
    url: OFFSCREEN_URL,
    reasons: ['BLOBS'],
    justification: 'Stitching screenshot frames incrementally on HTML5 Canvas'
  });

  try {
    await isOffscreenCreating;
  } finally {
    isOffscreenCreating = null;
  }
}

async function closeOffscreenDocument() {
  if (await hasOffscreenDocument()) {
    await chrome.offscreen.closeDocument();
  }
}

// Messages to the offscreen stitcher. No other extension page answers them.
function toStitcher(message) {
  return chrome.runtime.sendMessage(message).catch(() => undefined);
}

const CAPTURE_MODES = ['region', 'full', 'visible'];

function unsupportedPageError(url) {
  if (url && url.startsWith('file:')) {
    return 'To capture local files, open chrome://extensions, click Details under ScrollShot Pro and turn on "Allow access to file URLs".';
  }
  return 'ScrollShot cannot run on this page (browser pages, the Chrome Web Store and PDF viewers are blocked by Chrome).';
}

// Trigger selection mode on a tab (optionally after a countdown delay in seconds).
// mode: 'region' (draw a box / click a scroll area), 'full' (whole page) or 'visible' (what's on screen)
async function activateSelectionMode(tabId, delay = 0, mode = 'region') {
  if (!CAPTURE_MODES.includes(mode)) mode = 'region';
  let tab = null;
  try {
    tab = await chrome.tabs.get(tabId);
    // Scripts from an earlier injection are reused while they are alive. After an
    // extension update the old copies are orphaned, so inject fresh ones.
    let alive = false;
    try {
      const [probe] = await chrome.scripting.executeScript({
        target: { tabId },
        func: () => !!(window.ScrollShotOverlay && typeof window.ScrollShotOverlay.alive === 'function' && window.ScrollShotOverlay.alive())
      });
      alive = !!(probe && probe.result);
    } catch (e) { /* not injectable: the real injection below reports it */ }

    if (!alive) {
      await chrome.scripting.executeScript({
        target: { tabId },
        files: ['lib/transfer.js', 'content/overlay.js', 'content/scroll_inspector.js', 'content/toolbar.js']
      });
      await chrome.scripting.insertCSS({
        target: { tabId },
        files: ['content/overlay.css']
      });
    }

    await chrome.tabs.sendMessage(tabId, { action: 'INIT_OVERLAY', delay: delay || 0, mode });
    return { success: true };
  } catch (err) {
    return { success: false, error: unsupportedPageError(tab && (tab.url || tab.pendingUrl)) };
  }
}

// Keyboard shortcuts have no popup to show an error in: flag the toolbar icon instead
function flagActionError(tabId, message) {
  chrome.action.setBadgeBackgroundColor({ tabId, color: '#EF4444' }).catch(() => {});
  chrome.action.setBadgeText({ tabId, text: '!' }).catch(() => {});
  chrome.action.setTitle({ tabId, title: `ScrollShot Pro: ${message}` }).catch(() => {});
  setTimeout(() => {
    chrome.action.setBadgeText({ tabId, text: '' }).catch(() => {});
    chrome.action.setTitle({ tabId, title: '' }).catch(() => {});
  }, 6000);
}

const COMMAND_MODES = {
  'toggle-capture': 'region',
  'capture-full-page': 'full',
  'capture-visible': 'visible'
};

chrome.commands.onCommand.addListener(async (command, tab) => {
  const mode = COMMAND_MODES[command];
  if (!mode) return;
  if (!tab || !tab.id) {
    [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  }
  if (!tab || !tab.id) return;
  const res = await activateSelectionMode(tab.id, 0, mode);
  if (!res.success) flagActionError(tab.id, res.error);
});

// The preview modal lives in a closed shadow root, so page-level insertCSS does not reach it:
// it gets the stylesheet text along with the capture details.
let overlayCssText = null;
async function getOverlayCss() {
  if (overlayCssText === null) {
    try {
      overlayCssText = await (await fetch(chrome.runtime.getURL('content/overlay.css'))).text();
    } catch (err) {
      return '';
    }
  }
  return overlayCssText;
}

// The last capture read from history, so the preview's chunks don't reopen the database each time
let cachedCapture = null; // { id, blob }
async function captureBlob(id) {
  if (cachedCapture && cachedCapture.id === id) return cachedCapture.blob;
  try {
    const item = await self.ScrollShotHistory.get(id);
    if (item && item.blob) {
      cachedCapture = { id, blob: item.blob };
      return item.blob;
    }
  } catch (e) { /* database unavailable: the stitcher still has it in memory */ }
  return null;
}

// Chunked uploads from the preview (edited image, other export formats)
const uploads = new Map(); // key -> { chunks: [], total, tabId, at }
const MAX_UPLOAD_CHARS = 700 * 1024 * 1024;
function uploadKey(sender, uploadId) {
  return `${sender.tab ? sender.tab.id : 'x'}:${uploadId}`;
}
function takeUpload(sender, uploadId) {
  const key = uploadKey(sender, uploadId);
  const up = uploads.get(key);
  uploads.delete(key);
  if (!up || up.chunks.length !== up.total || up.chunks.some((c) => typeof c !== 'string')) {
    throw new Error('The image did not arrive completely. Please try again.');
  }
  return up.chunks;
}

const DOWNLOAD_TYPES = {
  'image/png': 'png',
  'image/jpeg': 'jpg',
  'image/webp': 'webp',
  'application/pdf': 'pdf'
};

function safeFilename(name, ext) {
  const base = String(name || '').replace(/\.[a-z0-9]+$/i, '').replace(/[^\w.-]+/g, '_').replace(/^[._]+/, '').slice(0, 120);
  return `${base || `scrollshot_${Date.now()}`}.${ext}`;
}

async function sendToTab(tabId, message) {
  return chrome.tabs.sendMessage(tabId, message, { frameId: 0 });
}

const handlers = {
  async START_SELECTION_MODE(message) {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.id) return { success: false, error: 'No active tab found.' };
    return activateSelectionMode(tab.id, message.delay, message.mode);
  },

  async INIT_STITCHER(message, sender) {
    if (!sender.tab || sender.frameId !== 0) return { success: false, error: 'Invalid sender' };
    const page = message.page || {};
    setSession({
      tabId: sender.tab.id,
      windowId: sender.tab.windowId,
      page: {
        title: String(page.title || '').slice(0, 300),
        url: String(page.url || '').slice(0, 2000),
        host: String(page.host || '').slice(0, 255)
      }
    });
    await setupOffscreenDocument();
    await toStitcher({ action: 'OFFSCREEN_INIT_CANVAS', region: message.region, page: session.page });
    return { success: true };
  },

  async CAPTURE_FRAME_REQUEST(message, sender) {
    const s = await getSession();
    if (!sender.tab || sender.frameId !== 0 || !s || s.tabId !== sender.tab.id) {
      return { success: false, error: 'No capture in progress for this tab.' };
    }
    // captureVisibleTab grabs whatever tab is showing in the window: never stitch another tab in
    const tab = await chrome.tabs.get(sender.tab.id);
    if (!tab.active) {
      wasInactive = true;
      return { success: false, code: 'inactive' };
    }
    if (wasInactive) {
      // Just switched back: give Chrome a moment to paint the tab before grabbing it
      wasInactive = false;
      await new Promise((r) => setTimeout(r, 400));
    }

    const dataUrl = await captureVisibleTabSafe(tab.windowId);
    // The user may have switched tabs while the screenshot was being taken
    const after = await chrome.tabs.get(sender.tab.id);
    if (!after.active) {
      wasInactive = true;
      return { success: false, code: 'inactive' };
    }
    await setupOffscreenDocument();
    await toStitcher({
      action: 'OFFSCREEN_ADD_FRAME',
      dataUrl,
      region: message.region,
      scrollOffset: message.scrollOffset,
      dpr: message.dpr,
      isFirstFrame: message.isFirstFrame
    });
    return { success: true };
  },

  async FINISH_CAPTURE() {
    await setupOffscreenDocument();
    await toStitcher({ action: 'OFFSCREEN_EXPORT' });
    return { success: true };
  },

  async STITCH_COMPLETE(message) {
    const s = await getSession();
    const tabId = s && s.tabId;
    if (tabId) await grant(message.id, tabId);
    const preview = {
      action: 'SHOW_PREVIEW',
      css: await getOverlayCss(),
      id: message.id,
      width: message.width,
      height: message.height,
      size: message.size,
      scale: message.scale
    };
    let delivered = false;
    if (tabId) {
      try {
        await sendToTab(tabId, preview);
        delivered = true;
      } catch (e) { /* tab closed or navigated away */ }
    }
    // Never show the capture inside some other site: open the history page instead
    if (!delivered) {
      chrome.tabs.create({ url: chrome.runtime.getURL('history/history.html') }).catch(() => {});
    }
    return { success: true };
  },

  async STITCH_FAILED(message) {
    const s = await getSession();
    if (s && s.tabId) {
      sendToTab(s.tabId, { action: 'SHOW_ERROR', error: message.error || 'The capture failed.' }).catch(() => {});
    }
    return { success: true };
  },

  async GET_CAPTURE_CHUNK(message, sender) {
    if (!(await isGranted(message.id, sender))) return { success: false, error: 'Not allowed' };
    const blob = await captureBlob(message.id);
    if (blob) return { success: true, data: await ScrollShotTransfer.blobChunk(blob, message.index) };
    // Not in the database (full disk?): the stitcher keeps the last few in memory
    const res = await toStitcher({ action: 'OFFSCREEN_GET_CHUNK', id: message.id, index: message.index });
    return res || { success: false, error: 'This capture is no longer available.' };
  },

  async UPLOAD_CHUNK(message, sender) {
    if (!sender.tab) return { success: false, error: 'Invalid sender' };
    const now = Date.now();
    for (const [k, v] of uploads) if (now - v.at > 120000) uploads.delete(k);
    const key = uploadKey(sender, message.uploadId);
    const total = Math.max(1, Math.min(200, message.total | 0));
    let up = uploads.get(key);
    if (!up) {
      up = { chunks: new Array(total), total, at: now, chars: 0 };
      uploads.set(key, up);
    }
    const index = message.index | 0;
    if (typeof message.data !== 'string' || index < 0 || index >= up.total) return { success: false, error: 'Bad chunk' };
    up.chars += message.data.length;
    if (up.chars > MAX_UPLOAD_CHARS) {
      uploads.delete(key);
      return { success: false, error: 'The image is too large.' };
    }
    up.chunks[index] = message.data;
    up.at = now;
    return { success: true };
  },

  async DOWNLOAD_IMAGE(message, sender) {
    const ext = DOWNLOAD_TYPES[message.mime];
    if (!ext) return { success: false, error: 'Unsupported format' };
    const chunks = takeUpload(sender, message.uploadId);
    const { askSaveAs } = await chrome.storage.local.get({ askSaveAs: true });
    const downloadId = await chrome.downloads.download({
      url: `data:${message.mime};base64,${chunks.join('')}`,
      filename: safeFilename(message.filename, ext),
      saveAs: askSaveAs !== false
    });
    return { success: true, downloadId };
  },

  // The user edited (cropped / blurred / annotated) the capture before exporting it
  async HISTORY_UPDATE(message, sender) {
    if (!(await isGranted(message.id, sender))) return { success: false, error: 'Not allowed' };
    const chunks = takeUpload(sender, message.uploadId);
    const blob = ScrollShotTransfer.chunksToBlob(chunks, 'image/png');
    const changes = {
      blob,
      width: message.width | 0,
      height: message.height | 0,
      edited: true
    };
    if (typeof message.thumb === 'string' && message.thumb.startsWith('data:image/jpeg;base64,')) changes.thumb = message.thumb;
    await self.ScrollShotHistory.update(message.id, changes);
    if (cachedCapture && cachedCapture.id === message.id) cachedCapture = null;
    return { success: true };
  },

  async TARGET_HEIGHT_REACHED() {
    const s = await getSession();
    if (s && s.tabId) sendToTab(s.tabId, { action: 'STOP_AUTO_SCROLL' }).catch(() => {});
    return { success: true };
  },

  async CANCEL_CAPTURE() {
    await closeOffscreenDocument();
    return { success: true };
  }
};

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const handler = message && handlers[message.action];
  if (!handler) return false;
  handler(message, sender).then(sendResponse, (err) => {
    sendResponse({ success: false, error: (err && err.message) || String(err) });
  });
  return true; // async sendResponse
});
