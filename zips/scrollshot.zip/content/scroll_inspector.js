// ScrollShot Pro - Scroll Inspector Content Script

(function () {
  if (window.ScrollShotInspector) return;

  let activeRegion = null;
  let scrollTarget = null;
  let initialScrollY = 0;
  let maxScrollY = 0;
  let isCapturing = false;
  let frameCount = 0;
  let hiddenStickyElements = [];

  let isFrameProcessing = false;
  let isAutoScrolling = false;
  let autoScrollTimer = null;

  const Inspector = {
    // forcedTarget: element to scroll (inner scroll area / document.body for full page)
    startCaptureSession(region, forcedTarget) {
      activeRegion = region;
      isCapturing = true;
      isFrameProcessing = false;
      isAutoScrolling = false;
      frameCount = 0;
      hiddenStickyElements = [];

      scrollTarget = forcedTarget || findScrollTarget(region);
      initialScrollY = getScrollPosition(scrollTarget);
      maxScrollY = initialScrollY;

      // Mask sticky elements
      maskStickyElements();

      // Show floating control toolbar with Finish, Cancel & Auto Scroll
      if (window.ScrollShotToolbar) {
        window.ScrollShotToolbar.showToolbar({
          onFinish: this.finishCapture.bind(this),
          onCancel: this.cancelCapture.bind(this),
          onToggleAutoScroll: toggleAutoScroll
        });
      }

      // Capture initial first frame. Mark it as in-flight so auto/manual scrolling
      // waits for it; otherwise the page can move before the first screenshot
      // is taken and a band of content goes missing from the stitch.
      isFrameProcessing = true;
      this.captureFrame(true, 0).finally(() => {
        // Full page: fixed/sticky bars (headers, sidebars, chat bubbles) belong in
        // the first frame only, otherwise they repeat down the whole image.
        if (region.fullPage) hideFloatingElements();
        isFrameProcessing = false;
        processPendingCaptures();
      });

      // Universal scroll listeners with event capture phase
      window.addEventListener('scroll', onScroll, { capture: true, passive: true });
      document.addEventListener('scroll', onScroll, { capture: true, passive: true });
      if (scrollTarget && scrollTarget !== document.body && scrollTarget !== document.documentElement) {
        scrollTarget.addEventListener('scroll', onScroll, { capture: true, passive: true });
      }

      // Esc cancels an active capture (the selection overlay's own Esc handler is gone by now)
      document.addEventListener('keydown', onCaptureKeyDown, true);

      // Auto-start Auto Scroll for 1-click effortless capture
      setTimeout(() => {
        if (isCapturing) {
          startAutoScroll();
        }
      }, 350);
    },

    async captureFrame(isFirstFrame = false, scrollDelta = 0) {
      if (!isCapturing) return;

      frameCount++;
      if (window.ScrollShotToolbar) {
        window.ScrollShotToolbar.updateFrameCount(frameCount);
      }

      // Hide locked box & toolbar UI before snapshot
      hideUIForCapture();

      // Allow browser frame paint to ensure UI overlay is completely hidden (60ms paint delay)
      await new Promise(r => requestAnimationFrame(() => setTimeout(r, 60)));

      try {
        await new Promise((resolve) => {
          chrome.runtime.sendMessage({
            action: 'CAPTURE_FRAME_REQUEST',
            region: activeRegion,
            scrollDelta: scrollDelta,
            dpr: activeRegion.dpr,
            isFirstFrame: isFirstFrame
          }, (response) => {
            resolve(response);
          });
        });
      } catch (err) {
        console.error('Frame capture request error:', err);
      } finally {
        // Restore locked box & toolbar UI after snapshot
        showUIAfterCapture();
      }
    },

    async finishCapture() {
      if (!isCapturing) return;

      stopAutoScroll();

      // Wait for any in-flight frame capture to complete
      while (isFrameProcessing) {
        await new Promise(r => setTimeout(r, 50));
      }

      // Check if current scroll position has new uncaptured scroll distance
      const currentScrollY = getScrollPosition(scrollTarget);
      if (currentScrollY > maxScrollY) {
        const delta = currentScrollY - maxScrollY;
        if (delta >= 10) {
          maxScrollY = currentScrollY;
          await this.captureFrame(false, delta);
        }
      }

      isCapturing = false;
      cleanupListeners();
      unmaskStickyElements();

      // Instantly restore scroll position back to initial start point
      restoreInitialScrollPosition();

      if (window.ScrollShotOverlay) {
        window.ScrollShotOverlay.hideLockedBox();
      }
      if (window.ScrollShotToolbar) {
        window.ScrollShotToolbar.hideToolbar();
      }

      chrome.runtime.sendMessage({ action: 'FINISH_CAPTURE' });
    },

    cancelCapture() {
      if (!isCapturing) return;
      isCapturing = false;
      isFrameProcessing = false;
      stopAutoScroll();
      cleanupListeners();
      unmaskStickyElements();

      // Instantly restore scroll position back to initial start point
      restoreInitialScrollPosition();

      if (window.ScrollShotOverlay) {
        window.ScrollShotOverlay.hideLockedBox();
      }
      if (window.ScrollShotToolbar) {
        window.ScrollShotToolbar.hideToolbar();
      }

      chrome.runtime.sendMessage({ action: 'CANCEL_CAPTURE' });
    }
  };

  function toggleAutoScroll() {
    if (isAutoScrolling) {
      stopAutoScroll();
    } else {
      startAutoScroll();
    }
  }

  function startAutoScroll() {
    if (!isCapturing || isAutoScrolling) return;
    isAutoScrolling = true;
    if (window.ScrollShotToolbar) {
      window.ScrollShotToolbar.updateAutoScrollState(true);
    }
    scheduleNextAutoScrollStep();
  }

  function stopAutoScroll() {
    isAutoScrolling = false;
    if (autoScrollTimer) {
      clearTimeout(autoScrollTimer);
      autoScrollTimer = null;
    }
    if (window.ScrollShotToolbar) {
      window.ScrollShotToolbar.updateAutoScrollState(false);
    }
  }

  function scheduleNextAutoScrollStep() {
    if (!isCapturing || !isAutoScrolling) return;

    autoScrollTimer = setTimeout(async () => {
      autoScrollTimer = null;
      if (!isCapturing || !isAutoScrolling) return;

      if (isFrameProcessing) {
        scheduleNextAutoScrollStep();
        return;
      }

      const target = scrollTarget && scrollTarget !== document.body && scrollTarget !== document.documentElement
        ? scrollTarget
        : (document.scrollingElement || document.documentElement || document.body);

      const maxAllowedScroll = Math.max(0, activeRegion.targetHeight - activeRegion.height);
      const currentScrolledDelta = Math.max(0, getScrollPosition(target) - initialScrollY);

      // Check if user's target selection height is already reached
      if (currentScrolledDelta >= maxAllowedScroll - 5 || activeRegion.targetHeight <= activeRegion.height) {
        stopAutoScroll();
        setTimeout(() => {
          if (isCapturing) {
            Inspector.finishCapture();
          }
        }, 200);
        return;
      }

      const remainingScroll = maxAllowedScroll - currentScrolledDelta;
      const idealStep = Math.max(100, Math.floor(activeRegion.height * 0.75));
      const stepSize = Math.min(idealStep, Math.max(10, remainingScroll));

      const beforeY = getScrollPosition(target);

      // Scroll target element by calculated step size
      if (target === document.body || target === document.documentElement || target === document.scrollingElement) {
        window.scrollBy(0, stepSize);
      } else {
        target.scrollTop += stepSize;
      }

      await new Promise(r => setTimeout(r, 60));

      const afterY = getScrollPosition(target);
      const delta = afterY - maxScrollY;

      if (delta >= 10) {
        maxScrollY = afterY;
        isFrameProcessing = true;
        try {
          await Inspector.captureFrame(false, delta);
        } finally {
          isFrameProcessing = false;
        }
      }

      const totalScrolled = Math.max(0, afterY - initialScrollY);
      const isAtBottom = isScrollAtBottom(target);

      if (totalScrolled >= maxAllowedScroll - 5 || isAtBottom || Math.abs(afterY - beforeY) < 3) {
        stopAutoScroll();
        setTimeout(() => {
          if (isCapturing) {
            Inspector.finishCapture();
          }
        }, 200);
        return;
      }

      scheduleNextAutoScrollStep();
    }, 280);
  }

  function isScrollAtBottom(target) {
    if (!target || target === document.body || target === document.documentElement || target === document.scrollingElement) {
      const winY = window.scrollY || window.pageYOffset || document.documentElement.scrollTop || 0;
      const windowHeight = window.innerHeight;
      const fullHeight = Math.max(
        document.body.scrollHeight,
        document.documentElement.scrollHeight
      );
      return (winY + windowHeight) >= (fullHeight - 15);
    } else {
      return (target.scrollTop + target.clientHeight) >= (target.scrollHeight - 15);
    }
  }

  // Runtime listener for target height completion
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.action === 'STOP_AUTO_SCROLL') {
      stopAutoScroll();
      if (isCapturing) {
        Inspector.finishCapture();
      }
    }
  });

  let scrollThrottleTimer = null;

  async function processPendingCaptures() {
    if (!isCapturing || isFrameProcessing) return;

    const currentScrollY = getScrollPosition(scrollTarget);
    if (currentScrollY > maxScrollY) {
      const delta = currentScrollY - maxScrollY;
      if (delta >= 10) {
        maxScrollY = currentScrollY;
        isFrameProcessing = true;
        try {
          await Inspector.captureFrame(false, delta);
        } finally {
          isFrameProcessing = false;
          // Process any further scrolling that occurred during capture
          processPendingCaptures();
        }
      }
    }
  }

  function onScroll() {
    if (!isCapturing) return;

    if (scrollThrottleTimer) return;

    // Responsive 100ms scroll debounce
    scrollThrottleTimer = setTimeout(() => {
      scrollThrottleTimer = null;
      processPendingCaptures();
    }, 100);
  }

  function getScrollPosition(target) {
    if (target && target !== document.body && target !== document.documentElement) {
      return target.scrollTop;
    }
    return window.scrollY || window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0;
  }

  function restoreInitialScrollPosition() {
    try {
      if (scrollTarget && scrollTarget !== document.body && scrollTarget !== document.documentElement) {
        scrollTarget.scrollTop = initialScrollY;
      } else {
        window.scrollTo({ top: initialScrollY, behavior: 'instant' });
      }
    } catch (e) {
      console.warn('Could not restore scroll position:', e);
    }
  }

  function findScrollTarget(region) {
    const centerX = region.x + region.width / 2;
    const centerY = region.y + region.height / 2;
    let el = document.elementFromPoint(centerX, centerY);

    while (el && el !== document.body && el !== document.documentElement) {
      const style = window.getComputedStyle(el);
      const overflowY = style.overflowY;
      const isScrollable = (overflowY === 'auto' || overflowY === 'scroll') && (el.scrollHeight > el.clientHeight);

      if (isScrollable) {
        return el;
      }
      el = el.parentElement;
    }

    return document.body;
  }

  function hideUIForCapture() {
    if (window.ScrollShotOverlay) {
      window.ScrollShotOverlay.hideForCapture();
    }
    if (window.ScrollShotToolbar) {
      window.ScrollShotToolbar.hideForCapture();
    }
  }

  function showUIAfterCapture() {
    if (window.ScrollShotOverlay) {
      window.ScrollShotOverlay.showAfterCapture();
    }
    if (window.ScrollShotToolbar) {
      window.ScrollShotToolbar.showAfterCapture();
    }
  }

  function maskStickyElements() {
    const allElements = document.querySelectorAll('*');
    hiddenStickyElements = [];

    allElements.forEach(el => {
      // Avoid masking our overlay or toolbar
      if (el.id === 'scrollshot-overlay-container' ||
        el.id === 'scrollshot-locked-box-element' ||
        el.id === 'scrollshot-toolbar-host') return;

      const rect = el.getBoundingClientRect();
      // NEVER mask main app viewports or large content containers (height > 250px or width > 50% screen)
      if (rect.height > 250 || rect.width > (window.innerWidth * 0.5)) return;

      const style = window.getComputedStyle(el);
      if (style.position === 'fixed' || style.position === 'sticky') {
        // Only mask small top header/nav overlays that intersect the top of the region
        if (rect.top <= activeRegion.y + 100 && rect.bottom >= activeRegion.y) {
          hiddenStickyElements.push({
            element: el,
            originalOpacity: el.style.opacity
          });
          el.style.opacity = '0';
        }
      }
    });
  }

  function unmaskStickyElements() {
    hiddenStickyElements.forEach(item => {
      if ('originalVisibility' in item) {
        item.element.style.setProperty('visibility', item.originalVisibility, item.originalPriority);
      } else {
        item.element.style.opacity = item.originalOpacity;
      }
    });
    hiddenStickyElements = [];
  }

  function hideFloatingElements() {
    if (!isCapturing) return;
    document.querySelectorAll('body *').forEach(el => {
      if (el.id === 'scrollshot-overlay-container' ||
        el.id === 'scrollshot-locked-box-element' ||
        el.id === 'scrollshot-toolbar-host') return;
      const pos = window.getComputedStyle(el).position;
      if (pos !== 'fixed' && pos !== 'sticky') return;
      hiddenStickyElements.push({
        element: el,
        originalVisibility: el.style.getPropertyValue('visibility'),
        originalPriority: el.style.getPropertyPriority('visibility')
      });
      el.style.setProperty('visibility', 'hidden', 'important');
    });
  }

  function onCaptureKeyDown(e) {
    if (e.key === 'Escape' && isCapturing) {
      e.preventDefault();
      e.stopPropagation();
      Inspector.cancelCapture();
    }
  }

  function cleanupListeners() {
    document.removeEventListener('keydown', onCaptureKeyDown, true);
    window.removeEventListener('scroll', onScroll, { capture: true });
    document.removeEventListener('scroll', onScroll, { capture: true });
    if (scrollTarget && scrollTarget !== document.body && scrollTarget !== document.documentElement) {
      scrollTarget.removeEventListener('scroll', onScroll, { capture: true });
    }
  }

  window.ScrollShotInspector = Inspector;
})();
