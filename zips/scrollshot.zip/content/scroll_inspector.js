// ScrollShot Pro - Scroll Inspector Content Script

(function () {
  // Re-injection: keep a live copy, replace an orphaned one (left behind by an extension update)
  const previous = window.ScrollShotInspector;
  if (previous && typeof previous.alive === 'function' && previous.alive()) return;
  if (previous) {
    try { previous.cancelCapture(); } catch (e) { /* stale copy */ }
  }

  function alive() {
    try {
      return !!(chrome.runtime && chrome.runtime.id);
    } catch (e) {
      return false;
    }
  }

  let activeRegion = null;
  let scrollTarget = null;
  let initialScrollY = 0;
  let maxScrollY = 0;
  let isCapturing = false;
  let frameCount = 0;
  let restoreList = [];      // inline styles to put back when the capture ends
  let floatingFixed = [];    // fixed elements to hide after the first frame

  let isFrameProcessing = false;
  let isAutoScrolling = false;
  let autoScrollTimer = null;

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const nextFrame = () => new Promise((r) => requestAnimationFrame(() => r()));

  const Inspector = {
    alive,

    isCapturing() {
      return isCapturing;
    },

    // forcedTarget: element to scroll (inner scroll area / document.body for full page)
    startCaptureSession(region, forcedTarget) {
      activeRegion = region;
      isCapturing = true;
      isFrameProcessing = false;
      isAutoScrolling = false;
      frameCount = 0;
      restoreList = [];
      floatingFixed = [];

      scrollTarget = forcedTarget || findScrollTarget(region);
      initialScrollY = getScrollPosition(scrollTarget);
      maxScrollY = initialScrollY;

      // Sticky bars scroll with the content; fixed ones are noted to hide after the first frame
      if (!region.visible) prepareFloatingElements();

      // Show floating control toolbar with Finish, Cancel & Auto Scroll
      if (window.ScrollShotToolbar && !region.visible) {
        window.ScrollShotToolbar.showToolbar({
          onFinish: this.finishCapture.bind(this),
          onCancel: this.cancelCapture.bind(this),
          onToggleAutoScroll: toggleAutoScroll
        });
      }

      // Capture initial first frame. Mark it as in-flight so auto/manual scrolling
      // waits for it; otherwise the page can move before the first screenshot
      // is taken and a band of content goes missing from the stitch.
      isFrameProcessing = true;
      this.captureFrame(true).finally(() => {
        // Fixed bars (headers, sidebars, chat bubbles) belong in the first frame only,
        // otherwise they repeat down the whole image.
        hideFixedElements();
        isFrameProcessing = false;
        // Visible area: one frame is the whole capture
        if (region.visible) {
          Inspector.finishCapture();
          return;
        }
        processPendingCaptures();
      });

      // Universal scroll listeners with event capture phase
      window.addEventListener('scroll', onScroll, { capture: true, passive: true });
      if (scrollTarget && scrollTarget !== document.body && scrollTarget !== document.documentElement) {
        scrollTarget.addEventListener('scroll', onScroll, { capture: true, passive: true });
      }
      document.addEventListener('visibilitychange', onVisibilityChange);

      // Esc cancels an active capture (the selection overlay's own Esc handler is gone by now)
      window.addEventListener('keydown', onCaptureKeyDown, true);

      // Auto-start Auto Scroll for 1-click effortless capture
      setTimeout(() => {
        if (isCapturing && !region.visible) {
          startAutoScroll();
        }
      }, 350);
    },

    // Returns false when the frame could not be taken (tab in the background, quota...)
    async captureFrame(isFirstFrame = false) {
      if (!isCapturing) return false;

      // captureVisibleTab only sees the tab that is showing: wait until it is
      await waitUntilVisible();
      if (!isCapturing) return false;

      // Let lazy-loaded images in the capture area arrive
      await waitForContent();
      if (!isCapturing) return false;

      // Hide locked box & toolbar UI, and make sure that is painted before the snapshot
      hideUIForCapture();
      await new Promise(r => requestAnimationFrame(() => setTimeout(r, 60)));

      // Measured right before the shot, so the stitcher places it exactly
      const scrollOffset = getScrollPosition(scrollTarget) - initialScrollY;
      let ok = false;
      try {
        const response = await chrome.runtime.sendMessage({
          action: 'CAPTURE_FRAME_REQUEST',
          region: activeRegion,
          scrollOffset,
          dpr: activeRegion.dpr,
          isFirstFrame
        });
        ok = !!(response && response.success);
      } catch (err) {
        ok = false;
      } finally {
        // Restore locked box & toolbar UI after snapshot
        showUIAfterCapture();
      }

      if (ok) {
        frameCount++;
        if (window.ScrollShotToolbar) {
          window.ScrollShotToolbar.updateFrameCount(frameCount);
        }
      }
      return ok;
    },

    async finishCapture() {
      if (!isCapturing) return;

      stopAutoScroll();

      // Wait for any in-flight frame capture to complete
      while (isFrameProcessing) {
        await sleep(50);
      }
      if (!isCapturing) return;

      // Check if current scroll position has new uncaptured scroll distance
      const currentScrollY = getScrollPosition(scrollTarget);
      if (currentScrollY - maxScrollY >= 10) {
        maxScrollY = currentScrollY;
        isFrameProcessing = true;
        try {
          await this.captureFrame(false);
        } finally {
          isFrameProcessing = false;
        }
      }
      if (!isCapturing) return;

      isCapturing = false;
      endSession();

      chrome.runtime.sendMessage({ action: 'FINISH_CAPTURE' }).catch(() => {});
    },

    cancelCapture() {
      if (!isCapturing) return;
      isCapturing = false;
      isFrameProcessing = false;
      endSession();

      try {
        chrome.runtime.sendMessage({ action: 'CANCEL_CAPTURE' }).catch(() => {});
      } catch (e) { /* extension updated: nothing to cancel */ }
    }
  };

  function endSession() {
    stopAutoScroll();
    cleanupListeners();
    restoreFloatingElements();

    // Instantly restore scroll position back to initial start point
    restoreInitialScrollPosition();

    if (window.ScrollShotOverlay) {
      window.ScrollShotOverlay.hideLockedBox();
    }
    if (window.ScrollShotToolbar) {
      window.ScrollShotToolbar.hideToolbar();
    }
  }

  function waitUntilVisible() {
    if (!document.hidden) return Promise.resolve();
    if (window.ScrollShotToolbar) window.ScrollShotToolbar.setStatus('Paused - switch back to this tab');
    return new Promise((resolve) => {
      const check = () => {
        if (!document.hidden || !isCapturing) {
          document.removeEventListener('visibilitychange', check);
          if (window.ScrollShotToolbar) window.ScrollShotToolbar.updateFrameCount(frameCount);
          // Give the compositor a moment to paint the tab again (the first frames can be blank)
          requestAnimationFrame(() => requestAnimationFrame(() => setTimeout(resolve, 400)));
        }
      };
      document.addEventListener('visibilitychange', check);
    });
  }

  function onVisibilityChange() {
    if (!document.hidden && isCapturing) processPendingCaptures();
  }

  // Lazy-loaded images: give the page a moment to start loading what scrolled into
  // view, then wait (bounded) for the images inside the capture area to arrive.
  async function waitForContent() {
    await nextFrame();
    await sleep(80);
    const r = activeRegion;
    const pending = [];
    for (const img of document.images) {
      if (img.complete) continue;
      const b = img.getBoundingClientRect();
      if (b.width === 0 || b.height === 0) continue;
      if (b.bottom < r.y || b.top > r.y + r.height || b.right < r.x || b.left > r.x + r.width) continue;
      pending.push(new Promise((resolve) => {
        img.addEventListener('load', resolve, { once: true });
        img.addEventListener('error', resolve, { once: true });
      }));
      if (pending.length >= 50) break;
    }
    if (pending.length) {
      await Promise.race([Promise.all(pending), sleep(2000)]);
      await nextFrame();
    }
  }

  function toggleAutoScroll() {
    if (isAutoScrolling) {
      stopAutoScroll();
    } else {
      startAutoScroll();
    }
  }

  function startAutoScroll() {
    if (!isCapturing || isAutoScrolling) return;
    isAutoScrolling = true;
    if (window.ScrollShotToolbar) {
      window.ScrollShotToolbar.updateAutoScrollState(true);
    }
    scheduleNextAutoScrollStep();
  }

  function stopAutoScroll() {
    isAutoScrolling = false;
    if (autoScrollTimer) {
      clearTimeout(autoScrollTimer);
      autoScrollTimer = null;
    }
    if (window.ScrollShotToolbar) {
      window.ScrollShotToolbar.updateAutoScrollState(false);
    }
  }

  function finishSoon() {
    stopAutoScroll();
    setTimeout(() => {
      if (isCapturing) {
        Inspector.finishCapture();
      }
    }, 200);
  }

  function isWindowTarget(target) {
    return !target || target === document.body || target === document.documentElement || target === document.scrollingElement;
  }

  // Instant scrolling: pages with `scroll-behavior: smooth` would otherwise still be
  // moving when the screenshot is taken.
  function scrollToPosition(target, top) {
    if (isWindowTarget(target)) {
      window.scrollTo({ top, behavior: 'instant' });
    } else {
      target.scrollTo({ top, behavior: 'instant' });
    }
  }

  function scheduleNextAutoScrollStep() {
    if (!isCapturing || !isAutoScrolling) return;

    autoScrollTimer = setTimeout(async () => {
      autoScrollTimer = null;
      if (!isCapturing || !isAutoScrolling) return;

      if (isFrameProcessing || document.hidden) {
        scheduleNextAutoScrollStep();
        return;
      }

      const target = scrollTarget;
      const maxAllowedScroll = Math.max(0, activeRegion.targetHeight - activeRegion.height);
      const currentScrolledDelta = Math.max(0, getScrollPosition(target) - initialScrollY);

      // Check if user's target selection height is already reached
      if (currentScrolledDelta >= maxAllowedScroll - 1 || activeRegion.targetHeight <= activeRegion.height) {
        finishSoon();
        return;
      }

      const remainingScroll = maxAllowedScroll - currentScrolledDelta;
      const idealStep = Math.max(100, Math.floor(activeRegion.height * 0.8));
      const stepSize = Math.min(idealStep, Math.max(1, remainingScroll));

      const beforeY = getScrollPosition(target);
      scrollToPosition(target, beforeY + stepSize);
      await nextFrame();
      if (!isCapturing) return;

      const afterY = getScrollPosition(target);
      const delta = afterY - maxScrollY;

      if (delta >= 1) {
        const prevMax = maxScrollY;
        maxScrollY = afterY;
        isFrameProcessing = true;
        try {
          const ok = await Inspector.captureFrame(false);
          if (!isCapturing) return; // cancelled or finished meanwhile: leave the scroll position alone
          if (!ok) {
            // Not captured (tab in the background...): go back and retake this part
            maxScrollY = prevMax;
            scrollToPosition(target, prevMax);
            isFrameProcessing = false;
            autoScrollTimer = setTimeout(scheduleNextAutoScrollStep, 400);
            return;
          }
        } finally {
          isFrameProcessing = false;
        }
      }

      const totalScrolled = Math.max(0, getScrollPosition(target) - initialScrollY);
      if (totalScrolled >= maxAllowedScroll - 1 || isScrollAtBottom(target) || Math.abs(afterY - beforeY) < 1) {
        finishSoon();
        return;
      }

      scheduleNextAutoScrollStep();
    }, 200);
  }

  function isScrollAtBottom(target) {
    if (isWindowTarget(target)) {
      const root = document.scrollingElement || document.documentElement;
      return (window.scrollY + root.clientHeight) >= (root.scrollHeight - 1);
    }
    return (target.scrollTop + target.clientHeight) >= (target.scrollHeight - 1);
  }

  // Runtime listener for target height completion
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.action === 'STOP_AUTO_SCROLL' && isCapturing) {
      stopAutoScroll();
      Inspector.finishCapture();
    }
  });

  let scrollThrottleTimer = null;

  async function processPendingCaptures() {
    if (!isCapturing || isFrameProcessing || isAutoScrolling || document.hidden) return;

    const currentScrollY = getScrollPosition(scrollTarget);
    if (currentScrollY - maxScrollY >= 10) {
      const prevMax = maxScrollY;
      maxScrollY = currentScrollY;
      isFrameProcessing = true;
      try {
        const ok = await Inspector.captureFrame(false);
        if (!ok) maxScrollY = prevMax;
      } finally {
        isFrameProcessing = false;
      }
      // Process any further scrolling that occurred during capture
      processPendingCaptures();
    }
  }

  // Manual scrolling (Auto Scroll paused): capture what the user scrolls to
  function onScroll() {
    if (!isCapturing || isAutoScrolling) return;
    if (scrollThrottleTimer) return;
    scrollThrottleTimer = setTimeout(() => {
      scrollThrottleTimer = null;
      processPendingCaptures();
    }, 150);
  }

  function getScrollPosition(target) {
    if (!isWindowTarget(target)) {
      return target.scrollTop;
    }
    return window.scrollY || document.documentElement.scrollTop || document.body.scrollTop || 0;
  }

  function restoreInitialScrollPosition() {
    try {
      scrollToPosition(scrollTarget, initialScrollY);
    } catch (e) { /* element removed by the page */ }
  }

  function findScrollTarget(region) {
    const centerX = region.x + region.width / 2;
    const centerY = region.y + region.height / 2;
    let el = document.elementFromPoint(centerX, centerY);

    while (el && el !== document.body && el !== document.documentElement) {
      const style = window.getComputedStyle(el);
      const overflowY = style.overflowY;
      const isScrollable = (overflowY === 'auto' || overflowY === 'scroll' || overflowY === 'overlay') && (el.scrollHeight > el.clientHeight);

      if (isScrollable) {
        return el;
      }
      el = el.parentElement;
    }

    return document.body;
  }

  function hideUIForCapture() {
    if (window.ScrollShotOverlay) {
      window.ScrollShotOverlay.hideForCapture();
    }
    if (window.ScrollShotToolbar) {
      window.ScrollShotToolbar.hideForCapture();
    }
  }

  function showUIAfterCapture() {
    if (window.ScrollShotOverlay) {
      window.ScrollShotOverlay.showAfterCapture();
    }
    if (window.ScrollShotToolbar) {
      window.ScrollShotToolbar.showAfterCapture();
    }
  }

  function isOwn(el) {
    return window.ScrollShotOverlay && window.ScrollShotOverlay.isOwnElement
      ? window.ScrollShotOverlay.isOwnElement(el)
      : false;
  }

  function setImportant(el, prop, value) {
    restoreList.push({
      element: el,
      prop,
      value: el.style.getPropertyValue(prop),
      priority: el.style.getPropertyPriority(prop)
    });
    el.style.setProperty(prop, value, 'important');
  }

  // Sticky elements (table headers, section titles, site headers) are made static so they
  // appear once, at their place in the content, instead of repeating in every frame or
  // being blanked out. Their layout space is the same, so nothing shifts. Fixed elements
  // that overlap the capture are remembered and hidden after the first frame.
  function prepareFloatingElements() {
    const r = activeRegion;
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const containerTarget = !isWindowTarget(scrollTarget) ? scrollTarget : null;

    for (const el of document.querySelectorAll('body *')) {
      if (isOwn(el)) continue;
      const pos = getComputedStyle(el).position;
      if (pos !== 'sticky' && pos !== 'fixed') continue;
      // Never move or hide the box that holds what we are capturing
      if (containerTarget && el.contains(containerTarget)) continue;

      if (pos === 'sticky') {
        setImportant(el, 'position', 'static');
        continue;
      }

      const b = el.getBoundingClientRect();
      if (b.width === 0 || b.height === 0) continue;
      // Full-window backgrounds and app shells stay: hiding them would change every frame
      if (b.width * b.height > vw * vh * 0.5) continue;
      if (!r.fullPage && (b.bottom <= r.y || b.top >= r.y + r.height || b.right <= r.x || b.left >= r.x + r.width)) continue;
      floatingFixed.push(el);
    }
  }

  function hideFixedElements() {
    if (!isCapturing) return;
    floatingFixed.forEach((el) => setImportant(el, 'visibility', 'hidden'));
    floatingFixed = [];
  }

  function restoreFloatingElements() {
    for (let i = restoreList.length - 1; i >= 0; i--) {
      const item = restoreList[i];
      try {
        item.element.style.setProperty(item.prop, item.value, item.priority);
      } catch (e) { /* element removed by the page */ }
    }
    restoreList = [];
    floatingFixed = [];
  }

  function onCaptureKeyDown(e) {
    if (e.key === 'Escape' && isCapturing) {
      e.preventDefault();
      e.stopPropagation();
      Inspector.cancelCapture();
    }
  }

  function cleanupListeners() {
    window.removeEventListener('keydown', onCaptureKeyDown, true);
    window.removeEventListener('scroll', onScroll, { capture: true });
    document.removeEventListener('visibilitychange', onVisibilityChange);
    if (scrollTarget && scrollTarget !== document.body && scrollTarget !== document.documentElement) {
      scrollTarget.removeEventListener('scroll', onScroll, { capture: true });
    }
    if (scrollThrottleTimer) {
      clearTimeout(scrollThrottleTimer);
      scrollThrottleTimer = null;
    }
  }

  window.ScrollShotInspector = Inspector;
})();
