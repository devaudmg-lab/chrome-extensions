// ScrollShot Pro - Selection Overlay Content Script with Full Selection Height Pipeline

(function () {
  // Re-injection: keep a live copy, replace an orphaned one (left behind by an extension update)
  const previous = window.ScrollShotOverlay;
  if (previous && typeof previous.alive === 'function' && previous.alive()) return;
  if (previous) {
    try { previous.removeOverlay(); } catch (e) { /* stale copy */ }
    try { previous.hideLockedBox(); } catch (e) { /* stale copy */ }
    try { if (previous.closePreview) previous.closePreview(); } catch (e) { /* stale copy */ }
  }

  function alive() {
    try {
      return !!(chrome.runtime && chrome.runtime.id);
    } catch (e) {
      return false;
    }
  }

  const MODE = {
    IDLE: 'IDLE',
    DRAWING: 'DRAWING',
    ADJUSTING: 'ADJUSTING',
    RESIZING: 'RESIZING',
    MOVING: 'MOVING'
  };

  const OWN_SELECTOR = '#scrollshot-overlay-container, #scrollshot-locked-box-element, #scrollshot-toolbar-host, #scrollshot-countdown, scrollshot-preview, scrollshot-toast';

  let currentMode = MODE.IDLE;
  let overlayContainer = null;
  let selectionBox = null;
  let dimensionBadge = null;
  let confirmBar = null;
  let lockedBox = null;

  let activeHandle = null;
  let dragStartX = 0;
  let dragStartY = 0;
  let initialRect = null; // Snapshot of rect at start of drag
  let currentRect = null; // { pageX, pageY, width, height }
  let hoverBox = null; // highlight of the scroll area under the pointer (click to capture it)
  let hoverTarget = null;
  let hintPill = null;

  // Visible viewport without scrollbars (innerWidth/innerHeight include them)
  function viewportWidth() {
    return document.documentElement.clientWidth || window.innerWidth;
  }
  function viewportHeight() {
    const h = document.documentElement.clientHeight;
    // Quirks mode pages report the document height here
    return h && h <= window.innerHeight ? h : window.innerHeight;
  }

  function initOverlay() {
    removeOverlay();
    hideLockedBox();

    currentMode = MODE.IDLE;

    overlayContainer = document.createElement('div');
    overlayContainer.id = 'scrollshot-overlay-container';

    selectionBox = document.createElement('div');
    selectionBox.className = 'scrollshot-selection-box';
    selectionBox.style.display = 'none';

    dimensionBadge = document.createElement('div');
    dimensionBadge.className = 'scrollshot-dimension-badge';
    dimensionBadge.style.display = 'none';

    selectionBox.appendChild(dimensionBadge);
    overlayContainer.appendChild(selectionBox);

    hoverBox = document.createElement('div');
    hoverBox.className = 'scrollshot-hover-box';
    hoverBox.style.display = 'none';
    const hoverLabel = document.createElement('div');
    hoverLabel.className = 'scrollshot-hover-label';
    hoverLabel.textContent = 'Click to capture this whole scroll area';
    hoverBox.appendChild(hoverLabel);
    overlayContainer.appendChild(hoverBox);

    // Guidance pill, shown whenever selection mode opens (hidden while drawing)
    hintPill = document.createElement('div');
    hintPill.className = 'scrollshot-hint-pill';
    hintPill.setAttribute('role', 'status');
    hintPill.innerHTML = '<b>Drag</b> to select an area &nbsp;·&nbsp; <b>Click</b> a highlighted scroll area to capture all of it &nbsp;·&nbsp; <kbd>Esc</kbd> to cancel';
    overlayContainer.appendChild(hintPill);

    // The overlay covers the whole document so drawing works anywhere
    const docH = Math.max(document.documentElement.scrollHeight, document.body ? document.body.scrollHeight : 0);
    overlayContainer.style.setProperty('height', docH + 'px', 'important');

    // On <html>, not <body>: a positioned or margined body would offset the page coordinates
    document.documentElement.appendChild(overlayContainer);

    overlayContainer.addEventListener('mousedown', onMouseDownContainer);
    // Capture phase on window: page handlers that stop propagation can't swallow them
    window.addEventListener('mousemove', onMouseMove, true);
    window.addEventListener('mouseup', onMouseUp, true);
    window.addEventListener('keydown', onKeyDown, true);
  }

  function onMouseDownContainer(e) {
    if (e.button !== 0) return;

    if (currentMode === MODE.IDLE && (e.target === overlayContainer || e.target === hoverBox)) {
      currentMode = MODE.DRAWING;
      if (hintPill) hintPill.style.display = 'none';
      dragStartX = e.pageX;
      dragStartY = e.pageY;
      currentRect = { pageX: dragStartX, pageY: dragStartY, width: 0, height: 0 };
      updateSelectionBox();
      selectionBox.style.display = 'block';
      dimensionBadge.style.display = 'block';
    }
  }

  // Edge auto-scroll: holding the pointer near the bottom/top edge while drawing or
  // resizing scrolls the page, so a selection can be taller than the viewport.
  const EDGE_PX = 40;
  const EDGE_STEP = 24;
  let lastClientX = 0;
  let lastClientY = 0;
  let edgeScrollTimer = null;

  function applyPointer(pageX, pageY) {
    if (currentMode === MODE.DRAWING) {
      const x = Math.min(dragStartX, pageX);
      const y = Math.min(dragStartY, pageY);
      currentRect = { pageX: x, pageY: y, width: Math.abs(pageX - dragStartX), height: Math.abs(pageY - dragStartY) };
      updateSelectionBox();
    }
    else if (currentMode === MODE.RESIZING && initialRect && activeHandle) {
      calculateResizedRect(pageX - dragStartX, pageY - dragStartY);
      updateSelectionBox();
    }
    else if (currentMode === MODE.MOVING && initialRect) {
      currentRect.pageX = Math.max(0, initialRect.pageX + (pageX - dragStartX));
      currentRect.pageY = Math.max(0, initialRect.pageY + (pageY - dragStartY));
      updateSelectionBox();
    }
  }

  function edgeScrollTick() {
    if (currentMode !== MODE.DRAWING && currentMode !== MODE.RESIZING) {
      stopEdgeScroll();
      return;
    }
    let dy = 0;
    if (lastClientY >= window.innerHeight - EDGE_PX) dy = EDGE_STEP;
    else if (lastClientY <= EDGE_PX) dy = -EDGE_STEP;
    if (dy === 0) {
      stopEdgeScroll();
      return;
    }
    const before = window.scrollY;
    window.scrollBy({ top: dy, behavior: 'instant' });
    if (window.scrollY !== before) {
      applyPointer(lastClientX + window.scrollX, lastClientY + window.scrollY);
    }
  }

  function stopEdgeScroll() {
    if (edgeScrollTimer) {
      clearInterval(edgeScrollTimer);
      edgeScrollTimer = null;
    }
  }

  // ---- Click a scroll area: highlight the scrollable container under the pointer ----
  function isOwnElement(el) {
    return !!(el && el.closest && el.closest(OWN_SELECTOR));
  }

  function isScrollableBox(el) {
    if (!el || el === document.body || el === document.documentElement) return false;
    if (el.scrollHeight - el.clientHeight <= 20) return false;
    const oy = getComputedStyle(el).overflowY;
    if (oy !== 'auto' && oy !== 'scroll' && oy !== 'overlay') return false;
    const r = el.getBoundingClientRect();
    return r.width >= 80 && r.height >= 60;
  }

  function scrollableAt(clientX, clientY) {
    const stack = document.elementsFromPoint(clientX, clientY).filter((el) => !isOwnElement(el));
    let el = stack[0];
    while (el && el !== document.body && el !== document.documentElement) {
      if (isScrollableBox(el)) return el;
      el = el.parentElement;
    }
    return null;
  }

  let hoverRaf = 0;
  function updateHover(clientX, clientY) {
    if (hoverRaf) return;
    hoverRaf = requestAnimationFrame(() => {
      hoverRaf = 0;
      if (!hoverBox || currentMode !== MODE.IDLE) return;
      const el = scrollableAt(clientX, clientY);
      hoverTarget = el;
      if (!el) {
        hoverBox.style.display = 'none';
        return;
      }
      const r = el.getBoundingClientRect();
      hoverBox.style.left = `${r.left + window.scrollX}px`;
      hoverBox.style.top = `${r.top + window.scrollY}px`;
      hoverBox.style.width = `${r.width}px`;
      hoverBox.style.height = `${r.height}px`;
      hoverBox.style.display = 'block';
    });
  }

  function hideHover() {
    hoverTarget = null;
    if (hoverBox) hoverBox.style.display = 'none';
  }

  // Capture an inner scroll container from its top to the end of its content
  function captureContainer(el) {
    el.scrollTo({ top: 0, behavior: 'instant' });
    let r = el.getBoundingClientRect();
    const vh = viewportHeight();
    // Bring the container into view (top edge visible, as much of it as fits)
    if (r.top < 0 || r.bottom > vh) {
      window.scrollBy({ top: r.top - Math.max(0, Math.min(40, vh - r.height)), behavior: 'instant' });
      r = el.getBoundingClientRect();
    }
    const left = r.left + el.clientLeft;
    const top = r.top + el.clientTop;
    const visTop = Math.max(0, top);
    const visBottom = Math.min(vh, top + el.clientHeight);
    const camera = Math.max(20, visBottom - visTop);
    const hiddenBelow = Math.max(0, (top + el.clientHeight) - visBottom); // part of the box below the screen
    const targetHeight = camera + hiddenBelow + (el.scrollHeight - el.clientHeight);

    currentRect = {
      pageX: Math.max(0, left) + window.scrollX,
      pageY: visTop + window.scrollY,
      width: Math.min(el.clientWidth, viewportWidth() - Math.max(0, left)),
      height: targetHeight
    };
    confirmAndStartCapture({ cameraHeight: camera, scrollTarget: el });
  }

  // One-click full page: the whole document from the top, or the main inner
  // scroll area for web apps whose window itself doesn't scroll.
  function startFullPage() {
    const root = document.scrollingElement || document.documentElement;
    if (root.scrollHeight - viewportHeight() > 20) {
      window.scrollTo({ top: 0, behavior: 'instant' });
      currentRect = {
        pageX: 0,
        pageY: 0,
        width: viewportWidth(),
        height: root.scrollHeight
      };
      confirmAndStartCapture({ scrollTarget: document.body, fullPage: true });
      return;
    }
    let best = null;
    let bestArea = 0;
    for (const el of document.body.querySelectorAll('*')) {
      if (!isScrollableBox(el)) continue;
      const r = el.getBoundingClientRect();
      const area = r.width * r.height;
      if (area > bestArea) {
        best = el;
        bestArea = area;
      }
    }
    if (best) {
      captureContainer(best);
      return;
    }
    startVisible();
  }

  // What is on screen right now, in one frame
  function startVisible() {
    currentRect = { pageX: window.scrollX, pageY: window.scrollY, width: viewportWidth(), height: viewportHeight() };
    confirmAndStartCapture({ scrollTarget: document.body, visible: true });
  }

  function onMouseMove(e) {
    lastClientX = e.clientX;
    lastClientY = e.clientY;
    applyPointer(e.pageX, e.pageY);
    if (currentMode === MODE.IDLE) updateHover(e.clientX, e.clientY);
    else if (hoverTarget) hideHover();

    const nearEdge = e.clientY >= window.innerHeight - EDGE_PX || e.clientY <= EDGE_PX;
    if (nearEdge && !edgeScrollTimer && (currentMode === MODE.DRAWING || currentMode === MODE.RESIZING)) {
      edgeScrollTimer = setInterval(edgeScrollTick, 30);
    }
  }

  function onMouseUp(e) {
    stopEdgeScroll();
    if (currentMode === MODE.DRAWING) {
      if (!currentRect || currentRect.width < 20 || currentRect.height < 20) {
        // A click (no drag): capture the highlighted scroll area, otherwise keep waiting
        const clicked = scrollableAt(e.clientX, e.clientY);
        if (clicked) {
          captureContainer(clicked);
          return;
        }
        currentMode = MODE.IDLE;
        currentRect = null;
        selectionBox.style.display = 'none';
        dimensionBadge.style.display = 'none';
        if (hintPill) hintPill.style.display = '';
        return;
      }
      hideHover();
      currentMode = MODE.ADJUSTING;
      enterAdjustMode();
    }
    else if (currentMode === MODE.RESIZING || currentMode === MODE.MOVING) {
      currentMode = MODE.ADJUSTING;
      activeHandle = null;
      initialRect = null;
    }
  }

  function enterAdjustMode() {
    renderResizeHandles();
    renderConfirmBar();

    selectionBox.onmousedown = (e) => {
      if (e.target.classList.contains('scrollshot-resize-handle')) return;
      if (e.target.closest('.scrollshot-confirm-bar')) return;

      currentMode = MODE.MOVING;
      dragStartX = e.pageX;
      dragStartY = e.pageY;
      initialRect = { ...currentRect };
      e.stopPropagation();
    };
  }

  function renderResizeHandles() {
    removeResizeHandles();

    const handles = ['nw', 'ne', 'sw', 'se', 'n', 's', 'w', 'e'];
    handles.forEach(type => {
      const handle = document.createElement('div');
      handle.className = `scrollshot-resize-handle handle-${type}`;
      handle.dataset.handle = type;

      handle.onmousedown = (e) => {
        e.stopPropagation();
        e.preventDefault();
        currentMode = MODE.RESIZING;
        activeHandle = type;
        dragStartX = e.pageX;
        dragStartY = e.pageY;
        initialRect = { ...currentRect };
      };

      selectionBox.appendChild(handle);
    });
  }

  function removeResizeHandles() {
    if (!selectionBox) return;
    const existing = selectionBox.querySelectorAll('.scrollshot-resize-handle');
    existing.forEach(h => h.remove());
  }

  function renderConfirmBar() {
    removeConfirmBar();

    confirmBar = document.createElement('div');
    confirmBar.className = 'scrollshot-confirm-bar';
    confirmBar.innerHTML = `
      <button type="button" class="scrollshot-confirm-btn scrollshot-btn-start">▶️ Start Capture <kbd class="scrollshot-kbd">Enter ↵</kbd></button>
      <button type="button" class="scrollshot-confirm-btn scrollshot-btn-cancel-select">❌ Cancel <kbd class="scrollshot-kbd">Esc</kbd></button>
    `;

    selectionBox.appendChild(confirmBar);

    const startBtn = confirmBar.querySelector('.scrollshot-btn-start');
    const cancelBtn = confirmBar.querySelector('.scrollshot-btn-cancel-select');
    startBtn.onmousedown = (e) => e.stopPropagation();
    startBtn.onclick = (e) => {
      e.stopPropagation();
      confirmAndStartCapture();
    };
    cancelBtn.onmousedown = (e) => e.stopPropagation();
    cancelBtn.onclick = (e) => {
      e.stopPropagation();
      removeOverlay();
    };
  }

  function removeConfirmBar() {
    if (confirmBar && confirmBar.parentNode) {
      confirmBar.parentNode.removeChild(confirmBar);
    }
    confirmBar = null;
  }

  function calculateResizedRect(dx, dy) {
    if (!initialRect) return;

    let { pageX, pageY, width, height } = initialRect;

    switch (activeHandle) {
      case 'se':
        width = Math.max(20, initialRect.width + dx);
        height = Math.max(20, initialRect.height + dy);
        break;
      case 'sw':
        width = Math.max(20, initialRect.width - dx);
        pageX = initialRect.pageX + (initialRect.width - width);
        height = Math.max(20, initialRect.height + dy);
        break;
      case 'ne':
        width = Math.max(20, initialRect.width + dx);
        height = Math.max(20, initialRect.height - dy);
        pageY = initialRect.pageY + (initialRect.height - height);
        break;
      case 'nw':
        width = Math.max(20, initialRect.width - dx);
        pageX = initialRect.pageX + (initialRect.width - width);
        height = Math.max(20, initialRect.height - dy);
        pageY = initialRect.pageY + (initialRect.height - height);
        break;
      case 'n':
        height = Math.max(20, initialRect.height - dy);
        pageY = initialRect.pageY + (initialRect.height - height);
        break;
      case 's':
        height = Math.max(20, initialRect.height + dy);
        break;
      case 'w':
        width = Math.max(20, initialRect.width - dx);
        pageX = initialRect.pageX + (initialRect.width - width);
        break;
      case 'e':
        width = Math.max(20, initialRect.width + dx);
        break;
    }

    currentRect = { pageX, pageY, width, height };
  }

  function updateSelectionBox() {
    if (!currentRect || !selectionBox) return;
    selectionBox.style.left = `${currentRect.pageX}px`;
    selectionBox.style.top = `${currentRect.pageY}px`;
    selectionBox.style.width = `${currentRect.width}px`;
    selectionBox.style.height = `${currentRect.height}px`;

    const dpr = window.devicePixelRatio || 1;
    const pxW = Math.round(currentRect.width * dpr);
    const pxH = Math.round(currentRect.height * dpr);
    dimensionBadge.textContent = `${Math.round(currentRect.width)} × ${Math.round(currentRect.height)} px (${pxW} × ${pxH} native)`;
  }

  // Height of fixed/sticky bars pinned to the top of the window (site headers)
  function topBarHeight() {
    let bottom = 0;
    for (const el of document.body.querySelectorAll('*')) {
      if (isOwnElement(el)) continue;
      const pos = getComputedStyle(el).position;
      if (pos !== 'fixed' && pos !== 'sticky') continue;
      const r = el.getBoundingClientRect();
      if (r.top <= 1 && r.bottom > 0 && r.height < window.innerHeight * 0.3 && r.width > window.innerWidth * 0.5) {
        bottom = Math.max(bottom, r.bottom);
      }
    }
    return bottom ? Math.ceil(bottom) + 8 : 0;
  }

  // opts.cameraHeight: on-screen height to capture each frame (inner scroll areas)
  // opts.scrollTarget: element to scroll instead of guessing from the region centre
  // opts.fullPage / opts.visible: capture mode (no re-positioning below sticky headers)
  function confirmAndStartCapture(opts = {}) {
    if (!currentRect || currentRect.width < 20 || currentRect.height < 20) return;

    // If the user scrolled while extending the selection, bring its top edge back
    // into view: capture starts at the top of the region and scrolls downward.
    // Keep it below any fixed/sticky top bar so the bar isn't captured over the content.
    const vh = viewportHeight();
    if (!opts.visible) {
      const topBar = opts.fullPage ? 0 : topBarHeight();
      if (currentRect.pageY < window.scrollY + topBar || currentRect.pageY > window.scrollY + vh - 20) {
        window.scrollTo({ top: Math.max(0, currentRect.pageY - topBar), behavior: 'instant' });
      }
    }

    // Convert page coordinates to current viewport coordinates
    const viewportX = Math.max(0, currentRect.pageX - window.scrollX);
    const viewportY = Math.max(0, currentRect.pageY - window.scrollY);

    // Camera height on screen cannot exceed the visible viewport (without a horizontal scrollbar)
    const cameraHeight = Math.max(1, Math.min(vh - viewportY, opts.cameraHeight || currentRect.height));

    const dpr = window.devicePixelRatio || 1;
    const region = {
      x: Math.round(viewportX),
      y: Math.round(viewportY),
      width: Math.round(Math.min(currentRect.width, viewportWidth() - viewportX)),
      height: Math.round(cameraHeight),             // Camera frame height on screen
      targetHeight: Math.round(opts.visible ? cameraHeight : currentRect.height), // Full target height
      dpr: dpr,
      viewportWidth: window.innerWidth, // lets the stitcher derive the real screenshot scale
      fullPage: !!opts.fullPage,
      visible: !!opts.visible
    };

    removeOverlay();
    showLockedBox(region);

    // Notify Service Worker and Scroll Inspector
    chrome.runtime.sendMessage({
      action: 'INIT_STITCHER',
      region: region,
      dpr: dpr,
      page: { title: document.title, url: location.href, host: location.hostname }
    }, (res) => {
      if (chrome.runtime.lastError || !res || !res.success) {
        hideLockedBox();
        showToast('ScrollShot could not start the capture. Please try again.');
        return;
      }
      if (window.ScrollShotInspector) {
        window.ScrollShotInspector.startCaptureSession(region, opts.scrollTarget);
      }
    });
  }

  function showLockedBox(region) {
    hideLockedBox();

    lockedBox = document.createElement('div');
    lockedBox.id = 'scrollshot-locked-box-element';
    lockedBox.className = 'scrollshot-locked-box';
    lockedBox.style.left = `${region.x}px`;
    lockedBox.style.top = `${region.y}px`;
    lockedBox.style.width = `${region.width}px`;
    lockedBox.style.height = `${region.height}px`;

    const badge = document.createElement('div');
    badge.className = 'scrollshot-locked-badge';
    badge.textContent = region.fullPage ? '🔒 Full Page' : (region.visible ? '🔒 Visible Area' : '🔒 Region Locked');
    // Keep the badge on screen when the region starts at the very top
    if (region.y < 24) badge.classList.add('scrollshot-badge-inside');
    lockedBox.appendChild(badge);

    (document.documentElement || document.body).appendChild(lockedBox);
  }

  function hideLockedBox() {
    if (lockedBox && lockedBox.parentNode) {
      lockedBox.parentNode.removeChild(lockedBox);
    }
    lockedBox = null;
  }

  function hideForCapture() {
    if (lockedBox) {
      lockedBox.style.display = 'none';
    }
  }

  function showAfterCapture() {
    if (lockedBox) {
      lockedBox.style.display = 'block';
    }
  }

  function onKeyDown(e) {
    if (e.key === 'Escape') {
      e.preventDefault();
      e.stopPropagation();
      removeOverlay();
      hideLockedBox();
      if (window.ScrollShotInspector) {
        window.ScrollShotInspector.cancelCapture();
      }
    }
    else if (e.key === 'Enter' || e.key === ' ') {
      if (currentRect && currentRect.width >= 20 && currentRect.height >= 20 && currentMode === MODE.ADJUSTING) {
        e.preventDefault();
        e.stopPropagation();
        confirmAndStartCapture();
      }
    }
  }

  function removeOverlay() {
    stopEdgeScroll();
    hoverTarget = null;
    hoverBox = null;
    hintPill = null;
    window.removeEventListener('keydown', onKeyDown, true);
    window.removeEventListener('mousemove', onMouseMove, true);
    window.removeEventListener('mouseup', onMouseUp, true);

    if (overlayContainer && overlayContainer.parentNode) {
      overlayContainer.parentNode.removeChild(overlayContainer);
    }
    overlayContainer = null;
    selectionBox = null;
    dimensionBadge = null;
    confirmBar = null;
    currentMode = MODE.IDLE;
    activeHandle = null;
    initialRect = null;
  }

  // Short status message (text only, never image data)
  function showToast(text) {
    const old = document.querySelector('scrollshot-toast');
    if (old) old.remove();
    const host = document.createElement('scrollshot-toast');
    host.style.cssText = 'all: initial !important; position: fixed !important; z-index: 2147483647 !important; left: 50% !important; bottom: 32px !important; transform: translateX(-50%) !important;';
    const shadow = host.attachShadow({ mode: 'closed' });
    const box = document.createElement('div');
    box.setAttribute('role', 'alert');
    box.textContent = text;
    box.style.cssText = 'font: 500 13px/1.4 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; color: #F8FAFC; background: rgba(15, 23, 42, 0.95); border: 1px solid rgba(255, 255, 255, 0.15); border-radius: 12px; padding: 10px 16px; box-shadow: 0 10px 30px rgba(0, 0, 0, 0.35); max-width: 420px;';
    shadow.appendChild(box);
    document.documentElement.appendChild(host);
    setTimeout(() => host.remove(), 4500);
  }

  // Delayed capture: lets the user open menus / hover states before selecting
  let countdownTimer = null;
  let countdownKeyHandler = null;
  function stopCountdown() {
    if (countdownTimer) clearInterval(countdownTimer);
    countdownTimer = null;
    if (countdownKeyHandler) window.removeEventListener('keydown', countdownKeyHandler, true);
    countdownKeyHandler = null;
    const prev = document.getElementById('scrollshot-countdown');
    if (prev) prev.remove();
  }

  function startCountdown(seconds, done) {
    stopCountdown();

    const badge = document.createElement('div');
    badge.id = 'scrollshot-countdown';
    badge.className = 'scrollshot-countdown';
    badge.setAttribute('role', 'timer');
    badge.setAttribute('aria-label', 'Capture starts in');
    badge.textContent = String(seconds);
    (document.documentElement || document.body).appendChild(badge);

    countdownKeyHandler = (e) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        e.stopPropagation();
        stopCountdown();
      }
    };
    window.addEventListener('keydown', countdownKeyHandler, true);

    let remaining = seconds;
    countdownTimer = setInterval(() => {
      remaining--;
      if (remaining <= 0) {
        stopCountdown();
        done();
      } else {
        badge.textContent = String(remaining);
      }
    }, 1000);
  }

  function startMode(mode, delay) {
    // Already capturing in this tab: keep going rather than starting a second capture on top
    if (window.ScrollShotInspector && window.ScrollShotInspector.isCapturing()) return;
    closePreview();
    const start = mode === 'full' ? startFullPage : (mode === 'visible' ? startVisible : initOverlay);
    if (delay > 0) {
      startCountdown(delay, start);
    } else {
      start();
    }
  }

  window.ScrollShotOverlay = {
    alive,
    showLockedBox,
    hideLockedBox,
    hideForCapture,
    showAfterCapture,
    removeOverlay,
    closePreview: () => closePreview(),
    isOwnElement
  };

  // Message listener
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.action === 'INIT_OVERLAY') {
      const delay = Math.max(0, Math.min(30, parseInt(msg.delay, 10) || 0));
      startMode(msg.mode, delay);
      sendResponse({ status: 'ok' });
    }
    else if (msg.action === 'SHOW_PREVIEW') {
      hideLockedBox();
      showPreviewModal(msg);
      sendResponse({ status: 'ok' });
    }
    else if (msg.action === 'SHOW_ERROR') {
      hideLockedBox();
      showToast(String(msg.error || 'The capture failed.'));
      sendResponse({ status: 'ok' });
    }
  });

  const FORMATS = {
    png: { mime: 'image/png', label: 'PNG' },
    jpg: { mime: 'image/jpeg', label: 'JPG' },
    webp: { mime: 'image/webp', label: 'WebP' },
    pdf: { mime: 'application/pdf', label: 'PDF' }
  };

  // Smart file naming: scrollshot_{domain}_{date}_{time}.{ext}
  function buildFilename(ext) {
    const pad = (n) => String(n).padStart(2, '0');
    const d = new Date();
    const date = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
    const time = `${pad(d.getHours())}-${pad(d.getMinutes())}-${pad(d.getSeconds())}`;
    const domain = (location.hostname || 'page').replace(/^www\./, '').replace(/[^a-z0-9.-]/gi, '_');
    return `scrollshot_${domain}_${date}_${time}.${ext}`;
  }

  function canvasToBlob(c, type, quality) {
    return new Promise((resolve, reject) => {
      c.toBlob((b) => (b ? resolve(b) : reject(new Error('Chrome could not encode the image'))), type, quality);
    });
  }

  // Multi-page A4 PDF: the capture is fitted to the page width and split into pages
  async function buildPdf(src) {
    const pageW = 595.28;
    const pageH = 841.89;
    const rowsPerPage = Math.max(1, Math.floor(src.width * pageH / pageW));
    const pages = [];
    for (let y = 0; y < src.height; y += rowsPerPage) {
      const h = Math.min(rowsPerPage, src.height - y);
      const c = document.createElement('canvas');
      c.width = src.width;
      c.height = h;
      const cx = c.getContext('2d');
      cx.fillStyle = '#FFFFFF';
      cx.fillRect(0, 0, c.width, h);
      cx.drawImage(src, 0, y, src.width, h, 0, 0, src.width, h);
      const jpeg = await canvasToBlob(c, 'image/jpeg', 0.9);
      pages.push({ bytes: new Uint8Array(await jpeg.arrayBuffer()), w: src.width, h });
      c.width = 0;
      c.height = 0;
    }

    const enc = new TextEncoder();
    const parts = [];
    const offsets = [];
    let offset = 0;
    const push = (x) => {
      const b = typeof x === 'string' ? enc.encode(x) : x;
      parts.push(b);
      offset += b.length;
    };
    const obj = (n, write) => {
      offsets[n] = offset;
      push(`${n} 0 obj\n`);
      write();
      push('\nendobj\n');
    };

    push('%PDF-1.4\n%âãÏÓ\n');
    obj(1, () => push('<< /Type /Catalog /Pages 2 0 R >>'));
    obj(2, () => push(`<< /Type /Pages /Count ${pages.length} /Kids [${pages.map((_, k) => `${3 + 3 * k} 0 R`).join(' ')}] >>`));
    pages.forEach((p, k) => {
      const drawH = pageW * p.h / p.w;
      const content = `q ${pageW.toFixed(2)} 0 0 ${drawH.toFixed(2)} 0 ${(pageH - drawH).toFixed(2)} cm /Im0 Do Q`;
      obj(3 + 3 * k, () => push(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${pageW} ${pageH}] /Resources << /XObject << /Im0 ${5 + 3 * k} 0 R >> >> /Contents ${4 + 3 * k} 0 R >>`));
      obj(4 + 3 * k, () => push(`<< /Length ${content.length} >>\nstream\n${content}\nendstream`));
      obj(5 + 3 * k, () => {
        push(`<< /Type /XObject /Subtype /Image /Width ${p.w} /Height ${p.h} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${p.bytes.length} >>\nstream\n`);
        push(p.bytes);
        push('\nendstream');
      });
    });
    const count = 3 + 3 * pages.length;
    const xrefAt = offset;
    let xref = `xref\n0 ${count}\n0000000000 65535 f \n`;
    for (let i = 1; i < count; i++) xref += `${String(offsets[i]).padStart(10, '0')} 00000 n \n`;
    push(`${xref}trailer\n<< /Size ${count} /Root 1 0 R >>\nstartxref\n${xrefAt}\n%%EOF\n`);
    return new Blob(parts, { type: 'application/pdf' });
  }

  // ---------- Preview + editor (crop, blur, box, arrow, highlight, text) ----------
  const TOOLS = {
    crop: { label: 'Crop', icon: '✂️', key: 'c', hint: 'Drag over the part you want to keep.' },
    blur: { label: 'Blur', icon: '▦', key: 'b', hint: 'Drag over private details to pixelate them.' },
    box: { label: 'Box', icon: '▢', key: 'r', hint: 'Drag to draw a red box around something.' },
    arrow: { label: 'Arrow', icon: '↗', key: 'a', hint: 'Drag from where the arrow starts to what it points at.' },
    highlight: { label: 'Highlight', icon: '🖍️', key: 'h', hint: 'Drag to highlight text in yellow.' },
    text: { label: 'Text', icon: 'T', key: 't', hint: 'Click where the label goes, type, then press Enter.' }
  };
  const DEFAULT_HINT = 'Pick a tool to crop, blur or mark up the image, or export it as is.';

  // Pixelates a rectangle in place (irreversible in the exported image)
  function pixelate(ctx, x, y, w, h, block) {
    const sw = Math.max(1, Math.ceil(w / block));
    const sh = Math.max(1, Math.ceil(h / block));
    const tmp = document.createElement('canvas');
    tmp.width = sw;
    tmp.height = sh;
    const tctx = tmp.getContext('2d');
    tctx.drawImage(ctx.canvas, x, y, w, h, 0, 0, sw, sh);
    ctx.save();
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(tmp, 0, 0, sw, sh, x, y, w, h);
    ctx.restore();
  }

  const TEXT_FONT = '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif';

  function applyOp(canvas, op) {
    const ctx = canvas.getContext('2d');
    const unit = Math.max(1, canvas.width / 640); // keeps strokes/blocks proportional to the image
    if (op.type === 'crop') {
      const tmp = document.createElement('canvas');
      tmp.width = op.w;
      tmp.height = op.h;
      tmp.getContext('2d').drawImage(canvas, op.x, op.y, op.w, op.h, 0, 0, op.w, op.h);
      canvas.width = op.w;
      canvas.height = op.h;
      canvas.getContext('2d').drawImage(tmp, 0, 0);
    } else if (op.type === 'blur') {
      pixelate(ctx, op.x, op.y, op.w, op.h, Math.max(8, Math.round(9 * unit)));
    } else if (op.type === 'box') {
      const lw = Math.max(3, Math.round(2.5 * unit));
      ctx.save();
      ctx.strokeStyle = '#FF3B30';
      ctx.lineWidth = lw;
      ctx.lineJoin = 'round';
      ctx.strokeRect(op.x + lw / 2, op.y + lw / 2, Math.max(1, op.w - lw), Math.max(1, op.h - lw));
      ctx.restore();
    } else if (op.type === 'arrow') {
      const lw = Math.max(3, Math.round(3 * unit));
      const head = lw * 4.5;
      const ang = Math.atan2(op.y2 - op.y1, op.x2 - op.x1);
      const baseX = op.x2 - Math.cos(ang) * head * 0.85;
      const baseY = op.y2 - Math.sin(ang) * head * 0.85;
      ctx.save();
      ctx.strokeStyle = '#FF3B30';
      ctx.fillStyle = '#FF3B30';
      ctx.lineWidth = lw;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(op.x1, op.y1);
      ctx.lineTo(baseX, baseY);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(op.x2, op.y2);
      ctx.lineTo(op.x2 - head * Math.cos(ang - 0.42), op.y2 - head * Math.sin(ang - 0.42));
      ctx.lineTo(op.x2 - head * Math.cos(ang + 0.42), op.y2 - head * Math.sin(ang + 0.42));
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    } else if (op.type === 'highlight') {
      ctx.save();
      ctx.globalCompositeOperation = 'multiply';
      ctx.fillStyle = 'rgba(255, 221, 0, 0.55)';
      ctx.fillRect(op.x, op.y, op.w, op.h);
      ctx.restore();
    } else if (op.type === 'text') {
      ctx.save();
      ctx.font = `700 ${op.size}px ${TEXT_FONT}`;
      ctx.textBaseline = 'top';
      ctx.lineJoin = 'round';
      ctx.lineWidth = Math.max(2, op.size / 5);
      ctx.strokeStyle = '#FFFFFF';
      ctx.fillStyle = '#FF3B30';
      ctx.strokeText(op.text, op.x, op.y);
      ctx.fillText(op.text, op.x, op.y);
      ctx.restore();
    }
  }

  function makeThumb(canvas) {
    try {
      const tw = 360;
      const scale = tw / canvas.width;
      const srcH = Math.min(canvas.height, Math.round(270 / scale));
      const t = document.createElement('canvas');
      t.width = tw;
      t.height = Math.max(1, Math.round(srcH * scale));
      const tctx = t.getContext('2d');
      tctx.fillStyle = '#FFFFFF';
      tctx.fillRect(0, 0, t.width, t.height);
      tctx.drawImage(canvas, 0, 0, canvas.width, srcH, 0, 0, t.width, t.height);
      return t.toDataURL('image/jpeg', 0.8);
    } catch (e) {
      return '';
    }
  }

  // The preview shows the captured image (which can include cross-origin iframes the page
  // itself cannot read), so it lives in a closed shadow root that page scripts cannot reach.
  // The image itself only ever exists in this isolated world (blob, ImageBitmap, canvas).
  let previewHost = null;
  let previewCleanup = null;

  function closePreview() {
    if (previewCleanup) {
      const fn = previewCleanup;
      previewCleanup = null;
      fn();
    }
    if (previewHost) {
      previewHost.remove();
      previewHost = null;
    }
  }

  function showPreviewModal(msg) {
    closePreview();
    const historyId = msg.id;
    const returnFocus = document.activeElement;

    const modal = document.createElement('div');
    modal.id = 'scrollshot-preview-modal';
    modal.className = 'scrollshot-preview-overlay';

    const toolButtons = Object.entries(TOOLS).map(([id, t]) =>
      `<button type="button" class="scrollshot-tool-btn" data-tool="${id}" aria-pressed="false" title="${t.label} (${t.key.toUpperCase()})"><span class="scrollshot-tool-icon" aria-hidden="true">${t.icon}</span>${t.label}</button>`
    ).join('');
    const formatOptions = Object.entries(FORMATS).map(([id, f]) => `<option value="${id}">${f.label}</option>`).join('');

    modal.innerHTML = `
      <div class="scrollshot-preview-card" role="dialog" aria-modal="true" aria-labelledby="scrollshot-preview-title" tabindex="-1">
        <div class="scrollshot-preview-header">
          <span class="scrollshot-preview-title" id="scrollshot-preview-title">✨ ScrollShot Capture</span>
          <div class="scrollshot-toolbox" role="toolbar" aria-label="Edit tools">
            ${toolButtons}
            <span class="scrollshot-tool-sep"></span>
            <button type="button" class="scrollshot-tool-btn" id="scrollshot-undo-btn" title="Undo (Ctrl+Z)" disabled>↶ Undo</button>
          </div>
          <div class="scrollshot-preview-meta">
            <span id="scrollshot-size-label" aria-live="polite">Loading…</span>
            <button type="button" class="scrollshot-btn scrollshot-btn-secondary scrollshot-btn-small" id="scrollshot-toggle-fit-btn">🔍 Actual size</button>
          </div>
        </div>
        <div class="scrollshot-preview-note" id="scrollshot-preview-note" hidden></div>
        <div class="scrollshot-preview-body" id="scrollshot-preview-body-container">
          <div class="scrollshot-editor-stage" id="scrollshot-editor-stage">
            <canvas class="scrollshot-preview-img scrollshot-fit-screen" id="scrollshot-preview-img-el" role="img" aria-label="Stitched screenshot"></canvas>
            <div class="scrollshot-editor-sel" id="scrollshot-editor-sel"></div>
            <div class="scrollshot-editor-line" id="scrollshot-editor-line"></div>
          </div>
        </div>
        <div class="scrollshot-preview-footer">
          <span class="scrollshot-editor-hint" id="scrollshot-editor-hint" aria-live="polite">${DEFAULT_HINT}</span>
          <button type="button" class="scrollshot-btn scrollshot-btn-secondary" id="scrollshot-copy-btn" disabled>📋 Copy to Clipboard</button>
          <select class="scrollshot-format-select" id="scrollshot-format-select" title="Download format" aria-label="Download format">${formatOptions}</select>
          <button type="button" class="scrollshot-btn scrollshot-btn-primary" id="scrollshot-download-btn" disabled>⬇️ Download PNG</button>
          <button type="button" class="scrollshot-btn scrollshot-btn-secondary" id="scrollshot-close-btn" title="Close (Esc)">Close</button>
        </div>
      </div>
    `;

    previewHost = document.createElement('scrollshot-preview');
    previewHost.style.cssText = 'all: initial !important; position: fixed !important; inset: 0 !important; z-index: 2147483647 !important; display: block !important;';
    const shadow = previewHost.attachShadow({ mode: 'closed' });
    const style = document.createElement('style');
    style.textContent = msg.css || '';
    shadow.append(style, modal);
    document.documentElement.appendChild(previewHost);
    const $ = (id) => shadow.getElementById(id);

    const card = modal.querySelector('.scrollshot-preview-card');
    const canvas = $('scrollshot-preview-img-el');
    const stage = $('scrollshot-editor-stage');
    const selEl = $('scrollshot-editor-sel');
    const lineEl = $('scrollshot-editor-line');
    const sizeLabel = $('scrollshot-size-label');
    const hintEl = $('scrollshot-editor-hint');
    const noteEl = $('scrollshot-preview-note');
    const undoBtn = $('scrollshot-undo-btn');
    const fitBtn = $('scrollshot-toggle-fit-btn');
    const copyBtn = $('scrollshot-copy-btn');
    const formatSelect = $('scrollshot-format-select');
    const downloadBtn = $('scrollshot-download-btn');

    const ops = [];
    let tool = null;
    let syncedVersion = 0; // ops.length last written to history
    let original = null;     // ImageBitmap of the capture
    let originalBlob = null; // PNG as captured
    let textInput = null;
    let closed = false;

    function render() {
      if (!original) return;
      canvas.width = original.width;
      canvas.height = original.height;
      canvas.getContext('2d').drawImage(original, 0, 0);
      ops.forEach((op) => applyOp(canvas, op));
      sizeLabel.textContent = `${canvas.width} × ${canvas.height} px`;
      undoBtn.disabled = ops.length === 0;
    }

    function setTool(next) {
      commitText();
      tool = tool === next ? null : next;
      modal.querySelectorAll('[data-tool]').forEach((b) => {
        const on = b.dataset.tool === tool;
        b.classList.toggle('active', on);
        b.setAttribute('aria-pressed', String(on));
      });
      stage.classList.toggle('scrollshot-editing', !!tool);
      stage.classList.toggle('scrollshot-text-tool', tool === 'text');
      hintEl.textContent = tool ? TOOLS[tool].hint : DEFAULT_HINT;
    }

    function undo() {
      if (!ops.length) return;
      ops.pop();
      render();
    }

    if (msg.scale && msg.scale < 1) {
      noteEl.textContent = `This capture was taller than Chrome's largest image (32,000 px), so it was scaled to ${Math.round(msg.scale * 100)}% to keep all of it.`;
      noteEl.hidden = false;
    }

    // Load the capture from the extension in chunks (it can be larger than one message allows)
    (async () => {
      try {
        originalBlob = await window.ScrollShotTransfer.downloadCapture(historyId, msg.size || 1, 'image/png');
        const bmp = await createImageBitmap(originalBlob);
        if (closed) {
          bmp.close();
          return;
        }
        original = bmp;
        render();
        copyBtn.disabled = false;
        downloadBtn.disabled = false;
      } catch (err) {
        if (closed) return;
        sizeLabel.textContent = '';
        hintEl.textContent = 'This capture could not be loaded here. Open it from the history page (popup → View all).';
      }
    })();

    modal.querySelectorAll('[data-tool]').forEach((b) => {
      b.onclick = () => setTool(b.dataset.tool);
    });
    undoBtn.onclick = undo;

    // ---- drag on the image to apply the active tool ----
    let drag = null;
    const toCanvas = (e) => {
      const r = canvas.getBoundingClientRect();
      const sx = canvas.width / r.width;
      const sy = canvas.height / r.height;
      return {
        x: Math.max(0, Math.min(canvas.width, (e.clientX - r.left) * sx)),
        y: Math.max(0, Math.min(canvas.height, (e.clientY - r.top) * sy)),
        cx: Math.max(0, Math.min(r.width, e.clientX - r.left)),
        cy: Math.max(0, Math.min(r.height, e.clientY - r.top)),
        scale: sx
      };
    };

    function commitText() {
      if (!textInput) return;
      const input = textInput;
      textInput = null;
      const text = input.value.trim();
      if (text) {
        ops.push({ type: 'text', x: Math.round(input._pos.x), y: Math.round(input._pos.y), size: input._pos.size, text: text.slice(0, 300) });
        render();
      }
      input.remove();
    }

    function placeText(e) {
      commitText();
      const p = toCanvas(e);
      const unit = Math.max(1, canvas.width / 640);
      const size = Math.round(22 * unit);
      const input = document.createElement('input');
      input.type = 'text';
      input.className = 'scrollshot-text-input';
      input.setAttribute('aria-label', 'Label text');
      input.placeholder = 'Type a label…';
      input._pos = { x: p.x, y: p.y, size };
      input.style.left = `${canvas.offsetLeft + p.cx}px`;
      input.style.top = `${canvas.offsetTop + p.cy}px`;
      input.style.setProperty('font-size', `${Math.max(11, size / p.scale)}px`, 'important');
      input.addEventListener('keydown', (ev) => {
        ev.stopPropagation();
        if (ev.key === 'Enter') {
          ev.preventDefault();
          commitText();
        } else if (ev.key === 'Escape') {
          ev.preventDefault();
          textInput = null;
          input.remove();
        }
      });
      input.addEventListener('blur', () => setTimeout(commitText, 0));
      stage.appendChild(input);
      textInput = input;
      setTimeout(() => input.focus(), 0);
    }

    canvas.addEventListener('mousedown', (e) => {
      if (!tool || !original || e.button !== 0) return;
      e.preventDefault();
      if (tool === 'text') {
        placeText(e);
        return;
      }
      drag = { start: toCanvas(e), end: null };
      selEl.className = `scrollshot-editor-sel scrollshot-sel-${tool}`;
    });
    const onDragMove = (e) => {
      if (!drag) return;
      drag.end = toCanvas(e);
      const a = drag.start;
      const b = drag.end;
      const offX = canvas.offsetLeft;
      const offY = canvas.offsetTop;
      if (tool === 'arrow') {
        const len = Math.hypot(b.cx - a.cx, b.cy - a.cy);
        lineEl.style.left = `${offX + a.cx}px`;
        lineEl.style.top = `${offY + a.cy}px`;
        lineEl.style.width = `${len}px`;
        lineEl.style.transform = `rotate(${Math.atan2(b.cy - a.cy, b.cx - a.cx)}rad)`;
        lineEl.style.display = 'block';
        return;
      }
      selEl.style.left = `${offX + Math.min(a.cx, b.cx)}px`;
      selEl.style.top = `${offY + Math.min(a.cy, b.cy)}px`;
      selEl.style.width = `${Math.abs(a.cx - b.cx)}px`;
      selEl.style.height = `${Math.abs(a.cy - b.cy)}px`;
      selEl.style.display = 'block';
    };
    const onDragEnd = () => {
      if (!drag) return;
      const { start: a, end: b } = drag;
      drag = null;
      selEl.style.display = 'none';
      lineEl.style.display = 'none';
      if (!b) return;
      if (tool === 'arrow') {
        if (Math.hypot(b.x - a.x, b.y - a.y) < 8) return;
        ops.push({ type: 'arrow', x1: Math.round(a.x), y1: Math.round(a.y), x2: Math.round(b.x), y2: Math.round(b.y) });
        render();
        return;
      }
      const op = {
        type: tool,
        x: Math.round(Math.min(a.x, b.x)),
        y: Math.round(Math.min(a.y, b.y)),
        w: Math.round(Math.abs(a.x - b.x)),
        h: Math.round(Math.abs(a.y - b.y))
      };
      if (op.w < 4 || op.h < 4) return;
      ops.push(op);
      render();
      if (tool === 'crop') setTool(null); // one crop at a time feels most natural
    };
    window.addEventListener('mousemove', onDragMove, true);
    window.addEventListener('mouseup', onDragEnd, true);

    let isFit = true;
    fitBtn.onclick = () => {
      isFit = !isFit;
      canvas.className = `scrollshot-preview-img ${isFit ? 'scrollshot-fit-screen' : 'scrollshot-full-screen'}`;
      stage.style.setProperty('width', isFit ? 'auto' : '100%', 'important');
      fitBtn.textContent = isFit ? '🔍 Actual size' : '🔍 Fit to screen';
    };

    const close = () => closePreview();
    $('scrollshot-close-btn').onclick = close;

    // Keyboard: tool keys, Ctrl+Z undo, Esc closes (or drops the active tool)
    const keyHandler = (e) => {
      if (!previewHost) return;
      const target = e.composedPath()[0] || e.target; // see through the shadow root
      const tag = (target && target.tagName || '').toLowerCase();
      if (tag === 'select' || tag === 'input' || tag === 'textarea') return;
      const key = (e.key || '').toLowerCase();
      if (e.key === 'Escape') {
        e.preventDefault();
        e.stopPropagation();
        if (tool) setTool(null);
        else close();
      } else if ((e.ctrlKey || e.metaKey) && key === 'z') {
        e.preventDefault();
        e.stopPropagation();
        undo();
      } else if (!e.ctrlKey && !e.metaKey && !e.altKey) {
        const found = Object.entries(TOOLS).find(([, t]) => t.key === key);
        if (found) {
          e.preventDefault();
          e.stopPropagation();
          setTool(found[0]);
        }
      }
    };
    window.addEventListener('keydown', keyHandler, true);

    previewCleanup = () => {
      closed = true;
      window.removeEventListener('mousemove', onDragMove, true);
      window.removeEventListener('mouseup', onDragEnd, true);
      window.removeEventListener('keydown', keyHandler, true);
      if (original) original.close();
      original = null;
      canvas.width = 0;
      canvas.height = 0;
      if (returnFocus && typeof returnFocus.focus === 'function') {
        try { returnFocus.focus({ preventScroll: true }); } catch (e) { /* element gone */ }
      }
    };

    // Exports use the edited canvas (or the original PNG untouched)
    const exportPng = () => (ops.length || !originalBlob ? canvasToBlob(canvas, 'image/png') : Promise.resolve(originalBlob));

    async function exportBlob(format) {
      commitText();
      if (format === 'png') return exportPng();
      if (format === 'pdf') return buildPdf(canvas);
      if (format === 'jpg') {
        const c = document.createElement('canvas');
        c.width = canvas.width;
        c.height = canvas.height;
        const cx = c.getContext('2d');
        cx.fillStyle = '#FFFFFF';
        cx.fillRect(0, 0, c.width, c.height);
        cx.drawImage(canvas, 0, 0);
        const b = await canvasToBlob(c, 'image/jpeg', 0.92);
        c.width = 0;
        c.height = 0;
        return b;
      }
      return canvasToBlob(canvas, FORMATS[format].mime, 0.92);
    }

    // Edits are written back to the history entry
    async function syncHistory() {
      if (!historyId || ops.length === syncedVersion) return;
      const version = ops.length;
      try {
        const png = await canvasToBlob(canvas, 'image/png');
        const uploadId = await window.ScrollShotTransfer.uploadBlob(png);
        const res = await chrome.runtime.sendMessage({
          action: 'HISTORY_UPDATE',
          id: historyId,
          uploadId,
          width: canvas.width,
          height: canvas.height,
          thumb: makeThumb(canvas)
        });
        if (res && res.success) syncedVersion = version;
      } catch (e) { /* history is optional */ }
    }

    const syncDownloadLabel = () => {
      downloadBtn.textContent = `⬇️ Download ${FORMATS[formatSelect.value].label}`;
    };
    try {
      chrome.storage.local.get({ exportFormat: 'png' }, (prefs) => {
        if (chrome.runtime.lastError) return;
        if (FORMATS[prefs.exportFormat]) {
          formatSelect.value = prefs.exportFormat;
          syncDownloadLabel();
        }
      });
    } catch (e) { /* storage unavailable: keep PNG */ }
    formatSelect.onchange = () => {
      syncDownloadLabel();
      try { chrome.storage.local.set({ exportFormat: formatSelect.value }); } catch (e) { /* ignore */ }
    };

    let busy = false;
    downloadBtn.onclick = async () => {
      if (busy || !original) return;
      busy = true;
      const format = formatSelect.value;
      downloadBtn.textContent = format === 'pdf' ? '⏳ Building PDF…' : '⏳ Saving…';
      try {
        const blob = await exportBlob(format);
        const uploadId = await window.ScrollShotTransfer.uploadBlob(blob);
        const res = await chrome.runtime.sendMessage({
          action: 'DOWNLOAD_IMAGE',
          uploadId,
          mime: FORMATS[format].mime,
          filename: buildFilename(format)
        });
        if (!res || !res.success) throw new Error((res && res.error) || 'Download failed');
        syncDownloadLabel();
        syncHistory();
      } catch (err) {
        downloadBtn.textContent = '⚠️ Export failed';
        hintEl.textContent = `Export failed: ${(err && err.message) || 'unknown error'}`;
        setTimeout(syncDownloadLabel, 2500);
      } finally {
        busy = false;
      }
    };

    copyBtn.onclick = async () => {
      if (!original) return;
      try {
        // Passing the promise keeps the click's user activation while the PNG is encoded
        await navigator.clipboard.write([new ClipboardItem({ 'image/png': exportPng() })]);
        copyBtn.textContent = '✅ Copied!';
        setTimeout(() => copyBtn.textContent = '📋 Copy to Clipboard', 2000);
        syncHistory();
      } catch (err) {
        copyBtn.textContent = '⚠️ Copy blocked - use Download';
        setTimeout(() => copyBtn.textContent = '📋 Copy to Clipboard', 2500);
      }
    };

    try { card.focus({ preventScroll: true }); } catch (e) { /* ignore */ }
  }
})();
