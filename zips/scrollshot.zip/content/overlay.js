// ScrollShot Pro - Selection Overlay Content Script with Full Selection Height Pipeline

(function () {
  if (window.__scrollshotOverlayLoaded && window.ScrollShotOverlay) return;
  window.__scrollshotOverlayLoaded = true;

  const MODE = {
    IDLE: 'IDLE',
    DRAWING: 'DRAWING',
    ADJUSTING: 'ADJUSTING',
    RESIZING: 'RESIZING',
    MOVING: 'MOVING'
  };

  let currentMode = MODE.IDLE;
  let overlayContainer = null;
  let selectionBox = null;
  let dimensionBadge = null;
  let confirmBar = null;
  let lockedBox = null;

  let activeHandle = null;
  let dragStartX = 0;
  let dragStartY = 0;
  let initialRect = null; // Snapshot of rect at start of drag
  let currentRect = null; // { pageX, pageY, width, height }
  let hoverBox = null; // highlight of the scroll area under the pointer (click to capture it)
  let hoverTarget = null;
  let hintPill = null;

  function initOverlay() {
    removeOverlay();
    hideLockedBox();

    currentMode = MODE.IDLE;

    overlayContainer = document.createElement('div');
    overlayContainer.id = 'scrollshot-overlay-container';

    selectionBox = document.createElement('div');
    selectionBox.className = 'scrollshot-selection-box';
    selectionBox.style.display = 'none';

    dimensionBadge = document.createElement('div');
    dimensionBadge.className = 'scrollshot-dimension-badge';
    dimensionBadge.style.display = 'none';

    selectionBox.appendChild(dimensionBadge);
    overlayContainer.appendChild(selectionBox);

    hoverBox = document.createElement('div');
    hoverBox.className = 'scrollshot-hover-box';
    hoverBox.style.display = 'none';
    const hoverLabel = document.createElement('div');
    hoverLabel.className = 'scrollshot-hover-label';
    hoverLabel.textContent = 'Click to capture this whole scroll area';
    hoverBox.appendChild(hoverLabel);
    overlayContainer.appendChild(hoverBox);

    // Guidance pill, shown whenever selection mode opens (hidden while drawing)
    hintPill = document.createElement('div');
    hintPill.className = 'scrollshot-hint-pill';
    hintPill.innerHTML = '<b>Drag</b> to select an area &nbsp;·&nbsp; <b>Click</b> a highlighted scroll area to capture all of it &nbsp;·&nbsp; <kbd>Esc</kbd> to cancel';
    overlayContainer.appendChild(hintPill);

    // The overlay covers the whole document so drawing works anywhere
    const docH = Math.max(document.documentElement.scrollHeight, document.body.scrollHeight);
    overlayContainer.style.setProperty('height', docH + 'px', 'important');

    document.body.appendChild(overlayContainer);

    overlayContainer.addEventListener('mousedown', onMouseDownContainer);
    document.addEventListener('mousemove', onMouseMove);
    document.addEventListener('mouseup', onMouseUp);
    document.addEventListener('keydown', onKeyDown);
  }

  function onMouseDownContainer(e) {
    if (e.button !== 0) return;

    if (currentMode === MODE.IDLE && (e.target === overlayContainer || e.target === hoverBox)) {
      currentMode = MODE.DRAWING;
      if (hintPill) hintPill.style.display = 'none';
      dragStartX = e.pageX;
      dragStartY = e.pageY;
      currentRect = { pageX: dragStartX, pageY: dragStartY, width: 0, height: 0 };
      updateSelectionBox();
      selectionBox.style.display = 'block';
      dimensionBadge.style.display = 'block';
    }
  }

  // Edge auto-scroll: holding the pointer near the bottom/top edge while drawing or
  // resizing scrolls the page, so a selection can be taller than the viewport.
  const EDGE_PX = 40;
  const EDGE_STEP = 24;
  let lastClientX = 0;
  let lastClientY = 0;
  let edgeScrollTimer = null;

  function applyPointer(pageX, pageY) {
    if (currentMode === MODE.DRAWING) {
      const x = Math.min(dragStartX, pageX);
      const y = Math.min(dragStartY, pageY);
      currentRect = { pageX: x, pageY: y, width: Math.abs(pageX - dragStartX), height: Math.abs(pageY - dragStartY) };
      updateSelectionBox();
    }
    else if (currentMode === MODE.RESIZING && initialRect && activeHandle) {
      calculateResizedRect(pageX - dragStartX, pageY - dragStartY);
      updateSelectionBox();
    }
    else if (currentMode === MODE.MOVING && initialRect) {
      currentRect.pageX = initialRect.pageX + (pageX - dragStartX);
      currentRect.pageY = initialRect.pageY + (pageY - dragStartY);
      updateSelectionBox();
    }
  }

  function edgeScrollTick() {
    if (currentMode !== MODE.DRAWING && currentMode !== MODE.RESIZING) {
      stopEdgeScroll();
      return;
    }
    let dy = 0;
    if (lastClientY >= window.innerHeight - EDGE_PX) dy = EDGE_STEP;
    else if (lastClientY <= EDGE_PX) dy = -EDGE_STEP;
    if (dy === 0) {
      stopEdgeScroll();
      return;
    }
    const before = window.scrollY;
    window.scrollBy(0, dy);
    if (window.scrollY !== before) {
      applyPointer(lastClientX + window.scrollX, lastClientY + window.scrollY);
    }
  }

  function stopEdgeScroll() {
    if (edgeScrollTimer) {
      clearInterval(edgeScrollTimer);
      edgeScrollTimer = null;
    }
  }

  // ---- Click a scroll area: highlight the scrollable container under the pointer ----
  function isOwnElement(el) {
    return !!(el && el.closest && el.closest('#scrollshot-overlay-container, #scrollshot-locked-box-element, #scrollshot-toolbar-host'));
  }

  function isScrollableBox(el) {
    if (!el || el === document.body || el === document.documentElement) return false;
    if (el.scrollHeight - el.clientHeight <= 20) return false;
    const oy = getComputedStyle(el).overflowY;
    if (oy !== 'auto' && oy !== 'scroll' && oy !== 'overlay') return false;
    const r = el.getBoundingClientRect();
    return r.width >= 80 && r.height >= 60;
  }

  function scrollableAt(clientX, clientY) {
    const stack = document.elementsFromPoint(clientX, clientY).filter((el) => !isOwnElement(el));
    let el = stack[0];
    while (el && el !== document.body && el !== document.documentElement) {
      if (isScrollableBox(el)) return el;
      el = el.parentElement;
    }
    return null;
  }

  let hoverRaf = 0;
  function updateHover(clientX, clientY) {
    if (hoverRaf) return;
    hoverRaf = requestAnimationFrame(() => {
      hoverRaf = 0;
      if (!hoverBox || currentMode !== MODE.IDLE) return;
      const el = scrollableAt(clientX, clientY);
      hoverTarget = el;
      if (!el) {
        hoverBox.style.display = 'none';
        return;
      }
      const r = el.getBoundingClientRect();
      hoverBox.style.left = `${r.left + window.scrollX}px`;
      hoverBox.style.top = `${r.top + window.scrollY}px`;
      hoverBox.style.width = `${r.width}px`;
      hoverBox.style.height = `${r.height}px`;
      hoverBox.style.display = 'block';
    });
  }

  function hideHover() {
    hoverTarget = null;
    if (hoverBox) hoverBox.style.display = 'none';
  }

  // Capture an inner scroll container from its top to the end of its content
  function captureContainer(el) {
    el.scrollTop = 0;
    let r = el.getBoundingClientRect();
    // Bring the container into view (top edge visible, as much of it as fits)
    if (r.top < 0 || r.bottom > window.innerHeight) {
      window.scrollBy(0, r.top - Math.max(0, Math.min(40, window.innerHeight - r.height)));
      r = el.getBoundingClientRect();
    }
    const left = r.left + el.clientLeft;
    const top = r.top + el.clientTop;
    const visTop = Math.max(0, top);
    const visBottom = Math.min(window.innerHeight, top + el.clientHeight);
    const camera = Math.max(20, visBottom - visTop);
    const hiddenBelow = Math.max(0, (top + el.clientHeight) - visBottom); // part of the box below the screen
    const targetHeight = camera + hiddenBelow + (el.scrollHeight - el.clientHeight);

    currentRect = {
      pageX: left + window.scrollX,
      pageY: visTop + window.scrollY,
      width: Math.min(el.clientWidth, window.innerWidth - Math.max(0, left)),
      height: targetHeight
    };
    confirmAndStartCapture({ cameraHeight: camera, scrollTarget: el });
  }

  // One-click full page: the whole document from the top, or the main inner
  // scroll area for web apps whose window itself doesn't scroll.
  function startFullPage() {
    const root = document.scrollingElement || document.documentElement;
    if (root.scrollHeight - window.innerHeight > 20) {
      window.scrollTo({ top: 0, behavior: 'instant' });
      currentRect = {
        pageX: 0,
        pageY: 0,
        width: document.documentElement.clientWidth || window.innerWidth,
        height: root.scrollHeight
      };
      confirmAndStartCapture({ scrollTarget: document.body, fullPage: true });
      return;
    }
    let best = null;
    let bestArea = 0;
    for (const el of document.body.querySelectorAll('*')) {
      if (!isScrollableBox(el)) continue;
      const r = el.getBoundingClientRect();
      const area = r.width * r.height;
      if (area > bestArea) {
        best = el;
        bestArea = area;
      }
    }
    if (best) {
      captureContainer(best);
      return;
    }
    // Nothing scrolls: capture the visible page
    currentRect = { pageX: window.scrollX, pageY: window.scrollY, width: document.documentElement.clientWidth || window.innerWidth, height: window.innerHeight };
    confirmAndStartCapture({ scrollTarget: document.body, fullPage: true });
  }

  function onMouseMove(e) {
    lastClientX = e.clientX;
    lastClientY = e.clientY;
    applyPointer(e.pageX, e.pageY);
    if (currentMode === MODE.IDLE) updateHover(e.clientX, e.clientY);
    else if (hoverTarget) hideHover();

    const nearEdge = e.clientY >= window.innerHeight - EDGE_PX || e.clientY <= EDGE_PX;
    if (nearEdge && !edgeScrollTimer && (currentMode === MODE.DRAWING || currentMode === MODE.RESIZING)) {
      edgeScrollTimer = setInterval(edgeScrollTick, 30);
    }
  }

  function onMouseUp(e) {
    stopEdgeScroll();
    if (currentMode === MODE.DRAWING) {
      if (!currentRect || currentRect.width < 20 || currentRect.height < 20) {
        // A click (no drag): capture the highlighted scroll area, otherwise keep waiting
        const clicked = scrollableAt(e.clientX, e.clientY);
        if (clicked) {
          captureContainer(clicked);
          return;
        }
        currentMode = MODE.IDLE;
        currentRect = null;
        selectionBox.style.display = 'none';
        dimensionBadge.style.display = 'none';
        if (hintPill) hintPill.style.display = '';
        return;
      }
      hideHover();
      currentMode = MODE.ADJUSTING;
      enterAdjustMode();
    }
    else if (currentMode === MODE.RESIZING || currentMode === MODE.MOVING) {
      currentMode = MODE.ADJUSTING;
      activeHandle = null;
      initialRect = null;
    }
  }

  function enterAdjustMode() {
    renderResizeHandles();
    renderConfirmBar();

    selectionBox.onmousedown = (e) => {
      if (e.target.classList.contains('scrollshot-resize-handle')) return;
      if (e.target.closest('.scrollshot-confirm-bar')) return;

      currentMode = MODE.MOVING;
      dragStartX = e.pageX;
      dragStartY = e.pageY;
      initialRect = { ...currentRect };
      e.stopPropagation();
    };
  }

  function renderResizeHandles() {
    removeResizeHandles();

    const handles = ['nw', 'ne', 'sw', 'se', 'n', 's', 'w', 'e'];
    handles.forEach(type => {
      const handle = document.createElement('div');
      handle.className = `scrollshot-resize-handle handle-${type}`;
      handle.dataset.handle = type;

      handle.onmousedown = (e) => {
        e.stopPropagation();
        e.preventDefault();
        currentMode = MODE.RESIZING;
        activeHandle = type;
        dragStartX = e.pageX;
        dragStartY = e.pageY;
        initialRect = { ...currentRect };
      };

      selectionBox.appendChild(handle);
    });
  }

  function removeResizeHandles() {
    if (!selectionBox) return;
    const existing = selectionBox.querySelectorAll('.scrollshot-resize-handle');
    existing.forEach(h => h.remove());
  }

  function renderConfirmBar() {
    removeConfirmBar();

    confirmBar = document.createElement('div');
    confirmBar.className = 'scrollshot-confirm-bar';
    confirmBar.innerHTML = `
      <button class="scrollshot-confirm-btn scrollshot-btn-start" id="scrollshot-start-btn">▶️ Start Capture <kbd style="font-size: 10px; opacity: 0.85; margin-left: 4px; background: rgba(255,255,255,0.25); padding: 1px 5px; border-radius: 4px;">Enter ↵</kbd></button>
      <button class="scrollshot-confirm-btn scrollshot-btn-cancel-select" id="scrollshot-cancel-select-btn">❌ Cancel <kbd style="font-size: 10px; opacity: 0.6; margin-left: 4px; background: rgba(255,255,255,0.15); padding: 1px 4px; border-radius: 4px;">Esc</kbd></button>
    `;

    selectionBox.appendChild(confirmBar);

    selectionBox.querySelector('#scrollshot-start-btn').onmousedown = (e) => e.stopPropagation();
    selectionBox.querySelector('#scrollshot-start-btn').onclick = (e) => {
      e.stopPropagation();
      confirmAndStartCapture();
    };

    selectionBox.querySelector('#scrollshot-cancel-select-btn').onmousedown = (e) => e.stopPropagation();
    selectionBox.querySelector('#scrollshot-cancel-select-btn').onclick = (e) => {
      e.stopPropagation();
      removeOverlay();
    };
  }

  function removeConfirmBar() {
    if (confirmBar && confirmBar.parentNode) {
      confirmBar.parentNode.removeChild(confirmBar);
    }
    confirmBar = null;
  }

  function calculateResizedRect(dx, dy) {
    if (!initialRect) return;

    let { pageX, pageY, width, height } = initialRect;

    switch (activeHandle) {
      case 'se':
        width = Math.max(20, initialRect.width + dx);
        height = Math.max(20, initialRect.height + dy);
        break;
      case 'sw':
        width = Math.max(20, initialRect.width - dx);
        pageX = initialRect.pageX + (initialRect.width - width);
        height = Math.max(20, initialRect.height + dy);
        break;
      case 'ne':
        width = Math.max(20, initialRect.width + dx);
        height = Math.max(20, initialRect.height - dy);
        pageY = initialRect.pageY + (initialRect.height - height);
        break;
      case 'nw':
        width = Math.max(20, initialRect.width - dx);
        pageX = initialRect.pageX + (initialRect.width - width);
        height = Math.max(20, initialRect.height - dy);
        pageY = initialRect.pageY + (initialRect.height - height);
        break;
      case 'n':
        height = Math.max(20, initialRect.height - dy);
        pageY = initialRect.pageY + (initialRect.height - height);
        break;
      case 's':
        height = Math.max(20, initialRect.height + dy);
        break;
      case 'w':
        width = Math.max(20, initialRect.width - dx);
        pageX = initialRect.pageX + (initialRect.width - width);
        break;
      case 'e':
        width = Math.max(20, initialRect.width + dx);
        break;
    }

    currentRect = { pageX, pageY, width, height };
  }

  function updateSelectionBox() {
    if (!currentRect || !selectionBox) return;
    selectionBox.style.left = `${currentRect.pageX}px`;
    selectionBox.style.top = `${currentRect.pageY}px`;
    selectionBox.style.width = `${currentRect.width}px`;
    selectionBox.style.height = `${currentRect.height}px`;

    const dpr = window.devicePixelRatio || 1;
    const pxW = Math.round(currentRect.width * dpr);
    const pxH = Math.round(currentRect.height * dpr);
    dimensionBadge.textContent = `${Math.round(currentRect.width)} × ${Math.round(currentRect.height)} px (${pxW} × ${pxH} native)`;
  }

  // Height of fixed/sticky bars pinned to the top of the window (site headers)
  function topBarHeight() {
    let bottom = 0;
    for (const el of document.body.querySelectorAll('*')) {
      if (isOwnElement(el)) continue;
      const pos = getComputedStyle(el).position;
      if (pos !== 'fixed' && pos !== 'sticky') continue;
      const r = el.getBoundingClientRect();
      if (r.top <= 1 && r.bottom > 0 && r.height < window.innerHeight * 0.3 && r.width > window.innerWidth * 0.5) {
        bottom = Math.max(bottom, r.bottom);
      }
    }
    return bottom ? Math.ceil(bottom) + 8 : 0;
  }

  // opts.cameraHeight: on-screen height to capture each frame (inner scroll areas)
  // opts.scrollTarget: element to scroll instead of guessing from the region centre
  function confirmAndStartCapture(opts = {}) {
    if (!currentRect || currentRect.width < 20 || currentRect.height < 20) return;

    // If the user scrolled while extending the selection, bring its top edge back
    // into view: capture starts at the top of the region and scrolls downward.
    // Keep it below any fixed/sticky top bar so the bar isn't captured over the content.
    const topBar = opts.fullPage ? 0 : topBarHeight();
    if (currentRect.pageY < window.scrollY + topBar || currentRect.pageY > window.scrollY + window.innerHeight - 20) {
      window.scrollTo({ top: Math.max(0, currentRect.pageY - topBar), behavior: 'instant' });
    }

    // Convert page coordinates to current viewport coordinates
    const viewportX = currentRect.pageX - window.scrollX;
    const viewportY = currentRect.pageY - window.scrollY;

    // Camera height on screen cannot exceed visible viewport
    const cameraHeight = Math.min(window.innerHeight - Math.max(0, viewportY), opts.cameraHeight || currentRect.height);

    const dpr = window.devicePixelRatio || 1;
    const region = {
      x: Math.round(viewportX),
      y: Math.round(viewportY),
      width: Math.round(currentRect.width),
      height: Math.round(cameraHeight),             // Camera frame height on screen
      targetHeight: Math.round(currentRect.height), // Full target height selected by user (e.g. 4000px)
      dpr: dpr,
      viewportWidth: window.innerWidth, // lets the stitcher derive the real screenshot scale
      fullPage: !!opts.fullPage
    };

    removeOverlay();
    showLockedBox(region);

    // Notify Service Worker and Scroll Inspector
    chrome.runtime.sendMessage({
      action: 'INIT_STITCHER',
      region: region,
      dpr: dpr,
      page: { title: document.title, url: location.href, host: location.hostname }
    }, () => {
      if (window.ScrollShotInspector) {
        window.ScrollShotInspector.startCaptureSession(region, opts.scrollTarget);
      }
    });
  }

  function showLockedBox(region) {
    hideLockedBox();

    lockedBox = document.createElement('div');
    lockedBox.id = 'scrollshot-locked-box-element';
    lockedBox.className = 'scrollshot-locked-box';
    lockedBox.style.left = `${region.x}px`;
    lockedBox.style.top = `${region.y}px`;
    lockedBox.style.width = `${region.width}px`;
    lockedBox.style.height = `${region.height}px`;

    const badge = document.createElement('div');
    badge.className = 'scrollshot-locked-badge';
    badge.textContent = region.fullPage ? '🔒 Full Page' : '🔒 Region Locked';
    lockedBox.appendChild(badge);

    (document.documentElement || document.body).appendChild(lockedBox);
  }

  function hideLockedBox() {
    if (lockedBox && lockedBox.parentNode) {
      lockedBox.parentNode.removeChild(lockedBox);
    }
    lockedBox = null;
  }

  function hideForCapture() {
    if (lockedBox) {
      lockedBox.style.display = 'none';
    }
  }

  function showAfterCapture() {
    if (lockedBox) {
      lockedBox.style.display = 'block';
    }
  }

  function onKeyDown(e) {
    if (e.key === 'Escape') {
      removeOverlay();
      hideLockedBox();
      if (window.ScrollShotInspector) {
        window.ScrollShotInspector.cancelCapture();
      }
    }
    else if (e.key === 'Enter' || e.key === ' ') {
      if (currentRect && currentRect.width >= 20 && currentRect.height >= 20) {
        e.preventDefault();
        e.stopPropagation();
        confirmAndStartCapture();
      }
    }
  }

  function removeOverlay() {
    stopEdgeScroll();
    hoverTarget = null;
    hoverBox = null;
    hintPill = null;
    document.removeEventListener('keydown', onKeyDown);
    document.removeEventListener('mousemove', onMouseMove);
    document.removeEventListener('mouseup', onMouseUp);

    if (overlayContainer && overlayContainer.parentNode) {
      overlayContainer.parentNode.removeChild(overlayContainer);
    }
    overlayContainer = null;
    selectionBox = null;
    dimensionBadge = null;
    confirmBar = null;
    currentMode = MODE.IDLE;
    activeHandle = null;
    initialRect = null;
  }

  window.ScrollShotOverlay = {
    showLockedBox,
    hideLockedBox,
    hideForCapture,
    showAfterCapture,
    removeOverlay
  };

  // Message listener
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.action === 'INIT_OVERLAY') {
      const delay = Math.max(0, Math.min(30, parseInt(msg.delay, 10) || 0));
      const start = msg.mode === 'full' ? startFullPage : initOverlay;
      if (delay > 0) {
        startCountdown(delay, start);
      } else {
        start();
      }
      sendResponse({ status: 'ok' });
    }
    else if (msg.action === 'SHOW_PREVIEW') {
      hideLockedBox();
      showPreviewModal(msg.dataUrl, msg.width, msg.height, msg.historyId, msg.css);
      sendResponse({ status: 'ok' });
    }
  });

  // Delayed capture: lets the user open menus / hover states before selecting
  let countdownTimer = null;
  function startCountdown(seconds, done) {
    const prev = document.getElementById('scrollshot-countdown');
    if (prev) prev.remove();
    if (countdownTimer) clearInterval(countdownTimer);

    const badge = document.createElement('div');
    badge.id = 'scrollshot-countdown';
    badge.className = 'scrollshot-countdown';
    badge.textContent = String(seconds);
    (document.documentElement || document.body).appendChild(badge);

    let remaining = seconds;
    countdownTimer = setInterval(() => {
      remaining--;
      if (remaining <= 0) {
        clearInterval(countdownTimer);
        countdownTimer = null;
        badge.remove();
        done();
      } else {
        badge.textContent = String(remaining);
      }
    }, 1000);
  }

  const FORMATS = {
    png: { mime: 'image/png', label: 'PNG' },
    jpg: { mime: 'image/jpeg', label: 'JPG' },
    webp: { mime: 'image/webp', label: 'WebP' }
  };

  // Smart file naming: scrollshot_{domain}_{date}_{time}.{ext}
  function buildFilename(ext) {
    const pad = (n) => String(n).padStart(2, '0');
    const d = new Date();
    const date = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
    const time = `${pad(d.getHours())}-${pad(d.getMinutes())}-${pad(d.getSeconds())}`;
    const domain = (location.hostname || 'page').replace(/^www\./, '').replace(/[^a-z0-9.-]/gi, '_');
    return `scrollshot_${domain}_${date}_${time}.${ext}`;
  }

  // Re-encode the stitched PNG into the chosen format (JPG gets a white background)
  function convertDataUrl(pngDataUrl, format) {
    if (format === 'png') return Promise.resolve(pngDataUrl);
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => {
        const c = document.createElement('canvas');
        c.width = img.naturalWidth;
        c.height = img.naturalHeight;
        const cx = c.getContext('2d');
        if (format === 'jpg') {
          cx.fillStyle = '#FFFFFF';
          cx.fillRect(0, 0, c.width, c.height);
        }
        cx.drawImage(img, 0, 0);
        resolve(c.toDataURL(FORMATS[format].mime, 0.92));
      };
      img.onerror = () => reject(new Error('Could not decode capture'));
      img.src = pngDataUrl;
    });
  }

  // ---------- Preview + editor (crop, blur, box, highlight) ----------
  const TOOLS = {
    crop: { label: 'Crop', icon: '✂️', key: 'c', hint: 'Drag over the part you want to keep.' },
    blur: { label: 'Blur', icon: '▦', key: 'b', hint: 'Drag over private details to pixelate them.' },
    box: { label: 'Box', icon: '▢', key: 'r', hint: 'Drag to draw a red box around something.' },
    highlight: { label: 'Highlight', icon: '🖍️', key: 'h', hint: 'Drag to highlight text in yellow.' }
  };

  // Pixelates a rectangle in place (irreversible in the exported image)
  function pixelate(ctx, x, y, w, h, block) {
    const sw = Math.max(1, Math.ceil(w / block));
    const sh = Math.max(1, Math.ceil(h / block));
    const tmp = document.createElement('canvas');
    tmp.width = sw;
    tmp.height = sh;
    const tctx = tmp.getContext('2d');
    tctx.drawImage(ctx.canvas, x, y, w, h, 0, 0, sw, sh);
    ctx.save();
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(tmp, 0, 0, sw, sh, x, y, w, h);
    ctx.restore();
  }

  function applyOp(canvas, op) {
    const ctx = canvas.getContext('2d');
    const unit = Math.max(1, canvas.width / 640); // keeps strokes/blocks proportional to the image
    if (op.type === 'crop') {
      const tmp = document.createElement('canvas');
      tmp.width = op.w;
      tmp.height = op.h;
      tmp.getContext('2d').drawImage(canvas, op.x, op.y, op.w, op.h, 0, 0, op.w, op.h);
      canvas.width = op.w;
      canvas.height = op.h;
      canvas.getContext('2d').drawImage(tmp, 0, 0);
    } else if (op.type === 'blur') {
      pixelate(ctx, op.x, op.y, op.w, op.h, Math.max(8, Math.round(9 * unit)));
    } else if (op.type === 'box') {
      const lw = Math.max(3, Math.round(2.5 * unit));
      ctx.save();
      ctx.strokeStyle = '#FF3B30';
      ctx.lineWidth = lw;
      ctx.lineJoin = 'round';
      ctx.strokeRect(op.x + lw / 2, op.y + lw / 2, Math.max(1, op.w - lw), Math.max(1, op.h - lw));
      ctx.restore();
    } else if (op.type === 'highlight') {
      ctx.save();
      ctx.globalCompositeOperation = 'multiply';
      ctx.fillStyle = 'rgba(255, 221, 0, 0.55)';
      ctx.fillRect(op.x, op.y, op.w, op.h);
      ctx.restore();
    }
  }

  function makeThumb(canvas) {
    try {
      const tw = 360;
      const scale = tw / canvas.width;
      const srcH = Math.min(canvas.height, Math.round(270 / scale));
      const t = document.createElement('canvas');
      t.width = tw;
      t.height = Math.max(1, Math.round(srcH * scale));
      const tctx = t.getContext('2d');
      tctx.fillStyle = '#FFFFFF';
      tctx.fillRect(0, 0, t.width, t.height);
      tctx.drawImage(canvas, 0, 0, canvas.width, srcH, 0, 0, t.width, t.height);
      return t.toDataURL('image/jpeg', 0.8);
    } catch (e) {
      return '';
    }
  }

  let previewKeyHandler = null;
  // The preview shows the captured image (which can include cross-origin iframes the page
  // itself cannot read), so it lives in a closed shadow root that page scripts cannot reach.
  let previewHost = null;

  function closePreview() {
    if (previewHost) {
      previewHost.remove();
      previewHost = null;
    }
    if (previewKeyHandler) {
      window.removeEventListener('keydown', previewKeyHandler, true);
      previewKeyHandler = null;
    }
  }

  function showPreviewModal(dataUrl, width, height, historyId, css) {
    closePreview();

    const modal = document.createElement('div');
    modal.id = 'scrollshot-preview-modal';
    modal.className = 'scrollshot-preview-overlay';

    const toolButtons = Object.entries(TOOLS).map(([id, t]) =>
      `<button class="scrollshot-tool-btn" data-tool="${id}" title="${t.label} (${t.key.toUpperCase()})"><span class="scrollshot-tool-icon">${t.icon}</span>${t.label}</button>`
    ).join('');

    modal.innerHTML = `
      <div class="scrollshot-preview-card">
        <div class="scrollshot-preview-header">
          <span class="scrollshot-preview-title">✨ ScrollShot Capture</span>
          <div class="scrollshot-toolbox" role="toolbar" aria-label="Edit tools">
            ${toolButtons}
            <span class="scrollshot-tool-sep"></span>
            <button class="scrollshot-tool-btn" id="scrollshot-undo-btn" title="Undo (Ctrl+Z)" disabled>↶ Undo</button>
          </div>
          <div class="scrollshot-preview-meta">
            <span id="scrollshot-size-label"></span>
            <button class="scrollshot-btn scrollshot-btn-secondary scrollshot-btn-small" id="scrollshot-toggle-fit-btn">🔍 Fit to Screen</button>
          </div>
        </div>
        <div class="scrollshot-preview-body" id="scrollshot-preview-body-container">
          <div class="scrollshot-editor-stage" id="scrollshot-editor-stage">
            <canvas class="scrollshot-preview-img scrollshot-fit-screen" id="scrollshot-preview-img-el" aria-label="Stitched screenshot"></canvas>
            <div class="scrollshot-editor-sel" id="scrollshot-editor-sel"></div>
          </div>
        </div>
        <div class="scrollshot-preview-footer">
          <span class="scrollshot-editor-hint" id="scrollshot-editor-hint">Pick a tool to crop, blur or mark up the image, or export it as is.</span>
          <button class="scrollshot-btn scrollshot-btn-secondary" id="scrollshot-copy-btn">📋 Copy to Clipboard</button>
          <select class="scrollshot-format-select" id="scrollshot-format-select" title="Download format">
            <option value="png">PNG</option>
            <option value="jpg">JPG</option>
            <option value="webp">WebP</option>
          </select>
          <button class="scrollshot-btn scrollshot-btn-primary" id="scrollshot-download-btn">⬇️ Download PNG</button>
          <button class="scrollshot-btn scrollshot-btn-secondary" id="scrollshot-close-btn" title="Close (Esc)">Close</button>
        </div>
      </div>
    `;

    previewHost = document.createElement('scrollshot-preview');
    previewHost.style.cssText = 'all: initial; position: fixed; inset: 0; z-index: 2147483647;';
    const shadow = previewHost.attachShadow({ mode: 'closed' });
    const style = document.createElement('style');
    style.textContent = css || '';
    shadow.append(style, modal);
    (document.body || document.documentElement).appendChild(previewHost);
    const $ = (id) => shadow.getElementById(id);

    const canvas = $('scrollshot-preview-img-el');
    const stage = $('scrollshot-editor-stage');
    const selEl = $('scrollshot-editor-sel');
    const sizeLabel = $('scrollshot-size-label');
    const hintEl = $('scrollshot-editor-hint');
    const undoBtn = $('scrollshot-undo-btn');
    const fitBtn = $('scrollshot-toggle-fit-btn');

    const ops = [];
    let tool = null;
    let syncedVersion = 0; // ops.length last written to history
    const original = new Image();

    function render() {
      canvas.width = original.naturalWidth;
      canvas.height = original.naturalHeight;
      canvas.getContext('2d').drawImage(original, 0, 0);
      ops.forEach((op) => applyOp(canvas, op));
      sizeLabel.textContent = `${canvas.width} × ${canvas.height} px`;
      undoBtn.disabled = ops.length === 0;
    }

    function setTool(next) {
      tool = tool === next ? null : next;
      modal.querySelectorAll('[data-tool]').forEach((b) => b.classList.toggle('active', b.dataset.tool === tool));
      stage.classList.toggle('scrollshot-editing', !!tool);
      hintEl.textContent = tool ? TOOLS[tool].hint : 'Pick a tool to crop, blur or mark up the image, or export it as is.';
    }

    function undo() {
      if (!ops.length) return;
      ops.pop();
      render();
    }

    original.onload = render;
    original.src = dataUrl;

    modal.querySelectorAll('[data-tool]').forEach((b) => {
      b.onclick = () => setTool(b.dataset.tool);
    });
    undoBtn.onclick = undo;

    // ---- drag on the image to apply the active tool ----
    let drag = null;
    const toCanvas = (e) => {
      const r = canvas.getBoundingClientRect();
      const sx = canvas.width / r.width;
      const sy = canvas.height / r.height;
      return {
        x: Math.max(0, Math.min(canvas.width, (e.clientX - r.left) * sx)),
        y: Math.max(0, Math.min(canvas.height, (e.clientY - r.top) * sy)),
        cx: Math.max(0, Math.min(r.width, e.clientX - r.left)),
        cy: Math.max(0, Math.min(r.height, e.clientY - r.top))
      };
    };
    canvas.addEventListener('mousedown', (e) => {
      if (!tool || e.button !== 0) return;
      e.preventDefault();
      drag = { start: toCanvas(e), end: null };
      selEl.className = `scrollshot-editor-sel scrollshot-sel-${tool}`;
    });
    const onDragMove = (e) => {
      if (!drag) return;
      drag.end = toCanvas(e);
      const a = drag.start;
      const b = drag.end;
      const offX = canvas.offsetLeft;
      const offY = canvas.offsetTop;
      selEl.style.left = `${offX + Math.min(a.cx, b.cx)}px`;
      selEl.style.top = `${offY + Math.min(a.cy, b.cy)}px`;
      selEl.style.width = `${Math.abs(a.cx - b.cx)}px`;
      selEl.style.height = `${Math.abs(a.cy - b.cy)}px`;
      selEl.style.display = 'block';
    };
    const onDragEnd = () => {
      if (!drag) return;
      const { start: a, end: b } = drag;
      drag = null;
      selEl.style.display = 'none';
      if (!b) return;
      const op = {
        type: tool,
        x: Math.round(Math.min(a.x, b.x)),
        y: Math.round(Math.min(a.y, b.y)),
        w: Math.round(Math.abs(a.x - b.x)),
        h: Math.round(Math.abs(a.y - b.y))
      };
      if (op.w < 4 || op.h < 4) return;
      ops.push(op);
      render();
      if (tool === 'crop') setTool(null); // one crop at a time feels most natural
    };
    window.addEventListener('mousemove', onDragMove, true);
    window.addEventListener('mouseup', onDragEnd, true);

    let isFit = true;
    fitBtn.onclick = () => {
      isFit = !isFit;
      canvas.className = `scrollshot-preview-img ${isFit ? 'scrollshot-fit-screen' : 'scrollshot-full-screen'}`;
      stage.style.setProperty('width', isFit ? 'auto' : '100%', 'important');
      fitBtn.textContent = isFit ? '🔍 Fit to Screen' : '🔍 100% Full Size';
    };

    const close = () => {
      window.removeEventListener('mousemove', onDragMove, true);
      window.removeEventListener('mouseup', onDragEnd, true);
      closePreview();
    };
    $('scrollshot-close-btn').onclick = close;

    // Keyboard: C/B/R/H tools, Ctrl+Z undo, Esc closes (or drops the active tool)
    previewKeyHandler = (e) => {
      if (!previewHost) return;
      const target = e.composedPath()[0] || e.target; // see through the shadow root
      const tag = (target && target.tagName || '').toLowerCase();
      if (tag === 'select' || tag === 'input' || tag === 'textarea') return;
      const key = e.key.toLowerCase();
      if (e.key === 'Escape') {
        e.preventDefault();
        e.stopPropagation();
        if (tool) setTool(null);
        else close();
      } else if ((e.ctrlKey || e.metaKey) && key === 'z') {
        e.preventDefault();
        e.stopPropagation();
        undo();
      } else if (!e.ctrlKey && !e.metaKey && !e.altKey) {
        const found = Object.entries(TOOLS).find(([, t]) => t.key === key);
        if (found) {
          e.preventDefault();
          e.stopPropagation();
          setTool(found[0]);
        }
      }
    };
    window.addEventListener('keydown', previewKeyHandler, true);

    // Exports use the edited canvas; edits are also written back to the history entry
    const getExportDataUrl = () => (ops.length ? canvas.toDataURL('image/png') : dataUrl);
    const syncHistory = (outUrl) => {
      if (!historyId || ops.length === syncedVersion) return;
      syncedVersion = ops.length;
      try {
        chrome.runtime.sendMessage({
          action: 'HISTORY_UPDATE',
          id: historyId,
          dataUrl: outUrl,
          width: canvas.width,
          height: canvas.height,
          thumb: makeThumb(canvas)
        }, () => void chrome.runtime.lastError);
      } catch (e) { /* extension reloaded: ignore */ }
    };

    const formatSelect = $('scrollshot-format-select');
    const downloadBtn = $('scrollshot-download-btn');
    const syncDownloadLabel = () => {
      downloadBtn.textContent = `⬇️ Download ${FORMATS[formatSelect.value].label}`;
    };
    try {
      chrome.storage.local.get({ exportFormat: 'png' }, (prefs) => {
        if (chrome.runtime.lastError) return;
        if (FORMATS[prefs.exportFormat]) {
          formatSelect.value = prefs.exportFormat;
          syncDownloadLabel();
        }
      });
    } catch (e) { /* storage unavailable: keep PNG */ }
    formatSelect.onchange = () => {
      syncDownloadLabel();
      try { chrome.storage.local.set({ exportFormat: formatSelect.value }); } catch (e) { /* ignore */ }
    };

    downloadBtn.onclick = async () => {
      const format = formatSelect.value;
      try {
        const pngUrl = getExportDataUrl();
        syncHistory(pngUrl);
        const outUrl = await convertDataUrl(pngUrl, format);
        chrome.runtime.sendMessage({
          action: 'DOWNLOAD_IMAGE',
          dataUrl: outUrl,
          filename: buildFilename(format)
        });
      } catch (err) {
        console.error('Download failed:', err);
        downloadBtn.textContent = '⚠️ Export failed';
        setTimeout(syncDownloadLabel, 2000);
      }
    };

    const copyBtn = $('scrollshot-copy-btn');
    copyBtn.onclick = async () => {
      try {
        const pngUrl = getExportDataUrl();
        syncHistory(pngUrl);
        const blob = await (await fetch(pngUrl)).blob();
        await navigator.clipboard.write([
          new ClipboardItem({ [blob.type]: blob })
        ]);
        copyBtn.textContent = '✅ Copied!';
        setTimeout(() => copyBtn.textContent = '📋 Copy to Clipboard', 2000);
      } catch (err) {
        console.warn('Failed to copy to clipboard:', err);
        copyBtn.textContent = '⚠️ Copy blocked - use Download';
        setTimeout(() => copyBtn.textContent = '📋 Copy to Clipboard', 2500);
      }
    };
  }
})();
