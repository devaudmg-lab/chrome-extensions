// ScrollShot Pro - Selection Overlay Content Script with Full Selection Height Pipeline

(function () {
  if (window.__scrollshotOverlayLoaded && window.ScrollShotOverlay) return;
  window.__scrollshotOverlayLoaded = true;

  const MODE = {
    IDLE: 'IDLE',
    DRAWING: 'DRAWING',
    ADJUSTING: 'ADJUSTING',
    RESIZING: 'RESIZING',
    MOVING: 'MOVING'
  };

  let currentMode = MODE.IDLE;
  let overlayContainer = null;
  let selectionBox = null;
  let dimensionBadge = null;
  let confirmBar = null;
  let lockedBox = null;

  let activeHandle = null;
  let dragStartX = 0;
  let dragStartY = 0;
  let initialRect = null; // Snapshot of rect at start of drag
  let currentRect = null; // { pageX, pageY, width, height }

  function initOverlay() {
    removeOverlay();
    hideLockedBox();

    currentMode = MODE.IDLE;

    overlayContainer = document.createElement('div');
    overlayContainer.id = 'scrollshot-overlay-container';

    selectionBox = document.createElement('div');
    selectionBox.className = 'scrollshot-selection-box';
    selectionBox.style.display = 'none';

    dimensionBadge = document.createElement('div');
    dimensionBadge.className = 'scrollshot-dimension-badge';
    dimensionBadge.style.display = 'none';

    selectionBox.appendChild(dimensionBadge);
    overlayContainer.appendChild(selectionBox);
    document.body.appendChild(overlayContainer);

    overlayContainer.addEventListener('mousedown', onMouseDownContainer);
    document.addEventListener('mousemove', onMouseMove);
    document.addEventListener('mouseup', onMouseUp);
    document.addEventListener('keydown', onKeyDown);
  }

  function onMouseDownContainer(e) {
    if (e.button !== 0) return;

    if (currentMode === MODE.IDLE && e.target === overlayContainer) {
      currentMode = MODE.DRAWING;
      dragStartX = e.pageX;
      dragStartY = e.pageY;
      currentRect = { pageX: dragStartX, pageY: dragStartY, width: 0, height: 0 };
      updateSelectionBox();
      selectionBox.style.display = 'block';
      dimensionBadge.style.display = 'block';
    }
  }

  // Edge auto-scroll: holding the pointer near the bottom/top edge while drawing or
  // resizing scrolls the page, so a selection can be taller than the viewport.
  const EDGE_PX = 40;
  const EDGE_STEP = 24;
  let lastClientX = 0;
  let lastClientY = 0;
  let edgeScrollTimer = null;

  function applyPointer(pageX, pageY) {
    if (currentMode === MODE.DRAWING) {
      const x = Math.min(dragStartX, pageX);
      const y = Math.min(dragStartY, pageY);
      currentRect = { pageX: x, pageY: y, width: Math.abs(pageX - dragStartX), height: Math.abs(pageY - dragStartY) };
      updateSelectionBox();
    }
    else if (currentMode === MODE.RESIZING && initialRect && activeHandle) {
      calculateResizedRect(pageX - dragStartX, pageY - dragStartY);
      updateSelectionBox();
    }
    else if (currentMode === MODE.MOVING && initialRect) {
      currentRect.pageX = initialRect.pageX + (pageX - dragStartX);
      currentRect.pageY = initialRect.pageY + (pageY - dragStartY);
      updateSelectionBox();
    }
  }

  function edgeScrollTick() {
    if (currentMode !== MODE.DRAWING && currentMode !== MODE.RESIZING) {
      stopEdgeScroll();
      return;
    }
    let dy = 0;
    if (lastClientY >= window.innerHeight - EDGE_PX) dy = EDGE_STEP;
    else if (lastClientY <= EDGE_PX) dy = -EDGE_STEP;
    if (dy === 0) {
      stopEdgeScroll();
      return;
    }
    const before = window.scrollY;
    window.scrollBy(0, dy);
    if (window.scrollY !== before) {
      applyPointer(lastClientX + window.scrollX, lastClientY + window.scrollY);
    }
  }

  function stopEdgeScroll() {
    if (edgeScrollTimer) {
      clearInterval(edgeScrollTimer);
      edgeScrollTimer = null;
    }
  }

  function onMouseMove(e) {
    lastClientX = e.clientX;
    lastClientY = e.clientY;
    applyPointer(e.pageX, e.pageY);

    const nearEdge = e.clientY >= window.innerHeight - EDGE_PX || e.clientY <= EDGE_PX;
    if (nearEdge && !edgeScrollTimer && (currentMode === MODE.DRAWING || currentMode === MODE.RESIZING)) {
      edgeScrollTimer = setInterval(edgeScrollTick, 30);
    }
  }

  function onMouseUp(e) {
    stopEdgeScroll();
    if (currentMode === MODE.DRAWING) {
      if (!currentRect || currentRect.width < 20 || currentRect.height < 20) {
        removeOverlay();
        return;
      }
      currentMode = MODE.ADJUSTING;
      enterAdjustMode();
    }
    else if (currentMode === MODE.RESIZING || currentMode === MODE.MOVING) {
      currentMode = MODE.ADJUSTING;
      activeHandle = null;
      initialRect = null;
    }
  }

  function enterAdjustMode() {
    renderResizeHandles();
    renderConfirmBar();

    selectionBox.onmousedown = (e) => {
      if (e.target.classList.contains('scrollshot-resize-handle')) return;
      if (e.target.closest('.scrollshot-confirm-bar')) return;

      currentMode = MODE.MOVING;
      dragStartX = e.pageX;
      dragStartY = e.pageY;
      initialRect = { ...currentRect };
      e.stopPropagation();
    };
  }

  function renderResizeHandles() {
    removeResizeHandles();

    const handles = ['nw', 'ne', 'sw', 'se', 'n', 's', 'w', 'e'];
    handles.forEach(type => {
      const handle = document.createElement('div');
      handle.className = `scrollshot-resize-handle handle-${type}`;
      handle.dataset.handle = type;

      handle.onmousedown = (e) => {
        e.stopPropagation();
        e.preventDefault();
        currentMode = MODE.RESIZING;
        activeHandle = type;
        dragStartX = e.pageX;
        dragStartY = e.pageY;
        initialRect = { ...currentRect };
      };

      selectionBox.appendChild(handle);
    });
  }

  function removeResizeHandles() {
    if (!selectionBox) return;
    const existing = selectionBox.querySelectorAll('.scrollshot-resize-handle');
    existing.forEach(h => h.remove());
  }

  function renderConfirmBar() {
    removeConfirmBar();

    confirmBar = document.createElement('div');
    confirmBar.className = 'scrollshot-confirm-bar';
    confirmBar.innerHTML = `
      <button class="scrollshot-confirm-btn scrollshot-btn-start" id="scrollshot-start-btn">▶️ Start Capture <kbd style="font-size: 10px; opacity: 0.85; margin-left: 4px; background: rgba(255,255,255,0.25); padding: 1px 5px; border-radius: 4px;">Enter ↵</kbd></button>
      <button class="scrollshot-confirm-btn scrollshot-btn-cancel-select" id="scrollshot-cancel-select-btn">❌ Cancel <kbd style="font-size: 10px; opacity: 0.6; margin-left: 4px; background: rgba(255,255,255,0.15); padding: 1px 4px; border-radius: 4px;">Esc</kbd></button>
    `;

    selectionBox.appendChild(confirmBar);

    selectionBox.querySelector('#scrollshot-start-btn').onmousedown = (e) => e.stopPropagation();
    selectionBox.querySelector('#scrollshot-start-btn').onclick = (e) => {
      e.stopPropagation();
      confirmAndStartCapture();
    };

    selectionBox.querySelector('#scrollshot-cancel-select-btn').onmousedown = (e) => e.stopPropagation();
    selectionBox.querySelector('#scrollshot-cancel-select-btn').onclick = (e) => {
      e.stopPropagation();
      removeOverlay();
    };
  }

  function removeConfirmBar() {
    if (confirmBar && confirmBar.parentNode) {
      confirmBar.parentNode.removeChild(confirmBar);
    }
    confirmBar = null;
  }

  function calculateResizedRect(dx, dy) {
    if (!initialRect) return;

    let { pageX, pageY, width, height } = initialRect;

    switch (activeHandle) {
      case 'se':
        width = Math.max(20, initialRect.width + dx);
        height = Math.max(20, initialRect.height + dy);
        break;
      case 'sw':
        width = Math.max(20, initialRect.width - dx);
        pageX = initialRect.pageX + (initialRect.width - width);
        height = Math.max(20, initialRect.height + dy);
        break;
      case 'ne':
        width = Math.max(20, initialRect.width + dx);
        height = Math.max(20, initialRect.height - dy);
        pageY = initialRect.pageY + (initialRect.height - height);
        break;
      case 'nw':
        width = Math.max(20, initialRect.width - dx);
        pageX = initialRect.pageX + (initialRect.width - width);
        height = Math.max(20, initialRect.height - dy);
        pageY = initialRect.pageY + (initialRect.height - height);
        break;
      case 'n':
        height = Math.max(20, initialRect.height - dy);
        pageY = initialRect.pageY + (initialRect.height - height);
        break;
      case 's':
        height = Math.max(20, initialRect.height + dy);
        break;
      case 'w':
        width = Math.max(20, initialRect.width - dx);
        pageX = initialRect.pageX + (initialRect.width - width);
        break;
      case 'e':
        width = Math.max(20, initialRect.width + dx);
        break;
    }

    currentRect = { pageX, pageY, width, height };
  }

  function updateSelectionBox() {
    if (!currentRect || !selectionBox) return;
    selectionBox.style.left = `${currentRect.pageX}px`;
    selectionBox.style.top = `${currentRect.pageY}px`;
    selectionBox.style.width = `${currentRect.width}px`;
    selectionBox.style.height = `${currentRect.height}px`;

    const dpr = window.devicePixelRatio || 1;
    const pxW = Math.round(currentRect.width * dpr);
    const pxH = Math.round(currentRect.height * dpr);
    dimensionBadge.textContent = `${Math.round(currentRect.width)} × ${Math.round(currentRect.height)} px (${pxW} × ${pxH} native)`;
  }

  function confirmAndStartCapture() {
    if (!currentRect || currentRect.width < 20 || currentRect.height < 20) return;

    // If the user scrolled while extending the selection, bring its top edge back
    // into view: capture starts at the top of the region and scrolls downward.
    if (currentRect.pageY < window.scrollY || currentRect.pageY > window.scrollY + window.innerHeight - 20) {
      window.scrollTo({ top: Math.max(0, currentRect.pageY), behavior: 'instant' });
    }

    // Convert page coordinates to current viewport coordinates
    const viewportX = currentRect.pageX - window.scrollX;
    const viewportY = currentRect.pageY - window.scrollY;

    // Camera height on screen cannot exceed visible viewport
    const cameraHeight = Math.min(window.innerHeight - Math.max(0, viewportY), currentRect.height);

    const dpr = window.devicePixelRatio || 1;
    const region = {
      x: Math.round(viewportX),
      y: Math.round(viewportY),
      width: Math.round(currentRect.width),
      height: Math.round(cameraHeight),             // Camera frame height on screen
      targetHeight: Math.round(currentRect.height), // Full target height selected by user (e.g. 4000px)
      dpr: dpr,
      viewportWidth: window.innerWidth // lets the stitcher derive the real screenshot scale
    };

    removeOverlay();
    showLockedBox(region);

    // Notify Service Worker and Scroll Inspector
    chrome.runtime.sendMessage({
      action: 'INIT_STITCHER',
      region: region,
      dpr: dpr
    }, () => {
      if (window.ScrollShotInspector) {
        window.ScrollShotInspector.startCaptureSession(region);
      }
    });
  }

  function showLockedBox(region) {
    hideLockedBox();

    lockedBox = document.createElement('div');
    lockedBox.id = 'scrollshot-locked-box-element';
    lockedBox.className = 'scrollshot-locked-box';
    lockedBox.style.left = `${region.x}px`;
    lockedBox.style.top = `${region.y}px`;
    lockedBox.style.width = `${region.width}px`;
    lockedBox.style.height = `${region.height}px`;

    const badge = document.createElement('div');
    badge.className = 'scrollshot-locked-badge';
    badge.textContent = '🔒 Region Locked';
    lockedBox.appendChild(badge);

    (document.documentElement || document.body).appendChild(lockedBox);
  }

  function hideLockedBox() {
    if (lockedBox && lockedBox.parentNode) {
      lockedBox.parentNode.removeChild(lockedBox);
    }
    lockedBox = null;
  }

  function hideForCapture() {
    if (lockedBox) {
      lockedBox.style.display = 'none';
    }
  }

  function showAfterCapture() {
    if (lockedBox) {
      lockedBox.style.display = 'block';
    }
  }

  function onKeyDown(e) {
    if (e.key === 'Escape') {
      removeOverlay();
      hideLockedBox();
      if (window.ScrollShotInspector) {
        window.ScrollShotInspector.cancelCapture();
      }
    }
    else if (e.key === 'Enter' || e.key === ' ') {
      if (currentRect && currentRect.width >= 20 && currentRect.height >= 20) {
        e.preventDefault();
        e.stopPropagation();
        confirmAndStartCapture();
      }
    }
  }

  function removeOverlay() {
    stopEdgeScroll();
    document.removeEventListener('keydown', onKeyDown);
    document.removeEventListener('mousemove', onMouseMove);
    document.removeEventListener('mouseup', onMouseUp);

    if (overlayContainer && overlayContainer.parentNode) {
      overlayContainer.parentNode.removeChild(overlayContainer);
    }
    overlayContainer = null;
    selectionBox = null;
    dimensionBadge = null;
    confirmBar = null;
    currentMode = MODE.IDLE;
    activeHandle = null;
    initialRect = null;
  }

  window.ScrollShotOverlay = {
    showLockedBox,
    hideLockedBox,
    hideForCapture,
    showAfterCapture,
    removeOverlay
  };

  // Message listener
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.action === 'INIT_OVERLAY') {
      const delay = Math.max(0, Math.min(30, parseInt(msg.delay, 10) || 0));
      if (delay > 0) {
        startCountdown(delay, initOverlay);
      } else {
        initOverlay();
      }
      sendResponse({ status: 'ok' });
    }
    else if (msg.action === 'SHOW_PREVIEW') {
      hideLockedBox();
      showPreviewModal(msg.dataUrl, msg.width, msg.height);
      sendResponse({ status: 'ok' });
    }
  });

  // Delayed capture: lets the user open menus / hover states before selecting
  let countdownTimer = null;
  function startCountdown(seconds, done) {
    const prev = document.getElementById('scrollshot-countdown');
    if (prev) prev.remove();
    if (countdownTimer) clearInterval(countdownTimer);

    const badge = document.createElement('div');
    badge.id = 'scrollshot-countdown';
    badge.className = 'scrollshot-countdown';
    badge.textContent = String(seconds);
    (document.documentElement || document.body).appendChild(badge);

    let remaining = seconds;
    countdownTimer = setInterval(() => {
      remaining--;
      if (remaining <= 0) {
        clearInterval(countdownTimer);
        countdownTimer = null;
        badge.remove();
        done();
      } else {
        badge.textContent = String(remaining);
      }
    }, 1000);
  }

  const FORMATS = {
    png: { mime: 'image/png', label: 'PNG' },
    jpg: { mime: 'image/jpeg', label: 'JPG' },
    webp: { mime: 'image/webp', label: 'WebP' }
  };

  // Smart file naming: scrollshot_{domain}_{date}_{time}.{ext}
  function buildFilename(ext) {
    const pad = (n) => String(n).padStart(2, '0');
    const d = new Date();
    const date = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
    const time = `${pad(d.getHours())}-${pad(d.getMinutes())}-${pad(d.getSeconds())}`;
    const domain = (location.hostname || 'page').replace(/^www\./, '').replace(/[^a-z0-9.-]/gi, '_');
    return `scrollshot_${domain}_${date}_${time}.${ext}`;
  }

  // Re-encode the stitched PNG into the chosen format (JPG gets a white background)
  function convertDataUrl(pngDataUrl, format) {
    if (format === 'png') return Promise.resolve(pngDataUrl);
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => {
        const c = document.createElement('canvas');
        c.width = img.naturalWidth;
        c.height = img.naturalHeight;
        const cx = c.getContext('2d');
        if (format === 'jpg') {
          cx.fillStyle = '#FFFFFF';
          cx.fillRect(0, 0, c.width, c.height);
        }
        cx.drawImage(img, 0, 0);
        resolve(c.toDataURL(FORMATS[format].mime, 0.92));
      };
      img.onerror = () => reject(new Error('Could not decode capture'));
      img.src = pngDataUrl;
    });
  }

  function showPreviewModal(dataUrl, width, height) {
    const existing = document.getElementById('scrollshot-preview-modal');
    if (existing) existing.remove();

    const modal = document.createElement('div');
    modal.id = 'scrollshot-preview-modal';
    modal.className = 'scrollshot-preview-overlay';

    modal.innerHTML = `
      <div class="scrollshot-preview-card">
        <div class="scrollshot-preview-header">
          <span>✨ ScrollShot Stitched Capture</span>
          <div style="display: flex; align-items: center; gap: 12px;">
            <span style="font-size: 13px; color: #94A3B8;">${width} × ${height} px</span>
            <button class="scrollshot-btn scrollshot-btn-secondary" id="scrollshot-toggle-fit-btn" style="padding: 4px 10px; font-size: 12px;">🔍 Fit to Screen</button>
          </div>
        </div>
        <div class="scrollshot-preview-body" id="scrollshot-preview-body-container">
          <img src="${dataUrl}" class="scrollshot-preview-img scrollshot-fit-screen" id="scrollshot-preview-img-el" alt="Stitched Screenshot" />
        </div>
        <div class="scrollshot-preview-footer">
          <button class="scrollshot-btn scrollshot-btn-secondary" id="scrollshot-copy-btn">📋 Copy to Clipboard</button>
          <select class="scrollshot-format-select" id="scrollshot-format-select" title="Download format">
            <option value="png">PNG</option>
            <option value="jpg">JPG</option>
            <option value="webp">WebP</option>
          </select>
          <button class="scrollshot-btn scrollshot-btn-primary" id="scrollshot-download-btn">⬇️ Download PNG</button>
          <button class="scrollshot-btn scrollshot-btn-secondary" id="scrollshot-close-btn">Close</button>
        </div>
      </div>
    `;

    document.body.appendChild(modal);

    const imgEl = document.getElementById('scrollshot-preview-img-el');
    const fitBtn = document.getElementById('scrollshot-toggle-fit-btn');

    let isFit = true;

    fitBtn.onclick = () => {
      isFit = !isFit;
      if (isFit) {
        imgEl.className = 'scrollshot-preview-img scrollshot-fit-screen';
        fitBtn.textContent = '🔍 Fit to Screen';
      } else {
        imgEl.className = 'scrollshot-preview-img scrollshot-full-screen';
        fitBtn.textContent = '🔍 100% Full Size';
      }
    };

    document.getElementById('scrollshot-close-btn').onclick = () => modal.remove();

    const formatSelect = document.getElementById('scrollshot-format-select');
    const downloadBtn = document.getElementById('scrollshot-download-btn');
    const syncDownloadLabel = () => {
      downloadBtn.textContent = `⬇️ Download ${FORMATS[formatSelect.value].label}`;
    };
    try {
      chrome.storage.local.get({ exportFormat: 'png' }, (prefs) => {
        if (chrome.runtime.lastError) return;
        if (FORMATS[prefs.exportFormat]) {
          formatSelect.value = prefs.exportFormat;
          syncDownloadLabel();
        }
      });
    } catch (e) { /* storage unavailable: keep PNG */ }
    formatSelect.onchange = () => {
      syncDownloadLabel();
      try { chrome.storage.local.set({ exportFormat: formatSelect.value }); } catch (e) { /* ignore */ }
    };

    downloadBtn.onclick = async () => {
      const format = formatSelect.value;
      try {
        const outUrl = await convertDataUrl(dataUrl, format);
        chrome.runtime.sendMessage({
          action: 'DOWNLOAD_IMAGE',
          dataUrl: outUrl,
          filename: buildFilename(format)
        });
      } catch (err) {
        console.error('Download failed:', err);
        downloadBtn.textContent = '⚠️ Export failed';
        setTimeout(syncDownloadLabel, 2000);
      }
    };

    document.getElementById('scrollshot-copy-btn').onclick = async () => {
      try {
        const response = await fetch(dataUrl);
        const blob = await response.blob();
        await navigator.clipboard.write([
          new ClipboardItem({ [blob.type]: blob })
        ]);
        const copyBtn = document.getElementById('scrollshot-copy-btn');
        copyBtn.textContent = '✅ Copied!';
        setTimeout(() => copyBtn.textContent = '📋 Copy to Clipboard', 2000);
      } catch (err) {
        console.error('Failed to copy to clipboard:', err);
        const copyBtn = document.getElementById('scrollshot-copy-btn');
        copyBtn.textContent = '⚠️ Copy blocked - use Download';
        setTimeout(() => copyBtn.textContent = '📋 Copy to Clipboard', 2500);
      }
    };
  }
})();
