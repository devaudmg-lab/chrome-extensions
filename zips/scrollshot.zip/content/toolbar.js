// ScrollShot Pro - Floating Toolbar Content Script (Shadow DOM)

(function () {
  if (window.ScrollShotToolbar) return;

  let hostElement = null;
  let shadowRoot = null;
  let callbacks = {};

  const Toolbar = {
    showToolbar(opts = {}) {
      callbacks = opts;
      this.hideToolbar();

      hostElement = document.createElement('div');
      hostElement.id = 'scrollshot-toolbar-host';
      hostElement.style.cssText = `
        position: fixed !important;
        bottom: 24px !important;
        left: 50% !important;
        transform: translateX(-50%) !important;
        z-index: 2147483646 !important;
        pointer-events: auto !important;
      `;

      shadowRoot = hostElement.attachShadow({ mode: 'open' });

      shadowRoot.innerHTML = `
        <style>
          .toolbar {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 20px;
            background: rgba(15, 23, 42, 0.94);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            border: 1px solid rgba(255, 255, 255, 0.12);
            border-radius: 999px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4), 0 0 0 1px rgba(255, 255, 255, 0.05);
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            color: #F8FAFC;
            font-size: 13px;
            font-weight: 500;
            user-select: none;
            box-sizing: border-box;
          }

          .status-badge {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 5px 12px;
            background: rgba(0, 122, 255, 0.15);
            border: 1px solid rgba(0, 122, 255, 0.3);
            border-radius: 999px;
            color: #38BDF8;
            font-size: 12px;
            font-weight: 600;
          }

          .pulse-dot {
            width: 8px;
            height: 8px;
            background: #38BDF8;
            border-radius: 50%;
            animation: pulse 1.5s infinite;
          }

          @keyframes pulse {
            0% { transform: scale(0.95); opacity: 1; }
            50% { transform: scale(1.2); opacity: 0.5; }
            100% { transform: scale(0.95); opacity: 1; }
          }

          .btn-group {
            display: flex;
            align-items: center;
            gap: 8px;
          }

          .btn {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 7px 18px;
            border-radius: 999px;
            border: none;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.15s ease;
          }

          .btn-autoscroll {
            background: rgba(0, 122, 255, 0.2);
            color: #38BDF8;
            border: 1px solid rgba(0, 122, 255, 0.4);
          }

          .btn-autoscroll:hover {
            background: rgba(0, 122, 255, 0.35);
          }

          .btn-finish {
            background: #10B981;
            color: #FFFFFF;
            box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);
          }

          .btn-finish:hover {
            background: #059669;
            transform: translateY(-1px);
            box-shadow: 0 6px 16px rgba(16, 185, 129, 0.4);
          }

          .btn-cancel {
            background: rgba(239, 68, 68, 0.15);
            color: #FCA5A5;
            border: 1px solid rgba(239, 68, 68, 0.3);
          }

          .btn-cancel:hover {
            background: rgba(239, 68, 68, 0.3);
          }
        </style>

        <div class="toolbar" id="toolbar-root">
          <div class="status-badge">
            <div class="pulse-dot"></div>
            <span id="frame-count">Capturing... (1 frame)</span>
          </div>

          <div class="btn-group">
            <button class="btn btn-autoscroll" id="autoscroll-btn">⚡ Auto Scroll</button>
            <button class="btn btn-finish" id="finish-btn">✅ Finish</button>
            <button class="btn btn-cancel" id="cancel-btn">❌ Cancel</button>
          </div>
        </div>
      `;

      (document.documentElement || document.body).appendChild(hostElement);

      const autoScrollBtn = shadowRoot.getElementById('autoscroll-btn');
      const finishBtn = shadowRoot.getElementById('finish-btn');
      const cancelBtn = shadowRoot.getElementById('cancel-btn');

      autoScrollBtn.onclick = () => {
        if (callbacks.onToggleAutoScroll) callbacks.onToggleAutoScroll();
      };

      finishBtn.onclick = () => {
        if (callbacks.onFinish) callbacks.onFinish();
      };

      cancelBtn.onclick = () => {
        if (callbacks.onCancel) callbacks.onCancel();
      };
    },

    updateAutoScrollState(isAutoScrolling) {
      if (!shadowRoot) return;
      const btn = shadowRoot.getElementById('autoscroll-btn');
      if (btn) {
        btn.textContent = isAutoScrolling ? '⏸️ Pause Auto' : '⚡ Auto Scroll';
        btn.style.background = isAutoScrolling ? 'rgba(234, 179, 8, 0.25)' : 'rgba(0, 122, 255, 0.2)';
        btn.style.color = isAutoScrolling ? '#FACC15' : '#38BDF8';
        btn.style.borderColor = isAutoScrolling ? 'rgba(234, 179, 8, 0.4)' : 'rgba(0, 122, 255, 0.4)';
      }
    },

    updateFrameCount(count) {
      if (!shadowRoot) return;
      const countEl = shadowRoot.getElementById('frame-count');
      if (countEl) {
        countEl.textContent = `Capturing... (${count} frames)`;
      }
    },

    hideForCapture() {
      if (hostElement) {
        hostElement.style.display = 'none';
      }
    },

    showAfterCapture() {
      if (hostElement) {
        hostElement.style.display = 'block';
      }
    },

    hideToolbar() {
      if (hostElement && hostElement.parentNode) {
        hostElement.parentNode.removeChild(hostElement);
      }
      hostElement = null;
      shadowRoot = null;
    }
  };

  window.ScrollShotToolbar = Toolbar;
})();
