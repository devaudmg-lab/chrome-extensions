/**
 * Master Side Panel Script for ContextSearch (Phase 4).
 * Coordinates parallel multi-source search aggregation, AI synthesis, and pinned bookmarks.
 */

import { aggregateSearch } from '../search/search-aggregator.js';
import { queryAI } from '../ai/ai-client.js';
import { renderMarkdown } from '../content/popup/markdown-renderer.js';
import { renderResultCard } from './components/result-card-view.js';
import {
  getPinnedResults,
  togglePinResult,
  recordSearchSession,
  getSearchHistory,
  findPreviousSearch,
  formatTimeAgo,
  getVisitedResults,
  markResultVisited
} from '../search/history-manager.js';
import { getSettings } from '../shared/settings-manager.js';
import { ACTION_TYPES } from '../shared/constants.js';
import { escapeHtml } from '../shared/utils.js';

let activeContext = {
  selection: { text: 'AbortController' },
  page: { domain: 'developer.mozilla.org', title: 'Web API' },
  detected: { siteType: 'mdn', language: 'javascript', category: 'api' }
};

let allResults = [];
let activeFilter = 'all';
let activeSearchId = 0;
let activeAiController = null;
let lastAiAnswer = '';
let pinnedUrls = new Set();
let visitedResults = {};

function applyTheme(theme) {
  let resolved = theme === 'light' ? 'light' : 'dark';
  if (theme === 'system' && window.matchMedia) {
    resolved = window.matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark';
  }
  document.body.className = resolved === 'light' ? 'theme-light' : 'theme-dark';
}

async function initSidePanel() {
  const settings = await getSettings();
  applyTheme(settings.theme);
  if (settings.theme === 'system' && window.matchMedia) {
    window.matchMedia('(prefers-color-scheme: light)').addEventListener('change', () => applyTheme('system'));
  }

  // Load pinned state
  const pinned = await getPinnedResults();
  pinnedUrls = new Set(pinned.map(p => p.url));
  visitedResults = await getVisitedResults();

  // Check if context was passed from background (palette / context menu), then the active tab
  let hasContext = false;
  try {
    const pending = await chrome.runtime.sendMessage({ type: 'GET_PENDING_SIDEPANEL_CONTEXT' }).catch(() => null);
    if (pending && pending.context && pending.context.selection?.text) {
      activeContext = normalizeContext(pending.context);
      hasContext = true;
    }
  } catch (err) {
    console.debug('[ContextSearch SidePanel] Pending context notice:', err);
  }

  try {
    if (!hasContext && typeof chrome !== 'undefined' && chrome.tabs && chrome.tabs.query) {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab && tab.id) {
        const response = await chrome.tabs.sendMessage(tab.id, { type: 'GET_CURRENT_CONTEXT' }).catch(() => null);
        if (response && response.context && response.context.selection?.text) {
          activeContext = normalizeContext(response.context);
          hasContext = true;
        }
      }
    }
  } catch (err) {
    console.debug('[ContextSearch SidePanel] Context fetch notice:', err);
  }

  updateContextBanner();
  if (!hasContext) document.getElementById('sp-context-banner').style.display = 'none';

  const searchInput = document.getElementById('sp-search-input');

  // Bind event listeners
  bindEvents();

  if (hasContext) {
    searchInput.value = activeContext.selection.text;
    runDeepResearch(searchInput.value.trim());
  } else {
    showIdleState();
    searchInput.focus();
  }
}

/**
 * Fill in missing context fields so partial contexts (e.g. from the context menu) render safely.
 * @param {object} ctx
 * @returns {object}
 */
function normalizeContext(ctx = {}) {
  return {
    ...ctx,
    selection: { ...(ctx.selection || {}) },
    page: { ...(ctx.page || {}) },
    detected: { ...(ctx.detected || {}) }
  };
}

function showIdleState() {
  document.getElementById('sp-ai-shimmer').style.display = 'none';
  const aiBody = document.getElementById('sp-ai-body');
  aiBody.style.display = 'block';
  aiBody.innerHTML = '<p>Select text on any page and choose <strong>🔬 Deep Research</strong>, or type a query above and press Enter.</p><p class="sp-idle-tip">Tip: press <kbd>/</kbd> to jump to the search box and <kbd>Esc</kbd> to close drawers.</p>';
  document.getElementById('sp-ai-status').textContent = 'Ready';
  document.getElementById('sp-results-shimmer').style.display = 'none';
  document.getElementById('sp-results-stats').textContent = 'No search yet';
  renderRecentSearches(true);
}

/**
 * Show recent searches as a clickable list.
 * @param {boolean} [quietIfEmpty=false] Hide the section entirely when there is no history
 */
async function renderRecentSearches(quietIfEmpty = false) {
  const section = document.getElementById('sp-recent-section');
  const list = document.getElementById('sp-recent-list');
  const history = await getSearchHistory();

  if (history.length === 0) {
    if (quietIfEmpty) {
      section.style.display = 'none';
      return;
    }
    list.innerHTML = '<div class="sp-empty-note">No searches yet. Your recent research shows up here (stored only on this computer).</div>';
    section.style.display = 'flex';
    return;
  }

  list.innerHTML = history.slice(0, 12).map(h => `
    <button class="sp-recent-item" data-query="${escapeHtml(h.query)}" title="Search again">
      <span class="sp-recent-query">${escapeHtml(h.query)}</span>
      <span class="sp-recent-meta">${escapeHtml(h.language && h.language !== 'code' ? h.language + ' · ' : '')}${escapeHtml(formatTimeAgo(h.timestamp))}</span>
    </button>
  `).join('');

  list.querySelectorAll('.sp-recent-item').forEach(btn => {
    btn.addEventListener('click', () => {
      const q = btn.getAttribute('data-query') || '';
      const input = document.getElementById('sp-search-input');
      input.value = q;
      section.style.display = 'none';
      runDeepResearch(q);
    });
  });
  section.style.display = 'flex';
}

function visitedLabelFor(url) {
  const at = visitedResults[url];
  return at ? formatTimeAgo(at) : '';
}

function updateContextBanner() {
  const langTag = document.getElementById('sp-ctx-lang');
  const siteTag = document.getElementById('sp-ctx-site');
  const domainSnippet = document.getElementById('sp-ctx-domain');

  if (langTag) langTag.textContent = activeContext.detected.language || 'Code';
  if (siteTag) siteTag.textContent = activeContext.detected.siteType || 'Web';
  if (domainSnippet) domainSnippet.textContent = activeContext.page.domain || 'active tab';
}

async function runDeepResearch(query) {
  if (!query) return;

  const searchId = ++activeSearchId;
  const isCurrent = () => searchId === activeSearchId;
  if (activeAiController) activeAiController.abort();
  activeAiController = new AbortController();
  const aiSignal = activeAiController.signal;
  lastAiAnswer = '';
  const copyAiBtn = document.getElementById('sp-btn-copy-ai');
  if (copyAiBtn) copyAiBtn.style.display = 'none';

  const startTime = Date.now();
  allResults = [];

  // Reset UI
  const aiBody = document.getElementById('sp-ai-body');
  const aiShimmer = document.getElementById('sp-ai-shimmer');
  const aiStatus = document.getElementById('sp-ai-status');
  const resultsList = document.getElementById('sp-results-list');
  const resultsShimmer = document.getElementById('sp-results-shimmer');
  const statsBadge = document.getElementById('sp-results-stats');
  const latencyBadge = document.getElementById('sp-latency-badge');

  aiBody.style.display = 'none';
  aiShimmer.style.display = 'flex';
  aiStatus.textContent = 'Streaming...';

  resultsList.style.display = 'none';
  resultsShimmer.style.display = 'flex';
  statsBadge.textContent = 'Searching sources...';

  // 1. "Previously researched" hint, then record the session
  document.getElementById('sp-recent-section').style.display = 'none';
  const hint = document.getElementById('sp-history-hint');
  const previous = findPreviousSearch(query, await getSearchHistory());
  if (previous && Date.now() - previous.timestamp > 60000) {
    hint.textContent = `🕘 You researched this ${formatTimeAgo(previous.timestamp)}. Results you opened are marked ✓ Visited.`;
    hint.style.display = 'block';
  } else {
    hint.style.display = 'none';
  }
  await recordSearchSession(query, activeContext);

  // 2. Stream AI Synthesis in parallel
  queryAI({
    actionId: ACTION_TYPES.EXPLAIN,
    context: { ...activeContext, selection: { text: query } },
    signal: aiSignal,
    onChunk: (_chunk, accumulated) => {
      if (!isCurrent()) return;
      lastAiAnswer = accumulated;
      if (aiShimmer.style.display !== 'none') {
        aiShimmer.style.display = 'none';
        aiBody.style.display = 'block';
      }
      aiBody.innerHTML = renderMarkdown(accumulated);
    },
    onComplete: (final, meta) => {
      if (!isCurrent()) return;
      lastAiAnswer = final || lastAiAnswer;
      if (copyAiBtn && lastAiAnswer) copyAiBtn.style.display = 'inline-block';
      aiStatus.textContent = meta.cached ? '⚡ Cached' : `⚡ ${meta.provider}`;
    },
    onError: (err) => {
      if (!isCurrent() || aiSignal.aborted) return;
      aiShimmer.style.display = 'none';
      aiBody.style.display = 'block';
      aiBody.innerHTML = `<p style="color: #fda4af;">AI synthesis unavailable: ${escapeHtml(err?.message || 'unknown error')}. See verified sources below.</p>`;
      aiStatus.textContent = 'Notice';
    }
  }).catch(() => {});

  // 3. Parallel Aggregated Search
  await aggregateSearch({
    query,
    context: activeContext,
    onSourceResult: (_source, sourceResults) => {
      if (!isCurrent()) return;
      // Progressive update
      allResults.push(...sourceResults);
      updateFilterCounts();
      renderFilteredResults();

      resultsShimmer.style.display = 'none';
      resultsList.style.display = 'flex';
    },
    onComplete: (rankedItems) => {
      if (!isCurrent()) return;
      allResults = rankedItems;
      const duration = Date.now() - startTime;
      resultsShimmer.style.display = 'none';
      resultsList.style.display = 'flex';

      updateFilterCounts();
      renderFilteredResults();

      statsBadge.textContent = `${allResults.length} verified results`;
      latencyBadge.textContent = `⚡ ${duration}ms`;
    }
  });
}

function updateFilterCounts() {
  const counts = {
    all: allResults.length,
    mdn: allResults.filter(r => r.source === 'mdn').length,
    stackoverflow: allResults.filter(r => r.source === 'stackoverflow').length,
    github: allResults.filter(r => r.source === 'github').length,
    npm: allResults.filter(r => r.source === 'npm').length
  };

  document.getElementById('count-all').textContent = counts.all;
  document.getElementById('count-mdn').textContent = counts.mdn;
  document.getElementById('count-so').textContent = counts.stackoverflow;
  document.getElementById('count-gh').textContent = counts.github;
  document.getElementById('count-npm').textContent = counts.npm;
}

function renderFilteredResults() {
  const listContainer = document.getElementById('sp-results-list');
  let filtered = allResults;

  if (activeFilter !== 'all') {
    filtered = allResults.filter(r => r.source === activeFilter);
  }

  if (filtered.length === 0) {
    listContainer.innerHTML = `<div style="padding: 20px; text-align: center; color: var(--text-dim); font-size: 12px;">No results found for this filter.</div>`;
    return;
  }

  listContainer.innerHTML = filtered.map(item => {
    const isPinned = pinnedUrls.has(item.url);
    return renderResultCard(item, isPinned, visitedLabelFor(item.url));
  }).join('');

  attachCardEvents(listContainer);
}

function attachCardEvents(container) {
  container.querySelectorAll('a[href]').forEach(link => {
    const remember = () => {
      const card = link.closest('.cs-result-card');
      const url = card && card.getAttribute('data-url');
      if (!url) return;
      markResultVisited(url).then(v => { visitedResults = v; });
    };
    link.addEventListener('click', remember);
    link.addEventListener('auxclick', (e) => { if (e.button === 1) remember(); });
  });

  const pinButtons = container.querySelectorAll('.cs-card-action-btn[data-action="pin"]');
  pinButtons.forEach(btn => {
    btn.onclick = async (e) => {
      e.stopPropagation();
      const card = btn.closest('.cs-result-card');
      const url = card.getAttribute('data-url');
      const item = allResults.find(r => r.url === url);

      if (item) {
        const isNowPinned = await togglePinResult(item);
        if (isNowPinned) {
          pinnedUrls.add(url);
          btn.textContent = '📌';
          btn.classList.add('cs-pinned');
        } else {
          pinnedUrls.delete(url);
          btn.textContent = '📍';
          btn.classList.remove('cs-pinned');
        }
      }
    };
  });
}

async function renderPinnedDrawer() {
  const drawer = document.getElementById('sp-pinned-drawer');
  const list = document.getElementById('sp-pinned-list');
  const countSpan = document.getElementById('sp-pinned-count');

  const pinned = await getPinnedResults();
  countSpan.textContent = pinned.length;

  if (pinned.length === 0) {
    list.innerHTML = `<div style="padding: 20px; text-align: center; color: var(--text-dim); font-size: 12px;">No bookmarks pinned yet. Click 📍 on any search card to save.</div>`;
  } else {
    list.innerHTML = pinned.map(item => renderResultCard(item, true, visitedLabelFor(item.url))).join('');
    attachCardEvents(list);
  }

  drawer.style.display = 'flex';
}

function bindEvents() {
  const searchInput = document.getElementById('sp-search-input');
  const searchBtn = document.getElementById('sp-search-btn');

  const handleSearch = () => {
    const q = searchInput.value.trim();
    if (q) runDeepResearch(q);
  };

  searchBtn.addEventListener('click', handleSearch);
  searchInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') handleSearch();
  });

  // Filter chips
  const filterChips = document.querySelectorAll('.sp-filter-chip');
  filterChips.forEach(chip => {
    chip.addEventListener('click', () => {
      filterChips.forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      activeFilter = chip.getAttribute('data-filter') || 'all';
      renderFilteredResults();
    });
  });

  // Copy buttons on code blocks inside the AI answer
  document.getElementById('sp-ai-body').addEventListener('click', (e) => {
    const btn = e.target.closest && e.target.closest('.cs-code-copy-btn');
    if (!btn) return;
    navigator.clipboard.writeText(btn.getAttribute('data-code') || '').then(() => {
      btn.textContent = '✓ Copied';
      setTimeout(() => { btn.textContent = '📋 Copy'; }, 1500);
    }).catch(() => {});
  });

  // Copy AI answer
  const copyAiBtn = document.getElementById('sp-btn-copy-ai');
  if (copyAiBtn) {
    copyAiBtn.addEventListener('click', () => {
      if (!lastAiAnswer) return;
      navigator.clipboard.writeText(lastAiAnswer).then(() => {
        copyAiBtn.textContent = '✓';
        setTimeout(() => { copyAiBtn.textContent = '📋'; }, 1500);
      }).catch(() => {});
    });
  }

  // Pinned Bookmarks
  document.getElementById('sp-btn-bookmarks').addEventListener('click', () => {
    renderPinnedDrawer();
  });

  document.getElementById('sp-close-pinned-btn').addEventListener('click', () => {
    document.getElementById('sp-pinned-drawer').style.display = 'none';
  });

  // Recent searches
  document.getElementById('sp-btn-history').addEventListener('click', () => {
    const section = document.getElementById('sp-recent-section');
    if (section.style.display !== 'none') {
      section.style.display = 'none';
    } else {
      renderRecentSearches(false);
      section.scrollIntoView({ block: 'nearest' });
    }
  });
  document.getElementById('sp-close-recent-btn').addEventListener('click', () => {
    document.getElementById('sp-recent-section').style.display = 'none';
  });

  // Keyboard: "/" focuses search, Esc closes drawers
  document.addEventListener('keydown', (e) => {
    const tag = (e.target && e.target.tagName || '').toLowerCase();
    if (e.key === '/' && tag !== 'input' && tag !== 'textarea') {
      e.preventDefault();
      searchInput.focus();
      searchInput.select();
    } else if (e.key === 'Escape') {
      document.getElementById('sp-pinned-drawer').style.display = 'none';
      document.getElementById('sp-recent-section').style.display = 'none';
      if (tag === 'input') searchInput.blur();
    }
  });

  // Settings
  document.getElementById('sp-btn-settings').addEventListener('click', () => {
    if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.openOptionsPage) {
      chrome.runtime.openOptionsPage();
    }
  });

  // Listen for active context broadcast
  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener((msg) => {
      if (msg.type === 'CONTEXT_SEARCH_TRIGGER' && msg.context) {
        activeContext = normalizeContext(msg.context);
        updateContextBanner();
        document.getElementById('sp-context-banner').style.display = '';
        const text = msg.context.selection?.text || '';
        if (text) {
          searchInput.value = text;
          runDeepResearch(text);
        }
      }
    });
  }
}

document.addEventListener('DOMContentLoaded', initSidePanel);
