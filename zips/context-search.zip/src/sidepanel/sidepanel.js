/**
 * Master Side Panel Script for ContextSearch (Phase 4).
 * Coordinates parallel multi-source search aggregation, AI synthesis, and pinned bookmarks.
 */

import { aggregateSearch } from '../search/search-aggregator.js';
import { queryAI } from '../ai/ai-client.js';
import { renderMarkdown } from '../content/popup/markdown-renderer.js';
import { renderResultCard } from './components/result-card-view.js';
import { getPinnedResults, togglePinResult, recordSearchSession } from '../search/history-manager.js';
import { getSettings } from '../shared/settings-manager.js';
import { ACTION_TYPES } from '../shared/constants.js';
import { escapeHtml } from '../shared/utils.js';

let activeContext = {
  selection: { text: 'AbortController' },
  page: { domain: 'developer.mozilla.org', title: 'Web API' },
  detected: { siteType: 'mdn', language: 'javascript', category: 'api' }
};

let allResults = [];
let activeFilter = 'all';
let activeSearchId = 0;
let activeAiController = null;
let lastAiAnswer = '';
let pinnedUrls = new Set();

async function initSidePanel() {
  const settings = await getSettings();
  if (settings.theme === 'light') {
    document.body.className = 'theme-light';
  } else {
    document.body.className = 'theme-dark';
  }

  // Load pinned state
  const pinned = await getPinnedResults();
  pinnedUrls = new Set(pinned.map(p => p.url));

  // Check if context was passed from background (palette / context menu), then the active tab
  let hasContext = false;
  try {
    const pending = await chrome.runtime.sendMessage({ type: 'GET_PENDING_SIDEPANEL_CONTEXT' }).catch(() => null);
    if (pending && pending.context && pending.context.selection?.text) {
      activeContext = normalizeContext(pending.context);
      hasContext = true;
    }
  } catch (err) {
    console.debug('[ContextSearch SidePanel] Pending context notice:', err);
  }

  try {
    if (!hasContext && typeof chrome !== 'undefined' && chrome.tabs && chrome.tabs.query) {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab && tab.id) {
        const response = await chrome.tabs.sendMessage(tab.id, { type: 'GET_CURRENT_CONTEXT' }).catch(() => null);
        if (response && response.context && response.context.selection?.text) {
          activeContext = normalizeContext(response.context);
          hasContext = true;
        }
      }
    }
  } catch (err) {
    console.debug('[ContextSearch SidePanel] Context fetch notice:', err);
  }

  updateContextBanner();

  const searchInput = document.getElementById('sp-search-input');

  // Bind event listeners
  bindEvents();

  if (hasContext) {
    searchInput.value = activeContext.selection.text;
    runDeepResearch(searchInput.value.trim());
  } else {
    showIdleState();
    searchInput.focus();
  }
}

/**
 * Fill in missing context fields so partial contexts (e.g. from the context menu) render safely.
 * @param {object} ctx
 * @returns {object}
 */
function normalizeContext(ctx = {}) {
  return {
    ...ctx,
    selection: { ...(ctx.selection || {}) },
    page: { ...(ctx.page || {}) },
    detected: { ...(ctx.detected || {}) }
  };
}

function showIdleState() {
  document.getElementById('sp-ai-shimmer').style.display = 'none';
  const aiBody = document.getElementById('sp-ai-body');
  aiBody.style.display = 'block';
  aiBody.innerHTML = '<p>Select text on any page and choose <strong>🔬 Deep Research</strong>, or type a query above and press Enter.</p>';
  document.getElementById('sp-ai-status').textContent = 'Ready';
  document.getElementById('sp-results-shimmer').style.display = 'none';
  document.getElementById('sp-results-stats').textContent = 'No search yet';
}

function updateContextBanner() {
  const langTag = document.getElementById('sp-ctx-lang');
  const siteTag = document.getElementById('sp-ctx-site');
  const domainSnippet = document.getElementById('sp-ctx-domain');

  if (langTag) langTag.textContent = activeContext.detected.language || 'Code';
  if (siteTag) siteTag.textContent = activeContext.detected.siteType || 'Web';
  if (domainSnippet) domainSnippet.textContent = activeContext.page.domain || 'active tab';
}

async function runDeepResearch(query) {
  if (!query) return;

  const searchId = ++activeSearchId;
  const isCurrent = () => searchId === activeSearchId;
  if (activeAiController) activeAiController.abort();
  activeAiController = new AbortController();
  const aiSignal = activeAiController.signal;
  lastAiAnswer = '';
  const copyAiBtn = document.getElementById('sp-btn-copy-ai');
  if (copyAiBtn) copyAiBtn.style.display = 'none';

  const startTime = Date.now();
  allResults = [];

  // Reset UI
  const aiBody = document.getElementById('sp-ai-body');
  const aiShimmer = document.getElementById('sp-ai-shimmer');
  const aiStatus = document.getElementById('sp-ai-status');
  const resultsList = document.getElementById('sp-results-list');
  const resultsShimmer = document.getElementById('sp-results-shimmer');
  const statsBadge = document.getElementById('sp-results-stats');
  const latencyBadge = document.getElementById('sp-latency-badge');

  aiBody.style.display = 'none';
  aiShimmer.style.display = 'flex';
  aiStatus.textContent = 'Streaming...';

  resultsList.style.display = 'none';
  resultsShimmer.style.display = 'flex';
  statsBadge.textContent = 'Searching sources...';

  // 1. Record search session
  await recordSearchSession(query, activeContext);

  // 2. Stream AI Synthesis in parallel
  queryAI({
    actionId: ACTION_TYPES.EXPLAIN,
    context: { ...activeContext, selection: { text: query } },
    signal: aiSignal,
    onChunk: (_chunk, accumulated) => {
      if (!isCurrent()) return;
      lastAiAnswer = accumulated;
      if (aiShimmer.style.display !== 'none') {
        aiShimmer.style.display = 'none';
        aiBody.style.display = 'block';
      }
      aiBody.innerHTML = renderMarkdown(accumulated);
    },
    onComplete: (final, meta) => {
      if (!isCurrent()) return;
      lastAiAnswer = final || lastAiAnswer;
      if (copyAiBtn && lastAiAnswer) copyAiBtn.style.display = 'inline-block';
      aiStatus.textContent = meta.cached ? '⚡ Cached' : `⚡ ${meta.provider}`;
    },
    onError: (err) => {
      if (!isCurrent() || aiSignal.aborted) return;
      aiShimmer.style.display = 'none';
      aiBody.style.display = 'block';
      aiBody.innerHTML = `<p style="color: #fda4af;">AI synthesis unavailable: ${escapeHtml(err?.message || 'unknown error')}. See verified sources below.</p>`;
      aiStatus.textContent = 'Notice';
    }
  }).catch(() => {});

  // 3. Parallel Aggregated Search
  await aggregateSearch({
    query,
    context: activeContext,
    onSourceResult: (_source, sourceResults) => {
      if (!isCurrent()) return;
      // Progressive update
      allResults.push(...sourceResults);
      updateFilterCounts();
      renderFilteredResults();

      resultsShimmer.style.display = 'none';
      resultsList.style.display = 'flex';
    },
    onComplete: (rankedItems) => {
      if (!isCurrent()) return;
      allResults = rankedItems;
      const duration = Date.now() - startTime;
      resultsShimmer.style.display = 'none';
      resultsList.style.display = 'flex';

      updateFilterCounts();
      renderFilteredResults();

      statsBadge.textContent = `${allResults.length} verified results`;
      latencyBadge.textContent = `⚡ ${duration}ms`;
    }
  });
}

function updateFilterCounts() {
  const counts = {
    all: allResults.length,
    mdn: allResults.filter(r => r.source === 'mdn').length,
    stackoverflow: allResults.filter(r => r.source === 'stackoverflow').length,
    github: allResults.filter(r => r.source === 'github').length,
    npm: allResults.filter(r => r.source === 'npm').length
  };

  document.getElementById('count-all').textContent = counts.all;
  document.getElementById('count-mdn').textContent = counts.mdn;
  document.getElementById('count-so').textContent = counts.stackoverflow;
  document.getElementById('count-gh').textContent = counts.github;
  document.getElementById('count-npm').textContent = counts.npm;
}

function renderFilteredResults() {
  const listContainer = document.getElementById('sp-results-list');
  let filtered = allResults;

  if (activeFilter !== 'all') {
    filtered = allResults.filter(r => r.source === activeFilter);
  }

  if (filtered.length === 0) {
    listContainer.innerHTML = `<div style="padding: 20px; text-align: center; color: var(--text-dim); font-size: 12px;">No results found for this filter.</div>`;
    return;
  }

  listContainer.innerHTML = filtered.map(item => {
    const isPinned = pinnedUrls.has(item.url);
    return renderResultCard(item, isPinned);
  }).join('');

  attachCardEvents(listContainer);
}

function attachCardEvents(container) {
  const pinButtons = container.querySelectorAll('.cs-card-action-btn[data-action="pin"]');
  pinButtons.forEach(btn => {
    btn.onclick = async (e) => {
      e.stopPropagation();
      const card = btn.closest('.cs-result-card');
      const url = card.getAttribute('data-url');
      const item = allResults.find(r => r.url === url);

      if (item) {
        const isNowPinned = await togglePinResult(item);
        if (isNowPinned) {
          pinnedUrls.add(url);
          btn.textContent = '📌';
          btn.classList.add('cs-pinned');
        } else {
          pinnedUrls.delete(url);
          btn.textContent = '📍';
          btn.classList.remove('cs-pinned');
        }
      }
    };
  });
}

async function renderPinnedDrawer() {
  const drawer = document.getElementById('sp-pinned-drawer');
  const list = document.getElementById('sp-pinned-list');
  const countSpan = document.getElementById('sp-pinned-count');

  const pinned = await getPinnedResults();
  countSpan.textContent = pinned.length;

  if (pinned.length === 0) {
    list.innerHTML = `<div style="padding: 20px; text-align: center; color: var(--text-dim); font-size: 12px;">No bookmarks pinned yet. Click 📍 on any search card to save.</div>`;
  } else {
    list.innerHTML = pinned.map(item => renderResultCard(item, true)).join('');
    attachCardEvents(list);
  }

  drawer.style.display = 'flex';
}

function bindEvents() {
  const searchInput = document.getElementById('sp-search-input');
  const searchBtn = document.getElementById('sp-search-btn');

  const handleSearch = () => {
    const q = searchInput.value.trim();
    if (q) runDeepResearch(q);
  };

  searchBtn.addEventListener('click', handleSearch);
  searchInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') handleSearch();
  });

  // Filter chips
  const filterChips = document.querySelectorAll('.sp-filter-chip');
  filterChips.forEach(chip => {
    chip.addEventListener('click', () => {
      filterChips.forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      activeFilter = chip.getAttribute('data-filter') || 'all';
      renderFilteredResults();
    });
  });

  // Copy AI answer
  const copyAiBtn = document.getElementById('sp-btn-copy-ai');
  if (copyAiBtn) {
    copyAiBtn.addEventListener('click', () => {
      if (!lastAiAnswer) return;
      navigator.clipboard.writeText(lastAiAnswer).then(() => {
        copyAiBtn.textContent = '✓';
        setTimeout(() => { copyAiBtn.textContent = '📋'; }, 1500);
      }).catch(() => {});
    });
  }

  // Pinned Bookmarks
  document.getElementById('sp-btn-bookmarks').addEventListener('click', () => {
    renderPinnedDrawer();
  });

  document.getElementById('sp-close-pinned-btn').addEventListener('click', () => {
    document.getElementById('sp-pinned-drawer').style.display = 'none';
  });

  // Settings
  document.getElementById('sp-btn-settings').addEventListener('click', () => {
    if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.openOptionsPage) {
      chrome.runtime.openOptionsPage();
    }
  });

  // Listen for active context broadcast
  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener((msg) => {
      if (msg.type === 'CONTEXT_SEARCH_TRIGGER' && msg.context) {
        activeContext = normalizeContext(msg.context);
        updateContextBanner();
        const text = msg.context.selection?.text || '';
        if (text) {
          searchInput.value = text;
          runDeepResearch(text);
        }
      }
    });
  }
}

document.addEventListener('DOMContentLoaded', initSidePanel);
