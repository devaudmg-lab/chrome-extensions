/**
 * Result Card DOM View Component for ContextSearch Side Panel (Phase 4).
 */

function escapeHtml(str) {
  if (!str) return '';
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

/**
 * Render a single result card HTML.
 * @param {object} item 
 * @param {boolean} [isPinned=false] 
 * @returns {string}
 */
export function renderResultCard(item, isPinned = false, visitedLabel = '') {
  const meta = item.metadata || {};
  const metaTags = [];

  if (meta.isAccepted) {
    metaTags.push('<span class="cs-card-tag cs-tag-accepted">✓ Accepted</span>');
  }
  if (meta.votes !== undefined) {
    metaTags.push(`<span class="cs-card-tag">▲ ${meta.votes} votes</span>`);
  }
  if (meta.stars !== undefined) {
    metaTags.push(`<span class="cs-card-tag">⭐ ${meta.stars.toLocaleString()}</span>`);
  }
  if (meta.version) {
    metaTags.push(`<span class="cs-card-tag">v${meta.version}</span>`);
  }
  if (meta.gzipKb) {
    metaTags.push(`<span class="cs-card-tag">${meta.gzipKb} kB gzip</span>`);
  }

  if (visitedLabel) {
    metaTags.push(`<span class="cs-card-tag cs-tag-visited" title="You opened this result before">✓ Visited ${escapeHtml(visitedLabel)}</span>`);
  }

  const pinIcon = isPinned ? '📌' : '📍';
  const pinTitle = isPinned ? 'Unpin bookmark' : 'Pin to bookmarks';
  const pinClass = isPinned ? 'cs-card-action-btn cs-pinned' : 'cs-card-action-btn';

  return `
    <article class="cs-result-card${visitedLabel ? ' cs-visited' : ''}" data-id="${item.id}" data-url="${escapeHtml(item.url)}" data-source="${item.source}">
      <div class="cs-card-header">
        <div class="cs-card-source">
          <span class="cs-source-icon">${item.icon || '🔗'}</span>
          <span class="cs-source-label">${item.sourceLabel || item.source}</span>
        </div>
        <div class="cs-card-actions">
          <button class="${pinClass}" data-action="pin" title="${pinTitle}">${pinIcon}</button>
          <a href="${escapeHtml(item.url)}" target="_blank" rel="noopener noreferrer" class="cs-card-action-btn" title="Open in new tab">↗</a>
        </div>
      </div>

      <a href="${escapeHtml(item.url)}" target="_blank" rel="noopener noreferrer" class="cs-card-title">
        ${escapeHtml(item.title)}
      </a>

      <p class="cs-card-snippet">
        ${escapeHtml(item.snippet)}
      </p>

      ${metaTags.length > 0 ? `<div class="cs-card-meta">${metaTags.join('')}</div>` : ''}
    </article>
  `;
}
