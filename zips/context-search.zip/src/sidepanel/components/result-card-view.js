/**
 * Result Card DOM View Component for ContextSearch Side Panel (Phase 4).
 */

import { escapeHtml, isSafeHttpUrl } from '../../shared/utils.js';

/**
 * Render a single result card HTML.
 * @param {object} item 
 * @param {boolean} [isPinned=false] 
 * @returns {string}
 */
export function renderResultCard(item, isPinned = false, visitedLabel = '') {
  const meta = item.metadata || {};
  const metaTags = [];

  if (meta.isAccepted) {
    metaTags.push('<span class="cs-card-tag cs-tag-accepted">✓ Accepted</span>');
  }
  if (meta.votes !== undefined) {
    metaTags.push(`<span class="cs-card-tag">▲ ${Number(meta.votes) || 0} votes</span>`);
  }
  if (meta.stars !== undefined) {
    metaTags.push(`<span class="cs-card-tag">⭐ ${(Number(meta.stars) || 0).toLocaleString()}</span>`);
  }
  if (meta.version) {
    metaTags.push(`<span class="cs-card-tag">v${escapeHtml(meta.version)}</span>`);
  }
  if (meta.gzipKb) {
    metaTags.push(`<span class="cs-card-tag">${escapeHtml(meta.gzipKb)} kB gzip</span>`);
  }

  if (visitedLabel) {
    metaTags.push(`<span class="cs-card-tag cs-tag-visited" title="You opened this result before">✓ Visited ${escapeHtml(visitedLabel)}</span>`);
  }

  const pinIcon = isPinned ? '📌' : '📍';
  const pinTitle = isPinned ? 'Unpin bookmark' : 'Pin to bookmarks';
  const pinClass = isPinned ? 'cs-card-action-btn cs-pinned' : 'cs-card-action-btn';
  // Results come from third-party APIs: only ever link to http(s)
  const url = isSafeHttpUrl(item.url) ? item.url : '#';

  return `
    <article class="cs-result-card${visitedLabel ? ' cs-visited' : ''}" data-id="${escapeHtml(item.id)}" data-url="${escapeHtml(item.url)}" data-source="${escapeHtml(item.source)}">
      <div class="cs-card-header">
        <div class="cs-card-source">
          <span class="cs-source-icon" aria-hidden="true">${escapeHtml(item.icon || '🔗')}</span>
          <span class="cs-source-label">${escapeHtml(item.sourceLabel || item.source)}</span>
        </div>
        <div class="cs-card-actions">
          <button type="button" class="${pinClass}" data-action="pin" title="${pinTitle}" aria-label="${pinTitle}" aria-pressed="${isPinned ? 'true' : 'false'}">${pinIcon}</button>
          <a href="${escapeHtml(url)}" target="_blank" rel="noopener noreferrer" class="cs-card-action-btn" title="Open in new tab" aria-label="Open in new tab">↗</a>
        </div>
      </div>

      <a href="${escapeHtml(url)}" target="_blank" rel="noopener noreferrer" class="cs-card-title">
        ${escapeHtml(item.title)}
      </a>

      <p class="cs-card-snippet">
        ${escapeHtml(item.snippet)}
      </p>

      ${metaTags.length > 0 ? `<div class="cs-card-meta">${metaTags.join('')}</div>` : ''}
    </article>
  `;
}
