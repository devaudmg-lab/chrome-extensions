/**
 * Shared utility functions for ContextSearch.
 */

/**
 * Clean and normalize text, removing excessive whitespace and control characters.
 * @param {string} text 
 * @param {number} maxLen 
 * @returns {string}
 */
export function sanitizeText(text, maxLen = 500) {
  if (!text || typeof text !== 'string') return '';
  const cleaned = text
    .replace(/[\r\n\t]+/g, ' ')
    .replace(/\s{2,}/g, ' ')
    .trim();
  return maxLen && cleaned.length > maxLen ? cleaned.slice(0, maxLen) : cleaned;
}

/**
 * Escape a value for safe interpolation into HTML strings.
 * @param {*} value 
 * @returns {string}
 */
export function escapeHtml(value) {
  if (value === null || value === undefined) return '';
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

/**
 * Truncate text with ellipsis.
 * @param {string} text 
 * @param {number} length 
 * @returns {string}
 */
export function truncate(text, length = 30) {
  if (!text) return '';
  return text.length > length ? text.slice(0, length - 1) + '…' : text;
}

/**
 * Extract an identifier or package name from selection (removes trailing semicolons, parens, quotes).
 * @param {string} text 
 * @returns {string}
 */
export function extractCleanIdentifier(text) {
  if (!text) return '';
  return text
    .trim()
    .replace(/^["'`(<[{]+/, '')
    .replace(/["'`);>\]},]+$/, '')
    .trim();
}

/**
 * Safely parse domain from a URL string.
 * @param {string} urlString 
 * @returns {string}
 */
export function safeDomain(urlString) {
  try {
    if (!urlString) return '';
    const parsed = new URL(urlString);
    return parsed.hostname.toLowerCase();
  } catch {
    return '';
  }
}

/**
 * Extract clean query words without symbols.
 * @param {string} text 
 * @returns {string}
 */
export function cleanQueryWords(text) {
  return sanitizeText(text, 200)
    .replace(/[^a-zA-Z0-9_\-./@$#]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}
