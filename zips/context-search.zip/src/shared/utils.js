/**
 * Shared utility functions for ContextSearch.
 */

/**
 * Clean and normalize text, removing excessive whitespace and control characters.
 * @param {string} text
 * @param {number} maxLen
 * @returns {string}
 */
export function sanitizeText(text, maxLen = 500) {
  if (!text || typeof text !== 'string') return '';
  const cleaned = text
    .replace(/[\r\n\t]+/g, ' ')
    .replace(/\s{2,}/g, ' ')
    .trim();
  return maxLen && cleaned.length > maxLen ? safeSlice(cleaned, maxLen) : cleaned;
}

/**
 * Slice a string to at most maxLen UTF-16 units without splitting a surrogate pair
 * (a lone surrogate makes encodeURIComponent throw "URI malformed").
 * @param {string} text
 * @param {number} maxLen
 * @returns {string}
 */
export function safeSlice(text, maxLen) {
  if (!text || text.length <= maxLen) return text || '';
  let end = maxLen;
  const code = text.charCodeAt(end - 1);
  if (code >= 0xd800 && code <= 0xdbff) end -= 1;
  return text.slice(0, end);
}

/**
 * encodeURIComponent that never throws on lone surrogates (they become U+FFFD).
 * @param {*} value
 * @returns {string}
 */
export function safeEncode(value) {
  const str = value === null || value === undefined ? '' : String(value);
  return encodeURIComponent(typeof str.toWellFormed === 'function' ? str.toWellFormed() : str);
}

/**
 * Only allow http(s) URLs (blocks javascript:, data:, file: and friends).
 * @param {string} url
 * @returns {boolean}
 */
export function isSafeHttpUrl(url) {
  if (!url || typeof url !== 'string') return false;
  try {
    const parsed = new URL(url);
    return parsed.protocol === 'https:' || parsed.protocol === 'http:';
  } catch {
    return false;
  }
}

/**
 * Escape a value for safe interpolation into HTML strings.
 * @param {*} value
 * @returns {string}
 */
export function escapeHtml(value) {
  if (value === null || value === undefined) return '';
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

/**
 * Truncate text with ellipsis.
 * @param {string} text
 * @param {number} length
 * @returns {string}
 */
export function truncate(text, length = 30) {
  if (!text) return '';
  return text.length > length ? safeSlice(text, length - 1) + '…' : text;
}

/**
 * Extract an identifier or package name from selection (removes trailing semicolons, parens, quotes).
 * @param {string} text
 * @returns {string}
 */
export function extractCleanIdentifier(text) {
  if (!text) return '';
  return text
    .trim()
    .replace(/^["'`(<[{]+/, '')
    .replace(/["'`);>\]},]+$/, '')
    .trim();
}

/**
 * Safely parse domain from a URL string.
 * @param {string} urlString
 * @returns {string}
 */
export function safeDomain(urlString) {
  try {
    if (!urlString) return '';
    const parsed = new URL(urlString);
    return parsed.hostname.toLowerCase();
  } catch {
    return '';
  }
}

/**
 * Extract clean query words without symbols.
 * @param {string} text
 * @returns {string}
 */
export function cleanQueryWords(text) {
  return sanitizeText(text, 200)
    .replace(/[^a-zA-Z0-9_\-./@$#]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Small, fast, non-cryptographic string hash (FNV-1a, 32-bit) as 8 hex chars.
 * @param {string} str
 * @returns {string}
 */
export function hashString(str = '') {
  let h = 0x811c9dc5;
  const s = String(str);
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 0x01000193) >>> 0;
  }
  return h.toString(16).padStart(8, '0');
}
