/**
 * Configuration Importer, Exporter, and Team Shareable URL Generator for ContextSearch (Phase 5).
 */

import { getSettings, saveSettings } from './settings-manager.js';
import { getCustomActions, saveCustomActions } from '../custom-actions/custom-actions-manager.js';
import { getApiKeys, saveApiKeys } from './api-keys-manager.js';

const CONFIG_SCHEMA_VERSION = '1.0.0';

/**
 * Generate a complete configuration export object.
 * @param {boolean} [includeApiKeys=false] Whether to bundle API keys (defaults to false for security)
 * @returns {Promise<object>}
 */
export async function exportConfiguration(includeApiKeys = false) {
  const settings = await getSettings();
  const customActions = await getCustomActions();
  const apiKeys = includeApiKeys ? await getApiKeys() : {};

  return {
    version: CONFIG_SCHEMA_VERSION,
    exportedAt: new Date().toISOString(),
    settings,
    customActions,
    apiKeys: includeApiKeys ? apiKeys : undefined
  };
}

/**
 * Validate imported JSON configuration format.
 * @param {object} config 
 * @returns {{ valid: boolean, errors: Array<string> }}
 */
export function validateConfiguration(config) {
  const errors = [];

  if (!config || typeof config !== 'object') {
    return { valid: false, errors: ['Invalid JSON object'] };
  }

  if (config.customActions && !Array.isArray(config.customActions)) {
    errors.push('customActions must be an array');
  }

  if (config.settings && typeof config.settings !== 'object') {
    errors.push('settings must be an object');
  }

  return {
    valid: errors.length === 0,
    errors
  };
}

/**
 * Import and apply a configuration object.
 * @param {object} config 
 * @param {boolean} [merge=true] If true, merges custom actions; if false, overwrites
 * @returns {Promise<{ success: boolean, message: string }>}
 */
export async function importConfiguration(config, merge = true) {
  const validation = validateConfiguration(config);
  if (!validation.valid) {
    throw new Error(`Configuration validation failed: ${validation.errors.join(', ')}`);
  }

  // 1. Apply Settings
  if (config.settings) {
    const current = await getSettings();
    await saveSettings({ ...current, ...config.settings });
  }

  // 2. Apply Custom Actions
  if (config.customActions && Array.isArray(config.customActions)) {
    if (merge) {
      const currentActions = await getCustomActions();
      const actionMap = new Map();
      currentActions.forEach(a => actionMap.set(a.id, a));
      config.customActions.forEach(a => actionMap.set(a.id, a));
      await saveCustomActions(Array.from(actionMap.values()));
    } else {
      await saveCustomActions(config.customActions);
    }
  }

  // 3. Apply API Keys if explicitly present
  if (config.apiKeys && typeof config.apiKeys === 'object') {
    await saveApiKeys(config.apiKeys);
  }

  return { success: true, message: 'Configuration successfully imported' };
}

/**
 * Encode custom actions pack to a shareable Base64 string.
 * @param {Array<object>} actions 
 * @returns {string}
 */
export function encodeShareablePreset(actions) {
  try {
    const json = JSON.stringify(actions);
    return btoa(unescape(encodeURIComponent(json)));
  } catch {
    return '';
  }
}

/**
 * Decode shareable preset Base64 string into custom action objects.
 * @param {string} base64 
 * @returns {Array<object>}
 */
export function decodeShareablePreset(base64) {
  try {
    const json = decodeURIComponent(escape(atob(base64)));
    const parsed = JSON.parse(json);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}
