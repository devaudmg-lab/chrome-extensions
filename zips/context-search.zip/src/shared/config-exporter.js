/**
 * Configuration Importer, Exporter, and Team Shareable URL Generator for ContextSearch (Phase 5).
 */

import { getSettings, saveSettings } from './settings-manager.js';
import { getCustomActions, saveCustomActions } from '../custom-actions/custom-actions-manager.js';
import { getApiKeys, saveApiKeys } from './api-keys-manager.js';

const CONFIG_SCHEMA_VERSION = '1.0.0';

/**
 * Generate a complete configuration export object.
 * @param {boolean} [includeApiKeys=false] Whether to bundle API keys (defaults to false for security)
 * @returns {Promise<object>}
 */
export async function exportConfiguration(includeApiKeys = false) {
  const settings = await getSettings();
  const customActions = await getCustomActions();
  const apiKeys = includeApiKeys ? await getApiKeys() : {};

  return {
    version: CONFIG_SCHEMA_VERSION,
    exportedAt: new Date().toISOString(),
    settings,
    customActions,
    apiKeys: includeApiKeys ? apiKeys : undefined
  };
}

/**
 * Validate imported JSON configuration format.
 * @param {object} config 
 * @returns {{ valid: boolean, errors: Array<string> }}
 */
export function validateConfiguration(config) {
  const errors = [];

  if (!config || typeof config !== 'object') {
    return { valid: false, errors: ['Invalid JSON object'] };
  }

  if (config.customActions && !Array.isArray(config.customActions)) {
    errors.push('customActions must be an array');
  }

  if (config.settings && typeof config.settings !== 'object') {
    errors.push('settings must be an object');
  }

  return {
    valid: errors.length === 0,
    errors
  };
}

/**
 * Import and apply a configuration object.
 * @param {object} config 
 * @param {boolean} [merge=true] If true, merges custom actions; if false, overwrites
 * @returns {Promise<{ success: boolean, message: string }>}
 */
export async function importConfiguration(config, merge = true) {
  const validation = validateConfiguration(config);
  if (!validation.valid) {
    throw new Error(`Configuration validation failed: ${validation.errors.join(', ')}`);
  }

  // 1. Apply Settings
  if (config.settings) {
    const current = await getSettings();
    await saveSettings({ ...current, ...config.settings });
  }

  // 2. Apply Custom Actions (sanitized: imported files are untrusted)
  if (config.customActions && Array.isArray(config.customActions)) {
    config = { ...config, customActions: sanitizeActionPack(config.customActions).actions };
    if (merge) {
      const currentActions = await getCustomActions();
      const actionMap = new Map();
      currentActions.forEach(a => actionMap.set(a.id, a));
      config.customActions.forEach(a => actionMap.set(a.id, a));
      await saveCustomActions(Array.from(actionMap.values()));
    } else {
      await saveCustomActions(config.customActions);
    }
  }

  // 3. Apply API Keys if explicitly present
  if (config.apiKeys && typeof config.apiKeys === 'object') {
    await saveApiKeys(config.apiKeys);
  }

  return { success: true, message: 'Configuration successfully imported' };
}

/**
 * Encode custom actions pack to a shareable Base64 string.
 * @param {Array<object>} actions 
 * @returns {string}
 */
export function encodeShareablePreset(actions) {
  try {
    const json = JSON.stringify(actions);
    return btoa(unescape(encodeURIComponent(json)));
  } catch {
    return '';
  }
}

/**
 * Decode shareable preset Base64 string into custom action objects.
 * @param {string} base64 
 * @returns {Array<object>}
 */
export function decodeShareablePreset(base64) {
  try {
    const json = decodeURIComponent(escape(atob(base64)));
    const parsed = JSON.parse(json);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export const ACTION_PACK_FORMAT = 'context-search-action-pack';
const MAX_PACK_ACTIONS = 50;

/**
 * Build a shareable action pack (custom actions only, no settings, history or keys).
 * @param {Array<object>} actions
 * @param {string} [name]
 * @returns {object}
 */
export function buildActionPack(actions = [], name = 'My ContextSearch actions') {
  return {
    format: ACTION_PACK_FORMAT,
    version: 1,
    name,
    exportedAt: new Date().toISOString(),
    actions: sanitizeActionPack(actions).actions
  };
}

/**
 * Validate and clean custom actions coming from a shared file.
 * Accepts an action pack, a full config export ({ customActions }) or a bare array.
 * URL templates must be http(s); AI prompts are length-limited; unknown fields are dropped.
 * @param {object|Array<object>} input
 * @returns {{ actions: Array<object>, skipped: number, name: string }}
 */
export function sanitizeActionPack(input) {
  let list = [];
  let name = '';
  if (Array.isArray(input)) {
    list = input;
  } else if (input && typeof input === 'object') {
    name = typeof input.name === 'string' ? input.name.slice(0, 80) : '';
    if (Array.isArray(input.actions)) list = input.actions;
    else if (Array.isArray(input.customActions)) list = input.customActions;
  }

  const actions = [];
  let skipped = 0;
  const usedIds = new Set();

  for (const raw of list.slice(0, MAX_PACK_ACTIONS)) {
    if (!raw || typeof raw !== 'object' || typeof raw.name !== 'string' || !raw.name.trim()) {
      skipped++;
      continue;
    }
    const type = raw.type === 'ai' ? 'ai' : 'url';
    const template = typeof raw.template === 'string' ? raw.template.trim().slice(0, 2000) : '';
    const aiPrompt = typeof raw.aiPrompt === 'string' ? raw.aiPrompt.trim().slice(0, 4000) : '';

    if (type === 'url' && !/^https?:\/\//i.test(template)) { skipped++; continue; }
    if (type === 'ai' && !aiPrompt) { skipped++; continue; }

    let id = typeof raw.id === 'string' && /^[\w-]{1,64}$/.test(raw.id) ? raw.id : '';
    if (!id || usedIds.has(id)) id = `custom_${Date.now().toString(36)}_${actions.length}`;
    usedIds.add(id);

    const nameClean = raw.name.trim().slice(0, 60);
    actions.push({
      id,
      name: nameClean,
      shortLabel: typeof raw.shortLabel === 'string' && raw.shortLabel.trim() ? raw.shortLabel.trim().slice(0, 16) : nameClean.slice(0, 12),
      icon: typeof raw.icon === 'string' && raw.icon.trim() ? Array.from(raw.icon.trim()).slice(0, 4).join('') : '⚡',
      type,
      badge: type === 'ai' ? 'AI ✨' : '→Web',
      template: type === 'url' ? template : '',
      aiPrompt: type === 'ai' ? aiPrompt : '',
      conditions: raw.conditions && typeof raw.conditions === 'object' && !Array.isArray(raw.conditions) ? raw.conditions : {},
      enabled: raw.enabled !== false,
      isCustom: true
    });
  }

  skipped += Math.max(0, list.length - MAX_PACK_ACTIONS);
  return { actions, skipped, name };
}
