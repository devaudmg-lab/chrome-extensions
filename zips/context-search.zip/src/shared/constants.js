/**
 * Constants and shared definitions for ContextSearch (Phase 4).
 */

export const TEXT_CATEGORIES = {
  ERROR: 'error',
  CODE: 'code',
  PACKAGE: 'package',
  API: 'api',
  COMMAND: 'command',
  CONFIG: 'config',
  PATH: 'path',
  VERSION: 'version',
  CONCEPT: 'concept'
};

export const TEXT_SUBCATEGORIES = {
  ERROR_RUNTIME: 'error_runtime',
  ERROR_BUILD: 'error_build',
  ERROR_NETWORK: 'error_network',
  ERROR_TYPE: 'error_type',
  CODE_FUNCTION: 'code_function',
  CODE_CLASS: 'code_class',
  CODE_IMPORT: 'code_import',
  CODE_SNIPPET: 'code_snippet',
  COMMAND_NPM: 'command_npm',
  COMMAND_GIT: 'command_git',
  COMMAND_DOCKER: 'command_docker',
  COMMAND_SHELL: 'command_shell',
  PACKAGE_NPM: 'package_npm',
  PACKAGE_PYPI: 'package_pypi',
  PACKAGE_CRATE: 'package_crate',
  PACKAGE_GO: 'package_go',
  CONFIG_JSON: 'config_json',
  CONFIG_YAML: 'config_yaml',
  CONFIG_ENV: 'config_env',
  PATH_FILE: 'path_file',
  PATH_URL: 'path_url',
  PATH_ENDPOINT: 'path_endpoint',
  VERSION_SEMVER: 'version_semver',
  VERSION_RANGE: 'version_range',
  CONCEPT: 'concept'
};

export const SITE_TYPES = {
  GITHUB: 'github',
  GITLAB: 'gitlab',
  BITBUCKET: 'bitbucket',
  STACKOVERFLOW: 'stackoverflow',
  NPM: 'npm',
  PYPI: 'pypi',
  CRATES: 'crates',
  GO_PKG: 'go_pkg',
  MDN: 'mdn',
  DOCS_RS: 'docs_rs',
  PYTHON_DOCS: 'python_docs',
  NODE_DOCS: 'node_docs',
  REACT_DOCS: 'react_docs',
  NEXTJS_DOCS: 'nextjs_docs',
  VUE_DOCS: 'vue_docs',
  AWS_CONSOLE: 'aws_console',
  GCP_CONSOLE: 'gcp_console',
  DEV_COMMUNITY: 'dev_community',
  GENERIC: 'generic'
};

export const TRIGGER_MODES = {
  KEYBOARD: 'keyboard',
  AUTO_SELECT: 'auto_select',
  HOVER_ICON: 'hover_icon',
  RIGHT_CLICK_ONLY: 'right_click_only'
};

export const THEMES = {
  DARK: 'dark',
  LIGHT: 'light',
  SYSTEM: 'system'
};

export const SEARCH_MODES = {
  AUTO: 'auto',
  DEVELOPER: 'developer',
  GENERAL: 'general'
};

export const AI_PROVIDERS = {
  GEMINI: 'gemini',
  OPENAI: 'openai',
  ANTHROPIC: 'anthropic',
  CUSTOM: 'custom'
};

export const DEFAULT_MODELS = {
  [AI_PROVIDERS.GEMINI]: 'gemini-2.5-flash',
  [AI_PROVIDERS.OPENAI]: 'gpt-4o-mini',
  [AI_PROVIDERS.ANTHROPIC]: 'claude-haiku-4-5',
  [AI_PROVIDERS.CUSTOM]: 'llama3'
};

export const SEARCH_SOURCES = {
  STACKOVERFLOW: 'stackoverflow',
  GITHUB: 'github',
  NPM: 'npm',
  MDN: 'mdn',
  BUNDLEPHOBIA: 'bundlephobia',
  GOOGLE: 'google'
};

export const ACTION_TYPES = {
  DEEP_RESEARCH: 'deep_research',
  EXPLAIN: 'explain',
  DEBUG: 'debug',
  FIND_SOLUTIONS: 'find_solutions',
  SUMMARIZE: 'summarize',
  GENERATE_TESTS: 'generate_tests',
  SEARCH: 'search',
  FIND_DOCS: 'find_docs',
  FIND_EXAMPLES: 'find_examples',
  FIND_SO_SOLUTIONS: 'find_so_solutions',
  FIND_GH_ISSUES: 'find_gh_issues',
  FIND_ALTERNATIVES: 'find_alternatives',
  VIEW_NPM: 'view_npm',
  CHECK_BUNDLE_SIZE: 'check_bundle_size',
  EXPLAIN_COMMAND: 'explain_command',
  CHECK_SECURITY: 'check_security',
  CONVERT_SYNTAX: 'convert_syntax'
};

export const ACTION_DEFINITIONS = {
  [ACTION_TYPES.DEEP_RESEARCH]: {
    id: ACTION_TYPES.DEEP_RESEARCH,
    title: '🔬 Deep Research in Side Panel',
    shortLabel: 'Research',
    icon: '🔬',
    badge: 'SidePanel',
    isAI: false,
    isSidePanel: true,
    template: ''
  },
  [ACTION_TYPES.EXPLAIN]: {
    id: ACTION_TYPES.EXPLAIN,
    title: '🧠 Explain "%s"',
    shortLabel: 'Explain',
    icon: '🧠',
    badge: 'AI ✨',
    isAI: true,
    template: 'https://www.google.com/search?q=what+is+{selection}+{language}+explained'
  },
  [ACTION_TYPES.DEBUG]: {
    id: ACTION_TYPES.DEBUG,
    title: '🐛 Debug Error',
    shortLabel: 'Debug',
    icon: '🐛',
    badge: 'AI ✨',
    isAI: true,
    template: 'https://www.google.com/search?q={selection}+error+solution+{language}'
  },
  [ACTION_TYPES.FIND_SOLUTIONS]: {
    id: ACTION_TYPES.FIND_SOLUTIONS,
    title: '💡 Find AI Solutions',
    shortLabel: 'Solutions',
    icon: '💡',
    badge: 'AI ✨',
    isAI: true,
    template: 'https://www.google.com/search?q={selection}+solution+approach+{language}'
  },
  [ACTION_TYPES.SUMMARIZE]: {
    id: ACTION_TYPES.SUMMARIZE,
    title: '📝 Summarize Code',
    shortLabel: 'Summarize',
    icon: '📝',
    badge: 'AI ✨',
    isAI: true,
    template: 'https://www.google.com/search?q={selection}+summary'
  },
  [ACTION_TYPES.GENERATE_TESTS]: {
    id: ACTION_TYPES.GENERATE_TESTS,
    title: '🧪 Generate Unit Tests',
    shortLabel: 'Tests',
    icon: '🧪',
    badge: 'AI ✨',
    isAI: true,
    template: 'https://www.google.com/search?q=unit+tests+for+{selection}'
  },
  [ACTION_TYPES.SEARCH]: {
    id: ACTION_TYPES.SEARCH,
    title: '🔎 Search "%s"',
    shortLabel: 'Search',
    icon: '🔎',
    badge: '→G',
    isAI: false,
    template: 'https://www.google.com/search?q={selection}+{context}'
  },
  [ACTION_TYPES.FIND_DOCS]: {
    id: ACTION_TYPES.FIND_DOCS,
    title: '📚 Find Documentation',
    shortLabel: 'Docs',
    icon: '📚',
    badge: '→Doc',
    isAI: false,
    template: 'https://www.google.com/search?q={selection}+{language}+documentation'
  },
  [ACTION_TYPES.FIND_EXAMPLES]: {
    id: ACTION_TYPES.FIND_EXAMPLES,
    title: '💻 Find Code Examples',
    shortLabel: 'Examples',
    icon: '💻',
    badge: '→GH',
    isAI: false,
    template: 'https://www.google.com/search?q={selection}+example+code+{language}'
  },
  [ACTION_TYPES.FIND_SO_SOLUTIONS]: {
    id: ACTION_TYPES.FIND_SO_SOLUTIONS,
    title: '💬 Stack Overflow Solutions',
    shortLabel: 'SO Solutions',
    icon: '💬',
    badge: '→SO',
    isAI: false,
    template: 'https://www.google.com/search?q={selection}+site:stackoverflow.com'
  },
  [ACTION_TYPES.FIND_GH_ISSUES]: {
    id: ACTION_TYPES.FIND_GH_ISSUES,
    title: '🐙 Search GitHub Issues',
    shortLabel: 'GH Issues',
    icon: '🐙',
    badge: '→GH',
    isAI: false,
    template: 'https://www.google.com/search?q={selection}+site:github.com+issues'
  },
  [ACTION_TYPES.FIND_ALTERNATIVES]: {
    id: ACTION_TYPES.FIND_ALTERNATIVES,
    title: '🔄 Find Alternatives',
    shortLabel: 'Alternatives',
    icon: '🔄',
    badge: '→Alt',
    isAI: false,
    template: 'https://www.google.com/search?q={selection}+alternatives+comparison+{language}'
  },
  [ACTION_TYPES.VIEW_NPM]: {
    id: ACTION_TYPES.VIEW_NPM,
    title: '📦 View on npm',
    shortLabel: 'npm Package',
    icon: '📦',
    badge: '→npm',
    isAI: false,
    template: 'https://www.npmjs.com/package/{selection}'
  },
  [ACTION_TYPES.CHECK_BUNDLE_SIZE]: {
    id: ACTION_TYPES.CHECK_BUNDLE_SIZE,
    title: '⚖️ Check Bundle Size',
    shortLabel: 'Bundlephobia',
    icon: '⚖️',
    badge: '→Size',
    isAI: false,
    template: 'https://bundlephobia.com/package/{selection}'
  },
  [ACTION_TYPES.EXPLAIN_COMMAND]: {
    id: ACTION_TYPES.EXPLAIN_COMMAND,
    title: '⚡ Explain CLI Command',
    shortLabel: 'CLI Explain',
    icon: '⚡',
    badge: 'AI ✨',
    isAI: true,
    template: 'https://explainshell.com/explain?cmd={selection}'
  },
  [ACTION_TYPES.CHECK_SECURITY]: {
    id: ACTION_TYPES.CHECK_SECURITY,
    title: '🛡️ Check Security / CVE',
    shortLabel: 'Security',
    icon: '🛡️',
    badge: '→CVE',
    isAI: false,
    template: 'https://www.google.com/search?q={selection}+security+vulnerability+cve'
  },
  [ACTION_TYPES.CONVERT_SYNTAX]: {
    id: ACTION_TYPES.CONVERT_SYNTAX,
    title: '🔄 Convert Syntax',
    shortLabel: 'Convert',
    icon: '🔄',
    badge: 'AI ✨',
    isAI: true,
    template: 'https://www.google.com/search?q=convert+{selection}+to+typescript'
  }
};

export const DEFAULT_SETTINGS = {
  triggerMode: TRIGGER_MODES.KEYBOARD,
  searchMode: SEARCH_MODES.AUTO,
  theme: THEMES.DARK,
  maxActions: 6,
  enableFloatingPopup: true,
  enableContextMenu: true,
  disabledDomains: [
    'mail.google.com',
    'docs.google.com',
    'chase.com',
    'bankofamerica.com',
    'paypal.com'
  ],
  customShortcut: 'Ctrl+Shift+Space',
  // Phase 3 & 4 Settings
  aiProvider: AI_PROVIDERS.GEMINI,
  geminiModel: 'gemini-2.5-flash',
  openaiModel: 'gpt-4o-mini',
  anthropicModel: 'claude-haiku-4-5',
  customModel: 'llama3',
  customBaseUrl: 'http://localhost:11434/v1',
  maxHourlyRequests: 50,
  enableCaching: true,
  enableSidePanel: true
};
