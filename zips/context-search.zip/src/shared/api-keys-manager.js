/**
 * API Keys Manager for ContextSearch (Phase 3).
 * Securely manages API keys for OpenAI, Google Gemini, Anthropic, and Custom endpoints.
 */

import { AI_PROVIDERS } from './constants.js';

let inMemoryKeys = {};

/**
 * Retrieve saved API keys from secure local storage.
 * @returns {Promise<object>}
 */
export async function getApiKeys() {
  try {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      return new Promise((resolve) => {
        chrome.storage.local.get(['contextSearchApiKeys'], (res) => {
          if (res && res.contextSearchApiKeys) {
            inMemoryKeys = { ...res.contextSearchApiKeys };
          }
          resolve(inMemoryKeys);
        });
      });
    }
  } catch (err) {
    console.debug('[ContextSearch] API keys get notice:', err);
  }
  return inMemoryKeys;
}

/**
 * Save API keys to local storage.
 * @param {object} keys 
 * @returns {Promise<object>}
 */
export async function saveApiKeys(keys) {
  const merged = { ...inMemoryKeys, ...keys };
  inMemoryKeys = merged;

  try {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      await new Promise((resolve) => {
        chrome.storage.local.set({ contextSearchApiKeys: merged }, resolve);
      });
    }
  } catch (err) {
    console.debug('[ContextSearch] API keys save notice:', err);
  }

  return merged;
}

/**
 * Get active API key for a specific provider.
 * @param {string} provider 
 * @returns {Promise<string>}
 */
export async function getKeyForProvider(provider) {
  const keys = await getApiKeys();
  switch (provider) {
    case AI_PROVIDERS.GEMINI:
      return keys.geminiApiKey || '';
    case AI_PROVIDERS.OPENAI:
      return keys.openaiApiKey || '';
    case AI_PROVIDERS.ANTHROPIC:
      return keys.anthropicApiKey || '';
    case AI_PROVIDERS.CUSTOM:
      return keys.customApiKey || '';
    default:
      return '';
  }
}
