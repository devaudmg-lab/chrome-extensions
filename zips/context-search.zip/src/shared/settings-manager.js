/**
 * Settings Manager for ContextSearch.
 * Handles user preferences, trigger modes, themes, and domain blacklists.
 */

import { DEFAULT_SETTINGS } from './constants.js';
import { safeDomain } from './utils.js';

let inMemorySettings = { ...DEFAULT_SETTINGS };

/**
 * Load settings from Chrome storage with default fallbacks.
 * @returns {Promise<object>}
 */
export async function getSettings() {
  try {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.sync) {
      return new Promise((resolve) => {
        chrome.storage.sync.get(['contextSearchSettings'], (res) => {
          if (res && res.contextSearchSettings) {
            inMemorySettings = { ...DEFAULT_SETTINGS, ...res.contextSearchSettings };
          }
          resolve(inMemorySettings);
        });
      });
    } else if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      return new Promise((resolve) => {
        chrome.storage.local.get(['contextSearchSettings'], (res) => {
          if (res && res.contextSearchSettings) {
            inMemorySettings = { ...DEFAULT_SETTINGS, ...res.contextSearchSettings };
          }
          resolve(inMemorySettings);
        });
      });
    }
  } catch (err) {
    console.debug('[ContextSearch] Settings get error, using fallback:', err);
  }
  return inMemorySettings;
}

/**
 * Save user settings to storage.
 * @param {object} newSettings 
 * @returns {Promise<object>}
 */
export async function saveSettings(newSettings) {
  const merged = { ...inMemorySettings, ...newSettings };
  inMemorySettings = merged;

  try {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.sync) {
      await new Promise((resolve) => {
        chrome.storage.sync.set({ contextSearchSettings: merged }, resolve);
      });
    } else if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      await new Promise((resolve) => {
        chrome.storage.local.set({ contextSearchSettings: merged }, resolve);
      });
    }
  } catch (err) {
    console.debug('[ContextSearch] Settings save error:', err);
  }

  return merged;
}

/**
 * Reset settings back to factory defaults.
 * @returns {Promise<object>}
 */
export async function resetSettings() {
  return saveSettings(DEFAULT_SETTINGS);
}

/**
 * Check whether a given URL or hostname is blacklisted.
 * @param {string} urlOrDomain 
 * @param {object} [settings=null] 
 * @returns {boolean}
 */
export function isDomainBlacklisted(urlOrDomain, settings = null) {
  const currentSettings = settings || inMemorySettings;
  const list = currentSettings.disabledDomains || [];
  if (!list || list.length === 0) return false;

  let host = urlOrDomain.toLowerCase().trim();
  if (host.includes('://')) {
    host = safeDomain(host);
  }

  return list.some(item => {
    const clean = item.toLowerCase().trim();
    if (!clean) return false;
    return host === clean || host.endsWith(`.${clean}`);
  });
}
