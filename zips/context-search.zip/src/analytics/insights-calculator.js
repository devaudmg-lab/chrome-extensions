/**
 * Developer Productivity Insights Calculator for ContextSearch (Phase 5).
 * Computes estimated time saved, language distribution, and category frequencies.
 */

const SECONDS_SAVED_PER_SEARCH = 45; // Average developer time to switch tabs, filter ads, and find answer

/**
 * Calculate developer productivity insights from history sessions.
 * @param {Array<object>} historySessions 
 * @returns {object}
 */
export function calculateDeveloperInsights(historySessions = []) {
  const totalSearches = historySessions.length;
  const totalSecondsSaved = totalSearches * SECONDS_SAVED_PER_SEARCH;
  const hoursSaved = (totalSecondsSaved / 3600).toFixed(1);
  const minutesSaved = Math.round((totalSecondsSaved % 3600) / 60);

  // 1. Language breakdown
  const languageCounts = {};
  const categoryCounts = {};
  const queryCounts = {};

  historySessions.forEach((session) => {
    const lang = (session.language || 'generic').toLowerCase();
    languageCounts[lang] = (languageCounts[lang] || 0) + 1;

    const cat = (session.category || session.siteType || 'concept').toLowerCase();
    categoryCounts[cat] = (categoryCounts[cat] || 0) + 1;

    const q = (session.query || '').trim().toLowerCase();
    if (q) queryCounts[q] = (queryCounts[q] || 0) + 1;
  });

  // Convert to sorted percentage arrays
  const topLanguages = Object.entries(languageCounts)
    .map(([name, count]) => ({
      name,
      count,
      percent: totalSearches > 0 ? Math.round((count / totalSearches) * 100) : 0
    }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 5);

  const topCategories = Object.entries(categoryCounts)
    .map(([name, count]) => ({
      name,
      count,
      percent: totalSearches > 0 ? Math.round((count / totalSearches) * 100) : 0
    }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 5);

  const topQueries = Object.entries(queryCounts)
    .map(([query, count]) => ({ query, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 5);

  return {
    totalSearches,
    timeSavedFormatted: `${hoursSaved}h ${minutesSaved}m`,
    totalSecondsSaved,
    topLanguages,
    topCategories,
    topQueries
  };
}

/**
 * Generate CSV formatted string from history sessions.
 * @param {Array<object>} historySessions 
 * @returns {string}
 */
export function generateHistoryCSV(historySessions = []) {
  const headers = ['Query', 'Language', 'Category / Site', 'Timestamp'];
  const rows = historySessions.map(s => [
    csvCell(s.query || ''),
    csvCell(s.language || 'code'),
    csvCell(s.category || s.siteType || 'web'),
    csvCell(s.timestamp ? new Date(s.timestamp).toISOString() : '')
  ]);

  return [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
}

/**
 * One quoted CSV cell. Values a spreadsheet would run as a formula (=, +, -, @, tab, CR)
 * get a leading apostrophe so a crafted search can't execute when the CSV is opened.
 * @param {*} value
 * @returns {string}
 */
export function csvCell(value) {
  let text = String(value === null || value === undefined ? '' : value);
  if (/^[=+\-@\t\r]/.test(text)) text = `'${text}`;
  return `"${text.replace(/"/g, '""')}"`;
}
