/**
 * History Analytics Service for ContextSearch (Phase 5).
 */

import { getSearchHistory } from '../search/history-manager.js';
import { calculateDeveloperInsights, generateHistoryCSV } from './insights-calculator.js';

/**
 * Fetch and calculate developer productivity stats.
 * @returns {Promise<object>}
 */
export async function getProductivityStats() {
  const history = await getSearchHistory();
  return calculateDeveloperInsights(history);
}

/**
 * Filter search history by keyword or language.
 * @param {string} filterText 
 * @param {Array<object>} [historyList] 
 * @returns {Promise<Array<object>>}
 */
export async function filterSearchHistory(filterText = '', historyList = null) {
  const list = historyList || (await getSearchHistory());
  const clean = filterText.toLowerCase().trim();
  if (!clean) return list;

  return list.filter(item => {
    const q = (item.query || '').toLowerCase();
    const l = (item.language || '').toLowerCase();
    const c = (item.category || item.siteType || '').toLowerCase();
    return q.includes(clean) || l.includes(clean) || c.includes(clean);
  });
}

/**
 * Export history as downloadable CSV.
 * @returns {Promise<string>}
 */
export async function exportHistoryAsCSV() {
  const history = await getSearchHistory();
  return generateHistoryCSV(history);
}
