/**
 * Options and Power Hub Controller for ContextSearch (Phase 5).
 */

import { getSettings, saveSettings, resetSettings } from '../shared/settings-manager.js';
import { getApiKeys, saveApiKeys } from '../shared/api-keys-manager.js';
import { getCacheSize, clearCache } from '../ai/response-cache.js';
import { queryAI } from '../ai/ai-client.js';
import { getCustomActions, saveCustomActions, upsertCustomAction, deleteCustomAction, toggleCustomAction } from '../custom-actions/custom-actions-manager.js';
import { PRESET_PACKS, PRESET_CUSTOM_ACTIONS } from '../custom-actions/presets-library.js';
import { exportConfiguration, importConfiguration, buildActionPack, sanitizeActionPack, describeSensitiveImportChanges } from '../shared/config-exporter.js';
import { interpolateTemplate } from '../custom-actions/template-interpolator.js';
import { discoverModels, pickPreferredModel, OLLAMA_DEFAULT_BASE_URL } from '../ai/model-discovery.js';
import { getProductivityStats, filterSearchHistory, exportHistoryAsCSV } from '../analytics/history-analytics.js';
import { getSearchHistory, clearSearchHistory } from '../search/history-manager.js';
import { safeDomain, escapeHtml, isSafeHttpUrl } from '../shared/utils.js';

let currentSettings = {};
let currentCustomActions = [];
let allHistory = [];

// Tab Navigation
function initTabs() {
  const tabs = document.querySelectorAll('.nav-tab');
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));

      tab.classList.add('active');
      const targetId = tab.dataset.tab;
      const targetContent = document.getElementById(targetId);
      if (targetContent) targetContent.classList.add('active');

      if (targetId === 'tab-custom') renderCustomActions();
      if (targetId === 'tab-insights') loadProductivityInsights();
    });
  });
}

function updateProviderVisibility(provider) {
  const groups = {
    gemini: document.getElementById('group-gemini'),
    openai: document.getElementById('group-openai'),
    anthropic: document.getElementById('group-anthropic'),
    custom: document.getElementById('group-custom')
  };

  for (const [key, element] of Object.entries(groups)) {
    if (element) {
      element.style.display = key === provider ? 'flex' : 'none';
    }
  }
}

async function updateCacheDisplay() {
  const countBadge = document.getElementById('cache-count-badge');
  if (countBadge) {
    const size = await getCacheSize();
    countBadge.textContent = `${size} cached item${size === 1 ? '' : 's'}`;
  }
}

function renderBlacklist(domains) {
  const list = document.getElementById('blacklist-items');
  if (!list) return;
  list.innerHTML = '';

  (domains || []).forEach((domain, idx) => {
    const li = document.createElement('li');
    li.className = 'blacklist-item';
    li.innerHTML = `
      <span>${escapeHtml(domain)}</span>
      <button class="remove-btn" data-index="${idx}" title="Remove domain" aria-label="Remove ${escapeHtml(domain)}">✕</button>
    `;
    list.appendChild(li);
  });

  list.querySelectorAll('.remove-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const idx = parseInt(e.target.dataset.index, 10);
      currentSettings.disabledDomains.splice(idx, 1);
      renderBlacklist(currentSettings.disabledDomains);
      saveBlacklist().then(() => showSaveIndicator('Domain removed')).catch((err) => showSaveIndicator(`Could not save: ${err.message}`));
    });
  });
}

/**
 * The blacklist is saved right away (the indicator says "Domain added", so it must be true).
 * @returns {Promise<void>}
 */
async function saveBlacklist() {
  const latest = await getSettings();
  await saveSettings({ ...latest, disabledDomains: currentSettings.disabledDomains.slice() });
}

function stripLeadingIcon(name = '', icon = '') {
  return icon && name.startsWith(icon) ? name.slice(icon.length).trim() : name;
}

// Custom Actions
async function renderCustomActions() {
  const list = document.getElementById('custom-actions-list');
  if (!list) return;

  currentCustomActions = await getCustomActions();
  list.innerHTML = '';

  if (currentCustomActions.length === 0) {
    list.innerHTML = `<div style="padding: 16px; text-align: center; color: var(--text-muted); font-size: 12px;">No custom actions created. Click "+ Create Action" or apply a preset pack.</div>`;
    return;
  }

  currentCustomActions.forEach(action => {
    const card = document.createElement('div');
    card.className = 'custom-action-card';
    card.innerHTML = `
      <div class="custom-action-left">
        <span class="action-icon">${escapeHtml(action.icon || '⚡')}</span>
        <div class="action-info">
          <span class="action-name">${escapeHtml(stripLeadingIcon(action.name, action.icon))}</span>
          <span class="action-type-badge">${action.type === 'ai' ? '🧠 AI Prompt' : '🔗 URL Template'}</span>
        </div>
      </div>
      <div class="custom-action-controls">
        <button class="btn-secondary btn-edit-action" data-id="${escapeHtml(action.id)}">✏️ Edit</button>
        <button class="btn-secondary btn-toggle-action" data-id="${escapeHtml(action.id)}" aria-pressed="${action.enabled !== false ? 'true' : 'false'}">
          ${action.enabled !== false ? '🟢 Active' : '⚪ Disabled'}
        </button>
        <button class="btn-danger btn-delete-action" data-id="${escapeHtml(action.id)}" aria-label="Delete ${escapeHtml(stripLeadingIcon(action.name, action.icon))}" title="Delete">🗑️</button>
      </div>
    `;
    list.appendChild(card);
  });

  // Bind edit, toggle, delete
  list.querySelectorAll('.btn-edit-action').forEach(btn => {
    btn.addEventListener('click', () => openActionModal(btn.dataset.id));
  });

  list.querySelectorAll('.btn-toggle-action').forEach(btn => {
    btn.addEventListener('click', async () => {
      await toggleCustomAction(btn.dataset.id);
      renderCustomActions();
    });
  });

  list.querySelectorAll('.btn-delete-action').forEach(btn => {
    btn.addEventListener('click', async () => {
      if (confirm('Delete this custom action?')) {
        await deleteCustomAction(btn.dataset.id);
        renderCustomActions();
      }
    });
  });
}

function openActionModal(actionId = null) {
  const modal = document.getElementById('modal-custom-action');
  const title = document.getElementById('modal-title');
  const idInput = document.getElementById('edit-action-id');
  const nameInput = document.getElementById('edit-action-name');
  const iconInput = document.getElementById('edit-action-icon');
  const typeSelect = document.getElementById('edit-action-type');
  const templateInput = document.getElementById('edit-action-template');
  const promptInput = document.getElementById('edit-action-prompt');

  const groupUrl = document.getElementById('field-group-url');
  const groupAi = document.getElementById('field-group-ai');

  if (actionId) {
    const action = currentCustomActions.find(a => a.id === actionId);
    if (action) {
      title.textContent = 'Edit Custom Action';
      idInput.value = action.id;
      nameInput.value = action.name;
      iconInput.value = action.icon || '⚡';
      typeSelect.value = action.type || 'url';
      templateInput.value = action.template || '';
      promptInput.value = action.aiPrompt || '';
    }
  } else {
    title.textContent = 'Create Custom Action';
    idInput.value = '';
    nameInput.value = '';
    iconInput.value = '⚡';
    typeSelect.value = 'url';
    templateInput.value = '';
    promptInput.value = '';
  }

  const updateTypeFields = () => {
    const isAi = typeSelect.value === 'ai';
    groupUrl.style.display = isAi ? 'none' : 'flex';
    groupAi.style.display = isAi ? 'flex' : 'none';
  };

  typeSelect.onchange = updateTypeFields;
  updateTypeFields();

  modal.style.display = 'flex';
}

function closeActionModal() {
  document.getElementById('modal-custom-action').style.display = 'none';
}

async function handleSaveActionModal() {
  const id = document.getElementById('edit-action-id').value;
  const name = document.getElementById('edit-action-name').value.trim();
  const icon = document.getElementById('edit-action-icon').value.trim() || '⚡';
  const type = document.getElementById('edit-action-type').value;
  const template = document.getElementById('edit-action-template').value.trim();
  const aiPrompt = document.getElementById('edit-action-prompt').value.trim();

  if (!name) {
    alert('Please enter an action name');
    return;
  }
  if (type === 'ai' && !aiPrompt) {
    alert('Please enter the AI prompt for this action.');
    return;
  }
  if (type !== 'ai') {
    // Same rule as shared action packs: only http(s) links (no javascript:, data:, file: ...)
    const sample = interpolateTemplate(template, { selection: { text: 'test' }, detected: { language: 'javascript', category: 'code' }, page: { domain: 'example.com', title: 'Example' } });
    if (!isSafeHttpUrl(sample)) {
      alert('The URL template must start with https:// or http:// (for example https://www.google.com/search?q={selection}).');
      return;
    }
  }

  await upsertCustomAction({
    id: id || undefined,
    name,
    icon,
    type,
    template,
    aiPrompt
  });

  closeActionModal();
  renderCustomActions();
  showSaveIndicator('Action saved');
}

// Productivity Insights
async function loadProductivityInsights() {
  allHistory = await getSearchHistory();
  const stats = await getProductivityStats();

  document.getElementById('stat-time-saved').textContent = stats.timeSavedFormatted;
  document.getElementById('stat-total-searches').textContent = stats.totalSearches;

  // Render language bars
  const langContainer = document.getElementById('chart-languages');
  langContainer.innerHTML = (stats.topLanguages || []).map(l => `
    <div class="dist-bar-item">
      <div class="dist-bar-label"><span>${escapeHtml(l.name)}</span><span>${Number(l.percent) || 0}%</span></div>
      <div class="dist-bar-bg"><div class="dist-bar-fill" style="width: ${Number(l.percent) || 0}%;"></div></div>
    </div>
  `).join('') || '<span style="color: var(--text-dim); font-size: 11px;">No search history yet.</span>';

  // Render category bars
  const catContainer = document.getElementById('chart-categories');
  catContainer.innerHTML = (stats.topCategories || []).map(c => `
    <div class="dist-bar-item">
      <div class="dist-bar-label"><span>${escapeHtml(c.name)}</span><span>${Number(c.percent) || 0}%</span></div>
      <div class="dist-bar-bg"><div class="dist-bar-fill" style="width: ${Number(c.percent) || 0}%;"></div></div>
    </div>
  `).join('') || '<span style="color: var(--text-dim); font-size: 11px;">No search history yet.</span>';

  renderHistoryTable(allHistory);
}

function renderHistoryTable(historyList) {
  const tbody = document.getElementById('history-table-body');
  if (!tbody) return;

  if (!historyList || historyList.length === 0) {
    tbody.innerHTML = `<tr><td colspan="4" style="text-align: center; color: var(--text-muted);">No history entries found.</td></tr>`;
    return;
  }

  tbody.innerHTML = historyList.map(item => `
    <tr>
      <td><strong>${escapeHtml(item.query)}</strong></td>
      <td><span class="badge-count">${escapeHtml(item.language || 'code')}</span></td>
      <td>${escapeHtml(item.category || item.siteType || 'web')}</td>
      <td>${item.timestamp ? new Date(item.timestamp).toLocaleDateString() : 'Recent'}</td>
    </tr>
  `).join('');
}

// Ollama-first: model autodetect
function renderModelChips(models) {
  const chips = document.getElementById('detected-model-chips');
  const datalist = document.getElementById('custom-model-list');
  const modelInput = document.getElementById('custom-model');
  if (datalist) {
    datalist.innerHTML = '';
    models.forEach(m => {
      const opt = document.createElement('option');
      opt.value = m;
      datalist.appendChild(opt);
    });
  }
  if (!chips) return;
  chips.innerHTML = '';
  models.slice(0, 12).forEach(m => {
    const chip = document.createElement('button');
    chip.type = 'button';
    chip.className = 'model-chip' + (modelInput && modelInput.value === m ? ' active' : '');
    chip.textContent = m;
    chip.title = `Use ${m}`;
    chip.addEventListener('click', () => {
      if (modelInput) modelInput.value = m;
      chips.querySelectorAll('.model-chip').forEach(c => c.classList.toggle('active', c === chip));
      showSaveIndicator(`Model set to ${m}: click Save to keep it`);
    });
    chips.appendChild(chip);
  });
}

async function handleDetectModels() {
  const btn = document.getElementById('btn-detect-models');
  const out = document.getElementById('detect-models-result');
  const baseInput = document.getElementById('custom-base-url');
  const modelInput = document.getElementById('custom-model');
  const baseUrl = (baseInput.value || '').trim() || OLLAMA_DEFAULT_BASE_URL;
  btn.disabled = true;
  out.className = 'detect-result';
  out.textContent = 'Looking for models…';
  const res = await discoverModels(baseUrl, { apiKey: document.getElementById('custom-key').value.trim() });
  btn.disabled = false;
  if (!res.ok) {
    out.className = 'detect-result error';
    out.textContent = res.error;
    renderModelChips([]);
    return;
  }
  out.className = 'detect-result ok';
  out.textContent = `✓ Found ${res.models.length} model${res.models.length === 1 ? '' : 's'}`;
  if (!modelInput.value.trim() || !res.models.includes(modelInput.value.trim())) {
    modelInput.value = pickPreferredModel(res.models) || modelInput.value;
  }
  renderModelChips(res.models);
}

/**
 * On load: if no cloud key is set for the active provider, quietly check for a local Ollama.
 */
async function probeOllamaOnLoad() {
  const keys = await getApiKeys();
  const provider = currentSettings.aiProvider || 'gemini';
  if (provider === 'custom') {
    handleDetectModels();
    return;
  }
  const keyField = { gemini: 'geminiApiKey', openai: 'openaiApiKey', anthropic: 'anthropicApiKey' }[provider];
  if (keyField && keys[keyField]) return;

  const res = await discoverModels(OLLAMA_DEFAULT_BASE_URL, { timeoutMs: 1500 });
  if (!res.ok) return;
  const banner = document.getElementById('ollama-detected-banner');
  const text = document.getElementById('ollama-detected-text');
  if (!banner) return;
  text.textContent = `with ${res.models.length} model${res.models.length === 1 ? '' : 's'} (${res.models.slice(0, 3).join(', ')}${res.models.length > 3 ? ', …' : ''}). No key needed.`;
  banner.style.display = 'flex';
  document.getElementById('btn-use-ollama-detected').onclick = async () => {
    document.getElementById('ai-provider-select').value = 'custom';
    updateProviderVisibility('custom');
    document.getElementById('custom-base-url').value = OLLAMA_DEFAULT_BASE_URL;
    document.getElementById('custom-model').value = pickPreferredModel(res.models);
    renderModelChips(res.models);
    await handleSave();
    banner.style.display = 'none';
    showSaveIndicator('Now using your local Ollama');
  };
}

// Action packs
async function handleExportPack() {
  const actions = await getCustomActions();
  const pack = buildActionPack(actions);
  const result = document.getElementById('pack-import-result');
  if (pack.actions.length === 0) {
    result.className = 'pack-result error';
    result.textContent = 'There are no custom actions to export yet.';
    return;
  }
  const blob = new Blob([JSON.stringify(pack, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `context-search-actions-${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  result.className = 'pack-result ok';
  result.textContent = `Exported ${pack.actions.length} action${pack.actions.length === 1 ? '' : 's'}.`;
}

async function importPackText(text) {
  const result = document.getElementById('pack-import-result');
  let parsed;
  try {
    parsed = JSON.parse(text);
  } catch {
    result.className = 'pack-result error';
    result.textContent = 'That file is not valid JSON.';
    return;
  }
  const { actions, skipped, name } = sanitizeActionPack(parsed);
  if (actions.length === 0) {
    result.className = 'pack-result error';
    result.textContent = 'No valid actions found in that file.';
    return;
  }
  const summary = actions.map(a => `${a.icon} ${a.name} (${a.type === 'ai' ? 'AI prompt' : safeDomain(a.template)})`).join('\n');
  if (!confirm(`Import ${actions.length} action${actions.length === 1 ? '' : 's'}${name ? ` from "${name}"` : ''}?\n\n${summary}`)) return;
  const existing = await getCustomActions();
  const byId = new Map(existing.map(a => [a.id, a]));
  actions.forEach(a => byId.set(a.id, a));
  await saveCustomActions(Array.from(byId.values()));
  result.className = 'pack-result ok';
  result.textContent = `Imported ${actions.length} action${actions.length === 1 ? '' : 's'}${skipped ? ` (${skipped} skipped: unsafe or incomplete)` : ''}.`;
  renderCustomActions();
}

function showSaveIndicator(msg = 'Settings saved') {
  const status = document.getElementById('save-status');
  if (!status) return;
  status.textContent = msg;
  status.classList.add('visible');
  setTimeout(() => status.classList.remove('visible'), 2000);
}

async function loadFormValues() {
  currentSettings = await getSettings();
  const keys = await getApiKeys();

  const aiProvider = currentSettings.aiProvider || 'gemini';
  document.getElementById('ai-provider-select').value = aiProvider;
  updateProviderVisibility(aiProvider);

  document.getElementById('gemini-key').value = keys.geminiApiKey || '';
  setSelectValue('gemini-model', currentSettings.geminiModel, 'gemini-2.5-flash');

  document.getElementById('openai-key').value = keys.openaiApiKey || '';
  document.getElementById('openai-model').value = currentSettings.openaiModel || 'gpt-4o-mini';

  document.getElementById('anthropic-key').value = keys.anthropicApiKey || '';
  setSelectValue('anthropic-model', currentSettings.anthropicModel, 'claude-haiku-4-5');

  document.getElementById('custom-base-url').value = currentSettings.customBaseUrl || 'http://localhost:11434/v1';
  document.getElementById('custom-key').value = keys.customApiKey || '';
  document.getElementById('custom-model').value = currentSettings.customModel || 'llama3';

  const radios = document.querySelectorAll('input[name="triggerMode"]');
  radios.forEach(radio => {
    radio.checked = radio.value === currentSettings.triggerMode;
  });

  document.getElementById('theme-select').value = currentSettings.theme || 'dark';
  document.getElementById('search-mode-select').value = currentSettings.searchMode || 'auto';
  document.getElementById('max-actions-select').value = String(currentSettings.maxActions || 6);
  document.getElementById('max-hourly-input').value = currentSettings.maxHourlyRequests || 50;
  document.getElementById('learn-order-toggle').checked = currentSettings.learnActionOrder !== false;

  renderBlacklist(currentSettings.disabledDomains);
  await updateCacheDisplay();
}

async function handleSave() {
  const triggerMode = document.querySelector('input[name="triggerMode"]:checked')?.value || 'keyboard';
  const theme = document.getElementById('theme-select').value;
  const searchMode = document.getElementById('search-mode-select').value;
  const maxActions = parseInt(document.getElementById('max-actions-select').value, 10);
  const maxHourlyRequests = Math.min(1000, Math.max(1, parseInt(document.getElementById('max-hourly-input').value, 10) || 50));
  const learnActionOrder = document.getElementById('learn-order-toggle').checked;
  const aiProvider = document.getElementById('ai-provider-select').value;

  const geminiModel = document.getElementById('gemini-model').value;
  const openaiModel = document.getElementById('openai-model').value;
  const anthropicModel = document.getElementById('anthropic-model').value;
  const customModel = document.getElementById('custom-model').value;
  const customBaseUrl = document.getElementById('custom-base-url').value;

  await saveApiKeys({
    geminiApiKey: document.getElementById('gemini-key').value.trim(),
    openaiApiKey: document.getElementById('openai-key').value.trim(),
    anthropicApiKey: document.getElementById('anthropic-key').value.trim(),
    customApiKey: document.getElementById('custom-key').value.trim()
  });

  const updated = {
    ...currentSettings,
    triggerMode,
    theme,
    searchMode,
    maxActions,
    maxHourlyRequests,
    learnActionOrder,
    aiProvider,
    geminiModel,
    openaiModel,
    anthropicModel,
    customModel,
    customBaseUrl
  };

  try {
    await saveSettings(updated);
  } catch (err) {
    showSaveIndicator(`Could not save: ${err.message}`);
    throw err;
  }
  currentSettings = updated;
  showSaveIndicator('Preferences saved!');
}

function setSelectValue(id, value, fallback) {
  const select = document.getElementById(id);
  if (!select) return;
  const hasOption = value && Array.from(select.options).some(o => o.value === value);
  select.value = hasOption ? value : fallback;
}

async function handleTestConnection() {
  const btn = document.getElementById('btn-test-ai');
  const result = document.getElementById('test-ai-result');
  btn.disabled = true;
  result.style.color = 'var(--text-muted)';
  result.textContent = 'Testing...';
  const started = Date.now();
  try {
    await handleSave();
    const res = await queryAI({
      actionId: 'explain',
      context: { selection: { text: 'connection test' }, detected: {}, page: {} },
      customPrompt: 'Reply with the single word: OK',
      bypassCache: true,
      onChunk: () => {}
    });
    if (res.model === 'demo') {
      result.style.color = '#fbbf24';
      result.textContent = 'No API key set for this provider: running in Demo Mode.';
    } else {
      result.style.color = '#4ade80';
      result.textContent = `✓ ${res.provider} / ${res.model} responded in ${Date.now() - started}ms: "${String(res.content || '').trim().slice(0, 40)}"`;
    }
  } catch (err) {
    result.style.color = '#f87171';
    result.textContent = `✕ ${err?.message || 'Connection failed'}`.slice(0, 300);
  } finally {
    btn.disabled = false;
  }
}

document.addEventListener('DOMContentLoaded', () => {
  initTabs();
  document.getElementById('btn-test-ai').addEventListener('click', handleTestConnection);
  loadFormValues().then(probeOllamaOnLoad).catch(() => {});

  // Version badge + first-run welcome
  try {
    const versionBadge = document.getElementById('version-badge');
    if (versionBadge && chrome?.runtime?.getManifest) versionBadge.textContent = `v${chrome.runtime.getManifest().version}`;
  } catch { /* not running as an extension */ }
  chrome.storage.local.get(['onboardingOptionsSeen'], (res) => {
    if (!res || !res.onboardingOptionsSeen) document.getElementById('welcome-banner').style.display = 'flex';
  });
  document.getElementById('welcome-dismiss-btn').addEventListener('click', () => {
    document.getElementById('welcome-banner').style.display = 'none';
    chrome.storage.local.set({ onboardingOptionsSeen: true });
  });

  // Ollama-first tools
  document.getElementById('btn-detect-models').addEventListener('click', handleDetectModels);
  document.getElementById('btn-ollama-preset').addEventListener('click', () => {
    document.getElementById('custom-base-url').value = OLLAMA_DEFAULT_BASE_URL;
    handleDetectModels();
  });

  // Action packs
  document.getElementById('btn-export-pack').addEventListener('click', handleExportPack);
  document.getElementById('file-import-pack').addEventListener('change', (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    file.text().then(importPackText).finally(() => { e.target.value = ''; });
  });

  document.getElementById('ai-provider-select').addEventListener('change', (e) => {
    updateProviderVisibility(e.target.value);
    if (e.target.value === 'custom' && !document.getElementById('detected-model-chips').children.length) {
      handleDetectModels();
    }
  });

  document.getElementById('save-btn').addEventListener('click', () => handleSave().catch(() => {}));

  // Blacklist
  document.getElementById('add-blacklist-btn').addEventListener('click', () => {
    const input = document.getElementById('blacklist-input');
    let val = (input.value || '').trim();
    if (!val) return;
    if (val.includes('://')) val = safeDomain(val);
    val = val.toLowerCase();
    val = val.replace(/^\*\./, '').replace(/\/.*$/, '');
    if (!/^[a-z0-9.-]+$/.test(val)) {
      showSaveIndicator('Enter a domain such as example.com');
      return;
    }
    if (!Array.isArray(currentSettings.disabledDomains)) currentSettings.disabledDomains = [];
    if (!currentSettings.disabledDomains.includes(val)) {
      currentSettings.disabledDomains.push(val);
      renderBlacklist(currentSettings.disabledDomains);
      input.value = '';
      saveBlacklist().then(() => showSaveIndicator('Domain added')).catch((err) => showSaveIndicator(`Could not save: ${err.message}`));
    }
  });

  // Cache
  document.getElementById('clear-cache-btn').addEventListener('click', async () => {
    await clearCache();
    await updateCacheDisplay();
    showSaveIndicator('Cache cleared');
  });

  // Modal handlers
  document.getElementById('btn-new-custom-action').addEventListener('click', () => openActionModal());
  document.getElementById('modal-btn-close').addEventListener('click', closeActionModal);
  document.getElementById('modal-btn-cancel').addEventListener('click', closeActionModal);
  document.getElementById('modal-btn-save').addEventListener('click', handleSaveActionModal);

  // Presets
  document.querySelectorAll('.btn-apply-preset').forEach(btn => {
    btn.addEventListener('click', async () => {
      const packKey = btn.dataset.preset;
      const pack = PRESET_PACKS[packKey];
      if (pack) {
        const actionsToInstall = PRESET_CUSTOM_ACTIONS.filter(a => pack.actionIds.includes(a.id));
        for (const action of actionsToInstall) {
          await upsertCustomAction(action);
        }
        showSaveIndicator(`Applied ${pack.name}`);
        renderCustomActions();
      }
    });
  });

  // Export / Import
  document.getElementById('btn-export-config').addEventListener('click', async () => {
    const config = await exportConfiguration(false);
    const blob = new Blob([JSON.stringify(config, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `context-search-config-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    showSaveIndicator('Config downloaded');
  });

  document.getElementById('file-import-config').addEventListener('change', (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const parsed = JSON.parse(event.target.result);
        // Settings files are untrusted: changes that redirect your prompts or keys need an explicit OK
        const sensitive = describeSensitiveImportChanges(parsed, await getSettings());
        let importKeys = false;
        if (sensitive.length) {
          const ok = confirm(`This file changes:\n\n• ${sensitive.join('\n• ')}\n\nOnly continue if you trust where the file came from. Import it?`);
          if (!ok) { e.target.value = ''; return; }
          importKeys = sensitive.some(n => n.startsWith('API keys'));
        }
        await importConfiguration(parsed, true, importKeys);
        await loadFormValues();
        showSaveIndicator('Configuration imported!');
      } catch (err) {
        alert(`Import failed: ${err.message}`);
      } finally {
        e.target.value = '';
      }
    };
    reader.readAsText(file);
  });

  // History Filter & CSV Export
  const historySearch = document.getElementById('history-search-input');
  if (historySearch) {
    historySearch.addEventListener('input', async (e) => {
      const filtered = await filterSearchHistory(e.target.value, allHistory);
      renderHistoryTable(filtered);
    });
  }

  document.getElementById('btn-clear-history').addEventListener('click', async () => {
    if (!confirm('Delete your ContextSearch search history? Pinned results are kept.')) return;
    await clearSearchHistory();
    await loadProductivityInsights();
    showSaveIndicator('History cleared');
  });

  document.getElementById('btn-export-history-csv').addEventListener('click', async () => {
    const csv = await exportHistoryAsCSV();
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `context-search-history-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    showSaveIndicator('History CSV downloaded');
  });

  // Reset
  document.getElementById('reset-btn').addEventListener('click', async () => {
    if (confirm('Reset all preferences to their defaults? Custom actions, API keys, history and pinned results are kept.')) {
      await resetSettings();
      await loadFormValues();
      showSaveIndicator('Reset to defaults');
    }
  });
});
