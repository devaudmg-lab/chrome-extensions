/**
 * Options and Power Hub Controller for ContextSearch (Phase 5).
 */

import { getSettings, saveSettings, resetSettings } from '../shared/settings-manager.js';
import { getApiKeys, saveApiKeys } from '../shared/api-keys-manager.js';
import { getCacheSize, clearCache } from '../ai/response-cache.js';
import { queryAI } from '../ai/ai-client.js';
import { getCustomActions, upsertCustomAction, deleteCustomAction, toggleCustomAction } from '../custom-actions/custom-actions-manager.js';
import { PRESET_PACKS, PRESET_CUSTOM_ACTIONS } from '../custom-actions/presets-library.js';
import { exportConfiguration, importConfiguration } from '../shared/config-exporter.js';
import { getProductivityStats, filterSearchHistory, exportHistoryAsCSV } from '../analytics/history-analytics.js';
import { getSearchHistory } from '../search/history-manager.js';
import { safeDomain, escapeHtml } from '../shared/utils.js';

let currentSettings = {};
let currentCustomActions = [];
let allHistory = [];

// Tab Navigation
function initTabs() {
  const tabs = document.querySelectorAll('.nav-tab');
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));

      tab.classList.add('active');
      const targetId = tab.dataset.tab;
      const targetContent = document.getElementById(targetId);
      if (targetContent) targetContent.classList.add('active');

      if (targetId === 'tab-custom') renderCustomActions();
      if (targetId === 'tab-insights') loadProductivityInsights();
    });
  });
}

function updateProviderVisibility(provider) {
  const groups = {
    gemini: document.getElementById('group-gemini'),
    openai: document.getElementById('group-openai'),
    anthropic: document.getElementById('group-anthropic'),
    custom: document.getElementById('group-custom')
  };

  for (const [key, element] of Object.entries(groups)) {
    if (element) {
      element.style.display = key === provider ? 'flex' : 'none';
    }
  }
}

async function updateCacheDisplay() {
  const countBadge = document.getElementById('cache-count-badge');
  if (countBadge) {
    const size = await getCacheSize();
    countBadge.textContent = `${size} cached item${size === 1 ? '' : 's'}`;
  }
}

function renderBlacklist(domains) {
  const list = document.getElementById('blacklist-items');
  if (!list) return;
  list.innerHTML = '';

  (domains || []).forEach((domain, idx) => {
    const li = document.createElement('li');
    li.className = 'blacklist-item';
    li.innerHTML = `
      <span>${escapeHtml(domain)}</span>
      <button class="remove-btn" data-index="${idx}" title="Remove domain">✕</button>
    `;
    list.appendChild(li);
  });

  list.querySelectorAll('.remove-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const idx = parseInt(e.target.dataset.index, 10);
      currentSettings.disabledDomains.splice(idx, 1);
      renderBlacklist(currentSettings.disabledDomains);
      showSaveIndicator('Domain removed');
    });
  });
}

// Custom Actions
async function renderCustomActions() {
  const list = document.getElementById('custom-actions-list');
  if (!list) return;

  currentCustomActions = await getCustomActions();
  list.innerHTML = '';

  if (currentCustomActions.length === 0) {
    list.innerHTML = `<div style="padding: 16px; text-align: center; color: var(--text-muted); font-size: 12px;">No custom actions created. Click "+ Create Action" or apply a preset pack.</div>`;
    return;
  }

  currentCustomActions.forEach(action => {
    const card = document.createElement('div');
    card.className = 'custom-action-card';
    card.innerHTML = `
      <div class="custom-action-left">
        <span class="action-icon">${escapeHtml(action.icon || '⚡')}</span>
        <div class="action-info">
          <span class="action-name">${escapeHtml(action.name)}</span>
          <span class="action-type-badge">${action.type === 'ai' ? '🧠 AI Prompt' : '🔗 URL Template'}</span>
        </div>
      </div>
      <div class="custom-action-controls">
        <button class="btn-secondary btn-edit-action" data-id="${action.id}">✏️ Edit</button>
        <button class="btn-secondary btn-toggle-action" data-id="${action.id}">
          ${action.enabled !== false ? '🟢 Active' : '⚪ Disabled'}
        </button>
        <button class="btn-danger btn-delete-action" data-id="${action.id}">🗑️</button>
      </div>
    `;
    list.appendChild(card);
  });

  // Bind edit, toggle, delete
  list.querySelectorAll('.btn-edit-action').forEach(btn => {
    btn.addEventListener('click', () => openActionModal(btn.dataset.id));
  });

  list.querySelectorAll('.btn-toggle-action').forEach(btn => {
    btn.addEventListener('click', async () => {
      await toggleCustomAction(btn.dataset.id);
      renderCustomActions();
    });
  });

  list.querySelectorAll('.btn-delete-action').forEach(btn => {
    btn.addEventListener('click', async () => {
      if (confirm('Delete this custom action?')) {
        await deleteCustomAction(btn.dataset.id);
        renderCustomActions();
      }
    });
  });
}

function openActionModal(actionId = null) {
  const modal = document.getElementById('modal-custom-action');
  const title = document.getElementById('modal-title');
  const idInput = document.getElementById('edit-action-id');
  const nameInput = document.getElementById('edit-action-name');
  const iconInput = document.getElementById('edit-action-icon');
  const typeSelect = document.getElementById('edit-action-type');
  const templateInput = document.getElementById('edit-action-template');
  const promptInput = document.getElementById('edit-action-prompt');

  const groupUrl = document.getElementById('field-group-url');
  const groupAi = document.getElementById('field-group-ai');

  if (actionId) {
    const action = currentCustomActions.find(a => a.id === actionId);
    if (action) {
      title.textContent = 'Edit Custom Action';
      idInput.value = action.id;
      nameInput.value = action.name;
      iconInput.value = action.icon || '⚡';
      typeSelect.value = action.type || 'url';
      templateInput.value = action.template || '';
      promptInput.value = action.aiPrompt || '';
    }
  } else {
    title.textContent = 'Create Custom Action';
    idInput.value = '';
    nameInput.value = '';
    iconInput.value = '⚡';
    typeSelect.value = 'url';
    templateInput.value = '';
    promptInput.value = '';
  }

  const updateTypeFields = () => {
    const isAi = typeSelect.value === 'ai';
    groupUrl.style.display = isAi ? 'none' : 'flex';
    groupAi.style.display = isAi ? 'flex' : 'none';
  };

  typeSelect.onchange = updateTypeFields;
  updateTypeFields();

  modal.style.display = 'flex';
}

function closeActionModal() {
  document.getElementById('modal-custom-action').style.display = 'none';
}

async function handleSaveActionModal() {
  const id = document.getElementById('edit-action-id').value;
  const name = document.getElementById('edit-action-name').value.trim();
  const icon = document.getElementById('edit-action-icon').value.trim() || '⚡';
  const type = document.getElementById('edit-action-type').value;
  const template = document.getElementById('edit-action-template').value.trim();
  const aiPrompt = document.getElementById('edit-action-prompt').value.trim();

  if (!name) {
    alert('Please enter an action name');
    return;
  }

  await upsertCustomAction({
    id: id || undefined,
    name,
    icon,
    type,
    template,
    aiPrompt
  });

  closeActionModal();
  renderCustomActions();
  showSaveIndicator('Action saved');
}

// Productivity Insights
async function loadProductivityInsights() {
  allHistory = await getSearchHistory();
  const stats = await getProductivityStats();

  document.getElementById('stat-time-saved').textContent = stats.timeSavedFormatted;
  document.getElementById('stat-total-searches').textContent = stats.totalSearches;

  // Render language bars
  const langContainer = document.getElementById('chart-languages');
  langContainer.innerHTML = (stats.topLanguages || []).map(l => `
    <div class="dist-bar-item">
      <div class="dist-bar-label"><span>${l.name}</span><span>${l.percent}%</span></div>
      <div class="dist-bar-bg"><div class="dist-bar-fill" style="width: ${l.percent}%;"></div></div>
    </div>
  `).join('') || '<span style="color: var(--text-dim); font-size: 11px;">No search history yet.</span>';

  // Render category bars
  const catContainer = document.getElementById('chart-categories');
  catContainer.innerHTML = (stats.topCategories || []).map(c => `
    <div class="dist-bar-item">
      <div class="dist-bar-label"><span>${c.name}</span><span>${c.percent}%</span></div>
      <div class="dist-bar-bg"><div class="dist-bar-fill" style="width: ${c.percent}%;"></div></div>
    </div>
  `).join('') || '<span style="color: var(--text-dim); font-size: 11px;">No search history yet.</span>';

  renderHistoryTable(allHistory);
}

function renderHistoryTable(historyList) {
  const tbody = document.getElementById('history-table-body');
  if (!tbody) return;

  if (!historyList || historyList.length === 0) {
    tbody.innerHTML = `<tr><td colspan="4" style="text-align: center; color: var(--text-muted);">No history entries found.</td></tr>`;
    return;
  }

  tbody.innerHTML = historyList.map(item => `
    <tr>
      <td><strong>${escapeHtml(item.query)}</strong></td>
      <td><span class="badge-count">${escapeHtml(item.language || 'code')}</span></td>
      <td>${escapeHtml(item.category || item.siteType || 'web')}</td>
      <td>${item.timestamp ? new Date(item.timestamp).toLocaleDateString() : 'Recent'}</td>
    </tr>
  `).join('');
}

function showSaveIndicator(msg = 'Settings saved') {
  const status = document.getElementById('save-status');
  if (!status) return;
  status.textContent = msg;
  status.classList.add('visible');
  setTimeout(() => status.classList.remove('visible'), 2000);
}

async function loadFormValues() {
  currentSettings = await getSettings();
  const keys = await getApiKeys();

  const aiProvider = currentSettings.aiProvider || 'gemini';
  document.getElementById('ai-provider-select').value = aiProvider;
  updateProviderVisibility(aiProvider);

  document.getElementById('gemini-key').value = keys.geminiApiKey || '';
  setSelectValue('gemini-model', currentSettings.geminiModel, 'gemini-2.5-flash');

  document.getElementById('openai-key').value = keys.openaiApiKey || '';
  document.getElementById('openai-model').value = currentSettings.openaiModel || 'gpt-4o-mini';

  document.getElementById('anthropic-key').value = keys.anthropicApiKey || '';
  setSelectValue('anthropic-model', currentSettings.anthropicModel, 'claude-haiku-4-5');

  document.getElementById('custom-base-url').value = currentSettings.customBaseUrl || 'http://localhost:11434/v1';
  document.getElementById('custom-key').value = keys.customApiKey || '';
  document.getElementById('custom-model').value = currentSettings.customModel || 'llama3';

  const radios = document.querySelectorAll('input[name="triggerMode"]');
  radios.forEach(radio => {
    radio.checked = radio.value === currentSettings.triggerMode;
  });

  document.getElementById('theme-select').value = currentSettings.theme || 'dark';
  document.getElementById('search-mode-select').value = currentSettings.searchMode || 'auto';
  document.getElementById('max-actions-select').value = String(currentSettings.maxActions || 6);
  document.getElementById('max-hourly-input').value = currentSettings.maxHourlyRequests || 50;

  renderBlacklist(currentSettings.disabledDomains);
  await updateCacheDisplay();
}

async function handleSave() {
  const triggerMode = document.querySelector('input[name="triggerMode"]:checked')?.value || 'keyboard';
  const theme = document.getElementById('theme-select').value;
  const searchMode = document.getElementById('search-mode-select').value;
  const maxActions = parseInt(document.getElementById('max-actions-select').value, 10);
  const maxHourlyRequests = parseInt(document.getElementById('max-hourly-input').value, 10) || 50;
  const aiProvider = document.getElementById('ai-provider-select').value;

  const geminiModel = document.getElementById('gemini-model').value;
  const openaiModel = document.getElementById('openai-model').value;
  const anthropicModel = document.getElementById('anthropic-model').value;
  const customModel = document.getElementById('custom-model').value;
  const customBaseUrl = document.getElementById('custom-base-url').value;

  await saveApiKeys({
    geminiApiKey: document.getElementById('gemini-key').value.trim(),
    openaiApiKey: document.getElementById('openai-key').value.trim(),
    anthropicApiKey: document.getElementById('anthropic-key').value.trim(),
    customApiKey: document.getElementById('custom-key').value.trim()
  });

  const updated = {
    ...currentSettings,
    triggerMode,
    theme,
    searchMode,
    maxActions,
    maxHourlyRequests,
    aiProvider,
    geminiModel,
    openaiModel,
    anthropicModel,
    customModel,
    customBaseUrl
  };

  await saveSettings(updated);
  currentSettings = updated;
  showSaveIndicator('Preferences saved!');
}

function setSelectValue(id, value, fallback) {
  const select = document.getElementById(id);
  if (!select) return;
  const hasOption = value && Array.from(select.options).some(o => o.value === value);
  select.value = hasOption ? value : fallback;
}

async function handleTestConnection() {
  const btn = document.getElementById('btn-test-ai');
  const result = document.getElementById('test-ai-result');
  btn.disabled = true;
  result.style.color = 'var(--text-muted)';
  result.textContent = 'Testing...';
  const started = Date.now();
  try {
    await handleSave();
    const res = await queryAI({
      actionId: 'explain',
      context: { selection: { text: 'connection test' }, detected: {}, page: {} },
      customPrompt: 'Reply with the single word: OK',
      bypassCache: true,
      onChunk: () => {}
    });
    if (res.model === 'demo') {
      result.style.color = '#fbbf24';
      result.textContent = 'No API key set for this provider: running in Demo Mode.';
    } else {
      result.style.color = '#4ade80';
      result.textContent = `✓ ${res.provider} / ${res.model} responded in ${Date.now() - started}ms: "${String(res.content || '').trim().slice(0, 40)}"`;
    }
  } catch (err) {
    result.style.color = '#f87171';
    result.textContent = `✕ ${err?.message || 'Connection failed'}`.slice(0, 300);
  } finally {
    btn.disabled = false;
  }
}

document.addEventListener('DOMContentLoaded', () => {
  initTabs();
  document.getElementById('btn-test-ai').addEventListener('click', handleTestConnection);
  loadFormValues();

  document.getElementById('ai-provider-select').addEventListener('change', (e) => {
    updateProviderVisibility(e.target.value);
  });

  document.getElementById('save-btn').addEventListener('click', handleSave);

  // Blacklist
  document.getElementById('add-blacklist-btn').addEventListener('click', () => {
    const input = document.getElementById('blacklist-input');
    let val = (input.value || '').trim();
    if (!val) return;
    if (val.includes('://')) val = safeDomain(val);
    val = val.toLowerCase();
    if (!currentSettings.disabledDomains.includes(val)) {
      currentSettings.disabledDomains.push(val);
      renderBlacklist(currentSettings.disabledDomains);
      input.value = '';
      showSaveIndicator('Domain added');
    }
  });

  // Cache
  document.getElementById('clear-cache-btn').addEventListener('click', async () => {
    await clearCache();
    await updateCacheDisplay();
    showSaveIndicator('Cache cleared');
  });

  // Modal handlers
  document.getElementById('btn-new-custom-action').addEventListener('click', () => openActionModal());
  document.getElementById('modal-btn-close').addEventListener('click', closeActionModal);
  document.getElementById('modal-btn-cancel').addEventListener('click', closeActionModal);
  document.getElementById('modal-btn-save').addEventListener('click', handleSaveActionModal);

  // Presets
  document.querySelectorAll('.btn-apply-preset').forEach(btn => {
    btn.addEventListener('click', async () => {
      const packKey = btn.dataset.preset;
      const pack = PRESET_PACKS[packKey];
      if (pack) {
        const actionsToInstall = PRESET_CUSTOM_ACTIONS.filter(a => pack.actionIds.includes(a.id));
        for (const action of actionsToInstall) {
          await upsertCustomAction(action);
        }
        showSaveIndicator(`Applied ${pack.name}`);
        renderCustomActions();
      }
    });
  });

  // Export / Import
  document.getElementById('btn-export-config').addEventListener('click', async () => {
    const config = await exportConfiguration(false);
    const blob = new Blob([JSON.stringify(config, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `context-search-config-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    showSaveIndicator('Config downloaded');
  });

  document.getElementById('file-import-config').addEventListener('change', (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const parsed = JSON.parse(event.target.result);
        await importConfiguration(parsed, true);
        await loadFormValues();
        showSaveIndicator('Configuration imported!');
      } catch (err) {
        alert(`Import failed: ${err.message}`);
      }
    };
    reader.readAsText(file);
  });

  // History Filter & CSV Export
  const historySearch = document.getElementById('history-search-input');
  if (historySearch) {
    historySearch.addEventListener('input', async (e) => {
      const filtered = await filterSearchHistory(e.target.value, allHistory);
      renderHistoryTable(filtered);
    });
  }

  document.getElementById('btn-export-history-csv').addEventListener('click', async () => {
    const csv = await exportHistoryAsCSV();
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `context-search-history-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    showSaveIndicator('History CSV downloaded');
  });

  // Reset
  document.getElementById('reset-btn').addEventListener('click', async () => {
    if (confirm('Reset all preferences and custom actions to defaults?')) {
      await resetSettings();
      await loadFormValues();
      showSaveIndicator('Reset to defaults');
    }
  });
});
