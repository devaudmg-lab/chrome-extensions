/**
 * Programming Language Detector for ContextSearch.
 * Uses syntax heuristics, keyword frequencies, and token signatures.
 */

const LANGUAGE_SIGNATURES = {
  typescript: [
    /\b(interface|type|enum|implements|declare|readonly|keyof|typeof)\b/,
    /:\s*(string|number|boolean|any|unknown|never|void|object)\b/,
    /<[A-Z][A-Za-z0-9_,\s]*>/, // Generic types: <T>, <T, K>
    /\bas\s+(const|[A-Z][A-Za-z0-9_]*)\b/
  ],
  javascript: [
    /\b(const|let|var|function|async|await|return|import|export|from|default)\b/,
    /\b(console\.(log|error|warn|info)|document\.|window\.|localStorage|sessionStorage)\b/,
    /=>/,
    /\b(require|module\.exports)\b/
  ],
  python: [
    /\b(def|async\s+def|elif|except|finally|raise|pass|lambda|yield|is\s+None|is\s+not\s+None)\b/,
    /\b(self|cls|__init__|__name__|__main__|__str__|__repr__)\b/,
    /\b(print\s*\(|import\s+[a-z0-9_.]+|from\s+[a-z0-9_.]+\s+import)\b/,
    /:$/m // Line ending with colon
  ],
  rust: [
    /\b(fn|pub\s+fn|let\s+mut|impl|trait|struct|enum|match|where|unsafe)\b/,
    /\b(println!|eprintln!|format!|vec!|panic!)\b/,
    /\b(Result<|Option<|Vec<|Box<|Rc<|Arc<|Some\(|None|Ok\(|Err\()\b/,
    /::/
  ],
  go: [
    /\b(func|package\s+[a-z0-9_]+|import\s+\(|type\s+[A-Za-z0-9_]+\s+struct)\b/,
    /\b(fmt\.(Println|Printf|Sprintf)|log\.(Fatal|Println))\b/,
    /\b(err\s*!=\s*nil|go\s+func|chan\s+[a-z0-9_]+|defer\s+)\b/,
    /:=/
  ],
  java: [
    /\b(public\s+class|private\s+class|protected|public\s+static\s+void\s+main)\b/,
    /\b(System\.out\.(println|print)|new\s+[A-Z][A-Za-z0-9_]*\(\))\b/,
    /\b(@Override|@Autowired|@Component|@Entity|implements\s+[A-Z]|extends\s+[A-Z])\b/
  ],
  cpp: [
    /#include\s+<[a-z0-9_.]+>/,
    /\b(std::(cout|cin|endl|vector|string|make_shared|unique_ptr))\b/,
    /\b(nullptr|cout\s*<<|cin\s*>>|template\s*<typename)\b/
  ],
  ruby: [
    /\b(def\s+[a-z0-9_?!]+|attr_accessor|attr_reader|attr_writer|require_relative)\b/,
    /\b(puts|print|elsif|unless|rescue\s+=>|ensure|end\b)/,
    /do\s+\|[a-z0-9_,\s]+\|/
  ],
  php: [
    /<\?php/,
    /\$[a-zA-Z_\x80-\xff][a-zA-Z0-9_\x80-\xff]*/,
    /\b(echo|function\s+[a-zA-Z_]|var_dump|print_r|array_map)\b/
  ],
  sql: [
    /\b(SELECT|FROM|WHERE|INSERT\s+INTO|UPDATE|DELETE\s+FROM|CREATE\s+TABLE|ALTER\s+TABLE|DROP\s+TABLE)\b/i,
    /\b(GROUP\s+BY|ORDER\s+BY|HAVING|INNER\s+JOIN|LEFT\s+JOIN|RIGHT\s+JOIN|CROSS\s+JOIN|LIMIT|OFFSET)\b/i
  ],
  shell: [
    /^\s*(npm|pnpm|yarn|bun|git|docker|kubectl|curl|wget|cd|mkdir|rm|chmod|chown|sudo|cat|grep|systemctl)\s+/m,
    /\b(export\s+[A-Z_]+=|set\s+-e|source\s+~\/)\b/
  ],
  css: [
    /\b(display:\s*(flex|grid|block|inline|none)|margin:|padding:|background(-color)?:|font-size:|border:)\b/,
    /;\s*$/m
  ]
};

/**
 * Detect the programming language of a code snippet.
 * @param {string} code 
 * @param {string} [fallback='javascript'] 
 * @returns {string}
 */
export function detectLanguage(code, fallback = 'general') {
  if (!code || typeof code !== 'string') return fallback;

  const scores = {};

  for (const [lang, patterns] of Object.entries(LANGUAGE_SIGNATURES)) {
    scores[lang] = 0;
    for (const pattern of patterns) {
      if (pattern.test(code)) {
        scores[lang] += 2;
      }
    }
  }

  // TypeScript vs JavaScript tiebreaker
  if (scores.typescript > 0) {
    scores.typescript += 1;
  }

  let bestLang = fallback;
  let maxScore = 0;

  for (const [lang, score] of Object.entries(scores)) {
    if (score > maxScore) {
      maxScore = score;
      bestLang = lang;
    }
  }

  return maxScore >= 2 ? bestLang : fallback;
}
