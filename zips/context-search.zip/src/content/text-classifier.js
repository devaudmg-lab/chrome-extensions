/**
 * Enhanced Rule-Based Text Classifier for ContextSearch (Phase 2).
 */

import { TEXT_CATEGORIES, TEXT_SUBCATEGORIES } from '../shared/constants.js';
import { detectLanguage } from './language-detector.js';

// Specific Error Signatures
const NETWORK_ERROR_PATTERNS = [
  /\b(ECONNRESET|ETIMEDOUT|ECONNREFUSED|ENOTFOUND|EADDRINUSE|EACCES|EPIPE)\b/i,
  /\b(Failed to fetch|NetworkError|CORS policy|net::ERR_[A-Z_]+)\b/i,
  /\b(failed with status code \d{3}|HTTP\s+\d{3}|\b404 Not Found\b|\b500 Internal Server Error\b|\b502 Bad Gateway\b|\b503 Service Unavailable\b|\b504 Gateway Timeout\b)/i
];

const RUNTIME_ERROR_PATTERNS = [
  /\b(TypeError|ReferenceError|RangeError|URIError|EvalError|AggregateError)\b/,
  /\b(Cannot read propert(y|ies) of (undefined|null)|is not a function|is not defined)\b/i,
  /\b(NullPointerException|IndexOutOfBoundsException|KeyError|ValueError|AttributeError)\b/,
  /\b(Uncaught\s+[A-Za-z0-9_$]+Error)\b/i,
  /\bat\s+[A-Za-z0-9_$<>.]+\s+\([^)]+:\d+:\d+\)/,
  /\b(panic: runtime error:)/
];

const BUILD_ERROR_PATTERNS = [
  /\b(SyntaxError|ParseError|CompileError|ModuleNotFoundError|ERR_MODULE_NOT_FOUND)\b/i,
  /\b(Cannot find module|Cannot resolve dependency|Failed to compile|Compilation failed)\b/i,
  /\b(TS\d{4}:|expected `;`|unresolved external symbol)\b/
];

// CLI Command Signatures
const CLI_PATTERNS = [
  { subcategory: TEXT_SUBCATEGORIES.COMMAND_NPM, pattern: /^\s*(npm|pnpm|yarn|bun|npx)\s+(install|add|run|build|test|publish|init|remove|exec)\b/i },
  { subcategory: TEXT_SUBCATEGORIES.COMMAND_GIT, pattern: /^\s*git\s+(clone|checkout|commit|push|pull|rebase|merge|status|log|branch|stash|diff)\b/i },
  { subcategory: TEXT_SUBCATEGORIES.COMMAND_DOCKER, pattern: /^\s*(docker|docker-compose|podman|kubectl|helm)\s+/i },
  { subcategory: TEXT_SUBCATEGORIES.COMMAND_SHELL, pattern: /^\s*(curl|wget|chmod|chown|mkdir|grep|cat|systemctl|ssh|scp|tar|sudo)\s+/i }
];

// Semver and Version Patterns
const SEMVER_PATTERN = /^v?(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-((?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*)(?:\.(?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*))*))?(?:\+([0-9a-zA-Z-]+(?:\.[0-9a-zA-Z-]+)*))?$/;
const VERSION_RANGE_PATTERN = /^(\^|~|>=|<=|>|<)?\s*\d+(\.\d+)?(\.\d+)?(\s*-\s*\d+(\.\d+)?(\.\d+)?)?$/;

// File Paths and URLs
const FILE_PATH_PATTERN = /^(\.{1,2}\/|\/|[A-Za-z]:\\)[A-Za-z0-9_.\-/\\]+\.[a-zA-Z0-9]+$/;
const URL_PATTERN = /^https?:\/\/[a-zA-Z0-9_\-.]+(:\d+)?(\/[a-zA-Z0-9_.\-/?%&=#]*)?$/i;
const API_ENDPOINT_PATTERN = /^(GET|POST|PUT|DELETE|PATCH)\s+\/[a-zA-Z0-9_\-/{}]*$|^\/api\/v\d+\/[a-zA-Z0-9_\-/{}]+$/i;
const API_METHOD_PATTERN = /^[A-Za-z0-9_$]+(\.[A-Za-z0-9_$]+)+(\([^)]*\))?$/;

// Config patterns
const JSON_CONFIG_PATTERN = /^\{[\s\S]*"[a-zA-Z0-9_$-]+"\s*:[\s\S]*\}$/;
const YAML_CONFIG_PATTERN = /^[a-zA-Z0-9_$-]+\s*:\s*.+$/m;
const ENV_CONFIG_PATTERN = /^[A-Z0-9_]{3,}\s*=\s*.+$/m;

// Package patterns
const SCOPED_PACKAGE_PATTERN = /^@[a-z0-9-~][a-z0-9-._~]*\/[a-z0-9-~][a-z0-9-._~]*$/i;
const COMMON_PACKAGES = new Set([
  'react', 'react-dom', 'next', 'vue', 'svelte', 'angular', 'express', 'fastify', 'axios',
  'lodash', 'ramda', 'chalk', 'commander', 'zod', 'yup', 'prisma', 'tailwindcss',
  'vite', 'webpack', 'esbuild', 'rollup', 'typescript', 'eslint', 'prettier', 'jest',
  'vitest', 'pytest', 'flask', 'django', 'fastapi', 'pydantic', 'numpy', 'pandas',
  'dotenv', 'cors', 'jsonwebtoken', 'bcrypt', 'nodemon', 'ts-node', 'moment', 'dayjs',
  'tokio', 'serde', 'clap', 'reqwest', 'gin', 'fiber', 'gorm'
]);

// Code tokens
const CODE_SIGNATURE_PATTERNS = [
  /\b(const|let|var|function|return|import|export|class|interface|type|extends|implements)\b/,
  /\b(def|async\s+def|lambda|elif|except\s+Exception)\b/,
  /\b(pub\s+fn|impl|struct|enum|trait|match)\b/,
  /\b(package\s+main|func\s+\w+\()/ ,
  /=>/,
  /===|!==/,
  /->/,
  /[{};]\s*$/
];

/**
 * Classify text selection with enhanced sub-categorization and language detection.
 * @param {string} text 
 * @param {object} [context={}] 
 * @returns {{ category: string, subcategory: string, language: string, confidence: number, reasoning: string }}
 */
export function classifyText(text, context = {}) {
  if (!text || typeof text !== 'string') {
    return {
      category: TEXT_CATEGORIES.CONCEPT,
      subcategory: TEXT_SUBCATEGORIES.CONCEPT,
      language: context.language || 'javascript',
      confidence: 0,
      reasoning: 'Empty or invalid text'
    };
  }

  const trimmed = text.trim();
  const domainLanguage = context.language || null;
  const detectedLanguage = detectLanguage(trimmed, domainLanguage || 'general');

  // 1. CLI Commands
  for (const item of CLI_PATTERNS) {
    if (item.pattern.test(trimmed)) {
      return {
        category: TEXT_CATEGORIES.COMMAND,
        subcategory: item.subcategory,
        language: 'bash',
        confidence: 0.95,
        reasoning: `Matched CLI command pattern: ${item.subcategory}`
      };
    }
  }

  // 2. Errors (Network, Build, Runtime)
  for (const pattern of NETWORK_ERROR_PATTERNS) {
    if (pattern.test(trimmed)) {
      return {
        category: TEXT_CATEGORIES.ERROR,
        subcategory: TEXT_SUBCATEGORIES.ERROR_NETWORK,
        language: detectedLanguage,
        confidence: 0.95,
        reasoning: 'Matches network error signature'
      };
    }
  }

  for (const pattern of BUILD_ERROR_PATTERNS) {
    if (pattern.test(trimmed)) {
      return {
        category: TEXT_CATEGORIES.ERROR,
        subcategory: TEXT_SUBCATEGORIES.ERROR_BUILD,
        language: detectedLanguage,
        confidence: 0.95,
        reasoning: 'Matches build/compilation error signature'
      };
    }
  }

  for (const pattern of RUNTIME_ERROR_PATTERNS) {
    if (pattern.test(trimmed)) {
      return {
        category: TEXT_CATEGORIES.ERROR,
        subcategory: TEXT_SUBCATEGORIES.ERROR_RUNTIME,
        language: detectedLanguage,
        confidence: 0.95,
        reasoning: 'Matches runtime exception signature'
      };
    }
  }

  // 3. File Paths and URLs
  if (FILE_PATH_PATTERN.test(trimmed)) {
    return {
      category: TEXT_CATEGORIES.PATH,
      subcategory: TEXT_SUBCATEGORIES.PATH_FILE,
      language: detectedLanguage,
      confidence: 0.9,
      reasoning: 'Matches relative/absolute file path'
    };
  }

  if (URL_PATTERN.test(trimmed)) {
    return {
      category: TEXT_CATEGORIES.PATH,
      subcategory: TEXT_SUBCATEGORIES.PATH_URL,
      language: detectedLanguage,
      confidence: 0.95,
      reasoning: 'Matches valid HTTP/HTTPS URL'
    };
  }

  if (API_ENDPOINT_PATTERN.test(trimmed)) {
    return {
      category: TEXT_CATEGORIES.API,
      subcategory: TEXT_SUBCATEGORIES.PATH_ENDPOINT,
      language: detectedLanguage,
      confidence: 0.9,
      reasoning: 'Matches REST API endpoint or route pattern'
    };
  }

  if (API_METHOD_PATTERN.test(trimmed) && !trimmed.includes(' ') && trimmed.includes('.')) {
    return {
      category: TEXT_CATEGORIES.API,
      subcategory: TEXT_SUBCATEGORIES.PATH_ENDPOINT,
      language: detectedLanguage,
      confidence: 0.85,
      reasoning: 'Matches method invocation / property chain'
    };
  }

  // 4. SemVer / Versions
  if (SEMVER_PATTERN.test(trimmed)) {
    return {
      category: TEXT_CATEGORIES.VERSION,
      subcategory: TEXT_SUBCATEGORIES.VERSION_SEMVER,
      language: detectedLanguage,
      confidence: 0.95,
      reasoning: 'Matches standard Semantic Versioning format'
    };
  }

  if (VERSION_RANGE_PATTERN.test(trimmed) && trimmed.length <= 20) {
    return {
      category: TEXT_CATEGORIES.VERSION,
      subcategory: TEXT_SUBCATEGORIES.VERSION_RANGE,
      language: detectedLanguage,
      confidence: 0.85,
      reasoning: 'Matches package version range specification'
    };
  }

  // 5. Config Formats
  if (ENV_CONFIG_PATTERN.test(trimmed) && !trimmed.includes(';') && trimmed.length < 120) {
    return {
      category: TEXT_CATEGORIES.CONFIG,
      subcategory: TEXT_SUBCATEGORIES.CONFIG_ENV,
      language: 'shell',
      confidence: 0.85,
      reasoning: 'Matches .env environment configuration pattern'
    };
  }

  if (JSON_CONFIG_PATTERN.test(trimmed)) {
    return {
      category: TEXT_CATEGORIES.CONFIG,
      subcategory: TEXT_SUBCATEGORIES.CONFIG_JSON,
      language: 'json',
      confidence: 0.9,
      reasoning: 'Matches JSON configuration structure'
    };
  }

  // 6. Packages
  const isKebabCase = /^[a-z0-9]+(-[a-z0-9]+)+$/i.test(trimmed);
  const isKnownPackage = COMMON_PACKAGES.has(trimmed.toLowerCase());
  const isScoped = SCOPED_PACKAGE_PATTERN.test(trimmed);

  if (isScoped || isKnownPackage || (context.siteType === 'npm' && isKebabCase)) {
    let sub = TEXT_SUBCATEGORIES.PACKAGE_NPM;
    if (context.siteType === 'pypi') sub = TEXT_SUBCATEGORIES.PACKAGE_PYPI;
    if (context.siteType === 'crates') sub = TEXT_SUBCATEGORIES.PACKAGE_CRATE;
    if (context.siteType === 'go_pkg') sub = TEXT_SUBCATEGORIES.PACKAGE_GO;

    return {
      category: TEXT_CATEGORIES.PACKAGE,
      subcategory: sub,
      language: context.language || detectedLanguage,
      confidence: 0.9,
      reasoning: isScoped ? 'Scoped package name' : isKnownPackage ? 'Known ecosystem package' : 'Registry package format'
    };
  }

  // 7. Code Snippets & Language Constructs
  if (/^\s*(import|from|require)\b/.test(trimmed)) {
    return {
      category: TEXT_CATEGORIES.CODE,
      subcategory: TEXT_SUBCATEGORIES.CODE_IMPORT,
      language: detectedLanguage,
      confidence: 0.9,
      reasoning: 'Module import declaration'
    };
  }

  if (/^\s*(class|struct|interface|enum|type)\s+[A-Za-z0-9_$]+/.test(trimmed)) {
    return {
      category: TEXT_CATEGORIES.CODE,
      subcategory: TEXT_SUBCATEGORIES.CODE_CLASS,
      language: detectedLanguage,
      confidence: 0.9,
      reasoning: 'Class/Struct/Type definition'
    };
  }

  if (/^\s*(pub\s+|async\s+|public\s+|private\s+|protected\s+)?(function|def|func|fn)\s+[A-Za-z0-9_$]+/.test(trimmed) || /=>\s*\{?/.test(trimmed)) {
    return {
      category: TEXT_CATEGORIES.CODE,
      subcategory: TEXT_SUBCATEGORIES.CODE_FUNCTION,
      language: detectedLanguage,
      confidence: 0.9,
      reasoning: 'Function declaration or arrow expression'
    };
  }

  for (const pattern of CODE_SIGNATURE_PATTERNS) {
    if (pattern.test(trimmed)) {
      return {
        category: TEXT_CATEGORIES.CODE,
        subcategory: TEXT_SUBCATEGORIES.CODE_SNIPPET,
        language: detectedLanguage,
        confidence: 0.85,
        reasoning: 'Code snippet with language syntax tokens'
      };
    }
  }

  if (trimmed.includes(';') || trimmed.includes('{') || trimmed.includes('}') || trimmed.includes('()') || trimmed.includes('===')) {
    return {
      category: TEXT_CATEGORIES.CODE,
      subcategory: TEXT_SUBCATEGORIES.CODE_SNIPPET,
      language: detectedLanguage,
      confidence: 0.8,
      reasoning: 'Code snippet with language syntax tokens'
    };
  }

  // 8. Default: Technical Concept / Identifier
  return {
    category: TEXT_CATEGORIES.CONCEPT,
    subcategory: TEXT_SUBCATEGORIES.CONCEPT,
    language: detectedLanguage,
    confidence: 0.75,
    reasoning: 'Developer concept or identifier'
  };
}
