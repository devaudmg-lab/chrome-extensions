/**
 * Shadow-DOM aware selection helper for ContextSearch.
 * Pages built with web components (e.g. MDN code samples in <mdn-code-example>) keep the
 * selected text inside an open shadow root. The document-level Selection then reports an
 * empty rectangle and an inaccurate toString(). Selection.getComposedRanges() (Chrome 137+)
 * returns the real range when it is given the shadow roots involved.
 */

const OWN_HOST_ID = 'context-search-host';
const MAX_SCAN = 5000;

/**
 * Collect open shadow roots under an element (recursively), skipping ContextSearch's own UI.
 * @param {Element} root
 * @returns {Array<ShadowRoot>}
 */
function collectShadowRoots(root) {
  const roots = [];
  let scanned = 0;
  const visit = (node) => {
    const all = node.querySelectorAll ? node.querySelectorAll('*') : [];
    for (const el of all) {
      if (++scanned > MAX_SCAN) return;
      if (el.shadowRoot && el.id !== OWN_HOST_ID) {
        roots.push(el.shadowRoot);
        visit(el.shadowRoot);
      }
    }
  };
  if (root && root.shadowRoot && root.id !== OWN_HOST_ID) {
    roots.push(root.shadowRoot);
    visit(root.shadowRoot);
  }
  visit(root);
  return roots;
}

/**
 * Return a live Range for a selection that lives inside a shadow root, or null when the
 * normal document range is usable (the common case, which costs nothing extra).
 * @param {Selection} selection
 * @returns {Range|null}
 */
export function getShadowAwareRange(selection) {
  try {
    if (!selection || selection.rangeCount === 0 || selection.type !== 'Range') return null;
    if (typeof selection.getComposedRanges !== 'function') return null;

    const docRange = selection.getRangeAt(0);
    const rect = docRange.getBoundingClientRect();
    if (rect.width !== 0 || rect.height !== 0) return null; // regular light-DOM selection

    let ancestor = docRange.commonAncestorContainer;
    if (ancestor && ancestor.nodeType !== 1) ancestor = ancestor.parentElement;
    if (!ancestor) return null;

    const shadowRoots = collectShadowRoots(ancestor);
    if (shadowRoots.length === 0) return null;

    const [composed] = selection.getComposedRanges({ shadowRoots });
    if (!composed || composed.collapsed) return null;
    const startRoot = composed.startContainer.getRootNode();
    if (startRoot === document || startRoot !== composed.endContainer.getRootNode()) return null;

    const range = document.createRange();
    range.setStart(composed.startContainer, composed.startOffset);
    range.setEnd(composed.endContainer, composed.endOffset);
    return range;
  } catch {
    return null;
  }
}
