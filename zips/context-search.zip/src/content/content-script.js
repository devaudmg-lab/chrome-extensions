/**
 * ContextSearch Content Script.
 * Integrates Floating Popup inside Shadow DOM with configurable triggers.
 */

import { classifyDomain } from './domain-classifier.js';
import { classifyText } from './text-classifier.js';
import { sanitizeText } from '../shared/utils.js';
import { getSettings, isDomainBlacklisted } from '../shared/settings-manager.js';
import { getActionsForContext } from '../background/action-registry.js';
import { getCustomActions } from '../custom-actions/custom-actions-manager.js';
import { FloatingPopupManager } from './popup/floating-popup.js';
import { TRIGGER_MODES } from '../shared/constants.js';

let lastSentPayloadHash = '';
let debounceTimer = null;
let cachedSettings = null;
let cachedCustomActions = [];
const popupManager = new FloatingPopupManager();

// When the extension is reloaded/updated, a fresh copy of this script is injected while the old
// (orphaned) copy keeps its listeners. Tell any previous instance to stand down.
let instanceDisabled = false;
document.dispatchEvent(new CustomEvent('contextsearch:teardown'));
document.addEventListener('contextsearch:teardown', () => {
  instanceDisabled = true;
  try { popupManager.hide(); popupManager.hideBubble(); } catch { /* ignore */ }
}, { once: true });

function isInstanceActive() {
  if (instanceDisabled) return false;
  try {
    return Boolean(chrome.runtime && chrome.runtime.id);
  } catch {
    return false;
  }
}

getCustomActions().then(ca => { cachedCustomActions = ca; }).catch(() => {});

/**
 * Get surrounding text before and after selection.
 * @param {Selection} selection 
 * @returns {{ before: string, after: string }}
 */
function getSurroundingText(selection) {
  try {
    if (!selection || selection.rangeCount === 0) {
      return { before: '', after: '' };
    }

    const range = selection.getRangeAt(0);
    const container = range.commonAncestorContainer;
    const fullText = container.textContent || '';
    const selectedText = selection.toString();

    const startIndex = fullText.indexOf(selectedText);
    if (startIndex === -1) {
      return { before: '', after: '' };
    }

    const before = fullText.slice(Math.max(0, startIndex - 100), startIndex);
    const after = fullText.slice(startIndex + selectedText.length, startIndex + selectedText.length + 100);

    return {
      before: sanitizeText(before, 100),
      after: sanitizeText(after, 100)
    };
  } catch {
    return { before: '', after: '' };
  }
}

/**
 * Check if the active target element is a sensitive field.
 * @returns {boolean}
 */
function isSensitiveTarget() {
  const active = document.activeElement;
  if (!active) return false;
  const tagName = active.tagName.toLowerCase();
  const inputType = (active.getAttribute('type') || '').toLowerCase();

  return tagName === 'input' && (inputType === 'password' || inputType === 'hidden');
}

/**
 * Extract full context object from current selection and active page.
 * @returns {object|null}
 */
export function extractContext() {
  if (isSensitiveTarget()) return null;

  const selection = window.getSelection();
  let rawText = selection ? selection.toString() : '';

  // Also check active inputs or textareas if selection is empty
  if (!rawText && document.activeElement) {
    const el = document.activeElement;
    if (el.tagName === 'TEXTAREA' || (el.tagName === 'INPUT' && (el.type === 'text' || el.type === 'search' || !el.type))) {
      const start = el.selectionStart;
      const end = el.selectionEnd;
      if (typeof start === 'number' && typeof end === 'number' && start !== end) {
        rawText = el.value.substring(start, end);
      }
    }
  }

  const text = sanitizeText(rawText, 500);

  const domainContext = classifyDomain(window.location.href, document.title);
  const textContext = classifyText(text, domainContext);
  const surrounding = getSurroundingText(selection);

  return {
    selection: {
      text,
      length: text.length,
      surrounding
    },
    page: {
      url: window.location.href,
      domain: domainContext.domain,
      title: document.title,
      path: domainContext.path
    },
    detected: {
      siteType: domainContext.siteType,
      language: textContext.language || domainContext.language,
      category: textContext.category,
      subcategory: textContext.subcategory,
      confidence: textContext.confidence,
      reasoning: textContext.reasoning,
      repoOwner: domainContext.repoOwner,
      repoName: domainContext.repoName,
      packageName: domainContext.packageName
    },
    timestamp: Date.now()
  };
}

/**
 * Trigger the floating command palette for active selection.
 */
export async function triggerFloatingPalette() {
  if (!isInstanceActive()) return;
  const settings = cachedSettings || await getSettings();
  if (isDomainBlacklisted(window.location.href, settings)) return;

  const context = extractContext();
  if (!context || !context.selection.text.trim()) return;

  if (settings.searchMode && settings.searchMode !== 'auto') {
    context.mode = settings.searchMode;
    if (context.mode === 'general') {
      context.detected.language = 'general';
    }
  }

  const customActions = cachedCustomActions.length > 0 ? cachedCustomActions : await getCustomActions();
  const actions = getActionsForContext(context, customActions);
  popupManager.show(context, actions, settings);
}

/**
 * Dispatch updated context to background worker and handle auto triggers.
 */
export async function dispatchContextUpdate() {
  try {
    const settings = cachedSettings || await getSettings();
    if (isDomainBlacklisted(window.location.href, settings)) return;

    const context = extractContext();
    if (!context) {
      popupManager.hideBubble();
      return;
    }

    if (settings.searchMode && settings.searchMode !== 'auto') {
      context.mode = settings.searchMode;
      if (context.mode === 'general') {
        context.detected.language = 'general';
      }
    }

    // Send context update to background
    const payloadHash = `${context.selection.text}::${context.detected.category}::${context.page.url}`;
    if (payloadHash !== lastSentPayloadHash) {
      lastSentPayloadHash = payloadHash;
      if (chrome && chrome.runtime && chrome.runtime.sendMessage) {
        chrome.runtime.sendMessage({
          type: 'CONTEXT_UPDATED',
          payload: context
        }).catch(() => {});
      }
    }

    // Handle selection UI trigger modes
    const selection = window.getSelection();
    const customActions = cachedCustomActions.length > 0 ? cachedCustomActions : await getCustomActions();

    if (context.selection.text.trim().length > 0) {
      if (settings.triggerMode === TRIGGER_MODES.AUTO_SELECT) {
        const actions = getActionsForContext(context, customActions);
        popupManager.show(context, actions, settings);
      } else if (settings.triggerMode === TRIGGER_MODES.HOVER_ICON) {
        popupManager.showBubble(selection, () => {
          const actions = getActionsForContext(context, customActions);
          popupManager.show(context, actions, settings);
        });
      }
    } else {
      popupManager.hideBubble();
      if (!popupManager.isVisible) {
        popupManager.hide();
      }
    }
  } catch (err) {
    console.debug('[ContextSearch] Selection handling note:', err);
  }
}

function handleSelectionEvent() {
  if (!isInstanceActive()) return;
  clearTimeout(debounceTimer);
  debounceTimer = setTimeout(() => {
    dispatchContextUpdate();
  }, 120);
}

// In-page keyboard shortcut fallback: Ctrl+Shift+Space or Command+Shift+Space
window.addEventListener('keydown', (e) => {
  const isSpace = e.code === 'Space' || e.key === ' ' || e.keyCode === 32;
  const isModifier = (e.ctrlKey || e.metaKey) && e.shiftKey;
  if (isSpace && isModifier && isInstanceActive()) {
    e.preventDefault();
    e.stopPropagation();
    triggerFloatingPalette();
  }
}, true);

document.addEventListener('selectionchange', handleSelectionEvent, { passive: true });
document.addEventListener('mouseup', handleSelectionEvent, { passive: true });

// Listen for messages from background or popup
if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!message) return;

    if (message.type === 'GET_CURRENT_CONTEXT') {
      const context = extractContext();
      sendResponse({ success: true, context });
    } else if (message.type === 'TRIGGER_FLOATING_PALETTE' || message.type === 'TRIGGER_FLOATING_POPUP') {
      triggerFloatingPalette();
      sendResponse({ success: true });
    } else if (message.type === 'SETTINGS_CHANGED') {
      cachedSettings = message.settings;
    }
    return false;
  });
}

// Keep cached settings and custom actions fresh when changed from Options
if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.onChanged) {
  chrome.storage.onChanged.addListener((changes) => {
    if (changes.contextSearchSettings) {
      getSettings().then(s => { cachedSettings = s; }).catch(() => {});
    }
    if (changes.customActionsList) {
      getCustomActions().then(ca => { cachedCustomActions = ca; }).catch(() => {});
    }
  });
}

// Initial settings load
getSettings().then(s => { cachedSettings = s; }).catch(() => {});
