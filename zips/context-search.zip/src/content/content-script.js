/**
 * ContextSearch Content Script.
 * Integrates Floating Popup inside Shadow DOM with configurable triggers.
 */

import { classifyDomain } from './domain-classifier.js';
import { classifyText } from './text-classifier.js';
import { sanitizeText } from '../shared/utils.js';
import { getSettings, isDomainBlacklisted } from '../shared/settings-manager.js';
import { getActionsForContext } from '../background/action-registry.js';
import { promoteFrequentActions } from '../background/action-ranker.js';
import { FloatingPopupManager } from './popup/floating-popup.js';
import { TRIGGER_MODES, ACTION_DEFINITIONS } from '../shared/constants.js';
import { getShadowAwareRange } from './deep-selection.js';

let lastSentPayloadHash = '';
let debounceTimer = null;
let cachedSettings = null;
let paletteData = { customActions: [], actionStats: {} };
let paletteDataAt = 0;
// The selection the auto popup / hover icon was last shown for: after Esc it must not come back
// for the same selection (a stray mouseup would otherwise reopen it).
let lastAutoShownText = '';
const popupManager = new FloatingPopupManager();

// When the extension is reloaded/updated, a fresh copy of this script is injected while the old
// (orphaned) copy keeps its listeners. Tell any previous instance to stand down.
let instanceDisabled = false;
document.dispatchEvent(new CustomEvent('contextsearch:teardown'));
document.addEventListener('contextsearch:teardown', () => {
  instanceDisabled = true;
  try { popupManager.destroy(); } catch { /* ignore */ }
}, { once: true });

function isInstanceActive() {
  if (instanceDisabled) return false;
  try {
    return Boolean(chrome.runtime && chrome.runtime.id);
  } catch {
    return false;
  }
}

/**
 * Custom actions and usage stats live in chrome.storage.local, which content scripts are not
 * allowed to read (it also holds the API keys). Ask the service worker; cache for a short while.
 * @param {boolean} [force=false]
 * @returns {Promise<{ customActions: Array<object>, actionStats: object }>}
 */
async function loadPaletteData(force = false) {
  if (!force && Date.now() - paletteDataAt < 5000) return paletteData;
  try {
    const res = await chrome.runtime.sendMessage({ type: 'GET_PALETTE_DATA' });
    if (res && Array.isArray(res.customActions)) {
      paletteData = { customActions: res.customActions, actionStats: res.actionStats || {} };
      paletteDataAt = Date.now();
    }
  } catch { /* worker unavailable: keep the last copy */ }
  return paletteData;
}

/**
 * Actions for a context: built-ins plus matching custom actions, optionally ordered by usage.
 * @param {object} context
 * @param {object} settings
 * @returns {Promise<Array<object>>}
 */
async function resolveActions(context, settings) {
  const data = await loadPaletteData();
  const actions = getActionsForContext(context, data.customActions);
  return settings && settings.learnActionOrder === false ? actions : promoteFrequentActions(actions, data.actionStats);
}

/**
 * Is the focus in a text field or editor? Auto popups must not appear there: Enter or a digit
 * typed right after selecting would run an action instead of editing the text.
 * @returns {boolean}
 */
function isEditingText() {
  let el = document.activeElement;
  while (el && el.shadowRoot && el.shadowRoot.activeElement) el = el.shadowRoot.activeElement;
  if (!el) return false;
  const tag = (el.tagName || '').toLowerCase();
  return tag === 'textarea' || tag === 'input' || el.isContentEditable === true;
}

/**
 * Get surrounding text before and after selection.
 * @param {Selection} selection 
 * @returns {{ before: string, after: string }}
 */
function getSurroundingText(selection) {
  try {
    if (!selection || selection.rangeCount === 0) {
      return { before: '', after: '' };
    }

    const range = selection.getRangeAt(0);
    const container = range.commonAncestorContainer;
    const fullText = container.textContent || '';
    const selectedText = selection.toString();

    const startIndex = fullText.indexOf(selectedText);
    if (startIndex === -1) {
      return { before: '', after: '' };
    }

    const before = fullText.slice(Math.max(0, startIndex - 100), startIndex);
    const after = fullText.slice(startIndex + selectedText.length, startIndex + selectedText.length + 100);

    return {
      before: sanitizeText(before, 100),
      after: sanitizeText(after, 100)
    };
  } catch {
    return { before: '', after: '' };
  }
}

/**
 * Check if the active target element is a sensitive field.
 * @returns {boolean}
 */
function isSensitiveTarget() {
  const active = document.activeElement;
  if (!active) return false;
  const tagName = active.tagName.toLowerCase();
  const inputType = (active.getAttribute('type') || '').toLowerCase();

  return tagName === 'input' && (inputType === 'password' || inputType === 'hidden');
}

/**
 * Extract full context object from current selection and active page.
 * @returns {object|null}
 */
export function extractContext() {
  if (isSensitiveTarget()) return null;

  const selection = window.getSelection();
  // Text selected inside a web component's shadow root (e.g. MDN code samples)
  const shadowRange = getShadowAwareRange(selection);
  let rawText = shadowRange ? shadowRange.toString() : (selection ? selection.toString() : '');

  // Also check active inputs or textareas if selection is empty
  if (!rawText && document.activeElement) {
    const el = document.activeElement;
    if (el.tagName === 'TEXTAREA' || (el.tagName === 'INPUT' && (el.type === 'text' || el.type === 'search' || !el.type))) {
      const start = el.selectionStart;
      const end = el.selectionEnd;
      if (typeof start === 'number' && typeof end === 'number' && start !== end) {
        rawText = el.value.substring(start, end);
      }
    }
  }

  const text = sanitizeText(rawText, 500);

  const domainContext = classifyDomain(window.location.href, document.title);
  const textContext = classifyText(text, domainContext);
  const surrounding = getSurroundingText(selection);

  return {
    selection: {
      text,
      length: text.length,
      surrounding
    },
    page: {
      url: window.location.href,
      domain: domainContext.domain,
      title: document.title,
      path: domainContext.path
    },
    detected: {
      siteType: domainContext.siteType,
      language: textContext.language || domainContext.language,
      category: textContext.category,
      subcategory: textContext.subcategory,
      confidence: textContext.confidence,
      reasoning: textContext.reasoning,
      repoOwner: domainContext.repoOwner,
      repoName: domainContext.repoName,
      packageName: domainContext.packageName
    },
    timestamp: Date.now()
  };
}

/**
 * Trigger the floating command palette for active selection.
 */
export async function triggerFloatingPalette() {
  if (!isInstanceActive()) return;
  const settings = cachedSettings || await getSettings();
  if (isDomainBlacklisted(window.location.href, settings)) return;
  if (settings.triggerMode === TRIGGER_MODES.RIGHT_CLICK_ONLY) return;
  if (popupManager.isSelectionInside(window.getSelection())) return;

  const context = extractContext();
  if (!context || !context.selection.text.trim()) return;

  if (settings.searchMode && settings.searchMode !== 'auto') {
    context.mode = settings.searchMode;
    if (context.mode === 'general') {
      context.detected.language = 'general';
    }
  }

  const actions = await resolveActions(context, settings);
  popupManager.show(context, actions, settings);
}

/**
 * Run one action directly (right-click menu, toolbar popup) without showing the palette first.
 * @param {string} actionId
 * @param {string} [selectionText] Text from the caller when the page selection is gone
 * @returns {Promise<boolean>}
 */
async function runActionById(actionId, selectionText = '') {
  if (!isInstanceActive()) return false;
  const settings = cachedSettings || await getSettings();
  const context = extractContext();
  if (!context) return false;
  if (!context.selection.text.trim() && selectionText) {
    const text = sanitizeText(selectionText, 500);
    const domainContext = classifyDomain(window.location.href, document.title);
    const textContext = classifyText(text, domainContext);
    context.selection = { text, length: text.length, surrounding: { before: '', after: '' } };
    context.detected = {
      ...context.detected,
      language: textContext.language || domainContext.language,
      category: textContext.category,
      subcategory: textContext.subcategory
    };
  }
  if (!context.selection.text.trim()) return false;
  if (settings.searchMode && settings.searchMode !== 'auto') {
    context.mode = settings.searchMode;
    if (context.mode === 'general') context.detected.language = 'general';
  }
  const data = await loadPaletteData();
  const action = ACTION_DEFINITIONS[actionId] || data.customActions.find(a => a.id === actionId);
  if (!action) return false;
  const actions = await resolveActions(context, settings);
  popupManager.runAction(action, context, actions, settings);
  return true;
}

/**
 * Dispatch updated context to background worker and handle auto triggers.
 */
export async function dispatchContextUpdate() {
  try {
    const settings = cachedSettings || await getSettings();
    if (isDomainBlacklisted(window.location.href, settings)) return;

    // Selecting text inside our own panel (e.g. to copy part of an answer) is not a new query
    if (popupManager.isSelectionInside(window.getSelection())) return;

    const context = extractContext();
    if (!context) {
      popupManager.hideBubble();
      return;
    }

    if (settings.searchMode && settings.searchMode !== 'auto') {
      context.mode = settings.searchMode;
      if (context.mode === 'general') {
        context.detected.language = 'general';
      }
    }

    // Send context update to background (only for real selections: an empty one would just wake
    // the service worker on every click on every page)
    const payloadHash = `${context.selection.text}::${context.detected.category}::${context.page.url}`;
    if (context.selection.text && payloadHash !== lastSentPayloadHash) {
      lastSentPayloadHash = payloadHash;
      if (chrome && chrome.runtime && chrome.runtime.sendMessage) {
        chrome.runtime.sendMessage({
          type: 'CONTEXT_UPDATED',
          payload: context
        }).catch(() => {});
      }
    }

    // Handle selection UI trigger modes
    const selection = window.getSelection();
    const autoMode = settings.triggerMode === TRIGGER_MODES.AUTO_SELECT || settings.triggerMode === TRIGGER_MODES.HOVER_ICON;

    if (context.selection.text.trim().length > 0) {
      // Never replace an open AI answer or pop up inside a text field; the shortcut still works there
      if (!autoMode || isEditingText() || popupManager.isAiPanelOpen()) return;
      if (context.selection.text === lastAutoShownText) return;
      lastAutoShownText = context.selection.text;
      if (settings.triggerMode === TRIGGER_MODES.AUTO_SELECT) {
        const actions = await resolveActions(context, settings);
        popupManager.show(context, actions, settings);
      } else {
        popupManager.showBubble(selection, async () => {
          const actions = await resolveActions(context, settings);
          popupManager.show(context, actions, settings);
        });
      }
    } else {
      lastAutoShownText = '';
      popupManager.hideBubble();
    }
  } catch (err) {
    console.debug('[ContextSearch] Selection handling note:', err);
  }
}

function handleSelectionEvent() {
  if (!isInstanceActive()) return;
  clearTimeout(debounceTimer);
  debounceTimer = setTimeout(() => {
    dispatchContextUpdate();
  }, 120);
}

// In-page keyboard shortcut fallback: Ctrl+Shift+Space or Command+Shift+Space
window.addEventListener('keydown', (e) => {
  const isSpace = e.code === 'Space' || e.key === ' ' || e.keyCode === 32;
  const isModifier = (e.ctrlKey || e.metaKey) && e.shiftKey;
  if (isSpace && isModifier && isInstanceActive()) {
    e.preventDefault();
    e.stopPropagation();
    triggerFloatingPalette();
  }
}, true);

document.addEventListener('selectionchange', handleSelectionEvent, { passive: true });
document.addEventListener('mouseup', handleSelectionEvent, { passive: true });

// Listen for messages from background or popup
if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!message) return;

    if (!isInstanceActive()) return false;

    if (message.type === 'GET_CURRENT_CONTEXT') {
      const context = extractContext();
      sendResponse({ success: true, context });
    } else if (message.type === 'TRIGGER_FLOATING_PALETTE' || message.type === 'TRIGGER_FLOATING_POPUP') {
      triggerFloatingPalette();
      sendResponse({ success: true });
    } else if (message.type === 'RUN_ACTION' && typeof message.actionId === 'string') {
      runActionById(message.actionId, typeof message.selectionText === 'string' ? message.selectionText : '')
        .then((ok) => sendResponse({ success: ok }))
        .catch(() => sendResponse({ success: false }));
      return true; // async response
    }
    return false;
  });
}

// Keep cached settings and custom actions fresh when changed from Options
if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.onChanged) {
  chrome.storage.onChanged.addListener((changes) => {
    if (changes.contextSearchSettings) {
      getSettings().then(s => { cachedSettings = s; }).catch(() => {});
    }
  });
}

// Initial settings load
getSettings().then(s => { cachedSettings = s; }).catch(() => {});
