/**
 * Dynamic ESM Loader for ContextSearch Content Script in Chrome MV3.
 */
(async () => {
  try {
    const src = chrome.runtime.getURL('src/content/content-script.js');
    await import(src);
  } catch (err) {
    console.debug('[ContextSearch] Content script load error:', err);
  }
})();
