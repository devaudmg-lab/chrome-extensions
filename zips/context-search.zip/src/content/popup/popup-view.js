/**
 * View templates and DOM rendering for ContextSearch Floating Popup.
 */

import { truncate, escapeHtml } from '../../shared/utils.js';

/**
 * Render the complete floating popup HTML.
 * @param {object} context 
 * @param {Array<object>} actions 
 * @param {string} [theme='dark'] 
 * @returns {string}
 */
export function renderPopupHTML(context, actions, theme = 'dark') {
  const selectionText = context?.selection?.text || '';
  const snippet = truncate(selectionText, 24) || 'Search Actions';
  const detected = context?.detected || {};
  const siteType = detected.siteType ? detected.siteType.toUpperCase() : 'WEB';
  const language = detected.language || 'JS';

  const themeClass = theme === 'light' ? 'cs-theme-light' : 'cs-theme-dark';

  const actionRows = actions.map((action, index) => {
    const num = index + 1;
    let label = action.title && action.title.includes('%s')
      ? action.title.replace('%s', truncate(selectionText, 14))
      : (action.shortLabel || action.name || 'Action');
    // Titles such as '🧠 Explain "%s"' already carry the icon shown in its own column
    if (action.icon && label.startsWith(action.icon)) label = label.slice(action.icon.length).trim();

    return `
      <div class="cs-action-row ${index === 0 ? 'cs-selected' : ''}" role="option" id="cs-action-${index}" aria-selected="${index === 0 ? 'true' : 'false'}" data-action-id="${escapeHtml(action.id)}" data-index="${index}">
        <div class="cs-action-left">
          <span class="cs-num-key" aria-hidden="true">${num}</span>
          <span class="cs-action-icon" aria-hidden="true">${escapeHtml(action.icon)}</span>
          <span class="cs-action-label">${escapeHtml(label)}</span>
        </div>
        <span class="cs-badge-target" aria-hidden="true">${escapeHtml(action.badge || '↗')}</span>
      </div>
    `;
  }).join('');

  const mode = context?.mode || (detected.language === 'general' ? 'general' : 'developer');
  const isGeneral = mode === 'general';
  const modeLabel = isGeneral ? '🌐 General' : '💻 Dev';
  const langTag = isGeneral ? 'GENERAL' : (language || 'DEV').toUpperCase();

  return `
    <div class="cs-popup-container ${themeClass}" role="dialog" aria-label="ContextSearch actions">
      <div class="cs-header">
        <div class="cs-header-left">
          <span class="cs-logo">✨</span>
          <span class="cs-title-snippet" title="${escapeHtml(selectionText)}">${escapeHtml(snippet)}</span>
        </div>
        <div class="cs-header-right">
          <button type="button" class="cs-mode-toggle" id="cs-mode-toggle" title="Switch between Developer and General mode">${modeLabel}</button>
          <button type="button" class="cs-close-btn" id="cs-btn-close" title="Close (Esc)" aria-label="Close">✕</button>
        </div>
      </div>

      <div class="cs-actions-list" id="cs-actions-container" role="listbox" aria-label="Actions" aria-activedescendant="cs-action-0">
        ${actionRows}
      </div>

      <form class="cs-ask" id="cs-ask" autocomplete="off">
        <input type="text" id="cs-ask-input" class="cs-ask-input" maxlength="500"
          placeholder="Ask AI about this…  ( / )" aria-label="Ask the AI a question about the selected text">
        <button type="submit" class="cs-ask-send" title="Ask (Enter)" aria-label="Ask">➤</button>
      </form>

      <div class="cs-footer">
        <div class="cs-context-meta">
          <span class="cs-tag">${escapeHtml(siteType)}</span>
          <span class="cs-tag">${escapeHtml(langTag)}</span>
        </div>
        <span class="cs-hint">1-${actions.length} · ↵ · / ask</span>
      </div>
    </div>
  `;
}

/**
 * Render the hover trigger bubble.
 * @returns {string}
 */
export function renderBubbleHTML() {
  return `<div class="cs-hover-bubble" id="cs-bubble-trigger" role="button" tabindex="0" aria-label="Open ContextSearch actions" title="Open ContextSearch (Ctrl+Shift+Space)">✨</div>`;
}
