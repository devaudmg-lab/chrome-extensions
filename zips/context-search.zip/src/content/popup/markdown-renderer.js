/**
 * Lightweight, zero-dependency Markdown-to-HTML parser for ContextSearch (Phase 3).
 * Renders syntax-fenced code blocks, copy buttons, bold/italic, lists, and links safely.
 *
 * Safety model: every piece of model output is HTML-escaped first; only the tags this file
 * writes itself are ever produced, and links are limited to http(s).
 */

function escapeHtml(str) {
  if (!str) return '';
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

const TOKEN_OPEN = '\u0000CS';
const TOKEN_CLOSE = '\u0000';

/**
 * Inline formatting for one already-escaped line: `code`, [links](https://...), **bold**, *italic*.
 * Code spans and links are set aside first so emphasis markers inside them (snake_case names,
 * URLs with underscores, `a * b`) are left alone.
 * @param {string} text
 * @returns {string}
 */
function renderInline(text) {
  const saved = [];
  const keep = (html) => `${TOKEN_OPEN}${saved.push(html) - 1}${TOKEN_CLOSE}`;

  let out = text.replace(/`([^`\n]+)`/g, (_m, code) => keep(`<code>${code}</code>`));

  out = out.replace(/\[([^\]\n]+)\]\((https?:\/\/[^\s)]+)\)/g, (_m, label, url) =>
    keep(`<a href="${url}" target="_blank" rel="noopener noreferrer">${renderEmphasis(label)} ↗</a>`));

  out = renderEmphasis(out);

  // Restore (code spans inside link labels were kept first, so loop until stable)
  let prev;
  do {
    prev = out;
    out = out.replace(/\u0000CS(\d+)\u0000/g, (_m, i) => saved[Number(i)] ?? '');
  } while (out !== prev && out.includes(TOKEN_OPEN));
  return out;
}

/**
 * **bold**, __bold__, *italic*, _italic_ with word-boundary rules so `a * b * c`, `snake_case`
 * and list bullets are not mistaken for emphasis.
 * @param {string} text
 * @returns {string}
 */
function renderEmphasis(text) {
  return text
    .replace(/\*\*(?=\S)([^*\n]+?)(?<=\S)\*\*/g, '<strong>$1</strong>')
    .replace(/(^|[^\w])__(?=\S)([^_\n]+?)(?<=\S)__(?!\w)/g, '$1<strong>$2</strong>')
    .replace(/(^|[^\w*])\*([^\s*](?:[^*\n]*?[^\s*])?)\*(?![\w*])/g, '$1<em>$2</em>')
    .replace(/(^|[^\w])_(?=\S)([^_\n]+?)(?<=\S)_(?!\w)/g, '$1<em>$2</em>');
}

/**
 * Convert Markdown text into HTML.
 * @param {string} markdown
 * @returns {string}
 */
export function renderMarkdown(markdown) {
  if (!markdown || typeof markdown !== 'string') return '';

  // Normalize all line endings (\r\n, \r -> \n) and drop NULs (used for our own tokens)
  let text = markdown.replace(/\r\n?/g, '\n').replace(/\u0000/g, '');

  // While an answer is still streaming its last code fence may not be closed yet
  if (((text.match(/```/g) || []).length % 2) === 1) text += '\n```';

  // 1. Extract fenced code blocks
  const codeBlocks = [];
  text = text.replace(/```([a-zA-Z0-9_+\-#.]*)[^\n]*\n([\s\S]*?)```/g, (_match, lang, code) => {
    const cleanCode = code.replace(/^\n+|\s+$/g, '');
    const displayLang = escapeHtml((lang || 'code').trim().toLowerCase());
    codeBlocks.push(`<div class="cs-code-container"><div class="cs-code-header"><span class="cs-code-lang">${displayLang}</span><button type="button" class="cs-code-copy-btn" data-code="${escapeHtml(cleanCode)}">📋 Copy</button></div><pre><code class="language-${displayLang}">${escapeHtml(cleanCode)}</code></pre></div>`);
    return `\n${TOKEN_OPEN}BLOCK${codeBlocks.length - 1}${TOKEN_CLOSE}\n`;
  });

  // 2. Escape all remaining raw HTML so model output (or page text echoed back) can never inject markup
  text = escapeHtml(text);

  // 3. Block structure, line by line
  const lines = text.split('\n');
  const html = [];
  let paragraph = [];
  let list = null; // { type: 'ul'|'ol', items: [] }
  let quote = [];

  const flushParagraph = () => {
    if (paragraph.length) html.push(`<p>${paragraph.map(renderInline).join('<br/>')}</p>`);
    paragraph = [];
  };
  const flushList = () => {
    if (list) html.push(`<${list.type}>${list.items.map(i => `<li>${renderInline(i)}</li>`).join('\n')}</${list.type}>`);
    list = null;
  };
  const flushQuote = () => {
    if (quote.length) html.push(`<blockquote>${quote.map(renderInline).join('<br/>')}</blockquote>`);
    quote = [];
  };
  const flushAll = () => { flushParagraph(); flushList(); flushQuote(); };

  for (const rawLine of lines) {
    const line = rawLine.replace(/\s+$/, '');
    const block = line.trim().match(/^\u0000CSBLOCK(\d+)\u0000$/);
    if (block) {
      flushAll();
      html.push(codeBlocks[Number(block[1])] || '');
      continue;
    }
    if (!line.trim()) { flushAll(); continue; }

    const heading = line.match(/^(#{1,6})\s+(.*)$/);
    if (heading) {
      flushAll();
      const level = Math.min(heading[1].length, 3);
      html.push(`<h${level}>${renderInline(heading[2])}</h${level}>`);
      continue;
    }

    if (/^\s*([-*_])(\s*\1){2,}\s*$/.test(line)) { flushAll(); html.push('<hr/>'); continue; }

    const quoteLine = line.match(/^\s*&gt;\s?(.*)$/);
    if (quoteLine) { flushParagraph(); flushList(); quote.push(quoteLine[1]); continue; }

    const ul = line.match(/^\s*[-*+]\s+(.*)$/);
    const ol = !ul && line.match(/^\s*\d+[.)]\s+(.*)$/);
    if (ul || ol) {
      flushParagraph(); flushQuote();
      const type = ul ? 'ul' : 'ol';
      if (list && list.type !== type) flushList();
      if (!list) list = { type, items: [] };
      list.items.push((ul || ol)[1]);
      continue;
    }

    // Plain text: continues an open list item or quote only if it is indented / lazy continuation
    if (list && /^\s{2,}\S/.test(rawLine)) { list.items[list.items.length - 1] += `<br/>${line.trim()}`; continue; }
    flushList(); flushQuote();
    paragraph.push(line);
  }
  flushAll();

  return html.join('');
}
