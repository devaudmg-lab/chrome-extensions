/**
 * Lightweight, zero-dependency Markdown-to-HTML parser for ContextSearch (Phase 3).
 * Renders syntax-fenced code blocks, copy buttons, bold/italic, lists, and links safely.
 */

function escapeHtml(str) {
  if (!str) return '';
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

/**
 * Convert Markdown text into HTML.
 * @param {string} markdown 
 * @returns {string}
 */
export function renderMarkdown(markdown) {
  if (!markdown || typeof markdown !== 'string') return '';

  // Normalize all line endings (\r\n, \r -> \n)
  let text = markdown.replace(/\r\n?/g, '\n');

  // 1. Extract and replace code blocks with underscore-free token placeholders
  const codeBlocks = [];
  text = text.replace(/```([a-zA-Z0-9_+\-]*)[^\n]*\n([\s\S]*?)```/g, (_match, lang, code) => {
    const placeholder = `§§CSCODEBLOCK${codeBlocks.length}TOKEN§§`;
    const cleanCode = code.trim();
    const escapedCode = escapeHtml(cleanCode);
    const displayLang = escapeHtml((lang || 'code').trim().toLowerCase());

    const blockHtml = `<div class="cs-code-container"><div class="cs-code-header"><span class="cs-code-lang">${displayLang}</span><button class="cs-code-copy-btn" data-code="${escapeHtml(cleanCode)}">📋 Copy</button></div><pre><code class="language-${displayLang}">${escapedCode}</code></pre></div>`;

    codeBlocks.push(blockHtml);
    return `\n\n${placeholder}\n\n`;
  });

  // 2. Escape all remaining raw HTML so model output (or page text echoed back) can never inject markup
  text = escapeHtml(text);

  // 3. Inline code (already escaped above)
  text = text.replace(/`([^`\n]+)`/g, (_match, code) => `<code>${code}</code>`);

  // 3. Headers
  text = text.replace(/^###\s+(.*)$/gm, '<h3>$1</h3>');
  text = text.replace(/^##\s+(.*)$/gm, '<h2>$1</h2>');
  text = text.replace(/^#\s+(.*)$/gm, '<h1>$1</h1>');

  // 3b. Blockquotes ("> note", escaped to "&gt; note" above); adjacent lines merge
  text = text.replace(/^&gt;\s?(.*)$/gm, '<blockquote>$1</blockquote>');
  text = text.replace(/<\/blockquote>\n<blockquote>/g, '<br/>');

  // 4. Bold & Italic
  text = text.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
  text = text.replace(/__([^_]+)__/g, '<strong>$1</strong>');
  text = text.replace(/\*([^*]+)\*/g, '<em>$1</em>');
  text = text.replace(/_([^_]+)_/g, '<em>$1</em>');

  // 5. Links
  text = text.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1 ↗</a>');

  // 6. Unordered lists
  text = text.replace(/^\s*[-*]\s+(.*)$/gm, '<li>$1</li>');
  text = text.replace(/(<li>.*<\/li>(\n|$))+/g, '<ul>$&</ul>');

  // 7. Numbered lists
  text = text.replace(/^\s*(\d+)\.\s+(.*)$/gm, '<oli>$2</oli>');
  text = text.replace(/(<oli>.*<\/oli>(\n|$))+/g, (m) => `<ol>${m.replace(/<(\/?)oli>/g, '<$1li>')}</ol>`);

  // 8. Paragraphs
  const sections = text.split(/\n{2,}/);
  let html = sections
    .map(sec => {
      const trimmed = sec.trim();
      if (!trimmed) return '';
      if (
        trimmed.startsWith('<h') ||
        trimmed.startsWith('<ul') ||
        trimmed.startsWith('<ol') ||
        trimmed.startsWith('<blockquote') ||
        trimmed.includes('§§CSCODEBLOCK')
      ) {
        return trimmed;
      }
      return `<p>${trimmed.replace(/\n/g, '<br/>')}</p>`;
    })
    .join('');

  // 9. Restore code blocks
  codeBlocks.forEach((block, idx) => {
    html = html.split(`§§CSCODEBLOCK${idx}TOKEN§§`).join(block);
  });

  return html;
}
