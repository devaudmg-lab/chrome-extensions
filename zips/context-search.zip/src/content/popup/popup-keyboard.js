/**
 * Keyboard Navigation Handler for ContextSearch Floating Popup.
 */

export class PopupKeyboardNavigator {
  /**
   * @param {ShadowRoot} shadowRoot 
   * @param {number} actionCount 
   * @param {Function} onExecute 
   * @param {Function} onClose 
   */
  constructor(shadowRoot, actionCount, onExecute, onClose) {
    this.shadowRoot = shadowRoot;
    this.actionCount = actionCount;
    this.selectedIndex = 0;
    this.onExecute = onExecute;
    this.onClose = onClose;
    this.keyHandler = this.handleKeyDown.bind(this);
  }

  attach() {
    window.addEventListener('keydown', this.keyHandler, true);
    this.updateHighlight();
  }

  detach() {
    window.removeEventListener('keydown', this.keyHandler, true);
  }

  setSelectedIndex(index) {
    if (index >= 0 && index < this.actionCount) {
      this.selectedIndex = index;
      this.updateHighlight();
    }
  }

  updateHighlight() {
    if (!this.shadowRoot) return;
    const rows = this.shadowRoot.querySelectorAll('.cs-action-row');
    rows.forEach((row, idx) => {
      if (idx === this.selectedIndex) {
        row.classList.add('cs-selected');
        row.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
      } else {
        row.classList.remove('cs-selected');
      }
    });
  }

  handleKeyDown(event) {
    if (!this.shadowRoot) return;

    // Direct number shortcut (1-9)
    const num = parseInt(event.key, 10);
    if (!isNaN(num) && num >= 1 && num <= this.actionCount && !event.ctrlKey && !event.metaKey && !event.altKey) {
      event.preventDefault();
      event.stopPropagation();
      this.selectedIndex = num - 1;
      this.updateHighlight();
      this.onExecute(this.selectedIndex);
      return;
    }

    switch (event.key) {
      case 'ArrowDown': {
        event.preventDefault();
        event.stopPropagation();
        this.selectedIndex = (this.selectedIndex + 1) % this.actionCount;
        this.updateHighlight();
        break;
      }

      case 'ArrowUp': {
        event.preventDefault();
        event.stopPropagation();
        this.selectedIndex = (this.selectedIndex - 1 + this.actionCount) % this.actionCount;
        this.updateHighlight();
        break;
      }

      case 'Enter': {
        event.preventDefault();
        event.stopPropagation();
        this.onExecute(this.selectedIndex);
        break;
      }

      case 'Escape': {
        event.preventDefault();
        event.stopPropagation();
        this.onClose();
        break;
      }
    }
  }
}
