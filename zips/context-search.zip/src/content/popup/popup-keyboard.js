/**
 * Keyboard Navigation Handler for ContextSearch Floating Popup.
 */

export class PopupKeyboardNavigator {
  /**
   * @param {ShadowRoot} shadowRoot 
   * @param {number} actionCount 
   * @param {Function} onExecute 
   * @param {Function} onClose 
   * @param {Function} [onFocusAsk] "/" moves focus to the Ask box
   */
  constructor(shadowRoot, actionCount, onExecute, onClose, onFocusAsk = null) {
    this.shadowRoot = shadowRoot;
    this.actionCount = actionCount;
    this.selectedIndex = 0;
    this.onExecute = onExecute;
    this.onClose = onClose;
    this.onFocusAsk = onFocusAsk;
    this.keyHandler = this.handleKeyDown.bind(this);
  }

  attach() {
    window.addEventListener('keydown', this.keyHandler, true);
    this.updateHighlight();
  }

  detach() {
    window.removeEventListener('keydown', this.keyHandler, true);
  }

  setSelectedIndex(index) {
    if (index >= 0 && index < this.actionCount) {
      this.selectedIndex = index;
      this.updateHighlight();
    }
  }

  updateHighlight() {
    if (!this.shadowRoot) return;
    const rows = this.shadowRoot.querySelectorAll('.cs-action-row');
    const list = this.shadowRoot.getElementById('cs-actions-container');
    if (list) list.setAttribute('aria-activedescendant', `cs-action-${this.selectedIndex}`);
    rows.forEach((row, idx) => {
      row.setAttribute('aria-selected', idx === this.selectedIndex ? 'true' : 'false');
      if (idx === this.selectedIndex) {
        row.classList.add('cs-selected');
        row.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
      } else {
        row.classList.remove('cs-selected');
      }
    });
  }

  handleKeyDown(event) {
    if (!this.shadowRoot) return;

    // Typing in the palette's Ask box: only Esc is ours (the form handles Enter)
    const focused = this.shadowRoot.activeElement;
    if (focused && focused.tagName === 'INPUT') {
      if (event.key === 'Escape') {
        event.preventDefault();
        event.stopPropagation();
        // First Esc clears the box and returns to the action list (digits work again)
        if (focused.value) {
          focused.value = '';
          focused.blur();
        } else {
          this.onClose();
        }
      }
      return;
    }

    if (event.key === '/' && this.onFocusAsk && !event.ctrlKey && !event.metaKey && !event.altKey) {
      const t = event.composedPath()[0];
      const tag = t && t.tagName ? t.tagName.toLowerCase() : '';
      if (tag === 'input' || tag === 'textarea' || (t && t.isContentEditable)) return;
      event.preventDefault();
      event.stopPropagation();
      this.onFocusAsk();
      return;
    }

    // Direct number shortcut (1-9)
    const num = parseInt(event.key, 10);
    if (!isNaN(num) && num >= 1 && num <= this.actionCount && !event.ctrlKey && !event.metaKey && !event.altKey) {
      event.preventDefault();
      event.stopPropagation();
      this.selectedIndex = num - 1;
      this.updateHighlight();
      this.onExecute(this.selectedIndex);
      return;
    }

    switch (event.key) {
      case 'ArrowDown': {
        event.preventDefault();
        event.stopPropagation();
        this.selectedIndex = (this.selectedIndex + 1) % this.actionCount;
        this.updateHighlight();
        break;
      }

      case 'ArrowUp': {
        event.preventDefault();
        event.stopPropagation();
        this.selectedIndex = (this.selectedIndex - 1 + this.actionCount) % this.actionCount;
        this.updateHighlight();
        break;
      }

      case 'Enter': {
        event.preventDefault();
        event.stopPropagation();
        this.onExecute(this.selectedIndex);
        break;
      }

      case 'Escape': {
        event.preventDefault();
        event.stopPropagation();
        this.onClose();
        break;
      }
    }
  }
}
