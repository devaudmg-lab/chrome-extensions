/**
 * Isolated CSS styles injected into ContextSearch Shadow DOM (Phase 3).
 */

export const POPUP_STYLES = `
:host {
  all: initial;
  z-index: 2147483647;
  position: absolute;
  top: 0;
  left: 0;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
  color-scheme: dark;
  pointer-events: none;
}

.cs-theme-dark {
  --cs-bg: rgba(15, 23, 42, 0.96);
  --cs-card-bg: rgba(30, 41, 59, 0.85);
  --cs-card-hover: rgba(51, 65, 85, 0.95);
  --cs-border: rgba(148, 163, 184, 0.2);
  --cs-text-main: #f8fafc;
  --cs-text-sub: #94a3b8;
  --cs-text-muted: #8a99b0;
  --cs-accent: #38bdf8;
  --cs-on-accent: #0f172a;
  --cs-glow: rgba(56, 189, 248, 0.25);
  --cs-code-bg: rgba(10, 15, 30, 0.9);
  --cs-shadow: 0 14px 30px -5px rgba(0, 0, 0, 0.6), 0 8px 10px -6px rgba(0, 0, 0, 0.4);
}

.cs-theme-light {
  --cs-bg: rgba(255, 255, 255, 0.98);
  --cs-card-bg: rgba(241, 245, 249, 0.9);
  --cs-card-hover: rgba(226, 232, 240, 1);
  --cs-border: rgba(203, 213, 225, 0.8);
  --cs-text-main: #0f172a;
  --cs-text-sub: #475569;
  --cs-text-muted: #64748b;
  --cs-accent: #0369a1;
  --cs-on-accent: #ffffff;
  --cs-glow: rgba(2, 132, 199, 0.2);
  --cs-code-bg: rgba(241, 245, 249, 0.95);
  --cs-shadow: 0 14px 30px -5px rgba(0, 0, 0, 0.15), 0 8px 10px -6px rgba(0, 0, 0, 0.1);
}

/* Page styles on the host element are inherited: reset the text basics on our own boxes */
.cs-popup-container,
.cs-hover-bubble {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
  font-size: 13px;
  font-weight: 400;
  font-style: normal;
  line-height: 1.45;
  letter-spacing: normal;
  word-spacing: normal;
  text-align: left;
  text-transform: none;
  text-indent: 0;
  direction: ltr;
  white-space: normal;
  color: var(--cs-text-main, #f8fafc);
}

.cs-popup-container *,
.cs-popup-container *::before,
.cs-popup-container *::after {
  box-sizing: border-box;
}

.cs-popup-container {
  pointer-events: auto;
  position: absolute;
  width: 320px;
  max-width: 92vw;
  background: var(--cs-bg);
  backdrop-filter: blur(16px);
  -webkit-backdrop-filter: blur(16px);
  border: 1px solid var(--cs-border);
  border-radius: 12px;
  box-shadow: var(--cs-shadow);
  padding: 10px;
  display: flex;
  flex-direction: column;
  gap: 8px;
  opacity: 0;
  transform: translateY(6px) scale(0.98);
  transition: opacity 0.15s cubic-bezier(0.16, 1, 0.3, 1), transform 0.15s cubic-bezier(0.16, 1, 0.3, 1);
  box-sizing: border-box;
  user-select: none;
}

.cs-ai-panel-container {
  width: 440px;
  max-height: 540px;
  user-select: text;
}

.cs-popup-container.cs-visible {
  opacity: 1;
  transform: translateY(0) scale(1);
}

/* Header */
.cs-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding-bottom: 6px;
  border-bottom: 1px solid var(--cs-border);
}

.cs-header-left {
  display: flex;
  align-items: center;
  gap: 6px;
  overflow: hidden;
}

.cs-logo {
  font-size: 14px;
}

.cs-title-snippet {
  font-size: 12px;
  font-weight: 600;
  color: var(--cs-text-main);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  max-width: 320px;
  font-family: 'Fira Code', Consolas, Monaco, monospace;
}

.cs-header-right {
  display: flex;
  align-items: center;
  gap: 4px;
}

.cs-mode-toggle {
  background: rgba(56, 189, 248, 0.12);
  border: 1px solid rgba(56, 189, 248, 0.3);
  color: var(--cs-accent);
  font-size: 9.5px;
  font-weight: 600;
  padding: 2px 6px;
  border-radius: 10px;
  cursor: pointer;
  transition: all 0.12s ease;
  white-space: nowrap;
}

.cs-mode-toggle:hover {
  background: rgba(56, 189, 248, 0.22);
  transform: translateY(-1px);
}

.cs-close-btn {
  background: transparent;
  border: none;
  color: var(--cs-text-muted);
  cursor: pointer;
  padding: 2px 4px;
  font-size: 12px;
  border-radius: 4px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.cs-close-btn:hover {
  color: var(--cs-text-main);
  background: var(--cs-card-bg);
}

/* Action Items List */
.cs-actions-list {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.cs-action-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 6px 8px;
  background: var(--cs-card-bg);
  border: 1px solid transparent;
  border-radius: 6px;
  cursor: pointer;
  transition: all 0.1s ease;
  text-decoration: none;
}

.cs-action-row:hover,
.cs-action-row.cs-selected {
  background: var(--cs-card-hover);
  border-color: var(--cs-accent);
  box-shadow: 0 0 8px var(--cs-glow);
  transform: translateX(2px);
}

.cs-action-left {
  display: flex;
  align-items: center;
  gap: 7px;
  overflow: hidden;
}

.cs-num-key {
  font-size: 10px;
  font-weight: 700;
  color: var(--cs-text-muted);
  background: rgba(148, 163, 184, 0.15);
  border-radius: 3px;
  padding: 1px 4px;
  min-width: 14px;
  text-align: center;
}

.cs-action-icon {
  font-size: 13px;
}

.cs-action-label {
  font-size: 12px;
  font-weight: 500;
  color: var(--cs-text-main);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  max-width: 190px;
}

.cs-badge-target {
  font-size: 10px;
  font-weight: 600;
  color: var(--cs-text-muted);
  font-family: monospace;
  background: rgba(148, 163, 184, 0.1);
  padding: 2px 5px;
  border-radius: 4px;
}

/* AI Body & Markdown */
.cs-ai-body {
  max-height: 380px;
  overflow-y: auto;
  padding: 4px 2px;
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.cs-ai-content {
  font-size: 12.5px;
  line-height: 1.55;
  color: var(--cs-text-main);
}

.cs-ai-content p {
  margin: 0 0 8px;
}

.cs-ai-content > :first-child {
  margin-top: 0;
}

.cs-ai-content hr {
  border: 0;
  border-top: 1px solid var(--cs-border);
  margin: 8px 0;
}

.cs-ai-content h1, .cs-ai-content h2, .cs-ai-content h3 {
  font-size: 13px;
  font-weight: 700;
  margin: 10px 0 4px 0;
  color: var(--cs-accent);
}

.cs-ai-content ul, .cs-ai-content ol {
  margin: 4px 0 8px 18px;
  padding: 0;
}

.cs-ai-content li {
  margin-bottom: 3px;
}

.cs-ai-content code {
  font-family: 'Fira Code', Consolas, Monaco, monospace;
  font-size: 11.5px;
  background: rgba(148, 163, 184, 0.15);
  color: #7dd3fc;
  padding: 1px 4px;
  border-radius: 3px;
}

.cs-ai-content a {
  color: var(--cs-accent);
  text-decoration: none;
}

.cs-ai-content a:hover {
  text-decoration: underline;
}

/* Code Blocks */
.cs-code-container {
  background: var(--cs-code-bg);
  border: 1px solid var(--cs-border);
  border-radius: 6px;
  margin: 8px 0;
  overflow: hidden;
}

.cs-code-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 3px 8px;
  background: rgba(148, 163, 184, 0.08);
  border-bottom: 1px solid var(--cs-border);
}

.cs-code-lang {
  font-size: 10px;
  font-weight: 600;
  text-transform: uppercase;
  color: var(--cs-text-muted);
  font-family: monospace;
}

.cs-code-copy-btn {
  background: transparent;
  border: 1px solid var(--cs-border);
  border-radius: 4px;
  color: var(--cs-text-sub);
  font-size: 10px;
  padding: 1px 6px;
  cursor: pointer;
  transition: all 0.1s ease;
}

.cs-code-copy-btn:hover {
  background: var(--cs-card-hover);
  color: var(--cs-text-main);
  border-color: var(--cs-accent);
}

.cs-code-container pre {
  margin: 0;
  padding: 8px 10px;
  overflow-x: auto;
}

.cs-code-container pre code {
  background: transparent;
  padding: 0;
  color: #e2e8f0;
  font-size: 11.5px;
  display: block;
}

/* Shimmer Loading Skeleton */
.cs-shimmer-container {
  display: flex;
  flex-direction: column;
  gap: 8px;
  padding: 6px 0;
}

.cs-shimmer-line {
  height: 12px;
  background: linear-gradient(90deg, rgba(148, 163, 184, 0.1) 25%, rgba(148, 163, 184, 0.25) 50%, rgba(148, 163, 184, 0.1) 75%);
  background-size: 200% 100%;
  animation: cs-shimmer 1.5s infinite;
  border-radius: 4px;
}

.cs-shimmer-title { width: 45%; height: 14px; }
.cs-shimmer-long { width: 95%; }
.cs-shimmer-medium { width: 75%; }
.cs-shimmer-code { width: 100%; height: 48px; }

@keyframes cs-shimmer {
  0% { background-position: 200% 0; }
  100% { background-position: -200% 0; }
}

/* Error Callout */
.cs-ai-error {
  background: rgba(244, 63, 94, 0.1);
  border: 1px solid rgba(244, 63, 94, 0.3);
  border-radius: 6px;
  padding: 10px;
  color: #fda4af;
  font-size: 12px;
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.cs-btn-configure {
  background: linear-gradient(135deg, #6366f1, #38bdf8);
  border: none;
  border-radius: 4px;
  color: #fff;
  padding: 5px 10px;
  font-size: 11px;
  font-weight: 600;
  cursor: pointer;
  width: fit-content;
}

/* Footer */
.cs-footer, .cs-ai-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding-top: 6px;
  border-top: 1px solid var(--cs-border);
  font-size: 10px;
  color: var(--cs-text-muted);
}

.cs-ai-footer-left {
  display: flex;
  align-items: center;
  gap: 6px;
}

.cs-footer-btn {
  background: var(--cs-card-bg);
  border: 1px solid var(--cs-border);
  border-radius: 4px;
  color: var(--cs-text-main);
  font-size: 10.5px;
  padding: 3px 7px;
  cursor: pointer;
  transition: all 0.1s ease;
}

.cs-footer-btn:hover {
  background: var(--cs-card-hover);
  border-color: var(--cs-accent);
}

.cs-ai-meta-badge {
  font-size: 9.5px;
  color: var(--cs-text-muted);
}

.cs-context-meta {
  display: flex;
  align-items: center;
  gap: 5px;
}

.cs-tag {
  background: rgba(56, 189, 248, 0.12);
  color: var(--cs-accent);
  font-weight: 600;
  padding: 1px 5px;
  border-radius: 3px;
  font-size: 9px;
  text-transform: uppercase;
}

.cs-hint {
  font-size: 10px;
}

/* Hover Icon Trigger Bubble */
.cs-hover-bubble {
  pointer-events: auto;
  position: absolute;
  width: 26px;
  height: 26px;
  background: linear-gradient(135deg, #6366f1, #38bdf8);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 4px 12px rgba(56, 189, 248, 0.4);
  cursor: pointer;
  font-size: 13px;
  color: #fff;
  border: 1px solid rgba(255, 255, 255, 0.3);
  transition: transform 0.15s ease, box-shadow 0.15s ease;
  animation: cs-pop 0.15s ease-out;
}

.cs-hover-bubble:hover {
  transform: scale(1.12);
  box-shadow: 0 6px 16px rgba(56, 189, 248, 0.6);
}

.cs-ai-content blockquote {
  margin: 6px 0 8px;
  padding: 6px 10px;
  border-left: 3px solid var(--cs-accent);
  background: var(--cs-card-bg);
  border-radius: 0 6px 6px 0;
  color: var(--cs-text-sub);
  font-size: 11.5px;
}

.cs-ai-content ol {
  margin: 4px 0 8px 18px;
  padding: 0;
}

/* Follow-up chat */
.cs-ai-thread {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.cs-ai-thread:empty {
  display: none;
}

.cs-turn-user {
  align-self: flex-end;
  max-width: 85%;
  background: var(--cs-glow);
  border: 1px solid var(--cs-border);
  color: var(--cs-text-main);
  border-radius: 10px 10px 2px 10px;
  padding: 6px 9px;
  font-size: 12px;
  line-height: 1.45;
  white-space: pre-wrap;
  word-break: break-word;
}

.cs-turn-ai {
  border-left: 2px solid var(--cs-accent);
  padding-left: 8px;
}

.cs-turn-ai .cs-turn-pending {
  font-size: 11px;
  color: var(--cs-text-muted);
  font-style: italic;
}

.cs-turn-error {
  font-size: 11.5px;
  color: #f87171;
}

.cs-followup {
  display: flex;
  gap: 6px;
  margin: 0;
}

.cs-followup-input {
  flex: 1;
  min-width: 0;
  background: var(--cs-card-bg);
  border: 1px solid var(--cs-border);
  border-radius: 6px;
  color: var(--cs-text-main);
  font: inherit;
  font-size: 12px;
  padding: 6px 9px;
  outline: none;
}

.cs-followup-input::placeholder {
  color: var(--cs-text-muted);
}

.cs-followup-input:focus {
  border-color: var(--cs-accent);
  box-shadow: 0 0 0 2px var(--cs-glow);
}

.cs-followup-send {
  background: var(--cs-accent);
  border: none;
  border-radius: 6px;
  color: var(--cs-on-accent);
  font-size: 12px;
  padding: 0 11px;
  cursor: pointer;
}

.cs-followup-send:disabled {
  opacity: 0.5;
  cursor: default;
}

/* Ask anything (palette) */
.cs-ask {
  display: flex;
  gap: 6px;
  margin: 0;
}

.cs-ask-input {
  flex: 1;
  min-width: 0;
  background: var(--cs-card-bg);
  border: 1px solid var(--cs-border);
  border-radius: 6px;
  color: var(--cs-text-main);
  font: inherit;
  font-size: 12px;
  padding: 6px 9px;
  outline: none;
  user-select: text;
}

.cs-ask-input::placeholder {
  color: var(--cs-text-muted);
}

.cs-ask-input:focus {
  border-color: var(--cs-accent);
  box-shadow: 0 0 0 2px var(--cs-glow);
}

.cs-ask-send {
  background: var(--cs-card-bg);
  border: 1px solid var(--cs-border);
  border-radius: 6px;
  color: var(--cs-accent);
  font-size: 12px;
  padding: 0 10px;
  cursor: pointer;
}

.cs-ask-send:hover {
  background: var(--cs-accent);
  color: var(--cs-on-accent);
}

/* Initially hidden parts of the AI panel. Done in the stylesheet, not with style="" attributes:
   pages with a strict style-src CSP block inline style attributes parsed from HTML. */
#cs-ai-content,
#cs-ai-error,
#cs-followup,
#cs-btn-stop,
#cs-btn-regenerate,
#cs-btn-copy-all {
  display: none;
}

/* Keyboard focus is always visible */
.cs-popup-container button:focus-visible,
.cs-action-row:focus-visible,
.cs-hover-bubble:focus-visible,
.cs-ai-content a:focus-visible {
  outline: 2px solid var(--cs-accent);
  outline-offset: 2px;
}

.cs-popup-container.cs-closing {
  pointer-events: none;
}

@media (prefers-reduced-motion: reduce) {
  .cs-popup-container,
  .cs-action-row,
  .cs-hover-bubble {
    transition: none !important;
    animation: none !important;
  }
}

@keyframes cs-pop {
  from { opacity: 0; transform: scale(0.6); }
  to { opacity: 1; transform: scale(1); }
}
`;
