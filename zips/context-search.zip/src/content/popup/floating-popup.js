/**
 * Master Floating Action Popup Manager for ContextSearch (Phase 3).
 * Supports compact action palette and expanded AI streaming results panel.
 *
 * Privacy: everything is rendered inside a CLOSED shadow root that this instance creates itself.
 * Page scripts can see the empty host element but cannot reach the palette, the AI answers or the
 * follow-up conversation (host.shadowRoot is null for them, and composedPath() stops at the host).
 */

import { POPUP_STYLES } from './popup-styles.css.js';
import { calculatePopupPosition, calculateBubblePosition } from './popup-positioner.js';
import { renderPopupHTML, renderBubbleHTML } from './popup-view.js';
import { renderAiPanelHTML } from './ai-panel-view.js';
import { renderMarkdown } from './markdown-renderer.js';
import { PopupKeyboardNavigator } from './popup-keyboard.js';
import { buildTargetUrl } from '../../background/url-builder.js';
import { queryAIViaBackground } from '../../ai/ai-port-client.js';
import { interpolateTemplate } from '../../custom-actions/template-interpolator.js';
import { buildFollowUpPrompt, buildAskPrompt, MAX_FOLLOW_UP_TURNS } from '../../ai/prompt-builder.js';
import { escapeHtml, isSafeHttpUrl } from '../../shared/utils.js';
import { ACTION_TYPES } from '../../shared/constants.js';

export const HOST_ID = 'context-search-host';

// Inline !important wins over page stylesheets that target generic elements (div { ... }).
// Set through CSSOM (style.setProperty), which a strict style-src CSP does not block.
const HOST_STYLE = {
  display: 'block', position: 'absolute', top: '0', left: '0', width: '0', height: '0', margin: '0', padding: '0',
  border: '0', 'z-index': '2147483647', overflow: 'visible', transform: 'none', filter: 'none', opacity: '1',
  visibility: 'visible', 'pointer-events': 'none', contain: 'none'
};

/**
 * Resolve the 'system' theme setting to 'light' or 'dark'.
 * @param {string} theme
 * @returns {string}
 */
export function resolveTheme(theme) {
  if (theme === 'system') {
    try {
      return window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark';
    } catch {
      return 'dark';
    }
  }
  return theme === 'light' ? 'light' : 'dark';
}

/**
 * Stop keystrokes typed into our inputs from reaching page shortcuts (GitHub, YouTube, ...).
 * @param {HTMLElement} input
 */
function isolateKeys(input) {
  ['keydown', 'keyup', 'keypress'].forEach((type) => {
    input.addEventListener(type, (e) => {
      if (e.key !== 'Escape') e.stopPropagation();
    });
  });
}

export class FloatingPopupManager {
  constructor() {
    this.hostElement = null;
    this.shadowRoot = null;
    this.isVisible = false;
    this.isBubbleVisible = false;
    this.activeContext = null;
    this.activeActions = [];
    this.activeSettings = {};
    this.keyboardNav = null;
    this.activeAbortController = null;
    this.conversation = [];
    this.aiKeyHandler = null;
    this.currentAiAction = null;
    this.pointerInside = false;
    this.clickOutsideHandler = this.handleClickOutside.bind(this);
  }

  ensureHost() {
    if (this.hostElement && this.hostElement.isConnected) return;
    if (this.hostElement && !this.hostElement.isConnected) {
      // The page (or a SPA re-render of <html>) removed our host: put the same one back
      document.documentElement.appendChild(this.hostElement);
      return;
    }

    // Always our own element and our own closed root: never adopt an element the page created
    // with the same id (it could carry an open shadow root the page controls).
    this.hostElement = document.createElement('div');
    this.hostElement.id = HOST_ID;
    for (const [prop, value] of Object.entries(HOST_STYLE)) this.hostElement.style.setProperty(prop, value, 'important');
    this.shadowRoot = this.hostElement.attachShadow({ mode: 'closed' });

    const styleTag = document.createElement('style');
    styleTag.textContent = POPUP_STYLES;
    this.shadowRoot.appendChild(styleTag);

    // Remember whether the last press happened inside our UI (selection there is not a new query)
    this.shadowRoot.addEventListener('mousedown', () => { this.pointerInside = true; }, true);
    window.addEventListener('mousedown', (e) => {
      if (!this.hostElement || !e.composedPath().includes(this.hostElement)) this.pointerInside = false;
    }, true);

    document.documentElement.appendChild(this.hostElement);
  }

  /**
   * True when a selection lives in our own palette / AI panel.
   * @param {Selection} selection
   * @returns {boolean}
   */
  isSelectionInside(selection) {
    if (!this.hostElement) return false;
    try {
      const node = selection && selection.anchorNode;
      if (node && (node === this.hostElement || this.hostElement.contains(node))) return true;
      if (node && node.getRootNode && node.getRootNode() === this.shadowRoot) return true;
    } catch { /* ignore */ }
    return this.pointerInside && this.isVisible;
  }

  isAiPanelOpen() {
    return Boolean(this.isVisible && this.shadowRoot && this.shadowRoot.querySelector('.cs-ai-panel-container'));
  }

  /**
   * Display the compact action palette.
   * @param {object} context
   * @param {Array<object>} actions
   * @param {object} [settings={}]
   * @param {{ top: number, left: number }} [position] Keep the palette where it was (mode toggle, Back)
   */
  show(context, actions, settings = {}, position = null) {
    if (!context || !actions || actions.length === 0) return;
    this.ensureHost();
    this.hideBubble();
    this.abortActive();

    this.activeContext = context;
    this.activeSettings = settings;
    this.allActions = actions;
    const maxActions = settings.maxActions || 6;
    this.activeActions = actions.slice(0, maxActions);
    this.detachAiKeys();
    const theme = resolveTheme(settings.theme || 'dark');

    // Remove existing popup elements
    this.removeContainers();

    // Render new popup HTML
    const wrapper = document.createElement('div');
    wrapper.innerHTML = renderPopupHTML(this.activeContext, this.activeActions, theme);
    const container = wrapper.firstElementChild;
    this.shadowRoot.appendChild(container);

    // Compute coordinates
    const pos = position || calculatePopupPosition(window.getSelection());
    container.style.top = `${pos.top}px`;
    container.style.left = `${pos.left}px`;
    if (position) this.clampToViewport(container);

    // Entrance animation
    requestAnimationFrame(() => {
      container.classList.add('cs-visible');
    });

    this.isVisible = true;

    // Attach keyboard navigation
    if (this.keyboardNav) this.keyboardNav.detach();
    this.keyboardNav = new PopupKeyboardNavigator(
      this.shadowRoot,
      this.activeActions.length,
      (idx) => this.handleActionSelection(idx),
      () => this.hide(),
      () => this.focusAskInput()
    );
    this.keyboardNav.attach();

    // Attach click handlers
    const closeBtn = this.shadowRoot.getElementById('cs-btn-close');
    if (closeBtn) {
      closeBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        this.hide();
      });
    }

    const modeBtn = this.shadowRoot.getElementById('cs-mode-toggle');
    if (modeBtn) {
      modeBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        const currentMode = this.activeContext.mode || (this.activeContext.detected?.language === 'general' ? 'general' : 'developer');
        this.activeContext.mode = currentMode === 'general' ? 'developer' : 'general';
        if (this.activeContext.mode === 'general') {
          this.activeContext.detected.language = 'general';
        }
        this.show(this.activeContext, this.allActions, this.activeSettings, this.currentPosition(container));
      });
    }

    const actionRows = this.shadowRoot.querySelectorAll('.cs-action-row');
    actionRows.forEach((row, idx) => {
      row.addEventListener('click', (e) => {
        e.stopPropagation();
        this.handleActionSelection(idx);
      });
      row.addEventListener('mouseenter', () => {
        if (this.keyboardNav) this.keyboardNav.setSelectedIndex(idx);
      });
    });

    // "Ask anything about the selection"
    const askForm = this.shadowRoot.getElementById('cs-ask');
    const askInput = this.shadowRoot.getElementById('cs-ask-input');
    if (askForm && askInput) {
      isolateKeys(askInput);
      askForm.addEventListener('submit', (e) => {
        e.preventDefault();
        e.stopPropagation();
        const question = askInput.value.trim();
        if (question) this.askQuestion(question);
      });
    }

    // Listen for click outside
    window.removeEventListener('mousedown', this.clickOutsideHandler, true);
    setTimeout(() => {
      if (this.isVisible) window.addEventListener('mousedown', this.clickOutsideHandler, true);
    }, 50);
  }

  /**
   * Run one action without the palette (context menu, toolbar popup).
   * @param {object} action
   * @param {object} context
   * @param {Array<object>} actions Palette actions for Back
   * @param {object} settings
   */
  runAction(action, context, actions, settings = {}) {
    this.ensureHost();
    this.hideBubble();
    this.abortActive();
    this.activeContext = context;
    this.activeSettings = settings;
    this.allActions = actions && actions.length ? actions : [action];
    this.activeActions = this.allActions.slice(0, settings.maxActions || 6);
    this.isVisible = true;
    this.executeAction(action, calculatePopupPosition(window.getSelection()));
    window.removeEventListener('mousedown', this.clickOutsideHandler, true);
    setTimeout(() => {
      if (this.isVisible) window.addEventListener('mousedown', this.clickOutsideHandler, true);
    }, 50);
  }

  focusAskInput() {
    const input = this.shadowRoot && this.shadowRoot.getElementById('cs-ask-input');
    if (input) input.focus();
  }

  /**
   * Free-form question about the selection, typed in the palette.
   * @param {string} question
   */
  askQuestion(question) {
    const action = {
      id: ACTION_TYPES.ASK,
      name: 'Ask',
      shortLabel: 'Ask',
      icon: '💬',
      isAI: true,
      question: question.slice(0, 500)
    };
    this.showAiPanel(action);
  }

  currentPosition(container) {
    if (!container) return null;
    const top = parseFloat(container.style.top);
    const left = parseFloat(container.style.left);
    return Number.isFinite(top) && Number.isFinite(left) ? { top, left } : null;
  }

  removeContainers() {
    if (!this.shadowRoot) return;
    this.shadowRoot.querySelectorAll('.cs-popup-container').forEach(el => el.remove());
  }

  abortActive() {
    if (this.activeAbortController) {
      this.activeAbortController.abort();
      this.activeAbortController = null;
    }
  }

  /**
   * Display the expanded AI streaming results panel.
   * @param {object} action
   * @param {object} [options]
   * @param {boolean} [options.regenerate=false] Ignore the cached answer
   * @param {{ top: number, left: number }} [options.position]
   */
  async showAiPanel(action, { regenerate = false, position = null } = {}) {
    this.ensureHost();
    if (this.keyboardNav) {
      this.keyboardNav.detach();
      this.keyboardNav = null;
    }
    this.abortActive();
    this.currentAiAction = action;

    const oldContainer = this.shadowRoot.querySelector('.cs-popup-container');
    const pos = position || this.currentPosition(oldContainer) || { top: (window.scrollY || 0) + 100, left: (window.scrollX || 0) + 100 };
    this.removeContainers();

    const theme = resolveTheme(this.activeSettings.theme || 'dark');
    const wrapper = document.createElement('div');
    wrapper.innerHTML = renderAiPanelHTML(action, this.activeContext, theme);
    const container = wrapper.firstElementChild;
    container.style.top = `${pos.top}px`;
    container.style.left = `${pos.left}px`;
    this.shadowRoot.appendChild(container);
    this.isVisible = true;

    requestAnimationFrame(() => {
      container.classList.add('cs-visible');
    });

    // The panel is larger than the palette and grows while streaming: keep it on screen
    this.clampToViewport(container);
    if (typeof ResizeObserver !== 'undefined') {
      const ro = new ResizeObserver(() => {
        if (!container.isConnected) { ro.disconnect(); return; }
        this.clampToViewport(container);
      });
      ro.observe(container);
    }

    const $ = (id) => this.shadowRoot.getElementById(id);
    const closeBtn = $('cs-btn-close');
    if (closeBtn) closeBtn.addEventListener('click', () => this.hide());

    const backBtn = $('cs-btn-back');
    if (backBtn) {
      backBtn.addEventListener('click', () => {
        this.show(this.activeContext, this.allActions || this.activeActions, this.activeSettings, this.currentPosition(container));
      });
    }

    const shimmer = $('cs-ai-shimmer');
    const contentArea = $('cs-ai-content');
    const errorArea = $('cs-ai-error');
    const errorText = $('cs-error-text');
    const configureBtn = $('cs-btn-configure-key');
    const metaBadge = $('cs-ai-meta-badge');
    const copyAllBtn = $('cs-btn-copy-all');
    const stopBtn = $('cs-btn-stop');
    const regenBtn = $('cs-btn-regenerate');
    const body = this.shadowRoot.querySelector('.cs-ai-body');

    if (configureBtn) {
      configureBtn.addEventListener('click', () => {
        try { chrome.runtime.sendMessage({ type: 'OPEN_OPTIONS' }).catch(() => {}); } catch { /* reloaded */ }
      });
    }
    if (copyAllBtn) {
      copyAllBtn.addEventListener('click', () => {
        navigator.clipboard.writeText(this.conversationAsMarkdown()).then(() => {
          copyAllBtn.textContent = '✓ Copied!';
          setTimeout(() => { copyAllBtn.textContent = '📋 Copy All'; }, 1500);
        }).catch(() => {});
      });
    }
    if (regenBtn) regenBtn.addEventListener('click', () => this.showAiPanel(action, { regenerate: true, position: this.currentPosition(container) }));

    this.conversation = [];
    this.attachAiKeys();

    let fullMarkdownText = '';
    const startTime = Date.now();
    const controller = new AbortController();
    this.activeAbortController = controller;
    let stoppedByUser = false;

    const firstQuestion = action.question
      ? `${action.question} (about "${this.activeContext?.selection?.text || ''}")`
      : `${action.name || action.shortLabel || 'Explain'}: ${this.activeContext?.selection?.text || ''}`;

    const finishFirstTurn = (text) => {
      this.conversation = [
        { role: 'user', content: firstQuestion },
        { role: 'assistant', content: text }
      ];
      if (copyAllBtn) copyAllBtn.style.display = 'inline-block';
      if (stopBtn) stopBtn.style.display = 'none';
      if (regenBtn) regenBtn.style.display = 'inline-block';
      if (contentArea) contentArea.setAttribute('aria-busy', 'false');
      this.enableFollowUp();
    };

    if (stopBtn) {
      stopBtn.style.display = 'inline-block';
      stopBtn.addEventListener('click', () => {
        stoppedByUser = true;
        controller.abort();
        if (shimmer) shimmer.style.display = 'none';
        if (metaBadge) metaBadge.textContent = '⏹ Stopped';
        if (fullMarkdownText) {
          finishFirstTurn(fullMarkdownText);
        } else {
          if (stopBtn) stopBtn.style.display = 'none';
          if (regenBtn) regenBtn.style.display = 'inline-block';
        }
      });
    }

    let customPrompt = '';
    if (action.question) customPrompt = buildAskPrompt(action.question, this.activeContext);
    else if (action.aiPrompt) customPrompt = interpolateTemplate(action.aiPrompt, this.activeContext);

    try {
      await queryAIViaBackground({
        actionId: action.id,
        context: this.activeContext,
        customPrompt,
        regenerate,
        signal: controller.signal,
        onChunk: (chunk, accumulated) => {
          if (controller.signal.aborted) return;
          fullMarkdownText = accumulated;
          if (shimmer && shimmer.style.display !== 'none') {
            shimmer.style.display = 'none';
            contentArea.style.display = 'block';
          }
          const nearBottom = body && body.scrollHeight - body.scrollTop - body.clientHeight < 40;
          contentArea.innerHTML = renderMarkdown(accumulated);
          this.bindCodeCopyButtons();
          if (body && nearBottom) body.scrollTop = body.scrollHeight;
        },
        onComplete: (completedText, meta) => {
          if (controller.signal.aborted) return;
          const duration = Date.now() - startTime;
          const statusText = meta.cached
            ? `⚡ Cached (${meta.provider}) · 0ms`
            : `⚡ ${meta.provider} · ${duration}ms`;
          if (metaBadge) {
            metaBadge.textContent = statusText;
            metaBadge.title = meta.cached ? 'Answer from the local cache: click ↻ for a fresh one' : '';
          }
          finishFirstTurn(completedText || fullMarkdownText);
        },
        onError: (err) => {
          if (controller.signal.aborted) return;
          if (shimmer) shimmer.style.display = 'none';
          if (errorArea) {
            errorArea.style.display = 'flex';
            errorText.textContent = err.message || 'Failed to process AI query.';
          }
          if (metaBadge) metaBadge.textContent = 'Error';
          if (stopBtn) stopBtn.style.display = 'none';
          if (regenBtn) regenBtn.style.display = 'inline-block';
        }
      });
    } catch {
      // Handled in onError
    }
    if (stoppedByUser && this.activeAbortController === controller) this.activeAbortController = null;
  }

  /**
   * Keep an absolutely positioned panel inside the visible viewport.
   * @param {HTMLElement} container
   */
  clampToViewport(container) {
    const margin = 12;
    const scrollX = window.scrollX || 0;
    const scrollY = window.scrollY || 0;
    const width = container.offsetWidth || 440;
    const height = container.offsetHeight || 0;
    let top = parseFloat(container.style.top);
    let left = parseFloat(container.style.left);
    if (!Number.isFinite(top)) top = scrollY + 100;
    if (!Number.isFinite(left)) left = scrollX + margin;
    const maxTop = scrollY + window.innerHeight - height - margin;
    const maxLeft = scrollX + window.innerWidth - width - margin;
    top = Math.max(scrollY + margin, Math.min(top, maxTop));
    left = Math.max(scrollX + margin, Math.min(left, maxLeft));
    container.style.top = `${top}px`;
    container.style.left = `${left}px`;
  }

  /**
   * Show the follow-up input once the first answer is complete.
   */
  enableFollowUp() {
    if (!this.shadowRoot) return;
    const form = this.shadowRoot.getElementById('cs-followup');
    const input = this.shadowRoot.getElementById('cs-followup-input');
    if (!form || !input) return;
    form.style.display = 'flex';
    if (form.dataset.bound === '1') return;
    form.dataset.bound = '1';

    isolateKeys(input);

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      e.stopPropagation();
      const question = input.value.trim();
      if (!question) return;
      input.value = '';
      this.askFollowUp(question);
    });
  }

  /**
   * Send a follow-up question with the earlier turns as context.
   * @param {string} question
   */
  async askFollowUp(question) {
    if (!this.shadowRoot) return;
    const $ = (id) => this.shadowRoot.getElementById(id);
    const thread = $('cs-ai-thread');
    const sendBtn = $('cs-followup-send');
    const input = $('cs-followup-input');
    const metaBadge = $('cs-ai-meta-badge');
    const stopBtn = $('cs-btn-stop');
    const regenBtn = $('cs-btn-regenerate');
    const body = this.shadowRoot.querySelector('.cs-ai-body');
    if (!thread) return;

    const askedSoFar = this.conversation.filter(t => t.role === 'user').length - 1;
    if (askedSoFar >= MAX_FOLLOW_UP_TURNS) {
      if (metaBadge) metaBadge.textContent = 'Follow-up limit reached: start a new search';
      return;
    }

    const userEl = document.createElement('div');
    userEl.className = 'cs-turn-user';
    userEl.textContent = question;
    const aiEl = document.createElement('div');
    aiEl.className = 'cs-turn-ai';
    aiEl.innerHTML = '<div class="cs-turn-pending">Thinking…</div>';
    thread.appendChild(userEl);
    thread.appendChild(aiEl);
    if (body) body.scrollTop = body.scrollHeight;

    if (sendBtn) sendBtn.disabled = true;
    if (input) input.disabled = true;
    if (metaBadge) metaBadge.textContent = 'Thinking...';
    if (regenBtn) regenBtn.style.display = 'none';

    const earlier = this.conversation.slice();
    const startTime = Date.now();
    this.abortActive();
    const controller = new AbortController();
    this.activeAbortController = controller;
    let answer = '';
    const record = () => {
      this.conversation.push({ role: 'user', content: question }, { role: 'assistant', content: answer });
    };

    let onStop = null;
    if (stopBtn) {
      stopBtn.style.display = 'inline-block';
      onStop = () => {
        controller.abort();
        if (answer) record();
        else aiEl.innerHTML = '<div class="cs-turn-pending">Stopped.</div>';
        if (metaBadge) metaBadge.textContent = '⏹ Stopped';
      };
      stopBtn.addEventListener('click', onStop, { once: true });
    }

    try {
      await queryAIViaBackground({
        actionId: ACTION_TYPES.FOLLOW_UP,
        context: { ...this.activeContext, followUpQuestion: question },
        customPrompt: buildFollowUpPrompt(earlier, question, this.activeContext),
        signal: controller.signal,
        onChunk: (_chunk, accumulated) => {
          if (controller.signal.aborted) return;
          answer = accumulated;
          aiEl.innerHTML = `<div class="cs-ai-content">${renderMarkdown(accumulated)}</div>`;
          this.bindCodeCopyButtons();
          if (body) body.scrollTop = body.scrollHeight;
        },
        onComplete: (text, meta) => {
          if (controller.signal.aborted) return;
          answer = text || answer;
          record();
          const n = this.conversation.filter(t => t.role === 'user').length - 1;
          if (metaBadge) metaBadge.textContent = `⚡ ${meta.provider || 'AI'} · ${Date.now() - startTime}ms · follow-up ${n}/${MAX_FOLLOW_UP_TURNS}`;
        },
        onError: (err) => {
          if (controller.signal.aborted) return;
          aiEl.innerHTML = `<div class="cs-turn-error">${escapeHtml(err?.message || 'Follow-up failed.')}</div>`;
          if (metaBadge) metaBadge.textContent = 'Error';
        }
      });
    } catch {
      // Reported in onError
    } finally {
      if (stopBtn) {
        stopBtn.style.display = 'none';
        if (onStop) stopBtn.removeEventListener('click', onStop);
      }
      if (this.activeAbortController === controller) this.activeAbortController = null;
      if (sendBtn) sendBtn.disabled = false;
      if (input) {
        input.disabled = false;
        if (this.isVisible) input.focus();
      }
    }
  }

  conversationAsMarkdown() {
    return this.conversation.map((t, i) => {
      if (i === 0) return `**${t.content}**`;
      return t.role === 'user' ? `**Q: ${t.content}**` : t.content;
    }).join('\n\n');
  }

  /**
   * In the AI panel: Esc closes it, "/" jumps to the follow-up box.
   */
  attachAiKeys() {
    this.detachAiKeys();
    this.aiKeyHandler = (event) => {
      if (!this.isVisible || !this.shadowRoot) return;
      const input = this.shadowRoot.getElementById('cs-followup-input');
      const inInput = !!input && this.shadowRoot.activeElement === input;
      if (event.key === 'Escape') {
        event.preventDefault();
        event.stopPropagation();
        if (inInput && input.value) {
          input.value = '';
        } else {
          this.hide();
        }
      } else if (event.key === '/' && !inInput && input && input.offsetParent !== null) {
        const t = event.composedPath()[0];
        const tag = t && t.tagName ? t.tagName.toLowerCase() : '';
        if (tag === 'input' || tag === 'textarea' || (t && t.isContentEditable)) return;
        event.preventDefault();
        event.stopPropagation();
        input.focus();
      }
    };
    window.addEventListener('keydown', this.aiKeyHandler, true);
  }

  detachAiKeys() {
    if (this.aiKeyHandler) {
      window.removeEventListener('keydown', this.aiKeyHandler, true);
      this.aiKeyHandler = null;
    }
  }

  bindCodeCopyButtons() {
    if (!this.shadowRoot) return;
    const copyButtons = this.shadowRoot.querySelectorAll('.cs-code-copy-btn');
    copyButtons.forEach(btn => {
      btn.onclick = (e) => {
        e.stopPropagation();
        const code = btn.getAttribute('data-code') || '';
        navigator.clipboard.writeText(code).then(() => {
          btn.textContent = '✓ Copied!';
          setTimeout(() => { btn.textContent = '📋 Copy'; }, 1500);
        }).catch(() => {});
      };
    });
  }

  handleActionSelection(index) {
    const action = this.activeActions[index];
    if (!action) return;
    const container = this.shadowRoot && this.shadowRoot.querySelector('.cs-popup-container');
    this.executeAction(action, this.currentPosition(container));
  }

  /**
   * @param {object} action
   * @param {{ top: number, left: number }} [position]
   */
  executeAction(action, position = null) {
    // Record action execution analytics
    try {
      chrome.runtime.sendMessage({
        type: 'ACTION_EXECUTED',
        actionId: action.id
      }).catch(() => {});
    } catch { /* extension reloaded */ }

    if (action.isSidePanel || action.id === ACTION_TYPES.DEEP_RESEARCH) {
      this.hide();
      try {
        chrome.runtime.sendMessage({
          type: 'OPEN_SIDEPANEL',
          context: this.activeContext
        }).catch(() => {});
      } catch { /* extension reloaded */ }
    } else if (action.type === 'ai' || action.isAI) {
      this.showAiPanel(action, { position });
    } else {
      // Custom actions use their own template; built-ins use the context-aware URL builder
      // (e.g. GitHub issue search inside the current repository).
      const targetUrl = action.isCustom && action.template
        ? interpolateTemplate(action.template, this.activeContext)
        : buildTargetUrl(action.id, this.activeContext);
      this.hide();
      if (isSafeHttpUrl(targetUrl)) {
        window.open(targetUrl, '_blank', 'noopener');
      }
    }
  }

  /**
   * Display a compact hover trigger bubble.
   * @param {Selection} selection
   * @param {Function} onClick
   */
  showBubble(selection, onClick) {
    this.ensureHost();
    this.hideBubble();
    if (this.isVisible) return;

    const pos = calculateBubblePosition(selection);
    if (pos.top === 0 && pos.left === 0) return;

    const wrapper = document.createElement('div');
    wrapper.innerHTML = renderBubbleHTML();
    const bubble = wrapper.firstElementChild;
    bubble.style.top = `${pos.top}px`;
    bubble.style.left = `${pos.left}px`;

    const activate = (e) => {
      e.stopPropagation();
      e.preventDefault();
      this.hideBubble();
      onClick();
    };
    bubble.addEventListener('click', activate);
    bubble.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') activate(e);
    });

    this.shadowRoot.appendChild(bubble);
    this.isBubbleVisible = true;
  }

  hideBubble() {
    if (this.shadowRoot) {
      const bubble = this.shadowRoot.getElementById('cs-bubble-trigger');
      if (bubble) bubble.remove();
    }
    this.isBubbleVisible = false;
  }

  hide() {
    if (!this.isVisible) return;
    this.abortActive();
    if (this.keyboardNav) {
      this.keyboardNav.detach();
      this.keyboardNav = null;
    }

    window.removeEventListener('mousedown', this.clickOutsideHandler, true);
    this.detachAiKeys();
    this.conversation = [];

    if (this.shadowRoot) {
      this.shadowRoot.querySelectorAll('.cs-popup-container').forEach(container => {
        container.classList.remove('cs-visible');
        container.classList.add('cs-closing');
        setTimeout(() => container.remove(), 150);
      });
    }

    this.isVisible = false;
    this.pointerInside = false;
  }

  /**
   * Remove everything this instance added to the page (used when a newer copy takes over).
   */
  destroy() {
    try { this.hide(); } catch { /* ignore */ }
    this.hideBubble();
    if (this.hostElement) this.hostElement.remove();
    this.hostElement = null;
    this.shadowRoot = null;
  }

  handleClickOutside(event) {
    if (!this.isVisible) return;
    const path = event.composedPath();
    if (!path.includes(this.hostElement)) {
      this.hide();
    }
  }
}
