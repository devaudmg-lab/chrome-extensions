/**
 * Master Floating Action Popup Manager for ContextSearch (Phase 3).
 * Supports compact action palette and expanded AI streaming results panel.
 */

import { POPUP_STYLES } from './popup-styles.css.js';
import { calculatePopupPosition, calculateBubblePosition } from './popup-positioner.js';
import { renderPopupHTML, renderBubbleHTML } from './popup-view.js';
import { renderAiPanelHTML } from './ai-panel-view.js';
import { renderMarkdown } from './markdown-renderer.js';
import { PopupKeyboardNavigator } from './popup-keyboard.js';
import { buildTargetUrl } from '../../background/url-builder.js';
import { queryAIViaBackground } from '../../ai/ai-port-client.js';
import { interpolateTemplate } from '../../custom-actions/template-interpolator.js';
import { buildFollowUpPrompt, MAX_FOLLOW_UP_TURNS } from '../../ai/prompt-builder.js';
import { escapeHtml } from '../../shared/utils.js';

/**
 * Resolve the 'system' theme setting to 'light' or 'dark'.
 * @param {string} theme
 * @returns {string}
 */
export function resolveTheme(theme) {
  if (theme === 'system') {
    try {
      return window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark';
    } catch {
      return 'dark';
    }
  }
  return theme === 'light' ? 'light' : 'dark';
}

export class FloatingPopupManager {
  constructor() {
    this.hostElement = null;
    this.shadowRoot = null;
    this.isVisible = false;
    this.isBubbleVisible = false;
    this.activeContext = null;
    this.activeActions = [];
    this.activeSettings = {};
    this.keyboardNav = null;
    this.activeAbortController = null;
    this.conversation = [];
    this.aiKeyHandler = null;
    this.clickOutsideHandler = this.handleClickOutside.bind(this);
  }

  ensureHost() {
    if (!this.hostElement) {
      let existing = document.getElementById('context-search-host');
      if (existing) {
        this.hostElement = existing;
        this.shadowRoot = existing.shadowRoot;
      } else {
        this.hostElement = document.createElement('div');
        this.hostElement.id = 'context-search-host';
        document.documentElement.appendChild(this.hostElement);
        this.shadowRoot = this.hostElement.attachShadow({ mode: 'open' });

        const styleTag = document.createElement('style');
        styleTag.textContent = POPUP_STYLES;
        this.shadowRoot.appendChild(styleTag);
      }
    }
  }

  /**
   * Display the compact action palette.
   * @param {object} context 
   * @param {Array<object>} actions 
   * @param {object} [settings={}] 
   */
  show(context, actions, settings = {}) {
    if (!context || !actions || actions.length === 0) return;
    this.ensureHost();
    this.hideBubble();
    if (this.activeAbortController) {
      this.activeAbortController.abort();
      this.activeAbortController = null;
    }

    this.activeContext = context;
    this.activeSettings = settings;
    const maxActions = settings.maxActions || 6;
    this.activeActions = actions.slice(0, maxActions);
    this.detachAiKeys();
    const theme = resolveTheme(settings.theme || 'dark');

    // Remove existing popup elements
    const oldContainer = this.shadowRoot.querySelector('.cs-popup-container');
    if (oldContainer) oldContainer.remove();

    // Render new popup HTML
    const wrapper = document.createElement('div');
    wrapper.innerHTML = renderPopupHTML(this.activeContext, this.activeActions, theme);
    const container = wrapper.firstElementChild;
    this.shadowRoot.appendChild(container);

    // Compute coordinates
    const selection = window.getSelection();
    const pos = calculatePopupPosition(selection);
    container.style.top = `${pos.top}px`;
    container.style.left = `${pos.left}px`;

    // Entrance animation
    requestAnimationFrame(() => {
      container.classList.add('cs-visible');
    });

    this.isVisible = true;

    // Attach keyboard navigation
    if (this.keyboardNav) this.keyboardNav.detach();
    this.keyboardNav = new PopupKeyboardNavigator(
      this.shadowRoot,
      this.activeActions.length,
      (idx) => this.handleActionSelection(idx),
      () => this.hide()
    );
    this.keyboardNav.attach();

    // Attach click handlers
    const closeBtn = this.shadowRoot.getElementById('cs-btn-close');
    if (closeBtn) {
      closeBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        this.hide();
      });
    }

    const modeBtn = this.shadowRoot.getElementById('cs-mode-toggle');
    if (modeBtn) {
      modeBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        const currentMode = this.activeContext.mode || (this.activeContext.detected?.language === 'general' ? 'general' : 'developer');
        this.activeContext.mode = currentMode === 'general' ? 'developer' : 'general';
        if (this.activeContext.mode === 'general') {
          this.activeContext.detected.language = 'general';
        }
        this.show(this.activeContext, this.activeActions, this.activeSettings);
      });
    }

    const actionRows = this.shadowRoot.querySelectorAll('.cs-action-row');
    actionRows.forEach((row, idx) => {
      row.addEventListener('click', (e) => {
        e.stopPropagation();
        this.handleActionSelection(idx);
      });
      row.addEventListener('mouseenter', () => {
        if (this.keyboardNav) this.keyboardNav.setSelectedIndex(idx);
      });
    });

    // Listen for click outside
    setTimeout(() => {
      window.addEventListener('mousedown', this.clickOutsideHandler, true);
    }, 50);
  }

  /**
   * Display the expanded AI streaming results panel.
   * @param {object} action 
   */
  async showAiPanel(action) {
    if (this.keyboardNav) {
      this.keyboardNav.detach();
      this.keyboardNav = null;
    }

    const oldContainer = this.shadowRoot.querySelector('.cs-popup-container');
    const prevTop = oldContainer ? oldContainer.style.top : '100px';
    const prevLeft = oldContainer ? oldContainer.style.left : '100px';
    if (oldContainer) oldContainer.remove();

    const theme = resolveTheme(this.activeSettings.theme || 'dark');
    const wrapper = document.createElement('div');
    wrapper.innerHTML = renderAiPanelHTML(action, this.activeContext, theme);
    const container = wrapper.firstElementChild;
    container.style.top = prevTop;
    container.style.left = prevLeft;
    this.shadowRoot.appendChild(container);

    requestAnimationFrame(() => {
      container.classList.add('cs-visible');
    });

    // The panel is larger than the palette and grows while streaming: keep it on screen
    this.clampToViewport(container);
    if (typeof ResizeObserver !== 'undefined') {
      const ro = new ResizeObserver(() => {
        if (!container.isConnected) { ro.disconnect(); return; }
        this.clampToViewport(container);
      });
      ro.observe(container);
    }

    // Bind panel buttons
    const closeBtn = this.shadowRoot.getElementById('cs-btn-close');
    if (closeBtn) closeBtn.addEventListener('click', () => this.hide());

    const backBtn = this.shadowRoot.getElementById('cs-btn-back');
    if (backBtn) {
      backBtn.addEventListener('click', () => {
        this.show(this.activeContext, this.activeActions, this.activeSettings);
      });
    }

    const shimmer = this.shadowRoot.getElementById('cs-ai-shimmer');
    const contentArea = this.shadowRoot.getElementById('cs-ai-content');
    const errorArea = this.shadowRoot.getElementById('cs-ai-error');
    const errorText = this.shadowRoot.getElementById('cs-error-text');
    const configureBtn = this.shadowRoot.getElementById('cs-btn-configure-key');
    const metaBadge = this.shadowRoot.getElementById('cs-ai-meta-badge');
    const copyAllBtn = this.shadowRoot.getElementById('cs-btn-copy-all');

    if (configureBtn) {
      configureBtn.addEventListener('click', () => {
        if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.openOptionsPage) {
          chrome.runtime.openOptionsPage();
        }
      });
    }

    this.conversation = [];
    this.attachAiKeys();

    let fullMarkdownText = '';
    const startTime = Date.now();
    this.activeAbortController = new AbortController();

    try {
      await queryAIViaBackground({
        actionId: action.id,
        context: this.activeContext,
        customPrompt: action.aiPrompt ? interpolateTemplate(action.aiPrompt, this.activeContext) : '',
        signal: this.activeAbortController.signal,
        onChunk: (chunk, accumulated) => {
          fullMarkdownText = accumulated;
          if (shimmer && shimmer.style.display !== 'none') {
            shimmer.style.display = 'none';
            contentArea.style.display = 'block';
            copyAllBtn.style.display = 'inline-block';
          }
          contentArea.innerHTML = renderMarkdown(accumulated);
          this.bindCodeCopyButtons();
        },
        onComplete: (completedText, meta) => {
          const duration = Date.now() - startTime;
          const statusText = meta.cached
            ? `⚡ Cached (${meta.provider}) · 0ms`
            : `⚡ ${meta.provider} · ${duration}ms`;
          if (metaBadge) metaBadge.textContent = statusText;

          this.conversation = [
            { role: 'user', content: `${action.name || action.shortLabel || 'Explain'}: ${this.activeContext?.selection?.text || ''}` },
            { role: 'assistant', content: completedText || fullMarkdownText }
          ];

          if (copyAllBtn) {
            copyAllBtn.onclick = () => {
              navigator.clipboard.writeText(this.conversationAsMarkdown()).then(() => {
                copyAllBtn.textContent = '✓ Copied!';
                setTimeout(() => { copyAllBtn.textContent = '📋 Copy All'; }, 1500);
              });
            };
          }
          this.enableFollowUp();
        },
        onError: (err) => {
          if (this.activeAbortController && this.activeAbortController.signal.aborted) return;
          if (shimmer) shimmer.style.display = 'none';
          if (errorArea) {
            errorArea.style.display = 'flex';
            errorText.textContent = err.message || 'Failed to process AI query.';
          }
          if (metaBadge) metaBadge.textContent = 'Error';
        }
      });
    } catch {
      // Handled in onError
    }
  }

  /**
   * Keep an absolutely positioned panel inside the visible viewport.
   * @param {HTMLElement} container
   */
  clampToViewport(container) {
    const margin = 12;
    const scrollX = window.scrollX || 0;
    const scrollY = window.scrollY || 0;
    const width = container.offsetWidth || 440;
    const height = container.offsetHeight || 0;
    let top = parseFloat(container.style.top) || scrollY + 100;
    let left = parseFloat(container.style.left) || scrollX + margin;
    const maxTop = scrollY + window.innerHeight - height - margin;
    const maxLeft = scrollX + window.innerWidth - width - margin;
    top = Math.max(scrollY + margin, Math.min(top, maxTop));
    left = Math.max(scrollX + margin, Math.min(left, maxLeft));
    container.style.top = `${top}px`;
    container.style.left = `${left}px`;
  }

  /**
   * Show the follow-up input once the first answer is complete.
   */
  enableFollowUp() {
    if (!this.shadowRoot) return;
    const form = this.shadowRoot.getElementById('cs-followup');
    const input = this.shadowRoot.getElementById('cs-followup-input');
    if (!form || !input) return;
    form.style.display = 'flex';
    if (form.dataset.bound === '1') return;
    form.dataset.bound = '1';

    // Keep keystrokes typed into the box away from page shortcuts (GitHub, YouTube, ...)
    ['keydown', 'keyup', 'keypress'].forEach((type) => {
      input.addEventListener(type, (e) => {
        if (e.key !== 'Escape') e.stopPropagation();
      });
    });

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      e.stopPropagation();
      const question = input.value.trim();
      if (!question) return;
      input.value = '';
      this.askFollowUp(question);
    });
  }

  /**
   * Send a follow-up question with the earlier turns as context.
   * @param {string} question
   */
  async askFollowUp(question) {
    if (!this.shadowRoot) return;
    const thread = this.shadowRoot.getElementById('cs-ai-thread');
    const sendBtn = this.shadowRoot.getElementById('cs-followup-send');
    const input = this.shadowRoot.getElementById('cs-followup-input');
    const metaBadge = this.shadowRoot.getElementById('cs-ai-meta-badge');
    const body = this.shadowRoot.querySelector('.cs-ai-body');
    if (!thread) return;

    const askedSoFar = this.conversation.filter(t => t.role === 'user').length - 1;
    if (askedSoFar >= MAX_FOLLOW_UP_TURNS) {
      if (metaBadge) metaBadge.textContent = 'Follow-up limit reached: start a new search';
      return;
    }

    const userEl = document.createElement('div');
    userEl.className = 'cs-turn-user';
    userEl.textContent = question;
    const aiEl = document.createElement('div');
    aiEl.className = 'cs-turn-ai';
    aiEl.innerHTML = '<div class="cs-turn-pending">Thinking…</div>';
    thread.appendChild(userEl);
    thread.appendChild(aiEl);
    if (body) body.scrollTop = body.scrollHeight;

    if (sendBtn) sendBtn.disabled = true;
    if (input) input.disabled = true;
    if (metaBadge) metaBadge.textContent = 'Thinking...';

    const earlier = this.conversation.slice();
    const startTime = Date.now();
    if (this.activeAbortController) this.activeAbortController.abort();
    const controller = new AbortController();
    this.activeAbortController = controller;
    let answer = '';

    try {
      await queryAIViaBackground({
        actionId: 'follow_up',
        context: { ...this.activeContext, followUpQuestion: question },
        customPrompt: buildFollowUpPrompt(earlier, question, this.activeContext),
        signal: controller.signal,
        onChunk: (_chunk, accumulated) => {
          answer = accumulated;
          aiEl.innerHTML = `<div class="cs-ai-content">${renderMarkdown(accumulated)}</div>`;
          this.bindCodeCopyButtons();
          if (body) body.scrollTop = body.scrollHeight;
        },
        onComplete: (text, meta) => {
          answer = text || answer;
          this.conversation.push({ role: 'user', content: question }, { role: 'assistant', content: answer });
          const n = this.conversation.filter(t => t.role === 'user').length - 1;
          if (metaBadge) metaBadge.textContent = `⚡ ${meta.provider || 'AI'} · ${Date.now() - startTime}ms · follow-up ${n}/${MAX_FOLLOW_UP_TURNS}`;
        },
        onError: (err) => {
          if (controller.signal.aborted) return;
          aiEl.innerHTML = `<div class="cs-turn-error">${escapeHtml(err?.message || 'Follow-up failed.')}</div>`;
          if (metaBadge) metaBadge.textContent = 'Error';
        }
      });
    } catch {
      // Reported in onError
    } finally {
      if (sendBtn) sendBtn.disabled = false;
      if (input) {
        input.disabled = false;
        if (this.isVisible) input.focus();
      }
    }
  }

  conversationAsMarkdown() {
    return this.conversation.map((t, i) => {
      if (i === 0) return `**${t.content}**`;
      return t.role === 'user' ? `**Q: ${t.content}**` : t.content;
    }).join('\n\n');
  }

  /**
   * In the AI panel: Esc closes it, "/" jumps to the follow-up box.
   */
  attachAiKeys() {
    this.detachAiKeys();
    this.aiKeyHandler = (event) => {
      if (!this.isVisible || !this.shadowRoot) return;
      const input = this.shadowRoot.getElementById('cs-followup-input');
      const inInput = !!input && this.shadowRoot.activeElement === input;
      if (event.key === 'Escape') {
        event.preventDefault();
        event.stopPropagation();
        if (inInput && input.value) {
          input.value = '';
        } else {
          this.hide();
        }
      } else if (event.key === '/' && !inInput && input && input.offsetParent !== null) {
        const t = event.composedPath()[0];
        const tag = t && t.tagName ? t.tagName.toLowerCase() : '';
        if (tag === 'input' || tag === 'textarea' || (t && t.isContentEditable)) return;
        event.preventDefault();
        event.stopPropagation();
        input.focus();
      }
    };
    window.addEventListener('keydown', this.aiKeyHandler, true);
  }

  detachAiKeys() {
    if (this.aiKeyHandler) {
      window.removeEventListener('keydown', this.aiKeyHandler, true);
      this.aiKeyHandler = null;
    }
  }

  bindCodeCopyButtons() {
    if (!this.shadowRoot) return;
    const copyButtons = this.shadowRoot.querySelectorAll('.cs-code-copy-btn');
    copyButtons.forEach(btn => {
      btn.onclick = (e) => {
        e.stopPropagation();
        const code = btn.getAttribute('data-code') || '';
        navigator.clipboard.writeText(code).then(() => {
          btn.textContent = '✓ Copied!';
          setTimeout(() => { btn.textContent = '📋 Copy'; }, 1500);
        });
      };
    });
  }

  handleActionSelection(index) {
    const action = this.activeActions[index];
    if (!action) return;

    // Record action execution analytics
    if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
      chrome.runtime.sendMessage({
        type: 'ACTION_EXECUTED',
        actionId: action.id,
        context: this.activeContext
      }).catch(() => {});
    }

    if (action.isSidePanel || action.id === 'deep_research') {
      this.hide();
      if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
        chrome.runtime.sendMessage({
          type: 'OPEN_SIDEPANEL',
          context: this.activeContext
        }).catch(() => {});
      }
    } else if (action.type === 'ai' || action.isAI) {
      this.showAiPanel(action);
    } else {
      let targetUrl = action.template
        ? interpolateTemplate(action.template, this.activeContext)
        : buildTargetUrl(action.id, this.activeContext);
      this.hide();
      if (targetUrl) {
        window.open(targetUrl, '_blank');
      }
    }
  }

  /**
   * Display a compact hover trigger bubble.
   * @param {Selection} selection 
   * @param {Function} onClick 
   */
  showBubble(selection, onClick) {
    this.ensureHost();
    this.hideBubble();
    if (this.isVisible) return;

    const pos = calculateBubblePosition(selection);
    if (pos.top === 0 && pos.left === 0) return;

    const wrapper = document.createElement('div');
    wrapper.innerHTML = renderBubbleHTML();
    const bubble = wrapper.firstElementChild;
    bubble.style.top = `${pos.top}px`;
    bubble.style.left = `${pos.left}px`;

    bubble.addEventListener('click', (e) => {
      e.stopPropagation();
      this.hideBubble();
      onClick();
    });

    this.shadowRoot.appendChild(bubble);
    this.isBubbleVisible = true;
  }

  hideBubble() {
    if (this.shadowRoot) {
      const bubble = this.shadowRoot.getElementById('cs-bubble-trigger');
      if (bubble) bubble.remove();
    }
    this.isBubbleVisible = false;
  }

  hide() {
    if (!this.isVisible) return;
    if (this.activeAbortController) {
      this.activeAbortController.abort();
      this.activeAbortController = null;
    }
    if (this.keyboardNav) {
      this.keyboardNav.detach();
      this.keyboardNav = null;
    }

    window.removeEventListener('mousedown', this.clickOutsideHandler, true);
    this.detachAiKeys();

    if (this.shadowRoot) {
      const container = this.shadowRoot.querySelector('.cs-popup-container');
      if (container) {
        container.classList.remove('cs-visible');
        setTimeout(() => container.remove(), 150);
      }
    }

    this.isVisible = false;
  }

  handleClickOutside(event) {
    if (!this.isVisible) return;
    const path = event.composedPath();
    if (!path.includes(this.hostElement)) {
      this.hide();
    }
  }
}
