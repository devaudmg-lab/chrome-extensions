/**
 * Smart Positioning Engine for ContextSearch Floating Popup.
 * Handles viewport collision, scroll offsets, and automatic flipping.
 */

const POPUP_WIDTH = 320;
const POPUP_ESTIMATED_HEIGHT = 240;
const VIEWPORT_MARGIN = 12;
const SELECTION_OFFSET = 8;

/**
 * Calculate absolute page coordinates for the floating popup.
 * @param {Selection} selection 
 * @returns {{ top: number, left: number, isFlipped: boolean }}
 */
export function calculatePopupPosition(selection) {
  const fallback = {
    top: window.scrollY + 100,
    left: window.scrollX + Math.max(VIEWPORT_MARGIN, (window.innerWidth - POPUP_WIDTH) / 2),
    isFlipped: false
  };

  try {
    if (!selection || selection.rangeCount === 0) return fallback;

    const range = selection.getRangeAt(0);
    const rect = range.getBoundingClientRect();

    if (rect.width === 0 && rect.height === 0) return fallback;

    const viewportWidth = window.innerWidth;
    const viewportHeight = window.innerHeight;
    const scrollX = window.scrollX || window.pageXOffset || 0;
    const scrollY = window.scrollY || window.pageYOffset || 0;

    // Horizontal positioning: center on selection
    let left = scrollX + rect.left + rect.width / 2 - POPUP_WIDTH / 2;

    // Clamp horizontal bounds within viewport
    const minLeft = scrollX + VIEWPORT_MARGIN;
    const maxLeft = scrollX + viewportWidth - POPUP_WIDTH - VIEWPORT_MARGIN;
    left = Math.max(minLeft, Math.min(left, maxLeft));

    // Vertical positioning: default below selection
    let top = scrollY + rect.bottom + SELECTION_OFFSET;
    let isFlipped = false;

    // Check if bottom overflows viewport
    const distanceToBottom = viewportHeight - rect.bottom;
    if (distanceToBottom < POPUP_ESTIMATED_HEIGHT + SELECTION_OFFSET) {
      // Flip above selection
      const topPosition = scrollY + rect.top - POPUP_ESTIMATED_HEIGHT - SELECTION_OFFSET;
      if (topPosition > scrollY + VIEWPORT_MARGIN) {
        top = topPosition;
        isFlipped = true;
      }
    }

    return { top, left, isFlipped };
  } catch {
    return fallback;
  }
}

/**
 * Calculate coordinates for the compact hover trigger icon.
 * @param {Selection} selection 
 * @returns {{ top: number, left: number }}
 */
export function calculateBubblePosition(selection) {
  try {
    if (!selection || selection.rangeCount === 0) return { top: 0, left: 0 };
    const range = selection.getRangeAt(0);
    const rect = range.getBoundingClientRect();

    const scrollX = window.scrollX || 0;
    const scrollY = window.scrollY || 0;

    return {
      top: scrollY + rect.bottom + 4,
      left: scrollX + rect.right + 4
    };
  } catch {
    return { top: 0, left: 0 };
  }
}
