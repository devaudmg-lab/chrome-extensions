/**
 * View templates for ContextSearch Expanded AI Results Panel (Phase 3).
 */

import { truncate, escapeHtml } from '../../shared/utils.js';

/**
 * Render the expanded AI results panel container.
 * @param {object} action 
 * @param {object} context 
 * @param {string} [theme='dark'] 
 * @returns {string}
 */
export function renderAiPanelHTML(action, context, theme = 'dark') {
  const selectionText = context?.selection?.text || '';
  const snippet = truncate(selectionText, 22) || 'AI Result';
  const heading = action.question
    ? `Ask: ${escapeHtml(truncate(action.question, 40))}`
    : `${escapeHtml(action.shortLabel || action.name || 'AI')}: "${escapeHtml(snippet)}"`;
  const themeClass = theme === 'light' ? 'cs-theme-light' : 'cs-theme-dark';

  return `
    <div class="cs-popup-container cs-ai-panel-container ${themeClass}" role="dialog" aria-label="ContextSearch AI answer">
      <div class="cs-header">
        <div class="cs-header-left">
          <span class="cs-logo" aria-hidden="true">${escapeHtml(action.icon || '✨')}</span>
          <span class="cs-title-snippet" title="${escapeHtml(action.question || selectionText)}">${heading}</span>
        </div>
        <button type="button" class="cs-close-btn" id="cs-btn-close" title="Close (Esc)" aria-label="Close">✕</button>
      </div>

      <div class="cs-ai-body">
        <!-- Shimmer Skeleton Loading State -->
        <div class="cs-shimmer-container" id="cs-ai-shimmer" role="status" aria-label="Waiting for the answer">
          <div class="cs-shimmer-line cs-shimmer-title"></div>
          <div class="cs-shimmer-line cs-shimmer-long"></div>
          <div class="cs-shimmer-line cs-shimmer-medium"></div>
          <div class="cs-shimmer-line cs-shimmer-code"></div>
        </div>

        <!-- Rendered Stream Content -->
        <div class="cs-ai-content" id="cs-ai-content" aria-busy="true"></div>

        <!-- Follow-up conversation turns -->
        <div class="cs-ai-thread" id="cs-ai-thread"></div>

        <!-- Error / Missing Key Callout -->
        <div class="cs-ai-error" id="cs-ai-error" role="alert">
          <div class="cs-error-msg" id="cs-error-text"></div>
          <button type="button" class="cs-btn-configure" id="cs-btn-configure-key">⚙️ Open Settings</button>
        </div>
      </div>

      <form class="cs-followup" id="cs-followup" autocomplete="off">
        <input type="text" id="cs-followup-input" class="cs-followup-input" maxlength="500"
          placeholder="Ask a follow-up…  ( / to focus, Enter to send )" aria-label="Ask a follow-up question">
        <button type="submit" class="cs-followup-send" id="cs-followup-send" title="Send (Enter)" aria-label="Send follow-up">➤</button>
      </form>

      <div class="cs-ai-footer">
        <div class="cs-ai-footer-left">
          <button type="button" class="cs-footer-btn" id="cs-btn-back" title="Back to actions list">↩️ Back</button>
          <button type="button" class="cs-footer-btn" id="cs-btn-stop" title="Stop generating">⏹ Stop</button>
          <button type="button" class="cs-footer-btn" id="cs-btn-regenerate" title="Get a fresh answer (skips the cache)">↻ Regenerate</button>
          <button type="button" class="cs-footer-btn" id="cs-btn-copy-all" title="Copy the whole conversation as Markdown">📋 Copy All</button>
        </div>
        <span class="cs-ai-meta-badge" id="cs-ai-meta-badge" role="status">Thinking...</span>
      </div>
    </div>
  `;
}
