/**
 * View templates for ContextSearch Expanded AI Results Panel (Phase 3).
 */

import { truncate, escapeHtml } from '../../shared/utils.js';

/**
 * Render the expanded AI results panel container.
 * @param {object} action 
 * @param {object} context 
 * @param {string} [theme='dark'] 
 * @returns {string}
 */
export function renderAiPanelHTML(action, context, theme = 'dark') {
  const selectionText = context?.selection?.text || '';
  const snippet = truncate(selectionText, 22) || 'AI Result';
  const themeClass = theme === 'light' ? 'cs-theme-light' : 'cs-theme-dark';

  return `
    <div class="cs-popup-container cs-ai-panel-container ${themeClass}">
      <div class="cs-header">
        <div class="cs-header-left">
          <span class="cs-logo">${escapeHtml(action.icon || '✨')}</span>
          <span class="cs-title-snippet">${escapeHtml(action.shortLabel || action.name || 'AI')}: "${escapeHtml(snippet)}"</span>
        </div>
        <button class="cs-close-btn" id="cs-btn-close" title="Close (Esc)">✕</button>
      </div>

      <div class="cs-ai-body">
        <!-- Shimmer Skeleton Loading State -->
        <div class="cs-shimmer-container" id="cs-ai-shimmer">
          <div class="cs-shimmer-line cs-shimmer-title"></div>
          <div class="cs-shimmer-line cs-shimmer-long"></div>
          <div class="cs-shimmer-line cs-shimmer-medium"></div>
          <div class="cs-shimmer-line cs-shimmer-code"></div>
        </div>

        <!-- Rendered Stream Content -->
        <div class="cs-ai-content" id="cs-ai-content" style="display: none;"></div>

        <!-- Follow-up conversation turns -->
        <div class="cs-ai-thread" id="cs-ai-thread"></div>

        <!-- Error / Missing Key Callout -->
        <div class="cs-ai-error" id="cs-ai-error" style="display: none;">
          <div class="cs-error-msg" id="cs-error-text"></div>
          <button class="cs-btn-configure" id="cs-btn-configure-key">⚙️ Configure API Key</button>
        </div>
      </div>

      <form class="cs-followup" id="cs-followup" style="display: none;" autocomplete="off">
        <input type="text" id="cs-followup-input" class="cs-followup-input" maxlength="500"
          placeholder="Ask a follow-up…  ( / to focus, Enter to send )" aria-label="Ask a follow-up question">
        <button type="submit" class="cs-followup-send" id="cs-followup-send" title="Send (Enter)">➤</button>
      </form>

      <div class="cs-ai-footer">
        <div class="cs-ai-footer-left">
          <button class="cs-footer-btn" id="cs-btn-back" title="Back to actions list">↩️ Back</button>
          <button class="cs-footer-btn" id="cs-btn-copy-all" title="Copy full response" style="display: none;">📋 Copy All</button>
        </div>
        <span class="cs-ai-meta-badge" id="cs-ai-meta-badge">Thinking...</span>
      </div>
    </div>
  `;
}
