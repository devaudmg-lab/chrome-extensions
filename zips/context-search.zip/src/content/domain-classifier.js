/**
 * Enhanced Domain and Platform Classifier for ContextSearch (Phase 2).
 */

import { SITE_TYPES } from '../shared/constants.js';

const EXTENSION_LANGUAGE_MAP = {
  js: 'javascript',
  jsx: 'javascript',
  mjs: 'javascript',
  cjs: 'javascript',
  ts: 'typescript',
  tsx: 'typescript',
  py: 'python',
  go: 'go',
  rs: 'rust',
  java: 'java',
  cpp: 'cpp',
  cc: 'cpp',
  c: 'c',
  cs: 'csharp',
  rb: 'ruby',
  php: 'php',
  swift: 'swift',
  kt: 'kotlin',
  html: 'html',
  css: 'css',
  scss: 'css',
  sql: 'sql',
  sh: 'bash',
  bash: 'bash',
  json: 'json',
  yaml: 'yaml',
  yml: 'yaml',
  toml: 'toml'
};

/**
 * Classify the active website and extract developer platform metadata.
 * @param {string} urlString 
 * @param {string} [pageTitle=''] 
 * @returns {object}
 */
export function classifyDomain(urlString, pageTitle = '') {
  const result = {
    siteType: SITE_TYPES.GENERIC,
    domain: '',
    language: 'javascript',
    repoOwner: null,
    repoName: null,
    packageName: null,
    path: ''
  };

  try {
    if (!urlString) return result;
    const url = new URL(urlString);
    result.domain = url.hostname.toLowerCase();
    result.path = url.pathname;

    const hostname = result.domain;
    const pathname = url.pathname;

    // 1. GitHub
    if (hostname.includes('github.com')) {
      result.siteType = SITE_TYPES.GITHUB;
      const parts = pathname.split('/').filter(Boolean);
      if (parts.length >= 2) {
        result.repoOwner = parts[0];
        result.repoName = parts[1];
      }
      extractLanguageFromExtension(parts, result);
      return result;
    }

    // 2. GitLab
    if (hostname.includes('gitlab.com')) {
      result.siteType = SITE_TYPES.GITLAB;
      const parts = pathname.split('/').filter(Boolean);
      if (parts.length >= 2) {
        result.repoOwner = parts[0];
        result.repoName = parts[1];
      }
      extractLanguageFromExtension(parts, result);
      return result;
    }

    // 3. Bitbucket
    if (hostname.includes('bitbucket.org')) {
      result.siteType = SITE_TYPES.BITBUCKET;
      const parts = pathname.split('/').filter(Boolean);
      if (parts.length >= 2) {
        result.repoOwner = parts[0];
        result.repoName = parts[1];
      }
      extractLanguageFromExtension(parts, result);
      return result;
    }

    // 4. Stack Overflow / Stack Exchange
    if (hostname.includes('stackoverflow.com') || hostname.includes('stackexchange.com')) {
      result.siteType = SITE_TYPES.STACKOVERFLOW;
      inferLanguageFromTitle(pageTitle, result);
      return result;
    }

    // 5. npm
    if (hostname.includes('npmjs.com')) {
      result.siteType = SITE_TYPES.NPM;
      result.language = 'javascript';
      const parts = pathname.split('/').filter(Boolean);
      if (parts[0] === 'package' && parts[1]) {
        result.packageName = parts.slice(1).join('/');
      }
      return result;
    }

    // 6. PyPI
    if (hostname.includes('pypi.org')) {
      result.siteType = SITE_TYPES.PYPI;
      result.language = 'python';
      const parts = pathname.split('/').filter(Boolean);
      if (parts[0] === 'project' && parts[1]) {
        result.packageName = parts[1];
      }
      return result;
    }

    // 7. Crates.io
    if (hostname.includes('crates.io')) {
      result.siteType = SITE_TYPES.CRATES;
      result.language = 'rust';
      const parts = pathname.split('/').filter(Boolean);
      if (parts[0] === 'crates' && parts[1]) {
        result.packageName = parts[1];
      }
      return result;
    }

    // 8. Go Packages (pkg.go.dev)
    if (hostname.includes('pkg.go.dev')) {
      result.siteType = SITE_TYPES.GO_PKG;
      result.language = 'go';
      result.packageName = pathname.replace(/^\//, '');
      return result;
    }

    // 9. MDN Web Docs
    if (hostname.includes('developer.mozilla.org')) {
      result.siteType = SITE_TYPES.MDN;
      result.language = 'javascript';
      if (pathname.includes('/CSS/')) result.language = 'css';
      if (pathname.includes('/HTML/')) result.language = 'html';
      return result;
    }

    // 10. Docs.rs
    if (hostname.includes('docs.rs')) {
      result.siteType = SITE_TYPES.DOCS_RS;
      result.language = 'rust';
      const parts = pathname.split('/').filter(Boolean);
      if (parts[0]) result.packageName = parts[0];
      return result;
    }

    // 11. React Docs
    if (hostname.includes('react.dev')) {
      result.siteType = SITE_TYPES.REACT_DOCS;
      result.language = 'javascript';
      return result;
    }

    // 12. Next.js / Vercel Docs
    if (hostname.includes('nextjs.org') || hostname.includes('vercel.com')) {
      result.siteType = SITE_TYPES.NEXTJS_DOCS;
      result.language = 'typescript';
      return result;
    }

    // 13. Vue Docs
    if (hostname.includes('vuejs.org')) {
      result.siteType = SITE_TYPES.VUE_DOCS;
      result.language = 'javascript';
      return result;
    }

    // 14. Python Docs
    if (hostname.includes('docs.python.org')) {
      result.siteType = SITE_TYPES.PYTHON_DOCS;
      result.language = 'python';
      return result;
    }

    // 15. Node.js Docs
    if (hostname.includes('nodejs.org')) {
      result.siteType = SITE_TYPES.NODE_DOCS;
      result.language = 'javascript';
      return result;
    }

    // 16. Cloud Consoles (AWS / GCP)
    if (hostname.includes('console.aws.amazon.com')) {
      result.siteType = SITE_TYPES.AWS_CONSOLE;
      result.language = 'bash';
      return result;
    }
    if (hostname.includes('console.cloud.google.com')) {
      result.siteType = SITE_TYPES.GCP_CONSOLE;
      result.language = 'bash';
      return result;
    }

    // 17. Developer Communities (Dev.to, HN, Reddit programming)
    if (hostname.includes('dev.to') || hostname.includes('news.ycombinator.com') || hostname.includes('reddit.com')) {
      result.siteType = SITE_TYPES.DEV_COMMUNITY;
      inferLanguageFromTitle(pageTitle, result);
      return result;
    }

    // Generic fallback
    inferLanguageFromTitle(pageTitle, result);
    return result;
  } catch {
    return result;
  }
}

function extractLanguageFromExtension(parts, result) {
  const lastPart = parts[parts.length - 1] || '';
  const dotIndex = lastPart.lastIndexOf('.');
  if (dotIndex !== -1) {
    const ext = lastPart.slice(dotIndex + 1).toLowerCase();
    if (EXTENSION_LANGUAGE_MAP[ext]) {
      result.language = EXTENSION_LANGUAGE_MAP[ext];
    }
  }
}

function inferLanguageFromTitle(title, result) {
  const titleLower = (title || '').toLowerCase();
  for (const [ext, lang] of Object.entries(EXTENSION_LANGUAGE_MAP)) {
    if (titleLower.includes(` ${lang}`) || titleLower.includes(`${lang} `) || titleLower.includes(`[${lang}]`)) {
      result.language = lang;
      break;
    }
  }
}
