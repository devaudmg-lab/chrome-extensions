/**
 * Context Menu Manager for ContextSearch.
 */

import { getActionsForContext } from './action-registry.js';
import { buildTargetUrl } from './url-builder.js';
import { truncate, sanitizeText } from '../shared/utils.js';

export const ROOT_MENU_ID = 'context_search_root';
export const SIDEPANEL_MENU_ID = 'context_search_sidepanel';

let latestContext = null;
let currentSubMenuIds = [];

/**
 * Initialize default base context menu.
 */
export function initContextMenu() {
  if (typeof chrome === 'undefined' || !chrome.contextMenus) return;

  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: ROOT_MENU_ID,
      title: '✨ ContextSearch',
      contexts: ['selection']
    }, () => {
      if (chrome.runtime.lastError) {
        console.debug('[ContextSearch] Init menu notice:', chrome.runtime.lastError.message);
      }
    });
    chrome.contextMenus.create({
      id: SIDEPANEL_MENU_ID,
      parentId: ROOT_MENU_ID,
      title: '🔬 Deep Research in Side Panel',
      contexts: ['selection']
    }, () => {
      if (chrome.runtime.lastError) { /* ignore */ }
    });
  });
}

export const setupContextMenu = initContextMenu;

/**
 * Dynamically update the context menu based on active selection context.
 * @param {object} context 
 */
export function updateContextMenu(context) {
  if (typeof chrome === 'undefined' || !chrome.contextMenus) return;
  latestContext = context;

  const rawText = context?.selection?.text || '';
  const cleanSnippet = truncate(sanitizeText(rawText), 22);

  const rootTitle = cleanSnippet ? `✨ ContextSearch: "${cleanSnippet}"` : '✨ ContextSearch';

  // Update root title
  chrome.contextMenus.update(ROOT_MENU_ID, {
    title: rootTitle,
    contexts: ['selection']
  }, () => {
    // If root doesn't exist yet, re-create it
    if (chrome.runtime.lastError) {
      initContextMenu();
    }
  });

  // Remove previous sub-menus
  for (const id of currentSubMenuIds) {
    chrome.contextMenus.remove(id, () => {
      if (chrome.runtime.lastError) { /* ignore */ }
    });
  }
  currentSubMenuIds = [];

  // Generate new sub-items based on active context
  const actions = getActionsForContext(context);

  actions.forEach((action, index) => {
    const subMenuId = `cs_action_${action.id}_${index}`;
    currentSubMenuIds.push(subMenuId);

    // Format title with selected text preview if placeholder exists
    let itemTitle = action.title && action.title.includes('%s')
      ? action.title.replace('%s', truncate(cleanSnippet, 16))
      : `${action.icon || '⚡'} ${action.shortLabel || action.name || 'Action'}`;

    chrome.contextMenus.create({
      id: subMenuId,
      parentId: ROOT_MENU_ID,
      title: itemTitle,
      contexts: ['selection']
    }, () => {
      if (chrome.runtime.lastError) {
        console.debug('[ContextSearch] Create sub-item notice:', chrome.runtime.lastError.message);
      }
    });
  });
}

export const updateContextMenuForContext = updateContextMenu;

/**
 * Handle user clicks on context menu items.
 * @param {object} info 
 * @param {object} tab 
 */
export function handleContextMenuClick(info, tab) {
  const menuItemId = String(info.menuItemId || '');
  const selectionText = info.selectionText || latestContext?.selection?.text || '';

  // Match action ID from item ID format: cs_action_<actionId>_<index>
  const match = menuItemId.match(/^cs_action_(.+)_\d+$/);
  const actionId = match ? match[1] : (menuItemId === ROOT_MENU_ID ? 'explain' : null);

  if (!actionId) return;

  const activeContext = latestContext || {
    selection: { text: selectionText },
    page: { url: tab?.url || '', title: tab?.title || '' },
    detected: { language: 'javascript' }
  };

  // Ensure selection text is present in active context
  if (!activeContext.selection) activeContext.selection = {};
  if (!activeContext.selection.text) activeContext.selection.text = selectionText;

  const targetUrl = buildTargetUrl(actionId, activeContext);

  if (targetUrl && chrome.tabs && chrome.tabs.create) {
    chrome.tabs.create({
      url: targetUrl,
      index: (tab?.index ?? 0) + 1
    });
  }
}
