/**
 * Local Action Ranker for ContextSearch (Phase 2).
 * Tracks action frequencies and sorts actions according to developer preference.
 */

/**
 * Calculate dynamic score for an action based on local usage frequency and recency.
 * @param {object} action 
 * @param {object} stats 
 * @returns {number}
 */
export function calculateActionScore(action, stats = {}) {
  const itemStat = stats[action.id] || { count: 0, lastUsed: 0 };
  const count = itemStat.count || 0;
  const lastUsed = itemStat.lastUsed || 0;

  // Recency bonus: if used within the last 24 hours, add +5
  const now = Date.now();
  const isRecent = now - lastUsed < 24 * 60 * 60 * 1000;
  const recencyBonus = isRecent ? 5 : 0;

  return count * 10 + recencyBonus;
}

/**
 * Sort a list of actions by developer usage score while keeping stable base order for ties.
 * @param {Array<object>} actions 
 * @param {object} [stats={}] 
 * @returns {Array<object>}
 */
export function rankActions(actions, stats = {}) {
  if (!actions || actions.length <= 1) return actions || [];

  return [...actions].sort((a, b) => {
    const scoreA = calculateActionScore(a, stats);
    const scoreB = calculateActionScore(b, stats);
    if (scoreB !== scoreA) {
      return scoreB - scoreA;
    }
    return 0; // Preserve default matrix priority on tie
  });
}

/**
 * Record an executed action to local storage.
 * @param {string} actionId 
 * @returns {Promise<object>}
 */
export async function recordActionUsage(actionId) {
  if (!actionId) return {};

  try {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      return new Promise((resolve) => {
        chrome.storage.local.get(['actionStats'], (res) => {
          const stats = res.actionStats || {};
          const current = stats[actionId] || { count: 0, lastUsed: 0 };

          stats[actionId] = {
            count: current.count + 1,
            lastUsed: Date.now()
          };

          chrome.storage.local.set({ actionStats: stats }, () => {
            resolve(stats);
          });
        });
      });
    }
  } catch (err) {
    console.debug('[ContextSearch] Action usage record notice:', err);
  }

  return {};
}
