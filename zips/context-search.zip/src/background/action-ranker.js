/**
 * Local Action Ranker for ContextSearch (Phase 2).
 * Tracks action frequencies and sorts actions according to developer preference.
 */

/**
 * Calculate dynamic score for an action based on local usage frequency and recency.
 * @param {object} action 
 * @param {object} stats 
 * @returns {number}
 */
export function calculateActionScore(action, stats = {}) {
  const itemStat = stats[action.id] || { count: 0, lastUsed: 0 };
  const count = itemStat.count || 0;
  const lastUsed = itemStat.lastUsed || 0;

  // Recency bonus: if used within the last 24 hours, add +5
  const now = Date.now();
  const isRecent = now - lastUsed < 24 * 60 * 60 * 1000;
  const recencyBonus = isRecent ? 5 : 0;

  return count * 10 + recencyBonus;
}

/**
 * Sort a list of actions by developer usage score while keeping stable base order for ties.
 * @param {Array<object>} actions 
 * @param {object} [stats={}] 
 * @returns {Array<object>}
 */
export function rankActions(actions, stats = {}) {
  if (!actions || actions.length <= 1) return actions || [];

  return [...actions].sort((a, b) => {
    const scoreA = calculateActionScore(a, stats);
    const scoreB = calculateActionScore(b, stats);
    if (scoreB !== scoreA) {
      return scoreB - scoreA;
    }
    return 0; // Preserve default matrix priority on tie
  });
}

const MIN_USES_TO_PROMOTE = 3;
const HALF_LIFE_DAYS = 21;

/**
 * Gentle "learn my favourites" ordering for the palette.
 * The first action stays where the context put it (it is the best match for what is selected),
 * then actions you use often (3+ times, fading after a few weeks without use) move up,
 * and everything else keeps its contextual order.
 * @param {Array<object>} actions Contextual order
 * @param {object} [stats={}] { [actionId]: { count, lastUsed } }
 * @param {number} [now=Date.now()]
 * @returns {Array<object>}
 */
export function promoteFrequentActions(actions, stats = {}, now = Date.now()) {
  if (!Array.isArray(actions) || actions.length <= 2 || !stats) return actions || [];
  const weight = (action) => {
    const s = stats[action.id];
    if (!s || (s.count || 0) < MIN_USES_TO_PROMOTE) return 0;
    const days = Math.max(0, (now - (s.lastUsed || 0)) / 86400000);
    return s.count * Math.pow(0.5, days / HALF_LIFE_DAYS);
  };
  const [first, ...rest] = actions;
  const scored = rest.map((action, index) => ({ action, index, w: weight(action) }));
  scored.sort((a, b) => {
    const aFav = a.w >= 1 ? 1 : 0;
    const bFav = b.w >= 1 ? 1 : 0;
    if (aFav !== bFav) return bFav - aFav;
    if (aFav && b.w !== a.w) return b.w - a.w;
    return a.index - b.index;
  });
  return [first, ...scored.map(s => s.action)];
}

/**
 * Record an executed action to local storage.
 * @param {string} actionId 
 * @returns {Promise<object>}
 */
export async function recordActionUsage(actionId) {
  if (!actionId) return {};

  try {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      return new Promise((resolve) => {
        chrome.storage.local.get(['actionStats'], (res) => {
          const stats = res.actionStats || {};
          const current = stats[actionId] || { count: 0, lastUsed: 0 };

          stats[actionId] = {
            count: current.count + 1,
            lastUsed: Date.now()
          };

          chrome.storage.local.set({ actionStats: stats }, () => {
            resolve(stats);
          });
        });
      });
    }
  } catch (err) {
    console.debug('[ContextSearch] Action usage record notice:', err);
  }

  return {};
}
