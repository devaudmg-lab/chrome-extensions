/**
 * Enhanced Contextual URL Builder for ContextSearch (Phase 2).
 */

import { ACTION_TYPES, SITE_TYPES } from '../shared/constants.js';
import { extractCleanIdentifier, cleanQueryWords } from '../shared/utils.js';

/**
 * Build an enriched destination URL based on action type and detected context.
 * @param {string} actionId 
 * @param {object} context 
 * @returns {string}
 */
export function buildTargetUrl(actionId, context = {}) {
  const selection = context.selection || {};
  const detected = context.detected || {};

  const rawText = selection.text || '';
  const cleanId = extractCleanIdentifier(rawText);
  const cleanQuery = cleanQueryWords(rawText);
  const language = detected.language || 'javascript';
  const repoOwner = detected.repoOwner;
  const repoName = detected.repoName;

  switch (actionId) {
    case ACTION_TYPES.EXPLAIN_COMMAND: {
      const q = encodeURIComponent(`what does ${cleanId || cleanQuery} command do in shell explained`);
      return `https://www.google.com/search?q=${q}`;
    }

    case ACTION_TYPES.CHECK_SECURITY: {
      const q = encodeURIComponent(`${cleanId || cleanQuery} security vulnerability cve advisory`);
      return `https://www.google.com/search?q=${q}`;
    }

    case ACTION_TYPES.CONVERT_SYNTAX: {
      const q = encodeURIComponent(`convert ${cleanId || cleanQuery} from ${language} to typescript example`);
      return `https://www.google.com/search?q=${q}`;
    }

    case ACTION_TYPES.EXPLAIN: {
      const q = encodeURIComponent(`what is ${cleanId || cleanQuery} ${language} explained`);
      return `https://www.google.com/search?q=${q}`;
    }

    case ACTION_TYPES.DEBUG: {
      const q = encodeURIComponent(`${cleanQuery} error solution ${language}`);
      return `https://www.google.com/search?q=${q}`;
    }

    case ACTION_TYPES.FIND_DOCS: {
      if (detected.siteType === SITE_TYPES.PYTHON_DOCS || language === 'python') {
        const q = encodeURIComponent(`${cleanId || cleanQuery} site:docs.python.org`);
        return `https://www.google.com/search?q=${q}`;
      }
      if (detected.siteType === SITE_TYPES.DOCS_RS || language === 'rust') {
        const q = encodeURIComponent(`${cleanId || cleanQuery} site:docs.rs`);
        return `https://www.google.com/search?q=${q}`;
      }
      if (detected.siteType === SITE_TYPES.NODE_DOCS) {
        const q = encodeURIComponent(`${cleanId || cleanQuery} site:nodejs.org/api`);
        return `https://www.google.com/search?q=${q}`;
      }
      if (detected.siteType === SITE_TYPES.REACT_DOCS) {
        const q = encodeURIComponent(`${cleanId || cleanQuery} site:react.dev`);
        return `https://www.google.com/search?q=${q}`;
      }
      if (detected.siteType === SITE_TYPES.NEXTJS_DOCS) {
        const q = encodeURIComponent(`${cleanId || cleanQuery} site:nextjs.org/docs`);
        return `https://www.google.com/search?q=${q}`;
      }

      // Default to MDN and official documentation
      const q = encodeURIComponent(`${cleanId || cleanQuery} ${language} documentation site:developer.mozilla.org OR site:nodejs.org OR site:docs.python.org`);
      return `https://www.google.com/search?q=${q}`;
    }

    case ACTION_TYPES.FIND_EXAMPLES: {
      const q = encodeURIComponent(`${cleanId || cleanQuery} example code ${language}`);
      return `https://www.google.com/search?q=${q}`;
    }

    case ACTION_TYPES.FIND_SO_SOLUTIONS: {
      const q = encodeURIComponent(`${cleanQuery} site:stackoverflow.com ${language}`);
      return `https://www.google.com/search?q=${q}`;
    }

    case ACTION_TYPES.FIND_GH_ISSUES: {
      if (repoOwner && repoName) {
        const q = encodeURIComponent(`is:issue ${cleanQuery}`);
        return `https://github.com/${repoOwner}/${repoName}/issues?q=${q}`;
      }
      const q = encodeURIComponent(`${cleanQuery} site:github.com issues`);
      return `https://www.google.com/search?q=${q}`;
    }

    case ACTION_TYPES.FIND_ALTERNATIVES: {
      const q = encodeURIComponent(`best alternatives to ${cleanId || cleanQuery} ${language}`);
      return `https://www.google.com/search?q=${q}`;
    }

    case ACTION_TYPES.VIEW_NPM: {
      const pkg = encodeURIComponent(cleanId || cleanQuery);
      return `https://www.npmjs.com/package/${pkg}`;
    }

    case ACTION_TYPES.CHECK_BUNDLE_SIZE: {
      const pkg = encodeURIComponent(cleanId || cleanQuery);
      return `https://bundlephobia.com/package/${pkg}`;
    }

    case ACTION_TYPES.SEARCH:
    default: {
      const contextKeywords = language ? ` ${language}` : '';
      const q = encodeURIComponent(`${cleanQuery}${contextKeywords}`);
      return `https://www.google.com/search?q=${q}`;
    }
  }
}
