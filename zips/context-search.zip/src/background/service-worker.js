/**
 * Background Service Worker for ContextSearch (Phase 4).
 * Coordinates context menus, side panel triggers, search actions, command shortcuts,
 * and relays in-page AI requests so they run from the extension origin.
 */

import {
  setupContextMenu,
  handleContextMenuClick,
  updateContextMenuForContext,
  SIDEPANEL_MENU_ID
} from './context-menu.js';
import { recordActionUsage } from './action-ranker.js';
import { queryAI } from '../ai/ai-client.js';
import { AI_PORT_NAME } from '../ai/ai-port-client.js';

// Context handed to the side panel when it is opened from a page (pulled on load).
let pendingSidePanelContext = null;

// Setup context menus on installation / update
chrome.runtime.onInstalled.addListener(() => {
  setupContextMenu();
  injectIntoOpenTabs();
});

/**
 * Inject the content script into tabs that were already open before install/update,
 * so the palette works without a page refresh.
 */
async function injectIntoOpenTabs() {
  if (!chrome.scripting || !chrome.scripting.executeScript) return;
  try {
    const tabs = await chrome.tabs.query({ url: ['https://*/*', 'http://localhost/*', 'http://127.0.0.1/*'] });
    for (const tab of tabs) {
      if (!tab.id || tab.discarded) continue;
      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['src/content/content-loader.js']
      }).catch(() => { /* restricted page (e.g. Web Store) */ });
    }
  } catch (err) {
    console.debug('[ContextSearch] Tab injection notice:', err);
  }
}

/**
 * Open the side panel for a tab. Must be called synchronously inside a user gesture.
 * @param {object} tab
 */
function openSidePanelForTab(tab) {
  if (!chrome.sidePanel || !chrome.sidePanel.open || !tab) return;
  const target = tab.id ? { tabId: tab.id } : { windowId: tab.windowId };
  chrome.sidePanel.open(target).catch((err) => {
    console.debug('[ContextSearch] SidePanel open notice:', err);
  });
}

function forwardContextToSidePanel(context) {
  if (!context) return;
  pendingSidePanelContext = { context, at: Date.now() };
  // An already-open panel receives this; a freshly opened one pulls it via GET_PENDING_SIDEPANEL_CONTEXT
  chrome.runtime.sendMessage({ type: 'CONTEXT_SEARCH_TRIGGER', context }).catch(() => {});
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || !message.type) return false;

  if (message.type === 'CONTEXT_UPDATED') {
    const context = message.payload || message.context;
    if (context) updateContextMenuForContext(context);
    sendResponse({ status: 'ok' });
    return false;
  }

  if (message.type === 'ACTION_EXECUTED' && message.actionId) {
    recordActionUsage(message.actionId);
    sendResponse({ status: 'recorded' });
    return false;
  }

  if (message.type === 'OPEN_SIDEPANEL') {
    if (sender.tab) openSidePanelForTab(sender.tab);
    forwardContextToSidePanel(message.context);
    sendResponse({ status: 'opening' });
    return false;
  }

  if (message.type === 'GET_PENDING_SIDEPANEL_CONTEXT') {
    const fresh = pendingSidePanelContext && Date.now() - pendingSidePanelContext.at < 15000;
    sendResponse({ context: fresh ? pendingSidePanelContext.context : null });
    pendingSidePanelContext = null;
    return false;
  }

  return false;
});

// Relay AI streaming for content scripts (floating palette)
chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== AI_PORT_NAME) return;

  const controller = new AbortController();
  let connected = true;
  const post = (msg) => {
    if (!connected) return;
    try { port.postMessage(msg); } catch { connected = false; }
  };

  port.onDisconnect.addListener(() => {
    connected = false;
    controller.abort();
  });

  port.onMessage.addListener((msg) => {
    if (!msg || msg.type !== 'AI_QUERY') return;
    queryAI({
      actionId: msg.actionId,
      context: msg.context || {},
      customPrompt: msg.customPrompt || '',
      signal: controller.signal,
      onChunk: (chunk, accumulated) => post({ type: 'chunk', chunk, accumulated }),
      onComplete: (text, meta) => post({ type: 'complete', text, meta }),
      onError: (err) => {
        if (controller.signal.aborted) return;
        post({ type: 'error', message: err?.message || 'AI request failed.' });
      }
    }).catch(() => { /* reported via onError */ });
  });
});

// Handle Context Menu clicks
chrome.contextMenus.onClicked.addListener((info, tab) => {
  const menuId = String(info.menuItemId || '');
  if (menuId === SIDEPANEL_MENU_ID || /^cs_action_deep_research_\d+$/.test(menuId)) {
    // Open synchronously to keep the user gesture, then hand over the selection
    openSidePanelForTab(tab);
    forwardContextToSidePanel({
      selection: { text: (info.selectionText || '').slice(0, 500) },
      page: { url: tab?.url || '', title: tab?.title || '', domain: safeHost(tab?.url) },
      detected: {}
    });
    return;
  }
  handleContextMenuClick(info, tab);
});

function safeHost(url) {
  try { return new URL(url).hostname; } catch { return ''; }
}

// Handle Keyboard Shortcuts (commands)
chrome.commands.onCommand.addListener((command, tab) => {
  if (command === 'toggle-context-search') {
    const send = (t) => {
      if (t && t.id) chrome.tabs.sendMessage(t.id, { type: 'TRIGGER_FLOATING_PALETTE' }).catch(() => {});
    };
    if (tab) {
      send(tab);
    } else {
      chrome.tabs.query({ active: true, currentWindow: true }).then(([t]) => send(t)).catch(() => {});
    }
  } else if (command === 'open-side-panel') {
    if (tab) {
      openSidePanelForTab(tab);
    } else if (chrome.windows && chrome.windows.getLastFocused) {
      chrome.windows.getLastFocused().then((w) => w && chrome.sidePanel.open({ windowId: w.id })).catch(() => {});
    }
  }
});
