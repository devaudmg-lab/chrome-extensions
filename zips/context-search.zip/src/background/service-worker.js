/**
 * Background Service Worker for ContextSearch (Phase 4).
 * Coordinates context menus, side panel triggers, search actions, command shortcuts,
 * and relays in-page AI requests so they run from the extension origin.
 */

import {
  setupContextMenu,
  handleContextMenuClick,
  updateContextMenuForContext,
  SIDEPANEL_MENU_ID
} from './context-menu.js';
import { recordActionUsage } from './action-ranker.js';
import { queryAI } from '../ai/ai-client.js';
import { AI_PORT_NAME } from '../ai/ai-port-client.js';
import { getCustomActions } from '../custom-actions/custom-actions-manager.js';
import { sanitizeText } from '../shared/utils.js';

/**
 * Keep chrome.storage.local (API keys, AI answer cache, history, custom actions) out of reach of
 * content scripts. Content scripts run inside web pages, so a compromised renderer could read
 * anything they can read. The palette gets the few things it needs through GET_PALETTE_DATA.
 * Called on every worker start because the access level is not guaranteed to persist.
 */
function restrictLocalStorage() {
  try {
    const p = chrome.storage.local.setAccessLevel && chrome.storage.local.setAccessLevel({ accessLevel: 'TRUSTED_CONTEXTS' });
    if (p && p.catch) p.catch(() => { /* older Chrome: not supported */ });
  } catch { /* not supported */ }
}
restrictLocalStorage();

// Context handed to the side panel when it is opened from a page (pulled on load).
let pendingSidePanelContext = null;

// Setup context menus on installation / update
chrome.runtime.onInstalled.addListener((details) => {
  restrictLocalStorage();
  setupContextMenu();
  // A Chrome update does not reload the extension: the content scripts already running are fine
  if (!details || details.reason === 'install' || details.reason === 'update') injectIntoOpenTabs();
});

chrome.runtime.onStartup.addListener(restrictLocalStorage);

/**
 * Inject the content script into tabs that were already open before install/update,
 * so the palette works without a page refresh.
 */
async function injectIntoOpenTabs() {
  if (!chrome.scripting || !chrome.scripting.executeScript) return;
  try {
    const tabs = await chrome.tabs.query({ url: ['https://*/*', 'http://localhost/*', 'http://127.0.0.1/*'] });
    for (const tab of tabs) {
      if (!tab.id || tab.discarded) continue;
      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['src/content/content-loader.js']
      }).catch(() => { /* restricted page (e.g. Web Store) */ });
    }
  } catch (err) {
    console.debug('[ContextSearch] Tab injection notice:', err);
  }
}

/**
 * Open the side panel for a tab. Must be called synchronously inside a user gesture.
 * @param {object} tab
 */
function openSidePanelForTab(tab) {
  if (!chrome.sidePanel || !chrome.sidePanel.open || !tab) return;
  const target = tab.id ? { tabId: tab.id } : { windowId: tab.windowId };
  chrome.sidePanel.open(target).catch((err) => {
    console.debug('[ContextSearch] SidePanel open notice:', err);
  });
}

/**
 * @param {object} context
 * @param {number} [windowId] Only the side panel of this window should react
 */
function forwardContextToSidePanel(context, windowId) {
  if (!context) return;
  pendingSidePanelContext = { context, windowId, at: Date.now() };
  // Survives the worker going to sleep before a freshly opened panel asks for it
  try { chrome.storage.session.set({ pendingSidePanelContext }).catch(() => {}); } catch { /* ignore */ }
  // An already-open panel receives this; a freshly opened one pulls it via GET_PENDING_SIDEPANEL_CONTEXT
  chrome.runtime.sendMessage({ type: 'CONTEXT_SEARCH_TRIGGER', context, windowId }).catch(() => {});
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || !message.type) return false;

  if (message.type === 'CONTEXT_UPDATED') {
    const context = message.payload || message.context;
    if (context) updateContextMenuForContext(context);
    sendResponse({ status: 'ok' });
    return false;
  }

  if (message.type === 'OPEN_OPTIONS') {
    // Content scripts can't call runtime.openOptionsPage themselves
    chrome.runtime.openOptionsPage().catch(() => {});
    sendResponse({ status: 'ok' });
    return false;
  }

  if (message.type === 'GET_PALETTE_DATA') {
    // Content scripts can't read chrome.storage.local (see restrictLocalStorage)
    Promise.all([
      getCustomActions(),
      chrome.storage.local.get(['actionStats']).then(r => (r && r.actionStats) || {}).catch(() => ({}))
    ]).then(([customActions, actionStats]) => sendResponse({ customActions, actionStats }))
      .catch(() => sendResponse({ customActions: [], actionStats: {} }));
    return true; // async response
  }

  if (message.type === 'ACTION_EXECUTED' && message.actionId) {
    recordActionUsage(message.actionId);
    sendResponse({ status: 'recorded' });
    return false;
  }

  if (message.type === 'OPEN_SIDEPANEL') {
    if (sender.tab) openSidePanelForTab(sender.tab);
    forwardContextToSidePanel(message.context, sender.tab ? sender.tab.windowId : message.windowId);
    sendResponse({ status: 'opening' });
    return false;
  }

  if (message.type === 'GET_PENDING_SIDEPANEL_CONTEXT') {
    const take = (pending) => {
      const fresh = pending && Date.now() - pending.at < 15000 &&
        (pending.windowId === undefined || message.windowId === undefined || pending.windowId === message.windowId);
      pendingSidePanelContext = null;
      try { chrome.storage.session.remove('pendingSidePanelContext').catch(() => {}); } catch { /* ignore */ }
      sendResponse({ context: fresh ? pending.context : null });
    };
    if (pendingSidePanelContext) {
      take(pendingSidePanelContext);
      return false;
    }
    chrome.storage.session.get('pendingSidePanelContext')
      .then((r) => take(r && r.pendingSidePanelContext))
      .catch(() => sendResponse({ context: null }));
    return true; // async response
  }

  return false;
});

// Relay AI streaming for content scripts (floating palette)
chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== AI_PORT_NAME) return;

  const controller = new AbortController();
  let connected = true;
  const post = (msg) => {
    if (!connected) return;
    try { port.postMessage(msg); } catch { connected = false; }
  };

  port.onDisconnect.addListener(() => {
    connected = false;
    controller.abort();
  });

  port.onMessage.addListener((msg) => {
    if (!msg || msg.type !== 'AI_QUERY') return;
    queryAI({
      actionId: msg.actionId,
      context: msg.context || {},
      customPrompt: msg.customPrompt || '',
      regenerate: msg.regenerate === true,
      signal: controller.signal,
      onChunk: (chunk, accumulated) => post({ type: 'chunk', chunk, accumulated }),
      onComplete: (text, meta) => post({ type: 'complete', text, meta }),
      onError: (err) => {
        if (controller.signal.aborted) return;
        post({ type: 'error', message: err?.message || 'AI request failed.' });
      }
    }).catch(() => { /* reported via onError */ });
  });
});

// Handle Context Menu clicks
chrome.contextMenus.onClicked.addListener((info, tab) => {
  const menuId = String(info.menuItemId || '');
  if (menuId === SIDEPANEL_MENU_ID || /^cs_action_deep_research_\d+$/.test(menuId)) {
    // Open synchronously to keep the user gesture, then hand over the selection
    openSidePanelForTab(tab);
    forwardContextToSidePanel({
      selection: { text: sanitizeText(info.selectionText || '', 500) },
      page: { url: tab?.url || '', title: tab?.title || '', domain: safeHost(tab?.url) },
      detected: {}
    }, tab ? tab.windowId : undefined);
    return;
  }
  handleContextMenuClick(info, tab);
});

function safeHost(url) {
  try { return new URL(url).hostname; } catch { return ''; }
}

// Handle Keyboard Shortcuts (commands)
chrome.commands.onCommand.addListener((command, tab) => {
  if (command === 'toggle-context-search') {
    const send = (t) => {
      if (t && t.id) chrome.tabs.sendMessage(t.id, { type: 'TRIGGER_FLOATING_PALETTE' }).catch(() => {});
    };
    if (tab) {
      send(tab);
    } else {
      chrome.tabs.query({ active: true, currentWindow: true }).then(([t]) => send(t)).catch(() => {});
    }
  } else if (command === 'open-side-panel') {
    if (tab) {
      openSidePanelForTab(tab);
    } else if (chrome.windows && chrome.windows.getLastFocused) {
      chrome.windows.getLastFocused().then((w) => w && chrome.sidePanel.open({ windowId: w.id })).catch(() => {});
    }
  }
});
