/**
 * Content-script AI client for ContextSearch.
 * Relays AI queries to the background service worker over a long-lived port so that
 * provider requests run from the extension origin (host permissions, no page CORS / CSP,
 * works with local Ollama) and API keys never travel through the host page.
 */

export const AI_PORT_NAME = 'cs-ai-stream';

/**
 * Same signature as queryAI() in ai-client.js, executed in the service worker.
 * @param {object} params
 * @returns {Promise<{ content: string, cached?: boolean, provider?: string, model?: string }>}
 */
export function queryAIViaBackground({ actionId, context, customPrompt = '', regenerate = false, onChunk, onComplete, onError, signal }) {
  return new Promise((resolve, reject) => {
    let port;
    let settled = false;

    const finish = (fn, value) => {
      if (settled) return;
      settled = true;
      try { port && port.disconnect(); } catch { /* already closed */ }
      fn(value);
    };

    const fail = (message) => {
      const err = new Error(message || 'AI request failed.');
      if (onError) onError(err);
      finish(reject, err);
    };

    try {
      port = chrome.runtime.connect({ name: AI_PORT_NAME });
    } catch (err) {
      fail('ContextSearch was updated or reloaded. Please refresh this page.');
      return;
    }

    if (signal) {
      if (signal.aborted) {
        finish(resolve, { content: '' });
        return;
      }
      signal.addEventListener('abort', () => finish(resolve, { content: '' }), { once: true });
    }

    port.onMessage.addListener((msg) => {
      if (!msg || settled) return;
      if (msg.type === 'chunk') {
        if (onChunk) onChunk(msg.chunk || '', msg.accumulated || '');
      } else if (msg.type === 'complete') {
        if (onComplete) onComplete(msg.text || '', msg.meta || {});
        finish(resolve, { content: msg.text || '', ...(msg.meta || {}) });
      } else if (msg.type === 'error') {
        fail(msg.message);
      }
    });

    port.onDisconnect.addListener(() => {
      void chrome.runtime.lastError;
      if (!settled) fail('Connection to the ContextSearch background worker was lost.');
    });

    port.postMessage({ type: 'AI_QUERY', actionId, context, customPrompt, regenerate: regenerate === true });
  });
}
