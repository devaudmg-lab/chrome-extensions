/**
 * Master AI Client for ContextSearch (Phase 3).
 * Coordinates provider adapters, caching, rate limiting, and demo streaming fallback.
 */

import { AI_PROVIDERS, DEFAULT_MODELS, ACTION_TYPES } from '../shared/constants.js';
import { getSettings } from '../shared/settings-manager.js';
import { getKeyForProvider } from '../shared/api-keys-manager.js';
import { buildSystemPrompt, buildUserPrompt } from './prompt-builder.js';
import { generateCacheKey, getCachedResponse, setCachedResponse } from './response-cache.js';
import { checkRateLimit, recordRequest } from './rate-limiter.js';
import { streamGemini } from './adapters/gemini-adapter.js';
import { streamOpenAI } from './adapters/openai-adapter.js';
import { streamAnthropic } from './adapters/anthropic-adapter.js';
import { streamCustom } from './adapters/custom-adapter.js';

const RETIRED_MODELS = new Set([
  'gemini-1.5-flash',
  'gemini-1.5-flash-8b',
  'gemini-1.5-pro',
  'gemini-2.0-flash',
  'gemini-2.0-flash-lite',
  'claude-3-5-haiku-20241022',
  'claude-3-5-sonnet-20241022'
]);

/**
 * Generate context-aware demo response when no API key is configured.
 * @param {string} actionId 
 * @param {object} context 
 * @returns {string}
 */
function generateDemoResponse(actionId, context = {}) {
  const selectionText = context?.selection?.text || 'this concept';
  const detected = context?.detected || {};
  const language = detected.language || 'general';
  const site = detected.siteType || 'web';
  const mode = context?.mode || detected.mode || 'auto';
  const isGeneral = mode === 'general' || (language === 'general' && detected.category === 'concept');

  if (isGeneral) {
    switch (actionId) {
      case ACTION_TYPES.EXPLAIN:
        return `### Overview: "${selectionText}"\n**${selectionText}** is a notable concept and subject.\n\n### Key Principles & Meaning:\n* **Definition:** Core subject matter describing its essential characteristics and purpose.\n* **Significance:** Widely referenced across modern literature, research, and analysis.\n* **Real-World Context:** Helps provide clarity and structure when applied in everyday practice.\n\n> 💡 *Demo Mode: Add your Gemini or OpenAI API Key in Settings (⚙️) to query live multi-model answers.*`;

      case ACTION_TYPES.DEBUG:
        return `### Analysis & Troubleshooting\nExamining **"${selectionText}"**:\n\n1. **Core Issue:** The stated condition or expression requires verification or refinement.\n2. **Underlying Cause:** Ambiguity, outdated parameters, or situational misalignment.\n3. **Recommended Resolution:** Adjust approach according to standard validated conventions.\n\n> 💡 *Demo Mode: Add your API key in Settings for live AI troubleshooting.*`;

      case ACTION_TYPES.FIND_SOLUTIONS:
        return `### Approach 1: Primary Recommendation\nImplement standard best-practice methodology for **"${selectionText}"**.\n* **Benefits:** Reliable, straightforward, and broadly supported.\n\n### Approach 2: Alternative Strategy\nAdopt an agile, flexible model tailored to edge-case requirements.\n\n> 💡 *Demo Mode: Add your API key in Settings to query live solutions.*`;

      case ACTION_TYPES.SUMMARIZE:
        return `### Summary: "${selectionText}"\n* **Core Theme:** Primary subject overview and central takeaways.\n* **Context:** Documented within ${site}.\n* **Actionable Insight:** Apply core concepts directly to your active task.\n\n> 💡 *Demo Mode: Add your API key in Settings.*`;

      default:
        return `### Topic Analysis\nReviewing **\`${selectionText}\`** in general knowledge context on **${site}**.\n\n> 💡 *Add your API key in Settings (⚙️) to enable full live AI generation.*`;
    }
  }

  const isSnippet = /[\s;=(){}]/.test(selectionText.trim());
  switch (actionId) {
    case ACTION_TYPES.EXPLAIN:
      if (isSnippet) return generateDemoSnippetExplain(selectionText, language, site);
      return `### Overview\n\`${selectionText}\` is a core feature in **${language}** (context: *${site}*).\n\nIt provides structured control over async execution, state handling, and resource lifecycle management.\n\n### Practical Example\n\`\`\`${language}\n// Example usage of ${selectionText}\nconst handler = new ${selectionText}();\nconsole.log('Initialized:', handler);\n\`\`\`\n\n> 💡 *Demo Mode: Add your Gemini or OpenAI API Key in Settings (⚙️) to unlock live multi-model responses.*`;

    case ACTION_TYPES.DEBUG:
      return `### Root Cause Analysis\nThe error \`${selectionText}\` typically occurs in **${language}** when an async operation, network socket, or unhandled promise rejection fails.\n\n### Top Probable Causes:\n1. **Connection Reset/Timeout:** Remote server closed the TCP socket abruptly.\n2. **Unmatched Types / Null Reference:** Property accessed before state initialized.\n3. **CORS / Network Firewall:** Browser blocked request header.\n\n### Recommended Fix:\n\`\`\`${language}\ntry {\n  // Wrap error-prone operation\n  await executeOperation();\n} catch (err) {\n  console.error('Handled ${selectionText}:', err.message);\n}\n\`\`\`\n\n> 💡 *Demo Mode: Add your API key in Settings to debug with live LLMs.*`;

    case ACTION_TYPES.FIND_SOLUTIONS:
      return `### Solution 1: Standard Modern Pattern\n\`\`\`${language}\n// Modern idiomatic approach for ${selectionText}\nasync function handleTask() {\n  const result = await processData();\n  return result;\n}\n\`\`\`\n* **Pros:** Clean, readable, natively supported in ${language}.\n* **Cons:** Requires modern runtime support.\n\n### Solution 2: Resilient Fallback Pattern\n\`\`\`${language}\n// Robust pattern with error boundaries\nfunction safeExecute() {\n  return Promise.resolve().catch(console.error);\n}\n\`\`\`\n\n> 💡 *Demo Mode: Add your API key in Settings to query live solutions.*`;

    case ACTION_TYPES.SUMMARIZE:
      return `### Code Summary\n* **Purpose:** Encapsulates logic related to \`${selectionText}\`.\n* **Language:** ${language} (optimized for ${site}).\n* **Key Behavior:** Dispatches events and manages execution boundaries safely.\n\n> 💡 *Demo Mode: Set an API key in Settings for full context summarization.*`;

    case ACTION_TYPES.GENERATE_TESTS:
      return `### Unit Tests (${language})\n\`\`\`${language}\ndescribe('${selectionText}', () => {\n  test('should initialize correctly with default values', () => {\n    expect(${selectionText}).toBeDefined();\n  });\n\n  test('handles edge case inputs gracefully', async () => {\n    const res = await runOperation(null);\n    expect(res).toBeNull();\n  });\n\n  test('throws expected error on invalid state', () => {\n    expect(() => executeInvalid()).toThrow();\n  });\n});\n\`\`\`\n\n> 💡 *Demo Mode: Add your API key in Settings for live test suite generation.*`;

    default:
      return `### Context Analysis\nAnalyzing **\`${selectionText}\`** in **${language}** on **${site}**.\n\n> 💡 *Add your API key in Settings (⚙️) to enable full live AI generation.*`;
  }
}

/**
 * Demo answer for a follow-up question (no API key configured).
 * @param {string} question
 * @param {object} context
 * @returns {string}
 */
function generateDemoFollowUp(question = '', context = {}) {
  const language = context?.detected?.language && context.detected.language !== 'general' ? context.detected.language : 'javascript';
  return [
    'The same approach extends to your follow-up:',
    '',
    '1. **Reuse what you already have** from the previous answer instead of starting over.',
    '2. **Share it** across the related calls, so one change applies to all of them.',
    '3. **Clean up** in a `finally` block so nothing is left running.',
    '',
    '```' + language,
    'const results = await Promise.all(tasks.map((task) => task(shared)));',
    '```',
    '',
    'This keeps the code short, and changing the behaviour for every call becomes a one-line edit.',
    '',
    '> 💡 *Demo Mode: add an API key or a local Ollama model in Settings (⚙️) for live follow-ups.*'
  ].join('\n');
}

/**
 * Demo explanation for a multi-token code snippet (rather than a single identifier).
 * @param {string} snippet
 * @param {string} language
 * @param {string} site
 * @returns {string}
 */
function generateDemoSnippetExplain(snippet, language, site) {
  const lang = language && language !== 'general' ? language : 'code';
  const lines = snippet.split('\n').map(l => l.trim()).filter(Boolean);
  const assigned = Array.from(new Set(lines
    .map(l => (l.match(/^(?:const|let|var)?\s*([A-Za-z_$][\w$]*)\s*=(?!=)/) || [])[1])
    .filter(Boolean))).slice(0, 3);
  const points = assigned.length
    ? assigned.map(name => `* \`${name}\` is assigned here and used by the code that follows.`)
    : ['* Each statement runs top to bottom; values on the right of `=` are stored in the names on the left.'];
  return [
    '### What this snippet does',
    `A ${lines.length}-line **${lang}** snippet from *${site}*:`,
    '',
    ...points,
    '* **Watch out for:** missing error handling around async calls, and values that may be `undefined`.',
    '',
    '> 💡 *Demo Mode: add your Gemini, OpenAI or Claude key (or a local Ollama model) in Settings (⚙️) for real answers.*'
  ].join('\n');
}

/**
 * Simulate word-by-word streaming for demo responses.
 * @param {string} fullText 
 * @param {Function} onChunk 
 * @param {AbortSignal} [signal] 
 * @returns {Promise<string>}
 */
async function streamDemoText(fullText, onChunk, signal) {
  const words = fullText.split(' ');
  let accumulated = '';

  for (let i = 0; i < words.length; i++) {
    if (signal && signal.aborted) break;
    const word = words[i] + (i < words.length - 1 ? ' ' : '');
    accumulated += word;
    onChunk(word, accumulated);
    await new Promise(resolve => setTimeout(resolve, 18));
  }

  return accumulated;
}

/**
 * Execute an AI query with streaming, caching, and rate limiting.
 * @param {object} params 
 * @param {string} params.actionId 
 * @param {object} params.context 
 * @param {Function} params.onChunk 
 * @param {Function} [params.onComplete] 
 * @param {Function} [params.onError] 
 * @param {AbortSignal} [params.signal] 
 * @param {string} [params.customPrompt] Already-interpolated user prompt (custom AI actions)
 * @param {boolean} [params.bypassCache] Skip the response cache (e.g. connection tests)
 * @returns {Promise<{ content: string, cached: boolean, provider: string, model: string }>}
 */
export async function queryAI({ actionId, context, onChunk, onComplete, onError, signal, customPrompt = '', bypassCache = false }) {
  let errorReported = false;
  try {
    const settings = await getSettings();
    const provider = settings.aiProvider || AI_PROVIDERS.GEMINI;

    // 1. Check Cache
    const isFollowUp = actionId === ACTION_TYPES.FOLLOW_UP;
    const cacheKey = generateCacheKey(customPrompt ? `${actionId}::${customPrompt.length}::${customPrompt.slice(0, 64)}` : actionId, context);
    const useCache = settings.enableCaching !== false && !bypassCache && !isFollowUp;
    if (useCache) {
      const cached = await getCachedResponse(cacheKey);
      if (cached) {
        onChunk(cached, cached);
        if (onComplete) onComplete(cached, { cached: true, provider, model: 'cache' });
        return { content: cached, cached: true, provider, model: 'cache' };
      }
    }

    // 2. Retrieve API Key
    const apiKey = await getKeyForProvider(provider);

    // If no API key is provided, stream demo data smoothly
    if (!apiKey && provider !== AI_PROVIDERS.CUSTOM) {
      const demoText = isFollowUp
        ? generateDemoFollowUp(context?.followUpQuestion, context)
        : customPrompt
        ? `### Custom AI Action
Your prompt is ready:

\`\`\`text
${customPrompt.slice(0, 400)}
\`\`\`

> 💡 *Demo Mode: Add an API key (or a local Ollama endpoint) in Settings (⚙️) to run custom prompts live.*`
        : generateDemoResponse(actionId, context);
      const streamed = await streamDemoText(demoText, onChunk, signal);
      const meta = { cached: false, provider: 'Demo Mode (Add API Key in ⚙️)', model: 'demo' };
      if (onComplete) onComplete(streamed, meta);
      return { content: streamed, cached: false, provider: 'Demo', model: 'demo' };
    }

    // 3. Check Rate Limit
    const rateLimit = await checkRateLimit(settings.maxHourlyRequests || 50);
    if (!rateLimit.allowed) {
      const err = new Error(`Hourly AI request limit reached (${settings.maxHourlyRequests || 50}/hr). Resets in ${rateLimit.resetInMinutes} minutes.`);
      errorReported = true;
      if (onError) onError(err);
      throw err;
    }

    // 4. Resolve Model (retired model IDs saved by older versions fall back to current defaults)
    let model = DEFAULT_MODELS[provider];
    if (provider === AI_PROVIDERS.GEMINI && settings.geminiModel && !RETIRED_MODELS.has(settings.geminiModel)) model = settings.geminiModel;
    if (provider === AI_PROVIDERS.OPENAI && settings.openaiModel) model = settings.openaiModel;
    if (provider === AI_PROVIDERS.ANTHROPIC && settings.anthropicModel && !RETIRED_MODELS.has(settings.anthropicModel)) model = settings.anthropicModel;
    if (provider === AI_PROVIDERS.CUSTOM && settings.customModel) model = settings.customModel;

    // 5. Construct Prompts
    const systemPrompt = buildSystemPrompt(context);
    const userPrompt = customPrompt || buildUserPrompt(actionId, context);

    let fullText = '';
    const chunkCallback = (chunk, accumulated) => {
      fullText = accumulated;
      onChunk(chunk, accumulated);
    };

    // 6. Dispatch to provider
    switch (provider) {
      case AI_PROVIDERS.GEMINI:
        fullText = await streamGemini({ apiKey, model, systemPrompt, userPrompt, onChunk: chunkCallback, signal });
        break;

      case AI_PROVIDERS.OPENAI:
        fullText = await streamOpenAI({ apiKey, model, systemPrompt, userPrompt, onChunk: chunkCallback, signal });
        break;

      case AI_PROVIDERS.ANTHROPIC:
        fullText = await streamAnthropic({ apiKey, model, systemPrompt, userPrompt, onChunk: chunkCallback, signal });
        break;

      case AI_PROVIDERS.CUSTOM:
        fullText = await streamCustom({
          apiKey,
          baseUrl: settings.customBaseUrl || 'http://localhost:11434/v1',
          model,
          systemPrompt,
          userPrompt,
          onChunk: chunkCallback,
          signal
        });
        break;

      default:
        throw new Error(`Unsupported AI provider: ${provider}`);
    }

    // 7. Cache response and record usage
    if (fullText && useCache) {
      await setCachedResponse(cacheKey, fullText);
    }
    await recordRequest();

    const resultMeta = { cached: false, provider, model };
    if (onComplete) onComplete(fullText, resultMeta);

    return { content: fullText, cached: false, provider, model };
  } catch (err) {
    if (onError && !errorReported) onError(err);
    throw err;
  }
}
