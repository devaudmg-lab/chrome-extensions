/**
 * OpenAI Chat Completions Streaming API Adapter for ContextSearch (Phase 3).
 */

/**
 * Stream responses from OpenAI Chat Completions API.
 * @param {object} params 
 * @param {string} params.apiKey 
 * @param {string} params.model 
 * @param {string} params.systemPrompt 
 * @param {string} params.userPrompt 
 * @param {Function} params.onChunk 
 * @param {AbortSignal} [params.signal] 
 * @returns {Promise<string>}
 */
export async function streamOpenAI({ apiKey, model = 'gpt-4o-mini', systemPrompt, userPrompt, onChunk, signal }) {
  if (!apiKey) {
    throw new Error('OpenAI API Key is required. Please set it in ContextSearch Options.');
  }

  const endpoint = 'https://api.openai.com/v1/chat/completions';

  const body = {
    model,
    messages: [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: userPrompt }
    ],
    temperature: 0.2,
    max_tokens: 600,
    stream: true
  };

  const response = await fetch(endpoint, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`
    },
    body: JSON.stringify(body),
    signal
  });

  if (!response.ok) {
    const errorText = await response.text().catch(() => '');
    throw new Error(`OpenAI API error (${response.status}): ${errorText || response.statusText}`);
  }

  const reader = response.body.getReader();
  const decoder = new TextDecoder('utf-8');
  let fullText = '';
  let buffer = '';

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;

    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split('\n');
    buffer = lines.pop() || '';

    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed || !trimmed.startsWith('data:')) continue;

      const jsonStr = trimmed.replace(/^data:\s*/, '');
      if (jsonStr === '[DONE]') continue;

      try {
        const parsed = JSON.parse(jsonStr);
        const chunk = parsed?.choices?.[0]?.delta?.content || '';
        if (chunk) {
          fullText += chunk;
          onChunk(chunk, fullText);
        }
      } catch {
        // Incomplete chunk, skip
      }
    }
  }

  return fullText;
}
