/**
 * Anthropic Claude Streaming API Adapter for ContextSearch (Phase 3).
 */

/**
 * Stream responses from Anthropic Messages API.
 * @param {object} params 
 * @param {string} params.apiKey 
 * @param {string} params.model 
 * @param {string} params.systemPrompt 
 * @param {string} params.userPrompt 
 * @param {Function} params.onChunk 
 * @param {AbortSignal} [params.signal] 
 * @returns {Promise<string>}
 */
export async function streamAnthropic({ apiKey, model = 'claude-haiku-4-5', systemPrompt, userPrompt, onChunk, signal }) {
  if (!apiKey) {
    throw new Error('Anthropic API Key is required. Please set it in ContextSearch Options.');
  }

  const endpoint = 'https://api.anthropic.com/v1/messages';

  const body = {
    model,
    max_tokens: 600,
    system: systemPrompt,
    messages: [
      { role: 'user', content: userPrompt }
    ],
    stream: true
  };

  const response = await fetch(endpoint, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
      'anthropic-dangerous-direct-browser-access': 'true'
    },
    body: JSON.stringify(body),
    signal
  });

  if (!response.ok) {
    const errorText = await response.text().catch(() => '');
    throw new Error(`Anthropic API error (${response.status}): ${errorText || response.statusText}`);
  }

  const reader = response.body.getReader();
  const decoder = new TextDecoder('utf-8');
  let fullText = '';
  let buffer = '';

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;

    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split('\n');
    buffer = lines.pop() || '';

    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed || !trimmed.startsWith('data:')) continue;

      const jsonStr = trimmed.replace(/^data:\s*/, '');
      try {
        const parsed = JSON.parse(jsonStr);
        if (parsed.type === 'content_block_delta' && parsed.delta?.text) {
          const chunk = parsed.delta.text;
          fullText += chunk;
          onChunk(chunk, fullText);
        }
      } catch {
        // Skip incomplete chunk
      }
    }
  }

  return fullText;
}
