/**
 * Custom / Local (Ollama, OpenRouter, Groq) Streaming API Adapter for ContextSearch (Phase 3).
 */

/**
 * Stream responses from OpenAI-compatible custom endpoints.
 * @param {object} params 
 * @param {string} [params.apiKey] 
 * @param {string} [params.baseUrl] 
 * @param {string} [params.model] 
 * @param {string} params.systemPrompt 
 * @param {string} params.userPrompt 
 * @param {Function} params.onChunk 
 * @param {AbortSignal} [params.signal] 
 * @returns {Promise<string>}
 */
export async function streamCustom({ apiKey = '', baseUrl = 'http://localhost:11434/v1', model = 'llama3', systemPrompt, userPrompt, onChunk, signal }) {
  const cleanBaseUrl = baseUrl.replace(/\/+$/, '');
  const endpoint = `${cleanBaseUrl}/chat/completions`;

  const headers = { 'Content-Type': 'application/json' };
  if (apiKey) {
    headers['Authorization'] = `Bearer ${apiKey}`;
  }

  const body = {
    model,
    messages: [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: userPrompt }
    ],
    temperature: 0.2,
    max_tokens: 600,
    stream: true
  };

  const response = await fetch(endpoint, {
    method: 'POST',
    headers,
    body: JSON.stringify(body),
    signal
  });

  if (!response.ok) {
    const errorText = await response.text().catch(() => '');
    throw new Error(`Custom endpoint error (${response.status}): ${errorText || response.statusText}`);
  }

  const reader = response.body.getReader();
  const decoder = new TextDecoder('utf-8');
  let fullText = '';
  let buffer = '';

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;

    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split('\n');
    buffer = lines.pop() || '';

    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed || !trimmed.startsWith('data:')) continue;

      const jsonStr = trimmed.replace(/^data:\s*/, '');
      if (jsonStr === '[DONE]') continue;

      try {
        const parsed = JSON.parse(jsonStr);
        const chunk = parsed?.choices?.[0]?.delta?.content || '';
        if (chunk) {
          fullText += chunk;
          onChunk(chunk, fullText);
        }
      } catch {
        // Skip incomplete chunk
      }
    }
  }

  return fullText;
}
