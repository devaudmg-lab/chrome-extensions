/**
 * Turn a provider's HTTP error body into a short, readable message.
 * Providers answer with JSON such as {"error":{"message":"..."}}; showing the raw body
 * in the panel is noisy, so the message is extracted and capped.
 * @param {string} label Provider name shown to the user
 * @param {number} status HTTP status
 * @param {string} bodyText Raw response body
 * @returns {Error}
 */
export function providerError(label, status, bodyText = '') {
  let detail = '';
  try {
    const parsed = JSON.parse(bodyText);
    const err = Array.isArray(parsed) ? parsed[0]?.error : parsed?.error;
    detail = (err && (err.message || err.type)) || parsed?.message || '';
  } catch {
    detail = String(bodyText || '').replace(/\s+/g, ' ').trim();
  }
  let hint = '';
  if (status === 401 || status === 403) hint = ' Check the API key in ContextSearch Options.';
  else if (status === 404) hint = ' Check the model name in ContextSearch Options.';
  else if (status === 429) hint = ' The provider is rate limiting you: wait a moment and try again.';
  const text = String(detail || '').slice(0, 240).replace(/[.\s]+$/, '');
  return new Error(`${label} error (${status})${text ? `: ${text}` : ''}.${hint}`);
}
