/**
 * Google Gemini Streaming API Adapter for ContextSearch (Phase 3).
 */

/**
 * Stream responses from Google Gemini API.
 * @param {object} params 
 * @param {string} params.apiKey 
 * @param {string} params.model 
 * @param {string} params.systemPrompt 
 * @param {string} params.userPrompt 
 * @param {Function} params.onChunk 
 * @param {AbortSignal} [params.signal] 
 * @returns {Promise<string>}
 */
export async function streamGemini({ apiKey, model = 'gemini-2.5-flash', systemPrompt, userPrompt, onChunk, signal }) {
  if (!apiKey) {
    throw new Error('Google Gemini API Key is required. Please set it in ContextSearch Options.');
  }

  const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${model}:streamGenerateContent?alt=sse&key=${apiKey}`;

  const body = {
    system_instruction: {
      parts: [{ text: systemPrompt }]
    },
    contents: [
      {
        role: 'user',
        parts: [{ text: userPrompt }]
      }
    ],
    generationConfig: {
      temperature: 0.2,
      maxOutputTokens: 600
    }
  };

  const response = await fetch(endpoint, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
    signal
  });

  if (!response.ok) {
    const errorText = await response.text().catch(() => '');
    throw new Error(`Gemini API error (${response.status}): ${errorText || response.statusText}`);
  }

  const reader = response.body.getReader();
  const decoder = new TextDecoder('utf-8');
  let fullText = '';
  let buffer = '';

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;

    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split('\n');
    buffer = lines.pop() || '';

    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed || !trimmed.startsWith('data:')) continue;

      const jsonStr = trimmed.replace(/^data:\s*/, '');
      if (jsonStr === '[DONE]') continue;

      try {
        const parsed = JSON.parse(jsonStr);
        const chunk = parsed?.candidates?.[0]?.content?.parts?.[0]?.text || '';
        if (chunk) {
          fullText += chunk;
          onChunk(chunk, fullText);
        }
      } catch {
        // Incomplete JSON chunk, skip
      }
    }
  }

  return fullText;
}
