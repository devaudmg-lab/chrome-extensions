/**
 * Local model discovery for ContextSearch (Ollama-first mode).
 * Lists the models a local Ollama (or any OpenAI-compatible server) has available,
 * so users can pick one instead of typing a model name.
 */

export const OLLAMA_DEFAULT_BASE_URL = 'http://localhost:11434/v1';

/**
 * Normalize model list payloads from OpenAI-compatible (`/v1/models`) or
 * Ollama-native (`/api/tags`) endpoints into a sorted, de-duplicated list of names.
 * @param {object} payload
 * @returns {Array<string>}
 */
export function parseModelList(payload) {
  if (!payload || typeof payload !== 'object') return [];
  const names = [];

  if (Array.isArray(payload.data)) {
    payload.data.forEach(m => { if (m && typeof m.id === 'string') names.push(m.id); });
  }
  if (Array.isArray(payload.models)) {
    payload.models.forEach(m => {
      const name = m && (m.name || m.model);
      if (typeof name === 'string') names.push(name);
    });
  }

  return Array.from(new Set(names.map(n => n.trim()).filter(Boolean))).sort((a, b) => a.localeCompare(b));
}

/**
 * Pick a sensible default from a discovered model list (prefers coding / general chat models,
 * skips embedding-only models).
 * @param {Array<string>} models
 * @returns {string}
 */
export function pickPreferredModel(models = []) {
  const usable = models.filter(m => !/embed|bge|minilm|nomic-embed/i.test(m));
  if (usable.length === 0) return '';
  const preferences = [/coder/i, /llama3/i, /qwen/i, /mistral|mixtral/i, /gemma/i, /phi/i, /deepseek/i];
  for (const re of preferences) {
    const hit = usable.find(m => re.test(m));
    if (hit) return hit;
  }
  return usable[0];
}

/**
 * Ollama's native API root for a given OpenAI-compatible base URL
 * (e.g. http://localhost:11434/v1 -> http://localhost:11434).
 * @param {string} baseUrl
 * @returns {string}
 */
export function nativeRootFor(baseUrl = OLLAMA_DEFAULT_BASE_URL) {
  return String(baseUrl || OLLAMA_DEFAULT_BASE_URL).replace(/\/+$/, '').replace(/\/v1$/, '');
}

/**
 * Query a local server for its installed models.
 * Tries the OpenAI-compatible `/models` route first, then Ollama's native `/api/tags`.
 * @param {string} [baseUrl]
 * @param {object} [opts]
 * @param {number} [opts.timeoutMs=2500]
 * @param {string} [opts.apiKey]
 * @returns {Promise<{ ok: boolean, models: Array<string>, error?: string, status?: number }>}
 */
export async function discoverModels(baseUrl = OLLAMA_DEFAULT_BASE_URL, { timeoutMs = 2500, apiKey = '' } = {}) {
  const clean = String(baseUrl || OLLAMA_DEFAULT_BASE_URL).replace(/\/+$/, '');
  const urls = [`${clean}/models`, `${nativeRootFor(clean)}/api/tags`];
  const headers = apiKey ? { Authorization: `Bearer ${apiKey}` } : {};
  let lastError = 'No response';
  let lastStatus;

  for (const url of urls) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const res = await fetch(url, { headers, signal: controller.signal });
      lastStatus = res.status;
      if (!res.ok) {
        lastError = res.status === 403
          ? 'Ollama refused the request (403). Start it with OLLAMA_ORIGINS=chrome-extension://* and try again.'
          : `Server answered ${res.status}`;
        continue;
      }
      const models = parseModelList(await res.json());
      if (models.length > 0) return { ok: true, models };
      lastError = 'The server is running but has no models. Pull one first, e.g. "ollama pull llama3.2".';
    } catch {
      if (lastStatus === undefined) lastError = 'No local server answered. Is Ollama running?';
    } finally {
      clearTimeout(timer);
    }
  }

  return { ok: false, models: [], error: lastError, status: lastStatus };
}
