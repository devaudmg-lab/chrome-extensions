/**
 * Local Response Cache for ContextSearch AI Queries (Phase 3).
 * Hashes queries, enforces a 24h TTL, and evicts LRU entries.
 */

const CACHE_TTL_MS = 24 * 60 * 60 * 1000; // 24 hours
const MAX_CACHE_ENTRIES = 100;

let memoryCache = new Map();

/**
 * Generate a cache key from action and context.
 * @param {string} actionId 
 * @param {object} context 
 * @returns {string}
 */
export function generateCacheKey(actionId, context = {}) {
  const text = context?.selection?.text || '';
  const lang = context?.detected?.language || '';
  const site = context?.detected?.siteType || '';
  return `${actionId}::${site}::${lang}::${text.trim()}`;
}

/**
 * Retrieve cached response if present and not expired.
 * @param {string} key 
 * @returns {Promise<string|null>}
 */
export async function getCachedResponse(key) {
  if (!key) return null;

  // 1. Check memory cache first
  if (memoryCache.has(key)) {
    const entry = memoryCache.get(key);
    if (Date.now() - entry.timestamp < CACHE_TTL_MS) {
      return entry.content;
    }
    memoryCache.delete(key);
  }

  // 2. Check storage.local
  try {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      return new Promise((resolve) => {
        chrome.storage.local.get(['aiResponseCache'], (res) => {
          const cache = res.aiResponseCache || {};
          const entry = cache[key];
          if (entry && (Date.now() - entry.timestamp < CACHE_TTL_MS)) {
            memoryCache.set(key, entry);
            resolve(entry.content);
          } else {
            resolve(null);
          }
        });
      });
    }
  } catch (err) {
    console.debug('[ContextSearch] Cache lookup notice:', err);
  }

  return null;
}

/**
 * Store response in cache.
 * @param {string} key 
 * @param {string} content 
 * @returns {Promise<void>}
 */
export async function setCachedResponse(key, content) {
  if (!key || !content) return;

  const entry = {
    content,
    timestamp: Date.now()
  };

  memoryCache.set(key, entry);

  try {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      chrome.storage.local.get(['aiResponseCache'], (res) => {
        const cache = res.aiResponseCache || {};
        cache[key] = entry;

        // Evict oldest entries if capacity exceeded
        const keys = Object.keys(cache);
        if (keys.length > MAX_CACHE_ENTRIES) {
          keys.sort((a, b) => cache[a].timestamp - cache[b].timestamp);
          const toDelete = keys.slice(0, keys.length - MAX_CACHE_ENTRIES);
          toDelete.forEach(k => delete cache[k]);
        }

        chrome.storage.local.set({ aiResponseCache: cache });
      });
    }
  } catch (err) {
    console.debug('[ContextSearch] Cache set notice:', err);
  }
}

/**
 * Clear all cached responses.
 * @returns {Promise<void>}
 */
export async function clearCache() {
  memoryCache.clear();
  try {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      await new Promise(resolve => chrome.storage.local.remove(['aiResponseCache'], resolve));
    }
  } catch (err) {
    console.debug('[ContextSearch] Cache clear notice:', err);
  }
}

/**
 * Get count of cached entries.
 * @returns {Promise<number>}
 */
export async function getCacheSize() {
  try {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      return new Promise((resolve) => {
        chrome.storage.local.get(['aiResponseCache'], (res) => {
          const cache = res.aiResponseCache || {};
          resolve(Object.keys(cache).length);
        });
      });
    }
  } catch {
    return memoryCache.size;
  }
  return memoryCache.size;
}
