/**
 * Rate Limiter for ContextSearch AI Queries (Phase 3).
 * Tracks request counts in a 1-hour rolling window.
 */

const WINDOW_MS = 60 * 60 * 1000; // 1 hour

/**
 * Check if the user has remaining request quota within the active window.
 * @param {number} maxHourly 
 * @returns {Promise<{ allowed: boolean, remaining: number, resetInMinutes: number }>}
 */
export async function checkRateLimit(maxHourly = 50) {
  const now = Date.now();

  try {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      return new Promise((resolve) => {
        chrome.storage.local.get(['rateLimitData'], (res) => {
          let data = res.rateLimitData || { timestamps: [] };

          // Filter out timestamps older than 1 hour
          data.timestamps = data.timestamps.filter(ts => now - ts < WINDOW_MS);

          const count = data.timestamps.length;
          const allowed = count < maxHourly;
          const remaining = Math.max(0, maxHourly - count);

          const oldest = data.timestamps[0] || now;
          const resetInMinutes = Math.max(1, Math.ceil((WINDOW_MS - (now - oldest)) / 60000));

          resolve({ allowed, remaining, resetInMinutes, count });
        });
      });
    }
  } catch (err) {
    console.debug('[ContextSearch] Rate limit check notice:', err);
  }

  return { allowed: true, remaining: maxHourly, resetInMinutes: 60, count: 0 };
}

/**
 * Record a consumed request timestamp.
 * @returns {Promise<void>}
 */
export async function recordRequest() {
  const now = Date.now();

  try {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      chrome.storage.local.get(['rateLimitData'], (res) => {
        let data = res.rateLimitData || { timestamps: [] };
        data.timestamps = data.timestamps.filter(ts => now - ts < WINDOW_MS);
        data.timestamps.push(now);
        chrome.storage.local.set({ rateLimitData: data });
      });
    }
  } catch (err) {
    console.debug('[ContextSearch] Rate limit record notice:', err);
  }
}
