/**
 * Context-Aware Prompt Builder for ContextSearch (Phase 3 & 5).
 * Constructs optimized system and user prompts with Developer / General Mode support.
 */

import { ACTION_TYPES } from '../shared/constants.js';

/**
 * Build the system prompt injecting developer or general context.
 * @param {object} context 
 * @returns {string}
 */
export function buildSystemPrompt(context = {}) {
  const detected = context.detected || {};
  const page = context.page || {};
  const selection = context.selection || {};
  const mode = context.mode || detected.mode || 'auto';

  const isGeneralMode = mode === 'general' || (mode === 'auto' && (detected.language === 'general' || (detected.category === 'concept' && !detected.language)));

  if (isGeneralMode) {
    return `You are ContextSearch, an intelligent, versatile knowledge assistant embedded in the browser.
You provide clear, accurate, insightful, and natural explanations for concepts, terms, questions, and topics.

CONTEXT:
- Page Title: ${page.title || 'Web'} (${page.domain || 'active tab'})
- Query Topic: ${selection.text || ''}
- Surrounding Text: ${selection.surrounding?.before || ''} [SELECTION] ${selection.surrounding?.after || ''}

RULES:
- Answer directly and clearly in concise, easy-to-read Markdown.
- Do NOT assume the query is programming code unless it explicitly contains code syntax.
- Use bullet points, bold key terms, and simple real-world examples where helpful.
- Skip all conversational filler, greetings, and disclaimers.`;
  }

  const platform = detected.siteType || 'Web';
  const language = (detected.language && detected.language !== 'general') ? detected.language : 'software development';
  const repoOrPkg = detected.repoName
    ? `${detected.repoOwner}/${detected.repoName}`
    : (detected.packageName || 'None');

  return `You are ContextSearch, a high-speed, expert developer assistant embedded in the browser.
You provide precise, practical, and highly context-aware explanations, fixes, and code.

CONTEXT:
- Platform: ${platform} (${page.domain || 'active tab'})
- Page Title: ${page.title || 'Untitled'}
- Repository / Package: ${repoOrPkg}
- Detected Language: ${language}
- Selection Category: ${detected.category || 'concept'} (${detected.subcategory || 'general'})
- Surrounding Context: ${selection.surrounding?.before || ''} [SELECTION] ${selection.surrounding?.after || ''}

RULES:
- Be concise and direct (under 150 words unless writing code/tests).
- Skip all conversational filler, greetings, and generic disclaimers.
- Use GitHub Flavored Markdown with syntax-highlighted code fences.
- Focus on practical, copy-pasteable solutions tailored to modern standards.`;
}

/**
 * Build action-specific user prompt.
 * @param {string} actionId 
 * @param {object} context 
 * @returns {string}
 */
export function buildUserPrompt(actionId, context = {}) {
  const selectionText = context?.selection?.text || '';
  const detected = context?.detected || {};
  const mode = context?.mode || detected.mode || 'auto';
  const language = detected.language || 'general';
  const isGeneral = mode === 'general' || (language === 'general' && detected.category === 'concept');

  switch (actionId) {
    case ACTION_TYPES.EXPLAIN:
      if (isGeneral) {
        return `Explain "${selectionText}" in clear, insightful, and accessible terms. Provide key definitions, context, and a simple real-world example if applicable.`;
      }
      return `Explain what "${selectionText}" is/does in ${language}. Provide a brief, practical code example showing typical usage.`;

    case ACTION_TYPES.DEBUG:
      if (isGeneral) {
        return `Analyze and troubleshoot the following issue or statement:\n"${selectionText}"\nProvide the root cause and a clear resolution.`;
      }
      return `The following error occurred in ${language}:\n"${selectionText}"\n\n1. Briefly identify the root cause.\n2. List the top 2-3 most probable reasons for this error.\n3. Provide the exact code fix or solution.`;

    case ACTION_TYPES.FIND_SOLUTIONS:
      if (isGeneral) {
        return `Provide 2-3 effective approaches or strategies to address "${selectionText}". Include brief pros and cons for each.`;
      }
      return `Provide 2 practical, modern approaches to solve or implement "${selectionText}" in ${language}. Include code snippets and brief pros/cons for each approach.`;

    case ACTION_TYPES.SUMMARIZE:
      return `Summarize the following text concisely into key takeaways and core points:\n\n"${selectionText}"`;

    case ACTION_TYPES.GENERATE_TESTS:
      return `Generate 3 unit test cases (Happy path, Edge case, Error handling) for the following ${language !== 'general' ? language : 'code'}:\n\n\`\`\`${language}\n${selectionText}\n\`\`\``;

    case ACTION_TYPES.EXPLAIN_COMMAND:
      return `Explain what this CLI command does step-by-step, including each flag/argument:\n\`${selectionText}\``;

    case ACTION_TYPES.CONVERT_SYNTAX:
      return `Convert the following code from ${language} to TypeScript with strict types and modern syntax:\n\n\`\`\`${language}\n${selectionText}\n\`\`\``;

    default:
      return isGeneral
        ? `Explain and analyze "${selectionText}".`
        : `Analyze and explain "${selectionText}" in the context of ${language}.`;
  }
}

/** Maximum number of earlier turns sent with a follow-up question. */
export const MAX_FOLLOW_UP_TURNS = 6;

/**
 * Build a single user prompt for a follow-up question that carries the earlier conversation.
 * Works with every provider adapter (they all take one system + one user prompt).
 * @param {Array<{ role: 'user'|'assistant', content: string }>} turns Earlier turns, oldest first
 * @param {string} question The new follow-up question
 * @param {object} [context]
 * @returns {string}
 */
export function buildFollowUpPrompt(turns = [], question = '', context = {}) {
  const selectionText = context?.selection?.text || '';
  const recent = (Array.isArray(turns) ? turns : []).slice(-MAX_FOLLOW_UP_TURNS);
  const transcript = recent
    .filter(t => t && t.content)
    .map(t => `${t.role === 'user' ? 'User' : 'Assistant'}: ${String(t.content).slice(0, 2000)}`)
    .join('\n\n');

  return `We are discussing the selected text "${selectionText.slice(0, 500)}".

CONVERSATION SO FAR:
${transcript || '(none)'}

FOLLOW-UP QUESTION:
${String(question).trim()}

Answer the follow-up directly, building on the conversation above. Do not repeat earlier answers.`;
}
