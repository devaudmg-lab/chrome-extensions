/**
 * Template and Prompt Variable Interpolator for ContextSearch (Phase 5).
 * Substitutes dynamic context tokens into custom URL templates and AI prompts.
 */

import { safeEncode } from '../shared/utils.js';

/**
 * Interpolate context variables into a template or prompt string.
 * @param {string} template 
 * @param {object} context 
 * @returns {string}
 */
export function interpolateTemplate(template, context = {}) {
  if (!template || typeof template !== 'string') return '';

  const selection = context?.selection?.text || '';
  const detected = context?.detected || {};
  const page = context?.page || {};

  const language = detected.language || 'javascript';
  const domain = page.domain || '';
  const pageTitle = page.title || '';
  const repoOwner = detected.repoOwner || '';
  const repoName = detected.repoName || '';
  const repo = repoOwner && repoName ? `${repoOwner}/${repoName}` : '';
  const category = detected.category || 'concept';
  const subcategory = detected.subcategory || category;

  return template
    .replace(/\{selection\}/gi, safeEncode(selection))
    .replace(/\{rawSelection\}/gi, selection)
    .replace(/\{language\}/gi, safeEncode(language))
    .replace(/\{rawLanguage\}/gi, language)
    .replace(/\{domain\}/gi, safeEncode(domain))
    .replace(/\{repo\}/gi, safeEncode(repo))
    .replace(/\{repoOwner\}/gi, safeEncode(repoOwner))
    .replace(/\{repoName\}/gi, safeEncode(repoName))
    .replace(/\{pageTitle\}/gi, safeEncode(pageTitle))
    .replace(/\{category\}/gi, safeEncode(category))
    .replace(/\{subcategory\}/gi, safeEncode(subcategory))
    .replace(/\{context\}/gi, safeEncode(`${language} ${category}`));
}

/**
 * Check if a custom action matches the active context conditions.
 * @param {object} action 
 * @param {object} context 
 * @returns {boolean}
 */
export function matchesActionConditions(action, context = {}) {
  if (!action || action.enabled === false) return false;
  if (!action.conditions) return true;

  const detected = context?.detected || {};
  const page = context?.page || {};

  const lang = (detected.language || '').toLowerCase();
  const category = (detected.category || '').toLowerCase();
  const domain = (page.domain || '').toLowerCase();

  // 1. Language condition
  if (action.conditions.languages && action.conditions.languages.length > 0) {
    const langs = action.conditions.languages.map(l => l.toLowerCase());
    if (!langs.includes(lang) && !langs.includes('*')) {
      return false;
    }
  }

  // 2. Category condition
  if (action.conditions.categories && action.conditions.categories.length > 0) {
    const cats = action.conditions.categories.map(c => c.toLowerCase());
    if (!cats.includes(category) && !cats.includes('*')) {
      return false;
    }
  }

  // 3. Domain condition
  if (action.conditions.domains && action.conditions.domains.length > 0) {
    const matchedDomain = action.conditions.domains.some(d => domain.includes(d.toLowerCase()));
    if (!matchedDomain) {
      return false;
    }
  }

  return true;
}
