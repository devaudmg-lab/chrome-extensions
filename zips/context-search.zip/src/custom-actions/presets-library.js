/**
 * Pre-built Custom Actions & Preset Packs Library for ContextSearch (Phase 5).
 */

export const PRESET_CUSTOM_ACTIONS = [
  {
    id: 'preset_big_o',
    name: '⏱️ Big-O Complexity Analysis',
    shortLabel: 'Big-O',
    icon: '⏱️',
    type: 'ai',
    badge: 'AI ✨',
    aiPrompt: 'Analyze the time and space complexity (Big-O notation) of the following {rawLanguage} code:\n\n```{rawLanguage}\n{rawSelection}\n```\nProvide: 1) Best Case, 2) Average Case, 3) Worst Case, 4) Auxiliary Space, and a concise 2-sentence optimization tip.',
    template: '',
    conditions: { categories: ['code'] },
    enabled: true,
    isCustom: true
  },
  {
    id: 'preset_eli5',
    name: '👶 Explain Like I\'m 5 (ELI5)',
    shortLabel: 'ELI5',
    icon: '👶',
    type: 'ai',
    badge: 'AI ✨',
    aiPrompt: 'Explain "{rawSelection}" in simple, intuitive, non-technical terms using a real-world analogy. Avoid complex jargon.',
    template: '',
    conditions: {},
    enabled: true,
    isCustom: true
  },
  {
    id: 'preset_convert_rust',
    name: '🦀 Convert to Idiomatic Rust',
    shortLabel: 'To Rust',
    icon: '🦀',
    type: 'ai',
    badge: 'AI ✨',
    aiPrompt: 'Rewrite the following {rawLanguage} code into modern, idiomatic, memory-safe Rust with error handling:\n\n```{rawLanguage}\n{rawSelection}\n```',
    conditions: { categories: ['code'] },
    enabled: true,
    isCustom: true
  },
  {
    id: 'preset_dockerfile',
    name: '🐳 Generate Dockerfile',
    shortLabel: 'Dockerfile',
    icon: '🐳',
    type: 'ai',
    badge: 'AI ✨',
    aiPrompt: 'Generate an optimized multi-stage production Dockerfile and .dockerignore for a modern {rawLanguage} project using "{rawSelection}".',
    conditions: {},
    enabled: true,
    isCustom: true
  },
  {
    id: 'preset_caniuse',
    name: '🌐 Check on CanIUse.com',
    shortLabel: 'CanIUse',
    icon: '🌐',
    type: 'url',
    badge: '→Web',
    template: 'https://caniuse.com/?search={selection}',
    aiPrompt: '',
    conditions: {},
    enabled: true,
    isCustom: true
  },
  {
    id: 'preset_grep_app',
    name: '🔎 Search on Grep.app (500k repos)',
    shortLabel: 'Grep.app',
    icon: '🔎',
    type: 'url',
    badge: '→Code',
    template: 'https://grep.app/search?q={selection}&filter[lang][0]={language}',
    aiPrompt: '',
    conditions: { categories: ['code', 'api', 'concept'] },
    enabled: true,
    isCustom: true
  }
];

export const PRESET_PACKS = {
  frontend_pro: {
    id: 'frontend_pro',
    name: 'Frontend Pro Pack',
    description: 'React, Next.js, CanIUse compatibility, and web performance tools.',
    actionIds: ['preset_caniuse', 'preset_big_o', 'preset_eli5']
  },
  backend_devops: {
    id: 'backend_devops',
    name: 'Backend & DevOps Pack',
    description: 'Docker generation, Rust conversion, Big-O analysis, and Grep.app code search.',
    actionIds: ['preset_dockerfile', 'preset_convert_rust', 'preset_grep_app', 'preset_big_o']
  },
  fullstack: {
    id: 'fullstack',
    name: 'Full-Stack Developer Suite',
    description: 'All pre-built developer workflows for frontend, backend, and system design.',
    actionIds: ['preset_big_o', 'preset_eli5', 'preset_convert_rust', 'preset_dockerfile', 'preset_caniuse', 'preset_grep_app']
  }
};
