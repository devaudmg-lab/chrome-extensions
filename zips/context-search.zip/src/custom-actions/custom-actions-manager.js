/**
 * Custom Actions CRUD Manager for ContextSearch (Phase 5).
 * Persists user-defined actions in chrome.storage.local.
 */

import { PRESET_CUSTOM_ACTIONS } from './presets-library.js';

let inMemoryCustomActions = [...PRESET_CUSTOM_ACTIONS];

/**
 * Retrieve all custom actions (persisted + active presets).
 * @returns {Promise<Array<object>>}
 */
export async function getCustomActions() {
  try {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      return new Promise((resolve) => {
        chrome.storage.local.get(['customActionsList'], (res) => {
          if (res && res.customActionsList && Array.isArray(res.customActionsList)) {
            inMemoryCustomActions = res.customActionsList;
          } else {
            inMemoryCustomActions = [...PRESET_CUSTOM_ACTIONS];
          }
          resolve(inMemoryCustomActions);
        });
      });
    }
  } catch {
    // Return memory cache
  }
  return inMemoryCustomActions;
}

/**
 * Save the entire list of custom actions.
 * @param {Array<object>} actions 
 * @returns {Promise<Array<object>>}
 */
export async function saveCustomActions(actions) {
  inMemoryCustomActions = Array.isArray(actions) ? actions : [];

  try {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      await new Promise((resolve) => {
        chrome.storage.local.set({ customActionsList: inMemoryCustomActions }, resolve);
      });
    }
  } catch {
    // Ignore
  }

  return inMemoryCustomActions;
}

/**
 * Add or update a single custom action.
 * @param {object} action 
 * @returns {Promise<Array<object>>}
 */
export async function upsertCustomAction(action) {
  if (!action || !action.name) throw new Error('Action must have a name');

  const actions = await getCustomActions();
  const id = action.id || `custom_${Date.now()}`;
  const fullAction = {
    id,
    name: action.name,
    shortLabel: action.shortLabel || action.name.slice(0, 12),
    icon: action.icon || '⚡',
    type: action.type || 'url',
    badge: action.type === 'ai' ? 'AI ✨' : '→Web',
    template: action.template || '',
    aiPrompt: action.aiPrompt || '',
    conditions: action.conditions || {},
    enabled: action.enabled !== false,
    isCustom: true
  };

  const existingIdx = actions.findIndex(a => a.id === id);
  if (existingIdx >= 0) {
    actions[existingIdx] = fullAction;
  } else {
    actions.push(fullAction);
  }

  return saveCustomActions(actions);
}

/**
 * Delete a custom action by ID.
 * @param {string} id 
 * @returns {Promise<Array<object>>}
 */
export async function deleteCustomAction(id) {
  const actions = await getCustomActions();
  const filtered = actions.filter(a => a.id !== id);
  return saveCustomActions(filtered);
}

/**
 * Toggle enable/disable status for a custom action.
 * @param {string} id 
 * @returns {Promise<boolean>}
 */
export async function toggleCustomAction(id) {
  const actions = await getCustomActions();
  const target = actions.find(a => a.id === id);
  if (target) {
    target.enabled = !target.enabled;
    await saveCustomActions(actions);
    return target.enabled;
  }
  return false;
}

/**
 * Reset custom actions to built-in presets.
 * @returns {Promise<Array<object>>}
 */
export async function resetCustomActions() {
  return saveCustomActions([...PRESET_CUSTOM_ACTIONS]);
}
