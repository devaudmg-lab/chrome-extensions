/**
 * ContextSearch Popup Script.
 */

import { getActionsForContext } from '../background/action-registry.js';
import { buildTargetUrl } from '../background/url-builder.js';
import { classifyText } from '../content/text-classifier.js';
import { classifyDomain } from '../content/domain-classifier.js';
import { truncate, escapeHtml } from '../shared/utils.js';

let activeContext = null;

/**
 * Update the popup UI with the provided context.
 * @param {object} context 
 */
function renderContextUI(context) {
  if (!context) return;
  activeContext = context;

  const siteBadge = document.getElementById('site-badge');
  const selectionText = document.getElementById('selection-text');
  const categoryBadge = document.getElementById('category-badge');
  const languageBadge = document.getElementById('language-badge');
  const domainText = document.getElementById('domain-text');
  const actionsList = document.getElementById('actions-list');

  const detected = context.detected || {};
  const selection = context.selection || {};
  const page = context.page || {};

  // Site Badge
  siteBadge.textContent = detected.siteType ? detected.siteType.toUpperCase() : 'GENERIC';

  // Selection
  if (selection.text && selection.text.trim()) {
    selectionText.textContent = selection.text;
  } else {
    selectionText.textContent = 'No text selected on page';
  }

  // Category Badge
  const category = detected.category || 'concept';
  categoryBadge.textContent = category.toUpperCase();
  categoryBadge.className = `badge category-badge ${category}`;

  // Language Badge
  languageBadge.textContent = detected.language || 'javascript';

  // Domain Text
  domainText.textContent = page.domain || 'active tab';

  // Actions
  const actions = getActionsForContext(context);
  actionsList.innerHTML = '';

  if (!actions || actions.length === 0) {
    actionsList.innerHTML = '<div class="action-item-placeholder">No actions available for context</div>';
    return;
  }

  actions.forEach(action => {
    const item = document.createElement('div');
    item.className = 'action-item';

    const cleanSnippet = truncate(selection.text || 'text', 14);
    let label = action.title && action.title.includes('%s')
      ? action.title.replace('%s', cleanSnippet)
      : `${action.icon || '⚡'} ${action.shortLabel || action.name || 'Action'}`;

    item.innerHTML = `
      <div class="action-left">
        <span class="action-icon">${escapeHtml(action.icon)}</span>
        <span class="action-label">${escapeHtml(label)}</span>
      </div>
      <span class="action-target-badge">↗</span>
    `;

    item.addEventListener('click', () => {
      const targetUrl = buildTargetUrl(action.id, activeContext);
      if (chrome && chrome.tabs && chrome.tabs.create) {
        chrome.tabs.create({ url: targetUrl });
      } else {
        window.open(targetUrl, '_blank');
      }
    });

    actionsList.appendChild(item);
  });
}

/**
 * Load context from active tab or background storage.
 */
async function loadActiveContext() {
  try {
    // 1. Try querying active tab content script
    if (chrome && chrome.tabs && chrome.tabs.query) {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab && tab.id) {
        try {
          const response = await chrome.tabs.sendMessage(tab.id, { type: 'GET_CURRENT_CONTEXT' });
          if (response && response.context && response.context.selection?.text) {
            renderContextUI(response.context);
            return;
          }
        } catch {
          // Content script may not be loaded on internal chrome:// pages
        }

        // Default tab context if no active selection
        const domainContext = classifyDomain(tab.url || '', tab.title || '');
        const fallbackContext = {
          selection: { text: '' },
          page: { url: tab.url || '', domain: domainContext.domain, title: tab.title || '' },
          detected: {
            siteType: domainContext.siteType,
            language: domainContext.language,
            category: 'concept'
          }
        };
        renderContextUI(fallbackContext);
      }
    }
  } catch (err) {
    console.debug('[ContextSearch] Popup init notice:', err);
  }
}

/**
 * Handle quick manual test classification.
 */
function handleTestQuery() {
  const input = document.getElementById('test-input');
  const text = (input.value || '').trim();
  if (!text) return;

  const domainContext = classifyDomain(activeContext?.page?.url || 'https://github.com/test/repo', 'Test Page');
  const textContext = classifyText(text, domainContext);

  const testContext = {
    selection: { text, length: text.length },
    page: {
      url: activeContext?.page?.url || 'https://github.com',
      domain: domainContext.domain || 'github.com',
      title: 'Manual Query Test'
    },
    detected: {
      siteType: domainContext.siteType,
      language: domainContext.language,
      category: textContext.category,
      confidence: textContext.confidence,
      reasoning: textContext.reasoning
    }
  };

  renderContextUI(testContext);
}

document.addEventListener('DOMContentLoaded', () => {
  loadActiveContext();

  const openSettingsBtn = document.getElementById('open-settings-btn');
  if (openSettingsBtn) {
    openSettingsBtn.addEventListener('click', () => {
      if (chrome && chrome.runtime && chrome.runtime.openOptionsPage) {
        chrome.runtime.openOptionsPage();
      } else {
        window.open('../options/options.html', '_blank');
      }
    });
  }

  const testBtn = document.getElementById('test-btn');
  const testInput = document.getElementById('test-input');

  if (testBtn) testBtn.addEventListener('click', handleTestQuery);
  if (testInput) {
    testInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') handleTestQuery();
    });
  }
});
