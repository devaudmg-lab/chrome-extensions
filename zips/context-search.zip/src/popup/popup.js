/**
 * ContextSearch Popup Script.
 */

import { getActionsForContext } from '../background/action-registry.js';
import { buildTargetUrl } from '../background/url-builder.js';
import { classifyText } from '../content/text-classifier.js';
import { classifyDomain } from '../content/domain-classifier.js';
import { truncate, escapeHtml } from '../shared/utils.js';
import { getSettings } from '../shared/settings-manager.js';
import { getKeyForProvider } from '../shared/api-keys-manager.js';
import { getCustomActions } from '../custom-actions/custom-actions-manager.js';
import { interpolateTemplate } from '../custom-actions/template-interpolator.js';
import { isSafeHttpUrl } from '../shared/utils.js';

const PROVIDER_LABELS = { gemini: 'Gemini', openai: 'OpenAI', anthropic: 'Claude', custom: 'Local / custom' };

/**
 * Show which AI provider answers (or that Demo Mode is active).
 */
async function renderAiStatus() {
  const el = document.getElementById('ai-status');
  if (!el) return;
  try {
    const settings = await getSettings();
    const provider = settings.aiProvider || 'gemini';
    if (provider === 'custom') {
      el.textContent = `AI: ${settings.customModel || 'local model'} (local)`;
      return;
    }
    const key = await getKeyForProvider(provider);
    if (!key) {
      el.textContent = 'AI: Demo Mode (add a key)';
      el.classList.add('demo');
      el.style.cursor = 'pointer';
      el.onclick = () => chrome.runtime.openOptionsPage();
    } else {
      el.textContent = `AI: ${PROVIDER_LABELS[provider] || provider}`;
    }
  } catch {
    el.textContent = '';
  }
}

let activeContext = null;
let activeTabId = null;
let pageSelection = false; // true when the context came from a real selection in the tab
let customActions = [];
let currentWindowId = null;

/**
 * Show whether ContextSearch can run on the current tab (it can't on chrome://, the Web Store, PDFs...).
 * @param {boolean} available
 */
function setPageStatus(available) {
  const el = document.querySelector('.status-indicator');
  if (!el) return;
  el.classList.toggle('active', available);
  el.classList.toggle('inactive', !available);
  el.title = available ? 'ContextSearch is running on this page' : 'Browsers do not allow extensions on this page';
  const label = el.querySelector('.status-label');
  if (label) label.textContent = available ? 'Active' : 'Not on this page';
}

/**
 * Run an action picked in the popup.
 * AI actions answer in the page (the popup closes), Deep Research opens the side panel,
 * search actions open a new tab.
 * @param {object} action
 */
function runPopupAction(action) {
  if (!activeContext) return;
  if ((action.isSidePanel || action.id === 'deep_research') && chrome.sidePanel && currentWindowId !== null) {
    // Must be called synchronously inside the click (user gesture)
    chrome.sidePanel.open({ windowId: currentWindowId }).catch(() => {});
    chrome.runtime.sendMessage({ type: 'OPEN_SIDEPANEL', context: activeContext }).catch(() => {});
    setTimeout(() => window.close(), 150);
    return;
  }
  if ((action.isAI || action.type === 'ai') && pageSelection && activeTabId !== null) {
    chrome.tabs.sendMessage(activeTabId, { type: 'RUN_ACTION', actionId: action.id, selectionText: activeContext.selection?.text || '' })
      .then((res) => {
        if (res && res.success) window.close();
        else openUrlFor(action);
      })
      .catch(() => openUrlFor(action));
    return;
  }
  openUrlFor(action);
}

function openUrlFor(action) {
  const targetUrl = action.isCustom && action.template
    ? interpolateTemplate(action.template, activeContext)
    : buildTargetUrl(action.id, activeContext);
  if (!isSafeHttpUrl(targetUrl)) return;
  chrome.tabs.create({ url: targetUrl });
}

/**
 * Update the popup UI with the provided context.
 * @param {object} context 
 */
function renderContextUI(context) {
  if (!context) return;
  activeContext = context;

  const siteBadge = document.getElementById('site-badge');
  const selectionText = document.getElementById('selection-text');
  const categoryBadge = document.getElementById('category-badge');
  const languageBadge = document.getElementById('language-badge');
  const domainText = document.getElementById('domain-text');
  const actionsList = document.getElementById('actions-list');

  const detected = context.detected || {};
  const selection = context.selection || {};
  const page = context.page || {};

  // Site Badge
  siteBadge.textContent = detected.siteType ? detected.siteType.toUpperCase() : 'GENERIC';

  // Selection
  if (selection.text && selection.text.trim()) {
    selectionText.textContent = selection.text;
  } else {
    selectionText.textContent = 'No text selected on page';
  }

  // Category Badge
  const category = detected.category || 'concept';
  categoryBadge.textContent = category.toUpperCase();
  categoryBadge.className = `badge category-badge ${category}`;

  // Language Badge
  languageBadge.textContent = detected.language || 'javascript';

  // Domain Text
  domainText.textContent = page.domain || 'active tab';

  // Actions
  actionsList.innerHTML = '';
  if (!selection.text || !selection.text.trim()) {
    actionsList.innerHTML = '<div class="action-item-placeholder">Select text on the page (or type a test query below) to see actions.</div>';
    return;
  }

  const actions = getActionsForContext(context, customActions);
  if (!actions || actions.length === 0) {
    actionsList.innerHTML = '<div class="action-item-placeholder">No actions available for context</div>';
    return;
  }

  actions.forEach(action => {
    const item = document.createElement('button');
    item.type = 'button';
    item.className = 'action-item';

    const cleanSnippet = truncate(selection.text || 'text', 14);
    let label = action.title && action.title.includes('%s')
      ? action.title.replace('%s', cleanSnippet)
      : (action.shortLabel || action.name || 'Action');
    if (action.icon && label.startsWith(action.icon)) label = label.slice(action.icon.length).trim();

    item.innerHTML = `
      <div class="action-left">
        <span class="action-icon">${escapeHtml(action.icon)}</span>
        <span class="action-label">${escapeHtml(label)}</span>
      </div>
      <span class="action-target-badge" aria-hidden="true">${escapeHtml(action.badge || '↗')}</span>
    `;

    item.addEventListener('click', () => runPopupAction(action));

    actionsList.appendChild(item);
  });
}

/**
 * Load context from active tab or background storage.
 */
async function loadActiveContext() {
  try {
    // 1. Try querying active tab content script
    if (chrome && chrome.tabs && chrome.tabs.query) {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab && tab.id) {
        activeTabId = tab.id;
        try {
          const response = await chrome.tabs.sendMessage(tab.id, { type: 'GET_CURRENT_CONTEXT' }, { frameId: 0 });
          setPageStatus(true);
          if (response && response.context && response.context.selection?.text) {
            pageSelection = true;
            renderContextUI(response.context);
            return;
          }
        } catch {
          // Content script may not be loaded on internal chrome:// pages
          setPageStatus(false);
        }

        // Default tab context if no active selection
        const domainContext = classifyDomain(tab.url || '', tab.title || '');
        const fallbackContext = {
          selection: { text: '' },
          page: { url: tab.url || '', domain: domainContext.domain, title: tab.title || '' },
          detected: {
            siteType: domainContext.siteType,
            language: domainContext.language,
            category: 'concept'
          }
        };
        renderContextUI(fallbackContext);
      }
    }
  } catch (err) {
    console.debug('[ContextSearch] Popup init notice:', err);
  }
}

/**
 * Handle quick manual test classification.
 */
function handleTestQuery() {
  const input = document.getElementById('test-input');
  const text = (input.value || '').trim();
  if (!text) return;

  const domainContext = classifyDomain(activeContext?.page?.url || 'https://github.com/test/repo', 'Test Page');
  const textContext = classifyText(text, domainContext);

  const testContext = {
    selection: { text, length: text.length },
    page: {
      url: activeContext?.page?.url || 'https://github.com',
      domain: domainContext.domain || 'github.com',
      title: 'Manual Query Test'
    },
    detected: {
      siteType: domainContext.siteType,
      language: domainContext.language,
      category: textContext.category,
      confidence: textContext.confidence,
      reasoning: textContext.reasoning
    }
  };

  pageSelection = false;
  renderContextUI(testContext);
}

document.addEventListener('DOMContentLoaded', async () => {
  try { customActions = await getCustomActions(); } catch { customActions = []; }
  loadActiveContext();
  renderAiStatus();

  try {
    document.getElementById('version-tag').textContent = `v${chrome.runtime.getManifest().version} · AI & dev search`;
  } catch { /* not running as an extension */ }

  // First-run quick start
  chrome.storage.local.get(['onboardingPopupSeen'], (res) => {
    if (!res || !res.onboardingPopupSeen) document.getElementById('welcome-card').style.display = 'block';
  });
  document.getElementById('welcome-dismiss').addEventListener('click', () => {
    document.getElementById('welcome-card').style.display = 'none';
    chrome.storage.local.set({ onboardingPopupSeen: true });
  });

  // Open the side panel (popup click counts as a user gesture)
  chrome.windows.getCurrent().then(w => { currentWindowId = w.id; }).catch(() => {});
  document.getElementById('open-panel-btn').addEventListener('click', () => {
    if (currentWindowId === null || !chrome.sidePanel) return;
    // Called synchronously so the click still counts as a user gesture
    chrome.sidePanel.open({ windowId: currentWindowId })
      .then(() => window.close())
      .catch((err) => console.debug('[ContextSearch] Side panel open notice:', err));
  });

  const openSettingsBtn = document.getElementById('open-settings-btn');
  if (openSettingsBtn) {
    openSettingsBtn.addEventListener('click', () => {
      if (chrome && chrome.runtime && chrome.runtime.openOptionsPage) {
        chrome.runtime.openOptionsPage();
      } else {
        window.open('../options/options.html', '_blank');
      }
    });
  }

  const testBtn = document.getElementById('test-btn');
  const testInput = document.getElementById('test-input');

  if (testBtn) testBtn.addEventListener('click', handleTestQuery);
  if (testInput) {
    testInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') handleTestQuery();
    });
  }
});
