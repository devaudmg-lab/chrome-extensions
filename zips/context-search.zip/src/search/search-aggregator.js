/**
 * Master Parallel Search Aggregator for ContextSearch (Phase 4).
 * Coordinates parallel API requests across Stack Overflow, GitHub, npm, MDN, and Bundlephobia.
 */

import { SEARCH_SOURCES } from '../shared/constants.js';
import { selectSourcesForContext } from './source-selector.js';
import { rankAndDeduplicateResults } from './result-ranker.js';
import { searchStackOverflow } from './adapters/stackoverflow-source.js';
import { searchGitHub } from './adapters/github-source.js';
import { searchNpm } from './adapters/npm-source.js';
import { searchMdn } from './adapters/mdn-source.js';
import { searchBundlephobia } from './adapters/bundlephobia-source.js';

/**
 * Execute parallel aggregated search across selected developer sources.
 * @param {object} params 
 * @param {string} params.query 
 * @param {object} params.context 
 * @param {Function} [params.onSourceResult] Progressive callback as each source resolves
 * @param {Function} [params.onComplete] Final callback with all ranked items
 * @returns {Promise<Array<object>>}
 */
export async function aggregateSearch({ query, context = {}, onSourceResult, onComplete }) {
  if (!query || !query.trim()) {
    if (onComplete) onComplete([]);
    return [];
  }

  const sources = selectSourcesForContext(context);
  const allResults = [];

  const promises = sources.map(async (source) => {
    let sourceResults = [];
    try {
      switch (source) {
        case SEARCH_SOURCES.STACKOVERFLOW:
          sourceResults = await searchStackOverflow(query, context);
          break;
        case SEARCH_SOURCES.GITHUB:
          sourceResults = await searchGitHub(query, context);
          break;
        case SEARCH_SOURCES.NPM:
          sourceResults = await searchNpm(query);
          break;
        case SEARCH_SOURCES.MDN:
          sourceResults = await searchMdn(query);
          break;
        case SEARCH_SOURCES.BUNDLEPHOBIA:
          sourceResults = await searchBundlephobia(query);
          break;
        default:
          sourceResults = [];
      }
    } catch {
      sourceResults = [];
    }

    if (sourceResults && sourceResults.length > 0) {
      allResults.push(...sourceResults);
      if (onSourceResult) {
        onSourceResult(source, sourceResults);
      }
    }
    return sourceResults;
  });

  await Promise.allSettled(promises);

  const rankedResults = rankAndDeduplicateResults(allResults, query);
  if (onComplete) {
    onComplete(rankedResults);
  }

  return rankedResults;
}
