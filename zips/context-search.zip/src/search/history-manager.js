/**
 * Research History and Pinned Bookmarks Manager for ContextSearch (Phase 4).
 */

let memoryHistory = [];
let memoryPinned = [];

/**
 * Retrieve recent search sessions.
 * @returns {Promise<Array<object>>}
 */
export async function getSearchHistory() {
  try {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      return new Promise((resolve) => {
        chrome.storage.local.get(['searchHistory'], (res) => {
          memoryHistory = res.searchHistory || [];
          resolve(memoryHistory);
        });
      });
    }
  } catch {
    // Return memory cache
  }
  return memoryHistory;
}

/**
 * Add a query to recent search history.
 * @param {string} query 
 * @param {object} context 
 * @returns {Promise<void>}
 */
export async function recordSearchSession(query, context = {}) {
  if (!query) return;

  const item = {
    id: `sess_${Date.now()}`,
    query: query.trim(),
    language: context?.detected?.language || 'code',
    siteType: context?.detected?.siteType || 'web',
    category: context?.detected?.category || '',
    timestamp: Date.now()
  };

  // Load stored history first so a freshly opened panel doesn't overwrite it
  const existing = await getSearchHistory();
  memoryHistory = [item, ...existing.filter(h => h && h.query && h.query.toLowerCase() !== item.query.toLowerCase())].slice(0, 50);

  try {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      chrome.storage.local.set({ searchHistory: memoryHistory });
    }
  } catch {
    // Ignore
  }
}

/**
 * Retrieve pinned bookmark results.
 * @returns {Promise<Array<object>>}
 */
export async function getPinnedResults() {
  try {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      return new Promise((resolve) => {
        chrome.storage.local.get(['pinnedResults'], (res) => {
          memoryPinned = res.pinnedResults || [];
          resolve(memoryPinned);
        });
      });
    }
  } catch {
    // Return memory cache
  }
  return memoryPinned;
}

/**
 * Toggle pinned status for a result card.
 * @param {object} item 
 * @returns {Promise<boolean>} True if now pinned, False if unpinned
 */
export async function togglePinResult(item) {
  if (!item || !item.url) return false;

  const current = await getPinnedResults();
  const exists = current.some(p => p.url === item.url);
  let updated = [];

  if (exists) {
    updated = current.filter(p => p.url !== item.url);
  } else {
    updated = [{ ...item, pinnedAt: Date.now() }, ...current];
  }

  memoryPinned = updated;

  try {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      await new Promise(resolve => chrome.storage.local.set({ pinnedResults: updated }, resolve));
    }
  } catch {
    // Ignore
  }

  return !exists;
}

/**
 * Delete all recent search sessions (pinned results and visited marks are kept).
 * @returns {Promise<void>}
 */
export async function clearSearchHistory() {
  memoryHistory = [];
  try {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      await new Promise(resolve => chrome.storage.local.set({ searchHistory: [] }, resolve));
    }
  } catch {
    // Ignore
  }
}

/**
 * Find an earlier session for the same query (case-insensitive).
 * @param {string} query
 * @param {Array<object>} history
 * @returns {object|null}
 */
export function findPreviousSearch(query, history = []) {
  const q = String(query || '').trim().toLowerCase();
  if (!q) return null;
  return (history || []).find(h => h && typeof h.query === 'string' && h.query.toLowerCase() === q) || null;
}

/**
 * Human-friendly "time ago" label.
 * @param {number} timestamp
 * @param {number} [now=Date.now()]
 * @returns {string}
 */
export function formatTimeAgo(timestamp, now = Date.now()) {
  const diff = Math.max(0, now - (timestamp || 0));
  const min = Math.floor(diff / 60000);
  if (min < 1) return 'just now';
  if (min < 60) return `${min} min ago`;
  const hours = Math.floor(min / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  if (days === 1) return 'yesterday';
  if (days < 30) return `${days} days ago`;
  const months = Math.floor(days / 30);
  return months <= 1 ? 'a month ago' : `${months} months ago`;
}

const MAX_VISITED = 300;

/**
 * Map of result URL -> last time it was opened from the side panel.
 * @returns {Promise<Object<string, number>>}
 */
export async function getVisitedResults() {
  try {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      return new Promise((resolve) => {
        chrome.storage.local.get(['visitedResults'], (res) => resolve((res && res.visitedResults) || {}));
      });
    }
  } catch {
    // Ignore
  }
  return {};
}

/**
 * Remember that a result URL was opened (keeps the newest MAX_VISITED entries).
 * @param {string} url
 * @returns {Promise<Object<string, number>>}
 */
export async function markResultVisited(url) {
  if (!url) return {};
  const visited = await getVisitedResults();
  visited[url] = Date.now();
  const trimmed = Object.fromEntries(
    Object.entries(visited).sort((a, b) => b[1] - a[1]).slice(0, MAX_VISITED)
  );
  try {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      await new Promise(resolve => chrome.storage.local.set({ visitedResults: trimmed }, resolve));
    }
  } catch {
    // Ignore
  }
  return trimmed;
}
