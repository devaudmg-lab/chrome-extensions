/**
 * Research History and Pinned Bookmarks Manager for ContextSearch (Phase 4).
 */

let memoryHistory = [];
let memoryPinned = [];

/**
 * Retrieve recent search sessions.
 * @returns {Promise<Array<object>>}
 */
export async function getSearchHistory() {
  try {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      return new Promise((resolve) => {
        chrome.storage.local.get(['searchHistory'], (res) => {
          memoryHistory = res.searchHistory || [];
          resolve(memoryHistory);
        });
      });
    }
  } catch {
    // Return memory cache
  }
  return memoryHistory;
}

/**
 * Add a query to recent search history.
 * @param {string} query 
 * @param {object} context 
 * @returns {Promise<void>}
 */
export async function recordSearchSession(query, context = {}) {
  if (!query) return;

  const item = {
    id: `sess_${Date.now()}`,
    query: query.trim(),
    language: context?.detected?.language || 'code',
    siteType: context?.detected?.siteType || 'web',
    timestamp: Date.now()
  };

  memoryHistory = [item, ...memoryHistory.filter(h => h.query.toLowerCase() !== query.toLowerCase())].slice(0, 20);

  try {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      chrome.storage.local.set({ searchHistory: memoryHistory });
    }
  } catch {
    // Ignore
  }
}

/**
 * Retrieve pinned bookmark results.
 * @returns {Promise<Array<object>>}
 */
export async function getPinnedResults() {
  try {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      return new Promise((resolve) => {
        chrome.storage.local.get(['pinnedResults'], (res) => {
          memoryPinned = res.pinnedResults || [];
          resolve(memoryPinned);
        });
      });
    }
  } catch {
    // Return memory cache
  }
  return memoryPinned;
}

/**
 * Toggle pinned status for a result card.
 * @param {object} item 
 * @returns {Promise<boolean>} True if now pinned, False if unpinned
 */
export async function togglePinResult(item) {
  if (!item || !item.url) return false;

  const current = await getPinnedResults();
  const exists = current.some(p => p.url === item.url);
  let updated = [];

  if (exists) {
    updated = current.filter(p => p.url !== item.url);
  } else {
    updated = [{ ...item, pinnedAt: Date.now() }, ...current];
  }

  memoryPinned = updated;

  try {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      await new Promise(resolve => chrome.storage.local.set({ pinnedResults: updated }, resolve));
    }
  } catch {
    // Ignore
  }

  return !exists;
}
