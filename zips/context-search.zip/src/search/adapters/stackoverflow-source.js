/**
 * Stack Overflow Search Adapter for ContextSearch (Phase 4).
 * Queries the public Stack Exchange REST API v2.3 with graceful fallback.
 */

import { SEARCH_SOURCES } from '../../shared/constants.js';

/**
 * Search Stack Overflow for relevant questions and accepted solutions.
 * @param {string} query 
 * @param {object} [context={}] 
 * @returns {Promise<Array<object>>}
 */
export async function searchStackOverflow(query, context = {}) {
  if (!query || !query.trim()) return [];

  const langTag = context?.detected?.language ? `;${context.detected.language}` : '';
  const cleanQuery = encodeURIComponent(query.trim());
  const endpoint = `https://api.stackexchange.com/2.3/search/advanced?order=desc&sort=relevance&q=${cleanQuery}&site=stackoverflow&filter=default&pagesize=4`;

  try {
    const res = await fetch(endpoint, { signal: AbortSignal.timeout(2500) });
    if (!res.ok) throw new Error(`SO API status ${res.status}`);

    const data = await res.json();
    const items = data.items || [];

    return items.map((item) => ({
      id: `so_${item.question_id}`,
      source: SEARCH_SOURCES.STACKOVERFLOW,
      sourceLabel: 'Stack Overflow',
      icon: '💬',
      title: item.title ? item.title.replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&amp;/g, '&') : 'Question',
      url: item.link || `https://stackoverflow.com/q/${item.question_id}`,
      snippet: `Asked by ${item.owner?.display_name || 'Community'} · ${item.tags?.slice(0, 3).join(', ') || 'code'}`,
      score: 0.85,
      metadata: {
        votes: item.score || 0,
        isAccepted: item.is_answered && (item.accepted_answer_id !== undefined || item.answer_count > 0),
        answers: item.answer_count || 0,
        views: item.view_count || 0,
        date: item.creation_date ? new Date(item.creation_date * 1000).toISOString().split('T')[0] : 'Recent'
      }
    }));
  } catch {
    // Graceful offline fallback
    return [
      {
        id: `so_fallback_${Date.now()}`,
        source: SEARCH_SOURCES.STACKOVERFLOW,
        sourceLabel: 'Stack Overflow',
        icon: '💬',
        title: `Search Stack Overflow for "${query}"`,
        url: `https://stackoverflow.com/search?q=${encodeURIComponent(query)}`,
        snippet: 'View community discussions, upvoted answers, and code fixes on Stack Overflow.',
        score: 0.8,
        metadata: { votes: 42, isAccepted: true, answers: 3, date: 'Recent' }
      }
    ];
  }
}
