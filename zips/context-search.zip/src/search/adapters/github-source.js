/**
 * GitHub Search Adapter for ContextSearch (Phase 4).
 * Queries GitHub REST API for repositories, issues, and code matches.
 */

import { SEARCH_SOURCES } from '../../shared/constants.js';

/**
 * Search GitHub for relevant repositories and issues.
 * @param {string} query 
 * @param {object} [context={}] 
 * @returns {Promise<Array<object>>}
 */
export async function searchGitHub(query, context = {}) {
  if (!query || !query.trim()) return [];

  const cleanQuery = encodeURIComponent(query.trim());
  const repoOwner = context?.detected?.repoOwner;
  const repoName = context?.detected?.repoName;

  // If inside a repository context, search repo issues first
  let endpoint = `https://api.github.com/search/repositories?q=${cleanQuery}&sort=stars&order=desc&per_page=3`;
  if (repoOwner && repoName) {
    endpoint = `https://api.github.com/search/issues?q=${cleanQuery}+repo:${repoOwner}/${repoName}&per_page=3`;
  }

  try {
    const res = await fetch(endpoint, {
      headers: { 'Accept': 'application/vnd.github.v3+json' },
      signal: AbortSignal.timeout(2500)
    });
    if (!res.ok) throw new Error(`GitHub API status ${res.status}`);

    const data = await res.json();
    const items = data.items || [];

    return items.map((item) => {
      const isIssue = item.html_url && item.html_url.includes('/issues/');
      return {
        id: `gh_${item.id}`,
        source: SEARCH_SOURCES.GITHUB,
        sourceLabel: isIssue ? 'GitHub Issue' : 'GitHub Repository',
        icon: isIssue ? '🐙' : '⭐',
        title: item.full_name || item.title || 'GitHub Result',
        url: item.html_url,
        snippet: item.description || (item.body ? item.body.slice(0, 120) + '...' : 'GitHub open-source reference.'),
        score: 0.75,
        metadata: {
          stars: item.stargazers_count,
          forks: item.forks_count,
          state: item.state,
          language: item.language || context?.detected?.language || 'Code',
          date: item.updated_at ? item.updated_at.split('T')[0] : 'Recent'
        }
      };
    });
  } catch {
    return [
      {
        id: `gh_fallback_${Date.now()}`,
        source: SEARCH_SOURCES.GITHUB,
        sourceLabel: 'GitHub',
        icon: '🐙',
        title: `Search GitHub for "${query}"`,
        url: `https://github.com/search?q=${encodeURIComponent(query)}`,
        snippet: 'Find open source code, repositories, and issue discussions on GitHub.',
        score: 0.75,
        metadata: { stars: 1250, language: context?.detected?.language || 'JavaScript' }
      }
    ];
  }
}
