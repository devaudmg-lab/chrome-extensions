/**
 * npm Package Search Adapter for ContextSearch (Phase 4).
 * Queries registry.npmjs.org search API.
 */

import { SEARCH_SOURCES } from '../../shared/constants.js';

/**
 * Search npm for package matches.
 * @param {string} query 
 * @returns {Promise<Array<object>>}
 */
export async function searchNpm(query) {
  if (!query || !query.trim()) return [];

  const cleanQuery = encodeURIComponent(query.trim());
  const endpoint = `https://registry.npmjs.org/-/v1/search?text=${cleanQuery}&size=3`;

  try {
    const res = await fetch(endpoint, { signal: AbortSignal.timeout(2500) });
    if (!res.ok) throw new Error(`npm API status ${res.status}`);

    const data = await res.json();
    const objects = data.objects || [];

    return objects.map((obj) => {
      const pkg = obj.package || {};
      return {
        id: `npm_${pkg.name}`,
        source: SEARCH_SOURCES.NPM,
        sourceLabel: 'npm Package',
        icon: '📦',
        title: pkg.name,
        url: pkg.links?.npm || `https://www.npmjs.com/package/${pkg.name}`,
        snippet: pkg.description || 'npm JavaScript/TypeScript ecosystem package.',
        score: 0.85,
        metadata: {
          version: pkg.version,
          publisher: pkg.publisher?.username,
          date: pkg.date ? pkg.date.split('T')[0] : 'Recent'
        }
      };
    });
  } catch {
    return [
      {
        id: `npm_fallback_${Date.now()}`,
        source: SEARCH_SOURCES.NPM,
        sourceLabel: 'npm Package',
        icon: '📦',
        title: query,
        url: `https://www.npmjs.com/package/${encodeURIComponent(query)}`,
        snippet: 'View package README, dependencies, and downloads on npm.',
        score: 0.8,
        metadata: { version: 'latest' }
      }
    ];
  }
}
