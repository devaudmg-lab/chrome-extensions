/**
 * MDN Documentation Search Adapter for ContextSearch (Phase 4).
 * Queries developer.mozilla.org public search API.
 */

import { SEARCH_SOURCES } from '../../shared/constants.js';

/**
 * Search MDN web documentation.
 * @param {string} query 
 * @returns {Promise<Array<object>>}
 */
export async function searchMdn(query) {
  if (!query || !query.trim()) return [];

  const cleanQuery = encodeURIComponent(query.trim());
  const endpoint = `https://developer.mozilla.org/api/v1/search?q=${cleanQuery}&locale=en-US`;

  try {
    const res = await fetch(endpoint, { signal: AbortSignal.timeout(2500) });
    if (!res.ok) throw new Error(`MDN API status ${res.status}`);

    const data = await res.json();
    const documents = (data.documents || []).slice(0, 3);

    return documents.map((doc) => ({
      id: `mdn_${doc.mdn_url}`,
      source: SEARCH_SOURCES.MDN,
      sourceLabel: 'MDN Web Docs',
      icon: '📚',
      title: doc.title || 'MDN Documentation',
      url: `https://developer.mozilla.org${doc.mdn_url}`,
      snippet: doc.summary || 'Official web standard specification and documentation.',
      score: 1.0,
      metadata: {
        isOfficial: true,
        category: 'Web Documentation'
      }
    }));
  } catch {
    return [
      {
        id: `mdn_fallback_${Date.now()}`,
        source: SEARCH_SOURCES.MDN,
        sourceLabel: 'MDN Web Docs',
        icon: '📚',
        title: `${query} — MDN Web Docs`,
        url: `https://developer.mozilla.org/en-US/search?q=${encodeURIComponent(query)}`,
        snippet: 'Comprehensive references and guides for JavaScript, HTML, CSS, and Web APIs.',
        score: 1.0,
        metadata: { isOfficial: true }
      }
    ];
  }
}
