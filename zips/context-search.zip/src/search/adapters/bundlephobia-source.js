/**
 * Bundlephobia Search Adapter for ContextSearch (Phase 4).
 * Queries bundlephobia.com bundle size API.
 */

import { SEARCH_SOURCES } from '../../shared/constants.js';

/**
 * Fetch package bundle size from Bundlephobia.
 * @param {string} packageName 
 * @returns {Promise<Array<object>>}
 */
export async function searchBundlephobia(packageName) {
  if (!packageName || !packageName.trim()) return [];

  const cleanName = packageName.trim().replace(/^@/, '').replace('/', '%2F');
  const endpoint = `https://bundlephobia.com/api/size?package=${cleanName}`;

  try {
    const res = await fetch(endpoint, { signal: AbortSignal.timeout(2000) });
    if (!res.ok) throw new Error(`Bundlephobia status ${res.status}`);

    const data = await res.json();
    const minifiedKb = (data.size / 1024).toFixed(1);
    const gzipKb = (data.gzip / 1024).toFixed(1);

    return [
      {
        id: `bundle_${data.name}`,
        source: SEARCH_SOURCES.BUNDLEPHOBIA,
        sourceLabel: 'Bundlephobia Size',
        icon: '⚖️',
        title: `${data.name} (${gzipKb} kB min+gzip)`,
        url: `https://bundlephobia.com/package/${data.name}`,
        snippet: `Minified: ${minifiedKb} kB · Gzipped: ${gzipKb} kB · Version: ${data.version}`,
        score: 0.85,
        metadata: {
          sizeKb: minifiedKb,
          gzipKb: gzipKb,
          version: data.version
        }
      }
    ];
  } catch {
    return [];
  }
}
