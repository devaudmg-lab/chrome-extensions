/**
 * Result Ranker and Normalizer for ContextSearch (Phase 4).
 * Combines relevance, domain authority, community engagement, and recency.
 */

import { SEARCH_SOURCES } from '../shared/constants.js';

const AUTHORITY_WEIGHTS = {
  [SEARCH_SOURCES.MDN]: 1.0,
  [SEARCH_SOURCES.STACKOVERFLOW]: 0.9,
  [SEARCH_SOURCES.NPM]: 0.85,
  [SEARCH_SOURCES.BUNDLEPHOBIA]: 0.85,
  [SEARCH_SOURCES.GITHUB]: 0.8,
  [SEARCH_SOURCES.GOOGLE]: 0.6
};

/**
 * Calculate multi-factor ranking score for a search result card.
 * @param {object} item 
 * @param {string} query 
 * @returns {number} Score between 0 and 1
 */
export function calculateResultScore(item, query = '') {
  const cleanQuery = (query || '').toLowerCase().trim();
  const title = (item.title || '').toLowerCase();
  const snippet = (item.snippet || '').toLowerCase();

  // 1. Relevance factor (0 to 1)
  let relevance = 0.5;
  if (title.includes(cleanQuery)) {
    relevance = 1.0;
  } else if (snippet.includes(cleanQuery)) {
    relevance = 0.8;
  }

  // 2. Domain Authority factor
  let authority = AUTHORITY_WEIGHTS[item.source] || 0.7;
  if (item.metadata?.isAccepted) {
    authority = 1.0; // Bonus for verified accepted Stack Overflow answer
  }

  // 3. Community Engagement factor (votes / stars)
  let engagement = 0.5;
  if (item.metadata?.votes) {
    engagement = Math.min(1.0, 0.5 + Math.log10(Math.max(1, item.metadata.votes)) * 0.2);
  } else if (item.metadata?.stars) {
    engagement = Math.min(1.0, 0.5 + Math.log10(Math.max(1, item.metadata.stars)) * 0.15);
  }

  // 4. Recency factor
  let recency = 0.7;
  if (item.metadata?.date === 'Recent' || (item.metadata?.date && item.metadata.date.startsWith('202'))) {
    recency = 0.9;
  }

  // Weighted sum
  const finalScore = (relevance * 0.40) + (authority * 0.25) + (engagement * 0.20) + (recency * 0.15);
  return Math.round(finalScore * 100) / 100;
}

/**
 * Deduplicate and sort search results descending by score.
 * @param {Array<object>} results 
 * @param {string} query 
 * @returns {Array<object>}
 */
export function rankAndDeduplicateResults(results = [], query = '') {
  const seenUrls = new Set();
  const scoredItems = [];

  for (const item of results) {
    if (!item || !item.url) continue;
    if (seenUrls.has(item.url)) continue;
    seenUrls.add(item.url);

    const score = calculateResultScore(item, query);
    scoredItems.push({
      ...item,
      score
    });
  }

  return scoredItems.sort((a, b) => b.score - a.score);
}
