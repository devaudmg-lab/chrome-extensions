/**
 * Source Selector for ContextSearch (Phase 4).
 * Selects 3-4 optimal query sources based on context category and platform.
 */

import { SEARCH_SOURCES, TEXT_CATEGORIES, SITE_TYPES } from '../shared/constants.js';

/**
 * Determine which sources to query for a given context.
 * @param {object} context 
 * @returns {Array<string>} List of SEARCH_SOURCES
 */
export function selectSourcesForContext(context = {}) {
  const detected = context?.detected || {};
  const category = detected.category || TEXT_CATEGORIES.CONCEPT;
  const siteType = detected.siteType || SITE_TYPES.GENERIC;

  // 1. Errors: Stack Overflow + GitHub Issues + MDN
  if (category === TEXT_CATEGORIES.ERROR) {
    return [
      SEARCH_SOURCES.STACKOVERFLOW,
      SEARCH_SOURCES.GITHUB,
      SEARCH_SOURCES.MDN
    ];
  }

  // 2. Packages: npm + Bundlephobia + GitHub
  if (category === TEXT_CATEGORIES.PACKAGE || siteType === SITE_TYPES.NPM) {
    return [
      SEARCH_SOURCES.NPM,
      SEARCH_SOURCES.BUNDLEPHOBIA,
      SEARCH_SOURCES.GITHUB
    ];
  }

  // 3. Code & Functions: MDN/Docs + GitHub Code + Stack Overflow
  if (category === TEXT_CATEGORIES.CODE || category === TEXT_CATEGORIES.API) {
    return [
      SEARCH_SOURCES.MDN,
      SEARCH_SOURCES.GITHUB,
      SEARCH_SOURCES.STACKOVERFLOW
    ];
  }

  // 4. CLI Commands: Stack Overflow + GitHub + Google
  if (category === TEXT_CATEGORIES.COMMAND) {
    return [
      SEARCH_SOURCES.STACKOVERFLOW,
      SEARCH_SOURCES.GITHUB,
      SEARCH_SOURCES.GOOGLE
    ];
  }

  // 5. Default Concepts: MDN + Stack Overflow + GitHub
  return [
    SEARCH_SOURCES.MDN,
    SEARCH_SOURCES.STACKOVERFLOW,
    SEARCH_SOURCES.GITHUB
  ];
}
