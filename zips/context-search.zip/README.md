# ContextSearch: AI & Multi-Source Developer Search

Select text on any web page and ContextSearch figures out what it is (an error message, a CLI command, an npm package, an API name, a file path, a plain concept), where you are (GitHub, Stack Overflow, MDN, npm, ...) and offers the most useful actions for it.

## Features

- **Floating command palette** (`Ctrl+Shift+Space`, `Cmd+Shift+Space` on Mac): context-aware actions, keyboard navigation (arrows, `1`-`9`, Enter, Esc). It can also open automatically on selection or from a small hover icon (Settings > General).
- **Inline AI answers**: Explain, Debug, Find Solutions, Summarize, Generate Tests and more, streamed straight into the page. Bring your own key for Google Gemini, OpenAI or Anthropic, or use a local model through Ollama or any OpenAI-compatible endpoint. Without a key it runs in Demo Mode.
- **Ask anything** (new in 0.4.0): type your own question about the selection in the palette's "Ask AI about this…" box (`/` jumps there).
- **Stop and Regenerate** (new in 0.4.0): stop a long answer mid-stream, or get a fresh one that skips the response cache.
- **Learns your favourite actions** (new in 0.4.0): actions you use often (3+ times) move up in the palette; the best match for the selection stays first. Turn it off in Settings > General.
- **Right-click AI actions answer in the page** (0.4.0): Explain, Debug and the other AI items in the right-click menu and the toolbar popup open the in-page answer panel instead of a web search.
- **Follow-up questions** (0.3.0): after an answer, type a follow-up right in the panel. ContextSearch sends the earlier turns along so the AI keeps the context (up to 6 follow-ups). Copy All copies the whole conversation.
- **Local Ollama, no key needed** (new): Options detects a running Ollama and offers to use it. "Detect models" lists the models you have installed so you can pick one with a click.
- **Deep Research side panel**: searches Stack Overflow, GitHub, npm (with Bundlephobia sizes) and MDN in parallel, ranks the results, writes an AI summary you can copy, and lets you pin results as bookmarks.
- **Search history hints** (new): the side panel lists your recent searches, tells you when you researched the same thing before, and marks results you already opened with "✓ Visited".
- **Works on web-component pages** (fixed): selecting code inside components such as MDN's code samples now picks up the right text and places the palette next to it.
- **Right-click menu**: contextual actions plus "Deep Research in Side Panel" for any selection.
- **Custom actions & preset packs**: your own URL templates or AI prompts with `{selection}`, `{rawSelection}`, `{language}`, `{repo}`, `{domain}` and more. Import and export your configuration as JSON (API keys are left out by default).
- **Shareable action packs** (new): export just your custom actions as a small JSON file and import a teammate's pack. Imports are checked first: only `http(s)` links and non-empty prompts are accepted, and you see the list before anything is added.
- **Productivity insights**: search history, language and category breakdown, CSV export, and a Clear button.
- **Privacy**: no telemetry and no ContextSearch server. Requests go directly from your browser to the AI provider and search APIs you use. Password fields and blacklisted domains are ignored.

## Keyboard shortcuts

| Where | Keys | What it does |
| --- | --- | --- |
| Any page | `Ctrl+Shift+Space` (`Cmd+Shift+Space` on Mac) | Open the palette for the selected text |
| Palette | `↑` `↓`, `1`-`9`, `Enter`, `Esc` | Move, run an action, close |
| Palette | `/` | Jump to the "Ask AI about this…" box (`Enter` asks, `Esc` clears) |
| AI answer panel | `/` | Jump to the follow-up box (`Enter` sends) |
| AI answer panel | `Esc` | Clear the follow-up box, or close the panel |
| Side panel | `/` | Focus the search box |
| Side panel | `Esc` | Close the recent searches / pinned drawers |
| Browser | set at `chrome://extensions/shortcuts` | "Open ContextSearch Side Panel" (no default key) |

## Install (Load unpacked)

1. Download and unzip the ZIP.
2. Open `chrome://extensions` and turn on **Developer mode** (top right).
3. Click **Load unpacked** and select the unzipped folder (the one that contains `manifest.json`).
4. Pin ContextSearch to the toolbar. Open its **Options** page to choose an AI provider, add your API key and click **Save & Test Connection**.

Using Ollama: if Ollama is running, the **AI Models** tab shows "Ollama is running on this computer": click **Use Ollama**. Otherwise choose "Local Ollama / OpenAI-compatible", click **🦙 Ollama defaults** and pick one of the detected models. If Ollama answers with 403, start it with `OLLAMA_ORIGINS=chrome-extension://*`.

You can change the keyboard shortcuts at `chrome://extensions/shortcuts`.

## Permissions

| Permission | Why |
| --- | --- |
| Content script on all sites | Reads the text you select and shows the floating palette. Nothing is read until you select text. |
| `https://*/*` host access | Lets the extension call the AI provider you configure and the public search APIs (Stack Exchange, GitHub, npm, MDN, Bundlephobia), and lets it add the palette to tabs that were already open when you installed it. |
| `http://localhost`, `http://127.0.0.1` | Only used for local AI servers such as Ollama (sending prompts, and listing installed models when you open the AI Models tab or click "Detect models"). |
| `contextMenus` | Adds the right-click menu. |
| `storage` | Saves settings, custom actions, search history, pinned and visited results, and the AI response cache. API keys stay in local storage and never sync. Everything stays on your computer. Since 0.4.0 local storage is restricted to the extension's own pages: scripts running inside web pages (including ContextSearch's own content script) cannot read your keys, answers or history. |
| `sidePanel` | The Deep Research side panel. |
| `activeTab`, `scripting` | Read the current tab's context from the toolbar popup, and inject the content script into tabs that were already open when you installed or updated the extension. |

## Development

```bash
npm test   # offline unit tests (Node's built-in test runner)
```

No build step: the extension runs directly from the source files.

No new permissions were added in 0.3.0 or 0.4.0.

## Security notes

- The palette and AI panel live in a **closed** shadow root that the content script creates itself. Page scripts see only an empty host element: they cannot read the answers, the conversation or anything else inside it.
- AI requests run in the service worker, so API keys never enter the page. Gemini keys are sent in the `x-goog-api-key` header, not in the URL.
- Only the modules the content script needs are web-accessible (no extension pages), so sites cannot frame the Options page.
- Imported configuration files are checked: unknown settings are dropped, and a change of AI provider or endpoint, or bundled API keys, needs your explicit OK.
- Custom URL actions, links in answers and search-result links must be `http(s)`.
- Known limit: keystrokes typed into the in-page Ask and follow-up boxes are keyboard events the page can observe (as with any in-page input). The answers themselves stay private.

## Changelog

See the Changelog section at the end of `memory.md`. 0.4.0 adds Ask anything, Stop/Regenerate and learned action order, and hardens privacy (closed shadow root, keys unreadable from content scripts, safer imports). 0.3.0 adds follow-up questions, Ollama model detection, search history hints, shareable action packs and onboarding, and fixes selection inside web components, panel positioning and history being overwritten.
