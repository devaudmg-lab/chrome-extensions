# ContextSearch: AI & Multi-Source Developer Search

Select text on any web page and ContextSearch figures out what it is (an error message, a CLI command, an npm package, an API name, a file path, a plain concept), where you are (GitHub, Stack Overflow, MDN, npm, ...) and offers the most useful actions for it.

## Features

- **Floating command palette** (`Ctrl+Shift+Space`, `Cmd+Shift+Space` on Mac): context-aware actions, keyboard navigation (arrows, `1`-`9`, Enter, Esc). It can also open automatically on selection or from a small hover icon (Settings > General).
- **Inline AI answers**: Explain, Debug, Find Solutions, Summarize, Generate Tests and more, streamed straight into the page. Bring your own key for Google Gemini, OpenAI or Anthropic, or use a local model through Ollama or any OpenAI-compatible endpoint. Without a key it runs in Demo Mode.
- **Deep Research side panel**: searches Stack Overflow, GitHub, npm (with Bundlephobia sizes) and MDN in parallel, ranks the results, writes an AI summary you can copy, and lets you pin results as bookmarks.
- **Right-click menu**: contextual actions plus "Deep Research in Side Panel" for any selection.
- **Custom actions & preset packs**: your own URL templates or AI prompts with `{selection}`, `{rawSelection}`, `{language}`, `{repo}`, `{domain}` and more. Import and export your configuration as JSON (API keys are left out by default).
- **Productivity insights**: search history, language and category breakdown, CSV export.
- **Privacy**: no telemetry and no ContextSearch server. Requests go directly from your browser to the AI provider and search APIs you use. Password fields and blacklisted domains are ignored.

## Install (Load unpacked)

1. Download and unzip the ZIP.
2. Open `chrome://extensions` and turn on **Developer mode** (top right).
3. Click **Load unpacked** and select the unzipped folder (the one that contains `manifest.json`).
4. Pin ContextSearch to the toolbar. Open its **Options** page to choose an AI provider, add your API key and click **Save & Test Connection**.

Using Ollama: choose "Custom / Ollama / OpenRouter", set the base URL to `http://localhost:11434/v1` and enter a model name you have pulled (for example `llama3`). If Ollama answers with 403, start it with `OLLAMA_ORIGINS=chrome-extension://*`.

You can change the keyboard shortcuts at `chrome://extensions/shortcuts`.

## Permissions

| Permission | Why |
| --- | --- |
| Content script on all sites | Reads the text you select and shows the floating palette. Nothing is read until you select text. |
| `https://*/*` host access | Lets the extension call the AI provider you configure and the public search APIs (Stack Exchange, GitHub, npm, MDN, Bundlephobia), and lets it add the palette to tabs that were already open when you installed it. |
| `http://localhost`, `http://127.0.0.1` | Only used for local AI servers such as Ollama. |
| `contextMenus` | Adds the right-click menu. |
| `storage` | Saves settings, custom actions, history, pinned results and the AI response cache. API keys stay in local storage and never sync. |
| `sidePanel` | The Deep Research side panel. |
| `activeTab`, `scripting` | Read the current tab's context from the toolbar popup, and inject the content script into tabs that were already open when you installed or updated the extension. |

## Development

```bash
npm test   # offline unit tests (Node's built-in test runner)
```

No build step: the extension runs directly from the source files.
